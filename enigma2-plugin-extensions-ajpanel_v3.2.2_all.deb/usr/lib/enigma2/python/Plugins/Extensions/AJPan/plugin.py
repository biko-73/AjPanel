import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, sleep as iSleep
from time      import time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVU39M   = "v3.2.2"
VVS3oD    = "26-11-2021"
EASY_MODE    = 0
VV08un   = 0
VVqa96   = 0
VVDaUI  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVZfME  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVTiP2    = "/media/usb/"
VVBrAU    = "/usr/share/enigma2/picon/"
VVBjVb   = "/etc/enigma2/"
VVdOEs  = "ajpanel_update_url"
VVAdrV   = "AJPan"
VVjBnN    = ""
VVD1DD    = "Regular"
VVbwqB      = "-" * 80;
VVeSPq    = ("-" * 100, )
VVrz5L    = ""
VVKMzT   = " && echo 'Successful' || echo 'Failed!'"
VVVIG4    = []
VVbfxK  = "Cannot continue (No Enough Memory) !"
VV9l3Q     = 0
VVCkF3    = ""
VVp9kL  = False
VVRd2T  = False
VVXcKu     = 0
VVn9gY    = 1
VVW5aH    = 2
VVsERI   = 3
VVjxSB    = 4
VVpQFS    = 5
VVlcNn = 6
VVw4sR = 7
VVEb36  = 8
VV2Yz5   = 9
VVI3ap   = 10
VVhFAf   = 11
VVTk2N  = 12
VVEDFg  = 13
VV4xK4    = 14
VV9oGS   = 15
VVNcca   = 16
VVEjzp    = 17
VVX081    = 18
VVkFi9  = 15
VVhB6f   = 0
VVDZSi   = 1
VVx3E7   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.PIconsPath     = ConfigDirectory(default=VVBrAU, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVTiP2, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFRSxc():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV1BBp  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV3Skg = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV1BBp  : return 0
  elif VV3Skg : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVQX76 = FFRSxc()
VVQAQ9 = VVho0k = VVlb6B = VVP2je = VVHtZw = VVHecB = VVaENg = VVBlp5 = COLOR_CONS_BRIGHT_YELLOW = VVmWy8 = VVsahr = VVpw0r = ""
def FFlJTu(FFlJTuText="", addSep=True):
 if VV08un:
  FFlJTuText = str(FFlJTuText)
  if "\n" in FFlJTuText: FFlJTuText = "\n" + FFlJTuText
  txt = VVbwqB + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFlJTuText))
  os.system("cat << '_EOF' \n" + txt + "\n_EOF")
def FFwKP2(txt, isAppend=True, ignoreErr=False):
 if VV08un:
  tm = FF2QNV()
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFlJTu(err)
  FFlJTu("Output Log File : %s" % fileName)
VVVIG4 = []
def FFLQL2(win):
 global VVVIG4
 if not win in VVVIG4:
  VVVIG4.append(win)
def FFmCer(*args):
 global VVVIG4
 for win in VVVIG4:
  try:
   win.close()
  except:
   pass
 VVVIG4 = []
def FFS7Lg():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVTkrv = FFS7Lg()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFLilK()      : return getDescriptor(FFxJh9   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FF06ef()   : return getDescriptor(FFxJh9   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFTpdP()   : return getDescriptor(FF41pO , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager")
def FFyI0S()  : return getDescriptor(FFi7JK , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Live Log (OSCam/NCam)")
def FFuOr0(): return getDescriptor(FFJji3 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player")
def FF3Tq3()  : return getDescriptor(FFZqVh  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV")
def FFVKHI()     : return getDescriptor(FFO1uf , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info.")
def FFT5fn()       : return getDescriptor(FFJ1xZ  , [ PluginDescriptor.WHERE_MENU    ] )
def FFKgta()     : return PluginDescriptor(fnc=FFfVzC, where=[PluginDescriptor.WHERE_SESSIONSTART])
def Plugins(**kwargs):
 result = [ FFLilK() , FFT5fn() , FFKgta() , FFVKHI()]
 if CFG.showInExtensionMenu.getValue():
  result.append(FF06ef())
  result.append(FFTpdP())
  result.append(FFyI0S())
  result.append(FFuOr0())
  result.append(FF3Tq3())
 return result
def FFfVzC(reason, **kwargs):
 if reason == 0:
  FFucN3()
  if "session" in kwargs:
   session = kwargs["session"]
   FFXF1Q(session)
   CChBbB(session)
def FFJ1xZ(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFxJh9, PLUGIN_NAME, 45)]
 else:
  return []
def FFxJh9(session, **kwargs):
 session.open(Main_Menu)
def FF41pO(session, **kwargs):
 session.open(CCZMP9)
def FFi7JK(session, **kwargs):
 FFUjUP(session, CC4JVg.VVpOD5)
def FFJji3(session, **kwargs):
 FFMt8K(session, isFromSession=True)
def FFZqVh(session, **kwargs):
 session.open(CCRT5i)
def FFO1uf(session, **kwargs):
 session.open(CCS14C, fncMode=CCS14C.VVch8F)
def FFl727():
 pluginList   = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel   = FF06ef()
 descrFileMan  = FFTpdP()
 descrCamLog   = FFyI0S()
 descrSignalPlayer = FFuOr0()
 descrIptvMenu  = FF3Tq3()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel in pluginList   : iPlugins.addPlugin(descrPanel)
   if not descrFileMan in pluginList  : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList  : iPlugins.addPlugin(descrCamLog)
   if not descrSignalPlayer in pluginList : iPlugins.addPlugin(descrSignalPlayer)
   if not descrIptvMenu in pluginList  : iPlugins.addPlugin(descrIptvMenu)
  else:
   if descrPanel in pluginList    : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList   : iPlugins.removePlugin(descrFileMan)
   if descrCamLog in pluginList   : iPlugins.removePlugin(descrCamLog)
   if descrSignalPlayer in pluginList  : iPlugins.removePlugin(descrSignalPlayer)
   if descrIptvMenu in pluginList   : iPlugins.removePlugin(descrIptvMenu)
 except:
  pass
VV71Kr = None
def FFucN3():
 try:
  global VV71Kr
  if VV71Kr is None:
   VV71Kr    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFCLqm
  ChannelContextMenu.FFNYQA = FFNYQA
 except:
  pass
def FFCLqm(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV71Kr(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFNYQA, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFNYQA, title1, csel, isFind=True))))
def FFNYQA(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFPlzC(refCode)
 except:
  pass
 self.session.open(boundFunction(CCig7L, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFXF1Q(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFVZlM, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFVZlM, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFVZlM, session, "lred")
def FFVZlM(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFMt8K(session, isFromSession=True)
def FFgoqU(SELF, title="", addLabel=False, addScrollLabel=False, VVhjJY=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFRiG8()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCuAq6(SELF)
 if VVhjJY:
  SELF["myMenu"] = MenuList(VVhjJY)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVWwkM        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFE1I9(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF2jRa, SELF, "0") ,
  "1"    : boundFunction(FF2jRa, SELF, "1") ,
  "2"    : boundFunction(FF2jRa, SELF, "2") ,
  "3"    : boundFunction(FF2jRa, SELF, "3") ,
  "4"    : boundFunction(FF2jRa, SELF, "4") ,
  "5"    : boundFunction(FF2jRa, SELF, "5") ,
  "6"    : boundFunction(FF2jRa, SELF, "6") ,
  "7"    : boundFunction(FF2jRa, SELF, "7") ,
  "8"    : boundFunction(FF2jRa, SELF, "8") ,
  "9"    : boundFunction(FF2jRa, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FF0fId, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF2jRa(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVpw0r:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVpw0r + SELF.keyPressed + VVho0k)
    txt = VVho0k + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFbo0g(SELF, txt)
def FF0fId(SELF, tableObj, colNum):
 FFbo0g(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVmOep()
     break
 except:
  pass
def FFcqFA(SELF, setMenuAction=True):
 if setMenuAction:
  global VVrz5L
  VVrz5L = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFRiG8():
 return ("  %s" % VVrz5L)
def FFmNCq(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFdqBS(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFpT1f(color):
 return parseColor(color).argb()
def FF55DC(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFYzPI(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFcSxA(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF6vFh(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVpw0r)
 else:
  return ""
def FF1Vsg(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVbwqB, word, VVbwqB, VVpw0r)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVbwqB, word, VVbwqB)
def FF34IZ(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVpw0r
def FFA8ba(color):
 if color: return "echo -e '%s' %s;" % (VVbwqB, FF6vFh(VVbwqB, VVBlp5))
 else : return "echo -e '%s';" % VVbwqB
def FF03HQ(title, color):
 title = "%s\n%s\n%s\n" % (VVbwqB, title, VVbwqB)
 return FF34IZ(title, color)
def FF9iGG(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFbRrW(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFC95U(callBackFunction):
 tCons = CCL2ur()
 tCons.ePopen("echo", boundFunction(FFXqh9, callBackFunction))
def FFXqh9(callBackFunction, result, retval):
 callBackFunction()
def FFdDg8(SELF, fnc, title="Processing ...", clearMsg=True):
 FFbo0g(SELF, title)
 tCons = CCL2ur()
 tCons.ePopen("echo", boundFunction(FFrgZ4, SELF, fnc, clearMsg))
def FFrgZ4(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFbo0g(SELF)
def FFMlfy(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVbfxK
  else       : return ""
def FFHErt(cmd):
 txt = FFMlfy(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFCpPs(cmd):
 lines = FFHErt(cmd)
 if lines: return lines[0]
 else : return ""
def FFj3m1(SELF, cmd):
 lines = FFHErt(cmd)
 VVEl38 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVEl38.append((key, val))
  elif line:
   VVEl38.append((line, ""))
 if VVEl38:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFrMdi(SELF, None, header=header, VV8klC=VVEl38, VVxJaI=widths, VVhj1e=28)
 else:
  FF1tu3(SELF, cmd)
def FF1tu3(    SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, VVkl4E=True, VV9aL5=VVDZSi, **kwargs)
def FFch3D(  SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, **kwargs)
def FFEKD5(   SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, VVggza=True, VVFCuN=True, VV9aL5=VVDZSi, **kwargs)
def FFhEdh(  SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, VVggza=True, VVFCuN=True, VV9aL5=VVx3E7, **kwargs)
def FFTgBK(  SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, VV9GFV=True , **kwargs)
def FFjd2i( SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, VV6FiF=True   , **kwargs)
def FFYm78( SELF, cmd, **kwargs): SELF.session.open(CCmXLq, VVHIgK=cmd, VVoDEx=True  , **kwargs)
def FF0t1y(cmd):
 return cmd + " > /dev/null 2>&1"
def FFibik():
 return " > /dev/null 2>&1"
def FF5sJ5(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFF164(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFm75l():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFCpPs(cmd)
VVQVcc     = 0
VVkg6U      = 1
VVEKL9   = 2
VVa81b      = 3
VVFTJH      = 4
VVgLqE     = 5
VVSeHH     = 6
VVKhUe  = 7
VVBK9Y = 8
VVW7Xu  = 9
VVA4To     = 10
VVvsDU  = 11
VVmOpe  = 12
def FFGMYv(parmNum, grepTxt):
 if   parmNum == VVQVcc  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVkg6U   : param = ["list"   , "apt list" ]
 elif parmNum == VVEKL9: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFm75l()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFBSlb(parmNum, package):
 if   parmNum == VVa81b      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVFTJH      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VVgLqE     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVSeHH     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVKhUe  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVBK9Y : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVW7Xu  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVA4To     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVvsDU  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVmOpe  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFm75l()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFzWrJ():
 result = FFCpPs("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFBSlb(VVSeHH , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FF0t1y("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FF0t1y("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF6vFh(failed1, VVBlp5))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF6vFh(failed2, VVBlp5))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF6vFh(failed3, VVlb6B))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFcnwo(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFBSlb(VVSeHH , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FF0t1y("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF6vFh(failed1, VVBlp5))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF6vFh(failed2, VVlb6B))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFScuV(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FF0t1y('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FF0t1y("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFtCkf(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFPPAc(path, keepends=False, maxSize=-1):
 lines = FFtCkf(path, maxSize)
 return lines.splitlines(keepends)
def FFC3ew(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFPPAc(path, maxSize=maxSize)
  if lines: FFh3cd(SELF, lines, title=title, VV9aL5=VVDZSi)
  else : FFwNVh(SELF, path, title=title)
 else:
  FF5BoZ(SELF, path, title)
def FFmkwn(SELF, path, title):
 if fileExists(path):
  txt = FFtCkf(path)
  txt = txt.replace("#W#", VVpw0r)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVho0k)
  txt = txt.replace("#C#", VVmWy8)
  txt = txt.replace("#P#", VVP2je)
  FFh3cd(SELF, txt, title=title)
 else:
  FF5BoZ(SELF, path, title)
def FF5o9M(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF9ZzK(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFDFii(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFoGIr(parent)
 else    : return FFNOsT(parent)
def FF1HLI(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFoGIr(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFNOsT(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFoJFq():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVDaUI)
 paths.append(VVDaUI.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF9ZzK(ba)
 for p in list:
  p = ba + p + VVDaUI
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVAdrV, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVDaUI, VVAdrV , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV38ZS, VVVIGI = FFoJFq()
def FFl7aG():
 def VVGf7P(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVPI5g  = VVGf7P(CFG.backupPath, CCg4Sp.VVkqTN())
 VVSIbg  = VVGf7P(CFG.downloadedPackagesPath, t)
 VVIyEh = VVGf7P(CFG.exportedTablesPath, t)
 VVr5xQ = VVGf7P(CFG.exportedPIconsPath, t)
 VVGq05  = VVGf7P(CFG.packageOutputPath, t)
 global VVTiP2
 VVTiP2 = FFoGIr(CFG.backupPath.getValue())
 if VVPI5g or VVGq05 or VVSIbg or VVIyEh or VVr5xQ:
  configfile.save()
 return VVPI5g, VVGq05, VVSIbg, VVIyEh, VVr5xQ
def FFWoUk(path):
 path = FFNOsT(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFODZ8(SELF, pathList, tarFileName, addTimeStamp=True):
 VV8klC = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV8klC.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV8klC.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV8klC.append(path)
 if not VV8klC:
  FFdx4k(SELF, "Files not found!")
 elif not pathExists(VVTiP2):
  FFdx4k(SELF, "Path not found!\n\n%s" % VVTiP2)
 else:
  VV1Ocz = FFoGIr(VVTiP2)
  tarFileName = "%s%s" % (VV1Ocz, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFmJh3())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV8klC:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVbwqB
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF6vFh(tarFileName, VVaENg))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF6vFh(failed, VVaENg))
  cmd += "fi;"
  cmd +=  sep
  FFch3D(SELF, cmd)
def FFmy0U(SELF, title, VViC2s):
 SELF.session.open(boundFunction(CCEP0s, Title=title, VViC2s=VViC2s))
def FFGkqs(labelObj, VViC2s):
 if VViC2s and fileExists(VViC2s):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVkAgp(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVkAgp)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VViC2s)
   return True
  except:
   pass
 return False
def FFOLoN(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFkiAa(satNum)
  return satName
def FFkiAa(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFl7Hp(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFOLoN(val)
  else  : sat = FFkiAa(val)
 return sat
def FFGAsY(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFOLoN(num)
 except:
  pass
 return sat
def FF5cxP(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFI5ot(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFFIZe(info, iServiceInformation.sServiceref)
   prov = FFFIZe(info, iServiceInformation.sProvider)
   state = str(FFFIZe(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFgsAM(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFk1Ul(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFFIZe(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFvoWy(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFPlzC(refCode):
 info = FFosLx(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FForgx(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFWB9I(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFosLx(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVSU8l = eServiceCenter.getInstance()
  if VVSU8l:
   info = VVSU8l.info(service)
 return info
def FF4ffD(SELF, refCode, VVXA27=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFUosa(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVXA27:
   FFMt8K(SELF, isFromSession)
 try:
  VV8xAY = InfoBar.instance
  if VV8xAY:
   VVOnZD = VV8xAY.servicelist
   if VVOnZD:
    servRef = eServiceReference(refCode)
    VVOnZD.saveChannel(servRef)
 except:
  pass
def FFUosa(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCN49V()
    if pr.VV0C5a(refCode, chName, decodedUrl, iptvRef):
     pr.VVIB8k(SELF, isFromSession)
def FFgsAM(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFk1Ul(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFDQFE(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFADrf(userBfile):
 txt = ""
 bFile = VVBjVb + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVBjVb + userBfile):
  fTxt = FFtCkf(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFCpPs('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFDQFE(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFbKZa(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFs7CX(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFScix(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF9axR(txt):
 try:
  return FFs7CX(FFScix(txt)) == txt
 except:
  return False
def FFMt8K(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CClGFA, isFromExternal=isFromSession)
 else      : FFU7WM(session, reopen=True)
def FFU7WM(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFU7WM, session), CC6O8G)
  except:
   try:
    FFiu9f(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFIKVK(refCode):
 tp = CCGAc5()
 if tp.VV7VOo(refCode) : return True
 else        : return False
def FFXDAC(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FF28nO():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFeUK9():
 VV8xAY = InfoBar.instance
 if VV8xAY:
  VVOnZD = VV8xAY.servicelist
  if VVOnZD:
   return VVOnZD.getBouquetList()
 return None
def FFLobe():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFToW0():
 path = FFLobe()
 if path:
  txt = FFtCkf(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FF8JSw(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVSU8l = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVSU8l.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FF3PrL():
 VVWauh = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVsyWY = list(VVWauh)
 return VVsyWY, VVWauh
def FFqgU2():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFUjUP(session, VV2hVw):
 VVJHTm, VVEnWi, VVMm1W, camCommand = FFn4bL()
 if VVEnWi:
  runLog = False
  if   VV2hVw == CC4JVg.VVdghp : runLog = True
  elif VV2hVw == CC4JVg.VV2V2y : runLog = True
  elif not VVMm1W          : FFiu9f(session, message="SoftCam not started yet!")
  elif fileExists(VVMm1W)        : runLog = True
  else             : FFiu9f(session, message="File not found !\n\n%s" % VVMm1W)
  if runLog:
   session.open(boundFunction(CC4JVg, VVJHTm=VVJHTm, VVEnWi=VVEnWi, VVMm1W=VVMm1W, VV2hVw=VV2hVw))
 else:
  FFiu9f(session, message="No active OSCam/NCam found !", title="Live Log")
def FFn4bL():
 VVJHTm = "/etc/tuxbox/config/"
 VVEnWi = None
 VVMm1W  = None
 camCommand = FFCpPs("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVEnWi = "oscam"
 elif "ncam"  in camCommand : VVEnWi = "ncam"
 if VVEnWi:
  path = FFCpPs(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFoGIr(path)
  if pathExists(path):
   VVJHTm = path
  tFile = VVJHTm + VVEnWi + ".conf"
  tFile = FFCpPs("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVMm1W = tFile
 return VVJHTm, VVEnWi, VVMm1W, camCommand
def FFCnzX(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFvbBP():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFmJh3():
 return FFvbBP().replace(" ", "_").replace("-", "").replace(":", "")
def FF4dJc(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF2QNV():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFgxGp(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCRT5i.VV8xGu(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCRT5i.VVzVND(fName)
     phpFile = tmpDir + fName + ext
     os.system(FF0t1y("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FF3oWp(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFXuQi(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFmcrU():
 return int(FFMlfy("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFOKUh():
 global VV9l3Q_TIME, VVCkF3
 VVCkF3  = int(FFmcrU())
 VV9l3Q_TIME = iTime()
def FF2Yzq():
 elapsed = iTime() - VV9l3Q_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFmcrU() - VVCkF3
 FFlJTu(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFUbus(SELF, message, title=""):
 SELF.session.open(boundFunction(CC5gEw, title=title, message=message, VVGDsG=True))
def FFh3cd(SELF, message, title="", VV9aL5=VVDZSi, **kwargs):
 SELF.session.open(boundFunction(CC5gEw, title=title, message=message, VV9aL5=VV9aL5, **kwargs))
def FFdx4k(SELF, message, title="")  : FFiu9f(SELF.session, message, title)
def FF5BoZ(SELF, path, title="") : FFiu9f(SELF.session, "File not found !\n\n%s" % path, title)
def FFwNVh(SELF, path, title="") : FFiu9f(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFHvqH(SELF, title="")  : FFiu9f(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFiu9f(session, message, title="") : session.open(boundFunction(CCTy4c, title=title, message=message))
def FFktKm(SELF, VVHVqi, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVHVqi, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVHVqi, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVHVqi, boundFunction(CCnAZJ, title=title, message=message, VVqjyy=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFdx4k(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFT4Vd(SELF, callBack_Yes, VVWn1k, callBack_No=None, title="", VVUw2L=False, VVbPNx=True):
 SELF.session.openWithCallback(boundFunction(FFxFRz, callBack_Yes, callBack_No)
        , boundFunction(CCTGG4, title=title, VVWn1k=VVWn1k, VVbPNx=VVbPNx, VVUw2L=VVUw2L))
def FFxFRz(callBack_Yes, callBack_No, FFT4Vded):
 if FFT4Vded : callBack_Yes()
 elif callBack_No: callBack_No()
def FFbo0g(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFzdle(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFtBhW(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVNgg7 = eTimer()
def FFzdle(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFSwL2, SELF))
 fnc = boundFunction(FFSwL2, SELF)
 try:
  t = VVNgg7.timeout.connect(fnc)
 except:
  VVNgg7.callback.append(fnc)
 VVNgg7.start(milliSeconds, 1)
def FFSwL2(SELF):
 VVNgg7.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFrMdi(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC3L8C, **kwargs))
  else   : win = SELF.session.open(boundFunction(CC3L8C, **kwargs))
  FFLQL2(win)
  return win
 except:
  return None
def FFmvQ5(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCgs9B, **kwargs))
 FFLQL2(win)
 return win
def FF9kJ8(SELF, **kwargs):
 SELF.session.open(CCS14C, **kwargs)
def FFbK0m(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFbIom(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVD1DD, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFHC43(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFbIom(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFCBpq():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFi9Up(VVhj1e):
 screenSize  = FFCBpq()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVhj1e)
 return bodyFontSize
def FFBQr7(VVhj1e, extraSpace):
 font = gFont(VVD1DD, VVhj1e)
 VVRjt3 = fontRenderClass.getInstance().getLineHeight(font) or (VVhj1e * 1.25)
 return int(VVRjt3 + VVRjt3 * extraSpace)
def FFHlLM(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVD1DD
def FFuMnj(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFCBpq()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVkFi9)
 bodyFontStr  = 'font="%s;%d"' % (VVD1DD, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFBQr7(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVD1DD, titleFontSize, alignLeftCenter)
 if winType == VVXcKu or winType == VVn9gY:
  if winType == VVn9gY : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVX081:
  pass
 elif winType == VV4xK4:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFUbusL = b2Left2 + timeW + marginLeft
  FFUbusW = b2Left3 - marginLeft - FFUbusL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFUbusL  , b2Top, FFUbusW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00aa7777", "#00aa7777", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
 elif winType == VV9oGS:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVjxSB:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVW5aH:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVsERI:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVD1DD, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVD1DD, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVI3ap:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFUbusH = int(bodyH * 0.5)
  inpTop = bodyTop + FFUbusH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFUbusH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVD1DD, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVD1DD, mapF, alignCenter)
 elif winType == VVhFAf:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVTk2N:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVD1DD, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVNcca:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVD1DD, fontH, alignCenter)
 elif winType == VVEDFg:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVD1DD, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVD1DD, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVD1DD, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVEjzp:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVw4sR : align = alignLeftCenter
  elif winType == VVlcNn : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV2Yz5:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVpQFS:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVlcNn:
    fontStr = 'font="%s;%d"' % (FFHlLM("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVhj1e = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVD1DD, VVhj1e, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVD1DD, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVD1DD, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVauqk = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVD1DD, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVauqk[i], VVD1DD, barFont, alignCenter)
   left += btnW + gap
 if winType == VVlcNn:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVauqk = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVauqk[i], VVD1DD, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVhjJY = []
  if VVqa96:
   VVhjJY.append(("-- MY TEST --"    , "myTest"   ))
  VVhjJY.append(("  File Manager"     , "FileManager"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("  Services/Channels"    , "ChannelsTools" ))
  VVhjJY.append(("  IPTV"       , "IptvTools"  ))
  VVhjJY.append(("  PIcons"       , "PIconsTools"  ))
  VVhjJY.append(("  SoftCam"      , "SoftCam"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("  Plugins"      , "PluginsTools" ))
  VVhjJY.append(("  Terminal"      , "Terminal"  ))
  VVhjJY.append(("  Backup & Restore"    , "BackupRestore" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("  Date/Time"      , "Date_Time"  ))
  VVhjJY.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVhjJY)
  FFgoqU(self, VVhjJY=VVhjJY)
  FFmNCq(self["keyRed"] , "Exit")
  FFmNCq(self["keyGreen"] , "Settings")
  FFmNCq(self["keyYellow"], "Dev. Info.")
  FFmNCq(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVO3IW       ,
   "yellow"  : self.VVuCXq       ,
   "blue"   : self.VVDe23       ,
   "info"   : self.VVDe23       ,
   "last"   : self.VV2Tjr      ,
   "next"   : self.VVTWC9       ,
   "menu"   : self.VV2pLC     ,
   "0"    : boundFunction(self.VVNTiP, 0) ,
   "1"    : boundFunction(self.VVnBXm, 1)   ,
   "2"    : boundFunction(self.VVnBXm, 2)   ,
   "3"    : boundFunction(self.VVnBXm, 3)   ,
   "4"    : boundFunction(self.VVnBXm, 4)   ,
   "5"    : boundFunction(self.VVnBXm, 5)   ,
   "6"    : boundFunction(self.VVnBXm, 6)   ,
   "7"    : boundFunction(self.VVnBXm, 7)   ,
   "8"    : boundFunction(self.VVnBXm, 8)   ,
   "9"    : boundFunction(self.VVnBXm, 9)
  })
  self.onShown.append(self.VVHk7P)
  self.onClose.append(self.onExit)
  global VVp9kL, VVRd2T
  VVp9kL = VVRd2T = False
 def VVWwkM(self):
  item = FFcqFA(self)
  self.VVnBXm(item)
 def VVnBXm(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVZ9qq()
   elif item in ("FileManager"  , 1) : self.session.open(CCZMP9)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCVkVQ)
   elif item in ("IptvTools"  , 3) : self.session.open(CCRT5i)
   elif item in ("PIconsTools"  , 4) : self.VV7lfF()
   elif item in ("SoftCam"   , 5) : self.session.open(CCSII5)
   elif item in ("PluginsTools" , 6) : self.session.open(CCJMnV)
   elif item in ("Terminal"  , 7) : self.session.open(CCQcrZ)
   elif item in ("BackupRestore" , 8) : self.session.open(CCskHy)
   elif item in ("Date_Time"  , 9) : self.session.open(CCxVpD)
   elif item in ("CheckInternet" , 10) : self.session.open(CCiaM4)
   else         : self.close()
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
  FFbK0m(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVU39M)
  self["myTitle"].setText(title)
  VVPI5g, VVGq05, VVSIbg, VVIyEh, VVr5xQ = FFl7aG()
  self.VVx8h3()
  if VVPI5g or VVGq05 or VVSIbg or VVIyEh or VVr5xQ:
   VVPlT0 = lambda path, subj: "%s:\n%s\n\n" % (subj, FF34IZ(path, VVlb6B)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVPlT0(VVPI5g   , "Backup/Restore Path"    )
   txt += VVPlT0(VVGq05  , "Created Package Files (IPK/DEB)" )
   txt += VVPlT0(VVSIbg  , "Download Packages (from feeds)" )
   txt += VVPlT0(VVIyEh , "Exported Tables"     )
   txt += VVPlT0(VVr5xQ , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFh3cd(self, txt, title="Settings Paths")
  if (EASY_MODE or VV08un or VVqa96):
   FFYzPI(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFbo0g(self, "Welcome", 300)
  FFC95U(boundFunction(self.VVFpX0, title))
 def VVFpX0(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCg4Sp.VVNNZq()
   if url:
    newWebVer = CCg4Sp.VVYMXy(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FF0t1y("rm /tmp/ajpanel*"))
 def VVNTiP(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVp9kL
    VVp9kL = True
    FFYzPI(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVTWC9(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVRd2T
   VVRd2T = True
   FFYzPI(self["myTitle"], "#dd5588")
 def VV2Tjr(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   fontFile = "/usr/share/fonts/ae_AlMateen.ttf"
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    color  = "#dd5500"
    try:
     addFont(fontFile, fontName, 100, True)
     FFYzPI(self["myTitle"], color)
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      FFYzPI(self["myTitle"], color)
     except:
      pass
 def VV7lfF(self):
  found = False
  pPath = CCBIQf.VVS0I8()
  if pathExists(pPath):
   for fName, fType in CCBIQf.VVaY26(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCBIQf)
  else:
   VVhjJY = []
   VVhjJY.append(("PIcons Manager" , "CCBIQf" ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(CCBIQf.VVrF7G())
   VVhjJY.append(VVeSPq)
   VVhjJY += CCBIQf.VVhWLa()
   FFmvQ5(self, self.VVtFAG, VVhjJY=VVhjJY)
 def VVtFAG(self, item=None):
  if item:
   if   item == "CCBIQf"   : self.session.open(CCBIQf)
   elif item == "VVHCxx"  : CCBIQf.VVHCxx(self)
   elif item == "VVx0DX"  : CCBIQf.VVx0DX(self)
   elif item == "findPiconBrokenSymLinks" : CCBIQf.VVitDW(self, True)
   elif item == "FindAllBrokenSymLinks" : CCBIQf.VVitDW(self, False)
 def VVO3IW(self):
  self.session.open(CCg4Sp)
 def VVuCXq(self):
  self.session.open(CCTbIw)
 def VVDe23(self):
  changeLogFile = VVVIGI + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFPPAc(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF34IZ("\n%s\n%s\n%s" % (VVbwqB, line, VVbwqB), VVP2je, VVpw0r)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FF34IZ(line, VVho0k, VVpw0r)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFh3cd(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVU39M), VVhj1e=26)
 def VV2pLC(self):
  VVhjJY = []
  VVhjJY.append(("Title Colors"   , "title" ))
  VVhjJY.append(("Menu Area Colors"  , "body" ))
  VVhjJY.append(("Menu Pointer Colors" , "cursor" ))
  VVhjJY.append(("Bottom Bar Colors" , "bar"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Reset"    , "reset" ))
  FFmvQ5(self, self.VVwMy9, VVhjJY=VVhjJY, width=500, title="Main Menu Colors")
 def VVwMy9(self, item=None):
  if item:
   if item == "reset":
    os.system(FF0t1y("rm %s" % self.VVKChz()))
    self.close()
   else:
    tDict = self.VVpfQf()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVlDsQ, tDict, item), CCSufm, defFG=fg, defBG=bg)
 def VVKChz(self):
  return VVTiP2 + "ajpanel_colors"
 def VVpfQf(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVKChz()
  if fileExists(p):
   txt = FFtCkf(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVlDsQ(self, tDict, item, fg, bg):
  if fg:
   self.VVX6qZ(item, fg)
   self.VVuDOz(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVqKpL(tDict)
 def VVqKpL(self, tDict):
   p = self.VVKChz()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVX6qZ(self, item, fg):
  if   item == "title" : FF55DC(self["myTitle"], fg)
  elif item == "body"  :
   FF55DC(self["myMenu"], fg)
   FF55DC(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFYzPI(self["myBar"], fg)
   FF55DC(self["keyRed"], fg)
   FF55DC(self["keyGreen"], fg)
   FF55DC(self["keyYellow"], fg)
   FF55DC(self["keyBlue"], fg)
 def VVuDOz(self, item, bg):
  if   item == "title" : FFYzPI(self["myTitle"], bg)
  elif item == "body"  :
   FFYzPI(self["myMenu"], bg)
   FFYzPI(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFYzPI(self["myBar"], bg)
 def VVx8h3(self):
  tDict = self.VVpfQf()
  self.VVygYg(tDict, "title")
  self.VVygYg(tDict, "body")
  self.VVygYg(tDict, "cursor")
  self.VVygYg(tDict, "bar")
 def VVygYg(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVX6qZ(name, fg)
  if bg: self.VVuDOz(name, bg)
 def VVZ9qq(self):
  pass
class CCTbIw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVhjJY = []
  VVhjJY.append(("Settings File"        , "SettingsFile"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Box Info"          , "VVHDBw"    ))
  VVhjJY.append(("Tuners Info"         , "VV7fMj"   ))
  VVhjJY.append(("Python Version"        , "VVy8wt"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Screen Size"         , "ScreenSize"    ))
  VVhjJY.append(("Locale"          , "Locale"     ))
  VVhjJY.append(("Processor"         , "Processor"    ))
  VVhjJY.append(("Operating System"        , "OperatingSystem"   ))
  VVhjJY.append(("Drivers"          , "drivers"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("System Users"         , "SystemUsers"    ))
  VVhjJY.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVhjJY.append(("Uptime"          , "Uptime"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Host Name"         , "HostName"    ))
  VVhjJY.append(("MAC Address"         , "MACAddress"    ))
  VVhjJY.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVhjJY.append(("Network Status"        , "NetworkStatus"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Disk Usage"         , "VVuSqb"    ))
  VVhjJY.append(("Mount Points"         , "MountPoints"    ))
  VVhjJY.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVhjJY.append(("USB Devices"         , "USB_Devices"    ))
  VVhjJY.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVhjJY.append(("Directory Size"        , "DirectorySize"   ))
  VVhjJY.append(("Memory"          , "Memory"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVhjJY.append(("Running Processes"       , "RunningProcesses"  ))
  VVhjJY.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFgoqU(self, VVhjJY=VVhjJY, title="Device Information")
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCTD5k)
   elif item == "VVHDBw"    : self.VVHDBw()
   elif item == "VV7fMj"   : self.VV7fMj()
   elif item == "VVy8wt"   : self.VVy8wt()
   elif item == "ScreenSize"    : FFh3cd(self, "Width\t: %s\nHeight\t: %s" % (FFCBpq()[0], FFCBpq()[1]))
   elif item == "Locale"     : self.VVGoRp()
   elif item == "Processor"    : self.VVhGLE()
   elif item == "OperatingSystem"   : FF1tu3(self, "uname -a"        )
   elif item == "drivers"     : self.VVHzy9()
   elif item == "SystemUsers"    : FF1tu3(self, "id"          )
   elif item == "LoggedInUsers"   : FF1tu3(self, "who -a"         )
   elif item == "Uptime"     : FF1tu3(self, "uptime"         )
   elif item == "HostName"     : FF1tu3(self, "hostname"        )
   elif item == "MACAddress"    : self.VV438v()
   elif item == "NetworkConfiguration"  : FF1tu3(self, "ifconfig %s %s" % (FF6vFh("HWaddr", VVsahr), FF6vFh("addr:", VVBlp5)))
   elif item == "NetworkStatus"   : FF1tu3(self, "netstat -tulpn"       )
   elif item == "VVuSqb"    : self.VVuSqb()
   elif item == "MountPoints"    : FF1tu3(self, "mount %s" % (FF6vFh(" on ", VVBlp5)))
   elif item == "FileSystemTable"   : FF1tu3(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF1tu3(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF1tu3(self, "blkid"         )
   elif item == "DirectorySize"   : FF1tu3(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVAVkY="Reading size ...")
   elif item == "Memory"     : FF1tu3(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVfHEl()
   elif item == "RunningProcesses"   : FF1tu3(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF1tu3(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVBJKw()
   else         : self.close()
 def VV438v(self):
  res = FFMlfy("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFh3cd(self, txt)
  else:
   FF1tu3(self, "ip link")
 def VVsVR7(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFHErt(cmd)
  return lines
 def VV00tD(self, lines, headerRepl, widths, VVenpJ):
  VVEl38 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVEl38.append(parts)
  if VVEl38 and len(header) == len(widths):
   VVEl38.sort(key=lambda x: x[0].lower())
   FFrMdi(self, None, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=28, VVTjTb=True)
   return True
  else:
   return False
 def VVuSqb(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVsVR7(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVenpJ = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VV00tD(lines, headerRepl, widths, VVenpJ)
  if not allOK:
   lines = FFHErt(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFNOsT(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVaENg:
     note = "\n%s" % FF34IZ("Green = Mounted Partitions", VVaENg)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVBlp5
     elif line.endswith(mountList) : color = VVaENg
     else       : color = VVho0k
     txt += FF34IZ(line, color) + "\n"
    FFh3cd(self, txt + note)
   else:
    FFdx4k(self, "Not data from system !")
 def VVfHEl(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVsVR7(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVenpJ = (LEFT , CENTER, LEFT )
  allOK = self.VV00tD(lines, headerRepl, widths, VVenpJ)
  if not allOK:
   FF1tu3(self, cmd)
 def VVGoRp(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFh3cd(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVHzy9(self):
  cmd = FFGMYv(VVEKL9, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF1tu3(self, cmd)
  else : FFHvqH(self)
 def VVhGLE(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF1tu3(self, cmd)
 def VVBJKw(self):
  cmd = FFGMYv(VVkg6U, "| grep secondstage")
  if cmd : FF1tu3(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFHvqH(self)
 def VVHDBw(self):
  c = VVaENg
  VV8klC = []
  VV8klC.append((FF34IZ("Box Type"  , c), FF34IZ(self.VVF09u("boxtype").upper(), c)))
  VV8klC.append((FF34IZ("Board Version", c), FF34IZ(self.VVF09u("board_revision") , c)))
  VV8klC.append((FF34IZ("Chipset"  , c), FF34IZ(self.VVF09u("chipset")  , c)))
  VV8klC.append((FF34IZ("S/N"   , c), FF34IZ(self.VVF09u("sn")    , c)))
  VV8klC.append((FF34IZ("Version"  , c), FF34IZ(self.VVF09u("version")  , c)))
  VVdqFn   = []
  VVqRCb = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVqRCb = SystemInfo[key]
     else:
      VVdqFn.append((FF34IZ(str(key), VVmWy8), FF34IZ(str(SystemInfo[key]), VVmWy8)))
  except:
   pass
  if VVqRCb:
   VVvXZj = self.VVUlCI(VVqRCb)
   if VVvXZj:
    VVvXZj.sort(key=lambda x: x[0].lower())
    VV8klC += VVvXZj
  if VVdqFn:
   VVdqFn.sort(key=lambda x: x[0].lower())
   VV8klC += VVdqFn
  if VV8klC:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFrMdi(self, None, header=header, VV8klC=VV8klC, VVxJaI=widths, VVhj1e=28, VVTjTb=True)
  else:
   FFh3cd(self, "Could not read info!")
 def VVF09u(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFPPAc(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVUlCI(self, mbDict):
  try:
   mbList = list(mbDict)
   VV8klC = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV8klC.append((FF34IZ(subject, VVBlp5), FF34IZ(value, VVBlp5)))
  except:
   pass
  return VV8klC
 def VV7fMj(self):
  txt = self.VVRceV("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVRceV("/proc/bus/nim_sockets")
  if not txt: txt = self.VV1FfS()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFh3cd(self, txt)
 def VV1FfS(self):
  txt = ""
  VVPlT0 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVPlT0("Slot Name" , slot.getSlotName())
     txt += FF34IZ(slotName, VVBlp5)
     txt += VVPlT0("Description"  , slot.getFullDescription())
     txt += VVPlT0("Frontend ID"  , slot.frontend_id)
     txt += VVPlT0("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVRceV(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFPPAc(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF34IZ(line, VVBlp5)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVy8wt(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFh3cd(self, txt)
class CCTD5k(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVhjJY = []
  VVhjJY.append(("Settings (All)"   , "Settings_All"   ))
  VVhjJY.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVhjJY.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVhjJY.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVhjJY.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVhjJY.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVhjJY.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVhjJY.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFgoqU(self, VVhjJY=VVhjJY)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF1tu3(self, cmd                )
   elif item == "Settings_HotKeys"   : FF1tu3(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF1tu3(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF1tu3(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF1tu3(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF1tu3(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF1tu3(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF1tu3(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCSII5(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVJHTm, VVEnWi, VVMm1W, camCommand = FFn4bL()
  self.VVEnWi = VVEnWi
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVhjJY = []
  VVhjJY.append(("OSCam Files"        , "OSCamFiles"  ))
  VVhjJY.append(("NCam Files"        , "NCamFiles"  ))
  VVhjJY.append(("CCcam Files"        , "CCcamFiles"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVhjJY.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVhjJY.append(VVeSPq)
  if VVEnWi:
   if   "oscam" in VVEnWi : camName = "OSCam"
   elif "ncam"  in VVEnWi : camName = "NCam"
   VVhjJY.append((camName + " Info."      , "camInfo"   ))
   VVhjJY.append((camName + " Live Status"    , "camLiveStatus" ))
   VVhjJY.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVhjJY.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVhjJY.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFgoqU(self, VVhjJY=VVhjJY)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCWGre, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCWGre, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCWGre, "cccam"))
   elif item == "OSCamReaders"  : self.VVAvGw("os")
   elif item == "NSCamReaders"  : self.VVAvGw("n")
   elif item == "camInfo"   : FFj3m1(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFUjUP(self.session, CC4JVg.VVdghp)
   elif item == "camLiveReaders" : FFUjUP(self.session, CC4JVg.VV2V2y)
   elif item == "camLiveLog"  : FFUjUP(self.session, CC4JVg.VVpOD5)
   else       : self.close()
 def VVAvGw(self, camPrefix):
  VVEl38 = self.VVw8c8(camPrefix)
  if VVEl38:
   VVEl38.sort(key=lambda x: int(x[0]))
   if self.VVEnWi and self.VVEnWi.startswith(camPrefix):
    VVB3WF = ("Toggle State", self.VVOOjH, [camPrefix], "Changing State ...")
   else:
    VVB3WF = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVenpJ  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFrMdi(self, None, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVB3WF=VVB3WF, VVWA0Q=True)
 def VVw8c8(self, camPrefix):
  readersFile = self.VVJHTm + camPrefix + "cam.server"
  VVEl38 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFPPAc(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVEl38.append((str(len(VVEl38) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVEl38:
    FFdx4k(self, "No readers found !")
  else:
   FF5BoZ(self, readersFile)
  return VVEl38
 def VVOOjH(self, VV8kdg, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVJHTm, camPrefix)
  readerState  = VV8kdg.VVJPyb(1)
  readerLabel  = VV8kdg.VVJPyb(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCSII5.VVyzQl(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VV8kdg.VVr9ZM()
    FFdx4k(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVEl38 = self.VVw8c8(camPrefix)
   if VVEl38:
    VV8kdg.VVmRNB(VVEl38)
 @staticmethod
 def VVyzQl(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFPPAc(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFdx4k(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFdx4k(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF5BoZ(SELF, confFile)
   return None
  if not iRequest:
   FFdx4k(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFdx4k(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFdx4k(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCWGre(Screen):
 def __init__(self, VVQFL6, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVJHTm, VVEnWi, VVMm1W, camCommand = FFn4bL()
  if   VVQFL6 == "ncam" : self.prefix = "n"
  elif VVQFL6 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVhjJY = []
  if self.prefix == "":
   VVhjJY.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVhjJY.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVhjJY.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVhjJY.append(("constant.cw"         , "x_constant_cw" ))
   VVhjJY.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVhjJY.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVhjJY.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVhjJY.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVhjJY.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVhjJY.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVhjJY.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVhjJY.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVhjJY.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVhjJY.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVhjJY.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFgoqU(self, VVhjJY=VVhjJY)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFC3ew(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFC3ew(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFC3ew(self, self.VVJHTm + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFC3ew(self, self.VVJHTm + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVrEK4("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVrEK4("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVrEK4("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVrEK4("cam.provid"        )
   elif item == "x_cam_server"  : self.VVrEK4("cam.server"        )
   elif item == "x_cam_services" : self.VVrEK4("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVrEK4("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVrEK4("cam.user"        )
   elif item == "x_VVbwqB"   : pass
   elif item == "x_SoftCam_Key" : FFC3ew(self, self.VVJHTm + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFC3ew(self, self.VVJHTm + "CCcam.cfg"    )
   elif item == "x_VVbwqB"   : pass
   elif item == "x_cam_log"  : FFC3ew(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFC3ew(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFC3ew(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVrEK4(self, fileName):
  FFC3ew(self, self.VVJHTm + self.prefix + fileName)
class CC4JVg(Screen):
 VVdghp  = 0
 VV2V2y = 1
 VVpOD5 = 2
 def __init__(self, session, VVJHTm="", VVEnWi="", VVMm1W="", VV2hVw=VVdghp):
  self.skin, self.skinParam = FFuMnj(VVlcNn, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVMm1W   = VVMm1W
  self.VV2hVw  = VV2hVw
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVJHTm + VVEnWi + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVEnWi : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVJHTm, self.camPrefix)
  if self.VV2hVw == self.VVdghp:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VV2hVw == self.VV2V2y:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFgoqU(self, self.Title, addScrollLabel=True)
  FFmNCq(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVFYIg
  self.onShown.append(self.VVHk7P)
  self.onClose.append(self.onExit)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self["myLabel"].VV36kJ(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFbK0m(self)
  self.VVFYIg()
 def onExit(self):
  self.timer.stop()
 def VVEoay(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV4U4J)
  except:
   self.timer.callback.append(self.VV4U4J)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFbo0g(self, "Started", 1000)
 def VVpKy4(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV4U4J)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFbo0g(self, "Stopped", 1000)
 def VVFYIg(self):
  if self.timerRunning:
   self.VVpKy4()
  else:
   self.VVEoay()
   if self.VV2hVw == self.VVdghp or self.VV2hVw == self.VV2V2y:
    if self.VV2hVw == self.VVdghp : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCSII5.VVyzQl(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFC95U(self.VVVx3W)
    else:
     self.close()
   else:
    self.VVu1cJ()
 def VV4U4J(self):
  if self.timerRunning:
   if   self.VV2hVw == self.VVdghp : self.VV5FTV()
   elif self.VV2hVw == self.VV2V2y : self.VV5FTV()
   else            : self.VVu1cJ()
 def VVu1cJ(self):
  if fileExists(self.VVMm1W):
   fTime = FFCnzX(os.path.getmtime(self.VVMm1W))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVqLCW(), VV9aL5=VVx3E7)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVMm1W)
 def VVVx3W(self):
  self.VV5FTV()
 def VV5FTV(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF34IZ("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVP2je))
   self.camWebIfErrorFound = True
   self.VVpKy4()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VV2hVw == self.VVdghp : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF34IZ("Error while parsing data elements !\n\nError = %s" % str(e), VVlb6B)
   self.camWebIfErrorFound = True
   self.VVpKy4()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVpr2I(root)
  self["myLabel"].setText(txt, VV9aL5=VVx3E7)
  self["myBar"].setText("Last Update : %s" % FFvbBP())
 def VVpr2I(self, rootElement):
  def VVPlT0(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VV2hVw == self.VVdghp:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF34IZ(status, VVaENg)
    else          : status = FF34IZ(status, VVlb6B)
    txt += VVbwqB + "\n"
    txt += VVPlT0("Name"  , name)
    txt += VVPlT0("Description" , desc)
    txt += VVPlT0("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVPlT0("Protocol" , protocol)
    txt += VVPlT0("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF34IZ("Yes", VVaENg)
    else    : enabTxt = FF34IZ("No", VVlb6B)
    txt += VVbwqB + "\n"
    txt += VVPlT0("Label"  , label)
    txt += VVPlT0("Protocol" , protocol)
    txt += VVPlT0("Enabled" , enabTxt)
  return txt
 def VVqLCW(self):
  wordsDict = self.VVwa0M()
  color = [ VVBlp5, VVsahr, VVaENg, VVlb6B, VVmWy8, VVHtZw]
  lines = FFHErt("tail -n %d %s" % (100, self.VVMm1W))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVP2je + line[:19] + VVho0k + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVpw0r + line[ndx + 3:] + VVho0k
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVBlp5 + line[ndx + 8 : ndx1 + 4] + VVho0k + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVho0k)
   elif line.startswith("----") or ">>" in line:
    line = FF34IZ(line, VVBlp5)
   txt += line + "\n"
  return txt
 def VVwa0M(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFPPAc(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCskHy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVhjJY = []
  VVhjJY.append(("Backup Channels"        , "VV3pup"   ))
  VVhjJY.append(("Restore Channels"        , "Restore_Channels"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Backup SoftCAM Files"       , "VV7H5c" ))
  VVhjJY.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVhjJY.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVhjJY.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Backup Network Settings"      , "VVvO2c"   ))
  VVhjJY.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVRd2T:
   VVhjJY.append(VVeSPq)
   VVhjJY.append((VVP2je + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VV9TIm"   ))
   VVhjJY.append((VVaENg + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVhjJY.append((VVaENg + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVhjJY.append((VVmWy8 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVhjJY.append((VVmWy8 + "Decode %s Crash Report"   % PLUGIN_NAME , "VVgKTd" ))
  FFgoqU(self, VVhjJY=VVhjJY)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV3pup"    : self.VV3pup()
   elif item == "Restore_Channels"    : self.VVhg5E("channels_backup*.tar.gz", self.VVLp2f)
   elif item == "VV7H5c"   : self.VV7H5c()
   elif item == "Restore_SoftCAM_Files"  : self.VVhg5E("softcam_backup*.tar.gz", self.VV6Sca)
   elif item == "Backup_TunerDiSEqC"   : self.VV3BMm("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVhg5E("tuner_backup*.backup", boundFunction(self.VV1Itc, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV3BMm("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVhg5E("hotkey_fhdg17_backup*.backup", boundFunction(self.VV1Itc, "misc"))
   elif item == "VVvO2c"    : self.VVvO2c()
   elif item == "Restore_Network"    : self.VVhg5E("network_backup*.tar.gz", self.VV5n4I)
   elif item == "VV9TIm"     : FFT4Vd(self, boundFunction(FFdDg8, self, boundFunction(CCskHy.VV9TIm, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVFcVn(False)
   elif item == "createMyDeb"     : self.VVFcVn(True)
   elif item == "createMyTar"     : self.VVqngT()
   elif item == "VVgKTd"   : self.VVgKTd()
 @staticmethod
 def VV9TIm(SELF):
  OBF_Path = VV38ZS + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV38ZS, VVU39M, VVS3oD)
   if err : FFdx4k(SELF, err)
   else : FFh3cd(SELF, txt)
  else:
   FF5BoZ(SELF, OBF_Path)
 def VVFcVn(self, VVgL4t):
  OBF_Path = VV38ZS + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFdx4k(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV38ZS)
  os.system("mv -f %s %s" % (VV38ZS + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV38ZS + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV38ZS + "plugin.py"))
  self.session.openWithCallback(self.VVFcVn1, boundFunction(CC5HTk, path=VV38ZS, VVgL4t=VVgL4t))
 def VVFcVn1(self):
  os.system("mv -f %s %s" % (VV38ZS + "OBF/main.py"  , VV38ZS))
  os.system("mv -f %s %s" % (VV38ZS + "OBF/plugin.py" , VV38ZS))
 def VVgKTd(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFdx4k(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFdx4k(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VV62NZ("%s*.list" % path)
  if err:
   FF5BoZ(self, path + "*.list")
   return
  srcF, err = self.VV62NZ("%s*main_final.py" % path)
  if err:
   FF5BoZ(self, path + "*.final.py")
   return
  VV8klC = []
  for f in files:
   f = os.path.basename(f)
   VV8klC.append((f, f))
  FFmvQ5(self, boundFunction(self.VVuQh8, path, codF, srcF), VVhjJY=VV8klC)
 def VVuQh8(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FF5BoZ(self, logF)
   else     : FFdDg8(self, boundFunction(self.VV3yge, logF, codF, srcF))
 def VV3yge(self, logF, codF, srcF):
  lst  = []
  lines = FFPPAc(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFdx4k(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV5P15(lst, logF, newLogF)
  totSrc  = self.VV5P15(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFh3cd(self, txt)
 def VV62NZ(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV5P15(self, lst, f1, f2):
  txt = FFtCkf(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVqngT(self):
  VV8klC = []
  VV8klC.append("%s%s" % (VV38ZS, "*.py"))
  VV8klC.append("%s%s" % (VV38ZS, "*.png"))
  VV8klC.append("%s%s" % (VV38ZS, "*.xml"))
  VV8klC.append("%s"  % (VVVIGI))
  FFODZ8(self, VV8klC, "%s_%s" % (PLUGIN_NAME, VVU39M), addTimeStamp=False)
 def VV3pup(self):
  path1 = VVBjVb
  path2 = "/etc/tuxbox/"
  VV8klC = []
  VV8klC.append("%s%s" % (path1, "*.tv"))
  VV8klC.append("%s%s" % (path1, "*.radio"))
  VV8klC.append("%s%s" % (path1, "*list"))
  VV8klC.append("%s%s" % (path1, "lamedb*"))
  VV8klC.append("%s%s" % (path2, "*.xml"))
  FFODZ8(self, VV8klC, "channels_backup", addTimeStamp=True)
 def VV7H5c(self):
  VV8klC = []
  VV8klC.append("/etc/tuxbox/config/")
  VV8klC.append("/usr/keys/")
  VV8klC.append("/usr/scam/")
  VV8klC.append("/etc/CCcam.cfg")
  FFODZ8(self, VV8klC, "softcam_backup", addTimeStamp=True)
 def VVvO2c(self):
  VV8klC = []
  VV8klC.append("/etc/hostname")
  VV8klC.append("/etc/default_gw")
  VV8klC.append("/etc/resolv.conf")
  VV8klC.append("/etc/wpa_supplicant*.conf")
  VV8klC.append("/etc/network/interfaces")
  VV8klC.append("/etc/enigma2/nameserversdns.conf")
  FFODZ8(self, VV8klC, "network_backup", addTimeStamp=True)
 def VVLp2f(self, fileName):
  if fileName:
   FFT4Vd(self, boundFunction(self.VVDLWH, fileName), "Overwrite current channels ?")
 def VVDLWH(self, fileName):
  path = "%s%s" % (VVTiP2, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCVkVQ.VV5hDF()
   lamedb5File, diabled5File = CCVkVQ.VVtrKu()
   cmd = ""
   cmd += FF0t1y("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FF0t1y("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FF28nO()
   if res == 0 : FFUbus(self, "Channels Restored.")
   else  : FFdx4k(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FF5BoZ(self, path)
 def VV6Sca(self, fileName):
  if fileName:
   FFT4Vd(self, boundFunction(self.VVFFda, fileName), "Overwrite SoftCAM files ?")
 def VVFFda(self, fileName):
  fileName = "%s%s" % (VVTiP2, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVbwqB
   note = "You may need to restart your SoftCAM."
   FFhEdh(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF6vFh(note, VVBlp5), sep))
  else:
   FF5BoZ(self, fileName)
 def VV5n4I(self, fileName):
  if fileName:
   FFT4Vd(self, boundFunction(self.VVLGd4, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVLGd4(self, fileName):
  fileName = "%s%s" % (VVTiP2, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFTgBK(self,  cmd)
  else:
   FF5BoZ(self, fileName)
 def VVhg5E(self, pattern, callBackFunction, isTuner=False):
  title = FFRiG8()
  if pathExists(VVTiP2):
   myFiles = iGlob("%s%s" % (VVTiP2, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV8klC = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV8klC.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVbBdV = ("Sat. List", self.VV86J9)
    else  : VVbBdV = None
    FFmvQ5(self, callBackFunction, title=title, VVhjJY=VV8klC, VVbBdV=VVbBdV)
   else:
    FFdx4k(self, "No files found in:\n\n%s" % VVTiP2, title)
  else:
   FFdx4k(self, "Path not found:\n\n%s" % VVTiP2, title)
 def VV3BMm(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCL2ur()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VV2Ljs, filePrefix))
 def VV2Ljs(self, filePrefix, result, retval):
  title = FFRiG8()
  if pathExists(VVTiP2):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFdx4k(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVTiP2, filePrefix, FFmJh3())
    try:
     VV8klC = str(result.strip()).split()
     if VV8klC:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV8klC:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVbwqB, FF34IZ(fName, VVBlp5), VVbwqB)
       FFh3cd(self, txt, title=title, VV9aL5=VVx3E7)
      else:
       FFdx4k(self, "File creation failed!", title)
     else:
      FFdx4k(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FF0t1y("rm %s" % fName))
     FFdx4k(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FF0t1y("rm %s" % fName))
     FFdx4k(self, "Error while writing file.")
  else:
   FFdx4k(self, "Path not found:\n\n%s" % VVTiP2, title)
 def VV1Itc(self, mode, path):
  if path:
   path = "%s%s" % (VVTiP2, path)
   if fileExists(path):
    lines = FFPPAc(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFT4Vd(self, boundFunction(self.VVUHSs, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFwNVh(self, path, title=FFRiG8())
   else:
    FF5BoZ(self, path)
 def VVUHSs(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVHIgK = []
  VVHIgK.append("echo -e 'Reading current settings ...'")
  VVHIgK.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVHIgK.append("echo -e 'Preparing new settings ...'")
  VVHIgK.append(settingsLines)
  VVHIgK.append("echo -e 'Applying new settings ...'")
  VVHIgK.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFYm78(self, VVHIgK)
 def VV86J9(self, VVdAc1Obj, path):
  if not path:
   return
  path = VVTiP2 + path
  if not fileExists(path):
   FF5BoZ(self, path)
   return
  txt = FFtCkf(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV8klC  = []
   for item in satList:
    VV8klC.append("%s\t%s" % (item[0], FFOLoN(item[1])))
   FFh3cd(self, VV8klC, title="  Satellites List")
  else:
   FFdx4k(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCJMnV(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVhjJY = []
  VVhjJY.append(("Plugins Browser List"       , "VVCBeb"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVhjJY.append(("Remove Packages (show all)"     , "VVuulXsAll"   ))
  VVhjJY.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Update List of Available Packages"   , "VV1p0I"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Packaging Tool"        , "VVAFNV"    ))
  VVhjJY.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFgoqU(self, VVhjJY=VVhjJY)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVCBeb"   : self.VVCBeb()
   elif item == "pluginsDirList"    : self.VVWxPr()
   elif item == "downloadInstallPackages"  : FFdDg8(self, boundFunction(self.VVoy2V, 0, ""))
   elif item == "VVuulXsAll"   : FFdDg8(self, boundFunction(self.VVoy2V, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFdDg8(self, boundFunction(self.VVoy2V, 2, "| grep -e skin -e enigma2-"))
   elif item == "VV1p0I"   : self.VV1p0I()
   elif item == "VVAFNV"    : self.VVAFNV()
   elif item == "packagesFeeds"    : self.VVh2Au()
   else          : self.close()
 def VVWxPr(self):
  extDirs  = FF9ZzK(VVDaUI)
  sysDirs  = FF9ZzK(VVZfME)
  VV8klC  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV8klC.append((item, VVDaUI + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV8klC.append((item, VVZfME + item))
  if VV8klC:
   VV8klC = sorted(VV8klC, key=lambda x: x[0].lower())
   VVRYtq = ("Package Info.", self.VVsxVN, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFrMdi(self, None, header=header, VV8klC=VV8klC, VVxJaI=widths, VVhj1e=28, VVRYtq=VVRYtq)
  else:
   FFdx4k(self, "Nothing found!")
 def VVsxVN(self, VV8kdg, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVDaUI) : loc = "extensions"
  elif path.startswith(VVZfME) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVj5iT(package)
  else:
   FFdx4k(self, "No info!")
 def VVh2Au(self):
  pkg = FFm75l()
  if pkg : FF1tu3(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFHvqH(self)
 def VVCBeb(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVPlT0(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVbwqB + "\n"
    txt += VVPlT0("Number"   , str(c))
    txt += VVPlT0("Name"   , FF34IZ(str(p.name), VVBlp5))
    txt += VVPlT0("Path"  , p.path  )
    txt += VVPlT0("Description" , p.description )
    txt += VVPlT0("Icon"  , p.iconstr  )
    txt += VVPlT0("Wakeup Fnc" , p.wakeupfnc )
    txt += VVPlT0("NeedsRestart", p.needsRestart)
    txt += VVPlT0("Internal" , p.internal )
    txt += VVPlT0("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFh3cd(self, txt)
 def VV1p0I(self):
  cmd = FFGMYv(VVQVcc, "")
  if cmd : FFTgBK(self, cmd, checkNetAccess=True)
  else : FFHvqH(self)
 def VVAFNV(self):
  pkg = FFm75l()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFUbus(self, txt)
 def VVoy2V(self, mode, grep, VV8kdg=None, title=""):
  if   mode == 0: cmd = FFGMYv(VVkg6U    , grep)
  elif mode == 1: cmd = FFGMYv(VVEKL9 , grep)
  elif mode == 2: cmd = FFGMYv(VVEKL9 , grep)
  if not cmd:
   FFHvqH(self)
   return
  VVEl38 = FFHErt(cmd)
  if not VVEl38:
   if VV8kdg: VV8kdg.VVr9ZM()
   FFdx4k(self, "No packages found!")
   return
  elif len(VVEl38) == 1 and VVEl38[0] == VVbfxK:
   FFdx4k(self, VVbfxK)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV8klC  = []
  for item in VVEl38:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV8klC.append((name, package, version))
  if mode > 0:
   extensions = FFHErt("ls %s -l | grep '^d' | awk '{print $9}'" % VVDaUI)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV8klC:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV8klC.append((name, VVDaUI + item, "-"))
   systemPlugins = FFHErt("ls %s -l | grep '^d' | awk '{print $9}'" % VVZfME)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV8klC:
      if item.lower() == row[0].lower():
       break
     else:
      VV8klC.append((item, VVZfME + item, "-"))
  if not VV8klC:
   FFdx4k(self, "No packages found!")
   return
  if VV8kdg:
   VV8klC.sort(key=lambda x: x[0].lower())
   VV8kdg.VVmRNB(VV8klC, title)
  else:
   widths = (20, 50, 30)
   VVB3WF = None
   VVn2KW = None
   if mode == 0:
    VV6Yzq = ("Install" , self.VVcKAM   , [])
    VVB3WF = ("Download" , self.VVrZrm   , [])
    VVn2KW = ("Filter"  , self.VVPAUH , [])
   elif mode == 1:
    VV6Yzq = ("Uninstall", self.VVuulX, [])
   elif mode == 2:
    VV6Yzq = ("Uninstall", self.VVuulX, [])
    widths= (18, 57, 25)
   VV8klC = sorted(VV8klC, key=lambda x: x[0].lower())
   VVRYtq = ("Package Info.", self.VVcK4D, [])
   header   = ("Name" ,"Package" , "Version" )
   FFrMdi(self, None, header=header, VV8klC=VV8klC, VVxJaI=widths, VVhj1e=28, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVn2KW=VVn2KW, VVldcK=self.lastSelectedRow
     , VVHOIE="#22110011", VVsOU8="#22191111", VVauqk="#22191111", VVMVsE="#00003030", VVHcAW="#00333333")
 def VVcK4D(self, VV8kdg, title, txt, colList):
  package = colList[1]
  self.VVj5iT(package)
 def VVPAUH(self, VV8kdg, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVhjJY = []
  VVhjJY.append(("All Packages", "all"))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVhjJY.append(VVeSPq)
  for word in words:
   VVhjJY.append((word, word))
  FFmvQ5(self, boundFunction(self.VVbxwx, VV8kdg), VVhjJY=VVhjJY, title="Select Filter")
 def VVbxwx(self, VV8kdg, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFdDg8(VV8kdg, boundFunction(self.VVoy2V, 0, grep, VV8kdg, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVuulX(self, VV8kdg, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVDaUI, VVZfME)):
   FFT4Vd(self, boundFunction(self.VVLSyw, VV8kdg, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVhjJY = []
   VVhjJY.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVhjJY.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVhjJY.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFmvQ5(self, boundFunction(self.VVZsE6, VV8kdg, package), VVhjJY=VVhjJY)
 def VVLSyw(self, VV8kdg, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVKMzT)
  FFTgBK(self, cmd, VVMQzL=boundFunction(self.VV8lMR, VV8kdg))
 def VVZsE6(self, VV8kdg, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVA4To
   elif item == "remove_ForceRemove"  : cmdOpt = VVvsDU
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVmOpe
   FFT4Vd(self, boundFunction(self.VVOjMa, VV8kdg, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVOjMa(self, VV8kdg, package, cmdOpt):
  self.lastSelectedRow = VV8kdg.VVvjAB()
  cmd = FFBSlb(cmdOpt, package)
  if cmd : FFTgBK(self, cmd, VVMQzL=boundFunction(self.VV8lMR, VV8kdg))
  else : FFHvqH(self)
 def VV8lMR(self, VV8kdg):
  VV8kdg.cancel()
  FFqgU2()
 def VVcKAM(self, VV8kdg, title, txt, colList):
  package  = colList[1]
  VVhjJY = []
  VVhjJY.append(("Install Package"         , "install_CheckVersion" ))
  VVhjJY.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVhjJY.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVhjJY.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFmvQ5(self, boundFunction(self.VVZjtK, package), VVhjJY=VVhjJY)
 def VVZjtK(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVSeHH
   elif item == "install_ForceReinstall" : cmdOpt = VVKhUe
   elif item == "install_ForceDowngrade" : cmdOpt = VVBK9Y
   elif item == "install_IgnoreDepends" : cmdOpt = VVW7Xu
   FFT4Vd(self, boundFunction(self.VVSYRk, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVSYRk(self, package, cmdOpt):
  cmd = FFBSlb(cmdOpt, package)
  if cmd : FFTgBK(self, cmd, VVMQzL=FFqgU2, checkNetAccess=True)
  else : FFHvqH(self)
 def VVrZrm(self, VV8kdg, title, txt, colList):
  package  = colList[1]
  FFT4Vd(self, boundFunction(self.VVC05A, package), "Download Package ?\n\n%s" % package)
 def VVC05A(self, package):
  if FFScuV():
   cmd = FFBSlb(VVgLqE, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF6vFh(success, VVaENg))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF6vFh(fail, VVlb6B))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFTgBK(self, cmd, VVnnIF=[VVlb6B, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFHvqH(self)
  else:
   FFdx4k(self, "No internet connection !")
 def VVj5iT(self, package):
  infoCmd  = FFBSlb(VVa81b, package)
  filesCmd = FFBSlb(VVFTJH, package)
  listInstCmd = FFGMYv(VVEKL9, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFA8ba(VVBlp5)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF6vFh(notInst, VVP2je))
   cmd += "else "
   cmd +=   FF1Vsg("System Info", VVBlp5)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF1Vsg("Related Files", VVBlp5)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFEKD5(self, cmd)
  else:
   FFHvqH(self)
class CCVkVQ(Screen):
 VVKXsZ  = 0
 VVGg72 = 1
 VVlNJn  = 2
 VVcv9Q  = 3
 VVcfvB = 4
 VVYyfD = 5
 VVQJHa = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV1DBk = None
  self.lastfilterUsed  = None
  VVhjJY = self.VV81Ac()
  FFgoqU(self, VVhjJY=VVhjJY, title="Services/Channels")
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self["myMenu"].setList(self.VV81Ac())
  FF9iGG(self["myMenu"])
  FFHC43(self)
 def VV81Ac(self):
  VVhjJY = []
  VVhjJY.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVhjJY.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVhjJY.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVhjJY.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVhjJY.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVhjJY.append(("Services with PIcons for the System"  , "VVUPvI"     ))
  VVhjJY.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVhjJY.append(VVeSPq)
  lamedbFile, disabledFile = CCVkVQ.VV5hDF()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVhjJY.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVhjJY.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVhjJY.append(("Reset Parental Control Settings"   , "VVe7AE"    ))
  VVhjJY.append(("Delete Channels with no names"   , "VVbjKr"    ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Reload Channels and Bouquets"    , "VV1XTa"      ))
  return VVhjJY
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFMt8K(self)
   elif item == "currentServiceInfo"     : FF9kJ8(self, fncMode=CCS14C.VVch8F)
   elif item == "TranspondersStats"     : FFdDg8(self, self.VVplJW     )
   elif item == "lameDB_allChannels_with_refCode"  : FFdDg8(self, self.VV1zXF )
   elif item == "lameDB_allChannels_with_tranaponder" : FFdDg8(self, self.VVrqQF)
   elif item == "lameDB_allChannels_with_details"  : FFdDg8(self, self.VVL3Rf )
   elif item == "parentalControlChannels"    : FFdDg8(self, self.VVfZ9a   )
   elif item == "showHiddenChannels"     : FFdDg8(self, self.VVmtRg     )
   elif item == "VVUPvI"     : FFdDg8(self, self.VVr4Na     )
   elif item == "servicesWithMissingPIcons"   : FFdDg8(self, self.VVrCXJ   )
   elif item == "enableHiddenChannels"     : self.VVyRPi(True)
   elif item == "disableHiddenChannels"    : self.VVyRPi(False)
   elif item == "VVe7AE"    : FFT4Vd(self, self.VVe7AE, "Reset and Restart ?" )
   elif item == "VVbjKr"    : FFdDg8(self, self.VVbjKr)
   elif item == "VV1XTa"      : FFdDg8(self, boundFunction(CCVkVQ.VV1XTa, self))
   else            : self.close()
 @staticmethod
 def VV1XTa(SELF):
  FF28nO()
  FFUbus(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV1zXF(self):
  self.VV1DBk = None
  self.lastfilterUsed  = None
  self.filterObj   = CCwKtp(self)
  VVEl38 = CCVkVQ.VVheOM(self, self.VVKXsZ)
  if VVEl38:
   VVEl38.sort(key=lambda x: x[0].lower())
   VVR5hp  = ("Zap"   , self.VV8awy     , [])
   VVkGsu = (""    , self.VVBoO1   , [])
   VVRYtq = ("Options"  , self.VVvT3N , [])
   VVB3WF = ("Current Service", self.VVxKPj , [])
   VVn2KW = ("Filter"   , self.VVANU2  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVenpJ  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFrMdi(self, None, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVn2KW=VVn2KW)
 def VVrqQF(self):
  self.VV1DBk = None
  self.lastfilterUsed  = None
  self.filterObj   = CCwKtp(self)
  VVEl38 = CCVkVQ.VVheOM(self, self.VVGg72)
  if VVEl38:
   VVEl38.sort(key=lambda x: x[0].lower())
   VVR5hp  = ("Zap"   , self.VV8awy      , [])
   VVkGsu = (""    , self.VVBoO1    , [])
   VVB3WF = ("Current Service", self.VVxKPj  , [])
   VVRYtq = ("Options"  , self.VVWHuA , [])
   VVn2KW = ("Filter"   , self.VVFT2r  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVenpJ  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFrMdi(self, None, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVn2KW=VVn2KW)
 def VVvT3N(self, VV8kdg, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCfYM9(self, VV8kdg, 3)
  mSel.VVNpxR(servName, refCode, pcState, hidState)
 def VVWHuA(self, VV8kdg, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCfYM9(self, VV8kdg, 3)
  mSel.VVHnff(servName, refCode)
 def VVrZ8F(self, VV8kdg, refCode, isAddToBlackList):
  self.VV1DBk = None
  self.lastfilterUsed  = None
  VV8kdg.VVp4RP("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFdDg8(self, boundFunction(self.VVhvlb, VV8kdg, refCode))
  else:
   FF5BoZ(self, path)
 def VV7o46(self, VV8kdg, refCode, isHide):
  self.VV1DBk = None
  self.lastfilterUsed  = None
  VV8kdg.VVp4RP("Changing state ...")
  if FFIKVK(refCode):
   ret = FFXDAC(refCode, isHide)
   if ret : FFdDg8(self, boundFunction(self.VVhvlb, VV8kdg, refCode))
   else : FFdx4k(self, "Cannot Hide/Unhide this channel.")
  else:
   FFdx4k(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVhvlb(self, VV8kdg, refCode):
  VVEl38 = CCVkVQ.VVheOM(self, self.VVKXsZ, VVuvX7=[3, [refCode], False])
  done = False
  if VVEl38:
   data = VVEl38[0]
   if data[3] == refCode:
    done = VV8kdg.VVRKTL(data)
  if not done:
   self.VVeEe2(VV8kdg, VV8kdg.VVvELd(), self.VVKXsZ)
  VV8kdg.VVr9ZM()
 def VVANU2(self, VV8kdg, title, txt, colList):
  self.filterObj.VVhacF(1, VV8kdg, 2, boundFunction(self.VV6e3Q, VV8kdg))
 def VV6e3Q(self, VV8kdg, item):
  self.VV4wpf(VV8kdg, item, 2, self.VVKXsZ)
 def VVFT2r(self, VV8kdg, title, txt, colList):
  self.filterObj.VVhacF(2, VV8kdg, 4, boundFunction(self.VVWmVo, VV8kdg))
 def VVWmVo(self, VV8kdg, item):
  self.VV4wpf(VV8kdg, item, 4, self.VVGg72)
 def VVzdTA(self, VV8kdg, title, txt, colList):
  self.filterObj.VVhacF(0, VV8kdg, 4, boundFunction(self.VVHiH2, VV8kdg))
 def VVHiH2(self, VV8kdg, item):
  self.VV4wpf(VV8kdg, item, 4, self.VVlNJn)
 def VV4wpf(self, VV8kdg, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VV8kdg.VVJPyb(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV1DBk = None
  else:
   words, asPrefix = CCwKtp.VVlIIO(words)
   self.VV1DBk = [col, words, asPrefix]
  if words: FFdDg8(self, boundFunction(self.VVeEe2, VV8kdg, title, mode), title="Reading Services ...")
  else : FFbo0g(VV8kdg, "Incorrect filter", 2000)
 def VVeEe2(self, VV8kdg, title, mode):
  VVEl38 = CCVkVQ.VVheOM(self, mode, VVuvX7=self.VV1DBk, VVUIx4=False)
  if VVEl38:
   VVEl38.sort(key=lambda x: x[0].lower())
   VV8kdg.VVmRNB(VVEl38, title)
  else:
   VV8kdg.VVr9ZM()
   FFbo0g(VV8kdg, "Not found!", 1500)
 def VVXpSd(self, VV8klC, VVR5hp=None, VVkGsu=None, VV6Yzq=None, VVB3WF=None, VVRYtq=None, VVn2KW=None):
  VVB3WF = ("Current Service", self.VVxKPj, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVenpJ = (LEFT  , LEFT  , CENTER, LEFT    )
  FFrMdi(self, None, header=header, VV8klC=VV8klC, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVn2KW=VVn2KW)
 def VVxKPj(self, VV8kdg, title, txt, colList):
  self.VViwl0(VV8kdg)
 def VVhgFH(self, VV8kdg, title, txt, colList):
  self.VViwl0(VV8kdg, True)
 def VViwl0(self, VV8kdg, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VV8kdg.VVwBkd(colDict, VVpwCo=True)
   else:
    VV8kdg.VVNoAg(3, refCode, True)
   return
  FFdx4k(self, "Colud not read current Reference Code !")
 def VVL3Rf(self):
  self.VV1DBk = None
  self.lastfilterUsed  = None
  self.filterObj   = CCwKtp(self)
  VVEl38 = CCVkVQ.VVheOM(self, self.VVlNJn)
  if VVEl38:
   VVEl38.sort(key=lambda x: x[0].lower())
   VVkGsu = (""    , self.VVygWX , []      )
   VVB3WF = ("Current Service", self.VVhgFH  , []      )
   VVn2KW = ("Filter"   , self.VVzdTA   , [], "Loading Filters ..." )
   VVR5hp  = ("Zap"   , self.VVi9dd      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVenpJ  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFrMdi(self, None, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVB3WF=VVB3WF, VVn2KW=VVn2KW)
 def VVygWX(self, VV8kdg, title, txt, colList):
  refCode  = self.VVE0Eq(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FF9kJ8(self, fncMode=CCS14C.VVfIDC, refCode=refCode, chName=chName, text=txt)
 def VVi9dd(self, VV8kdg, title, txt, colList):
  refCode = self.VVE0Eq(colList)
  FF4ffD(self, refCode)
 def VV8awy(self, VV8kdg, title, txt, colList):
  FF4ffD(self, colList[3])
 def VVE0Eq(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVheOM(SELF, mode, VVuvX7=None, VVUIx4=True, VVQoiw=True):
  lamedbFile, disabledFile = CCVkVQ.VV5hDF()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVuvX7:
    filterCol = VVuvX7[0]
    filterWords = VVuvX7[1]
    asPrefix = VVuvX7[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCVkVQ.VVKXsZ:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFPPAc(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCVkVQ.VVGg72:
    tp = CCGAc5()
   VVsyWY, VVWauh = FF3PrL()
   tagFound  = False
   if mode in (CCVkVQ.VVYyfD, CCVkVQ.VVQJHa):
    VVEl38 = {}
   else:
    VVEl38 = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFkiAa(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCVkVQ.VVlNJn:
        if sTypeInt in VVsyWY:
         STYPE = VVWauh[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVEl38.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVEl38.append(tRow)
        else:
         VVEl38.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCVkVQ.VVYyfD:
         VVEl38[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCVkVQ.VVQJHa:
         VVEl38[chName] = refCode
        elif mode == CCVkVQ.VVKXsZ:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVEl38.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVEl38.append(tRow)
         else:
          VVEl38.append(tRow)
        elif mode == CCVkVQ.VVGg72:
         if sTypeInt in VVsyWY:
          STYPE = VVWauh[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVBhAc(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVEl38.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVEl38.append(tRow)
         else:
          VVEl38.append(tRow)
        elif mode == CCVkVQ.VVcv9Q:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVEl38.append((chName, chProv, sat, refCode))
        elif mode == CCVkVQ.VVcfvB:
         VVEl38.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVEl38 and VVUIx4:
    FFdx4k(SELF, "No services found!")
   return VVEl38
  else:
   if VVQoiw:
    FF5BoZ(SELF, lamedbFile)
   return None
 def VVfZ9a(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFPPAc(path)
   if lines:
    newRows  = []
    VVEl38 = CCVkVQ.VVheOM(self, self.VVcfvB)
    if VVEl38:
     lines = set(lines)
     for item in VVEl38:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVEl38 = newRows
      VVEl38.sort(key=lambda x: x[0].lower())
      VVkGsu = ("", self.VVBoO1, [])
      VVR5hp = ("Zap", self.VV8awy, [])
      self.VVXpSd(VV8klC=VVEl38, VVR5hp=VVR5hp, VVkGsu=VVkGsu)
     else:
      FFh3cd(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVEl38)))
   else:
    FFUbus(self, "No active Parental Control services.", FFRiG8())
  else:
   FF5BoZ(self, path)
 def VVmtRg(self):
  VVEl38 = CCVkVQ.VVheOM(self, self.VVcv9Q)
  if VVEl38:
   VVEl38.sort(key=lambda x: x[0].lower())
   VVkGsu = ("" , self.VVBoO1, [])
   VVR5hp  = ("Zap", self.VV8awy, [])
   self.VVXpSd(VV8klC=VVEl38, VVR5hp=VVR5hp, VVkGsu=VVkGsu)
  else:
   FFUbus(self, "No hidden services.", FFRiG8())
 def VVplJW(self):
  totT, totC, totA, totS, totS2, satList = self.VVm4BN()
  txt = FF34IZ("Total Transponders:\n\n", VVmWy8)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF34IZ("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVmWy8)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF5cxP(item), satList.count(item))
  FFh3cd(self, txt)
 def VVm4BN(self):
  lamedbFile, disabledFile = CCVkVQ.VV5hDF()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FF5BoZ(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVr4Na(self)   : self.VVUPvI(True)
 def VVrCXJ(self) : self.VVUPvI(False)
 def VVUPvI(self, isWithPIcons):
  piconsPath = CCBIQf.VVS0I8()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCBIQf.VVaY26(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVEl38 = CCVkVQ.VVheOM(self, self.VVcfvB)
    if VVEl38:
     channels = []
     for (chName, chProv, sat, refCode) in VVEl38:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFWB9I(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVEl38)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVPlT0(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVPlT0("PIcons Path"  , piconsPath)
     txt += VVPlT0("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVPlT0("Total services" , totalServices)
     txt += VVPlT0("With PIcons"  , totalWithPIcons)
     txt += VVPlT0("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFh3cd(self, txt)
     else:
      VVkGsu     = (""      , self.VVBoO1 , [])
      if isWithPIcons : VVn2KW = ("Export Current PIcon", self.VVkZtL  , [])
      else   : VVn2KW = None
      VVRYtq     = ("Statistics", FFh3cd, [txt])
      VVR5hp      = ("Zap", self.VV8awy, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVXpSd(VV8klC=channels, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVRYtq=VVRYtq, VVn2KW=VVn2KW)
   else:
    FFdx4k(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFdx4k(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVBoO1(self, VV8kdg, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FF9kJ8(self, fncMode=CCS14C.VVfIDC, refCode=refCode, chName=chName, text=txt)
 def VVkZtL(self, VV8kdg, title, txt, colList):
  png, path = CCBIQf.VVyxTn(colList[3], colList[0])
  if path:
   CCBIQf.VVNMGh(self, png, path)
 @staticmethod
 def VV5hDF():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVtrKu():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVyRPi(self, isEnable):
  lamedbFile, disabledFile = CCVkVQ.VV5hDF()
  if isEnable and not fileExists(disabledFile):
   FFUbus(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFdx4k(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFT4Vd(self, boundFunction(self.VVxlxX, isEnable), "%s Hidden Channels ?" % word)
 def VVxlxX(self, isEnable):
  lamedbFile , disabledFile = CCVkVQ.VV5hDF()
  lamedb5File, diabled5File = CCVkVQ.VVtrKu()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FF28nO()
  if res == 0 : FFUbus(self, "Hidden List %s" % word)
  else  : FFdx4k(self, "Error while restoring:\n\n%s" % fileName)
 def VVe7AE(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFYm78(self, cmd)
 def VVbjKr(self):
  lamedbFile, disabledFile = CCVkVQ.VV5hDF()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FF0t1y("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFPPAc(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FF0t1y("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FF28nO()
   FFh3cd(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FF5BoZ(self, lamedbFile)
class CCS14C(Screen):
 VVch8F  = 0
 VVTsRg   = 1
 VVauHr   = 2
 VVfIDC    = 3
 VVU8VF    = 4
 VVdopo   = 5
 VVM5TP   = 6
 VV6FeV    = 7
 VVcLgJ   = 8
 VVSj2C   = 9
 VVQjMS   = 10
 VVPnZd   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFuMnj(VVlcNn, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVch8F)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FF34IZ("%s\n", VVQAQ9) % VVbwqB
  FFgoqU(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self["myLabel"].VV36kJ(textOutFile="chann_info")
  if   self.fncMode == self.VVch8F : fnc = self.VVzpO6_VVch8F
  elif self.fncMode == self.VVTsRg  : fnc = self.VVzpO6_VVch8F
  elif self.fncMode == self.VVauHr  : fnc = self.VVzpO6_VVch8F
  elif self.fncMode == self.VVfIDC  : fnc = self.VVzpO6_VVfIDC
  elif self.fncMode == self.VVU8VF  : fnc = self.VVzpO6_VVU8VF
  elif self.fncMode == self.VVdopo  : fnc = self.VVzpO6_VVdopo
  elif self.fncMode == self.VVM5TP  : fnc = self.VVzpO6_VVM5TP
  elif self.fncMode == self.VV6FeV  : fnc = self.VVzpO6_VV6FeV
  elif self.fncMode == self.VVcLgJ  : fnc = self.VVzpO6_VVcLgJ
  elif self.fncMode == self.VVSj2C : fnc = self.VVzpO6_VVSj2C
  elif self.fncMode == self.VVQjMS  : fnc = self.VVzpO6_VVQjMS
  elif self.fncMode == self.VVPnZd : fnc = self.VVzpO6_VVPnZd
  self["myLabel"].setText("\n   Reading Info ...")
  FFC95U(fnc)
 def VVxq3f(self, err):
  self["myLabel"].setText(err)
  FFYzPI(self["myTitle"], "#22200000")
  FFYzPI(self["myBody"], "#22200000")
  self["myLabel"].FFYzPIColor("#22200000")
  self["myLabel"].VVyPlD()
 def VVzpO6_VVch8F(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  self.refCode = refCode
  self.VVKn3E(chName)
 def VVzpO6_VVfIDC(self):
  self.VVKn3E(self.chName)
 def VVzpO6_VVU8VF(self):
  self.VVKn3E(self.chName)
 def VVzpO6_VVdopo(self):
  self.VVKn3E(self.chName)
 def VVzpO6_VVM5TP(self):
  self.VVKn3E("Picon Info")
 def VVzpO6_VV6FeV(self):
  self.VVKn3E(self.chName)
 def VVzpO6_VVcLgJ(self):
  self.VVKn3E(self.chName)
 def VVzpO6_VVSj2C(self):
  self.VVKn3E(self.chName)
 def VVzpO6_VVQjMS(self):
  self.chUrl = self.refCode + self.callingSELF.VVihT7(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVKn3E(self.chName)
 def VVzpO6_VVPnZd(self):
  self.VVKn3E(self.chName)
 def VVKn3E(self, title):
  self.VVR4p0(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVzyBV(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF34IZ(self.VVREM0(tUrl), VVho0k)
  if not self.epg:
   epg = self.VV21Dw(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVl5nE(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCBIQf.VVyxTn(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVl5nE(path)
  self.VVOzuL()
  self.VVSGZw()
  self["myLabel"].setText(self.text, VV9aL5=VVDZSi)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVyPlD(minHeight=minH)
 def VVSGZw(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFgsAM(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVz0qm(FFDQFE(url))
  if epg:
   self.text += "\n" + FF03HQ("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVOzuL()
 def VVOzuL(self):
  if not self.piconShown and self.picUrl:
   path, err = FFgxGp(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VVl5nE(path)
    if self.piconShown and self.refCode:
     self.VVc4aM(path, self.refCode)
 def VVc4aM(self, path, refCode):
  if path and fileExists(path) and os.system(FF0t1y("which ffmpeg")) == 0:
   pPath = CCBIQf.VVS0I8()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FF0t1y("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVl5nE(self, path):
  if path and fileExists(path):
   err, w, h = self.VVJOt9(path)
   if not err:
    if h > w:
     self.VVDlMH(self["myPicF"], w, h, True)
     self.VVDlMH(self["myPic"] , w, h, False)
   allOK = FFGkqs(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVDlMH(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVJOt9(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFCpPs(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVR4p0(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VVzyBV(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF34IZ(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVPlT0(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF34IZ(state, VVP2je)
   txt += "State\t: %s\n" % state
  w = FFFIZe(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFFIZe(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVSuWc(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVPlT0(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVPlT0(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVPlT0(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FF34IZ("IPTV", VVmWy8)
   txt += self.VV5wxN(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVjves(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCGAc5()
    tpTxt, namespace = tp.VVnpjs(refCode)
    del tp
    if tpTxt:
     txt += FF34IZ("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF34IZ("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVPlT0(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVPlT0(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVPlT0(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVPlT0(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVPlT0(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVPlT0(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVPlT0(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVPlT0(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVPlT0(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVSuWc(info):
  if info:
   aspect = FFFIZe(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVPlT0(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFFIZe(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVKIJl(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVKIJl(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVjves(self, refCode, iptvRef, chName):
  refCode = FFvoWy(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFtCkf(VVBjVb + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFtCkf(VVBjVb + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV8klC = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVBjVb + item
   if fileExists(path):
    txt = FFtCkf(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV8klC.append(bName)
  txt = self.Sep
  if VV8klC:
   if len(VV8klC) == 1:
    txt += "%s\t: %s\n" % (FF34IZ("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV8klC[0])
   else:
    txt += FF34IZ("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV8klC):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV21Dw(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVsatZ(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVsatZ(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVsatZ(event, 0)
     except:
      pass
  return epg
 def VVsatZ(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FF34IZ(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FFCnzX(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFCnzX(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF4dJc(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF4dJc(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF4dJc(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FF34IZ(evShort, VVho0k)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF34IZ(evDesc , VVho0k)
    if txt:
     txt = FF34IZ("\n%s\n%s Event:\n%s\n" % (VVbwqB, ("Current", "Next")[evNum], VVbwqB), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VV5wxN(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFk1Ul(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCWzIF()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVBlGO(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF34IZ("URL:", VVmWy8) + "\n%s\n" % self.VVREM0(decodedUrl)
  else:
   txt = "\n"
   txt += FF34IZ("Reference:", VVmWy8) + "\n%s\n" % refCode
  return txt
 def VVREM0(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVp9kL:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVz0qm(self, decodedUrl):
  if not FFScuV():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCRT5i.VV8xGu(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCRT5i.VV8uYD(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVOEUF(tDict)
   elif uType == "movie" : epg, picUrl = self.VVpW91(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVOEUF(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCRT5i.VVZuWD(item, "title"    , is_base64=True )
     lang    = CCRT5i.VVZuWD(item, "lang"         ).upper()
     description   = CCRT5i.VVZuWD(item, "description"  , is_base64=True )
     start_timestamp  = CCRT5i.VVZuWD(item, "start_timestamp" , isDate=True  )
     stop_timestamp  = CCRT5i.VVZuWD(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCRT5i.VVZuWD(item, "stop_timestamp"       )
     now_playing   = CCRT5i.VVZuWD(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVpw0r, ""
      else     : color, txt = VVP2je , "    (CURRENT EVENT)"
      epg += FF34IZ("_" * 32 + "\n", VVQAQ9)
      epg += FF34IZ("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FF34IZ(description, VVho0k)
      evNum += 1
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVpW91(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCRT5i.VVZuWD(item, "movie_image" )
    genre  = CCRT5i.VVZuWD(item, "genre"   ) or "-"
    plot  = CCRT5i.VVZuWD(item, "plot"   ) or "-"
    cast  = CCRT5i.VVZuWD(item, "cast"   ) or "-"
    rating  = CCRT5i.VVZuWD(item, "rating"   ) or "-"
    director = CCRT5i.VVZuWD(item, "director"  ) or "-"
    releasedate = CCRT5i.VVZuWD(item, "releasedate" ) or "-"
    duration = CCRT5i.VVZuWD(item, "duration"  ) or "-"
    try:
     lang = CCRT5i.VVZuWD(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF34IZ(cast, VVho0k)
    epg += "Plot:\n%s"    % FF34IZ(plot, VVho0k)
   except:
    pass
  return epg, movie_image
class CCWzIF():
 def __init__(self):
  self.VVsCKd  = ""
  self.VVLjyQ   = ""
  self.VVlKFk  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV68Oc(self, url, mac, VVpwCo=True):
  self.VVsCKd = ""
  self.VVLjyQ  = ""
  self.VVlKFk = ""
  host = self.VV5YaF(url)
  if not host:
   if VVpwCo:
    self.VVpwCoor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVystH(mac)
  if not host:
   if VVpwCo:
    self.VVpwCoor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVsCKd = host
  self.VVLjyQ  = mac
  self.VVlKFk = ""
  return True
 def VV2iRW(self):
  res, err = self.VVIu6o(self.VVsCKd, useCookies=False)
  if err:
   self.VVpwCoor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVIu6o(newUrl, res.cookies)
   if err:
    self.VVpwCoor(err, "URL Redirection")
    return False
   else:
    host = self.VV5YaF(newUrl)
    if not host:
     self.VVpwCoor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVsCKd = host
  token, profile = self.VVjzAS()
  if not token:
   return False
  return True
 def VV5YaF(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VVystH(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVjzAS(self, VVpwCo=True):
  try:
   token = self.VV7WMq()
   if token:
    self.VVlKFk = token
   else:
    if VVpwCo:
     self.VVpwCoor("Could not get Token from server !")
    return "", ""
   return token, self.VVDCwU()
  except:
   return "", ""
 def VV7WMq(self):
  token  = ""
  res, err = self.VVIu6o(self.VVj6Yu())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCRT5i.VVZuWD(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVDCwU(self):
  res, err = self.VVIu6o(self.VVR0KG())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVTo8E(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVV6Y3()
  if len(rows) < 10:
   rows = self.VV3Tfh()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVsCKd ))
   rows.append(("MAC (from URL)" , self.VVLjyQ ))
   rows.append(("Token"   , self.VVlKFk ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVLjyQ ))
   rows.append(("2", self.colored_server, "Host" , self.VVsCKd ))
   rows.append(("2", self.colored_server, "Token" , self.VVlKFk ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVLIzN(self):
  token, profile = self.VVjzAS()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVPsXp()
  res, err = self.VVIu6o(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCRT5i.VVZuWD(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVV6Y3(self):
  m3u_Url = self.VVLIzN()
  rows = []
  if m3u_Url:
   res, err = self.VVIu6o(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFCnzX(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFCnzX(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV3Tfh(self):
  token, profile = self.VVjzAS()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF9axR(val): val = FFScix(val.decode("UTF-8"))
     else     : val = self.VVLjyQ
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFCnzX(int(parts[1]))
      if parts[2] : ends = FFCnzX(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFCnzX(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVihT7(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVPG22(mode, chCm, epNum, epId)
  token, profile = self.VVjzAS(VVpwCo=False)
  if not token:
   return ""
  res, err = self.VVIu6o(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCRT5i.VVZuWD(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVVtrK(self):
  return self.VVsCKd + "/server/load.php?"
 def VVj6Yu(self):
  return self.VVVtrK() + "type=stb&action=handshake&token=&mac=%s" % self.VVLjyQ
 def VVR0KG(self):
  return self.VVVtrK() + "type=stb&action=get_profile"
 def VVar3K(self, mode):
  url = self.VVVtrK() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVRw7B(self, catID):
  return self.VVVtrK() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV7PK5(self, mode, catID, page):
  url = self.VVVtrK() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVMaqo(self, mode, searchName, page):
  return self.VVVtrK() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVY7jB(self, mode, catID):
  return self.VVVtrK() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVPG22(self, mode, chCm, serCode, serId):
  url = self.VVVtrK() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVPsXp(self):
  return self.VVVtrK() + "type=itv&action=create_link"
 def VV2bU5(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVbVnV(catID, stID, chNum)
  query = self.VVTQJ4(mode, FFs7CX(host), FFs7CX(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVTQJ4(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVBlGO(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVTQJ4(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFScix(host)
  mac   = FFScix(mac)
  valid = False
  if self.VV5YaF(playHost) and self.VV5YaF(host) and self.VV5YaF(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVIu6o(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVLjyQ, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVlKFk:
    headers["Authorization"] = "Bearer %s" % self.VVlKFk
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVF9RG(host, mac, tType, action, keysList=[]):
  myPortal = CCWzIF()
  ok = myPortal.VV68Oc(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VVjzAS()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVIu6o(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVvQ9Y(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVvQ9Y(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVpwCoor(self, err, title="Portal Browser"):
  FFdx4k(self, str(err), title=title)
 def VVEn1x(self, mode):
  if   mode in ("itv"  , CCRT5i.VVuNKO) : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCRT5i.VVOcOA) : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCRT5i.VVv0UV): return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode == "series2"           : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else               : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVlO8L(self, mode):
  if   mode in ("itv"  , CCRT5i.VVuNKO , CCRT5i.VVijuV)  : return "Live"
  elif mode in ("vod"  , CCRT5i.VVOcOA , CCRT5i.VVWIYs)  : return "VOD"
  elif mode in ("series" , CCRT5i.VVv0UV , CCRT5i.VV1sZp) : return "Series"
  else                          : return "IPTV"
 def VVlTff(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVlO8L(mode), searchName)
 def VV60RG(self):
  VVhjJY = []
  VVhjJY.append(("Live"    , "live"  ))
  VVhjJY.append(("VOD"    , "vod"   ))
  VVhjJY.append(("Series "   , "series"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Account Info." , "accountInfo" ))
  return VVhjJY
class CCN49V(CCWzIF):
 def __init__(self):
  CCWzIF.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VV0C5a(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVBlGO(decodedUrl)
  if valid:
   if self.VV68Oc(host, mac, VVpwCo=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVIB8k(self, passedSELF=None, isFromSession=False):
  chUrl = self.VVihT7(self.mode, self.chCm, self.epNum, self.epId)
  if not chUrl:
   return
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVrtBT(self.iptvRef, newIptvRef)
   if passedSELF:
    FF4ffD(passedSELF, newIptvRef, VVXA27=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FF4ffD(self, newIptvRef, VVXA27=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVrtBT(self, oldCode, newCode):
  bPath = FFLobe()
  if bPath:
   txt = FFtCkf(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FF28nO()
    return True
  return False
class CCHGHa(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFuMnj(VVX081, 10, 10, 50, 30, 20, "#22002020", "#22001122", 30)
  self.session = session
  FFgoqU(self, "")
  self.close()
class CChBbB(CCN49V):
 def __init__(self, passedSession):
  CCN49V.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={ iPlayableService.evEnd: self.VV8dHq})
  except:
   pass
 def VV8dHq(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VViMoY)
  except:
   self.timer1.callback.append(self.VViMoY)
  self.timer1.start(100, True)
 def VViMoY(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VV0C5a(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CClGFA.PLAYER_INSTANCE:
       self.VVIB8k(self.passedSession, isFromSession=True)
class CCkHXi():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVSF4f(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCRT5i.VVfaHx(name):
   return CCRT5i.VVt2GJ(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVmyko(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name, IGNORECASE)
  if span:
   name = span.group(1)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVAHtB(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVFLsW(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVYm0I(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCtJgL(CCWzIF):
 def __init__(self):
  CCWzIF.__init__(self)
 def VVWY2R(self):
  try:
   import requests
   FFdDg8(self, self.VV56Lm, title="Searching ...")
  except:
   FFT4Vd(self, self.VVEh1F, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVwUI7(self, winSession, url, mac):
  if self.VV68Oc(url, mac):
   FFdDg8(winSession, self.VVA4aH, title="Checking Server ...")
  else:
   FFdx4k(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVEh1F(self):
  from sys import version_info
  cmdUpd = FFGMYv(VVQVcc, "")
  if cmdUpd:
   cmdInst = FFBSlb(VVSeHH, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFTgBK(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFHvqH(self)
 def VV56Lm(self):
  lines = FFHErt('find / %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % FFF164(1))
  if lines:
   lines.sort()
   VVhjJY = []
   for line in lines:
    VVhjJY.append((line, line))
   OKBtnFnc = self.VVO4qM
   FFmvQ5(self, None, title="Select Portals File", VVhjJY=VVhjJY, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFdx4k(self, "No portal files found\n\nFile example : portalxx.txt \n(separate URL and MAC with space/tab/comma)")
 def VVO4qM(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CCxrdg, barTheme=CCxrdg.VV6xsn
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVdBef, path)
       , VVHVqi = boundFunction(self.VVsHzJ, menuInstance, path))
 def VVdBef(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  lines  = FFPPAc(path)
  progBarObj.VVgcp1(len(lines))
  progBarObj.VVF8YZ = []
  import time
  for lineNum, line in enumerate(lines, start=1):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVPQ4V(1, True)
   iSleep(0.0001)
   line = line.strip()
   if not line or "password" in line:
    continue
   span = iSearch(urlMacPatt, line, IGNORECASE)
   if span:
    c  += 1
    subj = span.group(1).strip() or "-"
    url  = span.group(2).strip()
    mac  = span.group(3).strip().replace(" ", "").upper()
    info = span.group(4).strip() or "-"
    host = self.VV5YaF(url)
    mac  = self.VVystH(mac)
    if host and mac and progBarObj:
     progBarObj.VVF8YZ.append((str(c), str(lineNum), subj, host, mac, info))
    url  = ""
    continue
   if not url:
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if not span:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
   else:
    span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     mac  = span.group(2).strip().replace(" ", "").upper()
     info = span.group(3).strip() or "-"
     host = self.VV5YaF(url)
     mac  = self.VVystH(mac)
     if host and mac and not mac.startswith("AC") and progBarObj:
      progBarObj.VVF8YZ.append((str(c), str(lineNum), "-", host, mac, info))
    else:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
 def VVsHzJ(self, menuInstance, path, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVF8YZ:
   VV6Yzq  = ("Home Menu", FFmCer, [])
   VVn2KW  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVRYtq = ("Edit File" , boundFunction(self.VV1Hsc, path) , [])
   VVR5hp  = ("Select"  , self.VVwUI7_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVenpJ  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VV8kdg = FFrMdi(self, None, title=title, header=header, VV8klC=VVF8YZ, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VV6Yzq=VV6Yzq, VVRYtq=VVRYtq, VVn2KW=VVn2KW, VVHOIE="#0a001111", VVsOU8="#0a001122", VVauqk="#0a001122", VVMVsE="#00000000", VVWA0Q=True, searchCol=1)
   if not VVV9Ca:
    FFbo0g(VV8kdg, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVV9Ca:
    FFdx4k(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVwUI7_fromMacFiles(self, VV8kdg, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVwUI7(VV8kdg, url, mac)
 def VV1Hsc(self, path, VV8kdg, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCVm0W(self, path, VVHVqi=boundFunction(self.VVOv1h, VV8kdg), curRowNum=rowNum)
  else    : FF5BoZ(self, path)
 def VVOv1h(self, VV8kdg, fileChanged):
  if fileChanged:
   VV8kdg.cancel()
 def VV4Irp(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFScix(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVA4aH(self):
  if self.VV2iRW():
   VVhjJY  = self.VV60RG()
   OKBtnFnc = self.VVR0IA
   VVvGoO = ("Home Menu", FFmCer)
   FFmvQ5(self, None, title="Portal Resources (MAC=%s)" % self.VVLjyQ, VVhjJY=VVhjJY, OKBtnFnc=OKBtnFnc, VVvGoO=VVvGoO)
 def VVR0IA(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFdDg8(menuInstance, boundFunction(self.VVVkhV, mode), title="Reading Categories ...")
   else : FFdDg8(menuInstance, boundFunction(self.VVkpxB, menuInstance, title), title="Reading Account ...")
 def VVkpxB(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVTo8E(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVLjyQ)
  VV6Yzq  = ("Home Menu" , FFmCer, [])
  if totCols == 2:
   VVn2KW = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVn2KW = ("More Info.", boundFunction(self.VVQ9AT, menuInstance) , [])
  FFrMdi(self, None, title=title, width=1200, header=header, VV8klC=rows, VVxJaI=widths, VVhj1e=26, VV6Yzq=VV6Yzq, VVn2KW=VVn2KW, VVHOIE="#0a00292B", VVsOU8="#0a002126", VVauqk="#0a002126", VVMVsE="#00000000", searchCol=searchCol)
 def VVQ9AT(self, menuInstance, VV8kdg, title, txt, colList):
  VV8kdg.cancel()
  FFdDg8(menuInstance, boundFunction(self.VVkpxB, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVVkhV(self, mode):
  token, profile = self.VVjzAS()
  if not token:
   return
  res, err = self.VVIu6o(self.VVar3K(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCkHXi()
     chList = tDict["js"]
     for item in chList:
      Id   = CCRT5i.VVZuWD(item, "id"       )
      Title  = CCRT5i.VVZuWD(item, "title"      )
      censored = CCRT5i.VVZuWD(item, "censored"     )
      Title = processChanName.VVAHtB(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVp9kL:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVlO8L(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x(mode)
   mName = self.VVlO8L(mode)
   VVR5hp   = ("Show List"  , boundFunction(self.VVZQox, mode) , [])
   VV6Yzq  = ("Home Menu"   , FFmCer         , [])
   if mode in ("vod", "series"):
    VVRYtq = ("Find in %s" % mName , boundFunction(self.VVV2GR, mode), [])
   else:
    VVRYtq = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFrMdi(self, None, title=title, width=1200, header=header, VV8klC=list, VVxJaI=widths, VVhj1e=30, VV6Yzq=VV6Yzq, VVRYtq=VVRYtq, VVR5hp=VVR5hp, VVHOIE=VVHOIE, VVsOU8=VVsOU8, VVauqk=VVauqk, VVMVsE=VVMVsE)
  else:
   FFdx4k(self, "Could not get Categories from server!", title=title)
 def VVPYSE(self, mode, VV8kdg, title, txt, colList):
  FFdDg8(VV8kdg, boundFunction(self.VV7XZz, mode, VV8kdg, title, txt, colList), title="Downloading ...")
 def VV7XZz(self, mode, VV8kdg, title, txt, colList):
  token, profile = self.VVjzAS()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVIu6o(self.VVRw7B(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCRT5i.VVZuWD(item, "id"    )
      actors   = CCRT5i.VVZuWD(item, "actors"   )
      added   = CCRT5i.VVZuWD(item, "added"   )
      age    = CCRT5i.VVZuWD(item, "age"   )
      category_id  = CCRT5i.VVZuWD(item, "category_id" )
      description  = CCRT5i.VVZuWD(item, "description" )
      director  = CCRT5i.VVZuWD(item, "director"  )
      genres_str  = CCRT5i.VVZuWD(item, "genres_str"  )
      name   = CCRT5i.VVZuWD(item, "name"   )
      path   = CCRT5i.VVZuWD(item, "path"   )
      screenshot_uri = CCRT5i.VVZuWD(item, "screenshot_uri" )
      series   = CCRT5i.VVZuWD(item, "series"   )
      cmd    = CCRT5i.VVZuWD(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVR5hp  = ("Play"  , boundFunction(self.VVnjCw, mode, False)      , [])
   VVkGsu = (""   , boundFunction(self.VVtjyP, mode)      , [])
   VV6Yzq = ("Home Menu" , FFmCer                , [])
   VVB3WF = ("Download PIcons" , boundFunction(self.VVuxZQ, mode)      , [])
   VVRYtq = ("Add ALL to Bouquet" , boundFunction(self.VVJoAo, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVenpJ  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFrMdi(self, None, title=seriesName, width=1200, header=header, VV8klC=list, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVHOIE="#0a00292B", VVsOU8="#0a002126", VVauqk="#0a002126", VVMVsE="#00000000")
  else:
   FFdx4k(self, "Could not get Episodes from server!", title=seriesName)
 def VVV2GR(self, mode, VV8kdg, title, txt, colList):
  VVhjJY = []
  VVhjJY.append(("Keyboard"  , "manualEntry"))
  VVhjJY.append(("From Filter" , "fromFilter"))
  FFmvQ5(self, boundFunction(self.VVohUq, VV8kdg, mode), title="Input Type", VVhjJY=VVhjJY, width=400)
 def VVohUq(self, VV8kdg, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFktKm(self, boundFunction(self.VVIOPp, VV8kdg, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCwKtp(self)
    filterObj.VVJk9C(boundFunction(self.VVIOPp, VV8kdg, mode))
 def VVIOPp(self, VV8kdg, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVlTff(mode, searchName)
   if len(searchName) < 3:
    FFdx4k(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCkHXi()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVFLsW([searchName]):
     FFdx4k(self, processChanName.VVYm0I(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVkOii(mode, searchName, "", searchName)
 def VVZQox(self, mode, VV8kdg, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVkOii(mode, bName, catID, "")
 def VVkOii(self, mode, bName, catID, searchName):
  self.session.open(CCxrdg, barTheme=CCxrdg.VVpCGU
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVjsJV, mode, bName, catID, searchName)
      , VVHVqi = boundFunction(self.VVw5CF, mode, bName, catID, searchName))
 def VVw5CF(self, mode, bName, catID, searchName, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVlTff(mode, searchName)
  else   : title = "%s : %s" % (self.VVlO8L(mode), bName)
  if VVF8YZ:
   if mode == "series":
    VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x("series2")
    VVR5hp  = ("Episodes", boundFunction(self.VVPYSE, mode) , [])
    VVB3WF = None
    VVRYtq = None
   else:
    VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x("")
    VVR5hp  = ("Play"    , boundFunction(self.VVnjCw, mode, False)   , [])
    VVB3WF = ("Download PIcons" , boundFunction(self.VVuxZQ, mode)     , [])
    VVRYtq = ("Add ALL to Bouquet" , boundFunction(self.VVJoAo, mode, bName) , [])
   VVkGsu = (""      , boundFunction(self.VVh8Q3, mode)    , [])
   VV6Yzq = ("Home Menu"    , FFmCer             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVenpJ  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VV8kdg = FFrMdi(self, None, title=title, header=header, VV8klC=VVF8YZ, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVHOIE=VVHOIE, VVsOU8=VVsOU8, VVauqk=VVauqk, VVMVsE=VVMVsE, VVWA0Q=True, searchCol=1)
   if not VVV9Ca:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VV8kdg.VVJeJA(VV8kdg.VVvELd() + tot)
    if threadErr: FFbo0g(VV8kdg, "Error while reading !", 2000)
    else  : FFbo0g(VV8kdg, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFdx4k(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFdx4k(self, "Could not get list from server !", title=title)
 def VVh8Q3(self, mode, VV8kdg, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FF9kJ8(self, fncMode=CCS14C.VVPnZd, portalHost=self.VVsCKd, portalMac=self.VVLjyQ, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVnCBR(mode, VV8kdg, title, txt, colList)
 def VVtjyP(self, mode, VV8kdg, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF34IZ(colList[10], VVho0k)
  txt += "Description:\n%s" % FF34IZ(colList[11], VVho0k)
  self.VVnCBR(mode, VV8kdg, title, txt, colList)
 def VVnCBR(self, mode, VV8kdg, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVFPfF(mode, colList)
  refCode, chUrl = self.VV2bU5(self.VVsCKd, self.VVLjyQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FF9kJ8(self, fncMode=CCS14C.VVQjMS, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVjsJV(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VVjzAS()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVF8YZ, total_items, max_page_items, err = self.VVCy6e(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVF8YZ and total_items > -1 and max_page_items > -1:
    progBarObj.VVgcp1(total_items)
    progBarObj.VVPQ4V(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVCy6e(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVOU66()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVF8YZ += list
      progBarObj.VVPQ4V(len(list), True)
  except:
   pass
 def VVCy6e(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url =self.VVMaqo(mode, searchName, page)
  else   : url =self.VV7PK5(mode, catID, page)
  res, err = self.VVIu6o(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVHhbp(CCRT5i.VVZuWD(item, "total_items" ))
     max_page_items = self.VVHhbp(CCRT5i.VVZuWD(item, "max_page_items" ))
     processChanName = CCkHXi()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCRT5i.VVZuWD(item, "id"    )
      name   = CCRT5i.VVZuWD(item, "name"   )
      tv_genre_id  = CCRT5i.VVZuWD(item, "tv_genre_id" )
      number   = CCRT5i.VVZuWD(item, "number"   ) or str(counter)
      logo   = CCRT5i.VVZuWD(item, "logo"   )
      screenshot_uri = CCRT5i.VVZuWD(item, "screenshot_uri" )
      cmd    = CCRT5i.VVZuWD(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVSF4f(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVJoAo(self, mode, bName, VV8kdg, title, txt, colList):
  FFdDg8(VV8kdg, boundFunction(self.VVEiC5, mode, bName, VV8kdg, title, txt, colList), title="Adding Channels ...")
 def VVEiC5(self, mode, bName, VV8kdg, title, txt, colList):
  bNameFile = CCRT5i.VVzVND(bName)
  num  = 0
  path = VVBjVb + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVBjVb + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VV8kdg.VVGUJf():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVFPfF(mode, row)
    refCode, chUrl = self.VV2bU5(self.VVsCKd, self.VVLjyQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFADrf(os.path.basename(path))
  self.VVgjI1(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVHhbp(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVnjCw(self, mode, fromPlayer, VV8kdg, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVFPfF(mode, colList)
  refCode, chUrl = self.VV2bU5(self.VVsCKd, self.VVLjyQ, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VVbMUe(mode, VV8kdg, chUrl)
  elif self.VVfaHx(chName):
   FFbo0g(VV8kdg, "This is a marker!", 300)
  else:
   FFdDg8(VV8kdg, boundFunction(self.VVbMUe, mode, VV8kdg, chUrl), title="Playing ...")
 def VVbMUe(self, mode, VV8kdg, chUrl):
  FF4ffD(self, chUrl, VVXA27=False)
  self.session.open(CClGFA, portalTableParam=(self, VV8kdg, mode))
 def VVFPfF(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCRT5i(Screen, CCtJgL):
 VVSaOJ = 0
 VVgLvo = 1
 VVXaVP = 2
 VVjDl6 = 3
 VVhp2Q  = 4
 VVgF4n  = 5
 VVQMdJ  = 6
 VVvfjS  = 7
 VV5DFD   = 8
 VVzGpG  = 9
 VVSTpe  = 10
 VVb1Nc  = 11
 VVeMd1  = 12
 VV8mls   = 13
 VVBEb0   = 14
 VVwpSg   = 15
 VVmTjg   = 16
 VVBvW6   = 17
 VV0ywR    = 0
 VVuNKO   = 1
 VVOcOA   = 2
 VVv0UV   = 3
 VVWOAy  = 4
 VVijuV   = 5
 VVWIYs   = 6
 VV1sZp  = 7
 VVRjie  = 8
 VVOvWE   = 9
 VV8TMU = 10
 VVQVem   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 900, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VV8kdg  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVNKFTData  = {}
  self.lastFindIptvName = ""
  CCtJgL.__init__(self)
  VVhjJY= self.VVEFTw()
  FFgoqU(self, title="IPTV", VVhjJY=VVhjJY)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
  FFLQL2(self)
 def VVEFTw(self):
  files = self.VVrueM()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVNKFT_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVNKFT_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVNKFT_fromM3u"  ))
  qUrl, iptvRef = self.VVZ4di()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVNKFT_fromCurrChan" ))
  VVhjJY = []
  if files:
   if self.VV8kdg:
    VVhjJY.append(("Add Current List to a New Bouquet"      , "VV3khv"  ))
    VVhjJY.append(VVeSPq)
    VVhjJY.append(("Change Current List References to Unique Codes"   , "VVNVgr"))
    VVhjJY.append(("Change Current List References to Identical Codes"  , "VVGwLj_rows" ))
    VVhjJY.append(VVeSPq)
    VVhjJY.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVVExD"   ))
    VVhjJY.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVE3zW"   ))
   else:
    VVhjJY += tList
    VVhjJY.append(VVeSPq)
    VVhjJY.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    VVhjJY.append(VVeSPq)
    VVhjJY.append(("Count Available IPTV Channels"       , "VVoeCo"    ))
    VVhjJY.append(("Check Reference Codes Format"        , "VV7TUt"   ))
    VVhjJY.append(("Check System Acceptable Reference Types"     , "VVpeJF"   ))
    VVhjJY.append(VVeSPq)
    VVhjJY.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VV9s5b"  ))
    VVhjJY.append(("Change ALL References to match existing Sat/C/T Channels" , "VVXKig" ))
    VVhjJY.append(("Change ALL References to Unique Codes"     , "VVSofN" ))
    VVhjJY.append(("Change ALL References to Identical Codes"     , "VVGwLj_all" ))
  if not self.VV8kdg:
   if not files:
    VVhjJY += tList
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Analyse m3u File"            , "VV6u7c"   ))
   VVhjJY.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVWN9P" ))
   VVhjJY.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVTaec" ))
   VVhjJY.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVxZnS" ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Reload Channels and Bouquets"         , "VV1XTa"   ))
  return VVhjJY
 def VVnBXm(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   if   item == "VV3khv"   : FFktKm(self, self.VV3khv, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVNVgr" : FFT4Vd(self, boundFunction(FFdDg8, self.VV8kdg, self.VVNVgr ), "Change Current List References to Unique Codes ?")
   elif item == "VVGwLj_rows" : FFT4Vd(self, boundFunction(FFdDg8, self.VV8kdg, self.VVGwLj   ), "Change Current List References to Identical Codes ?")
   elif item == "VVVExD"   : self.VVVExD(tTitle)
   elif item == "VVE3zW"   : self.VVE3zW(tTitle)
   elif item == "VVNKFT_fromPlayList" : FFdDg8(self, boundFunction(self.VV2PJe, True), title="Searching ...")
   elif item == "VVNKFT_fromM3u"  : FFdDg8(self, boundFunction(self.VVIpFL, 0), title="Searching ...")
   elif item == "VVNKFT_fromMac"  : self.VVWY2R()
   elif item == "VVNKFT_fromCurrChan" : self.VVwUI7_fromCurrChan()
   elif item == "iptvTable_live"   : FFdDg8(self, boundFunction(self.VVJM0q, self.VVvfjS ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFdDg8(self, boundFunction(self.VVJM0q, self.VVSaOJ) , title="Loading Channels ...")
   elif item == "VVoeCo"    : FFdDg8(self, self.VVoeCo)
   elif item == "VV7TUt"    : FFdDg8(self, self.VV7TUt)
   elif item == "VVpeJF"   : FFdDg8(self, self.VVpeJF)
   elif item == "VV9s5b"  : self.VV9s5b()
   elif item == "VVXKig"  : FFT4Vd(self, boundFunction(FFdDg8, self, self.VVXKig ), "Copy from existing Sat. Channel" )
   elif item == "VVSofN" : FFT4Vd(self, boundFunction(FFdDg8, self, self.VVSofN ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVGwLj_all" : FFT4Vd(self, boundFunction(FFdDg8, self, self.VVGwLj  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VV6u7c"   : FFdDg8(self, boundFunction(self.VVIpFL, 1), title="Searching ...")
   elif item == "VVWN9P" : self.VVWN9P()
   elif item == "VVTaec" : FFdDg8(self, boundFunction(self.VVIpFL, 2), title="Searching ...")
   elif item == "VVxZnS" : FFdDg8(self, boundFunction(self.VV2PJe, False), title="Searching ...")
   elif item == "VV1XTa"   : FFdDg8(self, boundFunction(CCVkVQ.VV1XTa, self))
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVnBXm(item)
 def VVJM0q(self, mode):
  VVEl38 = self.VVKlSg(mode)
  if VVEl38:
   VVB3WF = ("Current Service", self.VVEwLk    , [])
   VVRYtq = ("Options"  , self.VV2mKr      , [])
   VVn2KW = ("Filter"   , self.VVIY2L       , [])
   VVR5hp  = ("Play"   , boundFunction(self.VVOuA2, False) , [])
   VVkGsu = (""    , self.VV5PGn       , [])
   VV0KAt = (""    , self.VVErGh        , [])
   VVFJFw = (""    , self.VVDYHw       , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVenpJ  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFrMdi(self, None, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26
     , VVR5hp=VVR5hp, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVn2KW=VVn2KW, VVkGsu=VVkGsu, VV0KAt=VV0KAt
     , VVHOIE="#0a00292B", VVsOU8="#0a002126", VVauqk="#0a002126", VVMVsE="#00000000", VVWA0Q=True, searchCol=1)
  else:
   if mode == self.VVvfjS: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFdx4k(self, err)
 def VVErGh(self, VV8kdg, title, txt, colList):
  self.VV8kdg = VV8kdg
 def VVDYHw(self, VV8kdg):
  self.VV8kdg = None
 def VV2mKr(self, VV8kdg, title, txt, colList):
  VVhjJY= self.VVEFTw()
  FFmvQ5(self, self.VVnBXm, title="IPTV Tools", VVhjJY=VVhjJY)
 def VVIY2L(self, VV8kdg, title, txt, colList):
  VVhjJY = []
  VVhjJY.append(("All"         , "all"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Prefix of Selected Channel"   , "sameName" ))
  VVhjJY.append(("Suggest Words from Selected Channel" , "partName" ))
  VVhjJY.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Live TV"        , "live"  ))
  VVhjJY.append(("VOD"         , "vod"   ))
  VVhjJY.append(("Series"        , "series"  ))
  VVhjJY.append(("Uncategorised"      , "uncat"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Video"        , "video"  ))
  VVhjJY.append(("Audio"        , "audio"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("MKV"         , "MKV"   ))
  VVhjJY.append(("MP4"         , "MP4"   ))
  VVhjJY.append(("MP3"         , "MP3"   ))
  VVhjJY.append(("AVI"         , "AVI"   ))
  VVhjJY.append(("FLV"         , "FLV"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVrHnO()
  if bNames:
   bNames.sort()
   VVhjJY.append(VVeSPq)
   for item in bNames:
    VVhjJY.append((item, "__b__" + item))
  filterObj = CCwKtp(self)
  filterObj.VVKw38(VVhjJY, VVhjJY, boundFunction(self.VVckcr, VV8kdg))
 def VVckcr(self, VV8kdg, item=None):
  prefix = VV8kdg.VVJPyb(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVSaOJ, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVgLvo , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVXaVP , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVjDl6 , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVvfjS  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV5DFD   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVzGpG  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVSTpe  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVb1Nc  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVeMd1  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV8mls   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVBEb0   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVwpSg   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVmTjg   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVBvW6   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVQMdJ  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVhp2Q  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVgF4n  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVXaVP:
   VVhjJY = []
   chName = VV8kdg.VVJPyb(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVhjJY.append((item, item))
    if not VVhjJY and chName:
     VVhjJY.append((chName, chName))
    FFmvQ5(self, boundFunction(self.VVoacC_partOfName, title), title="Words from Current Selection", VVhjJY=VVhjJY)
   else:
    VV8kdg.VVhdSv("Invalid Channel Name")
  else:
   words, asPrefix = CCwKtp.VVlIIO(words)
   if not words and mode in (self.VVhp2Q, self.VVgF4n):
    FFbo0g(self.VV8kdg, "Incorrect filter", 2000)
   else:
    FFdDg8(self.VV8kdg, boundFunction(self.VVqujY, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVoacC_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFdDg8(self.VV8kdg, boundFunction(self.VVqujY, self.VVXaVP, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVt2GJ(txt):
  return "#f#11ffff00#" + txt
 def VVqujY(self, mode, words, asPrefix, title):
  VVEl38 = self.VVKlSg(mode=mode, words=words, asPrefix=asPrefix)
  if VVEl38 : self.VV8kdg.VVmRNB(VVEl38, title)
  else  : self.VV8kdg.VVhdSv("Not found")
 def VVKlSg(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVEl38 = []
  files  = self.VVrueM()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFtCkf(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVb0FY = span.group(1)
    else : VVb0FY = ""
    VVb0FY_lCase = VVb0FY.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVfaHx(chName): chNameMod = self.VVt2GJ(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVb0FY, chType, refCode, url)
     ok = False
     tUrl = FFDQFE(url).lower()
     if mode == self.VVSaOJ       : ok = True
     elif mode == self.VVQMdJ       : ok = True
     elif mode == self.VVb1Nc:
      if CCRT5i.VV8xGu(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVeMd1:
      if CCRT5i.VV8xGu(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVvfjS:
      if CCRT5i.VV8xGu(tUrl, compareType="live")  : ok = True
     elif mode == self.VV5DFD:
      if CCRT5i.VV8xGu(tUrl, compareType="movie") : ok = True
     elif mode == self.VVzGpG:
      if CCRT5i.VV8xGu(tUrl, compareType="series") : ok = True
     elif mode == self.VVSTpe:
      if CCRT5i.VV8xGu(tUrl, compareType="")   : ok = True
     elif mode == self.VV8mls:
      if CCRT5i.VV8xGu(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVBEb0:
      if CCRT5i.VV8xGu(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVwpSg:
      if CCRT5i.VV8xGu(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVmTjg:
      if CCRT5i.VV8xGu(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVBvW6:
      if CCRT5i.VV8xGu(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVgLvo:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVXaVP:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVjDl6:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVhp2Q:
      if words[0] == VVb0FY_lCase:
       ok = True
     elif mode == self.VVgF4n:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVEl38.append(row)
      chNum += 1
  if VVEl38 and mode == self.VVQMdJ:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVEl38)
   for item in VVEl38:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVEl38 = newRows
  return VVEl38
 def VV3khv(self, bName):
  if bName:
   FFdDg8(self.VV8kdg, boundFunction(self.VVdFsb, bName), title="Adding Channels ...")
 def VVdFsb(self, bName):
  num = 0
  path = VVBjVb + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVBjVb + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VV8kdg.VVGUJf():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFdqBS(row[1]))
    totChange += 1
  FFADrf(os.path.basename(path))
  self.VVgjI1(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV9s5b(self):
  txt = "Stream Type "
  VVhjJY = []
  VVhjJY.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVhjJY.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVhjJY.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVhjJY.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVhjJY.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVhjJY.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFmvQ5(self, self.VVHImO, title="Change Reference Types to:", VVhjJY=VVhjJY)
 def VVHImO(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVght7("1"   )
   elif item == "RT_4097" : self.VVght7("4097")
   elif item == "RT_5001" : self.VVght7("5001")
   elif item == "RT_5002" : self.VVght7("5002")
   elif item == "RT_8192" : self.VVght7("8192")
   elif item == "RT_8193" : self.VVght7("8193")
 def VVght7(self, rType):
  FFT4Vd(self, boundFunction(FFdDg8, self, boundFunction(self.VVTDZn, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVTDZn(self, refType):
  totChange = 0
  files  = self.VVrueM()
  if files:
   for path in files:
    txt = FFtCkf(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFADrf(os.path.basename(path))
  self.VVgjI1(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVoeCo(self):
  totFiles = 0
  files  = self.VVrueM()
  if files:
   totFiles = len(files)
  totChans = 0
  VVEl38 = self.VVKlSg()
  if VVEl38:
   totChans = len(VVEl38)
  FFh3cd(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV7TUt(self):
  files  = self.VVrueM()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFtCkf(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVaENg
   else    : color = VVP2je
   totInvalid = FF34IZ(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF34IZ("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFh3cd(self, txt, title="Check IPTV References")
 def VVpeJF(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVBjVb + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFADrf(os.path.basename(path))
  FF28nO()
  acceptedList = []
  VVaFS7 = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVaFS7:
   VVXiMh = FF8JSw(VVaFS7)
   if VVXiMh:
    for service in VVXiMh:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVBjVb + userBName
  bFile = VVBjVb + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FF0t1y("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FF0t1y("rm -f '%s'" % path)
  os.system(cmd)
  FF28nO()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVaENg
    else     : res, color = "No" , VVP2je
    txt += "    %s\t: %s\n" % (item, FF34IZ(res, color))
   FFh3cd(self, txt, title=title)
  else:
   txt = FFdx4k(self, "Could not complete the test on your system!", title=title)
 def VVXKig(self):
  lameDbChans = CCVkVQ.VVheOM(self, CCVkVQ.VVQJHa)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVrueM():
    toSave = False
    txt = FFtCkf(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVgjI1(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFdx4k(self, 'No channels in "lamedb" !')
 def VVSofN(self):
  files  = self.VVrueM()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFPPAc(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVTlpP(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVgjI1(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVNVgr(self):
  iptvRefList = []
  files  = self.VVrueM()
  if files:
   for path in files:
    txt = FFtCkf(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VV8kdg.VV28sP(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVTlpP(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVrueM()
  if files:
   for path in files:
    lines = FFPPAc(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVgjI1(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVTlpP(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVGwLj(self):
  list = None
  if self.VV8kdg:
   list = []
   for row in self.VV8kdg.VVGUJf():
    list.append(row[4] + row[5])
  files  = self.VVrueM()
  totChange = 0
  if files:
   for path in files:
    lines = FFPPAc(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVgjI1(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVgjI1(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF28nO()
   if refreshTable and self.VV8kdg:
    VVEl38 = self.VVKlSg()
    if VVEl38 and self.VV8kdg:
     self.VV8kdg.VVmRNB(VVEl38, self.tableTitle)
     self.VV8kdg.VVhdSv(txt)
   FFh3cd(self, txt, title=title)
  else:
   FFUbus(self, "No changes.")
 def VVrHnO(self):
  files = self.VVrueM()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VV6Fad = FFeUK9()
    if VV6Fad:
     for b in VV6Fad:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVrueM(self):
  return CCRT5i.VV21QT(self)
 @staticmethod
 def VV21QT(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVBjVb + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFtCkf(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV5PGn(self, VV8kdg, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFDQFE(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FF9kJ8(self, fncMode=CCS14C.VV6FeV, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVOuA2(self, fromPlayer, VV8kdg, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVn333(fromPlayer, VV8kdg, chName, chUrl, "localIptv")
 def VVt8hk(self, mode, fromPlayer, VV8kdg, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVvxiz(mode, colList)
  self.VVn333(fromPlayer, VV8kdg, chName, chUrl, mode)
 def VVn333(self, fromPlayer, VV8kdg, chName, chUrl, playerFlag):
  chName = FFdqBS(chName)
  if fromPlayer:
   self.VVluIl(VV8kdg, chUrl, playerFlag)
  elif self.VVfaHx(chName):
   FFbo0g(VV8kdg, "This is a marker!", 300)
  else:
   FFdDg8(VV8kdg, boundFunction(self.VVluIl, VV8kdg, chUrl, playerFlag), title="Playing ...")
 def VVluIl(self, VV8kdg, chUrl, playerFlag):
  FF4ffD(self, chUrl, VVXA27=False)
  self.session.open(CClGFA, portalTableParam=(self, VV8kdg, playerFlag))
 @staticmethod
 def VVfaHx(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVEwLk(self, VV8kdg, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  if refCode:
   bName = FFToW0()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFvoWy(refCode, origUrl, chName) }
   VV8kdg.VVwBkd_partial(colDict, VVpwCo=True)
 def VVWN9P(self):
  self.session.open(CCZMP9)
  self.close()
 def VVIpFL(self, m3uMode):
  lines = FFHErt("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFF164(1))
  if lines:
   lines.sort()
   VVhjJY = []
   for line in lines:
    VVhjJY.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVKkqL = ("All to Playlist", self.VVPZ9W)
   else    : VVKkqL = None
   OKBtnFnc = boundFunction(self.VVOds5, m3uMode, title)
   VVbBdV = ("Show Full Path", self.VVEios)
   FFmvQ5(self, None, title=title, VVhjJY=VVhjJY, OKBtnFnc=OKBtnFnc, VVbBdV=VVbBdV, VVKkqL=VVKkqL)
  else:
   FFdx4k(self, 'No "m3u" files found.')
 def VVEios(self, VVdAc1Obj, url):
  FFh3cd(self, url, title="Full Path")
 def VVOds5(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFdDg8(menuInstance, boundFunction(self.VVrMcB, title, path))
   elif m3uMode == 1 : self.VV6u7c(title, path)
   else    : self.VVMgWm(menuInstance, path)
 def VVPZ9W(self, VVdAc1Obj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVdAc1Obj.VVhjJY):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VV9MWi(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    pListF = "%sPlaylist_%s.txt" % (FFoGIr(CFG.exportedTablesPath.getValue()), FFmJh3())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVdAc1Obj.VVhjJY)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFh3cd(self, txt, title=title)
   else:
    FFdx4k(self, "Could not obtain URLs from this file list !", title=title)
 def VV6u7c(self, title, path):
  if fileExists(path):
   self.session.open(CCxrdg, barTheme=CCxrdg.VV6xsn
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VViRvY, path)
       , VVHVqi = boundFunction(self.VVo3c2, title, path))
  else:
   FFdx4k(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVo3c2(self, title, path, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  if VVV9Ca:
   FFh3cd(self, VVF8YZ, title=title)
 def VViRvY(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FFtCkf(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVF8YZ = ""
  progBarObj.VVgcp1(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVPQ4V(1, True)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FFDQFE(tUrl).lower()
   chType, host, username, password, streamId, chName = CCRT5i.VV8xGu(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCRT5i.VV8xGu(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FF34IZ("File:\n", VVmWy8)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FF34IZ("Channels:\n", VVmWy8)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FF34IZ("Category:\n", VVmWy8)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FF34IZ("Content:\n", VVmWy8)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    No channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VVF8YZ = txt
 def VV2PJe(self, isBrowseServer):
  lines = FFHErt('find / %s -iname "*playlist*" | grep -i ".txt"' % FFF164(1))
  if lines:
   lines.sort()
   VVhjJY = []
   for line in lines:
    VVhjJY.append((line, line))
   OKBtnFnc = boundFunction(self.VVv5Ln, isBrowseServer)
   FFmvQ5(self, None, title="Select Playlist File", VVhjJY=VVhjJY, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FF5BoZ(self, "( playlist.txt  or  playlists.txt )")
 def VVv5Ln(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFdDg8(menuInstance, boundFunction(self.VVIwYd, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVIwYd(self, fileMenuInstance, path, isBrowseServer):
  VVhjJY = []
  lines = FFPPAc(path)
  for line in lines:
   line = line.strip()
   span = iSearch(r"(http.+php.+username=.+password=.+)(?:[&]+)*", line, IGNORECASE)
   if span:
    VVhjJY.append((span.group(1), span.group(1)))
   else:
    span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
    if span:
     host = FFoGIr(span.group(1).strip())
     user1 = span.group(2).strip()
     pass1 = span.group(3).strip()
     line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
     VVhjJY.append((line, line))
  if VVhjJY:
   if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVhjJY)
   else    : title = "Convert to Bouquet"
   OKBtnFnc  = boundFunction(self.VVTGgM, isBrowseServer, title)
   VVvGoO  = ("Home Menu"  , FFmCer)
   VVbBdV  = ("Show URL"  , self.VVWdg8)
   VVKkqL   = ("Check & Filter" , boundFunction(self.VVD1Zq, fileMenuInstance, path, isBrowseServer))
   FFmvQ5(self, None, title=title, VVhjJY=VVhjJY, width=1200, OKBtnFnc=OKBtnFnc, VVvGoO=VVvGoO, VVbBdV=VVbBdV, VVKkqL=VVKkqL)
  else:
   FFdx4k(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVWdg8(self, VVdAc1Obj, url):
  FFh3cd(self, url, title="URL")
 def VVTGgM(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFdDg8(menuInstance, boundFunction(self.VVB7Wb, title, url), title="Checking Server ...")
   else:
    FFT4Vd(self, boundFunction(FFdDg8, menuInstance, boundFunction(self.VVO5Vb, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVO5Vb(self, menuInstance, url):
  path, err = FFgxGp(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFdx4k(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFtCkf(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFdx4k(self, "Unauthorized", title=title)
     os.system(FF0t1y("rm -f '%s'" % path))
     return
   self.VVMgWm(menuInstance, path)
 def VVVExD(self, title):
  curChName = self.VV8kdg.VVJPyb(1)
  FFktKm(self, boundFunction(self.VVOV0h, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVOV0h(self, title, name):
  if name:
   lameDbChans = CCVkVQ.VVheOM(self, CCVkVQ.VVcfvB, VVUIx4=False, VVQoiw=False)
   list = []
   if lameDbChans:
    processChanName = CCkHXi()
    name = processChanName.VVmyko(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFGAsY(item[2]), item[3], ratio))
   if list : self.VVHeqs(list, title)
   else : FFdx4k(self, "Not found:\n\n%s" % name, title=title)
 def VVE3zW(self, title):
  curChName = self.VV8kdg.VVJPyb(1)
  self.session.open(CCxrdg, barTheme=CCxrdg.VV6xsn
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVH8sF
      , VVHVqi = boundFunction(self.VVGA6d, title, curChName))
 def VVH8sF(self, progBarObj):
  curChName = self.VV8kdg.VVJPyb(1)
  lameDbChans = CCVkVQ.VVheOM(self, CCVkVQ.VVYyfD, VVUIx4=False, VVQoiw=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVF8YZ = []
  progBarObj.VVgcp1(len(lameDbChans))
  processChanName = CCkHXi()
  curCh = processChanName.VVmyko(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCBIQf.VVtqzP(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVPQ4V(1, True)
   if ratio > 50:
    progBarObj.VVF8YZ.append((chName, FFGAsY(sat), refCode.replace("_", ":"), str(ratio)))
 def VVGA6d(self, title, curChName, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  if VVV9Ca:
   if VVF8YZ : self.VVHeqs(VVF8YZ, title)
   else   : FFdx4k(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVHeqs(self, VVEl38, title):
  curChName = self.VV8kdg.VVJPyb(1)
  curRefCode = self.VV8kdg.VVJPyb(4)
  curUrl  = self.VV8kdg.VVJPyb(5)
  VVEl38 = sorted(VVEl38, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVR5hp  = ("Share Sat/C/T Ref.", boundFunction(self.VVbDcg, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFrMdi(self, None, title=title, header=header, VV8klC=VVEl38, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVHOIE="#0a00112B", VVsOU8="#0a001126", VVauqk="#0a001126", VVMVsE="#00000000")
 def VVbDcg(self, newtitle, curChName, curRefCode, curUrl, VV8kdg, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFT4Vd(self.VV8kdg, boundFunction(FFdDg8, self.VV8kdg, boundFunction(self.VVy33a, VV8kdg, data)), ques, title=newtitle, VVUw2L=True)
 def VVy33a(self, VV8kdg, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVrueM():
    txt = FFtCkf(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FF28nO()
    newRow = []
    for i in range(6):
     newRow.append(self.VV8kdg.VVJPyb(i))
    newRow[4] = newRefCode
    done = self.VV8kdg.VVRKTL(newRow)
    FFUbus(self, "Done", title=title)
   else:
    FFdx4k(self, "Not found in IPTV files !", title=title)
  else:
   FFdx4k(self, "Could not read channel info !", title=title)
  VV8kdg.cancel()
 def VVD1Zq(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, item):
  self.session.open(CCxrdg, barTheme=CCxrdg.VV6xsn
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VV9xmJ, urlMenuInstance)
      , VVHVqi = boundFunction(self.VVHRn4, fileMenuInstance, path, isBrowseServer, urlMenuInstance))
 def VV9xmJ(self, urlMenuInstance, progBarObj):
  progBarObj.VVgcp1(len(urlMenuInstance.VVhjJY))
  progBarObj.VVF8YZ = []
  for ndx, item in enumerate(urlMenuInstance.VVhjJY):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVPQ4V(1, True)
   qUrl = self.VVFZXw(self.VV0ywR, item[0])
   txt, err = self.VV8uYD(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVZuWD(item, "auth") == "0":
       progBarObj.VVF8YZ.append(qUrl)
    except:
     pass
 def VVHRn4(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  if VVV9Ca:
   list = VVF8YZ
   title = "Authorized Servers"
   if list:
    totChk = len(urlMenuInstance.VVhjJY)
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFmJh3()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV2PJe(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF34IZ(str(totAuth), VVaENg)
     txt += "%s\n\n%s"     %  (FF34IZ("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFh3cd(self, txt, title=title)
     urlMenuInstance.close()
     fileMenuInstance.close()
    else:
     FFUbus(self, "All URLs are authorized.", title=title)
   else:
    FFdx4k(self, "No authorized URL found !", title=title)
 def VVMgWm(self, parentInstant, path):
  files = CCRT5i.VV21QT(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCRT5i.VVNxWg(parentInstant, path, exitCurWin)
 @staticmethod
 def VVNxWg(SELF, path, exitCurWin):
  FFT4Vd(SELF, boundFunction(FFdDg8, SELF, boundFunction(CCRT5i.VVYe3S, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVYe3S(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFdx4k(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCRT5i.VVzVND(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVBjVb + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVBjVb + bFileName):
     bName = tmpBName
     break
  txt = FFtCkf(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVBjVb + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFbKZa(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFADrf(bFileName)
   FF28nO()
   FFUbus(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFdx4k(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VV8uYD(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVgpAh(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV8xGu(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVFZXw(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVgpAh(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV0ywR   : return "%s"            % url
  elif mode == self.VVuNKO   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVOcOA   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVv0UV  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVWOAy : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVijuV   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVWIYs    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV1sZp  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVRjie  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVOvWE  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VV8TMU : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVQVem   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVZuWD(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFCnzX(int(val))
    elif is_base64 : val = FFScix(val)
    elif isToHHMMSS : val = FF4dJc(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVrMcB(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VV9MWi(line)
     if qUrl:
      break
   if qUrl : self.VVB7Wb(title, qUrl)
   else : FFdx4k(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFdx4k(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVwUI7_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVZ4di()
  if qUrl:
   host, mac, isPortalUrl = self.VV4Irp(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVwUI7(self, host, mac)
    else   : FFdx4k(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFdDg8(self, boundFunction(self.VVB7Wb, title, qUrl), title="Checking Server ...")
  else:
   FFdx4k(self, "Error in current channel URL !", title=title)
 def VVZ4di(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  qUrl = self.VV9MWi(decodedUrl)
  return qUrl, iptvRef
 def VV9MWi(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVB7Wb(self, title, url):
  self.VVNKFTData = {}
  qUrl = self.VVFZXw(self.VV0ywR, url)
  txt, err = self.VV8uYD(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVNKFTData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVNKFTData["username"    ] = self.VVZuWD(item, "username"        )
    self.VVNKFTData["password"    ] = self.VVZuWD(item, "password"        )
    self.VVNKFTData["message"    ] = self.VVZuWD(item, "message"        )
    self.VVNKFTData["auth"     ] = self.VVZuWD(item, "auth"         )
    self.VVNKFTData["status"    ] = self.VVZuWD(item, "status"        )
    self.VVNKFTData["exp_date"    ] = self.VVZuWD(item, "exp_date"    , isDate=True )
    self.VVNKFTData["is_trial"    ] = self.VVZuWD(item, "is_trial"        )
    self.VVNKFTData["active_cons"   ] = self.VVZuWD(item, "active_cons"       )
    self.VVNKFTData["created_at"   ] = self.VVZuWD(item, "created_at"   , isDate=True )
    self.VVNKFTData["max_connections"  ] = self.VVZuWD(item, "max_connections"      )
    self.VVNKFTData["allowed_output_formats"] = self.VVZuWD(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVNKFTData[key] = lst
    item = tDict["server_info"]
    self.VVNKFTData["url"    ] = self.VVZuWD(item, "url"        )
    self.VVNKFTData["port"    ] = self.VVZuWD(item, "port"        )
    self.VVNKFTData["https_port"  ] = self.VVZuWD(item, "https_port"      )
    self.VVNKFTData["server_protocol" ] = self.VVZuWD(item, "server_protocol"     )
    self.VVNKFTData["rtmp_port"   ] = self.VVZuWD(item, "rtmp_port"       )
    self.VVNKFTData["timezone"   ] = self.VVZuWD(item, "timezone"       )
    self.VVNKFTData["timestamp_now"  ] = self.VVZuWD(item, "timestamp_now"  , isDate=True )
    self.VVNKFTData["time_now"   ] = self.VVZuWD(item, "time_now"       )
    VVhjJY  = self.VV60RG()
    OKBtnFnc = self.VVNKFTOptions
    VVvGoO = ("Home Menu", FFmCer)
    FFmvQ5(self, None, title="IPTV Server Resources", VVhjJY=VVhjJY, OKBtnFnc=OKBtnFnc, VVvGoO=VVvGoO)
   else:
    err = "Could not get data from server !"
  if err:
   FFdx4k(self, err, title=title)
  FFbo0g(self)
 def VVNKFTOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFdDg8(menuInstance, boundFunction(self.VVVFER, self.VVuNKO , title=title), title=wTxt)
   elif ref == "vod"   : FFdDg8(menuInstance, boundFunction(self.VVVFER, self.VVOcOA , title=title), title=wTxt)
   elif ref == "series"  : FFdDg8(menuInstance, boundFunction(self.VVVFER, self.VVv0UV, title=title), title=wTxt)
   elif ref == "accountInfo" : FFdDg8(menuInstance, boundFunction(self.VVAPDK          , title=title), title=wTxt)
 def VVAPDK(self, title):
  rows = []
  for key, val in self.VVNKFTData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VV6Yzq = ("Home Menu", FFmCer, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFrMdi(self, None, title=title, width=1200, header=header, VV8klC=rows, VVxJaI=widths, VVhj1e=26, VV6Yzq=VV6Yzq, VVHOIE="#0a00292B", VVsOU8="#0a002126", VVauqk="#0a002126", VVMVsE="#00000000", searchCol=2)
 def VV3l7h(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCkHXi()
    if mode == self.VVijuV:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVZuWD(item, "num"         )
      name     = self.VVZuWD(item, "name"        )
      stream_id    = self.VVZuWD(item, "stream_id"       )
      stream_icon    = self.VVZuWD(item, "stream_icon"       )
      epg_channel_id   = self.VVZuWD(item, "epg_channel_id"      )
      added     = self.VVZuWD(item, "added"    , isDate=True )
      is_adult    = self.VVZuWD(item, "is_adult"       )
      category_id    = self.VVZuWD(item, "category_id"       )
      name = processChanName.VVSF4f(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVWIYs:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVZuWD(item, "num"         )
      name    = self.VVZuWD(item, "name"        )
      stream_id   = self.VVZuWD(item, "stream_id"       )
      stream_icon   = self.VVZuWD(item, "stream_icon"       )
      added    = self.VVZuWD(item, "added"    , isDate=True )
      is_adult   = self.VVZuWD(item, "is_adult"       )
      category_id   = self.VVZuWD(item, "category_id"       )
      container_extension = self.VVZuWD(item, "container_extension"     ) or "mp4"
      name = processChanName.VVSF4f(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VV1sZp:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVZuWD(item, "num"        )
      name    = self.VVZuWD(item, "name"       )
      series_id   = self.VVZuWD(item, "series_id"      )
      cover    = self.VVZuWD(item, "cover"       )
      genre    = self.VVZuWD(item, "genre"       )
      episode_run_time = self.VVZuWD(item, "episode_run_time"    )
      category_id   = self.VVZuWD(item, "category_id"      )
      container_extension = self.VVZuWD(item, "container_extension"    ) or "mp4"
      name = processChanName.VVSF4f(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVVFER(self, mode, title):
  qUrl = self.VVFZXw(mode, self.VVNKFTData["playListURL"])
  txt, err = self.VV8uYD(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    hideAdult = CFG.hideIptvServerAdultWords.getValue()
    tDict = jLoads(txt)
    if tDict:
     processChanName = CCkHXi()
     for item in tDict:
      category_id  = self.VVZuWD(item, "category_id"  )
      category_name = self.VVZuWD(item, "category_name" )
      parent_id  = self.VVZuWD(item, "parent_id"  )
      category_name = processChanName.VVAHtB(category_name)
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   err = "Server Error:\n\n" + err
  if err:
   FFdx4k(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x(mode)
   mName = self.VVlO8L(mode)
   if   mode == self.VVuNKO  : fMode = self.VVijuV
   elif mode == self.VVOcOA  : fMode = self.VVWIYs
   elif mode == self.VVv0UV : fMode = self.VV1sZp
   VVRYtq = ("Find in %s" % mName , boundFunction(self.VVyte0, fMode) , [])
   VVR5hp  = ("Show List"   , boundFunction(self.VVM4ne, mode) , [])
   VV6Yzq = ("Home Menu"   , FFmCer          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFrMdi(self, None, title=title, width=1200, header=header, VV8klC=list, VVxJaI=widths, VVhj1e=30, VV6Yzq=VV6Yzq, VVRYtq=VVRYtq, VVR5hp=VVR5hp, VVHOIE=VVHOIE, VVsOU8=VVsOU8, VVauqk=VVauqk, VVMVsE=VVMVsE)
  else:
   FFdx4k(self, "No list from server !", title=title)
  FFbo0g(self)
 def VVM4ne(self, mode, VV8kdg, title, txt, colList):
  title = colList[1]
  FFdDg8(VV8kdg, boundFunction(self.VVCdcq, mode, VV8kdg, title, txt, colList), title="Downloading ...")
 def VVCdcq(self, mode, VV8kdg, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVlO8L(mode) + " : "+ bName
  if   mode == self.VVuNKO  : mode = self.VVijuV
  elif mode == self.VVOcOA  : mode = self.VVWIYs
  elif mode == self.VVv0UV : mode = self.VV1sZp
  qUrl  = self.VVFZXw(mode, self.VVNKFTData["playListURL"], catID)
  txt, err = self.VV8uYD(qUrl)
  list  = []
  if not err and mode in (self.VVijuV, self.VVWIYs, self.VV1sZp):
   list, err = self.VV3l7h(mode, txt)
  if err:
   FFdx4k(self, err, title=title)
  elif list:
   VV6Yzq  = ("Home Menu"   , FFmCer            , [])
   if mode == self.VVijuV:
    VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x(mode)
    VVR5hp  = ("Play"    , boundFunction(self.VVt8hk, mode, False)  , [])
    VVkGsu = (""     , boundFunction(self.VVFoZY, mode)    , [])
    VVB3WF = ("Download PIcons" , boundFunction(self.VVuxZQ, mode)    , [])
    VVRYtq = ("Add ALL to Bouquet" , boundFunction(self.VVI3La, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVenpJ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVWIYs:
    VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x(mode)
    VVR5hp  = ("Play"    , boundFunction(self.VVt8hk, mode, False)  , [])
    VVkGsu = (""     , boundFunction(self.VVFoZY, mode)    , [])
    VVB3WF = ("Download PIcons" , boundFunction(self.VVuxZQ, mode)    , [])
    VVRYtq = ("Add ALL to Bouquet" , boundFunction(self.VVI3La, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVenpJ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VV1sZp:
    VVHOIE, VVsOU8, VVauqk, VVMVsE = self.VVEn1x("series2")
    VVR5hp  = ("Show Seasons", boundFunction(self.VVSeKF, mode) , [])
    VVkGsu = ("", boundFunction(self.VVIOAn, mode)  , [])
    VVB3WF = None
    VVRYtq = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVenpJ  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFrMdi(self, None, title=title, header=header, VV8klC=list, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVkGsu=VVkGsu, VVHOIE=VVHOIE, VVsOU8=VVsOU8, VVauqk=VVauqk, VVMVsE=VVMVsE, VVWA0Q=True, searchCol=1)
  else:
   FFdx4k(self, "No Channels found !", title=title)
  FFbo0g(self)
 def VVSeKF(self, mode, VV8kdg, title, txt, colList):
  title = colList[1]
  FFdDg8(VV8kdg, boundFunction(self.VVh2Vk, mode, VV8kdg, title, txt, colList), title="Downloading ...")
 def VVh2Vk(self, mode, VV8kdg, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVFZXw(self.VVWOAy, self.VVNKFTData["playListURL"], series_id)
  txt, err = self.VV8uYD(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVZuWD(tDict["info"], "name"   )
      category_id = self.VVZuWD(tDict["info"], "category_id" )
      icon  = self.VVZuWD(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVZuWD(EP, "id"     )
        episode_num   = self.VVZuWD(EP, "episode_num"   )
        epTitle    = self.VVZuWD(EP, "title"     )
        container_extension = self.VVZuWD(EP, "container_extension" )
        seasonNum   = self.VVZuWD(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFdx4k(self, err, title=title)
  elif list:
   VV6Yzq = ("Home Menu"   , FFmCer            , [])
   VVB3WF = ("Download PIcons" , boundFunction(self.VVuxZQ , mode)   , [])
   VVRYtq = ("Add ALL to Bouquet" , boundFunction(self.VVI3La, mode, title) , [])
   VVkGsu = (""     , boundFunction(self.VVFoZY, mode)    , [])
   VVR5hp  = ("Play"    , boundFunction(self.VVt8hk, mode, False)  , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVenpJ  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFrMdi(self, None, title=title, header=header, VV8klC=list, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVR5hp=VVR5hp, VVkGsu=VVkGsu, VVRYtq=VVRYtq, VVHOIE="#0a00292B", VVsOU8="#0a002126", VVauqk="#0a002126", VVMVsE="#00000000")
  else:
   FFdx4k(self, "No Channels found !", title=title)
  FFbo0g(self)
 def VVyte0(self, mode, VV8kdg, title, txt, colList):
  VVhjJY = []
  VVhjJY.append(("Keyboard"  , "manualEntry"))
  VVhjJY.append(("From Filter" , "fromFilter"))
  FFmvQ5(self, boundFunction(self.VVRmJW, VV8kdg, mode), title="Input Type", VVhjJY=VVhjJY, width=400)
 def VVRmJW(self, VV8kdg, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFktKm(self, boundFunction(self.VVMMqV, VV8kdg, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCwKtp(self)
    filterObj.VVJk9C(boundFunction(self.VVMMqV, VV8kdg, mode))
 def VVMMqV(self, VV8kdg, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCkHXi()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVFLsW(words):
     FFdx4k(self, processChanName.VVYm0I(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCxrdg, barTheme=CCxrdg.VV6xsn
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVs9Cg, VV8kdg, mode, title, words, toFind, asPrefix, processChanName)
         , VVHVqi = boundFunction(self.VVQuvC, mode, toFind, title))
   else:
    FFdx4k(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVs9Cg(self, VV8kdg, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVgcp1(VV8kdg.VVQFOb())
  progBarObj.VVF8YZ = []
  for row in VV8kdg.VVGUJf():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVPQ4V(1)
   progBarObj.VVB2Vz_fromIptvFind(catName)
   qUrl  = self.VVFZXw(mode, self.VVNKFTData["playListURL"], catID)
   txt, err = self.VV8uYD(qUrl)
   if not err:
    tList, err = self.VV3l7h(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVSF4f(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVijuV:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVF8YZ.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVWIYs:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVF8YZ.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VV1sZp:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVF8YZ.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVQuvC(self, mode, toFind, title, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  if VVF8YZ:
   title = self.VVlTff(mode, toFind)
   if mode == self.VVijuV or mode == self.VVWIYs:
    bName   = CCRT5i.VVzVND(toFind)
    VVR5hp  = ("Play"     , boundFunction(self.VVt8hk, mode, False)  , [])
    VVRYtq = ("Add ALL to Bouquet" , boundFunction(self.VVI3La, mode, bName) , [])
    VVB3WF = ("Download PIcons" , boundFunction(self.VVuxZQ, mode)    , [])
   elif mode == self.VV1sZp:
    VVR5hp  = ("Show Seasons"  , boundFunction(self.VVSeKF, mode)    , [])
    VVRYtq = None
    VVB3WF = None
   VVkGsu = (""   , boundFunction(self.VVFoZY, mode) , [])
   VV6Yzq = ("Home Menu" , FFmCer         , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVenpJ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VV8kdg = FFrMdi(self, None, title=title, header=header, VV8klC=VVF8YZ, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVkGsu=VVkGsu, VVHOIE="#0a00292B", VVsOU8="#0a002126", VVauqk="#0a002126", VVMVsE="#00000000", VVWA0Q=True, searchCol=1)
   if not VVV9Ca:
    FFbo0g(VV8kdg, "Stopped" , 1000)
  else:
   if VVV9Ca:
    FFdx4k(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVvxiz(self, mode, colList):
  if mode == self.VVijuV:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVWIYs:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFdqBS(chName)
  url = self.VVNKFTData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVgpAh(url)
  refCode = self.VVbVnV(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVFoZY(self, mode, VV8kdg, title, txt, colList):
  FFdDg8(VV8kdg, boundFunction(self.VVH1xv, mode, VV8kdg, title, txt, colList))
 def VVH1xv(self, mode, VV8kdg, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVvxiz(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FF9kJ8(self, fncMode=CCS14C.VVcLgJ, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVIOAn(self, mode, VV8kdg, title, txt, colList):
  FFdDg8(VV8kdg, boundFunction(self.VVz4rc, mode, VV8kdg, title, txt, colList))
 def VVz4rc(self, mode, VV8kdg, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FF9kJ8(self, fncMode=CCS14C.VVSj2C, chName=name, text=txt, picUrl=Cover)
 def VVI3La(self, mode, bName, VV8kdg, title, txt, colList):
  FFdDg8(VV8kdg, boundFunction(self.VVVhrI, mode, bName, VV8kdg, title, txt, colList), title="Adding Channels ...")
 def VVVhrI(self, mode, bName, VV8kdg, title, txt, colList):
  url = self.VVNKFTData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVgpAh(url)
  bNameFile = CCRT5i.VVzVND(bName)
  num  = 0
  path = VVBjVb + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVBjVb + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VV8kdg.VVGUJf():
    chName, chUrl, picUrl, refCode = self.VVvxiz(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFADrf(os.path.basename(path))
  self.VVgjI1(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVuxZQ(self, mode, VV8kdg, title, txt, colList):
  if os.system(FF0t1y("which ffmpeg")) == 0:
   self.session.open(CCxrdg, barTheme=CCxrdg.VV8YZ8
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV6Eqc, VV8kdg, mode)
       , VVHVqi = self.VVoACP)
  else:
   FFT4Vd(self, self.VVpeSl, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVoACP(self, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVF8YZ["proces"], VVF8YZ["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVF8YZ["ok"], VVF8YZ["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVF8YZ["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVF8YZ["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVF8YZ["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVF8YZ["path"]
  if not VVV9Ca  : color = "#11402000"
  elif VVF8YZ["err"]: color = "#11201000"
  else     : color = None
  if VVF8YZ["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVF8YZ["err"], txt)
  title = "PIcons Download Result"
  if not VVV9Ca:
   title += "  (cancelled)"
  FFh3cd(self, txt, title=title, VVauqk=color)
 def VV6Eqc(self, VV8kdg, mode, progBarObj):
  totRows = VV8kdg.VVQFOb()
  progBarObj.VVgcp1(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCBIQf.VVS0I8()
  progBarObj.VVF8YZ = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VV8kdg.VVGUJf():
    if progBarObj.isCancelled:
     break
    progBarObj.VVF8YZ["proces"] += 1
    progBarObj.VVPQ4V(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVFPfF(mode, row)
     refCode = CCRT5i.VVbVnV(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVvxiz(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVF8YZ["attempt"] += 1
      path, err = FFgxGp(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVF8YZ["ok"] += 1
       if FF1HLI(path) > 0:
        cmd = ""
        if not mode == CCRT5i.VVijuV:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FF0t1y("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVF8YZ["size0"] += 1
        os.system(FF0t1y("rm -f '%s'" % path))
      elif err:
       progBarObj.VVF8YZ["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVF8YZ["err"] = err.title()
        break
     else:
      progBarObj.VVF8YZ["exist"] += 1
    else:
     progBarObj.VVF8YZ["badURL"] += 1
  except:
   pass
 def VVpeSl(self):
  cmd = FFBSlb(VVSeHH, "ffmpeg")
  if cmd : FFTgBK(self, cmd, title="Installing FFmpeg")
  else : FFHvqH(self)
 @staticmethod
 def VVbVnV(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCRT5i.VVZq73(catID, MAX_4b)
  TSID = CCRT5i.VVZq73(chNum, MAX_4b)
  ONID = CCRT5i.VVZq73(chNum, MAX_4b)
  NS  = CCRT5i.VVZq73(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVZq73(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVzVND(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CCig7L(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVHjCc  = 0
  self.VVOXL9 = 1
  self.VVZdgR  = 2
  VVhjJY = []
  VVhjJY.append(("Find All (from filter)"    , "VVaoVU" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Find All"        , "VVkAzG"    ))
  VVhjJY.append(("Find TV"        , "VVyErS"    ))
  VVhjJY.append(("Find Radio"       , "VVvg1w"   ))
  if self.VVEHvM():
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Hide Channel: %s" % self.servName , "VVDZ77"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Zap History"       , "VV8hGk"    ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("PIcons Tools"       , "PIconsTools"     ))
  VVhjJY.append(("Channels Tools"      , "ChannelsTools"    ))
  FFgoqU(self, VVhjJY=VVhjJY, title=title)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
  if self.isFindMode:
   self.VV3GMC(self.VVpTIn())
 def VVWwkM(self):
  global VVrz5L
  VVrz5L = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVkAzG"    : self.VVkAzG()
   elif item == "VVaoVU" : self.VVaoVU()
   elif item == "VVyErS"    : self.VVyErS()
   elif item == "VVvg1w"   : self.VVvg1w()
   elif item == "VVDZ77"   : self.VVDZ77()
   elif item == "VV8hGk"    : self.VV8hGk()
   elif item == "PIconsTools"     : self.session.open(CCBIQf)
   elif item == "ChannelsTools"    : self.session.open(CCVkVQ)
 def VVyErS(self) : self.VV3GMC(self.VVHjCc)
 def VVvg1w(self) : self.VV3GMC(self.VVOXL9)
 def VVkAzG(self) : self.VV3GMC(self.VVZdgR)
 def VV3GMC(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFktKm(self, boundFunction(self.VVNvYq, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVaoVU(self):
  filterObj = CCwKtp(self)
  filterObj.VVJk9C(self.VVOFhH)
 def VVOFhH(self, item):
  self.VVNvYq(self.VVZdgR, item)
 def VVEHvM(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFgsAM(self.refCode)        : return False
  return True
 def VVNvYq(self, mode, VVagrZ):
  FFdDg8(self, boundFunction(self.VVGTNU, mode, VVagrZ), title="Searching ...")
 def VVGTNU(self, mode, VVagrZ):
  if VVagrZ:
   self.findTxt = VVagrZ
   if   mode == self.VVHjCc  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVOXL9 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVagrZ)
   if len(title) > 55:
    title = title[:55] + ".."
   VVEl38 = self.VV4QCO(VVagrZ, servTypes)
   if self.isFindMode or mode == self.VVZdgR:
    VVEl38 += self.VVZIk1(VVagrZ)
   if VVEl38:
    VVEl38.sort(key=lambda x: x[0].lower())
    VVFJFw = self.VVtBmz
    VVR5hp  = ("Zap"   , self.VVGKY4    , [])
    VVB3WF = ("Current Service", self.VVIIGp , [])
    VVRYtq = ("Options"  , self.VVnRDh , [])
    VVkGsu = (""    , self.VVpyuR , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVenpJ  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFrMdi(self, None, title=title, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVFJFw=VVFJFw, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVkGsu=VVkGsu)
   else:
    self.VV3GMC(self.VVpTIn())
    FFUbus(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV4QCO(self, VVagrZ, servTypes):
  VVSU8l  = eServiceCenter.getInstance()
  VVhlTM   = '%s ORDER BY name' % servTypes
  VVVxBb   = eServiceReference(VVhlTM)
  VVPk4T = VVSU8l.list(VVVxBb)
  if VVPk4T: VV8klC = VVPk4T.getContent("CN", False)
  else     : VV8klC = None
  VVEl38 = []
  if VV8klC:
   VVsyWY, VVWauh = FF3PrL()
   tp   = CCGAc5()
   words, asPrefix = CCwKtp.VVlIIO(VVagrZ)
   colorYellow  = CCGqtk.VVZkkc(VVBlp5)
   colorWhite  = CCGqtk.VVZkkc(VVpw0r)
   for s in VV8klC:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFl7Hp(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVsyWY:
        STYPE = VVWauh[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVBhAc(refCode)
       if not "-S" in syst:
        sat = syst
       VVEl38.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVEl38
 def VVZIk1(self, VVagrZ):
  VVagrZ = VVagrZ.lower()
  VV6Fad = FFeUK9()
  VVEl38 = []
  colorYellow  = CCGqtk.VVZkkc(VVBlp5)
  colorWhite  = CCGqtk.VVZkkc(VVpw0r)
  if VV6Fad:
   for b in VV6Fad:
    VVb0FY  = b[0]
    VVC2dl  = b[1].toString()
    VVaFS7 = eServiceReference(VVC2dl)
    VVXiMh = FF8JSw(VVaFS7)
    for service in VVXiMh:
     refCode  = service[0]
     if FFgsAM(refCode):
      servName = service[1]
      if VVagrZ in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVagrZ), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVEl38.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVEl38
 def VVpTIn(self):
  VV8xAY = InfoBar.instance
  if VV8xAY:
   VVOnZD = VV8xAY.servicelist
   if VVOnZD:
    return VVOnZD.mode == 1
  return self.VVZdgR
 def VVtBmz(self, VV8kdg):
  self.close()
  VV8kdg.cancel()
 def VVGKY4(self, VV8kdg, title, txt, colList):
  FF4ffD(VV8kdg, colList[2], VVXA27=False, checkParentalControl=True)
 def VVIIGp(self, VV8kdg, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(VV8kdg)
  if refCode:
   VV8kdg.VVNoAg(2, FFvoWy(refCode, iptvRef, chName), True)
 def VVnRDh(self, VV8kdg, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCfYM9(self, VV8kdg, 2)
  mSel.VVHnff(servName, refCode)
 def VVpyuR(self, VV8kdg, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FF9kJ8(self, fncMode=CCS14C.VVU8VF, refCode=refCode, chName=chName, text=txt)
 def VVDZ77(self):
  FFT4Vd(self, self.VVUu88, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVUu88(self):
  ret = FFXDAC(self.refCode, True)
  if ret:
   self.VV6hKA()
   self.close()
  else:
   FFbo0g(self, "Cannot change state" , 1000)
 def VV6hKA(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVuVJX()
  except:
   self.VVNy7O()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFUosa(self, serviceRef)
 def VVQAA3(self):
  VV8xAY = InfoBar.instance
  if VV8xAY:
   VVOnZD = VV8xAY.servicelist
   if VVOnZD:
    VVOnZD.setMode()
 def VVuVJX(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV8xAY = InfoBar.instance
   if VV8xAY:
    VVOnZD = VV8xAY.servicelist
    if VVOnZD:
     hList = VVOnZD.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVOnZD.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVOnZD.history  = newList
       VVOnZD.history_pos = pos
 def VVNy7O(self):
  VV8xAY = InfoBar.instance
  if VV8xAY:
   VVOnZD = VV8xAY.servicelist
   if VVOnZD:
    VVOnZD.history  = []
    VVOnZD.history_pos = 0
 def VV8hGk(self):
  VV8xAY = InfoBar.instance
  VVEl38 = []
  if VV8xAY:
   VVOnZD = VV8xAY.servicelist
   if VVOnZD:
    VVsyWY, VVWauh = FF3PrL()
    for chParams in VVOnZD.history:
     refCode = chParams[-1].toString()
     chName = FFPlzC(refCode)
     isIptv = FFgsAM(refCode)
     if isIptv: sat = "-"
     else  : sat = FFl7Hp(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVsyWY:
       STYPE = VVWauh[sTypeInt]
     VVEl38.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVEl38:
   VVR5hp  = ("Zap"   , self.VVIHQd   , [])
   VVRYtq = ("Clear History" , self.VV9xOb   , [])
   VVkGsu = (""    , self.VVzpO6FromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVenpJ  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFrMdi(self, None, title=title, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=28, VVR5hp=VVR5hp, VVRYtq=VVRYtq, VVkGsu=VVkGsu)
  else:
   FFUbus(self, "Not found", title=title)
 def VVIHQd(self, VV8kdg, title, txt, colList):
  FF4ffD(VV8kdg, colList[3], VVXA27=False, checkParentalControl=True)
 def VV9xOb(self, VV8kdg, title, txt, colList):
  FFT4Vd(self, boundFunction(self.VVVlcG, VV8kdg), "Clear Zap History ?")
 def VVVlcG(self, VV8kdg):
  self.VVNy7O()
  VV8kdg.cancel()
 def VVzpO6FromZapHistory(self, VV8kdg, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FF9kJ8(self, fncMode=CCS14C.VVdopo, refCode=refCode, chName=chName, text=txt)
class CCBIQf(Screen):
 VVt5LL   = 0
 VVYklw  = 1
 VVavme  = 2
 VVBTi4  = 3
 VVmonJ  = 4
 VVG8B7  = 5
 VVwqRP  = 6
 VVK4zx  = 7
 VVUl0w = 8
 VV9VCp = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFuMnj(VVEDFg, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFgoqU(self, self.Title)
  FFmNCq(self["keyRed"] , "OK = Zap")
  FFmNCq(self["keyGreen"] , "Current Service")
  FFmNCq(self["keyYellow"], "Page Options")
  FFmNCq(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCBIQf.VVS0I8()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV8klC    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVOk0x        ,
   "green"   : self.VVR2Qy       ,
   "yellow"  : self.VVSA0j        ,
   "blue"   : self.VVJ259        ,
   "menu"   : self.VVKqee        ,
   "info"   : self.VVzpO6         ,
   "up"   : self.VVpYKT          ,
   "down"   : self.VVJykB         ,
   "left"   : self.VVzYlM         ,
   "right"   : self.VVtvtH         ,
   "pageUp"  : boundFunction(self.VVqFzE, True) ,
   "chanUp"  : boundFunction(self.VVqFzE, True) ,
   "pageDown"  : boundFunction(self.VVqFzE, False) ,
   "chanDown"  : boundFunction(self.VVqFzE, False) ,
   "next"   : self.VVq8G3        ,
   "last"   : self.VVr6HV         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FFbK0m(self)
  FFYzPI(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFdDg8(self, boundFunction(self.VV3lav, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVKqee(self):
  if not self.isBusy:
   VVhjJY = []
   VVhjJY.append(("Statistics"           , "VVNsXP"    ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Suggest PIcons for Current Channel"     , "VVcAlj"   ))
   VVhjJY.append(("Set to Current Channel (copy file)"     , "VVUaj0_file"  ))
   VVhjJY.append(("Set to Current Channel (as SymLink)"     , "VVUaj0_link"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(CCBIQf.VVrF7G())
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVOfXA"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY += CCBIQf.VVhWLa()
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("RCU Keys Help"          , "VVCMEX"    ))
   FFmvQ5(self, self.VVnBXm, title=self.Title, VVhjJY=VVhjJY)
 def VVnBXm(self, item=None):
  if item is not None:
   if   item == "VVNsXP"     : self.VVNsXP()
   elif item == "VVcAlj"    : self.VVcAlj()
   elif item == "VVUaj0_file"   : self.VVUaj0(0)
   elif item == "VVUaj0_link"   : self.VVUaj0(1)
   elif item == "VVcwA2_file"  : self.VVcwA2(0)
   elif item == "VVcwA2_link"  : self.VVcwA2(1)
   elif item == "VV3wPq"   : self.VV3wPq()
   elif item == "VVwTz3"  : self.VVwTz3()
   elif item == "VV4Kyd"   : self.VV4Kyd()
   elif item == "VVOfXA"   : self.VVOfXA()
   elif item == "VVHCxx"   : CCBIQf.VVHCxx(self)
   elif item == "VVx0DX"   : CCBIQf.VVx0DX(self)
   elif item == "findPiconBrokenSymLinks"  : CCBIQf.VVitDW(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCBIQf.VVitDW(self, False)
   elif item == "VVCMEX"      : self.VVCMEX()
 def VVSA0j(self):
  if not self.isBusy:
   VVhjJY = []
   VVhjJY.append(("Go to First PIcon"  , "VVeciC"  ))
   VVhjJY.append(("Go to Last PIcon"   , "VV0oAn"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Sort by Channel Name"     , "sortByChan" ))
   VVhjJY.append(("Sort by File Name"  , "sortByFile" ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Find from File List .." , "VVWFWf" ))
   FFmvQ5(self, self.VVg1K4, title=self.Title, VVhjJY=VVhjJY)
 def VVg1K4(self, item=None):
  if item is not None:
   if   item == "VVeciC"   : self.VVeciC()
   elif item == "VV0oAn"   : self.VV0oAn()
   elif item == "sortByChan"  : self.VVqteV(2)
   elif item == "sortByFile"  : self.VVqteV(0)
   elif item == "VVWFWf"  : self.VVWFWf()
 def VVCMEX(self):
  FFmkwn(self, VVVIGI + "_help_picons", "PIcons Manager (Keys Help)")
 def VVpYKT(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV0oAn()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVi8u6()
 def VVJykB(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVeciC()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVi8u6()
 def VVzYlM(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV0oAn()
  else:
   self.curCol -= 1
   self.VVi8u6()
 def VVtvtH(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVeciC()
  else:
   self.curCol += 1
   self.VVi8u6()
 def VVr6HV(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVi8u6(True)
 def VVq8G3(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVi8u6(True)
 def VVeciC(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVi8u6(True)
 def VV0oAn(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVi8u6(True)
 def VVWFWf(self):
  VVhjJY = []
  for item in self.VV8klC:
   VVhjJY.append((item[0], item[0]))
  FFmvQ5(self, self.VVdKwg, title='PIcons ".png" Files', VVhjJY=VVhjJY, VV14tH=True)
 def VVdKwg(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVyKF6(ndx)
 def VVOk0x(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV9MI0()
   if refCode:
    FF4ffD(self, refCode)
    self.VVsASz()
    self.VVRNSx()
 def VVqFzE(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVsASz()
   self.VVRNSx()
  except:
   pass
 def VVR2Qy(self):
  if self["keyGreen"].getVisible():
   self.VVyKF6(self.curChanIndex)
 def VVyKF6(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVi8u6(True)
  else:
   FFbo0g(self, "Not found", 1000)
 def VVqteV(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFdDg8(self, boundFunction(self.VV3lav, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVUaj0(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV9MI0()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVhjJY = []
     VVhjJY.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVhjJY.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFmvQ5(self, boundFunction(self.VV693z, mode, curChF, selPiconF), VVhjJY=VVhjJY, title="Current Channel PIcon (already exists)")
    else:
     self.VV693z(mode, curChF, selPiconF, "overwrite")
   else:
    FFdx4k(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFdx4k(self, "Could not read current channel info. !", title=title)
 def VV693z(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFdDg8(self, boundFunction(self.VV3lav, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVcwA2(self, mode):
  pass
 def VV3wPq(self):
  pass
 def VVwTz3(self):
  pass
 def VV4Kyd(self):
  pass
 def VVOfXA(self):
  lines = FFHErt("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFT4Vd(self, boundFunction(self.VV5KW8, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVUw2L=True)
  else:
   FFUbus(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV5KW8(self, fList):
  os.system(FF0t1y("find -L '%s' -type l -delete" % self.pPath))
  FFUbus(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVzpO6(self):
  FFdDg8(self, self.VVMJsv)
 def VVMJsv(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV9MI0()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF34IZ("PIcon Directory:\n", VVmWy8)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFWoUk(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFWoUk(path)
   txt += FF34IZ("PIcon File:\n", VVmWy8)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFHErt(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FF34IZ("Found %d SymLink%s to this file from:\n" % (tot, s), VVmWy8)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFPlzC(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FF34IZ(tChName, VVaENg)
     else  : tChName = ""
     txt += "  %s%s\n" % (FF34IZ(line, VVho0k), tChName)
    txt += "\n"
   if chName:
    txt += FF34IZ("Channel:\n", VVmWy8)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF34IZ(chName, VVaENg)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FF34IZ("Remarks:\n", VVmWy8)
    txt += "  %s\n" % FF34IZ("Unused", VVP2je)
  else:
   txt = "No info found"
  FF9kJ8(self, fncMode=CCS14C.VVM5TP, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV9MI0(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV8klC[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFGAsY(sat)
  return fName, refCode, chName, sat, inDB
 def VVsASz(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV8klC):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVRNSx(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV9MI0()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF34IZ("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVmWy8))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV9MI0()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF34IZ(self.curChanName, VVBlp5)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVNsXP(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV8klC:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFCpPs("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFh3cd(self, txt, title=self.Title)
 def VVJ259(self):
  if not self.isBusy:
   VVhjJY = []
   VVhjJY.append(("All"         , "all"   ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("Used by Channels"      , "used"  ))
   VVhjJY.append(("Unused PIcons"      , "unused"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("PIcons Files"       , "pFiles"  ))
   VVhjJY.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVhjJY.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVhjJY.append(VVeSPq)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFkiAa(val)
      VVhjJY.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCwKtp(self)
   filterObj.VVue4R(VVhjJY, self.nsList, self.VVIszG)
 def VVIszG(self, item=None):
  if item is not None:
   self.VVoacC(item)
 def VVoacC(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVt5LL   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVYklw   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVavme  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVBTi4  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVmonJ  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVG8B7  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVwqRP   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVK4zx   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVUl0w , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVG8B7:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFHErt("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFbo0g(self, "Not found", 1000)
     return
   elif mode == self.VV9VCp:
    return
   else:
    words, asPrefix = CCwKtp.VVlIIO(words)
   if not words and mode in (self.VVK4zx, self.VVUl0w):
    FFbo0g(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFdDg8(self, boundFunction(self.VV3lav, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVcAlj(self):
  self.session.open(CCxrdg, barTheme=CCxrdg.VV6xsn
      , titlePrefix = ""
      , fncToRun  = self.VV3Yhg
      , VVHVqi = self.VVCPrm)
 def VV3Yhg(self, progBarObj):
  lameDbChans = CCVkVQ.VVheOM(self, CCVkVQ.VVYyfD, VVUIx4=False, VVQoiw=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVF8YZ = []
  progBarObj.VVgcp1(len(lameDbChans))
  if lameDbChans:
   processChanName = CCkHXi()
   curCh = processChanName.VVmyko(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVPQ4V(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCBIQf.VVtqzP(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCBIQf.VVZMz6(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVF8YZ.append(f.replace(".png", ""))
 def VVCPrm(self, VVV9Ca, VVF8YZ, threadCounter, threadTotal, threadErr):
  if VVF8YZ:
   self.timer = eTimer()
   fnc = boundFunction(FFdDg8, self, boundFunction(self.VV3lav, mode=self.VV9VCp, words=VVF8YZ), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFbo0g(self, "Not found", 2000)
 def VV3lav(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VV77MI(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCVkVQ.VVheOM(self, CCVkVQ.VVYyfD, VVUIx4=False, VVQoiw=False)
  iptvRefList = self.VV8r65()
  tList = []
  for fName, fType in CCBIQf.VVaY26(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVt5LL:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVYklw  and chName         : isAdd = True
   elif mode == self.VVavme and not chName        : isAdd = True
   elif mode == self.VVBTi4  and fType == 0        : isAdd = True
   elif mode == self.VVmonJ  and fType == 1        : isAdd = True
   elif mode == self.VVG8B7  and fName in words       : isAdd = True
   elif mode == self.VV9VCp and fName in words       : isAdd = True
   elif mode == self.VVwqRP  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVK4zx  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVUl0w:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV8klC   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFbo0g(self)
  else:
   self.isBusy = False
   FFbo0g(self, "Not found", 1000)
   return
  self.VV8klC.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVsASz()
  self.totalPIcons = len(self.VV8klC)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVi8u6(True)
 def VV77MI(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCBIQf.VVaY26(self.pPath):
    if fName:
     return True
   if isFirstTime : FFdx4k(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFbo0g(self, "Not found", 1000)
  else:
   FFdx4k(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV8r65(self):
  VVEl38 = {}
  files  = CCRT5i.VV21QT(self)
  if files:
   for path in files:
    txt = FFtCkf(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVEl38[refCode] = item[1]
  return VVEl38
 def VVi8u6(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV5XOr = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV5XOr: self.curPage = VV5XOr
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVRseC()
  if self.curPage == VV5XOr:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVRNSx()
  filName, refCode, chName, sat, inDB = self.VV9MI0()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVRseC(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV8klC[ndx]
   fName = self.VV8klC[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF34IZ(chName, VVaENg))
    else : lbl.setText("-")
   except:
    lbl.setText(FF34IZ(chName, VVsahr))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVtqzP(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVrF7G():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVHCxx"   )
 @staticmethod
 def VVhWLa():
  VVhjJY = []
  VVhjJY.append(("Find SymLinks (to PIcon Directory)"   , "VVx0DX"   ))
  VVhjJY.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVhjJY.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVhjJY
 @staticmethod
 def VVHCxx(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(SELF)
  png, path = CCBIQf.VVyxTn(refCode)
  if path : CCBIQf.VVNMGh(SELF, png, path)
  else : FFdx4k(SELF, "No PIcon found for current channel in:\n\n%s" % CCBIQf.VVS0I8())
 @staticmethod
 def VVx0DX(SELF):
  if VVBlp5:
   sed1 = FF6vFh("->", VVBlp5)
   sed2 = FF6vFh("picon", VVP2je)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVsahr, VVpw0r)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFEKD5(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFF164(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVitDW(SELF, isPIcon):
  sed1 = FF6vFh("->", VVsahr)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF6vFh("picon", VVP2je)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFEKD5(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFF164(), grep, sed1, sed2))
 @staticmethod
 def VVaY26(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVS0I8():
  path = CFG.PIconsPath.getValue()
  return FFoGIr(path)
 @staticmethod
 def VVyxTn(refCode, chName=None):
  if FFgsAM(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFk1Ul(refCode)
  allPath, fName, refCodeFile, pList = CCBIQf.VVZMz6(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVNMGh(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF6vFh("%s%s" % (dest, png), VVaENg))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF6vFh(errTxt, VVlb6B))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF1tu3(SELF, cmd)
 @staticmethod
 def VVZMz6(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCBIQf.VVS0I8()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFdqBS(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCvGyE():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV5XSR  = None
  self.VVuYkL = ""
  self.VVs6Jg  = noService
  self.VVlJGp = 0
  self.VVobpW  = noService
  self.VVtJkr = 0
  self.VViV4B  = "-"
  self.VVlEhw = 0
  self.VVu2HG  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV57Bw(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV5XSR = frontEndStatus
     self.VVEEID()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVEEID(self):
  if self.VV5XSR:
   val = self.VV5XSR.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVuYkL = "%3.02f dB" % (val / 100.0)
   else         : self.VVuYkL = ""
   val = self.VV5XSR.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVlJGp = int(val)
   self.VVs6Jg  = "%d%%" % val
   val = self.VV5XSR.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVtJkr = int(val)
   self.VVobpW  = "%d%%" % val
   val = self.VV5XSR.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VViV4B  = "%d" % val
   val = int(val * 100 / 500)
   self.VVlEhw = min(500, val)
   val = self.VV5XSR.get("tuner_locked", 0)
   if val == 1 : self.VVu2HG = "Locked"
   else  : self.VVu2HG = "Not locked"
 def VVXfrA(self)   : return self.VVuYkL
 def VVZhK8(self)   : return self.VVs6Jg
 def VVhPr3(self)  : return self.VVlJGp
 def VVdwDg(self)   : return self.VVobpW
 def VV5RiI(self)  : return self.VVtJkr
 def VVapK8(self)   : return self.VViV4B
 def VVGOvl(self)  : return self.VVlEhw
 def VVzh8g(self)   : return self.VVu2HG
 def VV7uBq(self) : return self.serviceName
class CCGAc5():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVr4wj(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FForgx(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV4ri0(self.ORPOS  , mod=1   )
      self.sat2  = self.VV4ri0(self.ORPOS  , mod=2   )
      self.freq  = self.VV4ri0(self.FREQ  , mod=3   )
      self.sr   = self.VV4ri0(self.SR   , mod=4   )
      self.inv  = self.VV4ri0(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV4ri0(self.POL  , self.D_POL )
      self.fec  = self.VV4ri0(self.FEC  , self.D_FEC )
      self.syst  = self.VV4ri0(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV4ri0("modulation" , self.D_MOD )
       self.rolof = self.VV4ri0("rolloff"  , self.D_ROLOF )
       self.pil = self.VV4ri0("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV4ri0("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV4ri0("pls_code"  )
       self.iStId = self.VV4ri0("is_id"   )
       self.t2PlId = self.VV4ri0("t2mi_plp_id" )
       self.t2PId = self.VV4ri0("t2mi_pid"  )
 def VV4ri0(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFkiAa(val)
  elif mod == 2   : return FFOLoN(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVnpjs(self, refCode):
  txt = ""
  self.VVr4wj(refCode)
  if self.data:
   def VVPlT0(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVPlT0("System"   , self.syst)
    txt += VVPlT0("Satellite"  , self.sat2)
    txt += VVPlT0("Frequency"  , self.freq)
    txt += VVPlT0("Inversion"  , self.inv)
    txt += VVPlT0("Symbol Rate"  , self.sr)
    txt += VVPlT0("Polarization" , self.pol)
    txt += VVPlT0("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVPlT0("Modulation" , self.mod)
     txt += VVPlT0("Roll-Off" , self.rolof)
     txt += VVPlT0("Pilot"  , self.pil)
     txt += VVPlT0("Input Stream", self.iStId)
     txt += VVPlT0("T2MI PLP ID" , self.t2PlId)
     txt += VVPlT0("T2MI PID" , self.t2PId)
     txt += VVPlT0("PLS Mode" , self.plsMod)
     txt += VVPlT0("PLS Code" , self.plsCod)
   else:
    txt += VVPlT0("System"   , self.txMedia)
    txt += VVPlT0("Frequency"  , self.freq)
  return txt, self.namespace
 def VVquqp(self, refCode):
  txt = "Transpoder : ?"
  self.VVr4wj(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVmWy8 + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVBhAc(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FForgx(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV4ri0(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV4ri0(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV4ri0(self.SYST, self.D_SYS_S)
     freq = self.VV4ri0(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV4ri0(self.POL , self.D_POL)
      fec = self.VV4ri0(self.FEC , self.D_FEC)
      sr = self.VV4ri0(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV7VOo(self, refCode):
  self.data = None
  self.VVr4wj(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCVm0W():
 def __init__(self, VVwTuR, path, VVHVqi=None, curRowNum=-1):
  self.VVwTuR  = VVwTuR
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVHVqi  = VVHVqi
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FF0t1y("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVB6X4(curRowNum)
  else:
   FFdx4k(self.VVwTuR, "Error while preparing edit!")
 def VVB6X4(self, curRowNum):
  VVEl38 = self.VVehVG()
  VV6Yzq = None #("Delete Line" , self.deleteLine  , [])
  VVB3WF = ("Save Changes" , self.VVkbKz   , [])
  VVR5hp  = ("Edit Line"  , self.VVzoa8    , [])
  VVn2KW = ("Line Options" , self.VVah4P   , [])
  VV0KAt = (""    , self.VVazZa , [])
  VVFJFw = self.VVt1vF
  VVr83J  = self.VVJCr6
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVenpJ  = (CENTER  , LEFT  )
  VV8kdg = FFrMdi(self.VVwTuR, None, title=self.Title, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VV6Yzq=VV6Yzq, VVB3WF=VVB3WF, VVR5hp=VVR5hp, VVn2KW=VVn2KW, VVFJFw=VVFJFw, VVr83J=VVr83J, VV0KAt=VV0KAt, VVWA0Q=True
    , VVHOIE   = "#11001111"
    , VVsOU8   = "#11001111"
    , VVauqk   = "#11001111"
    , VVMVsE  = "#05333333"
    , VVHcAW  = "#00222222"
    , VV7rwH  = "#11331133"
    )
  VV8kdg.VVZXGi(curRowNum)
 def VVah4P(self, VV8kdg, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VV8kdg.VVv8M5()
  VVhjJY = []
  VVhjJY.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVhjJY.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVq7VL"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVjBnN:
   VVhjJY.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(  ("Delete Line"         , "deleteLine"   ))
  FFmvQ5(self.VVwTuR, boundFunction(self.VVgPbM, VV8kdg, lineNum), VVhjJY=VVhjJY, title="Line Options")
 def VVgPbM(self, VV8kdg, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV6TTu("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VV8kdg)
   elif item == "VVq7VL"  : self.VVq7VL(VV8kdg, lineNum)
   elif item == "copyToClipboard"  : self.VVJ9rV(VV8kdg, lineNum)
   elif item == "pasteFromClipboard" : self.VVGSNG(VV8kdg, lineNum)
   elif item == "deleteLine"   : self.VV6TTu("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VV8kdg)
 def VVJCr6(self, VV8kdg):
  VV8kdg.VVHpq5()
 def VVazZa(self, VV8kdg, title, txt, colList):
  if   self.insertMode == 1: VV8kdg.VVpWXt()
  elif self.insertMode == 2: VV8kdg.VVZXGg()
  self.insertMode = 0
 def VVq7VL(self, VV8kdg, lineNum):
  if lineNum == VV8kdg.VVv8M5():
   self.insertMode = 1
   self.VV6TTu("echo '' >> '%s'" % self.tmpFile, VV8kdg)
  else:
   self.insertMode = 2
   self.VV6TTu("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VV8kdg)
 def VVJ9rV(self, VV8kdg, lineNum):
  global VVjBnN
  VVjBnN = FFCpPs("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VV8kdg.VVhdSv("Copied to clipboard")
 def VVkbKz(self, VV8kdg, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FF0t1y("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FF0t1y("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VV8kdg.VVhdSv("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VV8kdg.VVHpq5()
    else:
     FFdx4k(self.VVwTuR, "Cannot save file!")
   else:
    FFdx4k(self.VVwTuR, "Cannot create backup copy of original file!")
 def VVt1vF(self, VV8kdg):
  if self.fileChanged:
   FFT4Vd(self.VVwTuR, boundFunction(self.VVvjZY, VV8kdg), "Cancel changes ?")
  else:
   finalOK = os.system(FF0t1y("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVvjZY(VV8kdg)
 def VVvjZY(self, VV8kdg):
  VV8kdg.cancel()
  os.system(FF0t1y("rm -f '%s'" % self.tmpFile))
  if self.VVHVqi:
   self.VVHVqi(self.fileSaved)
 def VVzoa8(self, VV8kdg, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVpw0r + "ORIGINAL TEXT:\n" + VVho0k + lineTxt
  FFktKm(self.VVwTuR, boundFunction(self.VVC7Zx, lineNum, VV8kdg), title="File Line", defaultText=lineTxt, message=message)
 def VVC7Zx(self, lineNum, VV8kdg, VVqjyy):
  if not VVqjyy is None:
   if VV8kdg.VVv8M5() <= 1:
    self.VV6TTu("echo %s > '%s'" % (VVqjyy, self.tmpFile), VV8kdg)
   else:
    self.VV9jOC(VV8kdg, lineNum, VVqjyy)
 def VVGSNG(self, VV8kdg, lineNum):
  if lineNum == VV8kdg.VVv8M5() and VV8kdg.VVv8M5() == 1:
   self.VV6TTu("echo %s >> '%s'" % (VVjBnN, self.tmpFile), VV8kdg)
  else:
   self.VV9jOC(VV8kdg, lineNum, VVjBnN)
 def VV9jOC(self, VV8kdg, lineNum, newTxt):
  VV8kdg.VVp4RP("Saving ...")
  lines = FFPPAc(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VV8kdg.VVOv4b()
  VVEl38 = self.VVehVG()
  VV8kdg.VVmRNB(VVEl38)
 def VV6TTu(self, cmd, VV8kdg):
  tCons = CCL2ur()
  tCons.ePopen(cmd, boundFunction(self.VVzceT, VV8kdg))
  self.fileChanged = True
  VV8kdg.VVOv4b()
 def VVzceT(self, VV8kdg, result, retval):
  VVEl38 = self.VVehVG()
  VV8kdg.VVmRNB(VVEl38)
 def VVehVG(self):
  if fileExists(self.tmpFile):
   lines = FFPPAc(self.tmpFile)
   VVEl38 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVEl38.append((str(ndx), line.strip()))
   if not VVEl38:
    VVEl38.append((str(1), ""))
   return VVEl38
  else:
   FF5BoZ(self.VVwTuR, self.tmpFile)
class CCwKtp():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVhjJY   = []
  self.satList   = []
 def VVJk9C(self, VVHVqi):
  self.VVhjJY = []
  VVhjJY, VVcBm0 = self.VVaPql(False, True)
  if VVhjJY:
   self.VVhjJY += VVhjJY
   self.VV5RHc(VVHVqi, VVcBm0)
 def VVhacF(self, mode, VV8kdg, satCol, VVHVqi):
  VV8kdg.VVp4RP("Loading Filters ...")
  self.VVhjJY = []
  self.VVhjJY.append(("All Services" , "all"))
  if mode == 1:
   self.VVhjJY.append(VVeSPq)
   self.VVhjJY.append(("Parental Control", "parentalControl"))
   self.VVhjJY.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVhjJY.append(VVeSPq)
   self.VVhjJY.append(("Selected Transponder"   , "selectedTP" ))
   self.VVhjJY.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVamS5(VV8kdg, satCol)
  VVhjJY, VVcBm0 = self.VVaPql(True, False)
  if VVhjJY:
   VVhjJY.insert(0, VVeSPq)
   self.VVhjJY += VVhjJY
  VV8kdg.VVr9ZM()
  self.VV5RHc(VVHVqi, VVcBm0)
 def VVue4R(self, VVhjJY, sats, VVHVqi):
  self.VVhjJY = VVhjJY
  VVhjJY, VVcBm0 = self.VVaPql(True, False)
  if VVhjJY:
   self.VVhjJY.append(VVeSPq)
   self.VVhjJY += VVhjJY
  self.VV5RHc(VVHVqi, VVcBm0)
 def VVKw38(self, VVhjJY, sats, VVHVqi):
  self.VVhjJY = VVhjJY
  VVhjJY, VVcBm0 = self.VVaPql(True, False)
  if VVhjJY:
   self.VVhjJY.append(VVeSPq)
   self.VVhjJY += VVhjJY
  self.VV5RHc(VVHVqi, VVcBm0)
 def VV5RHc(self, VVHVqi, VVcBm0):
  VVbBdV = ("Edit Filter", boundFunction(self.VVE3dQ, VVcBm0))
  VVKkqL  = ("Filter Help", boundFunction(self.VVdC9S, VVcBm0))
  FFmvQ5(self.callingSELF, boundFunction(self.VVA15o, VVHVqi), VVhjJY=self.VVhjJY, title="Select Filter", VVbBdV=VVbBdV, VVKkqL=VVKkqL)
 def VVA15o(self, VVHVqi, item):
  if item:
   VVHVqi(item)
 def VVE3dQ(self, VVcBm0, VVdAc1Obj, sel):
  if fileExists(VVcBm0) : CCVm0W(self.callingSELF, VVcBm0, VVHVqi=None)
  else       : FF5BoZ(self.callingSELF, VVcBm0)
  VVdAc1Obj.cancel()
 def VVdC9S(self, VVcBm0, VVdAc1Obj, sel):
  FFmkwn(self.callingSELF, VVVIGI + "_help_service_filter", "Service Filter")
 def VVamS5(self, VV8kdg, satColNum):
  if not self.satList:
   satList = VV8kdg.VV28sP(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFGAsY(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVeSPq)
  if self.VVhjJY:
   self.VVhjJY += self.satList
 def VVaPql(self, addTag, VVpwCo):
  FFl7aG()
  fileName  = "ajpanel_services_filter"
  VVcBm0 = VVTiP2 + fileName
  VVhjJY  = []
  if not fileExists(VVcBm0):
   os.system(FF0t1y("cp -f '%s' '%s'" % (VVVIGI + fileName, VVcBm0)))
  fileFound = False
  if fileExists(VVcBm0):
   fileFound = True
   lines = FFPPAc(VVcBm0)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVhjJY.append((line, "__w__" + line))
       else  : VVhjJY.append((line, line))
  if VVpwCo:
   if   not fileFound : FF5BoZ(self.callingSELF , VVcBm0)
   elif not VVhjJY : FFwNVh(self.callingSELF , VVcBm0)
  return VVhjJY, VVcBm0
 @staticmethod
 def VVlIIO(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCfYM9():
 def __init__(self, callingSELF, VV8kdg, refCodeColNum):
  self.callingSELF = callingSELF
  self.VV8kdg = VV8kdg
  self.refCodeColNum = refCodeColNum
  self.VVhjJY = []
  iMulSel = self.VV8kdg.VVL6ID()
  if iMulSel : self.VVhjJY.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVhjJY.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VV8kdg.VVqK6p()
  self.VVhjJY.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVhjJY.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVhjJY.append(VVeSPq)
 def VVHnff(self, servName, refCode):
  tot = self.VV8kdg.VVqK6p()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVhjJY.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVpyO7_multi" ))
  else    : self.VVhjJY.append( ("Add to Bouquet : %s"      % servName , "VVpyO7_one" ))
  self.VVaoMW(servName, refCode)
 def VVNpxR(self, servName, refCode, pcState, hidState):
  self.VVhjJY = []
  if pcState == "No" : self.VVhjJY.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVhjJY.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVhjJY.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVhjJY.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVaoMW(servName, refCode)
 def VVaoMW(self, servName, refCode):
  FFmvQ5(self.callingSELF, boundFunction(self.VVVH3T, servName, refCode), title="Options", VVhjJY=self.VVhjJY)
 def VVVH3T(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VV8kdg.VV8eq6(True)
   elif item == "MultSelDisab"    : self.VV8kdg.VV8eq6(False)
   elif item == "selectAll"    : self.VV8kdg.VV08GV()
   elif item == "unselectAll"    : self.VV8kdg.VVHHx7()
   elif item == "parentalControl_add"  : self.callingSELF.VVrZ8F(self.VV8kdg, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVrZ8F(self.VV8kdg, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VV7o46(self.VV8kdg, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VV7o46(self.VV8kdg, refCode, False)
   elif item == "VVpyO7_multi" : self.VVpyO7(refCode, True)
   elif item == "VVpyO7_one" : self.VVpyO7(refCode, False)
 def VVpyO7(self, refCode, isMulti):
  bouquets = FFeUK9()
  if bouquets:
   VVhjJY = []
   for item in bouquets:
    VVhjJY.append((item[0], item[1].toString()))
   VVbBdV = ("Create New", boundFunction(self.VVjfHz, refCode, isMulti))
   FFmvQ5(self.callingSELF, boundFunction(self.VVaA04, refCode, isMulti), VVhjJY=VVhjJY, title="Add to Bouquet", VVbBdV=VVbBdV, VV14tH=True, VV4UKo=True)
  else:
   FFT4Vd(self.callingSELF, boundFunction(self.VVeUHF, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVaA04(self, refCode, isMulti, bName=None):
  if bName:
   FFdDg8(self.VV8kdg, boundFunction(self.VVZWzI, refCode, isMulti, bName), title="Adding Channels ...")
 def VVZWzI(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVVgwW(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VV8xAY = InfoBar.instance
    if VV8xAY:
     VVOnZD = VV8xAY.servicelist
     if VVOnZD:
      mutableList = VVOnZD.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VV8kdg.VVr9ZM()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFUbus(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFdx4k(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVVgwW(self, refCode, isMulti):
  if isMulti : refCodeList = self.VV8kdg.VVpXLl(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVjfHz(self, refCode, isMulti, VVdAc1Obj, path):
  self.VVeUHF(refCode, isMulti)
 def VVeUHF(self, refCode, isMulti):
  FFktKm(self.callingSELF, boundFunction(self.VVvDi9, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVvDi9(self, refCode, isMulti, name):
  if name:
   FFdDg8(self.VV8kdg, boundFunction(self.VVZGXU, refCode, isMulti, name), title="Adding Channels ...")
 def VVZGXU(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVVgwW(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VV8xAY = InfoBar.instance
    if VV8xAY:
     VVOnZD = VV8xAY.servicelist
     if VVOnZD:
      try:
       VVOnZD.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVOnZD.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VV8kdg.VVr9ZM()
   title = "Add to Bouquet"
   if allOK: FFUbus(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFdx4k(self.callingSELF, "Nothing added!", title=title)
class CCxVpD(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVsERI, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFgoqU(self)
  FFmNCq(self["keyRed"]  , "Exit")
  FFmNCq(self["keyGreen"]  , "Save")
  FFmNCq(self["keyYellow"] , "Refresh")
  FFmNCq(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV2b1X  ,
   "green"   : self.VVwl04 ,
   "yellow"  : self.VVMuMM  ,
   "blue"   : self.VV8jnZ   ,
   "up"   : self.VVpYKT    ,
   "down"   : self.VVJykB   ,
   "left"   : self.VVzYlM   ,
   "right"   : self.VVtvtH   ,
   "cancel"  : self.VV2b1X
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVMuMM()
  self.VVTRCQ()
  FFbK0m(self)
 def VV2b1X(self) : self.close(True)
 def VVHy8Y(self) : self.close(False)
 def VV8jnZ(self):
  self.session.openWithCallback(self.VVosr8, boundFunction(CCEJmm))
 def VVosr8(self, closeAll):
  if closeAll:
   self.close()
 def VVpYKT(self):
  self.VVTA2B(1)
 def VVJykB(self):
  self.VVTA2B(-1)
 def VVzYlM(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVTRCQ()
 def VVtvtH(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVTRCQ()
 def VVTA2B(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVsR7j(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVsR7j(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVsR7j(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVrlQH(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVrlQH(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVTRCQ(self):
  for obj in self.list:
   FFYzPI(obj, "#11404040")
  FFYzPI(self.list[self.index], "#11ff8000")
 def VVMuMM(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVwl04(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCL2ur()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVUqAX)
 def VVUqAX(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFUbus(self, "Nothing returned from the system!")
  else:
   FFUbus(self, str(result))
class CCEJmm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVw4sR, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFgoqU(self, addLabel=True)
  FFmNCq(self["keyRed"]  , "Exit")
  FFmNCq(self["keyGreen"]  , "Sync")
  FFmNCq(self["keyYellow"] , "Refresh")
  FFmNCq(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV2b1X   ,
   "green"   : self.VVaIDb  ,
   "yellow"  : self.VVHrXw ,
   "blue"   : self.VVCYxr  ,
   "cancel"  : self.VV2b1X
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VV8T2u()
  self.onShow.append(self.start)
 def start(self):
  FFC95U(self.refresh)
  FFbK0m(self)
 def refresh(self):
  self.VVs86l()
  self.VVFuq6(False)
 def VV2b1X(self)  : self.close(True)
 def VVCYxr(self) : self.close(False)
 def VV8T2u(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVs86l(self):
  self.VV3ccJ()
  self.VVaXwo()
  self.VVN1cj()
  self.VVqC5F()
 def VVHrXw(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VV8T2u()
   self.VVs86l()
   FFC95U(self.refresh)
 def VVaIDb(self):
  if len(self["keyGreen"].getText()) > 0:
   FFT4Vd(self, self.VVpWaz, "Synchronize with Internet Date/Time ?")
 def VVpWaz(self):
  self.VVs86l()
  FFC95U(boundFunction(self.VVFuq6, True))
 def VV3ccJ(self)  : self["keyRed"].show()
 def VVWpcC(self)  : self["keyGreen"].show()
 def VVmB2S(self) : self["keyYellow"].show()
 def VVxmaJ(self)  : self["keyBlue"].show()
 def VVaXwo(self)  : self["keyGreen"].hide()
 def VVN1cj(self) : self["keyYellow"].hide()
 def VVqC5F(self)  : self["keyBlue"].hide()
 def VVFuq6(self, sync):
  localTime = FFvbBP()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVgbw4(server)
   if epoch_time is not None:
    ntpTime = FFCnzX(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCL2ur()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVUqAX, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVmB2S()
  self.VVxmaJ()
  if ok:
   self.VVWpcC()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVUqAX(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVFuq6(False)
  except:
   pass
 def VVgbw4(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFScuV():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCiaM4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFuMnj(VVEb36, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFgoqU(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FFC95U(self.VVWpgd)
 def VVWpgd(self):
  if FFScuV(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFYzPI(self["myBody"], color)
   FFYzPI(self["myLabel"], color)
  except:
   pass
class CC6O8G(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFCBpq()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFuMnj(VVTk2N, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCPGXY(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCPGXY(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCPGXY(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCvGyE()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFgoqU(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVpYKT          ,
   "down"  : self.VVJykB         ,
   "left"  : self.VVzYlM         ,
   "right"  : self.VVtvtH         ,
   "info"  : self.VVXc25        ,
   "epg"  : self.VVXc25        ,
   "menu"  : self.VVCMEX         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VV0AHO, -1)  ,
   "next"  : boundFunction(self.VV0AHO, 1)  ,
   "pageUp" : boundFunction(self.VVwqE1, True) ,
   "chanUp" : boundFunction(self.VVwqE1, True) ,
   "pageDown" : boundFunction(self.VVwqE1, False) ,
   "chanDown" : boundFunction(self.VVwqE1, False) ,
   "0"   : boundFunction(self.VV0AHO, 0)  ,
   "1"   : boundFunction(self.VVpC6L, pos=1) ,
   "2"   : boundFunction(self.VVpC6L, pos=2) ,
   "3"   : boundFunction(self.VVpC6L, pos=3) ,
   "4"   : boundFunction(self.VVpC6L, pos=4) ,
   "5"   : boundFunction(self.VVpC6L, pos=5) ,
   "6"   : boundFunction(self.VVpC6L, pos=6) ,
   "7"   : boundFunction(self.VVpC6L, pos=7) ,
   "8"   : boundFunction(self.VVpC6L, pos=8) ,
   "9"   : boundFunction(self.VVpC6L, pos=9) ,
  }, -1)
  self.onShown.append(self.VVHk7P)
  self.onClose.append(self.onExit)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self.sliderSNR.VVSkKS()
  self.sliderAGC.VVSkKS()
  self.sliderBER.VVSkKS(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVpC6L()
  self.VVxZGDInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVxZGD)
  except:
   self.timer.callback.append(self.VVxZGD)
  self.timer.start(500, False)
 def VVxZGDInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV57Bw(service)
  serviceName = self.tunerInfo.VV7uBq()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  tp = CCGAc5()
  txt = tp.VVquqp(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVxZGD(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV57Bw(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVXfrA())
   self["mySNR"].setText(self.tunerInfo.VVZhK8())
   self["myAGC"].setText(self.tunerInfo.VVdwDg())
   self["myBER"].setText(self.tunerInfo.VVapK8())
   self.sliderSNR.VVqHI0(self.tunerInfo.VVhPr3())
   self.sliderAGC.VVqHI0(self.tunerInfo.VV5RiI())
   self.sliderBER.VVqHI0(self.tunerInfo.VVGOvl())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVqHI0(0)
   self.sliderAGC.VVqHI0(0)
   self.sliderBER.VVqHI0(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
    if state and not state == "Tuned":
     FFbo0g(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVXc25(self):
  FF9kJ8(self, fncMode=CCS14C.VVTsRg)
 def VVCMEX(self):
  FFmkwn(self, VVVIGI + "_help_signal", "Signal Monitor (Keys)")
 def VVpYKT(self)  : self.VVpC6L(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVJykB(self) : self.VVpC6L(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVzYlM(self) : self.VVpC6L(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVtvtH(self) : self.VVpC6L(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVpC6L(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV0AHO(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF3oWp(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVwqE1(self, isUp):
  FFbo0g(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVxZGDInfo()
  except:
   pass
class CCPGXY(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVSkKS(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFYzPI(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVVIGI +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFYzPI(self.covObj, self.covColor)
   else:
    FFYzPI(self.covObj, "#00006688")
    self.isColormode = True
  self.VVqHI0(0)
 def VVqHI0(self, val):
  val  = FF3oWp(val, self.minN, self.maxN)
  width = int(FFXuQi(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF3oWp(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCxrdg(Screen):
 VV6xsn    = 0
 VV8YZ8 = 1
 VVpCGU = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVHVqi=None, barTheme=VV6xsn):
  ratio = self.VVGmfK(barTheme)
  self.skin, self.skinParam = FFuMnj(VVNcca, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVHVqi = VVHVqi
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVF8YZ = None
  self.timer   = eTimer()
  self.myThread  = None
  FFgoqU(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVHk7P)
  self.onClose.append(self.onExit)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self.VVkvmm()
  self["myProgBarVal"].setText("0%")
  FFYzPI(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVt8mU()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVt8mU)
  except:
   self.timer.callback.append(self.VVt8mU)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="threadFnc", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVgcp1(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVB2Vz_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVF8YZ), self.counter, self.maxValue, catName)
 def VVPQ4V(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVF8YZ), self.counter, self.maxValue)
  except:
   pass
 def VVOU66(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFbo0g(self, "Cancelling ...")
  self.isCancelled = True
  if self.VVHVqi:
   self.VVHVqi(False, self.VVF8YZ, self.counter, self.maxValue, self.isError)
  self.close()
 def VVt8mU(self):
  val = FF3oWp(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFXuQi(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VVHVqi and not self.isCancelled:
    self.VVHVqi(True, self.VVF8YZ, self.counter, self.maxValue, self.isError)
   self.close()
 def VVkvmm(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme == self.VV8YZ8:
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVpCGU:
   pass
 def VVGmfK(self, barTheme):
  if   barTheme == self.VV8YZ8 : return 0.8
  elif barTheme == self.VVpCGU : return 1
  else              : return 1
class CCL2ur(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVHVqi = {}
  self.commandRunning = False
  self.VVgL4t  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVHVqi, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVHVqi[name] = VVHVqi
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVgL4t:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVDRoh, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VV29Cb , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVDRoh, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VV29Cb , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV29Cb(name, retval)
  return True
 def VVDRoh(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV29Cb(self, name, retval):
  if not self.VVgL4t:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVHVqi[name]:
   self.VVHVqi[name](self.appResults[name], retval)
  del self.VVHVqi[name]
 def VVGXPZ(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCmXLq(Screen):
 def __init__(self, session, title="", VVHIgK=None, VVkl4E=False, VVFCuN=False, VV6FiF=False, VVoDEx=False, VVggza=False, VV9GFV=False, VV9aL5=VVhB6f, VVMQzL=None, VVo6it=False, VVnnIF=None, VVAVkY="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFuMnj(VVlcNn, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFgoqU(self, addScrollLabel=True)
  if not VVAVkY:
   VVAVkY = "Processing ..."
  self["myLabel"].setText("   %s" % VVAVkY)
  self.VVkl4E   = VVkl4E
  self.VVFCuN   = VVFCuN
  self.VV6FiF   = VV6FiF
  self.VVoDEx  = VVoDEx
  self.VVggza = VVggza
  self.VV9GFV = VV9GFV
  self.VV9aL5   = VV9aL5
  self.VVMQzL = VVMQzL
  self.VVo6it  = VVo6it
  self.VVnnIF  = VVnnIF
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCL2ur()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFRiG8()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVHIgK, str):
   self.VVHIgK = [VVHIgK]
  else:
   self.VVHIgK = VVHIgK
  if self.VV6FiF or self.VVoDEx:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVbwqB, VVbwqB)
   self.VVHIgK.append("echo -e '\n%s\n' %s" % (restartNote, FF6vFh(restartNote, VVBlp5)))
   if self.VV6FiF:
    self.VVHIgK.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVHIgK.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVggza:
   FFbo0g(self, "Processing ...")
  self.onLayoutFinish.append(self.VVMyYH)
  self.onClose.append(self.VVBgrO)
 def VVMyYH(self):
  self["myLabel"].VV36kJ(textOutFile="console" if self.enableSaveRes else "")
  if self.VVkl4E:
   self["myLabel"].VVyPlD()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV8JZo()
  else:
   self.VVVepF()
 def VV8JZo(self):
  if FFScuV():
   self["myLabel"].setText("Processing ...")
   self.VVVepF()
  else:
   self["myLabel"].setText(FF34IZ("\n   No connection to internet!", VVP2je))
 def VVVepF(self):
  allOK = self.container.ePopen(self.VVHIgK[0], self.VVOX7T, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVOX7T("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV9GFV or self.VV6FiF or self.VVoDEx:
    self["myLabel"].setText(FF03HQ("STARTED", VVBlp5) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVnnIF:
   colorWhite = CCGqtk.VVZkkc(VVpw0r)
   color  = CCGqtk.VVZkkc(self.VVnnIF[0])
   words  = self.VVnnIF[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VV9aL5=self.VV9aL5)
 def VVOX7T(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVHIgK):
   allOK = self.container.ePopen(self.VVHIgK[self.cmdNum], self.VVOX7T, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVOX7T("Cannot connect to Console!", -1)
  else:
   if self.VVggza and FFtBhW(self):
    FFbo0g(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV9GFV:
    self["myLabel"].appendText("\n" + FF03HQ("FINISHED", VVBlp5), self.VV9aL5)
   if self.VVkl4E or self.VVFCuN:
    self["myLabel"].VVyPlD()
   if self.VVMQzL is not None:
    self.VVMQzL()
   if not retval and self.VVo6it:
    self.VVBgrO()
 def VVBgrO(self):
  if self.container.VVGXPZ():
   self.container.killAll()
class CCQcrZ(Screen):
 def __init__(self, session, VVHIgK=None, VVggza=False):
  self.skin, self.skinParam = FFuMnj(VVlcNn, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVTiP2 + "ajpanel_terminal.history"
  self.customCommandsFile = VVTiP2 + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFCpPs("pwd") or "/home/root"
  self.container   = CCL2ur()
  FFgoqU(self, addScrollLabel=True)
  FFmNCq(self["keyRed"] , "Exit = Stop Command")
  FFmNCq(self["keyGreen"] , "OK = History")
  FFmNCq(self["keyYellow"], "Menu = Custom Cmds")
  FFmNCq(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVjzle ,
   "cancel" : self.VV0CpS  ,
   "menu"  : self.VV7hWM ,
   "last"  : self.VVRe8g  ,
   "next"  : self.VVRe8g  ,
   "1"   : self.VVRe8g  ,
   "2"   : self.VVRe8g  ,
   "3"   : self.VVRe8g  ,
   "4"   : self.VVRe8g  ,
   "5"   : self.VVRe8g  ,
   "6"   : self.VVRe8g  ,
   "7"   : self.VVRe8g  ,
   "8"   : self.VVRe8g  ,
   "9"   : self.VVRe8g  ,
   "0"   : self.VVRe8g
  })
  self.onLayoutFinish.append(self.VVHk7P)
  self.onClose.append(self.VVKCPR)
 def VVHk7P(self):
  self["myLabel"].VV36kJ(isResizable=False, textOutFile="terminal")
  FF55DC(self["keyRed"]  , "#00ff8000")
  FFYzPI(self["keyRed"]  , self.skinParam["titleColor"])
  FFYzPI(self["keyGreen"]  , self.skinParam["titleColor"])
  FFYzPI(self["keyYellow"] , self.skinParam["titleColor"])
  FFYzPI(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVVokl(FFCpPs("date"), 5)
  result = FFCpPs("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVIBja()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVVIGI + "LinuxCommands.lst"
   newTemplate = VVVIGI + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FF0t1y("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FF0t1y("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVKCPR(self):
  if self.container.VVGXPZ():
   self.container.killAll()
   self.VVVokl("Process killed\n", 4)
   self.VVIBja()
 def VV0CpS(self):
  if self.container.VVGXPZ():
   self.VVKCPR()
  else:
   FFT4Vd(self, self.close, "Exit ?", VVbPNx=False)
 def VVIBja(self):
  self.VVVokl(self.prompt, 1)
  self["keyRed"].hide()
 def VVVokl(self, txt, mode):
  if   mode == 1 : color = VVBlp5
  elif mode == 2 : color = VVmWy8
  elif mode == 3 : color = VVpw0r
  elif mode == 4 : color = VVP2je
  elif mode == 5 : color = VVho0k
  elif mode == 6 : color = VVQAQ9
  else   : color = VVpw0r
  try:
   self["myLabel"].appendText(FF34IZ(txt, color))
  except:
   pass
 def VVuzqu(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FF34IZ(parts[0].strip(), VVmWy8)
   right = FF34IZ("#" + parts[1].strip(), VVQAQ9)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVVokl(txt, 2)
  lastLine = self.VVRwJO()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVZT8a(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVOX7T, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FFdx4k(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVVokl(data, 3)
 def VVOX7T(self, data, retval):
  if not retval == 0:
   self.VVVokl("Exit Code : %d\n" % retval, 4)
  self.VVIBja()
 def VVjzle(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVRwJO() == "":
   self.VVZT8a("cd /tmp")
   self.VVZT8a("ls")
  VVEl38 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFPPAc(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVEl38.append((str(c), line, str(lNum)))
   self.VViQgR(VVEl38, title, self.commandHistoryFile, isHistory=True)
  else:
   FF5BoZ(self, self.commandHistoryFile, title=title)
 def VVRwJO(self):
  lastLine = FFCpPs("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVZT8a(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV7hWM(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFPPAc(self.customCommandsFile)
   lastLineIsSep = False
   VVEl38 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVEl38.append((str(c), line, str(lNum)))
   self.VViQgR(VVEl38, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF5BoZ(self, self.customCommandsFile, title=title)
 def VViQgR(self, VVEl38, title, filePath=None, isHistory=False):
  if VVEl38:
   VVMVsE = "#05333333"
   if isHistory: VVHOIE = VVsOU8 = VVauqk = "#11000020"
   else  : VVHOIE = VVsOU8 = VVauqk = "#06002020"
   VVRYtq = VVn2KW = None
   VVR5hp   = ("Send"   , self.VVaNDh        , [])
   VVB3WF  = ("Modify & Send" , self.VVEXFA        , [])
   if isHistory:
    VVRYtq = ("Clear History" , self.VVxxkE        , [])
   elif filePath:
    VVn2KW = ("Edit File"  , boundFunction(self.VVb9J9, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVenpJ     = (CENTER  , LEFT   , CENTER )
   FFrMdi(self, None, title=title, header=header, VV8klC=VVEl38, VVenpJ=VVenpJ, VVxJaI=widths, VVhj1e=26, VVR5hp=VVR5hp, VVB3WF=VVB3WF, VVRYtq=VVRYtq, VVn2KW=VVn2KW, VVWA0Q=True
     , VVHOIE   = VVHOIE
     , VVsOU8   = VVsOU8
     , VVauqk   = VVauqk
     , VVp86P  = "#05ffff00"
     , VVMVsE  = VVMVsE
    )
  else:
   FFwNVh(self, filePath, title=title)
 def VVaNDh(self, VV8kdg, title, txt, colList):
  cmd = colList[1].strip()
  VV8kdg.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVVokl("\n%s\n" % cmd, 6)
   self.VVVokl(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVVokl(cmd, 2)
    self.VVVokl("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVVokl(ch, 0)
    self.VVVokl("\nor\n", 4)
    self.VVVokl("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVIBja()
   else:
    self.VVuzqu(cmd)
 def VVEXFA(self, VV8kdg, title, txt, colList):
  cmd = colList[1]
  self.VVoR10(VV8kdg, cmd)
 def VVxxkE(self, VV8kdg, title, txt, colList):
  FFT4Vd(self, boundFunction(self.VVoLRz, VV8kdg), "Reset History File ?", title="Command History")
 def VVoLRz(self, VV8kdg):
  os.system(FF0t1y("echo '' > %s" % self.commandHistoryFile))
  VV8kdg.cancel()
 def VVb9J9(self, filePath, VV8kdg, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCVm0W(self, filePath, VVHVqi=boundFunction(self.VVdU5s, VV8kdg), curRowNum=rowNum)
  else     : FF5BoZ(self, filePath)
 def VVdU5s(self, VV8kdg, fileChanged):
  if fileChanged:
   VV8kdg.cancel()
   FFC95U(self.VV7hWM)
 def VVRe8g(self):
  self.VVoR10(None, self.lastCommand)
 def VVoR10(self, VV8kdg, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFktKm(self, boundFunction(self.VVD5Wb, VV8kdg), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVD5Wb(self, VV8kdg, cmd):
  if cmd and len(cmd) > 0:
   self.VVuzqu(cmd)
   if VV8kdg:
    VV8kdg.cancel()
class CCnAZJ(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVqjyy="", VVsowu=False, VVylAc=False, isTrimEnds=True):
  self.skin, self.skinParam = FFuMnj(VVI3ap, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFgoqU(self, title, addLabel=True)
  FFmNCq(self["keyRed"] , "Up/Down = Change")
  FFmNCq(self["keyGreen"] , "Overwrite")
  FFmNCq(self["keyYellow"], "Pick Key Map")
  FFmNCq(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVylAc   = VVylAc
  self.VVsowu  = VVsowu
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVqjyy, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVNc06      ,
   "green"    : self.VVmNjb    ,
   "yellow"   : self.VVuSE9      ,
   "blue"    : self.VVMgyx     ,
   "menu"    : self.VV0acM     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVp0hd, True) ,
   "down"    : boundFunction(self.VVp0hd, False) ,
   "left"    : self.VVFdLQ       ,
   "right"    : self.VVUOm2       ,
   "home"    : self.VV6qrO       ,
   "end"    : self.VVj9oQ       ,
   "next"    : self.VV6AK7      ,
   "last"    : self.VVYaNP      ,
   "deleteForward"  : self.VV6AK7      ,
   "deleteBackward" : self.VVYaNP      ,
   "tab"    : self.VVCPSM       ,
   "toggleOverwrite" : self.VVmNjb    ,
   "0"     : self.VVQeeT     ,
   "1"     : self.VVQeeT     ,
   "2"     : self.VVQeeT     ,
   "3"     : self.VVQeeT     ,
   "4"     : self.VVQeeT     ,
   "5"     : self.VVQeeT     ,
   "6"     : self.VVQeeT     ,
   "7"     : self.VVQeeT     ,
   "8"     : self.VVQeeT     ,
   "9"     : self.VVQeeT
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVt34v()
  self.onShown.append(self.VVHk7P)
  self.onClose.append(self.onExit)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self["myLabel"].setText(self.message)
  self.VVitPU()
  if self.VVsowu : self.VVmNjb()
  else    : self.VVOYri()
  FFbK0m(self)
  FFYzPI(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVEL3r)
  except:
   self.timer.callback.append(self.VVEL3r)
 def onExit(self):
  self.timer.stop()
 def VVNc06(self):
  self.VVORM5()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVORM5()
  self.close(None)
 def VV0acM(self):
  VVhjJY = []
  VVhjJY.append(("Home"         , "home"    ))
  VVhjJY.append(("End"         , "end"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Clear All"       , "clearAll"   ))
  VVhjJY.append(("Clear To Home"      , "clearToHome"   ))
  VVhjJY.append(("Clear To End"       , "clearToEnd"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVjBnN:
   VVhjJY.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("To Capital Letters"     , "toCapital"   ))
  VVhjJY.append(("To Small Letters"      , "toSmall"    ))
  FFmvQ5(self, self.VVgl9T, title="Edit Options", VVhjJY=VVhjJY)
 def VVgl9T(self, item=None):
  if item is not None:
   if   item == "home"     : self.VV6qrO()
   elif item == "end"     : self.VVj9oQ()
   elif item == "clearAll"    : self.VVyxLV()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VV6qrO()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVjBnN
    VVjBnN = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVjBnN)
    self.VV6qrO()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVEL3r(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVmNjb(self):
  self["myInput"].toggleOverwrite()
  self.VVOYri()
 def VVuSE9(self):
  self.session.openWithCallback(self.VVFC7q, boundFunction(CCl4HC, mode=self.charMode, VVylAc=self.VVylAc))
 def VVFC7q(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVitPU()
 def VVOYri(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVt34v(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVORM5(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVNtHX(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVFdLQ(self)     : self.VVcePD(self["myInput"].left)
 def VVUOm2(self)     : self.VVcePD(self["myInput"].right)
 def VV6AK7(self)     : self.VVcePD(self["myInput"].delete)
 def VV6qrO(self)     : self.VVcePD(self["myInput"].home)
 def VVj9oQ(self)     : self.VVcePD(self["myInput"].end)
 def VVYaNP(self)    : self.VVcePD(self["myInput"].deleteBackward)
 def VVCPSM(self)     : self.VVcePD(self["myInput"].tab)
 def VVyxLV(self)     : self["myInput"].setText("")
 def VVcePD(self, fnc):
  fnc()
  self.VVEL3r()
 def VVQeeT(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVNtHX(newChar, overwrite)
   self.VVUUwH(newChar, self["myInput"].mapping[number])
 def VVp0hd(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCl4HC.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCl4HC.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVNtHX(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVUUwH(newChar, group)
     break
 def VVUUwH(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVpw0r:
    group = VVho0k + group.replace(newChar, FF34IZ(newChar, VVpw0r, VVho0k))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVMgyx(self):
  if self.VVylAc : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVitPU()
 def VVitPU(self):
  self["myInput"].mapping = CCl4HC.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCl4HC.RCU_MAP_TITLES[self.charMode])
class CCl4HC(Screen):
 VVCpVr  = 0
 VVQl6g  = 1
 VVcj30  = 2
 VVyl3L  = 3
 VVPirk = 4
 VVjZtB = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVCpVr, VVylAc=False):
  self.skin, self.skinParam = FFuMnj(VVhFAf, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVylAc  = VVylAc
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFgoqU(self, title=self.Title)
  FFmNCq(self["keyRed"] ,"OK = Select")
  FFmNCq(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxTyE     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVjgv1, -1) ,
   "next"  : boundFunction(self.VVjgv1, +1) ,
   "left"  : boundFunction(self.VVjgv1, -1) ,
   "right"  : boundFunction(self.VVjgv1, +1) ,
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FFYzPI(self["keyRed"], "#11222222")
  FFYzPI(self["keyGreen"], "#11222222")
  self.VVJMOa()
 def VVJMOa(self):
  self.VVwb5y()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVwb5y(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVjgv1(self, direction):
  if self.VVylAc : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVJMOa()
 def VVxTyE(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CC5gEw(Screen):
 def __init__(self, session, title="", message="", VV9aL5=VVhB6f, VVGDsG=False, VVauqk=None, VVhj1e=30):
  self.skin, self.skinParam = FFuMnj(VVlcNn, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVhj1e)
  self.session   = session
  FFgoqU(self, title, addScrollLabel=True)
  self.VV9aL5   = VV9aL5
  self.VVGDsG   = VVGDsG
  self.VVauqk   = VVauqk
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self["myLabel"].VV36kJ(VVGDsG=self.VVGDsG)
  self["myLabel"].setText(self.message, self.VV9aL5)
  if self.VVauqk:
   FFYzPI(self["myBody"], self.VVauqk)
   FFYzPI(self["myLabel"], self.VVauqk)
   FFcSxA(self["myLabel"], self.VVauqk)
  self["myLabel"].VVyPlD()
class CCTy4c(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFuMnj(VV2Yz5, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFgoqU(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  path = VVVIGI + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CClGFA(Screen, CCN49V):
 PLAYER_INSTANCE = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False):
  self.skin, self.skinParam = FFuMnj(VV4xK4, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCN49V.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFgoqU(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVRR9e())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWwkM         ,
   "info"  : self.VVXc25        ,
   "epg"  : self.VVXc25        ,
   "menu"  : self.FFmvQ5         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVFasU        ,
   "green"  : boundFunction(self.VVCl1I, True),
   "play"  : self.VV3VIn        ,
   "pause"  : self.VV3VIn        ,
   "stop"  : self.VV3VIn        ,
   "left"  : boundFunction(self.VVJiSX, -1)   ,
   "right"  : boundFunction(self.VVJiSX,  1)   ,
   "rewind" : self.VVyPnM        ,
   "forward" : self.VVkB3e        ,
   "last"  : boundFunction(self.VVjOCE, 0)    ,
   "next"  : self.VVA9uk        ,
   "pageUp" : boundFunction(self.VV2R12, True) ,
   "pageDown" : boundFunction(self.VV2R12, False) ,
   "chanUp" : boundFunction(self.VV2R12, True) ,
   "chanDown" : boundFunction(self.VV2R12, False) ,
   "up"  : boundFunction(self.VV2R12, True) ,
   "down"  : boundFunction(self.VV2R12, False) ,
   "0"   : boundFunction(self.VVSpMk , 10)  ,
   "1"   : boundFunction(self.VVSpMk , 1)  ,
   "2"   : boundFunction(self.VVSpMk , 2)  ,
   "3"   : boundFunction(self.VVSpMk , 3)  ,
   "4"   : boundFunction(self.VVSpMk , 4)  ,
   "5"   : boundFunction(self.VVSpMk , 5)  ,
   "6"   : boundFunction(self.VVSpMk , 6)  ,
   "7"   : boundFunction(self.VVSpMk , 7)  ,
   "8"   : boundFunction(self.VVSpMk , 8)  ,
   "9"   : boundFunction(self.VVSpMk , 9)
  }, -1)
  self.onShown.append(self.VVHk7P)
  self.onClose.append(self.onExit)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  if not CClGFA.PLAYER_INSTANCE or self.portalTableParam:
   CClGFA.PLAYER_INSTANCE = self
  else:
   self.close()
  self.VV8RMF()
  self.instance.move(ePoint(40, 40))
  self.VV3fda(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVw1hj)
  except:
   self.timer.callback.append(self.VVw1hj)
  self.timer.start(250, False)
  self.VVw1hj("Checking ...")
  self.VVCl1I()
 def onExit(self):
  self.timer.stop()
  CClGFA.PLAYER_INSTANCE = None
 def VV8RMF(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFYzPI(self["myTitle"], color)
 def FFmvQ5(self):
  VVhjJY = []
  if self.isFromExternal:
   VVhjJY.append(("IPTV Menu" , "iptv" ))
   VVhjJY.append(VVeSPq)
  VVhjJY.append(("Move to Top"  , "top"  ))
  VVhjJY.append(("Move to Bottom" , "botm" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Help"    , "help" ))
  FFmvQ5(self, self.VVFrvP, VVhjJY=VVhjJY, width=500, title="Options")
 def VVFrvP(self, item=None):
  if item:
   if item == "iptv"  :
    self.session.open(CCRT5i)
    self.close()
   elif item == "botm"  : self.VV3fda(0)
   elif item == "top"  : self.VV3fda(1)
   elif item == "help"  : FFmkwn(self, VVVIGI + "_help_player", "Player Controller (Keys)")
 def VV3fda(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVWwkM(self):
  if self.isManualSeek:
   self.VVGSnv()
   self.VVjOCE(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVGSnv()
  else:
   self.close()
 def VVXc25(self):
  FF9kJ8(self, fncMode=CCS14C.VVauHr)
 def VV3VIn(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVw1hj("Toggling Play/Pause ...")
 def VVGSnv(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVJiSX(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVvkAh()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FF3oWp(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFXuQi(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FF4dJc(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVSpMk(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFmNCq(self["myPlayJmp"], self.VVRR9e())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVw1hj("Changed Jump Minutes to : %d" % val)
 def VVRR9e(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVw1hj(self, stateTxt=""):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
  fr = res = ""
  if info:
   w = FFFIZe(info, iServiceInformation.sVideoWidth) or -1
   h = FFFIZe(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFFIZe(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCS14C.VVSuWc(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVvkAh()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FF3oWp(percVal, 0, 100)
    width = int(FFXuQi(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   FF55DC(self["myPlayMsg"], "#00ff8066")
   self["myPlayMsg"].setText("-" if decodedUrl else FFl7Hp(refCode, True))
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not durTxt:
   self["myPlayVal"].setText(">>>>>")
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText(prov)
  if not posTxt:
   self["myPlayPos"].setText("")
  if not remTxt:
   self["myPlayRem"].setText("")
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVHdO9() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   FF55DC(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVtGdW()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVjOCE(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VV2Kff()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FF55DC(self["myPlayMsg"], "#0000ff00")
  else     : FF55DC(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVvkAh(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF4dJc(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF4dJc(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FF4dJc(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVFasU(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVHdO9()
   if cList:
    VVhjJY = []
    for pts, what in cList:
     txt = FF4dJc(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVhjJY.append((txt, pts))
    FFmvQ5(self, self.VVXvPN, VVhjJY=VVhjJY, title="Cut List")
   else:
    self.VVw1hj("No Cut-List for this channel !")
 def VVXvPN(self, item=None):
  if item:
   self.VVjOCE(item)
 def VVHdO9(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVkB3e(self) : self.VVgzuO(self.jumpMinutes)
 def VVyPnM(self) : self.VVgzuO(-self.jumpMinutes)
 def VVgzuO(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVw1hj("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVw1hj("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVw1hj("Cannot jump")
 def VVM5J2(self):
  InfoBar.instance.VVM5J2()
 def VVjOCE(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVw1hj("Changing Time ...")
 def VVA9uk(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVvkAh()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVw1hj("Jumping to end ...")
  except:
   pass
 def VVtGdW(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV2Kff(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV2R12(self, isUp):
  if self.enableZapping:
   self.VVw1hj("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVGSnv()
   if self.portalTableParam:
    self.VV8VYx(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VV8RMF()
    self.VVCl1I()
 def VV8VYx(self, isUp):
  CCRT5i_inatance, VV8kdg, mode = self.portalTableParam
  if isUp : VV8kdg.VVvN8F()
  else : VV8kdg.VVIKKn()
  FFdDg8(VV8kdg, boundFunction(self.VVFvv9, mode, VV8kdg, CCRT5i_inatance), title="Playing ...")
 def VVFvv9(self, mode, VV8kdg, CCRT5i_inatance):
  colList = VV8kdg.VVekGi()
  if mode == "localIptv":
   CCRT5i_inatance.VVOuA2(True, VV8kdg, "", "", colList)
  elif isinstance(mode, int):
   CCRT5i_inatance.VVt8hk(mode, True, VV8kdg, "", "", colList)
  else:
   CCRT5i_inatance.VVnjCw(mode, True, VV8kdg, "", "", colList)
  self.close()
 def VVCl1I(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVvkAh()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFI5ot(self)
   if not self.VV0C5a(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVw1hj("Refreshing Portal")
   FFC95U(self.VVeGzi)
  except:
   pass
 def VVeGzi(self):
  self.restoreLastPlayPos = self.VVIB8k()
class CCTGG4(Screen):
 def __init__(self, session, title="", VVWn1k="Continue?", VVbPNx=True, VVUw2L=False):
  self.skin, self.skinParam = FFuMnj(VVjxSB, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVWn1k = VVWn1k
  self.VVUw2L = VVUw2L
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVbPNx : VVhjJY = [no , yes]
  else   : VVhjJY = [yes, no ]
  FFgoqU(self, title, VVhjJY=VVhjJY, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWwkM ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVWn1k)
  if self.VVUw2L:
   self["myLabel"].instance.setHAlign(0)
  self.VVNPnB()
  FF9iGG(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFbRrW(self["myMenu"])
  FFbIom(self, self["myMenu"])
 def VVWwkM(self):
  item = FFcqFA(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVNPnB(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCgs9B(Screen):
 def __init__(self, session, title="", VVhjJY=None, width=1000, OKBtnFnc=None, VVvGoO=None, VVHAYN=None, VVbBdV=None, VVKkqL=None, VV14tH=False, VV4UKo=False):
  self.skin, self.skinParam = FFuMnj(VVXcKu, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVhjJY   = VVhjJY
  self.OKBtnFnc   = OKBtnFnc
  self.VVvGoO   = VVvGoO
  self.VVHAYN  = VVHAYN
  self.VVbBdV  = VVbBdV
  self.VVKkqL   = VVKkqL
  self.VV14tH  = VV14tH
  self.VV4UKo  = VV4UKo
  FFgoqU(self, title, VVhjJY=VVhjJY)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWwkM          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVvcz1         ,
   "green"  : self.VV1bZb         ,
   "yellow" : self.VVYYjW         ,
   "blue"  : self.VVj76w         ,
   "pageUp" : self.VVNeLg       ,
   "chanUp" : self.VVNeLg       ,
   "pageDown" : self.VVT9BM        ,
   "chanDown" : self.VVT9BM
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["myMenu"])
  FFHC43(self)
  self.VVQn63(self["keyRed"]  , self.VVvGoO )
  self.VVQn63(self["keyGreen"] , self.VVHAYN )
  self.VVQn63(self["keyYellow"] , self.VVbBdV )
  self.VVQn63(self["keyBlue"]  , self.VVKkqL )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFbK0m(self)
 def VVQn63(self, btnObj, btnFnc):
  if btnFnc:
   FFmNCq(btnObj, btnFnc[0])
 def VVWwkM(self):
  item = FFcqFA(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV14tH: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVvcz1(self)  : self.VVcePD(self.VVvGoO)
 def VV1bZb(self) : self.VVcePD(self.VVHAYN)
 def VVYYjW(self) : self.VVcePD(self.VVbBdV)
 def VVj76w(self) : self.VVcePD(self.VVKkqL)
 def VVcePD(self, btnFnc):
  if btnFnc:
   item = FFcqFA(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV4UKo:
    self.cancel()
 def VVFsii(self, VVhjJY):
  if len(VVhjJY) > 0:
   newList = []
   for item in VVhjJY:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVv8vk(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVNeLg(self):
  self["myMenu"].moveToIndex(0)
 def VVT9BM(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC3L8C(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VV8klC=None, VVenpJ=None, VVxJaI=None, VVhj1e=26, VVWA0Q=False, VVR5hp=None, VVkGsu=None, VV6Yzq=None, VVB3WF=None, VVRYtq=None, VVn2KW=None, VVr83J=None, VV0KAt=None, VVFJFw=None, VVldcK=-1, VVTjTb=False, searchCol=0, VVHOIE=None, VVsOU8=None, VVi9Zk="#00dddddd", VVauqk="#11002233", VVp86P="#00ff8833", VVMVsE="#11111111", VVHcAW="#0a555555", VVJ3mG="#0affffff", VV7rwH="#11552200", VVmF6M="#0055ff55"):
  self.skin, self.skinParam = FFuMnj(VVW5aH, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFgoqU(self, title)
  self.header     = header
  self.VV8klC     = VV8klC
  self.totalCols    = len(VV8klC[0])
  self.VVYXCN   = 0
  self.lastSortModeIsReverese = False
  self.VVWA0Q   = VVWA0Q
  self.VVolKr   = 0.01
  self.VVsUCT   = 0.02
  self.VVV4Hs  = 1
  self.VVxJaI = VVxJaI
  self.colWidthPixels   = []
  self.VVR5hp   = VVR5hp
  self.OKButtonObj   = None
  self.VVkGsu   = VVkGsu
  self.VV6Yzq   = VV6Yzq
  self.VVB3WF   = VVB3WF
  self.VVRYtq  = VVRYtq
  self.VVn2KW   = VVn2KW
  self.VVr83J    = VVr83J
  self.VV0KAt   = VV0KAt
  self.VVFJFw  = VVFJFw
  self.VVldcK    = VVldcK
  self.VVTjTb   = VVTjTb
  self.searchCol    = searchCol
  self.VVenpJ    = VVenpJ
  self.keyPressed    = -1
  self.VVhj1e    = FFi9Up(VVhj1e)
  self.VVRjt3    = FFBQr7(self.VVhj1e, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVHOIE    = VVHOIE
  self.VVsOU8      = VVsOU8
  self.VVi9Zk    = FFpT1f(VVi9Zk)
  self.VVauqk    = FFpT1f(VVauqk)
  self.VVp86P    = FFpT1f(VVp86P)
  self.VVMVsE    = FFpT1f(VVMVsE)
  self.VVHcAW   = FFpT1f(VVHcAW)
  self.VVJ3mG    = FFpT1f(VVJ3mG)
  self.VV7rwH    = FFpT1f(VV7rwH)
  self.VVmF6M   = FFpT1f(VVmF6M)
  self.VVjaPy  = False
  self.selectedItems   = 0
  self.VVGifu   = FFpT1f("#01fefe01")
  self.VVE39a   = FFpT1f("#11400040")
  self.VVGBqU  = self.VVGifu
  self.VVHWo5  = self.VVMVsE
  if self.VVTjTb:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVQTrT  ,
   "red"   : self.VVoMMS  ,
   "green"   : self.VV01tZ ,
   "yellow"  : self.VVzTKz ,
   "blue"   : self.VVdPO5  ,
   "menu"   : self.VVPMmq ,
   "info"   : self.VVazqU  ,
   "cancel"  : self.VVXBwt  ,
   "up"   : self.VVIKKn    ,
   "down"   : self.VVvN8F  ,
   "left"   : self.VVr6HV   ,
   "right"   : self.VVq8G3  ,
   "pageUp"  : self.VVVJ9X  ,
   "chanUp"  : self.VVVJ9X  ,
   "pageDown"  : self.VVZXGg  ,
   "chanDown"  : self.VVZXGg
  }, -1)
  FFE1I9(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  try:
   self.VV3BeZ()
  except Exception as err:
   FFdx4k(self, str(err))
   self.close(None)
 def VV3BeZ(self):
  FFbK0m(self)
  if self.VVHOIE:
   FFYzPI(self["myTitle"], self.VVHOIE)
  if self.VVsOU8:
   FFYzPI(self["myBody"] , self.VVsOU8)
   FFYzPI(self["myTableH"] , self.VVsOU8)
   FFYzPI(self["myTable"] , self.VVsOU8)
   FFYzPI(self["myBar"]  , self.VVsOU8)
  self.VVQn63(self.VV6Yzq  , self["keyRed"])
  self.VVQn63(self.VVB3WF  , self["keyGreen"])
  self.VVQn63(self.VVRYtq , self["keyYellow"])
  self.VVQn63(self.VVn2KW  , self["keyBlue"])
  if self.VVR5hp:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVR5hp[0])
    FFYzPI(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVRjt3)
  self["myTableH"].l.setFont(0, gFont(VVD1DD, self.VVhj1e))
  self["myTable"].l.setItemHeight(self.VVRjt3)
  self["myTable"].l.setFont(0, gFont(VVD1DD, self.VVhj1e))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVRjt3)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVRjt3))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVRjt3)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVRjt3
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVRjt3 * len(self.VV8klC) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVxJaI:
   self.VVxJaI = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVxJaI)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVenpJ:
   self.VVenpJ = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVenpJ
   self.VVenpJ = []
   for item in tmpList:
    self.VVenpJ.append(item | RT_VALIGN_CENTER)
  self.VV4el2()
  if self.VVr83J:
   self.VVr83J(self)
 def VVQn63(self, btnFnc, btn):
  if btnFnc : FFmNCq(btn, btnFnc[0])
  else  : FFmNCq(btn, "")
 def VVSErf(self, waitTxt):
  FFdDg8(self, self.VV4el2, title=waitTxt)
 def VV4el2(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVuqXn(0, self.header, self.VVJ3mG, self.VV7rwH, self.VVJ3mG, self.VV7rwH, self.VVmF6M)])
   rows = []
   for c, row in enumerate(self.VV8klC):
    rows.append(self.VVuqXn(c, row, self.VVi9Zk, self.VVauqk, self.VVp86P, self.VVMVsE, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVldcK > -1:
    self["myTable"].moveToIndex(self.VVldcK )
   self.VVmOep()
   if self.VVTjTb:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVRjt3 * len(self.VV8klC)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VV0KAt:
    self.VVcePD(self.VV0KAt, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFdx4k(self, str(err))
    self.close()
   except:
    pass
 def VVuqXn(self, keyIndex, columns, VVi9Zk, VVauqk, VVp86P, VVMVsE, VVmF6M):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVmF6M and ndx == self.VVYXCN : textColor = VVmF6M
   else           : textColor = VVi9Zk
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.+)", entry, IGNORECASE)
   if span:
    c = FFpT1f(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVauqk = c
    entry = span.group(3)
   if self.VVenpJ[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVRjt3)
           , font   = 0
           , flags   = self.VVenpJ[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVauqk
           , color_sel  = VVp86P
           , backcolor_sel = VVMVsE
           , border_width = 1
           , border_color = self.VVHcAW
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVazqU(self):
  rowData = self.VVxYlS()
  if rowData:
   title, txt, colList = rowData
   if self.VVkGsu:
    fnc  = self.VVkGsu[1]
    params = self.VVkGsu[2]
    fnc(self, title, txt, colList)
   else:
    FFh3cd(self, txt, title)
 def VVQTrT(self):
  if   self.VVjaPy : self.VV3Tlh(self.VVvjAB(), mode=2)
  elif self.VVR5hp  : self.VVcePD(self.VVR5hp, None)
  else      : self.VVazqU()
 def VVoMMS(self) : self.VVcePD(self.VV6Yzq , self["keyRed"])
 def VV01tZ(self) : self.VVcePD(self.VVB3WF , self["keyGreen"])
 def VVzTKz(self): self.VVcePD(self.VVRYtq , self["keyYellow"])
 def VVdPO5(self) : self.VVcePD(self.VVn2KW , self["keyBlue"])
 def VVcePD(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFbo0g(self, buttonFnc[3])
    FFC95U(boundFunction(self.VVdzGP, buttonFnc))
   else:
    self.VVdzGP(buttonFnc)
 def VVdzGP(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVxYlS()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV3Tlh(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV8klC[ndx]
   isSelected = row[1][9] == self.VVGifu
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVuqXn(ndx, item, self.VVi9Zk, self.VVauqk, self.VVp86P, self.VVMVsE, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVuqXn(ndx, item, self.VVGifu, self.VVE39a, self.VVGBqU, self.VVHWo5, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVmOep()
 def VV08GV(self):
  FFdDg8(self, self.VVUZ6U, title="Selecting all ...")
 def VVUZ6U(self):
  self.VV8eq6(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVGifu
   if not isSelected:
    item = self.VV8klC[ndx]
    newRow = self.VVuqXn(ndx, item, self.VVGifu, self.VVE39a, self.VVGBqU, self.VVHWo5, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVmOep()
  self.VVfLQA()
 def VVHHx7(self):
  FFdDg8(self, self.VVImXB, title="Unselecting all ...")
 def VVImXB(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVGifu:
    item = self.VV8klC[ndx]
    newRow = self.VVuqXn(ndx, item, self.VVi9Zk, self.VVauqk, self.VVp86P, self.VVMVsE, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVmOep()
  self.VVfLQA()
 def VVfLQA(self):
  self.hide()
  self.show()
 def VVxYlS(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVxJaI[i] > 1 or self.VVxJaI[i] == self.VVolKr:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VV8klC))
   return rowNum, txt, colList
  else:
   return None
 def VVXBwt(self):
  if self.VVFJFw : self.VVFJFw(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVvELd(self):
  return self["myTitle"].getText().strip()
 def VVJeJA(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVp4RP(self, txt):
  FFbo0g(self, txt)
 def VVhdSv(self, txt):
  FFbo0g(self, txt, 1000)
 def VVr9ZM(self):
  FFbo0g(self)
 def VVv8M5(self):
  return len(self.VV8klC)
 def VVOv4b(self): self["keyGreen"].show()
 def VVHpq5(self): self["keyGreen"].hide()
 def VVvjAB(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVQFOb(self):
  return len(self["myTable"].list)
 def VV8eq6(self, isOn):
  self.VVjaPy = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVn2KW: self["keyBlue"].hide()
   if self.VVR5hp and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVn2KW: self["keyBlue"].show()
   if self.VVR5hp and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVR5hp[0])
   self.VVHHx7()
  FFYzPI(self["myTitle"], color)
  FFYzPI(self["myBar"]  , color)
 def VVL6ID(self):
  return self.VVjaPy
 def VVqK6p(self):
  return self.selectedItems
 def VVZXGi(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVmOep()
 def VVpWXt(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVmOep()
 def VVMGC2(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV8klC:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVhzB6(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVv8M5()
  txt += FF03HQ("Total Unique Items", VVP2je)
  for i in range(self.totalCols):
   if self.VVxJaI[i - 1] > 1 or self.VVxJaI[i - 1] == self.VVolKr:
    name, tot = self.VVMGC2(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFh3cd(self, txt)
 def VVJPyb(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVekGi(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVmRNB(self, newList, newTitle=""):
  if newList:
   self.VV8klC = newList
   if self.VVWA0Q and self.VVYXCN == 0:
    self.VV8klC = sorted(self.VV8klC, key=lambda x: int(x[self.VVYXCN])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV8klC = sorted(self.VV8klC, key=lambda x: x[self.VVYXCN].lower(), reverse=self.lastSortModeIsReverese)
   self.VVSErf("Refreshing ...")
   if newTitle:
    self.VVJeJA(newTitle)
  else:
   FFdx4k(self, "Cannot refresh list")
   self.cancel()
 def VVRKTL(self, data):
  ndx = self.VVvjAB()
  newRow = self.VVuqXn(ndx, data, self.VVi9Zk, self.VVauqk, self.VVp86P, self.VVMVsE, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVmOep()
   return True
  else:
   return False
 def VVNoAg(self, colNum, textToFind, VVpwCo=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVmOep()
    break
  else:
   if VVpwCo:
    FFbo0g(self, "Not found", 1000)
 def VVwBkd(self, colDict, VVpwCo=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVmOep()
    return
  if VVpwCo:
   FFbo0g(self, "Not found", 1000)
 def VVwBkd_partial(self, colDict, VVpwCo=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVmOep()
    return
  if VVpwCo:
   FFbo0g(self, "Not found", 1000)
 def VV28sP(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVpXLl(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVGifu:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVGUJf(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVPMmq(self):
  if not self["keyMenu2F"].getVisible() or self.VVTjTb:
   return
  VVhjJY = []
  VVhjJY.append(("Table Statistcis"             , "tableStat"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append((FF34IZ("Export Table to .html"     , VVP2je) , "VVEZHY" ))
  VVhjJY.append((FF34IZ("Export Table to .csv"     , VVP2je) , "VV0wFA" ))
  VVhjJY.append((FF34IZ("Export Table to .txt (Tab Separated)", VVP2je) , "VVcAqc" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVxJaI[i] > 1 or self.VVxJaI[i] == self.VVsUCT:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVhjJY.append(VVeSPq)
   if tot == 1 : VVhjJY.append(("Sort", sList[0][1]))
   else  : VVhjJY += sList
  FFmvQ5(self, self.VVsdp0, VVhjJY=VVhjJY, title=self.VVvELd())
 def VVsdp0(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVhzB6()
   elif item == "VVEZHY": FFdDg8(self, self.VVEZHY, title=title)
   elif item == "VV0wFA" : FFdDg8(self, self.VV0wFA , title=title)
   elif item == "VVcAqc" : FFdDg8(self, self.VVcAqc , title=title)
   else:
    isReversed = False
    if self.VVYXCN == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVWA0Q and item == 0:
     self.VV8klC = sorted(self.VV8klC, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV8klC = sorted(self.VV8klC, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVYXCN = item
    self.VVSErf("Sorting ...")
 def VVIKKn(self):
  self["myTable"].up()
  self.VVmOep()
 def VVvN8F(self):
  self["myTable"].down()
  self.VVmOep()
 def VVr6HV(self):
  self["myTable"].pageUp()
  self.VVmOep()
 def VVq8G3(self):
  self["myTable"].pageDown()
  self.VVmOep()
 def VVVJ9X(self):
  self["myTable"].moveToIndex(0)
  self.VVmOep()
 def VVZXGg(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVmOep()
 def VVcAqc(self):
  expFile = self.VVqaMI() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV8o33()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV8klC:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVxJaI[ndx] > self.VVV4Hs:
      col = self.VVdeyf(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVh8eR(expFile)
 def VV0wFA(self):
  expFile = self.VVqaMI() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV8o33()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV8klC:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVxJaI[ndx] > self.VVV4Hs:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVdeyf(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVh8eR(expFile)
 def VVEZHY(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVvELd(), PLUGIN_NAME, VVU39M)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVvELd()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV8o33()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVxJaI:
   colgroup += '   <colgroup>'
   for w in self.VVxJaI:
    if w > self.VVV4Hs:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVqaMI() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV8klC:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVxJaI[ndx] > self.VVV4Hs:
      col = self.VVdeyf(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVh8eR(expFile)
 def VV8o33(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVxJaI[ndx] > self.VVV4Hs:
     newRow.append(col.strip())
  return newRow
 def VVdeyf(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFdqBS(col)
 def VVqaMI(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVvELd())
  fileName = fileName.replace("__", "_")
  path  = FFoGIr(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFmJh3()
  return expFile
 def VVh8eR(self, expFile):
  FFUbus(self, "File exported to:\n\n%s" % expFile, title=self.VVvELd())
 def VVmOep(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCEP0s(Screen):
 def __init__(self, session, Title="", VViC2s=None):
  self.skin, self.skinParam = FFuMnj(VVpQFS, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFgoqU(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VViC2s = VViC2s
  if len(Title) == 0 : Title = FFRiG8()
  else    : Title = "File : %s" % VViC2s
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  allOK = FFGkqs(self["myLabel"], self.VViC2s)
  if not allOK:
   FFdx4k(self, "Could not view this picture file")
   self.close()
class CCg4Sp(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFuMnj(VVn9gY, 1400, 950, 50, 40, 40, "#11201010", "#11101010", 30, barHeight=40, topRightBtns=1)
  self.session  = session
  FFgoqU(self)
  FFmNCq(self["keyGreen"], "Save")
  self.VV8klC = []
  self.VV8klC.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VV8klC.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VV8klC.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VV8klC.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VV8klC.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  self.VV8klC.append(getConfigListEntry(VVbwqB *2            ,         ))
  self.VV8klC.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VV8klC.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VV8klC.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VV8klC.append(getConfigListEntry(VVbwqB *2            ,         ))
  self.VV8klC.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VV8klC.append(getConfigListEntry(VVbwqB *2            ,         ))
  self.VV8klC.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VV8klC.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VV8klC.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VV8klC.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VV8klC.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VV8klC, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVWwkM   ,
   "OK"  : self.VVWwkM   ,
   "green"  : self.VV6E1n  ,
   "menu"  : self.VVR2KN ,
   "cancel" : self.VV0HwL
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FF9iGG(self["config"])
  FFHC43(self,  self["config"])
  FFbK0m(self)
 def VVWwkM(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VVwBtd(item)
   elif item == CFG.backupPath    : self.VVwBtd(item)
   elif item == CFG.packageOutputPath  : self.VVwBtd(item)
   elif item == CFG.downloadedPackagesPath : self.VVwBtd(item)
   elif item == CFG.exportedTablesPath  : self.VVwBtd(item)
   elif item == CFG.exportedPIconsPath  : self.VVwBtd(item)
 def VVwBtd(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VVe2nY, configObj)
         , boundFunction(CCZMP9, mode=CCZMP9.VV2fF7, VVXM9l=sDir))
 def VVe2nY(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV0HwL(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFT4Vd(self, self.VV6E1n, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VV6E1n(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV5AMv()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVR2KN(self):
  VVhjJY = []
  VVhjJY.append(("Use Backup directory in all other paths"      , "VVCC1a"   ))
  VVhjJY.append(("Reset all to default (including File Manager bookmarks)"  , "VVvet8"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Backup %s Settings" % PLUGIN_NAME        , "VVKydp"  ))
  VVhjJY.append(("Restore %s Settings" % PLUGIN_NAME       , "VVETKo"  ))
  if fileExists(VVTiP2 + VVdOEs):
   VVhjJY.append(VVeSPq)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVhjJY.append(('%s Checking for Update' % txt1       , txt2     ))
   VVhjJY.append(("Reinstall %s" % PLUGIN_NAME        , "VVbAkL"  ))
   VVhjJY.append(("Update %s" % PLUGIN_NAME        , "VVKNOQ"   ))
  FFmvQ5(self, self.VVMMkq, VVhjJY=VVhjJY, title="Config. Options")
 def VVMMkq(self, item=None):
  if item:
   if   item == "VVCC1a"  : FFT4Vd(self, self.VVCC1a , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVvet8"  : FFT4Vd(self, self.VVvet8, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCGqtk)
   elif item == "VVKydp" : self.VVKydp()
   elif item == "VVETKo" : FFdDg8(self, self.VVETKo, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVjAlC(True)
   elif item == "disableChkUpdate" : self.VVjAlC(False)
   elif item == "VVbAkL" : FFdDg8(self, self.VVbAkL , "Checking Server ...")
   elif item == "VVKNOQ"  : FFdDg8(self, self.VVKNOQ  , "Checking Server ...")
 def VVKydp(self):
  path = "%sajpanel_settings_%s" % (VVTiP2, FFmJh3())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFUbus(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVETKo(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFHErt("find / %s -iname '%s*' | grep %s" % (FFF164(1), name, name))
  if lines:
   lines.sort()
   VVhjJY = []
   for line in lines:
    VVhjJY.append((line, line))
   FFmvQ5(self, boundFunction(self.VVqNNQ, title), title=title, VVhjJY=VVhjJY, width=1200)
  else:
   FFdx4k(self, "No settings files found !", title=title)
 def VVqNNQ(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFPPAc(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VV5AMv()
    FFl7aG()
   else:
    FF5BoZ(SELF, path, title=title)
 def VVjAlC(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVCC1a(self):
  newPath = FFoGIr(VVTiP2)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV5AMv()
 @staticmethod
 def VVkqTN():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVvet8(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.PIconsPath.setValue(VVBrAU)
  CFG.backupPath.setValue(CCg4Sp.VVkqTN())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VV5AMv()
  self.close()
 def VV5AMv(self):
  configfile.save()
  global VVTiP2
  VVTiP2 = CFG.backupPath.getValue()
  FFl727()
 def VVKNOQ(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVOdYQ(title)
  if webVer:
   FFT4Vd(self, boundFunction(FFdDg8, self, boundFunction(self.VVXD7X, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVbAkL(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVOdYQ(title, True)
  if webVer:
   FFT4Vd(self, boundFunction(FFdDg8, self, boundFunction(self.VVXD7X, webVer, title)), "Install and Restart ?", title=title)
 def VVXD7X(self, webVer, title):
  url = self.VVNNZq(self, title)
  if url:
   VVgL4t = FFm75l() == "dpkg"
   if VVgL4t == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVgL4t else "ipk")
   path, err = FFgxGp(url + fName, fName, timeout=2)
   if path:
    cmd = FFBSlb(VVKhUe, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFTgBK(self, cmd)
    else:
     FFHvqH(self, title=title)
   else:
    FFdx4k(self, err, title=title)
 def VVOdYQ(self, title, anyVer=False):
  url = self.VVNNZq(self, title)
  if not url:
   return ""
  path, err = FFgxGp(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFdx4k(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFtCkf(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFdx4k(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVU39M.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFHErt(cmd)
   if list and curVer == list[0]:
    return webVer
  FFUbus(self, FF34IZ("No update required.", VVaENg) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVNNZq(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVTiP2 + VVdOEs
  if fileExists(path):
   span = iSearch(r"(http.+)", FFtCkf(path), IGNORECASE)
   if span : url = FFoGIr(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFdx4k(SELF, err, title)
  return url
 @staticmethod
 def VVYMXy(url):
  path, err = FFgxGp(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFtCkf(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVU39M.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFHErt(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCGqtk(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFuMnj(VV9oGS, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVQX76
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFgoqU(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVknl6("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVknl6("\c00888888", i) + sp + "GREY\n"
   txt += self.VVknl6("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVknl6("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVknl6("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVknl6("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVknl6("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVknl6("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVknl6("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVknl6("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVknl6("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVknl6("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVWwkM ,
   "green"   : self.VVWwkM ,
   "left"   : self.VVzYlM ,
   "right"   : self.VVtvtH ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  self.VVT3yn()
 def VVWwkM(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFT4Vd(self, self.VVeXat, "Change to : %s" % txt, title=self.Title)
 def VVeXat(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVQX76
  VVQX76 = self.cursorPos
  self.VVgGFD()
  self.close()
 def VVzYlM(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVT3yn()
 def VVtvtH(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVT3yn()
 def VVT3yn(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVknl6(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVZkkc(color):
  if VVBlp5: return "\\" + color
  else    : return ""
 @staticmethod
 def VVgGFD():
  global VVQAQ9, VVho0k, VVlb6B, VVP2je, VVHtZw, VVHecB, VVaENg, VVBlp5, COLOR_CONS_BRIGHT_YELLOW, VVmWy8, VVsahr, VVpw0r
  VVpw0r   = CCGqtk.VVknl6("\c00FFFFFF", VVQX76)
  VVho0k    = CCGqtk.VVknl6("\c00888888", VVQX76)
  VVQAQ9  = CCGqtk.VVknl6("\c005A5A5A", VVQX76)
  VVHecB    = CCGqtk.VVknl6("\c00FF0000", VVQX76)
  VVlb6B   = CCGqtk.VVknl6("\c00FF5000", VVQX76)
  VVBlp5   = CCGqtk.VVknl6("\c00FFFF00", VVQX76)
  COLOR_CONS_BRIGHT_YELLOW = CCGqtk.VVknl6("\c00FFFFAA", VVQX76)
  VVaENg   = CCGqtk.VVknl6("\c0000FF00", VVQX76)
  VVHtZw    = CCGqtk.VVknl6("\c000066FF", VVQX76)
  VVmWy8    = CCGqtk.VVknl6("\c0000FFFF", VVQX76)
  VVsahr   = CCGqtk.VVknl6("\c00FA55E7", VVQX76)
  VVP2je    = CCGqtk.VVknl6("\c00FF8F5F", VVQX76)
CCGqtk.VVgGFD()
class CC5HTk(Screen):
 def __init__(self, session, path, VVgL4t):
  self.skin, self.skinParam = FFuMnj(VVw4sR, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVGs85   = path
  self.VVAVR9   = ""
  self.VVlPkO   = ""
  self.VVgL4t    = VVgL4t
  self.VVpu95    = ""
  self.VVtEcY  = ""
  self.VVPcyH    = False
  self.VVJQm6  = False
  self.postInstAcion   = 0
  self.VVE0Ph  = "enigma2-plugin-extensions"
  self.VVuYjs  = "enigma2-plugin-systemplugins"
  self.VVQCAT = "enigma2"
  self.VV8Bb7  = 0
  self.VVglAk  = 1
  self.VV6NvV  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVEy0U = "DEBIAN"
  else        : self.VVEy0U = "CONTROL"
  self.controlPath = self.Path + self.VVEy0U
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVgL4t:
   self.packageExt  = ".deb"
   self.VVauqk  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVauqk  = "#11001020"
  FFgoqU(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFmNCq(self["keyRed"] , "Create")
  FFmNCq(self["keyGreen"] , "Post Install")
  FFmNCq(self["keyYellow"], "Installation Path")
  FFmNCq(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVmtP3  ,
   "green"   : self.VVua0T ,
   "yellow"  : self.VVB2KV  ,
   "blue"   : self.VVkdGd  ,
   "cancel"  : self.VV2b1X
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  FFbK0m(self)
  if self.VVauqk:
   FFYzPI(self["myBody"], self.VVauqk)
   FFYzPI(self["myLabel"], self.VVauqk)
  self.VVxw3O(True)
  self.VVzpO6(True)
 def VVzpO6(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV7PNY()
  if isFirstTime:
   if   package.startswith(self.VVE0Ph) : self.VVGs85 = VVDaUI + self.VVpu95 + "/"
   elif package.startswith(self.VVuYjs) : self.VVGs85 = VVZfME + self.VVpu95 + "/"
   else            : self.VVGs85 = self.Path
  if self.VVPcyH : myColor = VVP2je
  else    : myColor = VVpw0r
  txt  = ""
  txt += "Source Path\t: %s\n" % FF34IZ(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF34IZ(self.VVGs85, VVBlp5)
  if self.VVlPkO : txt += "Package File\t: %s\n" % FF34IZ(self.VVlPkO, VVho0k)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF34IZ("Check Control File fields : %s" % errTxt, VVlb6B)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF34IZ("Restart GUI", VVP2je)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF34IZ("Reboot Device", VVP2je)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FF34IZ("Post Install", VVaENg), act)
  if not errTxt and VVlb6B in controlInfo:
   txt += "Warning\t: %s\n" % FF34IZ("Errors in control file may affect the result package.", VVlb6B)
  txt += "\nControl File\t: %s\n" % FF34IZ(self.controlFile, VVho0k)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVua0T(self):
  VVhjJY = []
  VVhjJY.append(("No Action"    , "noAction"  ))
  VVhjJY.append(("Restart GUI"    , "VV6FiF"  ))
  VVhjJY.append(("Reboot Device"   , "rebootDev"  ))
  FFmvQ5(self, self.VVUIPZ, title="Package Installation Option (after completing installation)", VVhjJY=VVhjJY)
 def VVUIPZ(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV6FiF"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVxw3O(False)
   self.VVzpO6()
 def VVB2KV(self):
  rootPath = FF34IZ("/%s/" % self.VVpu95, VVQAQ9)
  VVhjJY = []
  VVhjJY.append(("Current Path"        , "toCurrent"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Extension Path"       , "toExtensions" ))
  VVhjJY.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVhjJY.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFmvQ5(self, self.VVhoz9, title="Installation Path", VVhjJY=VVhjJY)
 def VVhoz9(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVlNrY(FFDFii(self.Path, True))
   elif item == "toExtensions"  : self.VVlNrY(VVDaUI)
   elif item == "toSystemPlugins" : self.VVlNrY(VVZfME)
   elif item == "toRootPath"  : self.VVlNrY("/")
   elif item == "toRoot"   : self.VVlNrY("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVv9I2, boundFunction(CCZMP9, mode=CCZMP9.VV2fF7, VVXM9l=VVTiP2))
 def VVv9I2(self, path):
  if len(path) > 0:
   self.VVlNrY(path)
 def VVlNrY(self, parent, withPackageName=True):
  if withPackageName : self.VVGs85 = parent + self.VVpu95 + "/"
  else    : self.VVGs85 = "/"
  mode = self.VVvLpo()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV0jp3(mode), self.controlFile))
  self.VVzpO6()
 def VVkdGd(self):
  if fileExists(self.controlFile):
   lines = FFPPAc(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFktKm(self, self.VVTjdv, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFdx4k(self, "Version not found or incorrectly set !")
  else:
   FF5BoZ(self, self.controlFile)
 def VVTjdv(self, VVqjyy):
  if VVqjyy:
   version, color = self.VVaP7J(VVqjyy, False)
   if color == VVmWy8:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVqjyy, self.controlFile))
    self.VVzpO6()
   else:
    FFdx4k(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV2b1X(self):
  if self.newControlPath:
   if self.VVPcyH:
    self.VVowtS()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF34IZ(self.newControlPath, VVho0k)
    txt += FF34IZ("Do you want to keep these files ?", VVBlp5)
    FFT4Vd(self, self.close, txt, callBack_No=self.VVowtS, title="Create Package", VVUw2L=True)
  else:
   self.close()
 def VVowtS(self):
  os.system(FF0t1y("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV0jp3(self, mode):
  if   mode == self.VVglAk : prefix = self.VVE0Ph
  elif mode == self.VV6NvV : prefix = self.VVuYjs
  else        : prefix = self.VVQCAT
  return prefix + "-" + self.VVtEcY
 def VVvLpo(self):
  if   self.VVGs85.startswith(VVDaUI) : return self.VVglAk
  elif self.VVGs85.startswith(VVZfME) : return self.VV6NvV
  else            : return self.VV8Bb7
 def VVxw3O(self, isFirstTime):
  self.VVpu95   = os.path.basename(os.path.normpath(self.Path))
  self.VVpu95   = "_".join(self.VVpu95.split())
  self.VVtEcY = self.VVpu95.lower()
  self.VVPcyH = self.VVtEcY == VVAdrV.lower()
  if self.VVPcyH and self.VVtEcY.endswith("ajpan"):
   self.VVtEcY += "el"
  if self.VVPcyH : self.VVAVR9 = VVTiP2
  else    : self.VVAVR9 = CFG.packageOutputPath.getValue()
  self.VVAVR9 = FFoGIr(self.VVAVR9)
  if not pathExists(self.controlPath):
   os.system(FF0t1y("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVPcyH : t = PLUGIN_NAME
  else    : t = self.VVpu95
  self.VVKODN(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VV38ZS.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVPcyH : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVKODN(self.postrmFile, txt)
  if self.VVPcyH:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVU39M)
   self.VVKODN(self.preinstFile, txt)
  else:
   self.VVKODN(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVpu95)
  mode = self.VVvLpo()
  if isFirstTime and not mode == self.VV8Bb7:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVbwqB
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVKODN(self.postinstFile, txt, VVsowu=True)
  os.system(FF0t1y("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVPcyH : version, descripton, maintainer = VVU39M , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVpu95 , self.VVpu95
   txt = ""
   txt += "Package: %s\n"  % self.VV0jp3(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVKODN(self, path, lines, VVsowu=False):
  if not fileExists(path) or VVsowu:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV7PNY(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFPPAc(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF34IZ(line, VVlb6B)
     elif not line.startswith(" ")    : line = FF34IZ(line, VVlb6B)
     else          : line = FF34IZ(line, VVmWy8)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVmWy8
   else   : color = VVlb6B
   descr = FF34IZ(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVlb6B
     elif line.startswith((" ", "\t")) : color = VVlb6B
     elif line.startswith("#")   : color = VVho0k
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVaP7J(val, True)
      elif key == "Version"  : version, color = self.VVaP7J(val, False)
      elif key == "Maintainer" : maint  , color = val, VVmWy8
      elif key == "Architecture" : arch  , color = val, VVmWy8
      else:
       color = VVmWy8
      if not key == "OE" and not key.istitle():
       color = VVlb6B
     else:
      color = VVP2je
     txt += FF34IZ(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVlPkO = self.VVAVR9 + packageName
   self.VVJQm6 = True
   errTxt = ""
  else:
   self.VVlPkO  = ""
   self.VVJQm6 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVaP7J(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVmWy8
  else          : return val, VVlb6B
 def VVmtP3(self):
  if not self.VVJQm6:
   FFdx4k(self, "Please fix Control File errors first.")
   return
  if self.VVgL4t: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFDFii(self.VVGs85, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVpu95
  symlinkTo  = FFNOsT(self.Path)
  dataDir   = self.VVGs85.rstrip("/")
  removePorjDir = FF0t1y("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FF0t1y("rm -f '%s'" % self.VVlPkO) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFzWrJ()
  if self.VVgL4t:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFcnwo("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVPcyH:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVGs85 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVEy0U)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVlPkO, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVlPkO
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVlPkO, FF6vFh(result  , VVaENg))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVGs85, FF6vFh(instPath, VVmWy8))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF6vFh(failed, VVlb6B))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFTgBK(self, cmd)
class CCZMP9(Screen):
 VVVS8Z   = 0
 VV2fF7  = 1
 VVcRyg = 20
 def __init__(self, session, VVXM9l="/", mode=VVVS8Z, VVoqjh="Select", VVhj1e=30):
  self.skin, self.skinParam = FFuMnj(VVXcKu, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFgoqU(self)
  FFmNCq(self["keyRed"] , "Exit")
  FFmNCq(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVoqjh = VVoqjh
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVVS8Z  : VVlTbf, self.VVXM9l = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VV2fF7 : VVlTbf, self.VVXM9l = False, VVXM9l
  else           : VVlTbf, self.VVXM9l = True , VVXM9l
  VVXM9l = FFoGIr(VVXM9l)
  self["myMenu"] = CCjhxq(  directory   = "/"
         , VVlTbf   = VVlTbf
         , VVSnaB = True
         , VVHleR   = self.skinParam["width"]
         , VVhj1e   = self.skinParam["bodyFontSize"]
         , VVRjt3  = self.skinParam["bodyLineH"]
         , VVNnRO  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVWwkM      ,
   "red"    : self.cancel      ,
   "green"    : self.VVyX81    ,
   "yellow"   : self.VVTfQq   ,
   "blue"    : self.VVmVfX   ,
   "menu"    : self.VVAymy    ,
   "info"    : self.VVG71e    ,
   "cancel"   : self.VVgN8j     ,
   "pageUp"   : self.VVgN8j     ,
   "chanUp"   : self.VVgN8j
  }, -1)
  FFE1I9(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVTRCQ)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVTRCQ)
  FF9iGG(self["myMenu"], bg="#06003333")
  FFbK0m(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VV2fF7:
   FFmNCq(self["keyGreen"], self.VVoqjh)
   color = "#22000022"
   FFYzPI(self["myBody"], color)
   FFYzPI(self["myMenu"], color)
   color = "#22220000"
   FFYzPI(self["myTitle"], color)
   FFYzPI(self["myBar"], color)
  self.VVTRCQ()
  if self.VVjWbv(self.VVXM9l) > self.bigDirSize:
   FFbo0g(self, "Changing directory...")
   FFC95U(self.VVKnAS)
  else:
   self.VVKnAS()
 def VVKnAS(self):
  self["myMenu"].VVHBhl(self.VVXM9l)
 def VV7XkI(self):
  self["myMenu"].refresh()
  FFqgU2()
 def VVjWbv(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVWwkM(self):
  if self["myMenu"].VVUEG1():
   path = self.VVpLst(self.VVdAc1())
   if self.VVjWbv(path) > self.bigDirSize:
    FFbo0g(self, "Changing directory...")
    FFC95U(self.VVXJFY)
   else:
    self.VVXJFY()
  else:
   self.VV47Ju()
 def VVXJFY(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVTRCQ()
 def VVgN8j(self):
  if self["myMenu"].VVY8DA():
   self["myMenu"].moveToIndex(0)
   self.VVXJFY()
 def cancel(self):
  if not FFtBhW(self):
   self.close("")
 def VVyX81(self):
  if self.mode == self.VV2fF7:
   path = self.VVpLst(self.VVdAc1())
   self.close(path)
 def VVG71e(self):
  FFdDg8(self, self.VVe1yR, title="Calculating size ...")
 def VVe1yR(self):
  path = self.VVpLst(self.VVdAc1())
  param = self.VV9z5V(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFCpPs("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFCpPs("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVj2bS(size), format(size, ',d'))
   else   : size = "%s" % self.VVj2bS(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF34IZ(pathTxt, VVP2je) + "\n"
   if slBroken : fileTime = self.VVHvEP(path)
   else  : fileTime = self.VVIoOU(path)
   def VVwNVa(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVwNVa("Path"    , pathTxt)
   txt += VVwNVa("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVwNVa("Target"   , slTarget)
   txt += VVwNVa("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVwNVa("Owner"    , owner)
   txt += VVwNVa("Group"    , group)
   txt += VVwNVa("Perm. (User)"  , permUser)
   txt += VVwNVa("Perm. (Group)"  , permGroup)
   txt += VVwNVa("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVwNVa("Perm. (Ext.)" , permExtra)
   txt += VVwNVa("iNode"    , iNode)
   txt += VVwNVa("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVbwqB, VVbwqB)
    txt += hLinkedFiles
  else:
   FFdx4k(self, "Cannot access information !")
  if len(txt) > 0:
   FFh3cd(self, txt)
 def VV9z5V(self, path):
  path = path.strip()
  path = FFNOsT(path)
  result = FFCpPs("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVYK2v(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVYK2v(perm, 1, 4)
   permGroup = VVYK2v(perm, 4, 7)
   permOther = VVYK2v(perm, 7, 10)
   permExtra = VVYK2v(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFMlfy("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVIoOU(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFCnzX(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFCnzX(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFCnzX(os.path.getctime(path))
  return txt
 def VVHvEP(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFCpPs("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFCpPs("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFCpPs("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVj2bS(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVpLst(self, currentSel):
  currentDir  = self["myMenu"].VVY8DA()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVUEG1():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVdAc1(self):
  return self["myMenu"].getSelection()[0]
 def VVTRCQ(self):
  FFbo0g(self)
  path = self.VVpLst(self.VVdAc1())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV8klC = self.VVMOLN()
  if VV8klC and len(VV8klC) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVtftY(path)
  if self.mode == self.VVVS8Z and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVtftY(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVXpI1(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVAymy(self):
  if self.mode == self.VVVS8Z:
   path  = self.VVpLst(self.VVdAc1())
   isDir  = os.path.isdir(path)
   VVhjJY = []
   VVhjJY.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVqT0y(path):
     sepShown = True
     VVhjJY.append(VVeSPq)
     VVhjJY.append( (VVP2je + "Archiving / Packaging"      , "VVE0CW"  ))
    if self.VVMw2s(path):
     if not sepShown:
      VVhjJY.append(VVeSPq)
     VVhjJY.append( (VVP2je + "Read Backup information"     , "VVVcJu"  ))
     VVhjJY.append( (VVP2je + "Compress Octagon Image (to zip File)"  , "VV7vQP" ))
   elif os.path.isfile(path):
    selFile = self.VVdAc1()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVhjJY.extend(self.VV0LdA(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVhjJY.extend(self.VV85Xw(True))
    elif selFile.endswith(".m3u")              : VVhjJY.extend(self.VVgvCu(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF5o9M(path):
     VVhjJY.append(VVeSPq)
     VVhjJY.append((VVP2je + "View" , "text_View" ))
     VVhjJY.append((VVP2je + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVhjJY.append(VVeSPq)
     VVhjJY.append(   (VVP2je + txt      , "VV47Ju"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(     ("Create SymLink"       , "VVHp4j" ))
   if not self.VVqT0y(path):
    VVhjJY.append(   ("Rename"          , "VV5EAW" ))
    VVhjJY.append(   ("Copy"           , "copyFileOrDir" ))
    VVhjJY.append(   ("Move"           , "moveFileOrDir" ))
    VVhjJY.append(   ("DELETE"          , "VVzTzD" ))
    if fileExists(path):
     VVhjJY.append(VVeSPq)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVhjJY.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVhjJY.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVhjJY.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVhjJY.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVhjJY.append(VVeSPq)
   VVhjJY.append(    ("Set current directory as \"Startup Path\"" , "VVzSZw" ))
   FFmvQ5(self, self.VVfISW, title="Options", VVhjJY=VVhjJY)
 def VVfISW(self, item=None):
  if self.mode == self.VVVS8Z:
   if item is not None:
    path = self.VVpLst(self.VVdAc1())
    selFile = self.VVdAc1()
    if   item == "properties"    : self.VVG71e()
    elif item == "VVE0CW"  : self.VVE0CW(path)
    elif item == "VVVcJu"  : self.VVVcJu(path)
    elif item == "VV7vQP" : self.VV7vQP(path)
    elif item.startswith("extract_")  : self.VVg5E8(path, selFile, item)
    elif item.startswith("script_")   : self.VVZfwV(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVnBXmItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFC3ew(self, path)
    elif item.startswith("text_Edit")  : CCVm0W(self, path)
    elif item == "chmod644"     : self.VVvqcU(path, selFile, "644")
    elif item == "chmod755"     : self.VVvqcU(path, selFile, "755")
    elif item == "chmod777"     : self.VVvqcU(path, selFile, "777")
    elif item == "VVHp4j"   : self.VVHp4j(path, selFile)
    elif item == "VV5EAW"   : self.VV5EAW(path, selFile)
    elif item == "copyFileOrDir"   : self.VV5jN1(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VV5jN1(path, selFile, True)
    elif item == "VVzTzD"   : self.VVzTzD(path, selFile)
    elif item == "createNewFile"   : self.VVy6mj(path, True)
    elif item == "createNewDir"    : self.VVy6mj(path, False)
    elif item == "VVzSZw"   : self.VVzSZw(path)
    elif item == "VV47Ju"    : self.VV47Ju()
    else         : self.close()
 def VV47Ju(self):
  selFile = self.VVdAc1()
  path  = self.VVpLst(selFile)
  if os.path.isfile(path):
   VVHIgK = []
   category = self["myMenu"].VViPh4(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVYEeC(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFmy0U(self, selFile, path)
   elif category == "txt"         : FFC3ew(self, path)
   elif category in ("tar", "zip")       : self.VVAWZ9(path, selFile)
   elif category == "scr"         : self.VVCDnM(path, selFile)
   elif category == "m3u"         : self.VVGVc1(path, selFile)
   elif category in ("ipk", "deb")       : self.VV3KsM(path, selFile)
   elif category == "mus"         : self.VVxo58(path)
   elif category == "mov"         : self.VVxo58(path)
   elif not FF5o9M(path)        : FFC3ew(self, path)
 def VVxo58(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FF4ffD(self, refCode)
  except:
   pass
 def VVTfQq(self):
  path = self.VVpLst(self.VVdAc1())
  action = self.VVtftY(path)
  if action == 1:
   self.VVYwI3(path)
   FFbo0g(self, "Added", 500)
  elif action == -1:
   self.VVGpQi(path)
   FFbo0g(self, "Removed", 500)
  self.VVtftY(path)
 def VVYwI3(self, path):
  VV8klC = self.VVMOLN()
  if not VV8klC:
   VV8klC = []
  if len(VV8klC) >= self.VVcRyg:
   FFdx4k(SELF, "Max bookmarks reached (max=%d)." % self.VVcRyg)
  elif not path in VV8klC:
   VV8klC = [path] + VV8klC
   self.VVXNFI(VV8klC)
 def VVmVfX(self):
  VV8klC = self.VVMOLN()
  if VV8klC:
   newList = []
   for line in VV8klC:
    newList.append((line, line))
   VVvGoO  = ("Delete"  , self.VV3vYq )
   VVbBdV = ("Move Up"   , self.VV1rsX )
   VVKkqL  = ("Move Down" , self.VVBzVz )
   self.bookmarkMenu = FFmvQ5(self, self.VV9NwR, title="Bookmarks", VVhjJY=newList, VVvGoO=VVvGoO, VVbBdV=VVbBdV, VVKkqL=VVKkqL)
 def VV3vYq(self, VVdAc1Obj, path):
  if self.bookmarkMenu:
   VV8klC = self.VVGpQi(path)
   self.bookmarkMenu.VVFsii(VV8klC)
 def VV1rsX(self, VVdAc1Obj, path):
  if self.bookmarkMenu:
   VV8klC = self.bookmarkMenu.VVv8vk(True)
   if VV8klC:
    self.VVXNFI(VV8klC)
 def VVBzVz(self, VVdAc1Obj, path):
  if self.bookmarkMenu:
   VV8klC = self.bookmarkMenu.VVv8vk(False)
   if VV8klC:
    self.VVXNFI(VV8klC)
 def VV9NwR(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVHBhl(folder)
   self["myMenu"].moveToIndex(0)
  self.VVTRCQ()
 def VVMOLN(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVXpI1(self, path):
  VV8klC = self.VVMOLN()
  if VV8klC and path in VV8klC:
   return True
  else:
   return False
 def VVm9uk(self):
  if VVMOLN():
   return True
  else:
   return False
 def VVXNFI(self, VV8klC):
  line = ",".join(VV8klC)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVGpQi(self, path):
  VV8klC = self.VVMOLN()
  if VV8klC:
   while path in VV8klC:
    VV8klC.remove(path)
   self.VVXNFI(VV8klC)
   return VV8klC
 def VVzSZw(self, path):
  if not os.path.isdir(path):
   path = FFDFii(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVYEeC(self, selFile, VVWn1k, command):
  FFT4Vd(self, boundFunction(FFTgBK, self, command, VVMQzL=self.VV7XkI), "%s\n\n%s" % (VVWn1k, selFile))
 def VV0LdA(self, path, calledFromMenu):
  destPath = self.VVrreK(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVhjJY = []
  if calledFromMenu:
   VVhjJY.append(VVeSPq)
   color = VVP2je
  else:
   color = ""
  VVhjJY.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVhjJY.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVhjJY.append((color + "Extract Here"            , "extract_here"  ))
  if VVRd2T and path.endswith(".tar.gz"):
   VVhjJY.append(VVeSPq)
   VVhjJY.append((color + 'Convert to ".ipk" Package' , "VVRZSh"  ))
   VVhjJY.append((color + 'Convert to ".deb" Package' , "VVHoYR"  ))
  return VVhjJY
 def VVAWZ9(self, path, selFile):
  FFmvQ5(self, boundFunction(self.VVg5E8, path, selFile), title="Tar File Options", VVhjJY=self.VV0LdA(path, False))
 def VVg5E8(self, path, selFile, item=None):
  if item is not None:
   parent  = FFDFii(path, False)
   destPath = self.VVrreK(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVbwqB
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVbwqB, VVbwqB)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFEKD5(self, cmd)
   elif path.endswith(".zip"):
    self.VVSb8U(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FF0t1y("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVYEeC(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVYEeC(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFDFii(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVYEeC(selFile, "Extract Here ?"      , cmd)
   elif item == "VVRZSh" : self.VVRZSh(path)
   elif item == "VVHoYR" : self.VVHoYR(path)
 def VVrreK(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVSb8U(self, item, path, parent, destPath, VVWn1k):
  FFT4Vd(self, boundFunction(self.VVJMfx, item, path, parent, destPath), VVWn1k)
 def VVJMfx(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVbwqB
  cmd  = FFcnwo("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF6vFh(destPath, VVaENg))
  cmd +=   sep
  cmd += "fi;"
  FFhEdh(self, cmd, VVMQzL=self.VV7XkI)
 def VV85Xw(self, addSep=False):
  VVhjJY = []
  if addSep:
   VVhjJY.append(VVeSPq)
  VVhjJY.append((VVP2je + "View Script File"  , "script_View"  ))
  VVhjJY.append((VVP2je + "Execute Script File" , "script_Execute" ))
  VVhjJY.append((VVP2je + "Edit"     , "script_Edit" ))
  return VVhjJY
 def VVCDnM(self, path, selFile):
  FFmvQ5(self, boundFunction(self.VVZfwV, path, selFile), title="Script File Options", VVhjJY=self.VV85Xw())
 def VVZfwV(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFC3ew(self, path)
   elif item == "script_Execute" : self.VVYEeC(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCVm0W(self, path)
 def VVgvCu(self, addSep=False):
  VVhjJY = []
  if addSep:
   VVhjJY.append(VVeSPq)
  VVhjJY.append((VVP2je + "View"      , "m3u_View" ))
  VVhjJY.append((VVP2je + "Edit"      , "m3u_Edit" ))
  VVhjJY.append((VVP2je + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVhjJY
 def VVGVc1(self, path, selFile):
  FFmvQ5(self, boundFunction(self.VVnBXmItem_m3u, path, selFile), title="M3U File Options", VVhjJY=self.VVgvCu())
 def VVnBXmItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFC3ew(self, path)
   elif item == "m3u_Edit"  : CCVm0W(self, path)
   elif item == "m3u_Convert" : CCRT5i.VVNxWg(self, path, False)
 def VVvqcU(self, path, selFile, newChmod):
  FFT4Vd(self, boundFunction(self.VVFNPZ, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVFNPZ(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVKMzT)
  result = FFCpPs(cmd)
  if result == "Successful" : FFUbus(self, result)
  else      : FFdx4k(self, result)
 def VVHp4j(self, path, selFile):
  parent = FFDFii(path, False)
  self.session.openWithCallback(self.VVePuZ, boundFunction(CCZMP9, mode=CCZMP9.VV2fF7, VVXM9l=parent, VVoqjh="Create Symlink here"))
 def VVePuZ(self, newPath):
  if len(newPath) > 0:
   target = self.VVpLst(self.VVdAc1())
   target = FFNOsT(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFoGIr(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFdx4k(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFT4Vd(self, boundFunction(self.VViMKd, target, link), "Create Soft Link ?\n\n%s" % txt, VVUw2L=True)
 def VViMKd(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVKMzT)
  result = FFCpPs(cmd)
  if result == "Successful" : FFUbus(self, result)
  else      : FFdx4k(self, result)
 def VV5EAW(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFktKm(self, boundFunction(self.VVMont, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVMont(self, path, selFile, VVqjyy):
  if VVqjyy:
   parent = FFDFii(path, True)
   if os.path.isdir(path):
    path = FFNOsT(path)
   newName = parent + VVqjyy
   cmd = "mv '%s' '%s' %s" % (path, newName, VVKMzT)
   if VVqjyy:
    if selFile != VVqjyy:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFT4Vd(self, boundFunction(self.VVm8KB, cmd), message, title="Rename file?")
    else:
     FFdx4k(self, "Cannot use same name!", title="Rename")
 def VVm8KB(self, cmd):
  result = FFCpPs(cmd)
  if "Fail" in result:
   FFdx4k(self, result)
  self.VV7XkI()
 def VV5jN1(self, path, selFile, isMove):
  if isMove : VVoqjh = "Move to here"
  else  : VVoqjh = "Copy to here"
  parent = FFDFii(path, False)
  self.session.openWithCallback(boundFunction(self.VVf6uk, isMove, path, selFile)
         , boundFunction(CCZMP9, mode=CCZMP9.VV2fF7, VVXM9l=parent, VVoqjh=VVoqjh))
 def VVf6uk(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFNOsT(path)
   newPath = FFoGIr(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFT4Vd(self, boundFunction(FF1tu3, self, cmd, VVMQzL=self.VV7XkI), txt, VVUw2L=True)
   else:
    FFdx4k(self, "Cannot %s to same directory !" % action.lower())
 def VVzTzD(self, path, fileName):
  path = FFNOsT(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFT4Vd(self, boundFunction(self.VVKaRs, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVKaRs(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VV7XkI()
 def VVqT0y(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVp9kL and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVy6mj(self, path, isFile):
  dirName = FFoGIr(os.path.dirname(path))
  if isFile : objName, VVqjyy = "File"  , self.edited_newFile
  else  : objName, VVqjyy = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFktKm(self, boundFunction(self.VVJ16h, dirName, isFile, title), title=title, defaultText=VVqjyy, message="Enter %s Name:" % objName)
 def VVJ16h(self, dirName, isFile, title, VVqjyy):
  if VVqjyy:
   if isFile : self.edited_newFile = VVqjyy
   else  : self.edited_newDir  = VVqjyy
   path = dirName + VVqjyy
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVKMzT)
    else  : cmd = "mkdir '%s' %s" % (path, VVKMzT)
    result = FFCpPs(cmd)
    if "Fail" in result:
     FFdx4k(self, result)
    self.VV7XkI()
   else:
    FFdx4k(self, "Name already exists !\n\n%s" % path, title)
 def VV3KsM(self, path, selFile):
  VVhjJY = []
  VVhjJY.append(("List Package Files"          , "VVHyf9"     ))
  VVhjJY.append(("Package Information"          , "VVwxoi"     ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Install Package"           , "VVZKDV_CheckVersion" ))
  VVhjJY.append(("Install Package (force reinstall)"      , "VVZKDV_ForceReinstall" ))
  VVhjJY.append(("Install Package (force downgrade)"      , "VVZKDV_ForceDowngrade" ))
  VVhjJY.append(("Install Package (ignore failed dependencies)"    , "VVZKDV_IgnoreDepends" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Remove Related Package"         , "VVXpRs_ExistingPackage" ))
  VVhjJY.append(("Remove Related Package (force remove)"     , "VVXpRs_ForceRemove"  ))
  VVhjJY.append(("Remove Related Package (ignore failed dependencies)"  , "VVXpRs_IgnoreDepends" ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("Extract Files"           , "VVagag"     ))
  VVhjJY.append(("Unbuild Package"           , "VV3ck2"     ))
  FFmvQ5(self, boundFunction(self.VVZESO, path, selFile), VVhjJY=VVhjJY)
 def VVZESO(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVHyf9"      : self.VVHyf9(path, selFile)
   elif item == "VVwxoi"      : self.VVwxoi(path)
   elif item == "VVZKDV_CheckVersion"  : self.VVZKDV(path, selFile, VVSeHH     )
   elif item == "VVZKDV_ForceReinstall" : self.VVZKDV(path, selFile, VVKhUe )
   elif item == "VVZKDV_ForceDowngrade" : self.VVZKDV(path, selFile, VVBK9Y )
   elif item == "VVZKDV_IgnoreDepends" : self.VVZKDV(path, selFile, VVW7Xu )
   elif item == "VVXpRs_ExistingPackage" : self.VVXpRs(path, selFile, VVA4To     )
   elif item == "VVXpRs_ForceRemove"  : self.VVXpRs(path, selFile, VVvsDU  )
   elif item == "VVXpRs_IgnoreDepends"  : self.VVXpRs(path, selFile, VVmOpe )
   elif item == "VVagag"     : self.VVagag(path, selFile)
   elif item == "VV3ck2"     : self.VV3ck2(path, selFile)
   else           : self.close()
 def VVHyf9(self, path, selFile):
  if FF5sJ5("ar") : cmd = "allOK='1';"
  else    : cmd  = FFzWrJ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVbwqB, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVbwqB, VVbwqB)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFch3D(self, cmd, VVMQzL=self.VV7XkI)
 def VVagag(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFDFii(path, True) + selFile[:-4]
  cmd  =  FFzWrJ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FF0t1y("mkdir '%s'" % dest) + ";"
  cmd +=    FF0t1y("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF6vFh(dest, VVaENg))
  cmd += "fi;"
  FFTgBK(self, cmd, VVMQzL=self.VV7XkI)
 def VV3ck2(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV1Ocz = os.path.splitext(path)[0]
  else        : VV1Ocz = path + "_"
  if path.endswith(".deb")   : VVEy0U = "DEBIAN"
  else        : VVEy0U = "CONTROL"
  cmd  = FFzWrJ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV1Ocz, FFibik())
  cmd += "  mkdir '%s';"    % VV1Ocz
  cmd += "  CONTPATH='%s/%s';"  % (VV1Ocz, VVEy0U)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV1Ocz
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV1Ocz, VV1Ocz)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV1Ocz
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV1Ocz, VV1Ocz)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV1Ocz
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV1Ocz
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV1Ocz, FF6vFh(VV1Ocz, VVaENg))
  cmd += "fi;"
  FFTgBK(self, cmd, VVMQzL=self.VV7XkI)
 def VVwxoi(self, path):
  listCmd  = FFGMYv(VVEKL9, "")
  infoCmd  = FFBSlb(VVa81b , "")
  filesCmd = FFBSlb(VVFTJH, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFA8ba(VVBlp5)
   notInst = "Package not installed."
   cmd  = FF1Vsg("File Info", VVBlp5)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF1Vsg("System Info", VVBlp5)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF6vFh(notInst, VVP2je))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF1Vsg("Related Files", VVBlp5)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFEKD5(self, cmd)
  else:
   FFHvqH(self)
 def VVZKDV(self, path, selFile, cmdOpt):
  cmd = FFBSlb(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFT4Vd(self, boundFunction(FFTgBK, self, cmd, VVMQzL=FFqgU2), "Install Package ?\n\n%s" % selFile)
  else:
   FFHvqH(self)
 def VVXpRs(self, path, selFile, cmdOpt):
  listCmd  = FFGMYv(VVEKL9, "")
  infoCmd  = FFBSlb(VVa81b, "")
  instRemCmd = FFBSlb(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF6vFh(errTxt, VVP2je))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF6vFh(cannotTxt, VVP2je))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF6vFh(tryTxt, VVP2je))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFT4Vd(self, boundFunction(FFTgBK, self, cmd, VVMQzL=FFqgU2), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFHvqH(self)
 def VVSkfz(self, path):
  hostName = FFCpPs("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVMw2s(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVSkfz(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVE0CW(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVhjJY = []
  VVhjJY.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVhjJY.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVhjJY.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVhjJY.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVhjJY.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVhjJY.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVhjJY.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVhjJY.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVhjJY.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVhjJY.append(VVeSPq)
  VVhjJY.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVhjJY.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFmvQ5(self, boundFunction(self.VVKT14, path), VVhjJY=VVhjJY)
 def VVKT14(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVcf5j(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVcf5j(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVcf5j(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVcf5j(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVcf5j(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVcf5j(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVcf5j(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVcf5j(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVcf5j(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVcf5j(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVskzi(path, False)
   elif item == "convertDirToDeb"   : self.VVskzi(path, True)
   else         : self.close()
 def VVskzi(self, path, VVgL4t):
  self.session.openWithCallback(self.VV7XkI, boundFunction(CC5HTk, path=path, VVgL4t=VVgL4t))
 def VVcf5j(self, path, fileExt, preserveDirStruct):
  parent  = FFDFii(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFcnwo("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFcnwo("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFcnwo("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVbwqB
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FF0t1y("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF6vFh(resultFile, VVaENg))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF6vFh(failed, VVlb6B))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFch3D(self, cmd, VVMQzL=self.VV7XkI)
 def VVVcJu(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFC3ew(self, versionFile)
 def VV7vQP(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVSkfz(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFdx4k(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFPPAc(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFDFii(path, False)
  VV1Ocz = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF6vFh(errCmd, VVlb6B))
  installCmd = FFBSlb(VVSeHH , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV1Ocz, VV1Ocz)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV1Ocz
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV1Ocz
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV1Ocz, VV1Ocz)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFTgBK(self, cmd, VVMQzL=self.VV7XkI)
 def VVRZSh(self, path):
  FFdx4k(self, "Under Construction.")
 def VVHoYR(self, path):
  FFdx4k(self, "Under Construction.")
class CCjhxq(MenuList):
 def __init__(self, VVSnaB=False, directory="/", VVoWdu=True, VVlTbf=True, VV7OVy=True, VVw9FL=None, VV485b=False, VVFe2U=False, VVVoKi=False, isTop=False, VV3oJo=None, VVHleR=1000, VVhj1e=30, VVRjt3=30, VVNnRO="#00000000"):
  MenuList.__init__(self, list, VVSnaB, eListboxPythonMultiContent)
  self.VVoWdu  = VVoWdu
  self.VVlTbf    = VVlTbf
  self.VV7OVy  = VV7OVy
  self.VVw9FL  = VVw9FL
  self.VV485b   = VV485b
  self.VVFe2U   = VVFe2U or []
  self.VVVoKi   = VVVoKi or []
  self.isTop     = isTop
  self.additional_extensions = VV3oJo
  self.VVHleR    = VVHleR
  self.VVhj1e    = VVhj1e
  self.VVRjt3    = VVRjt3
  self.pngBGColor    = FFpT1f(VVNnRO)
  self.EXTENSIONS    = self.VVJgjK()
  self.VVSU8l   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVD1DD, self.VVhj1e))
  self.l.setItemHeight(self.VVRjt3)
  self.png_mem   = self.VVVl9W("mem")
  self.png_usb   = self.VVVl9W("usb")
  self.png_fil   = self.VVVl9W("fil")
  self.png_dir   = self.VVVl9W("dir")
  self.png_dirup   = self.VVVl9W("dirup")
  self.png_srv   = self.VVVl9W("srv")
  self.png_slwfil   = self.VVVl9W("slwfil")
  self.png_slbfil   = self.VVVl9W("slbfil")
  self.png_slwdir   = self.VVVl9W("slwdir")
  self.VVH3LZ()
  self.VVHBhl(directory)
 def VVVl9W(self, category):
  return LoadPixmap("%s%s.png" % (VVVIGI, category), getDesktop(0))
 def VVJgjK(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVKUOw(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFNOsT(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF34IZ(" -> " , VVBlp5) + FF34IZ(os.readlink(path), VVaENg)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVRjt3 + 10, 0, self.VVHleR, self.VVRjt3, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVTkrv: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVRjt3-4, self.VVRjt3-4, png, self.pngBGColor, self.pngBGColor, VVTkrv))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVRjt3-4, self.VVRjt3-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VViPh4(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVH3LZ(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVNKZW(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVg5K0(self, file):
  if os.path.realpath(file) == file:
   return self.VVNKZW(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVNKZW(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVNKZW(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVv39k(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVSU8l.info(l[0][0]).getEvent(l[0][0])
 def VVWCpX(self):
  return self.list
 def VVGkGd(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVHBhl(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VV7OVy:
    self.current_mountpoint = self.VVg5K0(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VV7OVy:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVVoKi and not self.VVGkGd(path, self.VVFe2U):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVKUOw(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV485b:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVSU8l = eServiceCenter.getInstance()
   list = VVSU8l.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVoWdu and not self.isTop:
   if directory == self.current_mountpoint and self.VV7OVy:
    self.list.append(self.VVKUOw(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVVoKi and self.VVNKZW(directory) in self.VVVoKi):
    self.list.append(self.VVKUOw(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVoWdu:
   for x in directories:
    if not (self.VVVoKi and self.VVNKZW(x) in self.VVVoKi) and not self.VVGkGd(x, self.VVFe2U):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVKUOw(name = name, absolute = x, isDir = True, png = png))
  if self.VVlTbf:
   for x in files:
    if self.VV485b:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF34IZ(" -> " , VVBlp5) + FF34IZ(target, VVaENg)
       else:
        png = self.png_slbfil
        name += FF34IZ(" -> " , VVBlp5) + FF34IZ(target, VVlb6B)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VViPh4(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVVIGI, category))
    if (self.VVw9FL is None) or iCompile(self.VVw9FL).search(path):
     self.list.append(self.VVKUOw(name = name, absolute = x , isDir = False, png = png))
  if self.VV7OVy and len(self.list) == 0:
   self.list.append(self.VVKUOw(name = FF34IZ("No USB connected", VVho0k), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVY8DA(self):
  return self.current_directory
 def VVUEG1(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVHBhl(self.getSelection()[0], select = self.current_directory)
 def VVOXn6(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVxoZT(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVUfB4)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVUfB4)
 def refresh(self):
  self.VVHBhl(self.current_directory, self.VVOXn6())
 def VVUfB4(self, action, device):
  self.VVH3LZ()
  if self.current_directory is None:
   self.refresh()
class CCSufm(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFuMnj(VVEjzp, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV8klC   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVzJCK(defFG, "#00FFFFFF")
  self.defBG   = self.VVzJCK(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFgoqU(self, self.Title)
  self["keyRed"].show()
  FFmNCq(self["keyGreen"] , "< > Transp.")
  FFmNCq(self["keyYellow"], "Foreground")
  FFmNCq(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVDYAv        ,
   "yellow"   : boundFunction(self.VVKSBL, False)  ,
   "blue"   : boundFunction(self.VVKSBL, True)  ,
   "up"   : self.VVpYKT          ,
   "down"   : self.VVJykB         ,
   "left"   : self.VVzYlM         ,
   "right"   : self.VVtvtH         ,
   "last"   : boundFunction(self.VVKJNG, -5) ,
   "next"   : boundFunction(self.VVKJNG, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVHk7P)
 def VVHk7P(self):
  self.onShown.remove(self.VVHk7P)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFYzPI(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFYzPI(self["keyRed"] , c)
  FFYzPI(self["keyGreen"] , c)
  self.VVpH70()
  self.VVk8SG()
  FF55DC(self["myColorTst"], self.defFG)
  FFYzPI(self["myColorTst"], self.defBG)
 def VVzJCK(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVk8SG(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV5IF9(0, 0)
     return
 def VVDYAv(self):
  self.close(self.defFG, self.defBG)
 def VVpYKT(self): self.VV5IF9(-1, 0)
 def VVJykB(self): self.VV5IF9(1, 0)
 def VVzYlM(self): self.VV5IF9(0, -1)
 def VVtvtH(self): self.VV5IF9(0, 1)
 def VV5IF9(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VViL72()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVMRrJ()
 def VVpH70(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVMRrJ(self):
  color = self.VViL72()
  if self.isBgMode: FFYzPI(self["myColorTst"], color)
  else   : FF55DC(self["myColorTst"], color)
 def VVKSBL(self, isBg):
  self.isBgMode = isBg
  self.VVpH70()
  self.VVk8SG()
 def VVKJNG(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV5IF9(0, 0)
 def VVvJcA(self):
  return hex(self.transp)[2:].zfill(2)
 def VViL72(self):
  return ("#%s%s" % (self.VVvJcA(), self.colors[self.curRow][self.curCol])).upper()
class CCuAq6(ScrollLabel):
 def __init__(self, parentSELF, text="", VVxQmi=True):
  ScrollLabel.__init__(self, text)
  self.VVxQmi=VVxQmi
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVkFu6  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVhj1e    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVmuRb   ,
   "green"   : self.VVMyD2  ,
   "yellow"  : self.VVEfsi  ,
   "blue"   : self.VVVIJ4  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVcVSG    ,
   "chanUp"  : self.VVcVSG    ,
   "pageDown"  : self.VV5XOr    ,
   "chanDown"  : self.VV5XOr
  }, -1)
 def VV36kJ(self, isResizable=True, VVGDsG=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFbK0m(self.parentSELF, True)
  self.isResizable = isResizable
  if VVGDsG:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVhj1e  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFYzPI(self, color)
 def FFYzPIColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVkFu6 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVhQJw()
 def pageUp(self):
  if self.VVkFu6 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVkFu6 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVcVSG(self):
  self.setPos(0)
 def VV5XOr(self):
  self.setPos(self.VVkFu6-self.pageHeight)
 def VVQ49t(self):
  return self.VVkFu6 <= self.pageHeight or self.curPos == self.VVkFu6 - self.pageHeight
 def VVhQJw(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVkFu6, 3))
   start = int((100 - vis) * self.curPos / (self.VVkFu6 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VV9aL5=VVhB6f):
  old_VVQ49t = self.VVQ49t()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVkFu6 = self.long_text.calculateSize().height()
   if self.VVxQmi and self.VVkFu6 > self.pageHeight:
    self.scrollbar.show()
    self.VVhQJw()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVkFu6))
   if   VV9aL5 == VVDZSi: self.setPos(0)
   elif VV9aL5 == VVx3E7 : self.VV5XOr()
   elif old_VVQ49t    : self.VV5XOr()
 def appendText(self, text, VV9aL5=VVx3E7):
  self.setText(self.message + str(text), VV9aL5)
 def VVEfsi(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVnF8d(size)
 def VVVIJ4(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVnF8d(size)
 def VVMyD2(self):
  self.VVnF8d(self.VVhj1e)
 def VVnF8d(self, VVhj1e):
  self.long_text.setFont(gFont(self.fontFamily, VVhj1e))
  self.setText(self.message, VV9aL5=VVhB6f)
  self.VVyPlD(calledFromFontSizer=True)
 def VVmuRb(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFoGIr(expPath), self.textOutFile, FFmJh3())
    with open(outF, "w") as f:
     f.write(FFdqBS(self.message))
    FFUbus(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFdx4k(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVyPlD(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVkFu6 > 0 and self.pageHeight > 0:
   if self.VVkFu6 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVkFu6
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
