import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVX28J   = "v8.5.0"
VV1y7w    = "04-02-2023"
EASY_MODE    = 0
VVoefQ   = 0
VVH3JP   = 0
VV9hRJ  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VV4ItM  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVPUYO    = "/media/usb/"
VVvHy0    = "/usr/share/enigma2/picon/"
VVGDFI = "/etc/enigma2/blacklist"
VVn6iK   = "/etc/enigma2/"
VVblf7   = "AJPan"
VVgLsZ  = "AUTO FIND"
VVjsUk  = "Custom"
VVmdbp  = None
VV48L0    = ""
VVnKBD = "Regular"
VVaizI = "Fixed"
VVkmMH  = "AJP_Main"
VVHPQk = "AJP_Terminal"
VVtCop = "AJP_System"
VVrHrQ  = VVnKBD
VVwtEz      = "-" * 80
VVXMhc    = ("-" * 100, )
VVLN9R    = ""
VVENt5   = " && echo 'Successful' || echo 'Failed!'"
VVLZrc    = []
VVwdtR  = "Cannot continue (No Enough Memory) !"
VVkhZN  = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
VVJAPg  = "utf8"
VVRR1W  = False
VVnusr  = False
VVG5k0     = 0
VVqSrQ    = 1
VVoBnl    = 2
VVyLlF   = 3
VVRHe2    = 4
VV1bMC    = 5
VVKV47 = 6
VV181V = 7
VVt3UW  = 8
VV6FtF   = 9
VVXc0G  = 10
VVZcl5  = 11
VVPeyn = 12
VVDOHw = 13
VVppbz = 14
VVoarh  = 15
VVAn5e    = 16
VVmUKz   = 17
VV6PU3   = 18
VVZm1S    = 19
VVw6T7    = 20
VVFovP  = 21
VV8xeD    = 22
VVT5lQ   = 0
VVyHv2   = 1
VVPiyR   = 2
def FF7uj5():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVrHrQ
  if VVkmMH in lst and CFG.fontPathMain.getValue(): VVrHrQ = VVkmMH
  else               : VVrHrQ = VVnKBD
  return lst
 else:
  return [VVnKBD]
def FF8ceC(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVJAPg)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVgLsZ, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVvHy0, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVPUYO, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt", "FROM SRT FILE"),("#00FFFF", "Aqua"),("#000000", "Black"),("#0000FF", "Blue"),("#FF00FF", "Fuchsia"),("#808080", "Gray"),("#008000", "Green"),("#00FF00", "Lime"),("#800000", "Maroon"),("#000080", "Navy"),("#808000", "Olive"),("#800080", "Purple"),("#FF0000", "Red"),("#C0C0C0", "Silver"),("#008080", "Teal"),("#FFFFFF", "White"),("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVrHrQ, choices=[(x,  x) for x in FF7uj5()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FF3ju9():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVauPC  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV9Hxn = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVauPC  : return 0
  elif VV9Hxn : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVsQSI = FF3ju9()
VVtUHQ = VVlhbS = VVzF5b = VVxsyh = VVLO3F = VVFaDd = VVyFNv = VVkPll = VVlwDq = VVPWV9 = VVOpMG = VVmuI1 = VV619a = VVDopz = VVW5KH = VVViAb = ""
def FF0QXw()  : FFaeLV(FFFzga())
def FFDTNE()  : FFaeLV(FFcBBu())
def FFUTNa(tDict): FFaeLV(iDumps(tDict, indent=4, sort_keys=True))
def FFjRPV(*args): FFXvLs(True, True, *args)
def FFaeLV(*args) : FFXvLs(True , False , *args)
def FF17lK(*args): FFXvLs(False, False, *args)
def FFXvLs(addSep=True, isArray=True, *args):
 if VVoefQ:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF9lyY(fnc):
 def VVnfkH(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFaeLV(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVnfkH
def FFtypX(*args):
 if VVoefQ:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FF17lK("Added to : %s" % path)
def FFkOqD(txt, isAppend=True, ignoreErr=False):
 if VVoefQ:
  tm = FFdK60()
  err = ""
  if not ignoreErr:
   err = FFcBBu()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFaeLV(err)
  FFaeLV("Output Log File : %s" % fileName)
def FFcBBu():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFdK60()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFFzga():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VViii5 = 0
def FFUFhQ():
 global VViii5
 VViii5 = iTime()
def FF9ajT(txt=""):
 FFaeLV(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VViii5)).rstrip("0"), txt))
VVLZrc = []
def FFMPfH(win):
 global VVLZrc
 if not win in VVLZrc:
  VVLZrc.append(win)
def FFcLLG(*args):
 global VVLZrc
 for win in VVLZrc:
  try:
   win.close()
  except:
   pass
 VVLZrc = []
def FFWjeD():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVmqKk = FFWjeD()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFXsRD()    : return PluginDescriptor(fnc=FFphaj, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFFQRT()      : return getDescriptor(FFGFqE , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFPZKq()     : return getDescriptor(FFbfsC  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFRIVf()  : return getDescriptor(FF9TuH, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFRyYn() : return getDescriptor(FFhYnz , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFTsX5()  : return getDescriptor(FF5Hwt , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFLtcB()  : return getDescriptor(FFn7r8  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FF3JXQ()      : return getDescriptor(FFkMcl, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFPZKq() , FFFQRT() , FFXsRD() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFRIVf())
  result.append(FFRyYn())
  result.append(FFTsX5())
  result.append(FFLtcB())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF3JXQ())
 return result
def FFphaj(reason, **kwargs):
 if reason == 0:
  CCAmZo.VVp2mZ()
  if "session" in kwargs:
   session = kwargs["session"]
   FFv3i9(session)
   CCwyZ7(session)
def FFGFqE(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFbfsC, PLUGIN_NAME, 45)]
 else:
  return []
def FFbfsC(session, **kwargs):
 session.open(Main_Menu)
def FF9TuH(session, **kwargs):
 session.open(CCVdBH)
def FFhYnz(session, **kwargs):
 session.open(CCHli4)
def FF5Hwt(session, **kwargs):
 CC0rhb.VVpY9t(session, isFromExternal=True)
def FFn7r8(session, **kwargs):
 FFhpkO(session, reopen=True)
def FFkMcl(session, **kwargs):
 session.open(CC8xkn, fncMode=CC8xkn.VVjn7L)
def FFZFvW():
 FFQw6L(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFRIVf(), FFRyYn(), FFTsX5(), FFLtcB() ])
 FFQw6L(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF3JXQ() ])
def FFQw6L(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFv3i9(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFqlFk, session, "lok")
 hk.actions["longCancel"]= BF(FFqlFk, session, "lesc")
 hk.actions["longRed"] = BF(FFqlFk, session, "lred")
 for k in (CC1HIn.VVX82d, CC1HIn.VVF4Xf, CC1HIn.VVG0V8):
  hk.actions[k] = BF(CC1HIn.VVOx1Z, session, k)
def FFqlFk(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCkbMr.VVpvKD:
    CCkbMr.VVpvKD.close()
   if not CC0rhb.VVuHV5:
    CC0rhb.VVpY9t(session, isFromExternal=True)
  except:
   pass
def FFoBdB(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFsd9n(SELF, title="", addLabel=False, addScrollLabel=False, VVY9NT=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFKcKn()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCTKZ9(SELF)
 if VVY9NT:
  SELF["myMenu"] = MenuList(VVY9NT)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVz6TU ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFgZsx(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FF497C, SELF, "0"),
  "1" : BF(FF497C, SELF, "1"),
  "2" : BF(FF497C, SELF, "2"),
  "3" : BF(FF497C, SELF, "3"),
  "4" : BF(FF497C, SELF, "4"),
  "5" : BF(FF497C, SELF, "5"),
  "6" : BF(FF497C, SELF, "6"),
  "7" : BF(FF497C, SELF, "7"),
  "8" : BF(FF497C, SELF, "8"),
  "9" : BF(FF497C, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFjHAV, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF497C(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVViAb:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVViAb + SELF.keyPressed + VVlhbS)
    txt = VVlhbS + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFZWPu(SELF, txt)
def FFjHAV(SELF, tableObj, colNum, isMenu):
 FFZWPu(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFUkF8(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVsNwl(i)
     else  : SELF.VVyOnh(i)
     break
 except:
  pass
def FFKcKn():
 return ("  %s" % VVLN9R)
def FFKpuS(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFUkF8(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFa79O(color):
 return parseColor(color).argb()
def FFR9H9(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFRkaP(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFw6AD(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFs7EJ(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVViAb)
 else:
  return ""
def FFsHvy(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVwtEz, word, VVwtEz, VVViAb)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVwtEz, word, VVwtEz)
def FFbRJw(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVViAb
def FFmquk(color):
 if color: return "echo -e '%s' %s;" % (VVwtEz, FFs7EJ(VVwtEz, VVOpMG))
 else : return "echo -e '%s';" % VVwtEz
def FFF2CM(title, color):
 title = "%s\n%s\n%s\n" % (VVwtEz, title, VVwtEz)
 return FFbRJw(title, color)
def FFR6rJ(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFRQX6(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFcigO(callBackFunction):
 tCons = CC6TQl()
 tCons.ePopen("echo", BF(FFetYp, callBackFunction))
def FFetYp(callBackFunction, result, retval):
 callBackFunction()
def FFDKj1(SELF, fnc, title="Processing ...", clearMsg=True):
 FFZWPu(SELF, title)
 tCons = CC6TQl()
 tCons.ePopen("echo", BF(FF3s3r, SELF, fnc, clearMsg))
def FF3s3r(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFZWPu(SELF)
def FFJ6lf(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVwdtR
  else       : return ""
def FFLYXX(cmd):
 txt = FFJ6lf(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFA2wB(cmd):
 lines = FFLYXX(cmd)
 if lines: return lines[0]
 else : return ""
def FFxMj3(SELF, cmd):
 lines = FFLYXX(cmd)
 VVJnaJ = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVJnaJ.append((key, val))
  elif line:
   VVJnaJ.append((line, ""))
 if VVJnaJ:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFXBR7(SELF, None, header=header, VV0wO4=VVJnaJ, VVgZrM=widths, VVfp7o=28)
 else:
  FFOm4Z(SELF, cmd)
def FFOm4Z(    SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, VVXjb4=True, VVQY0S=VVyHv2, **kwargs)
def FFb5TJ(  SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, **kwargs)
def FFQHMr(   SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, VVa6xF=True, VVMIrb=True, VVQY0S=VVyHv2, **kwargs)
def FF7o6J(  SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, VVa6xF=True, VVMIrb=True, VVQY0S=VVPiyR, **kwargs)
def FFx5HE(  SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, VVW4f4=True , **kwargs)
def FFFSGY(  session, cmd, **kwargs):      session.open(CC2Jby, VVelZe=cmd, VVW4f4=True , **kwargs)
def FFSgaO( SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, VVjtjK=True   , **kwargs)
def FFWveA( SELF, cmd, **kwargs): SELF.session.open(CC2Jby, VVelZe=cmd, VVupuq=True  , **kwargs)
def FF75pk(cmd):
 return cmd + " > /dev/null 2>&1"
def FFJvZy(cmd):
 return cmd + " 2> /dev/null"
def FFDyJa():
 return " > /dev/null 2>&1"
def FF1yPm(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFNjJC(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFaz01():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFA2wB(cmd)
VVjlpz     = 0
VViMeN      = 1
VV5YBB   = 2
VV5cDl   = 3
VVihTi      = 4
VVgD1q      = 5
VV4O5D     = 6
VVnfD4     = 7
VVzo0S     = 8
VVPgiB = 9
VVftKI = 10
VV2nWE = 11
VVONbh  = 12
VVFsUb     = 13
VVChqD  = 14
VVKfEX  = 15
def FFv5Rb(parmNum, grepTxt):
 if   parmNum == VVjlpz  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VViMeN   : param = ["list"   , "apt list"    ]
 elif parmNum == VV5YBB: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VV5cDl: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFaz01()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFXUpj(parmNum, package):
 if   parmNum == VVihTi      : param = ["info"      , "apt show"         ]
 elif parmNum == VVgD1q      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VV4O5D     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVnfD4     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVzo0S     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVPgiB : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVftKI : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VV2nWE : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVONbh  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVFsUb     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVChqD  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVKfEX  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFaz01()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFYhIs():
 result = FFA2wB("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFXUpj(VVzo0S, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FF75pk("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FF75pk("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFs7EJ(failed1, VVOpMG))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFs7EJ(failed2, VVOpMG))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFs7EJ(failed3, VVzF5b))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFKkrr(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFXUpj(VVzo0S , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FF75pk("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFs7EJ(failed1, VVOpMG))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFs7EJ(failed2, VVzF5b))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFvr8J(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCORAx.VVMGfk()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFun41(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFvr8J(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FF2tbi(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFtDuT(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFvr8J(path, maxSize=maxSize, encLst=encLst)
  if lines: FFHdWy(SELF, lines, title=title, VVQY0S=VVyHv2, width=1600, height=1000, titleFontSize=30)
  else : FFUVcy(SELF, path, title=title)
 else:
  FFCpVp(SELF, path, title)
def FFv9kY(SELF, fName, title):
 path = VVE5ib + fName
 if fileExists(path):
  txt = FFvr8J(path)
  txt = txt.replace("#W#", VVViAb)
  txt = txt.replace("#Y#", VVmuI1)
  txt = txt.replace("#G#", VVlhbS)
  txt = txt.replace("#C#", VV619a)
  txt = txt.replace("#P#", VVLO3F)
  FFHdWy(SELF, txt, title=title)
 else:
  FFCpVp(SELF, path, title)
def FFmf62(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFBCGr(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFd5Wt(parent)
 else    : return FFUEil(parent)
def FFjufa(path):
 return os.path.basename(os.path.normpath(path))
def FFtDuT(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  return -1
def FF1rjx(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FF0U10(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFiHj6(path):
 try:
  os.remove(path)
 except:
  pass
def FFoJ7V(path):
 return os.system(FF75pk("chattr -AacDdijsStu '%s'" % path) + ";" + FF75pk("rm -fr '%s'" % path))
def FFd5Wt(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFUEil(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF8ZuZ():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VV9hRJ)
 paths.append(VV9hRJ.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFmf62(ba)
 for p in list:
  p = ba + p + VV9hRJ
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVblf7, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VV9hRJ, VVblf7 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVjHuz, VVE5ib = FF8ZuZ()
def FFNERR():
 def VVA5cA(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVA9h3   = VVA5cA(CFG.backupPath, CC0lek.VVAVMo())
 VV0Ar3   = VVA5cA(CFG.downloadedPackagesPath, t)
 VVGq9q  = VVA5cA(CFG.exportedTablesPath, t)
 VVtQMR  = VVA5cA(CFG.exportedPIconsPath, t)
 VV69PD   = VVA5cA(CFG.packageOutputPath, t)
 global VVPUYO
 VVPUYO = FFd5Wt(CFG.backupPath.getValue())
 if VVA9h3 or VV69PD or VV0Ar3 or VVGq9q or VVtQMR or oldMovieDownloadPath:
  configfile.save()
 return VVA9h3, VV69PD, VV0Ar3, VVGq9q, VVtQMR, oldMovieDownloadPath
def FFfb1b(path):
 path = FFUEil(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFloYz(SELF, pathList, tarFileName, addTimeStamp=True):
 VV0wO4 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV0wO4.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV0wO4.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV0wO4.append(path)
 if not VV0wO4:
  FFh60c(SELF, "Files not found!")
 elif not pathExists(VVPUYO):
  FFh60c(SELF, "Path not found!\n\n%s" % VVPUYO)
 else:
  VV8Pva = FFd5Wt(VVPUYO)
  tarFileName = "%s%s" % (VV8Pva, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFDaMH())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV0wO4:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVwtEz
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFs7EJ(tarFileName, VVlwDq))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFs7EJ(failed, VVlwDq))
  cmd += "fi;"
  cmd +=  sep
  FFb5TJ(SELF, cmd)
def FFnx82(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFSGau(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFSGau(SELF["keyInfo"], "info")
def FFSGau(barObj, fName):
 path = "%s%s%s" % (VVE5ib, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFZmN3(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFeCPs(satNum)
  return satName
def FFeCPs(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FF8b2s(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFZmN3(val)
  else  : sat = FFeCPs(val)
 return sat
def FFoB4N(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFZmN3(num)
 except:
  pass
 return sat
def FFwcmp(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF02Rs(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFVMAI(info, iServiceInformation.sServiceref)
   prov = FFVMAI(info, iServiceInformation.sProvider)
   state = str(FFVMAI(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFpHD4(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFE7jz(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFVMAI(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFJQVB(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFiUHq(refCode):
 info = FFfmZn(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFQKyU(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFRC4s(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFfmZn(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVfpZj = eServiceCenter.getInstance()
  if VVfpZj:
   info = VVfpZj.info(service)
 return info
def FFqoI8(SELF, refCode, VVLrHC=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFE7jz(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCNJgc()
  if pr.VVVvef(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVt6FJ(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFR47V(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVLrHC:
   FFrocX(SELF, isFromSession)
 try:
  VVXVyg = InfoBar.instance
  if VVXVyg:
   VVCDrX = VVXVyg.servicelist
   if VVCDrX:
    servRef = eServiceReference(refCode)
    VVCDrX.saveChannel(servRef)
 except:
  pass
def FFR47V(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCNJgc()
    if pr.VVVvef(refCode, chName, decodedUrl, iptvRef):
     pr.VVt6FJ(SELF, isFromSession)
def FFpHD4(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFuuGZ(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFxp0h(url): return FFHZVk(url) or FFCYCF(url)
def FFHZVk(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFCYCF(url): return any(x in url for x in ("/series/", "mode=series"))
def FFE7jz(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFhKb1(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFhKb1(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFeaA3(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFLRAx(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFTy1z(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF1Wb5(txt):
 try:
  return FFLRAx(FFTy1z(txt)) == txt
 except:
  return False
def FFzuBj(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFd5Wt(newPath), patt))
def FFrocX(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CC0rhb.VVpY9t(session, isFromExternal=isFromSession)
 else      : FFhpkO(session, reopen=True)
def FFhpkO(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFhpkO, session), CCkbMr)
  except:
   try:
    FFkPRK(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFHUOD(refCode):
 tp = CCsRkT()
 if tp.VVq425(refCode) : return True
 else        : return False
def FFD1OO(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFMABX(True)
     return True
 return False
def FFMABX(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFHIIh()
def FFHIIh():
 VVXVyg = InfoBar.instance
 if VVXVyg:
  VVCDrX = VVXVyg.servicelist
  if VVCDrX:
   VVCDrX.setMode()
def FFrlgz(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVfpZj = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVfpZj.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFtgvA():
 VVF6pL = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVcAst = list(VVF6pL)
 return VVcAst, VVF6pL
def FFgh2b():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FF9pmh(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FF2gB8(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FF4W6Q():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFDaMH():
 return FF4W6Q().replace(" ", "_").replace("-", "").replace(":", "")
def FF8ZP4(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFdK60():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFzm7R(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCHli4.VVBGBM(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCHli4.VVaBJI(fName)
     phpFile = tmpDir + fName + ext
     os.system(FF75pk("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFEu9e(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FF10dh(num):
 return "s" if num > 1 else ""
def FFiWjh(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFo5AX(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFggFJ(a, b):
 return (a > b) - (a < b)
def FFSOId(a, b):
 def VVxCVG(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVxCVG(a)
 b = VVxCVG(b)
 return (a > b) - (a < b)
def FFKPxS(mycmp):
 class CCp0U7(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCp0U7
def FFNvXQ(SELF, message, title="", VVsfO0=None):
 SELF.session.openWithCallback(VVsfO0, CCqAwn, title=title, message=message, VVMebt=True)
def FFHdWy(SELF, message, title="", VVQY0S=VVyHv2, VVsfO0=None, **kwargs):
 SELF.session.openWithCallback(VVsfO0, CCqAwn, title=title, message=message, VVQY0S=VVQY0S, **kwargs)
def FFh60c(SELF, message, title="")  : FFkPRK(SELF.session, message, title)
def FFCpVp(SELF, path, title="") : FFkPRK(SELF.session, "File not found !\n\n%s" % path, title)
def FFUVcy(SELF, path, title="") : FFkPRK(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFhvmT(SELF, title="")  : FFkPRK(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFkPRK(session, message, title="") : session.open(BF(CCJVXf, title=title, message=message))
def FF5ZDh(SELF, VVsfO0, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVsfO0, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVsfO0, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFh60c(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFe4rI(SELF, callBack_Yes, VVT00f, callBack_No=None, title="", VVRAK2=False, VVmqJ5=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFjHaH, callBack_Yes, callBack_No)
         , BF(CCoKTm, title=title, VVT00f=VVT00f, VVmqJ5=VVmqJ5, VVRAK2=VVRAK2))
def FFjHaH(callBack_Yes, callBack_No, FFe4rIed):
 if FFe4rIed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFcw7s(*kargs, **kwargs):
 FFcigO(BF(FFZWPu, *kargs, **kwargs))
def FFZWPu(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFRkaP(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF7CXm(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFDQOc(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVWPGG = eTimer()
def FF7CXm(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FF7fWO, SELF))
 fnc = BF(FF7fWO, SELF)
 try:
  t = VVWPGG.timeout.connect(fnc)
 except:
  VVWPGG.callback.append(fnc)
 VVWPGG.start(milliSeconds, 1)
def FF7fWO(SELF):
 VVWPGG.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFXBR7(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCugyq, **kwargs))
  else   : win = SELF.session.open(BF(CCugyq, **kwargs))
  FFMPfH(win)
  return win
 except:
  return None
def FFaJ04(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CC9Nqc, **kwargs))
 FFMPfH(win)
 return win
def FF9lRG(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFuQxT(SELF, **kwargs):
 SELF.session.open(CC8xkn, **kwargs)
def FF4AQy(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
  except:
   pass
def FF5Gbi(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFaVeS(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVrHrQ, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFEPLV(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFaVeS(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FF02bi(SELF, winSize.width(), winSize.height())
def FF02bi(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FF7Vv0():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFX8wo(VVfp7o):
 screenSize  = FF7Vv0()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVfp7o)
 return bodyFontSize
def FFUpYz(VVfp7o, extraSpace):
 font = gFont(VVrHrQ, VVfp7o)
 VVbjgU = fontRenderClass.getInstance().getLineHeight(font) or (VVfp7o * 1.25)
 return int(VVbjgU + VVbjgU * extraSpace)
def FFWDRO(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FF7Vv0()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVrHrQ, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFUpYz(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVrHrQ, titleFontSize, alignLeftCenter)
 if winType in (VVG5k0, VVqSrQ):
  if winType == VVqSrQ : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVFovP:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVw6T7:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVrHrQ, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVAn5e:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFNvXQL = b2Left2 + timeW + marginLeft
  FFNvXQW = b2Left3 - marginLeft - FFNvXQL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFNvXQL , b2Top, FFNvXQW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVmUKz:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVRHe2:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVoBnl:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVyLlF:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVrHrQ, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVrHrQ, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVXc0G:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVrHrQ, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VV6PU3:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVrHrQ, fontH, alignCenter)
 elif winType in (VVZcl5, VVPeyn, VVDOHw, VVppbz, VVoarh):
  if   winType == VVZcl5  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVPeyn : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVDOHw : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVppbz : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVZcl5:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVrHrQ, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVrHrQ, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVrHrQ, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVrHrQ, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVrHrQ, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVrHrQ, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVrHrQ, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVZm1S:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV1bMC:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VV181V : align = alignLeftCenter
  elif winType == VVKV47 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV6FtF:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVrHrQ
  if usefixedFont and winType == VVKV47:
   fLst = FF7uj5()
   if   VVHPQk in fLst and CFG.fontPathTerm.getValue(): fontName = VVHPQk
   elif VVaizI in fLst         : fontName = VVaizI
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVfp7o = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVrHrQ, VVfp7o, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVrHrQ, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVkhZN[i], VVrHrQ, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVKV47:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVkhZN[i], VVrHrQ, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVlgBc = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVX28J)
  VVY9NT = []
  if VVH3JP:
   VVY9NT.append(("-- MY TEST --", "myTest" ))
  VVY9NT.append(("File Manager"  , "fMan" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("IPTV"    , "iptv" ))
  VVY9NT.append(("Movies Browser" , "movie" ))
  VVY9NT.append(("Services/Channels", "chan" ))
  VVY9NT.append(("PIcons"   , "picon" ))
  VVY9NT.append(("EPG"    , "epg"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Terminal"   , "term" ))
  VVY9NT.append(("SoftCam"   , "soft" ))
  VVY9NT.append(("Plugins"   , "plug" ))
  VVY9NT.append(("Backup & Restore" , "bakup" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Date/Time"  , "date" ))
  VVY9NT.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVY9NT):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVY9NT[ndx] = tuple(item)
  FFsd9n(self, title=self.Title, VVY9NT=VVY9NT)
  FFKpuS(self["keyRed"] , "Exit")
  FFKpuS(self["keyGreen"] , "Settings")
  FFKpuS(self["keyYellow"], "Dev. Info.")
  FFKpuS(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVnAWN      ,
   "yellow": self.VVxHOi      ,
   "blue" : self.VV4zsm     ,
   "info" : BF(FFDKj1, self, self.VV6gD6) ,
   "text" : self.VVA3kJ      ,
   "menu" : self.VVeeDI    ,
   "0"  : BF(self.VVKGI5, 0)   ,
   "1"  : BF(self.VVn6j2, "fMan")   ,
   "2"  : BF(self.VVn6j2, "iptv")   ,
   "3"  : BF(self.VVn6j2, "movie")   ,
   "4"  : BF(self.VVn6j2, "chan")   ,
   "5"  : BF(self.VVn6j2, "picon")   ,
   "6"  : BF(self.VVn6j2, "epg")   ,
   "7"  : BF(self.VVn6j2, "term")   ,
   "8"  : BF(self.VVn6j2, "soft")   ,
   "9"  : BF(self.VVn6j2, "plug")   ,
   "last" : BF(self.VVn6j2, "bakup")   ,
   "next" : BF(self.VVn6j2, "date")
  })
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
  global VVRR1W, VVnusr
  VVRR1W = VVnusr = False
 def VVz6TU(self):
  self.VVn6j2(self["myMenu"].l.getCurrentSelection()[1])
 def VVn6j2(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVLN9R
   VVLN9R = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVBNgp()
   elif item == "fMan"  : self.session.open(CCVdBH)
   elif item == "iptv"  : self.session.open(CCHli4)
   elif item == "movie" : FFDKj1(self, BF(CCGed9.VVicEA, self))
   elif item == "chan"  : self.session.open(CCwvQw)
   elif item == "picon" : self.VV8HWI()
   elif item == "epg"  : self.session.open(CCI7Ct)
   elif item == "term"  : self.session.open(CC7PJi)
   elif item == "soft"  : self.session.open(CCrxMo)
   elif item == "plug"  : self.session.open(CCHlgZ)
   elif item == "bakup" : self.session.open(CCpb7x)
   elif item == "date"  : self.session.open(CCWNSr)
   elif item == "net"  : self.session.open(CCuRKo)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
  FF4AQy(self)
  FFnx82(self)
  VVA9h3, VV69PD, VV0Ar3, VVGq9q, VVtQMR, oldMovieDownloadPath = FFNERR()
  if VVA9h3 or VV69PD or VV0Ar3 or VVGq9q or VVtQMR or oldMovieDownloadPath:
   VVg0pA = lambda path, subj: "%s:\n%s\n\n" % (subj, FFbRJw(path, VVxsyh)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVg0pA(VVA9h3   , "Backup/Restore Path"    )
   txt += VVg0pA(VV69PD  , "Created Package Files (IPK/DEB)" )
   txt += VVg0pA(VV0Ar3  , "Download Packages (from feeds)" )
   txt += VVg0pA(VVGq9q , "Exported Tables"     )
   txt += VVg0pA(VVtQMR , "Exported PIcons"     )
   txt += VVg0pA(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFHdWy(self, txt, title="Settings Paths")
  self.VVPHZ1()
  if (EASY_MODE or VVoefQ or VVH3JP):
   FFRkaP(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFZWPu(self, "Welcome", 300)
  FFcigO(self.VVGREN)
 def VVGREN(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CC0lek.VVNUdC()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  os.system(FF75pk("rm /tmp/ajp_*"))
  global VVRR1W, VVnusr
  VVRR1W = VVnusr = False
 def VVKGI5(self, digit):
  self.VVlgBc += str(digit)
  ln = len(self.VVlgBc)
  global VVRR1W
  if ln == 4:
   if self.VVlgBc == "0" * ln:
    VVRR1W = True
    FFRkaP(self["myTitle"], "#11805040")
   else:
    self.VVlgBc = "x"
 def VVA3kJ(self):
  self.VVlgBc += "t"
  if self.VVlgBc == "0" * 4 + "t" * 2:
   global VVnusr
   VVnusr = True
   FFRkaP(self["myTitle"], "#dd5588")
 def VV8HWI(self):
  found = False
  pPath = CCZBEU.VV0FjB()
  if pathExists(pPath):
   for fName, fType in CCZBEU.VVGoX4(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCZBEU)
  else:
   VVY9NT = []
   VVY9NT.append(("PIcons Tools" , "CCZBEU" ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(CCZBEU.VV0Gov())
   VVY9NT.append(VVXMhc)
   VVY9NT += CCZBEU.VVKEPJ()
   FFaJ04(self, self.VVJglr, VVY9NT=VVY9NT)
 def VVJglr(self, item=None):
  if item:
   if   item == "CCZBEU"   : self.session.open(CCZBEU)
   elif item == "VVyCBm"  : CCZBEU.VVyCBm(self)
   elif item == "VVMeKe"  : CCZBEU.VVMeKe(self)
   elif item == "findPiconBrokenSymLinks" : CCZBEU.VVHTCl(self, True)
   elif item == "FindAllBrokenSymLinks" : CCZBEU.VVHTCl(self, False)
 def VV6gD6(self):
  changeLogFile = VVE5ib + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFun41(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFbRJw("\n%s\n%s\n%s" % (VVwtEz, line, VVwtEz), VVOpMG, VVViAb)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFbRJw(line, VVlhbS, VVViAb)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFHdWy(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVX28J, PLUGIN_DESCRIPTION), VVfp7o=28, width=1600, height=1000, VVWGqy="#11000011")
 def VVeeDI(self):
  VVY9NT = []
  VVY9NT.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Keys Help"     , "hlp" ))
  FFaJ04(self, self.VV4S3V, VVY9NT=VVY9NT, width=650, title="Options")
 def VV4S3V(self, item=None):
  if item:
   if   item == "libr" : FFDKj1(self, BF(self.VVKUG0))
   elif item == "hlp" : FFv9kY(self, "_help_main", "Main Page (Keys Help)")
 def VVnAWN(self) : self.session.open(CC0lek)
 def VVxHOi(self) : self.session.open(CC1xY8)
 def VV4zsm(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVPWV9, VVxsyh, VVmuI1, VVFaDd
  VVY9NT = []
  VVY9NT.append((c1 + "Change Title Colors"   , "title"  ))
  VVY9NT.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVY9NT.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVY9NT.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVY9NT.append((c2 + "Reset Colors"    , "resetColor" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVY9NT.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c4 + "Change System Font"    , "sysFont"  ))
  FFaJ04(self, BF(self.VV7fIZ, title), VVY9NT=VVY9NT, width=600, title=title)
 def VV7fIZ(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVmGde()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVZM8g, tDict, item), CCYdfZ, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFe4rI(self, self.VVY8pp, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVa7SU(VVkmMH  )
   elif item == "termFont"  : self.VVa7SU(VVHPQk)
   elif item == "sysFont"  : self.VVa7SU(VVtCop  )
 def VVKUG0(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVJnaJ, pkgs = self.VVr68l()
  VVY2vy = ("Install", BF(self.VVtbPp, title, pkgs)  , [])
  VVNlag  = ("Update Sys. Packages", self.VVx0zM , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VV3dzh = (LEFT  , CENTER , LEFT  )
  VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, width=1350, VVY2vy=VVY2vy, VVNlag=VVNlag, VVjOuo="#00ffffaa", VVu0ZD=1)
 def VVtbPp(self, Title, pkgs, VV5PsO, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVI0aP, VV5PsO)
   item = colList[0]
   if   item == "requests" : CCWQxC.VVTp8Y(self, cbFnc=cbFnc)
   elif item == "Imaging" : CC1HIn.VV4AmA(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFx5HE(self, FFYhIs(), VV54cX=cbFnc)
   elif item in pkgs  : FFx5HE(self, FFKkrr(item, item, item.capitalize()), VV54cX=cbFnc)
  else:
   FFZWPu(VV5PsO, "Already installed.", 700, isGrn=True)
 def VVx0zM(self, VV5PsO, title, txt, colList):
  CCHlgZ.VVu8yb(self)
 def VVI0aP(self, VV5PsO):
  VVJnaJ, pkgs = self.VVr68l()
  VV5PsO.VVvHOE(VVJnaJ[VV5PsO.VV3w14()])
 def VVr68l(self):
  tDict = {}
  path = VVE5ib + "_sup_lib"
  if fileExists(path):
   for line in FFun41(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVg0pA(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFbRJw("Installed", VVlwDq), txt)
   else : return (lib, FFbRJw("Not installed", VVzF5b), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVJnaJ = []
  VVJnaJ.append(VVg0pA("requests", CCWQxC.VVTp8Y(self, install=False)))
  VVJnaJ.append(VVg0pA("Imaging" , CC1HIn.VV4AmA(self, "", False, install=False)))
  VVJnaJ.append(VVg0pA("ar"   , os.system("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 1; else exit 0; fi")))
  for item in pkgs: VVJnaJ.append(VVg0pA(item, FF1yPm(item)))
  VVJnaJ.sort(key=lambda x: x[0].lower())
  return VVJnaJ, pkgs
 def VVWwVf(self):
  return VVPUYO + "ajpanel_colors"
 def VVmGde(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVWwVf()
  if fileExists(p):
   txt = FFvr8J(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVZM8g(self, tDict, item, fg, bg):
  if fg:
   self.VVEfv1(item, fg)
   self.VVpwcP(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVj3da(tDict)
 def VVj3da(self, tDict):
   p = self.VVWwVf()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVEfv1(self, item, fg):
  if   item == "title" : FFR9H9(self["myTitle"], fg)
  elif item == "body"  :
   FFR9H9(self["myMenu"], fg)
   FFR9H9(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFR9H9(self[item], fg)
 def VVpwcP(self, item, bg):
  if   item == "title" : FFRkaP(self["myTitle"], bg)
  elif item == "body"  :
   FFRkaP(self["myMenu"], bg)
   FFRkaP(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFRkaP(self["myBar"], bg)
 def VVY8pp(self):
  os.system(FF75pk("rm %s" % self.VVWwVf()))
  self.close()
 def VVPHZ1(self):
  tDict = self.VVmGde()
  for item in ("title", "body", "cursor", "bar"):
   self.VVSPNl(tDict, item)
 def VVSPNl(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVEfv1(name, fg)
  if bg: self.VVpwcP(name, bg)
 def VVa7SU(self, which):
  if   which == VVkmMH  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVHPQk : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVtCop  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCc81z.VVx3so(self, "Change %s Font" % title, defFnt, rest, BF(self.VVhcXs, which))
 def VVhcXs(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVkmMH  : FFoBdB(CFG.fontPathMain, path)
   elif which == VVHPQk: FFoBdB(CFG.fontPathTerm, path)
   elif which == VVtCop  : FFoBdB(CFG.fontPathSys , path)
   err = Main_Menu.VVVssr(which)
   if err          : FFh60c(self, err, title=title)
   elif which == VVkmMH   : self.close()
   elif which == VVHPQk  : FFZWPu(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVtCop and path: FFZWPu(self, "System font applied", 1500, isGrn=True)
   elif which == VVtCop   : FFe4rI(self, BF(Main_Menu.VVjtjK, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVjtjK(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVVssr(name):
  if   name == VVkmMH : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVHPQk: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVtCop : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FF7uj5()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVtCop:
   nameLst = []
   for nm in FF7uj5():
    if not nm in (VVkmMH, VVHPQk):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FF8ceC(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FF7uj5()
  else    : return "Could not add font"
 def VVBNgp(self):
  CCFx66.VV1I99(self)
class CCuRKo(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVPUYO, "ajpanel_network")
  c1, c2 = VVmuI1, VVPWV9
  VVY9NT = []
  VVY9NT.append((c1 + "Network Devices"     , "dev" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Network Scanner (ping)"    , "ping"))
  VVY9NT.append(("Port Scanner (scan for famous ports)" , "port"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c2 + "Check Internet Connection"  , "intr"))
  FFsd9n(self, title="Network Tools", VVY9NT=VVY9NT)
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFDKj1(self, self.VVAnCi, title="REading Devices ...")
  elif item == "ping" : FFDKj1(self, self.VVLBJZ, title="Scanning ...")
  elif item == "port" : CCo7Gj.VVVHQ4(self, self.VVIYEh, title="Select host to scan")
  elif item == "intr" : self.session.open(CCTX3s)
 def VVAnCi(self, canCencel=False):
  title = "Network Devices"
  VVJnaJ = self.VVnfAn()
  if VVJnaJ:
   bg = "#0a223333"
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVo9Gm = BF(self.VVMVEe, canCencel)
   VVNiXY  = ("Start FTP"   , self.VVxnwh    , [])
   VVuKTt = ("Entry Options"  , self.VVKGMD  , [])
   VVNlag = ("Scan for Devices" , self.VVcQmR , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VV3dzh = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, width=1500, height=900, VVgZrM=widths, VVfp7o=28, VVNiXY=VVNiXY, VVo9Gm=VVo9Gm, VVuKTt=VVuKTt, VVNlag=VVNlag
       , VVU4bo=bg, VVdq78=bg, VVWGqy=bg, VVjOuo="#11ffff00", VVpoY2="#11220000", VVUWnf="#00333333", VVwS5R="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VV5PsO.VVyOnh(ndx)
  else:
   FFe4rI(self, BF(FFDKj1, self, BF(self.VV4pNc, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVMVEe, canCencel), title=title)
 def VVKGMD(self, VV5PsO, title, txt, colList):
  VVY9NT = []
  VVY9NT.append(("Change Username"   , "user"))
  VVY9NT.append(("Change Password"   , "pass"))
  VVY9NT.append(("Change Remarks"   , "rem"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Remove Selected Server" , "del"))
  FFaJ04(self, BF(self.VVpYo3, VV5PsO), VVY9NT=VVY9NT, title="Entry Options")
 def VVpYo3(self, VV5PsO, item=None):
  if item:
   if   item == "user" : self.VVnahq("u", VV5PsO)
   elif item == "pass" : self.VVnahq("p", VV5PsO)
   elif item == "rem" : self.VVnahq("r", VV5PsO)
   elif item == "del" : FFe4rI(self, BF(FFDKj1, self, BF(self.VVXP6y, VV5PsO), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVMVEe(self, canCencel, VV5PsO=None):
  if VV5PsO: VV5PsO.cancel()
  if canCencel : self.close()
 def VVxnwh(self, VV5PsO, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFoBdB(CFG.lastNetworkDevice, VV5PsO.VV3w14())
  self.session.openWithCallback(BF(self.VV3wJY, entry, VV5PsO), CCgQZl, entry)
 def VV3wJY(self, entry, VV5PsO, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVvIgl("d", newPath, ip, u, p, path, rem)
    self.VV5zwb(VV5PsO)
 def VVcQmR(self, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VV4pNc, mainTableInst=VV5PsO), title="Scanning Network ...")
 def VV4pNc(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCo7Gj.VVhG7i(CCo7Gj.VVN85q)
  if err:
   FFh60c(self, err, title=title)
   return
  telLst, err = CCo7Gj.VVhG7i(CCo7Gj.VVKTbj)
  if err:
   FFh60c(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VV2th9(p1, p2): return FFSOId(p1[0], p2[0])
   lst.sort(key=FFKPxS(VV2th9))
   bg = "#0a202020"
   VVo9Gm = BF(self.VVMVEe, canCencel)
   VVNiXY  = ("Add to Devices" , BF(self.VVRMOS, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VV3dzh = (LEFT   , CENTER   , CENTER  )
   FFXBR7(self, None, title=title, header=header, VV0wO4=lst, VV3dzh=VV3dzh, VVgZrM=widths, width=1200, VVfp7o=30, VVNiXY=VVNiXY, VVo9Gm=VVo9Gm, VVu0ZD=2
     , VVU4bo=bg, VVdq78=bg, VVWGqy=bg, VVjOuo="#11ffffaa", VVpoY2="#0a225555", VVwS5R="#11403040")
  else:
   FFh60c(self, "No devices found !", title=title)
 def VVLBJZ(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCo7Gj.VVhG7i(-1)
  if err:
   FFh60c(self, err, title=title)
  elif lst:
   def VV2th9(p1, p2): return FFSOId(p1[0], p2[0])
   lst.sort(key=FFKPxS(VV2th9))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VV3dzh = (LEFT   , LEFT   )
   FFXBR7(self, None, title=title, header=header, VV0wO4=lst, VV3dzh=VV3dzh, VVgZrM=widths, width=1000, height=700, VVfp7o=30
     , VVU4bo=bg, VVdq78=bg, VVWGqy=bg, VVjOuo="#11ffffaa", VVpoY2="#0a225555", VVwS5R="#11403040")
  else:
   FFh60c(self, "Network scanning failed !", title=title)
 def VVIYEh(self, ip=None):
  if ip:
   FFDKj1(self, BF(self.VVIGSE, ip), title="Scanning %s" % ip)
 def VVIGSE(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCo7Gj.VVXAii(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCo7Gj.VVMXhJ(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFHdWy(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVnfAn(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFvr8J(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VV2th9(p1, p2): return FFSOId(p1[0], p2[0])
  tLst.sort(key=FFKPxS(VV2th9))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVnfAn(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFvr8J(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VV2th9(p1, p2): return FFSOId(p1[0], p2[0])
  tLst.sort(key=FFKPxS(VV2th9))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVRMOS(self, mainTableInst, canCencel, VV5PsO, title, txt, colList):
  ip, mac, typ = VV5PsO.VVAxC0(VV5PsO.VV3w14())
  if "Own" in ip:
   FFZWPu(VV5PsO, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVnfAn():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     CCgBRx.VV8R3u(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVUtUa(ip, u, p, path, rem))
   if mainTableInst: self.VV5zwb(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVAnCi(canCencel)
   VV5PsO.cancel()
 def VVUtUa(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVXP6y(self, VV5PsO):
  num, ip, u, p, path, rem = VV5PsO.VVAxC0(VV5PsO.VV3w14())
  lst = self.VVnfAn()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVUtUa(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VV5zwb(VV5PsO)
  else:
   VV5PsO.cancel()
 def VVnahq(self, col, VV5PsO):
  num, ip, u, p, path, rem = VV5PsO.VVAxC0(VV5PsO.VV3w14())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FF5ZDh(self, BF(self.VVRqyU, col, orig, VV5PsO, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVRqyU(self, col, orig, VV5PsO, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFZWPu(VV5PsO, "No change", 1500)
   elif not newTxt and col == "u":
    FFZWPu(VV5PsO, "No user !", 2000)
   else:
    self.VVvIgl(col, newTxt, ip, u, p, path, rem)
    self.VV5zwb(VV5PsO)
 def VVvIgl(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVnfAn()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVUtUa(ip1, u1, p1, path1, rem1))
 def VV5zwb(self, VV5PsO, newEntry=None):
  VVJnaJ = self.VVnfAn()
  if VVJnaJ : VV5PsO.VVQNRz(VVJnaJ, tableRefreshCB=BF(self.VVTD8s, newEntry))
  else  : VV5PsO.cancel()
 def VVTD8s(self, newEntry, VV5PsO, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VV5PsO.VVexgG()):
    if row[1:] == newEntry:
     VV5PsO.VVyOnh(ndx)
 def VVMVEe(self, canCencel, VV5PsO=None):
  if VV5PsO: VV5PsO.cancel()
  if canCencel : self.close()
class CCo7Gj():
 VVN85q = 21
 VVKTbj = 23
 def __init__(self):
  self.VVazuT()
 def VVazuT(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VV75Cr(self, ip, User, Pass, timeout=5):
  myIp = CCo7Gj.VVRCRn()
  if ip != myIp:
   if CCo7Gj.VVMXhJ(ip, CCo7Gj.VVN85q):
    self.VVazuT()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VV0Mc1(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVuw6a(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVJjyO(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVuw6a()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVqNOx(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVbbH2(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VV1upZ(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VV0JkG(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVrxFt(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VV0JkG()
   if self.VV1upZ(path) : typ = "d"
   else      : typ = "b"
   self.VV1upZ(curDir)
   return typ
 def VVD0oX(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VV1upZ(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVfFXt(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVJKFR(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VV0EeW(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVV6gU(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVD0oX(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFiHj6(locFile)
   return "", sz, str(e)
 def VV58Il(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVazuT()
 @staticmethod
 def VVYhPN():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVRCRn():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVucvY():
  myIp = CCo7Gj.VVRCRn()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVYVjY():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFA2wB("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVgyB5(port=-1):
  lst = []
  def VVhPOT(ip):
   if port > -1: ok = CCo7Gj.VVMXhJ(ip, port)
   else  : ok = CCo7Gj.VVXAii(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCo7Gj.VVucvY()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVhPOT, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVhG7i(port):
  myIp = CCo7Gj.VVRCRn()
  myGw = CCo7Gj.VVYVjY()
  tDict = { myIp: CCo7Gj.VVYhPN() }
  devLst, err = CCo7Gj.VVgyB5(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFJ6lf("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVmuI1
    elif key == myGw: txt = " %s Gateway" % VVmuI1
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVXAii(ip):
  return True if os.system(FF75pk("ping -W1 -q -c1 %s" % ip)) == 0 else False
 @staticmethod
 def VVMXhJ(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVHLsi(ip="1.1.1.1", timeout=1):
  if CCo7Gj.VVMXhJ(ip, 53, timeout):
   return True
  if CCo7Gj.VVXAii(ip):
   return True
  return os.system(FF75pk("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
 @staticmethod
 def VVVHQ4(SELF, okFnc, title):
  baseIp = CCo7Gj.VVucvY()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFaJ04(SELF, okFnc, VVY9NT=lst, width=600, title=title, VVU4bo="#222222", VVdq78="#222222")
class CCgQZl(Screen, CCo7Gj):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVfp7o  = self.skinParam["bodyFontSize"]
  self.VVbjgU  = self.skinParam["bodyLineH"]
  self.VVHDWp  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCRrOq.VVPbiG("fil")
  self.png_dir  = CCRrOq.VVPbiG("dir")
  self.png_dirup  = CCRrOq.VVPbiG("dirup")
  self.png_slwfil  = CCRrOq.VVPbiG("slwfil")
  self.png_slbfil  = CCRrOq.VVPbiG("slbfil")
  self.png_slwdir  = CCRrOq.VVPbiG("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCo7Gj.__init__(self)
  VVY9NT = [("Item-%d" % x,) for x in range(50)]
  FFsd9n(self, title=self.Title, VVY9NT=VVY9NT)
  FFKpuS(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVY9NT, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVrHrQ, self.VVfp7o))
  self["myMenu"].l.setItemHeight(self.VVbjgU)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : BF(self.VVNdWb, True) ,
   "ok" : self.VVz6TU    ,
   "cancel": self.VVNdWb    ,
   "menu" : self.VVd7QM   ,
   "info" : self.VVGWjJ  ,
   "pageUp": self.VVDoux    ,
   "chanUp": self.VVDoux
  })
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVRj07)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
  FF4AQy(self)
  FFnx82(self)
  FFRkaP(self["keyBlue"], "#11333333")
  FFDKj1(self, self.VVxeNX, title="Connecting ...")
 def VVxeNX(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VV75Cr(ip, u, p)
  if err:
   FFh60c(self, err, title=self.Title)
   FFKpuS(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFKpuS(self["keyBlue"], self.ftpIp)
   if not self.VV1upZ(path):
    path = "/"
   self.VVl229(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVuw6a():
   self.VV58Il()
 def VVz6TU(self):
  if self.VVBNFS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVl229(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVDoux()
    else         : self.VVZ2Ag(os.path.join(self.curDir, name))
 def VVNdWb(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVDoux()
 def VVBNFS(self):
  if self.VVuw6a():
   return True
  else:
   FFh60c(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVZ2Ag(self, path):
  cat = self.VV0QZt(path)
  if cat in ("pic"):
   FFDKj1(self, BF(self.VVyaqr, path))
  elif cat in ("mov", "mus"):
   if CCHli4.VVAMy8("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFDKj1(self, BF(CCVdBH.VVe3wa, self, url, rType=rType), title="Playing Media ...")
 def VVyaqr(self, path):
  locFile, size, err = self.VVV6gU(path)
  if err: FFh60c(self, err, title="View Picture File")
  else  : CCG5Yr.VV12Wn(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFiHj6))
 def VVRj07(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCRrOq.VVq03P else sel[0][0])
  else  : title=  VVzF5b + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVDoux(self):
  if self.VVBNFS():
   lastPart = FFjufa(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVl229(parentDir, lastPart, "d")
 def VVl229(self, Dir, moveTo="", moveToType=""):
  FFDKj1(self, BF(self.VVHSY0, Dir, moveTo, moveToType))
 def VVHSY0(self, Dir, moveTo, moveToType):
  files, err = self.VVbbH2(Dir, isLong=True)
  self.curDir = self.VV0JkG() or "/"
  self.VVnRGo(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVnRGo(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VV3Mzg(CCRrOq.VVq03P, CCRrOq.VVq03P, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVrxFt(target)
    color = VVzF5b if targetState == "b" else VVlwDq
    origName = name + VVOpMG + linkSep + color + " "+ target
   self.list.append(self.VV3Mzg(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VV3Mzg(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VV0QZt(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVE5ib, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCRrOq.VVq03P: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVbjgU + 10, 0, self.VVHDWp, self.VVbjgU, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VVmqKk: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVbjgU-4, self.VVbjgU-4, png, None, None, VVmqKk))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVbjgU-4, self.VVbjgU-4, png, None, None))
  return tableRow
 def VV0QZt(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCRrOq.VVhZIz().items():
    if ext in lst:
     return cat
  return ""
 def VVd7QM(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCRrOq.VVq03P
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVKsbL(titl, ref, chk, color=""):
   if chk: return VVY9NT.append((color + titl, ref))
   else  : return VVY9NT.append((titl, ))
  VVY9NT = []
  VVKsbL("Properties", "VVGWjJ", not isTop)
  c = VVmuI1
  VVY9NT.append(VVXMhc)
  VVKsbL("Download Selected File ..."    , "FFzm7RFromServer", isFile, c)
  VVKsbL("Upload a Local File to Remote Server ...", "VVAv5d" , True  , c)
  VVY9NT.append(VVXMhc)
  VVKsbL("Create new directory", "VVLYln", True)
  VVKsbL("Rename", "VV6O2g", not isTop)
  VVKsbL("DELETE", "VVGxcn", not isTop, VVLO3F)
  VVY9NT.append(VVXMhc)
  VVKsbL("FTP Server Information", "VVT8Ir", True)
  VVY9NT.append(VVXMhc)
  VVKsbL("Refresh File List", "refresh", True)
  FFaJ04(self, self.VVGx2R, VVY9NT=VVY9NT, title="Options")
 def VVGx2R(self, item=None):
  if item:
   if   item == "VVGWjJ"     : self.VVGWjJ()
   elif item == "FFzm7RFromServer"   : self.FFzm7RFromServer()
   elif item == "VVAv5d"   : self.VVAv5d()
   elif item == "VVLYln"   : self.VVLYln()
   elif item == "VV6O2g"   : self.VV6O2g()
   elif item == "VVGxcn"   : self.VVGxcn()
   elif item == "VVT8Ir"    : self.VVT8Ir()
   elif item == "refresh"and self.VVBNFS() : self.VVl229(self.curDir)
 def VVGWjJ(self):
  if self.VVBNFS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFbRJw("Path", VVmuI1), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVD0oX(path)
    if sz > -1: txt += "Size\t: %s" % CCVdBH.VVFJRm(sz)
   else:
    txt = "Nothing selected"
   FFHdWy(self, txt, title="Properties")
 def VVT8Ir(self):
  if self.VVBNFS():
   Sys  = self.VV0Mc1() or " -"
   txt = "%s\n  %s\n\n" % (FFbRJw("System:", VVmuI1), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVqNOx() or " -"
   txt += "%s\n" % (FFbRJw("Status:", VVmuI1))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFHdWy(self, txt, title="FTP Server Information")
 def VVLYln(self, name=""):
  if self.VVBNFS():
   title = "Add New Directory"
   FF5ZDh(self, BF(self.VV1zKd, title), defaultText=name, title=title, message="Enter Directory name")
 def VV1zKd(self, title, name):
  if name and name.strip():
   if self.VVfFXt(name) : self.VVl229(self.curDir, name, "d")
   else     : FFh60c(self, "Failed to create : %s" % name, title)
 def VV6O2g(self):
  if self.VVBNFS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FF5ZDh(self, BF(self.VVRUFD, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVRUFD(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VV0EeW(name, newName.strip()) : self.VVl229(self.curDir, newName, flag)
   else          : FFh60c(self, "Failed to rename to : %s" % newName, title)
 def VVGxcn(self):
  if self.VVBNFS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFe4rI(self, BF(FFDKj1, self, BF(self.VV20BM, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VV20BM(self, name, flag):
  if self.VVJKFR(name, flag) : self.VVl229(self.curDir)
  else         : FFh60c(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFzm7RFromServer(self):
  if self.VVBNFS():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVD0oX(remFile)
    if size == -1:
     FFh60c(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVPUYO
     self.session.openWithCallback(BF(self.VVsyXC, title, remFile, name, size), BF(CCVdBH, mode=CCVdBH.VVHQKD, VVJO71="Download here", VVWic9=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVsyXC(self, title, remFile, name, size, locPath):
  if locPath:
   FFoBdB(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVbahR, remFile, size, locFile)
       , VVsfO0 = BF(self.VVxbdM, remFile, size, locFile))
 def VVbahR(self, remFile, size, locFile, VVq6PE):
  VVq6PE.VVlEfz(size)
  VVq6PE.VVwxC6 = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVFHXa(data):
     if not VVq6PE or VVq6PE.isCancelled:
      return
     locFileObj.write(data)
     VVq6PE.VVA8Cz(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVFHXa)
   except Exception as e:
    VVq6PE.VVwxC6 = str(e)
 def VVxbdM(self, remFile, size, locFile, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVwxC6:
   FFh60c(self, "%s\n\nftp:/%s" % (VVwxC6, remFile), title="Download Error")
   delF = True
  elif not VVWVbF:
   FFh60c(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFtDuT(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFNvXQ(self, txt, title=title)
   else:
    FFh60c(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFiHj6(locFile)
 def VVAv5d(self):
  if self.VVBNFS():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVPUYO
   self.session.openWithCallback(self.VVsXdp, BF(CCVdBH, VVJO71="Upload selected file", VVWic9=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVsXdp(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFoBdB(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFtDuT(locFile)
   if size == -1:
    FFh60c(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVDisx, locFile, size, remFile)
        , VVsfO0 = BF(self.VVDNOj, locFile, size, remFile))
 def VVDisx(self, locFile, size, remFile, VVq6PE):
  VVq6PE.VVlEfz(size)
  VVq6PE.VVwxC6 = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVPd6x(data):
     if not VVq6PE or VVq6PE.isCancelled:
      VVq6PE.VVwxC6 = "Upload cancelled"
      locFileObj.close()
      return
     VVq6PE.VVA8Cz(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVPd6x)
   except Exception as e:
    VVq6PE.VVwxC6 = VVq6PE.VVwxC6 or str(e)
 def VVDNOj(self, locFile, size, remFile, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVWVbF:
   if size == FFtDuT(locFile) : FFNvXQ(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVwxC6 : err = "%s\n\n%s" % (VVwxC6, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFh60c(self, err, title=title)
   self.VVJjyO()
   self.VVJKFR(remFile, "")
  self.VVl229(self.curDir)
class CC1HIn():
 VVX82d  = "all"
 VVF4Xf = "vid"
 VVG0V8  = "osd"
 @staticmethod
 def VVOx1Z(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FF1yPm("grab"):
    winShown = session.current_dialog.shown
    if k == CC1HIn.VVF4Xf and winShown: session.current_dialog.hide()
    FFcigO(BF(CC1HIn.VV2BPt, title, session, k, winShown))
   else:
    FFkPRK(session, "No Grab command !", title=title)
 @staticmethod
 def VV2BPt(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CC1HIn.VVG0V8:
   if not winShown:
    FFkPRK(session, "No Window to capture !", title=title)
    return
   if not CC1HIn.VV4AmA(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CC1HIn.VVMKJ3(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFkPRK(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFd5Wt(CFG.exportedPIconsPath.getValue()), fTitle, FFDaMH(), ext)
  res = os.system(FFJvZy("grab -q -s %s > '%s'" % (typ, path)))
  if k == CC1HIn.VVF4Xf and winShown:
   session.current_dialog.show()
  elif k == CC1HIn.VVG0V8:
   ok = CC1HIn.VVR3CN(path, x, y, w, h)
   if not ok:
    FFiHj6(path)
    FFkPRK(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCG5Yr, title=path, VVPYo2=path))
  else       : FFkPRK(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VV4AmA(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFe4rI(SELF, BF(CC1HIn.VVkHC4, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVkHC4(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFFSGY, VV54cX=cbFnc)
  else    : fnc = BF(FFx5HE , VV54cX=cbFnc)
  fnc(SELF, FFXUpj(VVzo0S, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVMKJ3(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVR3CN(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FF7Vv0()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFo5AX(x , 0, scrW, 0, w)
     y  = FFo5AX(y , 0, scrH, 0, h)
     x1 = FFo5AX(x1, 0, scrW, 0, w)
     y1 = FFo5AX(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVG0aD(path):
  size = FFtDuT(path)
  sizeTxt = CCVdBH.VVFJRm(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCc81z(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFbRJw(" (Requires GUI Restart)", VVFaDd) if withRestart else ""
  VVY9NT = []
  for path in self.fontsList:
   VVY9NT.append((os.path.splitext(os.path.basename(path))[0], path))
  VVY9NT.sort(key=lambda x: x[0].lower())
  VVY9NT.insert(0, VVXMhc)
  VVY9NT.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVY9NT):
    if len(item) == 2 and item[1] == self.defFnt:
     VVY9NT[ndx] = (VVlwDq + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVY9NT[curIndex] = (VVlwDq + VVY9NT[curIndex][0], VVY9NT[curIndex][1])
  FFsd9n(self, VVY9NT=VVY9NT, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
  self["myMenu"].onSelectionChanged.append(self.VVAUw4)
  self["myBar"].setText(self.VV0zTW())
  self["myBar"].instance.setHAlign(1)
  self.VVAUw4()
 def VVz6TU(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVAUw4(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FF8ceC(path, fnt, isRepl=1)
  else:
   fnt = VVnKBD
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VV0zTW(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVx3so(SELF, title, defFnt, rest, VVsfO0):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFzuBj(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVsfO0, CCc81z, title, fontsList, defFnt, rest)
  else  : FFh60c(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCE2ei(Screen):
 def __init__(self, session, path, VVY9NT, title):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFsd9n(self, VVY9NT=VVY9NT, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVz6TU   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVok5u,
   "chanUp" : self.VVok5u,
   "pageDown" : self.VVrAnr ,
   "chanDown" : self.VVrAnr ,
  }, -1)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
  FFRkaP(self["myLabelFrm"], "#11110000")
  FFRkaP(self["myLabelTit"], "#11663322")
  FFRkaP(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVL4hC)
  self.VVL4hC()
 def VVL4hC(self):
  if fileExists(self.path): txt = FFvr8J(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVz6TU(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVok5u(self) : self["myMenu"].moveToIndex(0)
 def VVrAnr(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCORAx():
 @staticmethod
 def VVMGfk():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVMIUk(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFXBR7(SELF, None, VV0wO4=lst, VVfp7o=30, VVu0ZD=1)
 @staticmethod
 def VV7Rit(path, SELF=None):
  for enc in CCORAx.VVMGfk():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFh60c(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVttmX(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VV4EMY(SELF, path, cbFnc, curEnc=VVJAPg, title="Select Encoding"):
  lst = CCORAx.VVZ1RP(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCE2ei, path, lst, title)
 @staticmethod
 def VVk8x7(SELF, cbFnc, curEnc=VVJAPg, title="Select Encoding"):
  lst = CCORAx.VVZ1RP(SELF, "", "")
  if lst:
   FFaJ04(SELF, cbFnc, title=title, VVY9NT=lst, width=1000, height=1000, VVU4bo="#22220000", VVdq78="#22220000", VVNDcU=True)
 @staticmethod
 def VVZ1RP(SELF, path, curEnc):
  lst = CCORAx.VVr3gM(path)
  if lst:
   VVY9NT = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVlwDq
    elif enc == VVJAPg: c = VVOpMG
    else      : c = ""
    VVY9NT.append((c + txt, enc))
   return VVY9NT
  else:
   FFcw7s(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVr3gM(path=""):
  encLst = []
  cPath = VVE5ib + "_sup_codecs"
  if fileExists(cPath):
   lines = FFun41(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCORAx.VVMGfk())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CC1xY8(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVY9NT = []
  VVY9NT.append(("Settings File"   , "SettingsFile"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Box Info"     , "VVt5lD"   ))
  VVY9NT.append(("Tuners Info"    , "VVppG2"  ))
  VVY9NT.append(("Python Version"   , "VVj820"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Screen Size"    , "ScreenSize"   ))
  VVY9NT.append(("Language/Locale"   , "Locale"    ))
  VVY9NT.append(("Processor"    , "Processor"   ))
  VVY9NT.append(("Operating System"   , "OperatingSystem"  ))
  VVY9NT.append(("Drivers"     , "drivers"    ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("System Users"    , "SystemUsers"   ))
  VVY9NT.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVY9NT.append(("Uptime"     , "Uptime"    ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Host Name"    , "HostName"   ))
  VVY9NT.append(("MAC Address"    , "MACAddress"   ))
  VVY9NT.append(("Network Configuration" , "NetworkConfiguration"))
  VVY9NT.append(("Network Status"   , "NetworkStatus"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Disk Usage"    , "VVXB7O"   ))
  VVY9NT.append(("Mount Points"    , "MountPoints"   ))
  VVY9NT.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVY9NT.append(("USB Devices"    , "USB_Devices"   ))
  VVY9NT.append(("List Block-Devices"  , "listBlockDevices" ))
  VVY9NT.append(("Directory Size"   , "DirectorySize"  ))
  VVY9NT.append(("Memory"     , "Memory"    ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVY9NT.append(("Running Processes"  , "RunningProcesses" ))
  VVY9NT.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFsd9n(self, VVY9NT=VVY9NT, title="Device Information")
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCcNqp)
   elif item == "VVt5lD"   : self.VVt5lD()
   elif item == "VVppG2"  : self.VVppG2()
   elif item == "VVj820"  : self.VVj820()
   elif item == "ScreenSize"   : FFHdWy(self, "Width\t: %s\nHeight\t: %s" % (FF7Vv0()[0], FF7Vv0()[1]))
   elif item == "Locale"    : CCORAx.VVMIUk(self)
   elif item == "Processor"   : self.VVhXYF()
   elif item == "OperatingSystem"  : FFOm4Z(self, "uname -a")
   elif item == "drivers"    : self.VVTXkY()
   elif item == "SystemUsers"   : FFOm4Z(self, "id")
   elif item == "LoggedInUsers"  : FFOm4Z(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFOm4Z(self, "uptime")
   elif item == "HostName"    : FFOm4Z(self, "hostname")
   elif item == "MACAddress"   : self.VVyjpe()
   elif item == "NetworkConfiguration" : FFOm4Z(self, "ifconfig %s %s" % (FFs7EJ("HWaddr", VVW5KH), FFs7EJ("addr:", VVOpMG)))
   elif item == "NetworkStatus"  : FFOm4Z(self, "netstat -tulpn", VVfp7o=24, consFont=True)
   elif item == "VVXB7O"   : self.VVXB7O()
   elif item == "MountPoints"   : FFOm4Z(self, "mount %s" % (FFs7EJ(" on ", VVOpMG)))
   elif item == "FileSystemTable"  : FFOm4Z(self, "cat /etc/fstab", VVfp7o=24, consFont=True)
   elif item == "USB_Devices"   : FFOm4Z(self, "lsusb")
   elif item == "listBlockDevices"  : FFOm4Z(self, "blkid")
   elif item == "DirectorySize"  : FFOm4Z(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVTGFI="Reading size ...")
   elif item == "Memory"    : FFOm4Z(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VV7gcz()
   elif item == "RunningProcesses"  : FFOm4Z(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFOm4Z(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVp0GN()
   else        : self.close()
 def VVyjpe(self):
  res = FFJ6lf("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFHdWy(self, txt)
  else:
   FFOm4Z(self, "ip link")
 def VVXrQS(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFLYXX(cmd)
  return lines
 def VVt35N(self, lines, headerRepl, widths, VV3dzh):
  VVJnaJ = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVJnaJ.append(parts)
  if VVJnaJ and len(header) == len(widths):
   VVJnaJ.sort(key=lambda x: x[0].lower())
   FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, VVu0ZD=1)
   return True
  else:
   return False
 def VVXB7O(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFJ6lf(cmd)
  if not "invalid option" in txt:
   lines  = self.VVXrQS(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV3dzh = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVt35N(lines, headerRepl, widths, VV3dzh)
  else:
   cmd = "df -h"
   lines  = self.VVXrQS(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV3dzh = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVt35N(lines, headerRepl, widths, VV3dzh)
  if not allOK:
   lines = FFLYXX(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFUEil(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVlwDq:
     note = "\n%s" % FFbRJw("Green = Mounted Partitions", VVlwDq)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVOpMG
     elif line.endswith(mountList) : color = VVlwDq
     else       : color = VVlhbS
     txt += FFbRJw(line, color) + "\n"
    FFHdWy(self, txt + note)
   else:
    FFh60c(self, "Not data from system !")
 def VV7gcz(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVXrQS(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV3dzh = (LEFT , CENTER, LEFT )
  allOK = self.VVt35N(lines, headerRepl, widths, VV3dzh)
  if not allOK:
   FFOm4Z(self, cmd)
 def VVTXkY(self):
  cmd = FFv5Rb(VV5YBB, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFOm4Z(self, cmd)
  else : FFhvmT(self)
 def VVhXYF(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFOm4Z(self, cmd)
 def VVp0GN(self):
  cmd = FFv5Rb(VViMeN, "| grep secondstage")
  if cmd : FFOm4Z(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFhvmT(self)
 def VVt5lD(self):
  c = VVlwDq
  VV0wO4 = []
  VV0wO4.append((FFbRJw("Box Type"  , c), FFbRJw(self.VVEpC3("boxtype").upper(), c)))
  VV0wO4.append((FFbRJw("Board Version", c), FFbRJw(self.VVEpC3("board_revision") , c)))
  VV0wO4.append((FFbRJw("Chipset"  , c), FFbRJw(self.VVEpC3("chipset")  , c)))
  VV0wO4.append((FFbRJw("S/N"   , c), FFbRJw(self.VVEpC3("sn")    , c)))
  VV0wO4.append((FFbRJw("Version"  , c), FFbRJw(self.VVEpC3("version")  , c)))
  VVrRZa   = []
  VVerB3 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVerB3 = SystemInfo[key]
     else:
      VVrRZa.append((FFbRJw(str(key), VV619a), FFbRJw(str(SystemInfo[key]), VV619a)))
  except:
   pass
  if VVerB3:
   VVTp6K = self.VVaNnB(VVerB3)
   if VVTp6K:
    VVTp6K.sort(key=lambda x: x[0].lower())
    VV0wO4 += VVTp6K
  if VVrRZa:
   VVrRZa.sort(key=lambda x: x[0].lower())
   VV0wO4 += VVrRZa
  if VV0wO4:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFXBR7(self, None, header=header, VV0wO4=VV0wO4, VVgZrM=widths, VVfp7o=28, VVu0ZD=1)
  else:
   FFHdWy(self, "Could not read info!")
 def VVEpC3(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFun41(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVaNnB(self, mbDict):
  try:
   mbList = list(mbDict)
   VV0wO4 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV0wO4.append((FFbRJw(subject, VVOpMG), FFbRJw(value, VVOpMG)))
  except:
   pass
  return VV0wO4
 def VVppG2(self):
  txt = self.VVWT9u("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVWT9u("/proc/bus/nim_sockets")
  if not txt: txt = self.VVwPF6()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFHdWy(self, txt)
 def VVwPF6(self):
  txt = ""
  VVg0pA = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVg0pA("Slot Name" , slot.getSlotName())
     txt += FFbRJw(slotName, VVOpMG)
     txt += VVg0pA("Description"  , slot.getFullDescription())
     txt += VVg0pA("Frontend ID"  , slot.frontend_id)
     txt += VVg0pA("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVWT9u(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFun41(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFbRJw(line, VVOpMG)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVj820(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFHdWy(self, txt)
 @staticmethod
 def VV4KAs():
  def VVg0pA(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVg0pA(v,0), "/etc/issue.net": VVg0pA(v,1), "/etc/image-version": VVg0pA(v,2)}
  for p1, d in v.items():
   img = CC1xY8.VVxPJt(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVg0pA(v,0), p + "Plugins/": VVg0pA(v,1), VV4ItM: VVg0pA(v,2), VV9hRJ: VVg0pA(v,3)}
  for p1, d in v.items():
   img = CC1xY8.VVCRP2(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVxPJt(path, d):
  if fileExists(path):
   txt = FFvr8J(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVCRP2(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCcNqp(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVY9NT = []
  VVY9NT.append(("Settings (All)"   , "Settings_All"   ))
  VVY9NT.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVY9NT.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVY9NT.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVY9NT.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVY9NT.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVY9NT.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVnusr:
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVY9NT.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVn6iK
   grep = " | grep "
   if   item == "Settings_All"   : FFOm4Z(self, cmd)
   elif item == "Settings_HotKeys"  : FFOm4Z(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFOm4Z(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFOm4Z(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFOm4Z(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFOm4Z(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFOm4Z(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFOm4Z(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFOm4Z(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCrxMo(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVI2JZ, VVLXA7, VVgAgq, camCommand = CCrxMo.VVeQ58()
  self.VVLXA7 = VVLXA7
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVLXA7:
   c = VVPWV9 if VVgAgq else VVDopz
   if   "oscam" in VVLXA7 : camName, oC = "OSCam", c
   elif "ncam"  in VVLXA7 : camName, nC = "NCam" , c
  VVY9NT = []
  VVY9NT.append(("OSCam Files" , "OSCamFiles" ))
  VVY9NT.append(("NCam Files" , "NCamFiles" ))
  VVY9NT.append(("CCcam Files" , "CCcamFiles" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((VVmuI1 + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVj1ug" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVY9NT.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVY9NT.append(VVXMhc)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVLXA7: VVY9NT.append((c + txt  , "camInfo" ))
  else  : VVY9NT.append((txt  ,    ))
  VVY9NT.append(VVXMhc)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVLXA7:
   for item in camLst: VVY9NT.append(item)
  else:
   for item in camLst: VVY9NT.append((item[0], ))
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCRX0q, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCRX0q, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCRX0q, "cccam"))
   elif item == "VVj1ug" : self.VVj1ug()
   elif item == "OSCamReaders"  : self.VVce3o("os")
   elif item == "NSCamReaders"  : self.VVce3o("n")
   elif item == "camInfo"   : FFxMj3(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCrxMo.VVNVPI(self.session, CC0ga7.VVy6r6)
   elif item == "camLiveReaders" : CCrxMo.VVNVPI(self.session, CC0ga7.VVJsAs)
   elif item == "camLiveLog"  : CCrxMo.VVNVPI(self.session, CC0ga7.VVqvWO)
   else       : self.close()
 def VVj1ug(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVPUYO, FFDaMH())
  if fileExists(path):
   lines = FFun41("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVg0pA = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVg0pA("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVg0pA("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVg0pA("protocol"   , "cccam"))
      f.write(VVg0pA("device"    , "%s,%s" % (host, port)))
      f.write(VVg0pA("user"    , User))
      f.write(VVg0pA("password"   , Pass))
      f.write(VVg0pA("fallback"   , "1"))
      f.write(VVg0pA("group"    , "64"))
      f.write(VVg0pA("cccversion"   , "2.3.2"))
      f.write(VVg0pA("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFNvXQ(self, "Output = %d Reader%s in:\n\n%s" % (tot, FF10dh(tot), outFile))
   else:
    FFZWPu(self, "No valid CCcam lines", 1500)
  else:
   FFZWPu(self, "%s not found" % path, 1500)
 def VVce3o(self, camPrefix):
  VVJnaJ = self.VVVzsC(camPrefix)
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: int(x[0]))
   if self.VVLXA7 and self.VVLXA7.startswith(camPrefix):
    VVY2vy = ("Toggle State", self.VVc155, [camPrefix], "Changing State ...")
   else:
    VVY2vy = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV3dzh  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVY2vy=VVY2vy, VVcNyk=True)
 def VVVzsC(self, camPrefix):
  readersFile = self.VVI2JZ + camPrefix + "cam.server"
  VVJnaJ = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFun41(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVJnaJ.append((str(len(VVJnaJ) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVJnaJ:
    FFh60c(self, "No readers found !")
  else:
   FFCpVp(self, readersFile)
  return VVJnaJ
 def VVc155(self, VV5PsO, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVI2JZ, camPrefix)
  readerState  = VV5PsO.VVEOMp(1)
  readerLabel  = VV5PsO.VVEOMp(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCrxMo.VVldHN(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VV5PsO.VVxwzS()
    FFh60c(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVJnaJ = self.VVVzsC(camPrefix)
   if VVJnaJ:
    VV5PsO.VVQNRz(VVJnaJ)
  else:
   VV5PsO.VVxwzS()
 @staticmethod
 def VVldHN(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFun41(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFh60c(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFh60c(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFCpVp(SELF, confFile)
   return None
  if not iRequest:
   FFh60c(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCrxMo.VVbAVn(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFh60c(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVbAVn(SELF):
  if iElem:
   return True
  else:
   FFh60c(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVNVPI(session, VVPoUm):
  VVI2JZ, VVLXA7, VVgAgq, camCommand = CCrxMo.VVeQ58()
  if VVLXA7:
   runLog = False
   if   VVPoUm == CC0ga7.VVy6r6 : runLog = True
   elif VVPoUm == CC0ga7.VVJsAs : runLog = True
   elif not VVgAgq          : FFkPRK(session, message="SoftCam not started yet!")
   elif fileExists(VVgAgq)        : runLog = True
   else             : FFkPRK(session, message="File not found !\n\n%s" % VVgAgq)
   if runLog:
    session.open(BF(CC0ga7, VVI2JZ=VVI2JZ, VVLXA7=VVLXA7, VVgAgq=VVgAgq, VVPoUm=VVPoUm))
  else:
   FFkPRK(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVeQ58():
  VVI2JZ = "/etc/tuxbox/config/"
  VVLXA7 = None
  VVgAgq  = None
  camCommand = FFA2wB("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVLXA7 = "oscam"
   elif camCmd.startswith("ncam") : VVLXA7 = "ncam"
  if VVLXA7:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFvr8J(path), IGNORECASE)
     if span:
      VVI2JZ = FFd5Wt(span.group(1))
      break
   else:
    path = FFA2wB(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFd5Wt(path)
    if pathExists(path):
     VVI2JZ = path
   tFile = FFd5Wt(VVI2JZ) + VVLXA7 + ".conf"
   tFile = FFA2wB("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVgAgq = tFile
  return VVI2JZ, VVLXA7, VVgAgq, camCommand
class CCRX0q(Screen):
 def __init__(self, VVyqLY, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVI2JZ, VVLXA7, VVgAgq, camCommand = CCrxMo.VVeQ58()
  if   VVyqLY == "ncam" : self.prefix = "n"
  elif VVyqLY == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVY9NT = []
  if self.prefix == "":
   VVY9NT.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVY9NT.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVY9NT.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVY9NT.append(("constant.cw"         , "x_constant_cw" ))
   VVY9NT.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVY9NT.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVY9NT.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVY9NT.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVY9NT.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVY9NT.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVY9NT.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVY9NT.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVY9NT.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVY9NT.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVY9NT.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF2tbi(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FF2tbi(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FF2tbi(self, self.VVI2JZ + "AutoRoll.Key")
   elif item == "x_constant_cw" : FF2tbi(self, self.VVI2JZ + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVCw32("cam.ccache")
   elif item == "x_cam_conf"  : self.VVCw32("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVCw32("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVCw32("cam.provid")
   elif item == "x_cam_server"  : self.VVCw32("cam.server")
   elif item == "x_cam_services" : self.VVCw32("cam.services")
   elif item == "x_cam_srvid2"  : self.VVCw32("cam.srvid2")
   elif item == "x_cam_user"  : self.VVCw32("cam.user")
   elif item == "x_VVwtEz"   : pass
   elif item == "x_SoftCam_Key" : self.VV5JQn()
   elif item == "x_CCcam_cfg"  : FF2tbi(self, self.VVI2JZ + "CCcam.cfg")
   elif item == "x_VVwtEz"   : pass
   elif item == "x_cam_log"  : FF2tbi(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FF2tbi(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FF2tbi(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVCw32(self, fileName):
  FF2tbi(self, self.VVI2JZ + self.prefix + fileName)
 def VV5JQn(self):
  path = self.VVI2JZ + "SoftCam.Key"
  if fileExists(path) : FF2tbi(self, path)
  else    : FF2tbi(self, path.replace(".Key", ".key"))
class CC0ga7(Screen):
 VVy6r6  = 0
 VVJsAs = 1
 VVqvWO = 2
 def __init__(self, session, VVI2JZ="", VVLXA7="", VVgAgq="", VVPoUm=VVy6r6):
  self.skin, self.skinParam = FFWDRO(VVKV47, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVgAgq   = VVgAgq
  self.VVPoUm  = VVPoUm
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVI2JZ + VVLXA7 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVLXA7 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVI2JZ, self.camPrefix)
  if self.VVPoUm == self.VVy6r6:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVPoUm == self.VVJsAs:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFsd9n(self, self.Title, addScrollLabel=True)
  FFKpuS(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVpStN
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self["myLabel"].VVxoM0(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF4AQy(self)
  self.VVpStN()
 def onExit(self):
  self.timer.stop()
 def VVaRqm(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1X01)
  except:
   self.timer.callback.append(self.VV1X01)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFZWPu(self, "Started", 1000)
 def VV6kEo(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV1X01)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFZWPu(self, "Stopped", 1000)
 def VVpStN(self):
  if self.timerRunning:
   self.VV6kEo()
  else:
   self.VVaRqm()
   if self.VVPoUm == self.VVy6r6 or self.VVPoUm == self.VVJsAs:
    if self.VVPoUm == self.VVy6r6 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCrxMo.VVldHN(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFcigO(self.VVBWG7)
    else:
     self.close()
   else:
    self.VV7MST()
 def VV1X01(self):
  if self.timerRunning:
   if   self.VVPoUm == self.VVy6r6 : self.VV5MhJ()
   elif self.VVPoUm == self.VVJsAs : self.VV5MhJ()
   else            : self.VV7MST()
 def VV7MST(self):
  if fileExists(self.VVgAgq):
   fTime = FF2gB8(os.path.getmtime(self.VVgAgq))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVHJeX(), VVQY0S=VVPiyR)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVgAgq)
 def VVBWG7(self):
  self.VV5MhJ()
 def VV5MhJ(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFbRJw("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVLO3F))
   self.camWebIfErrorFound = True
   self.VV6kEo()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVPoUm == self.VVy6r6 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFbRJw("Error while parsing data elements !\n\nError = %s" % str(e), VVzF5b)
   self.camWebIfErrorFound = True
   self.VV6kEo()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV37MH(root)
  self["myLabel"].setText(txt, VVQY0S=VVPiyR)
  self["myBar"].setText("Last Update : %s" % FF4W6Q())
 def VV37MH(self, rootElement):
  def VVg0pA(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVPoUm == self.VVy6r6:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFbRJw(status, VVlwDq)
    else          : status = FFbRJw(status, VVzF5b)
    txt += VVwtEz + "\n"
    txt += VVg0pA("Name"  , name)
    txt += VVg0pA("Description" , desc)
    txt += VVg0pA("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVg0pA("Protocol" , protocol)
    txt += VVg0pA("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFbRJw("Yes", VVlwDq)
    else    : enabTxt = FFbRJw("No", VVzF5b)
    txt += VVwtEz + "\n"
    txt += VVg0pA("Label"  , label)
    txt += VVg0pA("Protocol" , protocol)
    txt += VVg0pA("Enabled" , enabTxt)
  return txt
 def VVHJeX(self):
  lines = FFLYXX("tail -n %d %s" % (100, self.VVgAgq))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVFaDd + line[:19] + VVlhbS + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVyFNv + "WebIf" + VVlhbS)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VV619a + h1 + h2 + VVlhbS + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVlwDq + span.group(2) + VVmuI1 + span.group(3) + VVlhbS + span.group(4)
    line = self.VV4daZ(line, VVmuI1, ("(webif)", ))
    line = self.VV4daZ(line, VVmuI1, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VV4daZ(line, VVlwDq, ("OSCam", "NCam", "log switched"))
    line = self.VV4daZ(line, VVxsyh, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVOpMG + line[ndx + 3:] + VVlhbS
   elif line.startswith("----") or ">>" in line:
    line = FFbRJw(line, VVViAb)
   txt += line + "\n"
  return txt
 def VV4daZ(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVlhbS + t3
  return line
class CCpb7x(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVY9NT = []
  VVY9NT.append(("Backup Channels"    , "VVJzun"   ))
  VVY9NT.append(("Restore Channels"    , "Restore_Channels"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Backup SoftCAM Files"   , "VVOvqO" ))
  VVY9NT.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVY9NT.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVY9NT.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Backup Network Settings"  , "VVsOic"   ))
  VVY9NT.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVnusr:
   VVY9NT.append(VVXMhc)
   VVY9NT.append((VVLO3F + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVL61p"   ))
   VVY9NT.append((VVlwDq + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV1y7w), "createMyIpk"   ))
   VVY9NT.append((VVlwDq + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV1y7w), "createMyDeb"   ))
   VVY9NT.append((VV619a + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVY9NT.append((VV619a + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVHkyM" ))
   VVY9NT.append((VV619a + "Show Windows Stats"           , "VVR12H" ))
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVJzun"    : self.VVJzun()
   elif item == "Restore_Channels"    : self.VV6bVD("channels_backup*.tar.gz", self.VVCV4y, isChan=True)
   elif item == "VVOvqO"   : self.VVOvqO()
   elif item == "Restore_SoftCAM_Files"  : self.VV6bVD("softcam_backup*.tar.gz", self.VV6qGF)
   elif item == "Backup_TunerDiSEqC"   : self.VV3jth("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV6bVD("tuner_backup*.backup", BF(self.VVTdp4, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV3jth("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV6bVD("hotkey_*backup*.backup", BF(self.VVTdp4, "misc"))
   elif item == "VVsOic"    : self.VVsOic()
   elif item == "Restore_Network"    : self.VV6bVD("network_backup*.tar.gz", self.VVaqsk)
   elif item == "VVL61p"     : FFe4rI(self, BF(FFDKj1, self, BF(CCpb7x.VVL61p, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVcHI2(False)
   elif item == "createMyDeb"     : self.VVcHI2(True)
   elif item == "createMyTar"     : self.VVsgbL()
   elif item == "VVHkyM"   : self.VVHkyM()
   elif item == "VVR12H"    : CCpb7x.VVR12H(self)
 @staticmethod
 def VVLHrI(SELF):
  OBF_Path = VVjHuz + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFCpVp(SELF, OBF_Path)
   return None
 @staticmethod
 def VVR12H(SELF):
  obf = CCpb7x.VVLHrI(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFHdWy(SELF, txt, title=title)
 @staticmethod
 def VVL61p(SELF):
  obf = CCpb7x.VVLHrI(SELF)
  if obf:
   txt, err = obf.fixCode(VVjHuz, VVX28J, VV1y7w)
   if err : FFh60c(SELF, err)
   else : FFHdWy(SELF, txt)
 def VVcHI2(self, VVqneK):
  OBF_Path = VVjHuz + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFh60c(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVjHuz)
  os.system("mv -f %s %s" % (VVjHuz + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVjHuz + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVjHuz + "plugin.py"))
  self.session.openWithCallback(self.VVKOMY, BF(CC0rPh, path=VVjHuz, VVqneK=VVqneK))
 def VVKOMY(self):
  os.system("mv -f %s %s" % (VVjHuz + "OBF/main.py"  , VVjHuz))
  os.system("mv -f %s %s" % (VVjHuz + "OBF/plugin.py" , VVjHuz))
 def VVHkyM(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFh60c(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFh60c(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVd592("%s*.list" % path)
  if err:
   FFCpVp(self, path + "*.list")
   return
  srcF, err = self.VVd592("%s*main_final.py" % path)
  if err:
   FFCpVp(self, path + "*.final.py")
   return
  VV0wO4 = []
  for f in files:
   f = os.path.basename(f)
   VV0wO4.append((f, f))
  FFaJ04(self, BF(self.VVPZ52, path, codF, srcF), VVY9NT=VV0wO4)
 def VVPZ52(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFCpVp(self, logF)
   else     : FFDKj1(self, BF(self.VVOqXL, logF, codF, srcF))
 def VVOqXL(self, logF, codF, srcF):
  lst  = []
  lines = FFun41(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFh60c(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVj7kp(lst, logF, newLogF)
  totSrc  = self.VVj7kp(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFHdWy(self, txt)
 def VVd592(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVj7kp(self, lst, f1, f2):
  txt = FFvr8J(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVsgbL(self):
  VV0wO4 = []
  VV0wO4.append("%s%s" % (VVjHuz, "*.py"))
  VV0wO4.append("%s%s" % (VVjHuz, "*.png"))
  VV0wO4.append("%s%s" % (VVjHuz, "*.xml"))
  VV0wO4.append("%s"  % (VVE5ib))
  FFloYz(self, VV0wO4, "%s_%s" % (PLUGIN_NAME, VVX28J), addTimeStamp=False)
 def VVJzun(self):
  path1 = VVn6iK
  path2 = "/etc/tuxbox/"
  VV0wO4 = []
  VV0wO4.append("%s%s" % (path1, "*.tv"))
  VV0wO4.append("%s%s" % (path1, "*.radio"))
  VV0wO4.append("%s%s" % (path1, "*list"))
  VV0wO4.append("%s%s" % (path1, "lamedb*"))
  VV0wO4.append("%s%s" % (path2, "*.xml"))
  FFloYz(self, VV0wO4, self.VVSh9X("channels_backup"), addTimeStamp=True)
 def VVOvqO(self):
  VV0wO4 = []
  VV0wO4.append("/etc/tuxbox/config/")
  VV0wO4.append("/usr/keys/")
  VV0wO4.append("/usr/scam/")
  VV0wO4.append("/etc/CCcam.cfg")
  FFloYz(self, VV0wO4, self.VVSh9X("softcam_backup"), addTimeStamp=True)
 def VVsOic(self):
  VV0wO4 = []
  VV0wO4.append("/etc/hostname")
  VV0wO4.append("/etc/default_gw")
  VV0wO4.append("/etc/resolv.conf")
  VV0wO4.append("/etc/wpa_supplicant*.conf")
  VV0wO4.append("/etc/network/interfaces")
  VV0wO4.append("%snameserversdns.conf" % VVn6iK)
  FFloYz(self, VV0wO4, self.VVSh9X("network_backup"), addTimeStamp=True)
 def VVSh9X(self, fName):
  img = CC1xY8.VV4KAs()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVCV4y(self, fileName=None):
  if fileName:
   FFe4rI(self, BF(FFDKj1, self, BF(self.VVo7eA, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVo7eA(self, fileName):
  path = "%s%s" % (VVPUYO, fileName)
  if fileExists(path):
   if CCVdBH.VVAhRE(path):
    VVyaaA , VVcHLr = CCwvQw.VVo8AE()
    VVm8jJ, VVVpN1 = CCwvQw.VVf3n4()
    cmd  = FF75pk("cd %s" % VVn6iK) + ";"
    cmd += FF75pk("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVcHLr, VVVpN1))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFMABX()
    if res == 0 : FFNvXQ(self, "Channels Restored.")
    else  : FFh60c(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFh60c(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFCpVp(self, path)
 def VV6qGF(self, fileName=None):
  if fileName:
   FFe4rI(self, BF(self.VVPM3G, fileName), "Overwrite SoftCAM files ?")
 def VVPM3G(self, fileName):
  fileName = "%s%s" % (VVPUYO, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVwtEz
   note = "You may need to restart your SoftCAM."
   FF7o6J(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFs7EJ(note, VVOpMG), sep))
  else:
   FFCpVp(self, fileName)
 def VVaqsk(self, fileName=None):
  if fileName:
   FFe4rI(self, BF(self.VVGfps, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVGfps(self, fileName):
  fileName = "%s%s" % (VVPUYO, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFx5HE(self,  cmd)
  else:
   FFCpVp(self, fileName)
 def VV6bVD(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFKcKn()
  if pathExists(VVPUYO):
   myFiles = FFzuBj(VVPUYO, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV0wO4 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV0wO4.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV0Xwe = ("Sat. List", self.VV8LS3)
    elif isChan and iTar: VV0Xwe = ("Bouquets Importer", CCxIt0.VV5GQy)
    else    : VV0Xwe = None
    FFaJ04(self, callBackFunction, title=title, width=1200, VVY9NT=VV0wO4, VV0Xwe=VV0Xwe, yellowBasePath=VVPUYO)
   else:
    FFh60c(self, "No files found in:\n\n%s" % VVPUYO, title)
  else:
   FFh60c(self, "Path not found:\n\n%s" % VVPUYO, title)
 def VV3jth(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVn6iK
  tCons = CC6TQl()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVpKgW, filePrefix))
 def VVpKgW(self, filePrefix, result, retval):
  title = FFKcKn()
  if pathExists(VVPUYO):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFh60c(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVPUYO, filePrefix, self.VVSh9X(""), FFDaMH())
    try:
     VV0wO4 = str(result.strip()).split()
     if VV0wO4:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV0wO4:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVwtEz, FFbRJw(fName, VVOpMG), VVwtEz)
       FFHdWy(self, txt, title=title, VVQY0S=VVPiyR)
      else:
       FFh60c(self, "File creation failed!", title)
     else:
      FFh60c(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FF75pk("rm %s" % fName))
     FFh60c(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FF75pk("rm %s" % fName))
     FFh60c(self, "Error while writing file.")
  else:
   FFh60c(self, "Path not found:\n\n%s" % VVPUYO, title)
 def VVTdp4(self, mode, path=None):
  if path:
   path = "%s%s" % (VVPUYO, path)
   if fileExists(path):
    lines = FFun41(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFe4rI(self, BF(self.VVW434, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFUVcy(self, path, title=FFKcKn())
   else:
    FFCpVp(self, path)
 def VVW434(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVelZe = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVelZe.append("echo -e 'Reading current settings ...'")
  VVelZe.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVelZe.append("echo -e 'Preparing new settings ...'")
  VVelZe.append(settingsLines)
  VVelZe.append("echo -e 'Applying new settings ...'")
  VVelZe.append("mv -f %s %s" % (tFile, sFile))
  FFWveA(self, VVelZe)
 def VV8LS3(self, VVELdAObj, path):
  if not path:
   return
  path = VVPUYO + path
  if not fileExists(path):
   FFCpVp(self, path)
   return
  txt = FFvr8J(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFZmN3(item[1]))
   FFHdWy(self, txt, title="Satellites List")
  else:
   FFh60c(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCxIt0():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VV5GQy(SELF, fName):
  bi = CCxIt0(SELF)
  bi.instance = bi
  bi.VVtch7(SELF, fName)
 @staticmethod
 def VVNYpl(SELF):
  bi = CCxIt0(SELF)
  bi.instance = bi
  bi.VVlowe()
 def VVtch7(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVPUYO + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFDKj1(waitObg, self.VVgttL, title="Reading bouquets ...")
  else      : self.VVCpHh(self.filePath)
 def VVELFw(self, txt) : FFh60c(self.SELF, txt, title=self.Title)
 def VVyRz1(self, txt)  : FFZWPu(self, txt, 1500)
 def VVCpHh(self, path) : FFCpVp(self.SELF, path, title=self.Title)
 def VVlowe(self):
  if pathExists(VVPUYO):
   lst = FFzuBj(VVPUYO, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VV49KG())
   if len(lst) > 0:
    VVY9NT = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFbRJw(item, VVmuI1) if item.endswith(".zip") else item
     VVY9NT.append((txt, item))
    VVY9NT.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VV756z
    FFaJ04(self.SELF, self.VVGC5H, minRows=3, title=self.Title, width=1200, VVY9NT=VVY9NT, OKBtnFnc=OKBtnFnc, yellowBasePath=VVPUYO, VVU4bo="#22111111", VVdq78="#22111111")
   else:
    self.VVELFw("No valid backup files found in:\n\n%s" % VVPUYO)
  else:
   self.VVELFw("Backup Directory not found:\n\n%s" % VVPUYO)
 def VV756z(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVtch7(menuInstance, fName)
 def VVGC5H(self, item=None):
  if not item and self.instance:
   del self.instance
 def VV49KG(self):
  files = FFzuBj(VVPUYO, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVgttL(self):
  lines, err = CCxIt0.VV0kp9(self.filePath, "bouquets.tv")
  if err:
   self.VVELFw(err)
   return
  bTvSortLst  = self.VV5xaB(lines)
  lines, err = CCxIt0.VV0kp9(self.filePath, "bouquets.radio")
  if err:
   self.VVELFw(err)
   return
  bRadSortLst = self.VV5xaB(lines)
  VVJnaJ = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVY9kF(f, mode, len(VVJnaJ), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVJnaJ.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVY9kF(f, mode, len(VVJnaJ), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVY9kF(f, mode, len(VVJnaJ), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVJnaJ.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVY9kF(f, mode, len(VVJnaJ), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVJnaJ): VVJnaJ[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVJnaJ):
     if key == os.path.basename(row[9]):
      VVJnaJ = VVJnaJ[:ndx+1] + lst + VVJnaJ[ndx+1:]
      break
   for ndx, item in enumerate(VVJnaJ): VVJnaJ[ndx][0] = str(ndx + 1)
   VVWGqy = "#11000600"
   VVNiXY  = ("Show Services" , self.VVsMma  , [], "Reading ..." )
   VVo8Jh = (""    , self.VVhu8P, [])
   VVuKTt = ("Options"  , self.VVzgJC, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VV3dzh  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFXBR7(self.SELF, None, title=self.Title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=24, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVuKTt=VVuKTt, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVU4bo=VVWGqy, VVdq78=VVWGqy, VVWGqy=VVWGqy, VVjOuo="#11ffffff", VVpoY2="#00004455", VVUWnf="#0a282828")
  else:
   self.VVELFw("No valid bouquets in:\n\n%s" % self.filePath)
 def VV5xaB(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVhu8P(self, VV5PsO, title, txt, colList):
  FFHdWy(self.SELF, FFUkF8(txt), title=title)
 def VVzgJC(self, VV5PsO, title, txt, colList):
  mSel = CCkpOx(self.SELF, VV5PsO)
  if VV5PsO.VVSQQE:
   totSel = VV5PsO.VVkjUl()
   if totSel: VVY9NT = [("Import %s Bouquet%s" % (FFbRJw(str(totSel), VVlwDq), FF10dh(totSel)), "imp")]
   else  : VVY9NT = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFbRJw(bName, VVlwDq)
   VVY9NT = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFDKj1, VV5PsO, BF(CCxIt0.VVVpTY, self.SELF, VV5PsO, self.filePath))}
  mSel.VVUhFW(VVY9NT, cbFncDict)
 def VVsMma(self, VV5PsO, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCxIt0.VV0kp9(self.filePath, "lamedb")
   if err:
    self.VVELFw(err)
    return
   dbServLst = CCwvQw.VVllZf(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VV5PsO.VVkll0()
   lines, err = CCxIt0.VV0kp9(self.filePath, os.path.basename(fName))
   if err:
    self.VVELFw(err)
    return
   VVJnaJ = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVJnaJ.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVJnaJ.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVJnaJ.append((span.group(1).strip() or "-", "Stream Relay" if FFuuGZ(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVJnaJ.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVJnaJ.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCwvQw.VVFuMH(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVJnaJ.append((name.strip() or "-", FF8b2s(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVJnaJ):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCxIt0.VV0kp9(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVJnaJ[ndx] = (bName, descr)
   if VVJnaJ:
    VVWGqy = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VV3dzh = (LEFT  , CENTER)
    FFXBR7(self.SELF, None, title="Services in : %s" % bName, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, VVU4bo=VVWGqy, VVdq78=VVWGqy, VVWGqy=VVWGqy, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFZWPu(VV5PsO, err, 1500)
  else : VV5PsO.VVxwzS()
 def VVY9kF(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVELFw("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFuuGZ(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVmzbD(var):
   return str(var) if var else VVtUHQ + str(var)
  totItem = VVOpMG + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVLO3F   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVmuI1, "Sub-B."
  else  : bColor, totBnb = ""      , VVmzbD(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVmzbD(totDVB), VVmzbD(totIptv), VVmzbD(totSRelay), VVmzbD(totLoc), VVmzbD(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVVpTY(SELF, VV5PsO, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVn6iK + "bouquets.tv"
  radBouquetFile = VVn6iK + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFCpVp(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFCpVp(SELF, radBouquetFile, title=title)
   return
  isMulti = VV5PsO.VVSQQE
  if isMulti : rows = VV5PsO.VVlMWX()
  else  : rows = [VV5PsO.VVkll0()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFh60c(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFUkF8(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFUkF8(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVn6iK + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVn6iK + newFile
    CCxIt0.VVW2Oj(archPath, fName, VVn6iK, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CCgBRx.VV8R3u(tvBouquetFile)
   CCgBRx.VV8R3u(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCxIt0.VVnjHW(SELF, archPath, bList)
   FFMABX()
  txt  = FFbRJw("Added:\n", VVmuI1)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFbRJw("Imported to lamedab:\n", VVmuI1)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFbRJw("Missing from archived lamedb:\n", VVLO3F)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFHdWy(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVnjHW(SELF, archPath, bList):
  VVyaaA, err = CCwvQw.VVj9Zk(SELF, VVsFr5=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCwvQw.VVxgTR(VVyaaA, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFun41(VVn6iK + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCwvQw.VVFuMH(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCwvQw.VVCAjp(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCxIt0.VVMLLI(archPath, dbName)
   CCxIt0.VVW2Oj(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCwvQw.VVxgTR(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCwvQw.VVxgTR(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCwvQw.VVxgTR(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCwvQw.VVxgTR(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFiHj6(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVyaaA + ".tmp"
   lines   = FFun41(VVyaaA)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FF75pk("mv -f '%s' '%s'" % (tmpDbFile, VVyaaA)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVhLBe(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVMLLI(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVW2Oj(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VV0kp9(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCHlgZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVY9NT = []
  VVY9NT.append(("Plugins Browser"        , "pluginsBrowser"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Remove Packages (show all)"     , "VVKijCsAll"  ))
  VVY9NT.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Update Packages List from Feed"    , "VVu8yb"  ))
  VVY9NT.append(("Upgradable Packages"       , "VVNMvB" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Packaging Tool"        , "VVPXVf"   ))
  VVY9NT.append(("Active Feeds"         , "VV2Gsx"   ))
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCFx66.VV1I99(self)
   elif item == "downloadInstallPackages"  : FFDKj1(self, BF(self.VVKcOO, 0, ""))
   elif item == "VVKijCsAll"   : FFDKj1(self, BF(self.VVKcOO, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFDKj1(self, BF(self.VVKcOO, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVu8yb"   : CCHlgZ.VVu8yb(self)
   elif item == "VVNMvB"  : FFDKj1(self, self.VVNMvB)
   elif item == "VVPXVf"    : self.VVPXVf()
   elif item == "VV2Gsx"    : self.VV2Gsx()
   else          : self.close()
 def VV2Gsx(self):
  pkg = FFaz01()
  if pkg : FFOm4Z(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFhvmT(self)
 def VVNMvB(self, VV5PsO=None):
  lst = FFLYXX(FFv5Rb(VV5cDl, ""))
  VVJnaJ = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch("(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch("(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVJnaJ.append((str(len(VVJnaJ) + 1), pkg, curV, newVer))
   if VVJnaJ:
    if VV5PsO:
     VV5PsO.VVQNRz(VVJnaJ, VVbcbWMsg=True)
    else:
     bg = "#00221111"
     VVY2vy = ("Upgrade", self.VVQPKr   , [])
     VVuKTt = ("Package Info.", self.VViNY0 , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VV3dzh = (CENTER , LEFT  , LEFT  , LEFT   )
     FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, width=1700, VVfp7o=26, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVcNyk=True, VVBgr7=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVU4bo=bg, VVdq78=bg, VVWGqy=bg, VVjOuo="#0000ff00", VVpoY2="#00003040")
  if not VVJnaJ:
   FFcw7s(self, "Nothing to upgrade", 1500)
   if VV5PsO: VV5PsO.cancel()
 def VVQPKr(self, VV5PsO, title, txt, colList):
  pkg = colList[1]
  cmd = FFXUpj(VVzo0S, pkg)
  if cmd : FFx5HE(self, cmd, title="Installing : %s" % pkg, VV54cX=BF(self.VVNMvB, VV5PsO))
  else : FFhvmT(SELF)
 def VVPXVf(self):
  pkg = FFaz01()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFNvXQ(self, txt)
 def VVKcOO(self, mode, grep, VV5PsO=None, title=""):
  if   mode == 0: cmd = FFv5Rb(VViMeN    , grep)
  elif mode == 1: cmd = FFv5Rb(VV5YBB , grep)
  elif mode == 2: cmd = FFv5Rb(VV5YBB , grep)
  if not cmd:
   FFhvmT(self)
   return
  VVJnaJ = FFLYXX(cmd)
  if VVJnaJ:
   err = CCVdBH.VVTfqS(VVJnaJ, fromFind=False)
   if err:
    FFh60c(self, err)
    return
  else:
   if VV5PsO: VV5PsO.VVxwzS()
   FFh60c(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV0wO4  = []
  for item in VVJnaJ:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV0wO4.append((name, package, version))
  if mode > 0:
   extensions = FFLYXX("ls %s -l | grep '^d' | awk '{print $9}'" % VV9hRJ)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV0wO4:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV0wO4.append((name, VV9hRJ + item, "-"))
   systemPlugins = FFLYXX("ls %s -l | grep '^d' | awk '{print $9}'" % VV4ItM)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV0wO4:
      if item.lower() == row[0].lower():
       break
     else:
      VV0wO4.append((item, VV4ItM + item, "-"))
  if not VV0wO4:
   FFh60c(self, "No packages found!")
   return
  if VV5PsO:
   VV0wO4.sort(key=lambda x: x[0].lower())
   VV5PsO.VVQNRz(VV0wO4, title)
  else:
   widths = (20, 50, 30)
   VVY2vy = None
   VVNlag = None
   if mode == 0:
    VVNxWT = ("Install" , self.VVu9Fx   , [])
    VVY2vy = ("Download" , self.VVFb1q   , [])
    VVNlag = ("Filter"  , self.VVNm6A , [])
   elif mode == 1:
    VVNxWT = ("Uninstall", self.VVKijC, [])
   elif mode == 2:
    VVNxWT = ("Uninstall", self.VVKijC, [])
    widths= (18, 57, 25)
   VV0wO4.sort(key=lambda x: x[0].lower())
   VVuKTt = ("Package Info.", self.VViNY0, [])
   header   = ("Name" ,"Package" , "Version" )
   FFXBR7(self, None, header=header, VV0wO4=VV0wO4, VVgZrM=widths, VVfp7o=28, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, VVlPOg=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVU4bo="#22110011", VVdq78="#22191111", VVWGqy="#22191111", VVpoY2="#00003030", VVUWnf="#00333333")
 def VViNY0(self, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VV11MA, VV5PsO, colList[1]))
 def VV11MA(self, VV5PsO, pkg):
  if pathExists(pkg):
   pkg, err = CCHlgZ.VVKB7l(pkg)
   if err:
    FFcw7s(VV5PsO, err, 1000)
    return
  CCHlgZ.VVdFcI(self, pkg)
 def VVNm6A(self, VV5PsO, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVY9NT = []
  VVY9NT.append(("All Packages", "all"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVY9NT.append(VVXMhc)
  for word in words:
   VVY9NT.append((word, word))
  FFaJ04(self, BF(self.VVovDM, VV5PsO), VVY9NT=VVY9NT, title="Select Filter")
 def VVovDM(self, VV5PsO, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFDKj1(VV5PsO, BF(self.VVKcOO, 0, grep, VV5PsO, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVKijC(self, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VVkuXV, VV5PsO, colList[1]))
 def VVkuXV(self, VV5PsO, package):
  if pathExists(package):
   pkg, err = CCHlgZ.VVKB7l(package)
   if pkg:
    package = pkg
  if package.startswith((VV9hRJ, VV4ItM)):
   FFe4rI(self, BF(self.VVXSdb, VV5PsO, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVY9NT = []
   VVY9NT.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVY9NT.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVY9NT.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFaJ04(self, BF(self.VV0ixe, VV5PsO, package), VVY9NT=VVY9NT)
 def VVXSdb(self, VV5PsO, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVENt5)
  FFx5HE(self, cmd, VV54cX=BF(self.VVcGwY, VV5PsO))
 def VV0ixe(self, VV5PsO, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVFsUb
   elif item == "remove_ForceRemove"  : cmdOpt = VVChqD
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVKfEX
   FFe4rI(self, BF(self.VVk7ko, VV5PsO, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVk7ko(self, VV5PsO, package, cmdOpt):
  self.lastSelectedRow = VV5PsO.VV3w14()
  cmd = FFXUpj(cmdOpt, package)
  if cmd : FFx5HE(self, cmd, VV54cX=BF(self.VVcGwY, VV5PsO))
  else : FFhvmT(self)
 def VVcGwY(self, VV5PsO):
  VV5PsO.cancel()
  FFgh2b()
 def VVu9Fx(self, VV5PsO, title, txt, colList):
  package  = colList[1]
  VVY9NT = []
  VVY9NT.append(("Install Package"        , "install_CheckVersion" ))
  VVY9NT.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVY9NT.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVY9NT.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVY9NT.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFaJ04(self, BF(self.VV5RCU, package), VVY9NT=VVY9NT)
 def VV5RCU(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVzo0S
   elif item == "install_ForceReinstall" : cmdOpt = VVPgiB
   elif item == "install_ForceOverwrite" : cmdOpt = VVftKI
   elif item == "install_ForceDowngrade" : cmdOpt = VV2nWE
   elif item == "install_IgnoreDepends" : cmdOpt = VVONbh
   FFe4rI(self, BF(self.VVf05t, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVf05t(self, package, cmdOpt):
  cmd = FFXUpj(cmdOpt, package)
  if cmd : FFx5HE(self, cmd, VV54cX=FFgh2b, checkNetAccess=True)
  else : FFhvmT(self)
 def VVFb1q(self, VV5PsO, title, txt, colList):
  package  = colList[1]
  FFe4rI(self, BF(self.VVETxU, package), "Download Package ?\n\n%s" % package)
 def VVETxU(self, package):
  if CCo7Gj.VVHLsi():
   cmd = FFXUpj(VVnfD4, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFs7EJ(success, VVlwDq))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFs7EJ(fail, VVzF5b))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFx5HE(self, cmd, VV3Zt2=[VVzF5b, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFhvmT(self)
  else:
   FFh60c(self, "No internet connection !")
 @staticmethod
 def VVu8yb(SELF):
  cmd = FFv5Rb(VVjlpz, "")
  if cmd : FFx5HE(SELF, cmd, checkNetAccess=True)
  else : FFhvmT(SELF)
 @staticmethod
 def VVKB7l(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFLYXX(FFXUpj(VV4O5D, "*%s*" % path)):
    span = iSearch("(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch("(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVdFcI(SELF, package, title=""):
  title = title or package
  infoCmd  = FFXUpj(VVihTi, package)
  filesCmd = FFXUpj(VVgD1q, package)
  listInstCmd = FFv5Rb(VV5YBB, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFmquk(VVOpMG)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFs7EJ(notInst, VVLO3F))
   cmd += "else "
   cmd +=   FFsHvy("System Info", VVOpMG)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFsHvy("Related Files", VVOpMG)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFQHMr(SELF, cmd, title=title)
  else:
   FFhvmT(SELF, title=title)
class CCjheW():
 def VVs8cC(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVkZP0()
 def VVkZP0(self):
  files = FFzuBj(VVPUYO, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVY9NT = []
   for fil in files:
    VVY9NT.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVU4bo, VVdq78 = "#22221133", "#22221133"
   else    : VVU4bo, VVdq78 = "#22003344", "#22002233"
   VV0Xwe  = ("Add new File", self.VVQJ9r)
   FFaJ04(self, self.VVCFVv, VVY9NT=VVY9NT, width=1100, VV0Xwe=VV0Xwe, yellowBasePath="", minRows=4, VVU4bo=VVU4bo, VVdq78=VVdq78)
  else:
   FFe4rI(self, self.VVIIUr, "No files found.\n\nCreate a new file ?")
 def VVIIUr(self):
  path = self.VVlNOv()
  if fileExists(path) : self.VVkZP0()
  else    : FFZWPu(self, "Cannot create file", 1500)
 def VVQJ9r(self, menuInstance, path):
  path = self.VVlNOv()
  menuInstance.VViBv5((os.path.basename(path), path), isSort=True)
 def VVlNOv(self):
  path = "%s%s%s.xml" % (VVPUYO, self.shareFilePrefix, FFDaMH())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVCFVv(self, path=None):
  if path:
   FFDKj1(self, BF(self.VVyTVK, path))
 def VVyTVK(self, path):
  if not fileExists(path):
   FFCpVp(self, path)
   return
  elif not CCVdBH.VVoq5s(self, path, FFKcKn()):
   return
  else:
   self.shareFilePath = path
  if not CCrxMo.VVbAVn(self):
   return
  tree = CCwvQw.VVURao(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCgBRx.VVTY57()
  def VVg0pA(refCode):
   if   FFHUOD(refCode): return FFbRJw("DVB", VVPWV9)
   elif refCode in refLst     : return FFbRJw("IPTV", VVPWV9)
   else         : return ""
  VVJnaJ= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVB2cO(ch)
   if ok:
    srcTxt = VVg0pA(srcRef)
    dstTxt = VVg0pA(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVJnaJ:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVJnaJ.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVJnaJ:
   if self.shareIsRef : VVU4bo, VVdq78, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVU4bo, VVdq78, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVKFgA = (""    , BF(self.VVOVhO, dupl), [])
   VVo8Jh = (""    , self.VVNTU9    , [])
   VVNxWT = ("Delete Entry" , self.VV6ovx   , [])
   VVY2vy = ("Add Entry"  , self.VVTpMW   , [])
   VVuKTt = (optTxt   , self.VVU4O9  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VV3dzh = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VV5PsO = FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=24, VVKFgA=VVKFgA, VVo8Jh=VVo8Jh, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVcNyk=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVdq78, VVjOuo="#00ffffaa", VVpoY2="#0a000000")
  else:
   FFh60c(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVOVhO(self, dupl, VV5PsO, title, txt, colList):
  if dupl:
   VV5PsO.VViaMT("Skipped %d duplicate%s" % (dupl, FF10dh(dupl)), 2000)
 def VVNTU9(self, VV5PsO, title, txt, colList):
  def VVg0pA(key, val): return "%s\t: %s\n" % (key, val or FFbRJw("?", VVxsyh))
  Keys = VV5PsO.VVFYOn()
  Vals = VV5PsO.VVkll0()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVg0pA(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVlwDq, VVxsyh
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFHdWy(self, txt + txt1, title=title)
 def VVB2cO(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VV6ovx(self, VV5PsO, title, txt, colList):
  if VV5PsO.VV3w14() == 0 and VV5PsO.VVbwlY() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFe4rI(self, BF(self.VVkYS5, isLast, VV5PsO), ques)
 def VVkYS5(self, isLast, VV5PsO):
  if isLast:
   FFiHj6(self.shareFilePath)
   VV5PsO.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VV5PsO.VVkll0()
   if self.VVahBG(srcName, srcRef, dstName, dstRef):
    VV5PsO.VVghx6()
    VV5PsO.VVC4SC()
    FFZWPu(VV5PsO, "Deleted", 500, isGrn=True)
   else:
    FFZWPu(VV5PsO, "Cannot delete from file", 2000)
 def VVTpMW(self, VV5PsO, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVnNEZ(VV5PsO, isDvb=True)
  else    : self.VV3lJ6(VV5PsO, "Source Channel", "#22003344", "#22002233")
 def VV3lJ6(self, mainTableInst, title, VVU4bo, VVdq78):
  FFaJ04(self, BF(self.VVpqrg, mainTableInst, title), VVY9NT=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVU4bo=VVU4bo, VVdq78=VVdq78)
 def VVpqrg(self, mainTableInst, title, item=None):
  if item:
   FFDKj1(mainTableInst, BF(self.VVXCNP, mainTableInst, title, item), clearMsg=False)
 def VVXCNP(self, mainTableInst, title, item):
  FFZWPu(mainTableInst)
  if item == "DVB": self.VVnNEZ(mainTableInst, isDvb=True)
  else   : self.VVnNEZ(mainTableInst, isDvb=False)
 def VVpHee(self, mainTableInst, chType, VV5PsO, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VV5PsO.VV3w14()
  if   chType == "DVB" : FFoBdB(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFoBdB(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVexgG()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFh60c(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVOkiv(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVvWTa((str(mainTableInst.VVbwlY() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFZWPu(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFZWPu(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFZWPu(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVnNEZ(mainTableInst, isDvb=False)
   else    : FFcigO(BF(self.VV3lJ6, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VV5PsO.cancel()
 def VVxJ7L(self, item, VV5PsO, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VV5PsO.VVyOnh(ndx)
 def VVnNEZ(self, VV5PsO, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVpHee, VV5PsO, typ)
  doneFnc = BF(self.VVxJ7L, typ)
  if isDvb: CCjheW.VV7oYO(VV5PsO , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCjheW.VVFcGC(VV5PsO, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VV7oYO(SELF, title, okFnc, doneFnc=None):
  FFDKj1(SELF, BF(CCjheW.VVNGDg, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVNGDg(SELF, title, okFnc, doneFnc=None):
  VVJnaJ, err = CCwvQw.VVz7ZO(SELF, CCwvQw.VVPQ0f)
  if VVJnaJ:
   color = "#0a000022"
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVNiXY = ("Select" , okFnc, [])
   VVKFgA= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VV3dzh = (LEFT  , LEFT  , CENTER, LEFT    )
   FFXBR7(SELF, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVU4bo=color, VVdq78=color, VVWGqy=color, VVNiXY=VVNiXY, VVKFgA=VVKFgA, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFh60c(SELF, "No DVB Services !")
 @staticmethod
 def VVFcGC(SELF, title, okFnc, doneFnc=None):
  FFDKj1(SELF, BF(CCjheW.VVkrZL, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVkrZL(SELF, title, okFnc, doneFnc=None):
  VVJnaJ = CCjheW.VVY6me()
  if VVJnaJ:
   color = "#0a112211"
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVNiXY = ("Select" , okFnc, [])
   VVKFgA= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFXBR7(SELF, None, title=title, header=header, VV0wO4=VVJnaJ, VVgZrM=widths, VVfp7o=26, VVU4bo=color, VVdq78=color, VVWGqy=color, VVNiXY=VVNiXY, VVKFgA=VVKFgA, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFh60c(SELF, "No IPTV Services !")
 @staticmethod
 def VVY6me():
  VVJnaJ = []
  files  = CCHli4.VVwfQF()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFvr8J(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVEFj2 = span.group(1)
    else : VVEFj2 = ""
    VVEFj2_lCase = VVEFj2.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVJnaJ.append((chName, VVEFj2, url, refCode))
  return VVJnaJ
 def VVOkiv(self, srcName, srcRef, dstName, dstRef):
  tree = CCwvQw.VVURao(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVGUYQ(tree, root)
  return True
 def VVahBG(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCwvQw.VVURao(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVB2cO(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVGUYQ(tree, root)
  return found
 def VVGUYQ(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCwvQw.VV6nMQ(xmlTxt)
  parser = CCwvQw.CCRHIQ()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVU4O9(self, VV5PsO, title, txt, colList):
  if self.onlyEpg:
   self.VVa1ci(VV5PsO, "epg")
  else:
   if self.shareIsRef:
    FFe4rI(self, BF(FFDKj1, VV5PsO, BF(self.VVDCwo, VV5PsO)), "Copy all References from Source to Destination ?")
   else:
    VVY9NT = []
    VVY9NT.append(("Copy EPG\t (All List)" , "epg"  ))
    VVY9NT.append(("Copy Picons\t (All List)" , "picon" ))
    FFaJ04(self, BF(self.VVa1ci, VV5PsO), VVY9NT=VVY9NT, width=1000)
 def VVa1ci(self, VV5PsO, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVWYG8  , "EPG"
   elif item == "picon": fnc, txt = self.VVfkpc , "PIcons"
   title = "Copy %s" % txt
   tot   = VV5PsO.VVbwlY()
   FFe4rI(self, BF(FFDKj1, VV5PsO, BF(fnc, VV5PsO, title)), "Overwrite %s for %d Service%s ?" % (FFbRJw(txt, VVOpMG), tot, FF10dh(tot)), title=title)
 def VVDCwo(self, VV5PsO):
  files = CCHli4.VVwfQF()
  totChange = 0
  if files:
   for path in files:
    txt = FFvr8J(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VV5PsO.VVexgG():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFMABX()
  tot = VV5PsO.VVbwlY()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFHdWy(self, txt)
 def VVfkpc(self, VV5PsO, title):
  if not iCopyfile:
   FFh60c(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCZBEU.VV0FjB()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VV5PsO.VVexgG():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VV5PsO.VVbwlY()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFHdWy(self, txt, title=title)
 def VVWYG8(self, VV5PsO, title):
  txt, err = CCI7Ct.VVyrvR(VV5PsO, title)
  if err : FFh60c(self, err, title=title)
  else : FFHdWy(self, txt, title=title)
 class CCRHIQ(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVURao(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCwvQw.CCRHIQ())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFbRJw("XML Parse Error in:", VVxsyh), path)
   txt += "%s\n%s\n\n" % (FFbRJw("Error:", VVxsyh), str(e))
   FFHdWy(SELF, txt, VVWGqy="#11220000", title=title)
   return None
 @staticmethod
 def VV6nMQ(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCI7Ct(Screen, CCjheW):
 VVL04E  = "BDTSE"
 VVQXON   = "save"
 VVjTvK   = "load"
 VVlNe8  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCI7Ct.VVUCxT()
  qUrl, iptvRef = CCHli4.VVdZu8(self)
  VVY9NT = []
  VVY9NT.append((VVPWV9 + "Cache File Info." , "inf"))
  VVY9NT.append(VVXMhc)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  t1 = "Save EPG to File%s" % fTxt
  t2 = "Load EPG from File%s" % fTxt
  if valid:
   VVY9NT.append((t1, self.VVQXON))
   VVY9NT.append((t2, self.VVjTvK))
  else:
   VVY9NT.append((t1, ))
   VVY9NT.append((t2, ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((VVLO3F + "Delete EPG (from RAM only)", self.VVlNe8))
  VVY9NT.append(VVXMhc)
  txt = "Update Current Bouquet EPG (from IPTV Server)"
  if qUrl or "chCode" in iptvRef: VVY9NT.append((txt, "refreshIptvEPG" ))
  else        : VVY9NT.append((txt,     ))
  VVY9NT.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Translate Current Channel EPG %s(Experimental)" % VVLO3F, "VVqWY7"))
  FFsd9n(self, VVY9NT=VVY9NT)
  self.onShown.append(self.VVrYby)
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVOSB9()
   elif item in (self.VVQXON, self.VVjTvK, self.VVlNe8):
    reset = item == self.VVjTvK
    FFe4rI(self, BF(FFDKj1, self, BF(self.VV7nsy, item, reset)), VVT00f="Continue ?")
   elif item == "refreshIptvEPG"  : CCHli4.VVkHjN(self)
   elif item == "VVqWY7" : self.VVqWY7()
   elif item == "copyEpg"    : self.VVs8cC(False, onlyEpg=True)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VV7nsy(self, act, reset=False):
  ok = CCI7Ct.VV6ch0(act)
  if ok:
   if reset:
    CCI7Ct.VVuS6j(self)
   FFNvXQ(self, "Done")
  else:
   FFNvXQ(self, "Failed!")
 def VVOSB9(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCI7Ct.VVUCxT()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFbRJw("File not found (check System EPG settings).", VVLO3F))
   FFHdWy(self, txt, title=title)
  else:
   FFh60c(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVyRl7():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVqWY7(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVNiXY  = (""  , BF(self.VVLV6j, title, True) , [])
  VVY2vy = ("Start" , BF(self.VVLV6j, title, False), [])
  VVNlag = ("Change Language", self.VVDTFX      , [])
  widths  = (70 , 30)
  VV3dzh = (LEFT , CENTER)
  FFXBR7(self, None, title=title, VV0wO4=self.VVPQDT(), VV3dzh=VV3dzh, VVgZrM=widths, width=1200, vMargin=20, VVfp7o=30, VVNiXY=VVNiXY, VVY2vy=VVY2vy, VVNlag=VVNlag, VVu0ZD=2
    , VVU4bo="#11201010", VVdq78=bg, VVWGqy=bg, VVjOuo="#00ffffaa", VVpoY2="#00004455", VVUWnf=bg)
 def VVPQDT(self):
  Def, ch = "DISABLED", dict(CCI7Ct.VVyRl7())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VV0wO4 = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VV0wO4
 def VVDTFX(self, VV5PsO, title, txt, colList):
  ndx = VV5PsO.VV3w14()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CC0lek.VVqlFw(self, confItem, title, lst=CCI7Ct.VVyRl7(), cbFnc=BF(self.VV91ab, VV5PsO))
 def VV91ab(self, VV5PsO):
  for ndx, row in enumerate(self.VVPQDT()):
   VV5PsO.VVp8Vc(ndx, row)
 def VVLV6j(self, Title, isAsk, VV5PsO, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFZWPu(VV5PsO, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
   refCode, evList, err = CCI7Ct.VVXjZ4(refCode)
   fnc = BF(self.VVxEch, Title, refCode, evList, VV5PsO)
   if   err : FFh60c(self, err, title=Title)
   elif isAsk : FFe4rI(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVxEch(self, title, refCode, evList, VV5PsO):
  self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV3UUX, evList)
      , VVsfO0 = BF(self.VV5iTP, title, refCode))
  VV5PsO.cancel()
 def VV3UUX(self, evList, VVq6PE):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVq6PE.VVlEfz(totEv)
  VVq6PE.VVwxC6 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCI7Ct.VVgPGG(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVA8Cz(1)
   VVq6PE.VV0BdB(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVq6PE.VVwxC6 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VV5iTP(self, title, refCode, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVwxC6
  if newLst: totEv, totOK = CCI7Ct.VVqv7L(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCI7Ct.VVEUm5()
   CCI7Ct.VVuS6j(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFHdWy(self, txt, title=title)
 @staticmethod
 def VVgPGG(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVg0pA(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCI7Ct.VVN1y0(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVg0pA, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVN1y0(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFeaA3(txt))
   txt, err = CCHli4.VVgnJH(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFhKb1(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCI7Ct.VV3EdJ(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVUCxT():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFtDuT(path)
   szTxt = CCVdBH.VVFJRm(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VV7Pep():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVEUm5(): CCI7Ct.VV6ch0(CCI7Ct.VVQXON)
 @staticmethod
 def VV6ch0(act):
  ec, inst = CCI7Ct.VV7Pep()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVuS6j(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVXjZ4(refCode):
  ec, inst = CCI7Ct.VV7Pep()
  if inst:
   try:
    evList = inst.lookupEvent([CCI7Ct.VVL04E, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVqv7L(refCode, events, longDescDays=0):
  ec, inst = CCI7Ct.VV7Pep()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VV9tjr(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCI7Ct.VV7Pep()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCI7Ct.VVNJMT(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CC8xkn.CCI7Ct(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVNJMT(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCI7Ct.VVj7ZR(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVmMR6(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCI7Ct.VV7Pep()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCI7Ct.VVNJMT(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FF2gB8(evTime)
       evEndTxt  = FF2gB8(evEnd)
       evDurTxt  = FF8ZP4(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FF8ZP4(evPos)
        evRem = evEnd - now
        evRemTxt = FF8ZP4(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FF8ZP4(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVj7ZR(event):
  genre = PR = ""
  try:
   genre  = CCI7Ct.VVE7kZ(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCI7Ct.VVQ2hn(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVQ2hn(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVE7kZ(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCI7Ct.VV5I5Z()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VV5I5Z():
  path = VVE5ib + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFvr8J(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFvr8J(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVyrvR(VV5PsO, title):
  ec, inst = CCI7Ct.VV7Pep()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VV5PsO.VVexgG():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCI7Ct.VVL04E, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCI7Ct.VVqv7L(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCI7Ct.VVEUm5()
  txt  = "Services\t: %d\n"  % VV5PsO.VVbwlY()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VV1Prv(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCI7Ct.VVuMQf(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCI7Ct.VVuMQf(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCI7Ct.VVuMQf(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVuMQf(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCI7Ct.VVNJMT(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCI7Ct.VVgPGG(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFbRJw(evName, VVmuI1)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFbRJw(evNameTransl, VVmuI1))
    if evTime           : txt += "Start Time\t: %s\n" % FF2gB8(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF2gB8(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF8ZP4(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF8ZP4(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF8ZP4(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFbRJw(evShort, VVDopz)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFbRJw(evDesc , VVDopz)
    if txt:
     txt = FFbRJw("\n%s\n%s Event:\n%s\n" % (VVwtEz, ("Current", "Next")[evNum], VVwtEz), VVmuI1) + txt
  return txt
 @staticmethod
 def VV3EdJ(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCwvQw(Screen, CCjheW):
 VVj3bs  = 0
 VV2s1Z = 1
 VViukh  = 2
 VVXJbV  = 3
 VVk7oL = 4
 VVHDST = 5
 VVr00s = 6
 VVPQ0f   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV6wdo = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVY9NT = self.VVz2P5()
  FFsd9n(self, VVY9NT=VVY9NT, title="Services/Channels")
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self["myMenu"].setList(self.VVz2P5())
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
 def VVz2P5(self):
  VVY9NT = []
  c = VVPWV9
  VVY9NT.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVY9NT.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVY9NT.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVY9NT.append(VVXMhc)
  c = VVmuI1
  VVY9NT.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVY9NT.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVY9NT.append((VVxsyh + "More tables ..."     , "VVqWy7"    ))
  c = VVDopz
  VVY9NT.append(VVXMhc)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVY9NT.append((c + txt          , "VVNYpl"  ))
  else : VVY9NT.append((txt           ,          ))
  VVY9NT.append((c + 'Export Services to "channels.xml"'    , "VV7H36"      ))
  VVY9NT.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVFaDd
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVY9NT.append((c + "Invalid Services Cleaner"       , "VVFNqV"    ))
  c = VVFaDd
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c + "Delete Channels with no names"     , "VVZFSY"    ))
  VVY9NT.append((c + "Delete Empty Bouquets"       , "VVa2T9"     ))
  VVY9NT.append(VVXMhc)
  VVyaaA, VVcHLr = CCwvQw.VVo8AE()
  if fileExists(VVyaaA):
   enab = fileExists(VVcHLr)
   if enab: VVY9NT.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVY9NT.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVY9NT.append(("Reset Parental Control Settings"      , "VVxp6p"    ))
  VVY9NT.append(("Reload Channels and Bouquets"       , "VVpNd5"      ))
  return VVY9NT
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CC0rhb.VVpY9t(self.session)
   elif item == "openSignal"       : FFhpkO(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFuQxT(self, fncMode=CC8xkn.VVjn7L)
   elif item == "lameDB_allChannels_with_refCode"  : FFDKj1(self, self.VVHJww)
   elif item == "lameDB_allChannels_with_tranaponder" : FFDKj1(self, self.VVTCxj)
   elif item == "VVqWy7"     : self.VVqWy7()
   elif item == "VVNYpl"  : CCxIt0.VVNYpl(self)
   elif item == "VV7H36"      : self.VV7H36()
   elif item == "copyEpgPicons"      : self.VVs8cC(False)
   elif item == "SatellitesCleaner"     : FFDKj1(self, self.FFDKj1_SatellitesCleaner)
   elif item == "VVFNqV"    : FFDKj1(self, BF(self.VVFNqV))
   elif item == "VVZFSY"    : FFDKj1(self, self.VVZFSY)
   elif item == "VVa2T9"     : self.VVa2T9(self)
   elif item == "enableHiddenChannels"     : self.VVZSMX(True)
   elif item == "disableHiddenChannels"    : self.VVZSMX(False)
   elif item == "VVxp6p"    : FFe4rI(self, self.VVxp6p, "Reset and Restart ?")
   elif item == "VVpNd5"      : FFDKj1(self, BF(CCwvQw.VVpNd5, self))
 def VVqWy7(self):
  VVY9NT = []
  VVY9NT.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVY9NT.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVY9NT.append(("Services with PIcons for the System"  , "VVSNOB"    ))
  VVY9NT.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVY9NT.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFaJ04(self, self.VVLdcr, VVY9NT=VVY9NT, title="Service Information", VVNDcU=True)
 def VVLdcr(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFDKj1(self, BF(self.VVWq0u, title))
   elif ref == "parentalControlChannels"   : FFDKj1(self, BF(self.VVXpBw, title))
   elif ref == "showHiddenChannels"    : FFDKj1(self, BF(self.VVSW5L, title))
   elif ref == "VVSNOB"    : FFDKj1(self, BF(self.VVG2rT, title))
   elif ref == "servicesWithMissingPIcons"   : FFDKj1(self, BF(self.VViYRi, title))
   elif ref == "TranspondersStats"     : FFDKj1(self, BF(self.VVnDnD, title))
   elif ref == "SatellitesXmlStats"    : FFDKj1(self, BF(self.VVJyTb, title))
 def VV7H36(self):
  VVY9NT = []
  VVY9NT.append(("All DVB-S/C/T Services", "all"))
  VVY9NT.extend(CCgBRx.VVVi7P())
  FFaJ04(self, self.VVNcSA, VVY9NT=VVY9NT, title="", VVNDcU=True)
 def VVNcSA(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCwvQw.VVmiFv("1:7:")
   else   : lst = FFrlgz(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FF8b2s(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFuuGZ(r)  : sat = "Stream Relay"
       elif FFpHD4(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFd5Wt(CFG.exportedTablesPath.getValue()), FFDaMH())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFNvXQ(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFZWPu(self, "No Services found !", 1500)
 @staticmethod
 def VVpNd5(SELF):
  FFMABX()
  FFNvXQ(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVHJww(self):
  self.VV6wdo = None
  self.lastfilterUsed  = None
  self.filterObj   = CCxD0c(self)
  VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VVj3bs)
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVNiXY  = ("Zap"   , self.VVYuUA     , [])
   VVo8Jh = (""    , self.VVBHOs   , [])
   VVuKTt = ("Options"  , self.VVTqqB , [])
   VVY2vy = ("Current Service", self.VV4LEy , [])
   VVNlag = ("Filter"   , self.VVbkhL  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV3dzh  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindServices)
 def VVTCxj(self):
  self.VV6wdo = None
  self.lastfilterUsed  = None
  self.filterObj   = CCxD0c(self)
  VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VV2s1Z)
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVNiXY  = ("Zap"   , self.VVYuUA      , [])
   VVo8Jh = (""    , self.VVBHOs    , [])
   VVY2vy = ("Current Service", self.VV4LEy  , [])
   VVuKTt = ("Options"  , self.VVnyfC , [])
   VVNlag = ("Filter"   , self.VVbBqT  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV3dzh  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindServices)
 def VVTqqB(self, VV5PsO, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCkpOx(self, VV5PsO)
  VVY9NT = []
  isMulti = VV5PsO.VVSQQE
  if isMulti:
   refCodeList = VV5PsO.VVETD3(3)
   if refCodeList:
    VVY9NT.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVY9NT.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVY9NT.append(VVXMhc)
    VVY9NT.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVY9NT.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVY9NT.append(VVXMhc)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVY9NT.append((txt1, "parentalControl_add" ))
    VVY9NT.append((txt2,        ))
   else:
    VVY9NT.append((txt1,       ))
    VVY9NT.append((txt2, "parentalControl_remove" ))
   VVY9NT.append(VVXMhc)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVY9NT.append((txt1, "hiddenServices_add"  ))
    VVY9NT.append((txt2,       ))
   else:
    VVY9NT.append((txt1,        ))
    VVY9NT.append((txt2, "hiddenServices_remove" ))
   VVY9NT.append(VVXMhc)
  cbFncDict = { "parentalControl_add"   : BF(self.VVFcTi, VV5PsO, refCode, True)
     , "parentalControl_remove"  : BF(self.VVFcTi, VV5PsO, refCode, False)
     , "hiddenServices_add"   : BF(self.VVKC9k, VV5PsO, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVKC9k, VV5PsO, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVSy8P, VV5PsO, True)
     , "parentalControl_sel_remove" : BF(self.VVSy8P, VV5PsO, False)
     , "hiddenServices_sel_add"  : BF(self.VV52a5, VV5PsO, True)
     , "hiddenServices_sel_remove" : BF(self.VV52a5, VV5PsO, False)
     }
  VVY9NT1, cbFncDict1 = CCwvQw.VVfY3u(self, VV5PsO, servName, 3)
  VVY9NT.extend(VVY9NT1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVUhFW(VVY9NT, cbFncDict)
 def VVnyfC(self, VV5PsO, title, txt, colList):
  servName = colList[0]
  mSel = CCkpOx(self, VV5PsO)
  VVY9NT, cbFncDict = CCwvQw.VVfY3u(self, VV5PsO, servName, 3)
  mSel.VVUhFW(VVY9NT, cbFncDict)
 @staticmethod
 def VVfY3u(SELF, VV5PsO, servName, refCodeCol):
  tot = VV5PsO.VVkjUl()
  if tot > 0:
   sTxt = FFbRJw("%d Service%s" % (tot, FF10dh(tot)), VVmuI1)
   VVY9NT = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFUkF8(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFbRJw(servName, VVmuI1)
   VVY9NT = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCwvQw.VV9ztg, SELF, VV5PsO, refCodeCol, True)
     , "addToBouquet_one" : BF(CCwvQw.VV9ztg, SELF, VV5PsO, refCodeCol, False)
     }
  return VVY9NT, cbFncDict
 @staticmethod
 def VV9ztg(SELF, VV5PsO, refCodeCol, isMulti):
  picker = CCgBRx(SELF, VV5PsO, "Add to Bouquet", BF(CCwvQw.VVhpRG, VV5PsO, refCodeCol, isMulti))
 @staticmethod
 def VVhpRG(VV5PsO, refCodeCol, isMulti):
  if isMulti : refCodeList = VV5PsO.VVETD3(refCodeCol)
  else  : refCodeList = [VV5PsO.VVkll0()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVFcTi(self, VV5PsO, refCode, isAddToBlackList):
  VV5PsO.VVfxtU("Processing ...")
  FFcigO(BF(self.VVyy4R, VV5PsO, [refCode], isAddToBlackList))
 def VVSy8P(self, VV5PsO, isAddToBlackList):
  refCodeList = VV5PsO.VVETD3(3)
  if not refCodeList:
   FFh60c(self, "Nothing selected", title="Change Parental-Control State")
   return
  VV5PsO.VVfxtU("Processing ...")
  FFcigO(BF(self.VVyy4R, VV5PsO, refCodeList, isAddToBlackList))
 def VVyy4R(self, VV5PsO, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVGDFI, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVGDFI):
   lines = FFun41(VVGDFI)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVGDFI, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VV5PsO.VVSQQE
   if isMulti:
    self.VVhCjB(VV5PsO, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVkC4T(VV5PsO, refCode)
    VV5PsO.VVxwzS()
  else:
   VV5PsO.VViaMT("No changes")
 def VVKC9k(self, VV5PsO, refCode, isHide):
  title = "Change Hidden State"
  if FFHUOD(refCode):
   VV5PsO.VVfxtU("Processing ...")
   ret = FFD1OO(refCode, isHide)
   if ret : FFDKj1(self, BF(self.VVkC4T, VV5PsO, refCode))
   else : FFh60c(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFh60c(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVkC4T(self, VV5PsO, refCode):
  VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VVj3bs, VVSoc2=[3, [refCode], False])
  done = False
  if VVJnaJ:
   data = VVJnaJ[0]
   if data[3] == refCode:
    done = VV5PsO.VVvHOE(data)
  if not done:
   self.VVm7my(VV5PsO, VV5PsO.VV8zJV(), self.VVj3bs)
  VV5PsO.VVxwzS()
 def VVhCjB(self, VV5PsO, totRefCodes):
  VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VVj3bs, VVSoc2=self.VV6wdo)
  VV5PsO.VVQNRz(VVJnaJ)
  VV5PsO.VVho3y(False)
  VV5PsO.VViaMT("%d Processed" % totRefCodes)
 def VV52a5(self, VV5PsO, isHide):
  refCodeList = VV5PsO.VVETD3(3)
  if not refCodeList:
   FFh60c(self, "Nothing selected", title="Change Hidden State")
   return
  VV5PsO.VVfxtU("Processing ...")
  FFcigO(BF(self.VVV43s, VV5PsO, refCodeList, isHide))
 def VVV43s(self, VV5PsO, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFD1OO(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFMABX(True)
   self.VVhCjB(VV5PsO, len(refCodeList))
  else:
   VV5PsO.VViaMT("No changes")
 def VVbkhL(self, VV5PsO, title, txt, colList):
  inFilterFnc = BF(self.VVffeF, VV5PsO) if self.VV6wdo else None
  self.filterObj.VVnDc0(1, VV5PsO, 2, BF(self.VVMcLd, VV5PsO), inFilterFnc=inFilterFnc)
 def VVMcLd(self, VV5PsO, item):
  self.VVpDLz(VV5PsO, False, item, 2, self.VVj3bs)
 def VVffeF(self, VV5PsO, menuInstance, item):
  self.VVpDLz(VV5PsO, True, item, 2, self.VVj3bs)
 def VVbBqT(self, VV5PsO, title, txt, colList):
  inFilterFnc = BF(self.VV01im, VV5PsO) if self.VV6wdo else None
  self.filterObj.VVnDc0(2, VV5PsO, 4, BF(self.VVPoaF, VV5PsO), inFilterFnc=inFilterFnc)
 def VVPoaF(self, VV5PsO, item):
  self.VVpDLz(VV5PsO, False, item, 4, self.VV2s1Z)
 def VV01im(self, VV5PsO, menuInstance, item):
  self.VVpDLz(VV5PsO, True, item, 4, self.VV2s1Z)
 def VVz0nN(self, VV5PsO, title, txt, colList):
  inFilterFnc = BF(self.VVektp, VV5PsO) if self.VV6wdo else None
  self.filterObj.VVnDc0(0, VV5PsO, 4, BF(self.VVKPSd, VV5PsO), inFilterFnc=inFilterFnc)
 def VVKPSd(self, VV5PsO, item):
  self.VVpDLz(VV5PsO, False, item, 4, self.VViukh)
 def VVektp(self, VV5PsO, menuInstance, item):
  self.VVpDLz(VV5PsO, True, item, 4, self.VViukh)
 def VVpDLz(self, VV5PsO, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VV5PsO.VVEOMp(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV6wdo = None
  else:
   words, asPrefix = CCxD0c.VVuVDQ(words)
   self.VV6wdo = [col, words, asPrefix]
  if words: FFDKj1(VV5PsO, BF(self.VVm7my, VV5PsO, title, mode), clearMsg=False)
  else : FFZWPu(VV5PsO, "Incorrect filter", 2000)
 def VVm7my(self, VV5PsO, title, mode):
  VVJnaJ, err = CCwvQw.VVz7ZO(self, mode, VVSoc2=self.VV6wdo, VVwD2U=False)
  if self.servFilterInFilter:
   lst = []
   for row in VV5PsO.VVexgG():
    try:
     ndx = VVJnaJ.index(tuple(list(map(str.strip, row))))
     lst.append(VVJnaJ[ndx])
    except:
     pass
   VVJnaJ = lst
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VV5PsO.VVQNRz(VVJnaJ, title, VVbcbWMsg=True)
  else:
   FFZWPu(VV5PsO, "Not found!", 1500)
 def VVv8A1(self, title, VV0wO4, VVNiXY=None, VVo8Jh=None, VVNxWT=None, VVY2vy=None, VVuKTt=None, VVNlag=None):
  VVY2vy = ("Current Service", self.VV4LEy, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV3dzh = (LEFT  , LEFT  , CENTER, LEFT    )
  FFXBR7(self, None, title=title, header=header, VV0wO4=VV0wO4, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindServices)
 def VV4LEy(self, VV5PsO, title, txt, colList):
  self.VVUwqn(VV5PsO)
 def VVioi5(self, VV5PsO, title, txt, colList):
  self.VVUwqn(VV5PsO, True)
 def VVUwqn(self, VV5PsO, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VV5PsO.VVz1sS(colDict, VVyRz1=True)
   else:
    VV5PsO.VVIg0J(3, refCode, True)
   return
  FFh60c(self, "Cannot read current Reference Code !")
 def VVWq0u(self, title):
  self.VV6wdo = None
  self.lastfilterUsed  = None
  self.filterObj   = CCxD0c(self)
  VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VViukh)
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVo8Jh = (""    , self.VVQ20m , []      )
   VVY2vy = ("Current Service", self.VVioi5  , []      )
   VVNlag = ("Filter"   , self.VVz0nN   , [], "Loading Filters ..." )
   VVNiXY  = ("Zap"   , self.VVbEdo      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV3dzh  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVY2vy=VVY2vy, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindServices)
 def VVQ20m(self, VV5PsO, title, txt, colList):
  refCode  = self.VVXsrJ(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFuQxT(self, fncMode=CC8xkn.VVu3EF, refCode=refCode, chName=chName, text=txt)
 def VVbEdo(self, VV5PsO, title, txt, colList):
  refCode = self.VVXsrJ(colList)
  FFqoI8(self, refCode)
 def VVYuUA(self, VV5PsO, title, txt, colList):
  FFqoI8(self, colList[3])
 def VVXsrJ(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVxgTR(VVyaaA, mode=0):
  lines = FFun41(VVyaaA, encLst=["UTF-8"])
  return CCwvQw.VVllZf(lines, mode)
 @staticmethod
 def VVllZf(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVz7ZO(SELF, mode, VVSoc2=None, VVwD2U=True, VVsFr5=True):
  VVyaaA, err = CCwvQw.VVj9Zk(SELF, VVsFr5)
  if err:
   return None, err
  asPrefix = False
  if VVSoc2:
   filterCol = VVSoc2[0]
   filterWords = VVSoc2[1]
   asPrefix = VVSoc2[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCwvQw.VVj3bs:
   blackList = None
   if fileExists(VVGDFI):
    blackList = FFun41(VVGDFI)
    if blackList:
     blackList = set(blackList)
  elif mode == CCwvQw.VV2s1Z:
   tp = CCsRkT()
  VVcAst, VVF6pL = FFtgvA()
  if mode in (CCwvQw.VVHDST, CCwvQw.VVr00s):
   VVJnaJ = {}
  else:
   VVJnaJ = []
  tagFound = False
  with ioOpen(VVyaaA, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFeCPs(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCwvQw.VViukh:
       if sTypeInt in VVcAst:
        STYPE = VVF6pL[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVJnaJ.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVJnaJ.append(tRow)
       else:
        VVJnaJ.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCwvQw.VVPQ0f:
        VVJnaJ.append((chName, chProv, sat, refCode))
       elif mode == CCwvQw.VVHDST:
        VVJnaJ[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCwvQw.VVr00s:
        VVJnaJ[chName] = refCode
       elif mode == CCwvQw.VVj3bs:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVJnaJ.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVJnaJ.append(tRow)
        else:
         VVJnaJ.append(tRow)
       elif mode == CCwvQw.VV2s1Z:
        if sTypeInt in VVcAst:
         STYPE = VVF6pL[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVW1mB(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVJnaJ.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVJnaJ.append(tRow)
        else:
         VVJnaJ.append(tRow)
       elif mode == CCwvQw.VVXJbV:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVJnaJ.append((chName, chProv, sat, refCode))
       elif mode == CCwvQw.VVk7oL:
        VVJnaJ.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVJnaJ and VVwD2U:
   FFh60c(SELF, "No services found!")
  return VVJnaJ, ""
 def VVXpBw(self, title):
  if fileExists(VVGDFI):
   lines = FFun41(VVGDFI)
   if lines:
    newRows = []
    VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VVk7oL)
    if VVJnaJ:
     lines = set(lines)
     for item in VVJnaJ:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVJnaJ = newRows
      VVJnaJ.sort(key=lambda x: x[0].lower())
      VVo8Jh = ("", self.VVBHOs, [])
      VVNiXY = ("Zap", self.VVYuUA, [])
      self.VVv8A1(title, VVJnaJ, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh)
     else:
      FFHdWy(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVJnaJ)))
   else:
    FFNvXQ(self, "No active Parental Control services.", FFKcKn())
  else:
   FFCpVp(self, VVGDFI)
 def VVSW5L(self, title):
  VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VVXJbV)
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVo8Jh = ("" , self.VVBHOs, [])
   VVNiXY  = ("Zap", self.VVYuUA, [])
   self.VVv8A1(title, VVJnaJ, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh)
  elif err:
   pass
  else:
   FFNvXQ(self, "No hidden services.", FFKcKn())
 def VVFNqV(self):
  title = "Services unused in Tuner Configuration"
  VVyaaA, err = CCwvQw.VVj9Zk(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCwvQw.VVQWOW()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVX6qO(str(item[0]))
    nsLst.add(ns)
  sysLst = CCwvQw.VVmiFv("1:7:")
  tpLst  = CCwvQw.VVxgTR(VVyaaA, mode=1)
  VVJnaJ = []
  for refCode, chName in sysLst:
   servID = CCwvQw.VVFuMH(refCode)
   tpID = CCwvQw.VVCAjp(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVJnaJ.append((chName, FF8b2s(refCode, False), refCode, servID))
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVuKTt = ("Options"   , BF(self.VVXC4B, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VV3dzh  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVuKTt=VVuKTt, VVU4bo="#0a001122", VVdq78="#0a001122", VVWGqy="#0a001122", VVpoY2="#00004455", VVUWnf="#0a333333", VVwS5R="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFNvXQ(self, "No invalid service found !", title=title)
 def VVXC4B(self, Title, VV5PsO, title, txt, colList):
  mSel = CCkpOx(self, VV5PsO)
  isMulti = VV5PsO.VVSQQE
  if isMulti : txt = "Remove %s Services" % FFbRJw(str(VV5PsO.VVkjUl()), VVxsyh)
  else  : txt = "Remove : %s" % FFbRJw(VV5PsO.VVkll0()[0], VVxsyh)
  VVY9NT = [(txt, "del")]
  cbFncDict = {"del": BF(FFDKj1, VV5PsO, BF(self.VVPbXU, VV5PsO, Title))}
  mSel.VVUhFW(VVY9NT, cbFncDict)
 def VVPbXU(self, VV5PsO, title):
  VVyaaA, err = CCwvQw.VVj9Zk(self, title=title)
  if err:
   return
  isMulti = VV5PsO.VVSQQE
  skipLst = []
  if isMulti : skipLst = VV5PsO.VVETD3(3)
  else  : skipLst = [VV5PsO.VVkll0()[3]]
  tpLst = CCwvQw.VVxgTR(VVyaaA, mode=0)
  servLst = CCwvQw.VVxgTR(VVyaaA, mode=10)
  tmpDbFile = VVyaaA + ".tmp"
  lines   = FFun41(VVyaaA)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FF75pk("mv -f '%s' '%s'" % (tmpDbFile, VVyaaA)))
  VVJnaJ = []
  for row in VV5PsO.VVexgG():
   if not row[3] in skipLst:
    VVJnaJ.append(row)
  FFMABX()
  FFHdWy(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVJnaJ:
   VV5PsO.VVQNRz(VVJnaJ, title)
   VV5PsO.VVho3y(False)
  else:
   VV5PsO.cancel()
 def VVnDnD(self, title):
  VVyaaA, err = CCwvQw.VVj9Zk(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVFsoL(VVyaaA)
  txt = FFbRJw("Total Transponders:\n\n", VV619a)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFbRJw("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV619a)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFwcmp(item), satList.count(item))
  FFHdWy(self, txt, title)
 def VVFsoL(self, VVyaaA):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVyaaA, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVJyTb(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFCpVp(self, path, title=title)
   return
  elif not CCVdBH.VVoq5s(self, path, title):
   return
  if not CCrxMo.VVbAVn(self):
   return
  tree = CCwvQw.VVURao(self, path, title=title)
  if not tree:
   return
  VVJnaJ = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFeCPs(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVJnaJ.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVJnaJ:
   VVJnaJ.sort(key=lambda x: int(x[1]))
   VVY2vy = ("Current Satellite", BF(self.VVpIta, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VV3dzh  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=25, VVBgr7=1, VVY2vy=VVY2vy, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFh60c(self, "No data found !", title=title)
 def VVpIta(self, satCol, VV5PsO, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  sat = FF8b2s(refCode, False)
  for ndx, row in enumerate(VV5PsO.VVexgG()):
   if sat == row[satCol].strip():
    VV5PsO.VVyOnh(ndx)
    break
  else:
   FFZWPu(VV5PsO, "No listed !", 1500)
 def FFDKj1_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFh60c(self, "No Satellites found !")
   return
  usedSats = CCwvQw.VVQWOW()
  VVJnaJ = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVJnaJ.append((sat[1], posTxt, FFeCPs(sat[0]), tuners, str(posVal)))
  if VVJnaJ:
   VVWGqy = "#11222222"
   VVJnaJ.sort(key=lambda x: int(x[1]))
   VVY2vy = ("Current Satellite" , BF(self.VVpIta, 2) , [])
   VVuKTt = ("Options"   , self.VVv3wn  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VV3dzh  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVU4bo=VVWGqy, VVdq78=VVWGqy, VVWGqy=VVWGqy, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFh60c(self, "No data found !")
 def VVv3wn(self, VV5PsO, title, txt, colList):
  mSel = CCkpOx(self, VV5PsO)
  isMulti = VV5PsO.VVSQQE
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFbRJw(str(VV5PsO.VVkjUl()), VVxsyh)
  else  : txt = "Remove ALL Services on : %s" % FFbRJw(VV5PsO.VVkll0()[0], VVxsyh)
  VVY9NT = []
  VVY9NT.append((txt, "deleteSat"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Delete Empty Bouquets", "VVa2T9"))
  cbFncDict = { "deleteSat"   : BF(FFDKj1, VV5PsO, BF(self.VVHmG0, VV5PsO))
     , "VVa2T9" : BF(self.VVa2T9, VV5PsO)
     }
  mSel.VVUhFW(VVY9NT, cbFncDict)
 def VVHmG0(self, VV5PsO):
  posLst = []
  isMulti = VV5PsO.VVSQQE
  posLst = []
  if isMulti : posLst = VV5PsO.VVETD3(4)
  else  : posLst = [VV5PsO.VVkll0()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVX6qO(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVQGGp(nsLst)
  FFMABX(True)
  FFHdWy(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVa2T9(self, winObj):
  title = "Delete Empty Bouquets"
  FFe4rI(self, BF(FFDKj1, winObj, BF(self.VV4A02, title)), "Delete bouquets with no services ?", title=title)
 def VV4A02(self, title):
  bList = CCgBRx.VVNAEY()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCgBRx.VVUWsQ(bRef)
    bPath = VVn6iK + bFile
    FFiHj6(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVn6iK + fil
     if fileExists(path):
      lines = FFun41(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFMABX(True)
  if bNames: txt = "%s\n\n%s" % (FFbRJw("Deleted Bouquets:", VVmuI1), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFHdWy(self, txt, title=title)
 def VVX6qO(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVQGGp(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVn6iK)
  for srcF in files:
   if fileExists(srcF):
    lines = FFun41(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFQKyU(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVG2rT(self, title)   : self.VVSNOB(title, True)
 def VViYRi(self, title) : self.VVSNOB(title, False)
 def VVSNOB(self, title, isWithPIcons):
  piconsPath = CCZBEU.VV0FjB()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCZBEU.VVGoX4(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVJnaJ, err = CCwvQw.VVz7ZO(self, self.VVk7oL)
    if VVJnaJ:
     channels = []
     for (chName, chProv, sat, refCode) in VVJnaJ:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFRC4s(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVJnaJ)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVg0pA(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVg0pA("PIcons Path"  , piconsPath)
     txt += VVg0pA("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVg0pA("Total services" , totalServices)
     txt += VVg0pA("With PIcons"  , totalWithPIcons)
     txt += VVg0pA("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFHdWy(self, txt)
     else:
      VVo8Jh     = (""      , self.VVBHOs , [])
      if isWithPIcons : VVNlag = ("Export Current PIcon", self.VVjRjp  , [])
      else   : VVNlag = None
      VVuKTt     = ("Statistics", FFHdWy, [txt])
      VVNiXY      = ("Zap", self.VVYuUA, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVv8A1(title, channels, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVuKTt=VVuKTt, VVNlag=VVNlag)
   else:
    FFh60c(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFh60c(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVBHOs(self, VV5PsO, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFuQxT(self, fncMode=CC8xkn.VVu3EF, refCode=refCode, chName=chName, text=txt)
 def VVjRjp(self, VV5PsO, title, txt, colList):
  png, path = CCZBEU.VVdaFl(colList[3], colList[0])
  if path:
   CCZBEU.VVIUqf(self, png, path)
 @staticmethod
 def VVo8AE():
  VVyaaA  = "%slamedb" % VVn6iK
  VVcHLr = "%slamedb.disabled" % VVn6iK
  return VVyaaA, VVcHLr
 @staticmethod
 def VVf3n4():
  VVm8jJ  = "%slamedb5" % VVn6iK
  VVVpN1 = "%slamedb5.disabled" % VVn6iK
  return VVm8jJ, VVVpN1
 def VVZSMX(self, isEnable):
  VVyaaA, VVcHLr = CCwvQw.VVo8AE()
  if isEnable and not fileExists(VVcHLr):
   FFNvXQ(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVyaaA):
   FFh60c(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFe4rI(self, BF(self.VVRFsz, isEnable), "%s Hidden Channels ?" % word)
 def VVRFsz(self, isEnable):
  VVyaaA , VVcHLr = CCwvQw.VVo8AE()
  VVm8jJ, VVVpN1 = CCwvQw.VVf3n4()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVcHLr, VVcHLr, VVyaaA)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVVpN1, VVVpN1, VVm8jJ)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVyaaA  , VVyaaA , VVcHLr)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVm8jJ , VVm8jJ, VVVpN1)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVcHLr, VVyaaA )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVVpN1, VVm8jJ)
  res = os.system(cmd)
  FFMABX()
  if res == 0 : FFNvXQ(self, "Hidden List %s" % word)
  else  : FFh60c(self, "Error while restoring:\n\n%s" % fileName)
 def VVxp6p(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVn6iK
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVn6iK
  FFWveA(self, cmd)
 def VVZFSY(self):
  VVyaaA, err = CCwvQw.VVj9Zk(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFiHj6(tmpFile)
  totChan = totRemoved = 0
  lines = FFun41(VVyaaA, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFe4rI(self, BF(FFDKj1, self, BF(self.VVZm7x, tmpFile, VVyaaA, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FF10dh(totRemoved), totChan, FF10dh(totChan))
      , callBack_No=BF(self.VV14sp, tmpFile))
  else:
   FFHdWy(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVZm7x(self, tmpFile, VVyaaA, totRemoved, totChan):
  os.system(FF75pk("mv -f '%s' '%s'" % (tmpFile, VVyaaA)))
  FFMABX()
  FFHdWy(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VV14sp(self, tmpFile):
  FFiHj6(tmpFile)
 @staticmethod
 def VVj9Zk(SELF, VVsFr5=True, title=""):
  VVyaaA, VVcHLr = CCwvQw.VVo8AE()
  if   not fileExists(VVyaaA)       : err = "File not found !\n\n%s" % VVyaaA
  elif not CCVdBH.VVoq5s(SELF, VVyaaA) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVsFr5:
   FFh60c(SELF, err, title=title)
  return VVyaaA, err
 @staticmethod
 def VVCAjp(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVFuMH(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVmiFv(servTypes):
  VVfpZj  = eServiceCenter.getInstance()
  VV2FR7   = '%s ORDER BY name' % servTypes
  VVt6TJ   = eServiceReference(VV2FR7)
  VValRF = VVfpZj.list(VVt6TJ)
  if VValRF: return VValRF.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVQWOW():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CC8xkn(Screen):
 VVjn7L  = 0
 VVlCSN   = 1
 VVByzx   = 2
 VVu3EF    = 3
 VV5nWo    = 4
 VVW4bO   = 5
 VVpcWZ   = 6
 VVP4Xk    = 7
 VVoAkz   = 8
 VVoEp8   = 9
 VVozet   = 10
 VVMoJO   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFWDRO(VVKV47, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVjn7L)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFbRJw("%s\n", VVtUHQ) % VVwtEz
  self.picViewer  = None
  FFsd9n(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVoTYQ })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self["myLabel"].VVxoM0(outputFileToSave="chann_info")
  if   self.fncMode == self.VVjn7L : fnc = self.VVIpV2
  elif self.fncMode == self.VVlCSN  : fnc = self.VVIpV2
  elif self.fncMode == self.VVByzx  : fnc = self.VVIpV2
  elif self.fncMode == self.VVu3EF  : fnc = self.VVkDeS
  elif self.fncMode == self.VV5nWo  : fnc = self.VVJzls
  elif self.fncMode == self.VVW4bO  : fnc = self.VVY5TW
  elif self.fncMode == self.VVpcWZ  : fnc = self.VV8C2C
  elif self.fncMode == self.VVP4Xk  : fnc = self.VV81qS
  elif self.fncMode == self.VVoAkz  : fnc = self.VVkjX4
  elif self.fncMode == self.VVoEp8 : fnc = self.VV97l9
  elif self.fncMode == self.VVozet  : fnc = self.VVLg6y
  elif self.fncMode == self.VVMoJO : fnc = self.VV3LPl
  self["myLabel"].setText("\n   Reading Info ...")
  FFcigO(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVm6n5()
 def VVLout(self, err):
  self["myLabel"].setText(err)
  FFRkaP(self["myTitle"], "#22200000")
  FFRkaP(self["myBody"], "#22200000")
  self["myLabel"].VVEFsc("#22200000")
  self["myLabel"].VVDPfH()
 def VVIpV2(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  self.refCode = refCode
  self.VVQiGF(chName)
 def VVkDeS(self):
  self.VVQiGF(self.chName)
 def VVJzls(self):
  self.VVQiGF(self.chName)
 def VVY5TW(self):
  self.VVQiGF(self.chName)
 def VV8C2C(self):
  self.VVQiGF("Picon Info")
 def VV81qS(self):
  self.VVQiGF(self.chName)
 def VVkjX4(self):
  self.VVQiGF(self.chName)
 def VV97l9(self):
  self.VVQiGF(self.chName)
 def VVLg6y(self):
  self.chUrl = self.refCode + self.callingSELF.VVK0VR(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVQiGF(self.chName)
 def VV3LPl(self):
  self.VVQiGF(self.chName)
 def VVQiGF(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF02Rs(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVYJDX(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFbRJw(self.VVd7fw(tUrl), VVlhbS)
  if not self.epg:
   epg = CCI7Ct.VV1Prv(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVik8X(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCZBEU.VVdaFl(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVik8X(path)
  self.VVedlM()
  self.VVX6Ko()
  self["myLabel"].setText(self.text or "   No active service", VVQY0S=VVyHv2)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVDPfH(minHeight=minH)
 def VVX6Ko(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFpHD4(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVavQr(FFhKb1(url))
  if epg:
   self.text += "\n" + FFF2CM("EPG:", VVmuI1) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVedlM()
 def VVedlM(self):
  if not self.piconShown and self.picUrl:
   path, err = FFzm7R(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVik8X(path)
    if self.piconShown and self.refCode:
     self.VVUi53(path, self.refCode)
 def VVUi53(self, path, refCode):
  if path and fileExists(path) and os.system(FF75pk("which ffmpeg")) == 0:
   pPath = CCZBEU.VV0FjB()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CC8xkn.VVBBqL(path)
    cmd += FF75pk("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVik8X(self, path):
  if path and fileExists(path):
   err, w, h = self.VVYddk(path)
   if not err:
    if h > w:
     self.VVT2C4(self["myPicF"], w, h, True)
     self.VVT2C4(self["myPicB"], w, h, False)
     self.VVT2C4(self["myPic"] , w, h, False)
   self.picViewer = CCbSSH.VVZDD9(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVT2C4(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVYddk(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFA2wB(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVYJDX(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFbRJw(chName, VVmuI1)
  txt += self.VVg0pA(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFbRJw(state, VVLO3F)
   txt += "State\t: %s\n" % state
  w = FFVMAI(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFVMAI(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVJTNX(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVg0pA(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVg0pA(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVg0pA(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVrbBx()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV8Xm2()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CC8xkn.VVhaUo(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFbRJw("Stream-Relay" if FFuuGZ(decodedUrl) else "IPTV", VV619a)
   txt += self.VVBmVW(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVeME6(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCsRkT()
    tpTxt, namespace = tp.VVMAaV(refCode)
    if tpTxt:
     txt += FFbRJw("Tuner:\n", VVmuI1)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFbRJw("Codes:\n", VVmuI1)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVg0pA(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVg0pA(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVg0pA(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVg0pA(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVg0pA(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVg0pA(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVg0pA(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVg0pA(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVg0pA(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVJTNX(info):
  if info:
   aspect = FFVMAI(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVg0pA(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFVMAI(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV3iqf(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV3iqf(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVrbBx(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VV8Xm2(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVeME6(self, refCode, iptvRef, chName):
  refCode = FFJQVB(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFvr8J(VVn6iK + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFvr8J(VVn6iK + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VV0wO4 = []
  tmpRefCode = FFhKb1(refCode)
  for item in fList:
   path = VVn6iK + item
   if fileExists(path):
    txt = FFvr8J(path)
    if tmpRefCode in FFhKb1(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV0wO4.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VV0wO4:
   if len(VV0wO4) == 1:
    txt += "%s\t: %s%s\n" % (FFbRJw("Bouquet", VVmuI1), VV0wO4[0][0], " (%s)" % VV0wO4[0][1] if VVRR1W else "")
   else:
    txt += FFbRJw("Bouquets:\n", VVmuI1)
    for ndx, item in enumerate(VV0wO4):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVRR1W else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVBmVW(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFE7jz(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCQ0t1()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVdlsC(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFbRJw("URL:", VV619a) + "\n%s\n" % self.VVd7fw(decodedUrl)
  else:
   txt = "\n"
   txt += FFbRJw("Reference:", VV619a) + "\n%s\n" % refCode
  return txt
 def VVd7fw(self, url):
  if not FFuuGZ(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVnusr:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFhKb1(url)
 def VVavQr(self, decodedUrl):
  if not CCo7Gj.VVHLsi():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCHli4.VVBGBM(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCHli4.VVgnJH(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVgIZz(tDict)
   elif uType == "movie" : epg, picUrl = CC8xkn.VVofSC(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVgIZz(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCHli4.VVCns1(item, "title"    , is_base64=True )
     lang    = CCHli4.VVCns1(item, "lang"         ).upper()
     description   = CCHli4.VVCns1(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCHli4.VVCns1(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCHli4.VVCns1(item, "start_timestamp"      )
     stop_timestamp  = CCHli4.VVCns1(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCHli4.VVCns1(item, "stop_timestamp"       )
     now_playing   = CCHli4.VVCns1(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVViAb, ""
      else     : color, txt = VVLO3F , "    (CURRENT EVENT)"
      epg += FFbRJw("_" * 32 + "\n", VVtUHQ)
      epg += FFbRJw("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFbRJw(description, VVlhbS)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = CCI7Ct.VVqv7L(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVofSC(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCHli4.VVCns1(item, "movie_image" )
    genre  = CCHli4.VVCns1(item, "genre"   ) or "-"
    plot  = CCHli4.VVCns1(item, "plot"   ) or "-"
    cast  = CCHli4.VVCns1(item, "cast"   ) or "-"
    rating  = CCHli4.VVCns1(item, "rating"   ) or "-"
    director = CCHli4.VVCns1(item, "director"  ) or "-"
    releasedate = CCHli4.VVCns1(item, "releasedate" ) or "-"
    duration = CCHli4.VVCns1(item, "duration"  ) or "-"
    try:
     lang = CCHli4.VVCns1(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFbRJw(cast, VVlhbS)
    epg += "Plot:\n%s"    % FFbRJw(plot, VVlhbS)
   except:
    pass
  return epg, movie_image
 def VVoTYQ(self):
  if VVnusr:
   def VVg0pA(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVg0pA(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCQ0t1()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVdlsC(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVg0pA(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVwtEz, txt))
   FFZWPu(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVe18A(SELF):
  if not CCWQxC.VVTp8Y(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF)
  err = url =  fSize = resumable = ""
  if FFxp0h(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCQ0t1.VVFJfy(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCQ0t1.VVR1NX(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFh60c(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCVdBH.VVFJRm(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFbRJw(" (M3U/M3U8 File)", VVlhbS)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCPWpb.VVCRm0(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVmzbD(subj, val):
   return "%s\n%s\n\n" % (FFbRJw("%s:" % subj, VVmuI1), val)
  title = "File Size"
  txt  = VVmzbD(title , fSize or "?")
  txt += VVmzbD("Name" , chName)
  txt += VVmzbD("URL" , url)
  if resumable: txt += VVmzbD("Supports Download-Resume", resumable)
  if err  : txt += FFbRJw("Error:\n", VVLO3F) + err
  FFHdWy(SELF, txt, title=title)
 @staticmethod
 def VVhaUo(SELF):
  fPath, fDir, fName = CCVdBH.VV950I(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVBBqL(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VV0iot(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCZBEU.VV0FjB() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVWLqa(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFpHD4(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFQKyU(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCQ0t1():
 def __init__(self):
  self.VVIjll()
  self.VVLFqR    = ""
  self.VVC0OG   = "#f#11ffffaa#User"
  self.VVu8U1   = "#f#11aaffff#Server"
 def VVIjll(self):
  self.VVKBxA   = ""
  self.VVJQVO    = ""
  self.VVgwV4   = ""
  self.VVaLDN = ""
  self.VVvkec  = ""
  self.VVRkA3 = 0
 def VVM89p(self, url, mac, ph1="", VVyRz1=True):
  self.VVIjll()
  self.VVLFqR = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVlshG(url)
  if not host:
   if VVyRz1:
    self.VVELFw("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVdTEK(mac)
  if not host:
   if VVyRz1:
    self.VVELFw("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVKBxA = host
  self.VVJQVO  = mac
  return True
 def VVlshG(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVdTEK(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVXXXU(self):
  res, err = self.VVC12w(self.VVA9ss())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVKBxA.endswith("/c"):
    self.VVKBxA = self.VVKBxA[:-2]
    res, err = self.VVC12w(self.VVA9ss())
   elif self.VVKBxA.endswith("/stalker_portal"):
    self.VVKBxA = self.VVKBxA[:-15]
    res, err = self.VVC12w(self.VVA9ss())
   else:
    self.VVKBxA += "/c"
    res, err = self.VVC12w(self.VVA9ss())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCHli4.VVCns1(tDict["js"], "token")
    rand  = CCHli4.VVCns1(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVzV0F(self, VVyRz1=True):
  if not self.VVLFqR:
   self.VV9dFb()
  err = blkMsg = FFNvXQTxt = ""
  try:
   token, rand, err = self.VVXXXU()
   if token:
    self.VVgwV4 = token
    self.VVaLDN = rand
    if rand:
     self.VVRkA3 = 2
    prof, retTxt = self.VVYw6K(True)
    if prof:
     self.VVvkec = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVRkA3 = 3
      prof, retTxt = self.VVYw6K(False)
      if retTxt:
       self.VVvkec = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFNvXQTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFNvXQTxt: tErr += "\n%s" % FFNvXQTxt
  if VVyRz1:
   self.VVELFw(tErr)
  return "", "", tErr
 def VV9dFb(self):
  try:
   import requests
   url = self.VVHtgM()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCQ0t1.VVR1NX(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCQ0t1.VVR1NX(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVKBxA = url
       self.VVLFqR = span.group(1)
       return
  except:
   pass
  self.VVLFqR = "/server/load.php"
 def VVHtgM(self):
  url = self.VVKBxA.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVLda5(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVC12w("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVC12w("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVYw6K(self, capMac):
  res, err = self.VVC12w(self.VVManX(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCHli4.VVCns1(tDict["js"], "block_%s" % word)
    FFNvXQTxt = CCHli4.VVCns1(tDict["js"], word)
    return tDict, FFNvXQTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVManX(self, capMac):
  param = ""
  if self.VVvkec or self.VVaLDN:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVJQVO.upper() if capMac else self.VVJQVO.lower(), self.VVaLDN))
  return self.VVCkpx() + "type=stb&action=get_profile" + param
 exec(FFTy1z("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVMPMK(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVBkx2()
  if len(rows) < 10:
   rows = self.VV5feJ()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVKBxA ))
   rows.append(("MAC (from URL)" , self.VVJQVO ))
   rows.append(("Token"   , self.VVgwV4 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVC0OG  , "MAC" , self.VVJQVO ))
   rows.append(("2", self.VVu8U1, "Host" , self.VVKBxA ))
   rows.append(("2", self.VVu8U1, "Token" , self.VVgwV4 ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVU3aB(self, isPhp=True, VVyRz1=False):
  token, profile, tErr = self.VVzV0F(VVyRz1)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVHMMH()
  res, err = self.VVC12w(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCHli4.VVCns1(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFeaA3(span.group(2))
     pass1 = FFeaA3(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVBkx2(self):
  m3u_Url, host, user1, pass1, err = self.VVU3aB()
  rows = []
  if m3u_Url:
   res, err = self.VVC12w(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF2gB8(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVC0OG, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF2gB8(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVu8U1, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV5feJ(self):
  token, profile, tErr = self.VVzV0F()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF1Wb5(val): val = FFTy1z(val.decode("UTF-8"))
     else     : val = self.VVJQVO
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF2gB8(int(parts[1]))
      if parts[2] : ends = FF2gB8(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF2gB8(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVK0VR(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVzV0F(VVyRz1=False)
  if not token:
   return ""
  crLinkUrl = self.VVLF4R(mode, chCm, epNum, epId)
  res, err = self.VVC12w(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCHli4.VVCns1(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVCkpx(self):
  return self.VVKBxA + self.VVLFqR + "?"
 def VVA9ss(self):
  return self.VVCkpx() + "type=stb&action=handshake&token=&mac=%s" % self.VVJQVO
 def VV7cyQ(self, mode):
  url = self.VVCkpx() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVfQoa(self, catID):
  return self.VVCkpx() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVuv0d(self, mode, catID, page):
  url = self.VVCkpx() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVk4rH(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVCkpx() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVXfmB(self, mode, catID):
  return self.VVCkpx() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVLF4R(self, mode, chCm, serCode, serId):
  url = self.VVCkpx() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVHMMH(self):
  return self.VVCkpx() + "type=itv&action=create_link"
 def VVNcNK(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVERJx(catID, stID, chNum)
  query = self.VV35ky(mode, self.VVLFqR[1:2], FFLRAx(host), FFLRAx(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV35ky(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVdlsC(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV35ky(mode, ph1, host, mac, epNum, epId, FFeaA3(chCm))
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFTy1z(host)
  mac   = FFTy1z(mac)
  valid = False
  if self.VVlshG(playHost) and self.VVlshG(host) and self.VVlshG(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVC12w(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCQ0t1.VVR1NX()
   if self.VVgwV4:
    headers["Authorization"] = "Bearer %s" % self.VVgwV4
   if useCookies : cookies = {"mac": self.VVJQVO, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVYnhy(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCQ0t1.VVR1NX(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVR1NX():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVp9OY(host, mac, tType, action, keysList=None):
  myPortal = CCQ0t1()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVM89p(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVzV0F(VVyRz1=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVC12w(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV5gYh(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV5gYh(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVELFw(self, err, title="Portal Browser"):
  FFh60c(self, str(err), title=title)
 def VVyhdN(self, mode):
  if   mode in ("itv"  , CCHli4.VVO5De , CCHli4.VVYsqd)  : return "Live"
  elif mode in ("vod"  , CCHli4.VVvL0Y , CCHli4.VVkCEu)  : return "VOD"
  elif mode in ("series" , CCHli4.VVVboQ , CCHli4.VV5y6y) : return "Series"
  else                          : return "IPTV"
 def VVGUdI(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVyhdN(mode), FFbRJw(searchName, VVlhbS))
 def VVCuaq(self, catchup=False):
  VVY9NT = []
  VVY9NT.append(("Live"    , "live"  ))
  VVY9NT.append(("VOD"    , "vod"   ))
  VVY9NT.append(("Series"   , "series"  ))
  if catchup:
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Catch-up TV" , "catchup"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Account Info." , "accountInfo" ))
  return VVY9NT
 @staticmethod
 def VVpjeF(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCQ0t1()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVdlsC(decodedUrl)
  if valid:
   ok = p.VVM89p(host, mac, ph1, VVyRz1=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVU3aB(isPhp=False, VVyRz1=False)
    streamId = CCQ0t1.VVL1t0(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVL1t0(decodedUrl):
  p = CCQ0t1()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVdlsC(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFTy1z(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVFJfy(decodedUrl):
  p = CCQ0t1()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVdlsC(decodedUrl)
  if valid:
   if CCQ0t1.VVCQZz(chCm):
    return FFhKb1(chCm)
   else:
    ok = p.VVM89p(host, mac, ph1, VVyRz1=False)
    if ok:
     try:
      chUrl = p.VVK0VR(mode, chCm, epNum, epId)
      return FFhKb1(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVCQZz(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCNJgc(CCQ0t1):
 def __init__(self):
  CCQ0t1.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVVvef(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVdlsC(decodedUrl)
  if valid:
   if self.VVM89p(host, mac, ph1, VVyRz1=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVt6FJ(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVK0VR(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCQ0t1.VVCQZz(self.chCm):
   chUrl = FFhKb1(self.chCm)
   chUrl = FFeaA3(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVpqAI(chUrl)
  bPath = CCgBRx.VVJ0V1()
  if newIptvRef:
   if passedSELF:
    FFqoI8(passedSELF, newIptvRef, VVLrHC=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFqoI8(self, newIptvRef, VVLrHC=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVVBgV(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVpqAI(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVVBgV(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFun41(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFMABX()
class CCwyZ7(CCNJgc):
 def __init__(self, passedSession):
  CCNJgc.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVVssr(VVkmMH  )
  Main_Menu.VVVssr(VVHPQk)
  Main_Menu.VVVssr(VVtCop  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VV44v0, iPlayableService.evEOF: self.VVahFF, iPlayableService.evEnd: self.VV5ptg})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VV4McV)
  except:
   self.timer2.callback.append(self.VV4McV)
  self.timer2.start(3000, False)
  self.VV4McV()
 def VV4McV(self):
  if not CFG.downloadMonitor.getValue():
   self.VV2xJi()
   return
  lst = CCPWpb.VVMKM1()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFtDuT(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCPWpb.VVtWOQ(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCc3YV, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FF5Gbi(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VV2xJi()
 def VV2xJi(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VV44v0(self):
  self.startTime = iTime()
 def VVahFF(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFxp0h(decodedUrl):
     self.isFromEOF = True
     CCtonn(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VV5ptg(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVp1iF)
  except:
   self.timer1.callback.append(self.VVp1iF)
  self.timer1.start(100, True)
 def VVp1iF(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVVvef(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CC0rhb.VVuHV5:
       self.isFromEOF = False
       self.VVt6FJ(self.passedSession, isFromSession=True)
class CCcmOV():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film")
  self.adultWords2 = (  b"\xd1\x8d\xd1\x80\xd0\xbe\xd1\x82\xd0\xb8\xd1\x87\xd0\xb5\xd1\x81\xd0\xba\xd0\xb8\xd0\xb5".decode("UTF-8")
       , b"\xd1\x8d\xd1\x80\xd0\xbe\xd1\x82\xd0\xb8\xd1\x87\xd0\xb5\xd1\x81\xd0\xba\xd0\xb8\xd0\xb9".decode("UTF-8")
       , b"\xd0\xb2\xd0\xb7\xd1\x80\xd0\xbe\xd1\x81\xd0\xbb\xd1\x8b\xd1\x85".decode("UTF-8")
       , b"\x64\x6f\x72\x6f\x73\xc5\x82\x79\x63\x68".decode("UTF-8") )
 def VVpiAI(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCHli4.VV0slf(name):
   return CCHli4.VVWeG1(name)
  name = self.VVmoJr(name)
  return name.strip() or name
 def VVmoJr(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VVoOYr(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVmoJr(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVoeR0(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords) or any(x in tName for x in self.adultWords2):
    return ""
  return name.strip()
 def VVpGAi(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVN72B(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCWQxC(CCQ0t1):
 def __init__(self):
  CCQ0t1.__init__(self)
 def VVGpWH(self):
  if CCWQxC.VVTp8Y(self):
   FFDKj1(self, BF(self.VVNcFT, 2), title="Searching ...")
 def VVEBS2(self, winSession, url, mac):
  self.curUrl = url
  if CCWQxC.VVTp8Y(self):
   if self.VVM89p(url, mac):
    FFDKj1(winSession, self.VVCgHw, title="Checking Server ...")
   else:
    FFh60c(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVaZpA(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCORAx.VV7Rit(path, self)
   if enc == -1:
    return
   self.session.open(CCRrSr, barTheme=CCRrSr.VVHTAa
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVgNu0, path, enc)
       , VVsfO0 = BF(self.VVC0VS, menuInstance, path))
 def VVgNu0(self, path, enc, VVq6PE):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVq6PE.VVlEfz(totLines)
  VVq6PE.VVwxC6 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVq6PE or VVq6PE.isCancelled:
     return
    VVq6PE.VVA8Cz(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVlshG(url)
     mac  = self.VVdTEK(mac)
     if host and mac and VVq6PE:
      VVq6PE.VVwxC6.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVlshG(url)
      mac  = self.VVdTEK(mac)
      if host and mac and not mac.startswith("AC") and VVq6PE:
       VVq6PE.VVwxC6.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVC0VS(self, menuInstance, path, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVwxC6:
   VVNxWT  = ("Home Menu"  , FFcLLG            , [])
   VVuKTt = ("Edit File"  , BF(self.VVNdTf, path)       , [])
   VVY2vy = ("M3U Options" , self.VVJ6IT         , [])
   VVNlag = ("Check & Filter" , BF(self.VV1Riz, menuInstance, path), [])
   VVNiXY  = ("Select"   , self.VVJUIZ      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV3dzh  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVwxC6, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, VVU4bo="#0a001122", VVdq78="#0a001122", VVWGqy="#0a001122", VVpoY2="#00004455", VVUWnf="#0a333333", VVwS5R="#11331100", VVcNyk=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVWVbF:
    FFZWPu(VV5PsO, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVWVbF:
    FFh60c(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVJ6IT(self, VV5PsO, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVY9NT = []
  VVY9NT.append(("Browse as M3U"  , "browse"))
  VVY9NT.append(("Download M3U File" , "downld"))
  FFaJ04(self, BF(self.VV9pPk, VV5PsO, host, mac), title=title, VVY9NT=VVY9NT, width=600, VVNDcU=True)
 def VV9pPk(self, VV5PsO, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFDKj1(VV5PsO, BF(self.VVL1vW, VV5PsO, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFe4rI(self, BF(FFDKj1, VV5PsO, BF(self.VVL1vW, VV5PsO, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVL1vW(self, VV5PsO, title, host, mac, item):
  p = CCQ0t1()
  m3u_Url = ""
  ok = p.VVM89p(host, mac, VVyRz1=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVU3aB(VVyRz1=False)
  if m3u_Url:
   if   item == "browse": self.VV7FIE(title, m3u_Url)
   elif item == "downld": self.VV20CY(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFh60c(self, err or "No response from Server !", title=title)
 def VVJUIZ(self, VV5PsO, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVEBS2(VV5PsO, url, mac)
 def VVNdTf(self, path, VV5PsO, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCbHA8(self, path, VVsfO0=BF(self.VV5rKh, VV5PsO), curRowNum=rowNum)
  else    : FFCpVp(self, path)
 def VV1Riz(self, menuInstance, path, VV5PsO, title, txt, colList):
  self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVU80U, VV5PsO)
      , VVsfO0 = BF(self.VVXHuo, menuInstance, VV5PsO, path))
 def VVU80U(self, VV5PsO, VVq6PE):
  VVq6PE.VVwxC6 = []
  VVq6PE.VVlEfz(VV5PsO.VVbwlY())
  for row in VV5PsO.VVexgG():
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVA8Cz(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVM89p(host, mac, VVyRz1=False):
    token, profile, tErr = self.VVzV0F(VVyRz1=False)
    if token and VVq6PE and not VVq6PE.isCancelled:
     res, err = self.VVC12w(self.VV7cyQ("itv"))
     if res and VVq6PE and not VVq6PE.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVq6PE.VVA8Cz(0, showFound=True)
       VVq6PE.VVwxC6.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVq6PE:
    return
 def VVXHuo(self, menuInstance, VV5PsO, path, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if VVwxC6:
   VV5PsO.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFDaMH())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVwxC6:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFbRJw(str(threadCounter), VVLO3F)
    skipped = FFbRJw(str(threadTotal - threadCounter), VVLO3F)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVwxC6)
   txt += "%s\n\n%s"    %  (FFbRJw("Result File:", VVmuI1), newPath)
   FFHdWy(self, txt, title="Accessible Portals")
  elif VVWVbF:
   FFh60c(self, "No portal access found !", title="Accessible Portals")
 def VVzgaW(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFTy1z(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVCgHw(self):
  token, profile, tErr = self.VVzV0F()
  if token:
   dots = "." * self.VVRkA3
   dots += "+" if self.VVLFqR[1:2] == "p" else ""
   dots += "*" if not self.VVKBxA == self.curUrl else ""
   VVY9NT  = self.VVCuaq()
   OKBtnFnc = self.VVHy7E
   infoBtnFnc = self.VVCGxt
   VVtVox = ("Home Menu", FFcLLG)
   VVMxmU= ("Add to Menu", BF(CCHli4.VVu7aL, self, True, self.VVKBxA + "\t" + self.VVJQVO))
   VV8vtf = ("Bookmark Server", BF(CCHli4.VVJQvK, self, True, self.VVKBxA + "\t" + self.VVJQVO))
   FFaJ04(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVJQVO, dots), VVY9NT=VVY9NT, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVtVox=VVtVox, VVMxmU=VVMxmU, VV8vtf=VV8vtf)
 def VVHy7E(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFDKj1(menuInstance, BF(self.VVJOgJ, mode), title="Reading Categories ...")
   else : FFDKj1(menuInstance, BF(self.VVLH94, menuInstance, title), title="Reading Account ...")
 def VVLH94(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVMPMK(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVJQVO)
  VVNxWT  = ("Home Menu" , FFcLLG           , [])
  VVY2vy  = None
  if VVnusr:
   VVY2vy = ("Get JS"  , BF(self.VV70Aj, self.VVHtgM()) , [])
  if totCols == 2:
   VVNlag = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVNlag = ("More Info.", BF(self.VV9xgc, menuInstance)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFXBR7(self, None, title=title, width=1200, header=header, VV0wO4=rows, VVgZrM=widths, VVfp7o=26, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVNlag=VVNlag, VVU4bo="#0a00292B", VVdq78="#0a002126", VVWGqy="#0a002126", VVpoY2="#00000000", searchCol=searchCol)
 def VV70Aj(self, url, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VVd81s, url), title="Getting JS ...")
 def VVd81s(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVJQVO)
  ver, err = self.VVLda5(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVLda5(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFHdWy(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VV9xgc(self, menuInstance, VV5PsO, title, txt, colList):
  VV5PsO.cancel()
  FFDKj1(menuInstance, BF(self.VVLH94, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVJOgJ(self, mode):
  token, profile, tErr = self.VVzV0F()
  if not token:
   return
  res, err = self.VVC12w(self.VV7cyQ(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVPC0A = CCcmOV()
     chList = tDict["js"]
     for item in chList:
      Id   = CCHli4.VVCns1(item, "id"       )
      Title  = CCHli4.VVCns1(item, "title"      )
      censored = CCHli4.VVCns1(item, "censored"     )
      Title = VVPC0A.VVoeR0(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVRR1W:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVyhdN(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9(mode)
   mName = self.VVyhdN(mode)
   VVNiXY   = ("Show List"   , BF(self.VV03kT, mode)   , [])
   VVNxWT  = ("Home Menu"   , FFcLLG        , [])
   if mode in ("vod", "series"):
    VVuKTt = ("Find in %s" % mName , BF(self.VVljLq, mode, False), [])
    VVNlag = ("Find in Selected" , BF(self.VVljLq, mode, True) , [])
   else:
    VVuKTt = None
    VVNlag = None
   header   = None
   widths   = (100   , 0  )
   FFXBR7(self, None, title=title, width=1200, header=header, VV0wO4=list, VVgZrM=widths, VVfp7o=30, VVNxWT=VVNxWT, VVuKTt=VVuKTt, VVNlag=VVNlag, VVNiXY=VVNiXY, VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVWGqy, VVpoY2=VVpoY2, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVvkec:
     txt += "\n\n( %s )" % self.VVvkec
   else:
    txt = "Could not get Categories from server!"
   FFh60c(self, txt, title=title)
 def VV2V5R(self, mode, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VVIpUz, mode, VV5PsO, title, txt, colList), title="Downloading ...")
 def VVIpUz(self, mode, VV5PsO, title, txt, colList):
  token, profile, tErr = self.VVzV0F()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVC12w(self.VVfQoa(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCHli4.VVCns1(item, "id"    )
      actors   = CCHli4.VVCns1(item, "actors"   )
      added   = CCHli4.VVCns1(item, "added"   )
      age    = CCHli4.VVCns1(item, "age"   )
      category_id  = CCHli4.VVCns1(item, "category_id" )
      description  = CCHli4.VVCns1(item, "description" )
      director  = CCHli4.VVCns1(item, "director"  )
      genres_str  = CCHli4.VVCns1(item, "genres_str"  )
      name   = CCHli4.VVCns1(item, "name"   )
      path   = CCHli4.VVCns1(item, "path"   )
      screenshot_uri = CCHli4.VVCns1(item, "screenshot_uri" )
      series   = CCHli4.VVCns1(item, "series"   )
      cmd    = CCHli4.VVCns1(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVNiXY  = ("Play"    , BF(self.VV1whd, mode)       , [])
   VVo8Jh = (""     , BF(self.VVesuW, mode)     , [])
   VVNxWT = ("Home Menu"   , FFcLLG            , [])
   VVY2vy = ("Download Options" , BF(self.VVKOXG, mode, "sp", seriesName) , [])
   VVuKTt = ("Options"   , BF(self.VVEYM1, "pEp", mode, seriesName) , [])
   VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV3dzh  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFXBR7(self, None, title=seriesName, width=1200, header=header, VV0wO4=list, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindIptv, VVU4bo="#0a00292B", VVdq78="#0a002126", VVWGqy="#0a002126", VVpoY2="#00000000")
  else:
   FFh60c(self, "Could not get Episodes from server!", title=seriesName)
 def VVljLq(self, mode, searchInCat, VV5PsO, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVY9NT = []
  VVY9NT.append(("Keyboard"  , "manualEntry"))
  VVY9NT.append(("From Filter" , "fromFilter"))
  FFaJ04(self, BF(self.VVF1gY, VV5PsO, mode, searchCatId), title="Input Type", VVY9NT=VVY9NT, width=400)
 def VVF1gY(self, VV5PsO, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF5ZDh(self, BF(self.VVNo21, VV5PsO, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCxD0c(self)
    filterObj.VV4ACb(BF(self.VVNo21, VV5PsO, mode, searchCatId))
 def VVNo21(self, VV5PsO, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFoBdB(CFG.lastFindIptv, searchName)
   title = self.VVGUdI(mode, searchName)
   if "," in searchName : FFh60c(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFh60c(self, "Enter at least 3 characters.", title=title)
   else     :
    VVPC0A = CCcmOV()
    if CFG.hideIptvServerAdultWords.getValue() and VVPC0A.VVpGAi([searchName]):
     FFh60c(self, VVPC0A.VVN72B(), title=title)
    else:
     self.VVL3XK(mode, searchName, "", searchName, searchCatId)
 def VV03kT(self, mode, VV5PsO, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVL3XK(mode, bName, catID, "", "")
 def VVL3XK(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCRrSr, barTheme=CCRrSr.VVHTAa
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVsBpp, mode, bName, catID, searchName, searchCatId)
      , VVsfO0 = BF(self.VVkA9V, mode, bName, catID, searchName, searchCatId))
 def VVkA9V(self, mode, bName, catID, searchName, searchCatId, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVGUdI(mode, searchName)
  else   : title = "%s : %s" % (self.VVyhdN(mode), bName)
  if VVwxC6:
   VVY2vy = None
   VVuKTt = None
   if mode == "series":
    VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9("series2")
    VVNiXY  = ("Episodes"   , BF(self.VV2V5R, mode)           , [])
   else:
    VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9("")
    VVNiXY  = ("Play"    , BF(self.VV1whd, mode)           , [])
    VVY2vy = ("Download Options" , BF(self.VVKOXG, mode, "vp" if mode == "vod" else "", "") , [])
    VVuKTt = ("Options"   , BF(self.VVEYM1, "pCh", mode, bName)      , [])
   VVo8Jh = (""      , BF(self.VVdyEj, mode)         , [])
   VVNxWT = ("Home Menu"    , FFcLLG                , [])
   VVNlag = ("Posters Mode"   , BF(self.VVI27h, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VV3dzh  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVwxC6, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindIptv, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVWGqy, VVpoY2=VVpoY2, VVcNyk=True, searchCol=1)
   if not VVWVbF:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VV5PsO.VVNXg7(VV5PsO.VV8zJV() + tot)
    if threadErr: FFZWPu(VV5PsO, "Error while reading !", 2000)
    else  : FFZWPu(VV5PsO, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFh60c(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFh60c(self, "Could not get list from server !", title=title)
 def VVdyEj(self, mode, VV5PsO, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFuQxT(self, fncMode=CC8xkn.VVMoJO, portalHost=self.VVKBxA, portalMac=self.VVJQVO, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVowRV(mode, VV5PsO, title, txt, colList)
 def VVesuW(self, mode, VV5PsO, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFbRJw(colList[10], VVlhbS)
  txt += "Description:\n%s" % FFbRJw(colList[11], VVlhbS)
  self.VVowRV(mode, VV5PsO, title, txt, colList)
 def VVowRV(self, mode, VV5PsO, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVo2nq(mode, colList)
  refCode, chUrl = self.VVNcNK(self.VVKBxA, self.VVJQVO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFuQxT(self, fncMode=CC8xkn.VVozet, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVsBpp(self, mode, bName, catID, searchName, searchCatId, VVq6PE):
  try:
   token, profile, tErr = self.VVzV0F()
   if not token:
    return
   if VVq6PE.isCancelled:
    return
   VVq6PE.VVwxC6, total_items, max_page_items, err = self.VVb83V(mode, catID, 1, 1, searchName, searchCatId)
   if VVq6PE.isCancelled:
    return
   if VVq6PE.VVwxC6 and total_items > -1 and max_page_items > -1:
    VVq6PE.VVlEfz(total_items)
    VVq6PE.VVA8Cz(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVq6PE.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVb83V(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVq6PE.VVzQYG()
     if VVq6PE.isCancelled:
      return
     if list:
      VVq6PE.VVwxC6 += list
      VVq6PE.VVA8Cz(len(list), True)
  except:
   pass
 def VVb83V(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVk4rH(mode, searchName, searchCatId, page)
  else   : url = self.VVuv0d(mode, catID, page)
  res, err = self.VVC12w(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVC6D0(CCHli4.VVCns1(item, "total_items" ))
     max_page_items = self.VVC6D0(CCHli4.VVCns1(item, "max_page_items" ))
     VVPC0A = CCcmOV()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCHli4.VVCns1(item, "id"    )
      name   = CCHli4.VVCns1(item, "name"   )
      o_name   = CCHli4.VVCns1(item, "o_name"   )
      tv_genre_id  = CCHli4.VVCns1(item, "tv_genre_id" )
      number   = CCHli4.VVCns1(item, "number"   ) or str(counter)
      logo   = CCHli4.VVCns1(item, "logo"   )
      screenshot_uri = CCHli4.VVCns1(item, "screenshot_uri" )
      cmd    = CCHli4.VVCns1(item, "cmd"   )
      censored  = CCHli4.VVCns1(item, "censored"  )
      genres_str  = CCHli4.VVCns1(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVKBxA + picon).replace(sp * 2, sp)
      counter += 1
      name = VVPC0A.VVpiAI(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVC6D0(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV1whd(self, mode, VV5PsO, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVo2nq(mode, colList)
  refCode, chUrl = self.VVNcNK(self.VVKBxA, self.VVJQVO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VV0slf(chName):
   FFZWPu(VV5PsO, "This is a marker!", 300)
  else:
   FFDKj1(VV5PsO, BF(self.VVmFrq, mode, VV5PsO, chUrl), title="Playing ...")
 def VVmFrq(self, mode, VV5PsO, chUrl):
  FFqoI8(self, chUrl, VVLrHC=False)
  CC0rhb.VVpY9t(self.session, iptvTableParams=(self, VV5PsO, mode))
 def VVi8eb(self, mode, VV5PsO, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVo2nq(mode, colList)
  refCode, chUrl = self.VVNcNK(self.VVKBxA, self.VVJQVO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVo2nq(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVTp8Y(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVY9NT = []
    VVY9NT.append((title        , "inst" ))
    VVY9NT.append(("Update Packages then %s" % title , "updInst" ))
    FFaJ04(SELF, BF(CCWQxC.VVdIA7, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVY9NT=VVY9NT)
   return False
 @staticmethod
 def VVdIA7(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFv5Rb(VVjlpz, "")
   if cmdUpd:
    cmdInst = FFXUpj(VVzo0S, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFx5HE(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VV54cX=cbFnc)
   else:
    FFhvmT(SELF)
class CCHli4(Screen, CCWQxC, CCjheW):
 VVOI62    = 0
 VVEK5R    = 1
 VVuvCD    = 2
 VVPVdf    = 3
 VVFf3T     = 4
 VVi8Rr     = 5
 VVgVWj     = 6
 VVkCGx     = 7
 VVHru8     = 8
 VVHrFh     = 9
 VVxJdA      = 10
 VVwxHd     = 11
 VVMGH6     = 12
 VVOdCW     = 13
 VVj7II     = 14
 VVAtek      = 15
 VVWax4      = 16
 VVuN1M      = 17
 VVicvm      = 18
 VVd0qa      = 19
 VV6v9H    = 0
 VVO5De   = 1
 VVvL0Y   = 2
 VVVboQ   = 3
 VV8zB6  = 4
 VVgxDb  = 5
 VVYsqd   = 6
 VVkCEu   = 7
 VV5y6y  = 8
 VV6X9Z  = 9
 VVEJJ1  = 10
 VVbYE7 = 0
 VVHLiZ = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VV5PsO    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVOdMwData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCHli4.VVwfQF(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCWQxC.__init__(self)
  VVY9NT = self.VVz2P5()
  FFsd9n(self, title="IPTV", VVY9NT=VVY9NT)
  self["myActionMap"].actions.update({
   "menu" : self.VVMsS5
  })
  self["myMenu"].onSelectionChanged.append(self.VV4GMg)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self["myMenu"].setList(self.VVz2P5())
  FFEPLV(self)
  FFnx82(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFR6rJ(self["myMenu"])
   FFMPfH(self)
   if self.m3uOrM3u8File:
    self.VVjxff(self.m3uOrM3u8File)
 def VV4GMg(self):
  if self["myMenu"].getCurrent()[1] in ("VVFwk1", "VVjDWePortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVMsS5(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVjDWePortal" : confItem = CFG.favServerPortal
   elif item == "VVFwk1" : confItem = CFG.favServerPlaylist
   else         : return
   FFe4rI(self, BF(self.VVVLKp, confItem), 'Remove from menu ?', title=title)
 def VVVLKp(self, confItem):
  FFoBdB(confItem, "")
  self.VVrYby()
 def VVz2P5(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVFaDd
  VVY9NT = []
  if isFav1: VVY9NT.append((c +  "Favourite Playlist Server"   , "VVFwk1" ))
  if isFav2: VVY9NT.append((c +  "Favourite Portal Server"    , "VVjDWePortal" ))
  VVY9NT.append(("IPTV Server Browser (from Playlists)"     , "VVOdMw_fromPlayList" ))
  VVY9NT.append(("IPTV Server Browser (from Portal List)"    , "VVOdMw_fromMac"  ))
  VVY9NT.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVOdMw_fromM3u"  ))
  qUrl, iptvRef = CCHli4.VVdZu8(self)
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVY9NT.append((item     , "VVOdMw_fromCurrChan" ))
  else       : VVY9NT.append((item     ,       ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("M3U/M3U8 File Browser"        , "VVxiYm"   ))
  if self.iptvFileAvailable:
   VVY9NT.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVY9NT.append(VVXMhc)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVY9NT.append((item1            , "refreshIptvEPG"   ))
   VVY9NT.append((item2            , "refreshIptvPicons"  ))
  else:
   VVY9NT.append((item1            ,       ))
   VVY9NT.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVY9NT.append(VVXMhc)
   c1, c2 = VVDopz, VVmuI1
   t1 = FFbRJw("auto-match names", VVFaDd)
   t2 = FFbRJw("from xml file"  , VVFaDd)
   VVY9NT.append((c1 + "Count Available IPTV Channels"    , "VVBLyG"    ))
   VVY9NT.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVY9NT.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVtUbU" ))
   VVY9NT.append((VVxsyh + "More Reference Tools ..."  , "VVLgGW"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Reload Channels and Bouquets"       , "VVpNd5"   ))
  VVY9NT.append(VVXMhc)
  if not CCPWpb.VVBS71():
   VVY9NT.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVY9NT.append(("Download Manager ... No donwloads"    ,       ))
  return VVY9NT
 def VVn6j2(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVxGD4"   : self.VVxGD4()
   elif item == "VV73nJ" : FFe4rI(self, self.VV73nJ, "Change Current List References to Unique Codes ?")
   elif item == "VVVsRC_rows" : FFe4rI(self, BF(FFDKj1, self.VV5PsO, self.VVVsRC), "Change Current List References to Identical Codes ?")
   elif item == "VVF99C"   : self.VVF99C(tTitle)
   elif item == "VVIb0s"   : self.VVIb0s(tTitle)
   elif item == "VVFwk1" : self.VVjDWe(False)
   elif item == "VVjDWePortal" : self.VVjDWe(True)
   elif item == "VVOdMw_fromPlayList" : FFDKj1(self, BF(self.VVNcFT, 1), title=title)
   elif item == "VVOdMw_fromM3u"  : FFDKj1(self, BF(self.VVCJA2, CCHli4.VVbYE7), title=title)
   elif item == "VVOdMw_fromMac"  : self.VVGpWH()
   elif item == "VVOdMw_fromCurrChan" : self.VVqWnS()
   elif item == "VVxiYm"   : self.VVxiYm()
   elif item == "iptvTable_all"   : FFDKj1(self, BF(self.VVMQsW, self.VVOI62), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCHli4.VVkHjN(self)
   elif item == "refreshIptvPicons"  : self.VVY28o()
   elif item == "VVBLyG"    : FFDKj1(self, self.VVBLyG)
   elif item == "copyEpgPicons"   : self.VVs8cC(False)
   elif item == "renumIptvRef_fromFile" : self.VVs8cC(True)
   elif item == "VVtUbU" : FFe4rI(self, BF(FFDKj1, self, self.VVtUbU), VVT00f="Continue ?")
   elif item == "VVLgGW"    : self.VVLgGW()
   elif item == "VVpNd5"   : FFDKj1(self, BF(CCwvQw.VVpNd5, self))
   elif item == "dload_stat"    : CCPWpb.VVmwfS(self)
 def VVxiYm(self):
  if CCWQxC.VVTp8Y(self):
   FFDKj1(self, BF(self.VVCJA2, CCHli4.VVHLiZ), title="Searching ...")
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVn6j2(item)
 def VVMQsW(self, mode):
  VVJnaJ = self.VVKNTR(mode)
  if VVJnaJ:
   VVY2vy = ("Current Service", self.VVwymK , [])
   VVuKTt = ("Options"  , self.VVIeul   , [])
   VVNlag = ("Filter"   , self.VVnQfO   , [])
   VVNiXY  = ("Play"   , BF(self.VVvHXi)  , [])
   VVo8Jh = (""    , self.VVWOgZ    , [])
   VVKFgA = (""    , self.VVZlAo     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VV3dzh  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFXBR7(self, None, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26
     , VVNiXY=VVNiXY, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, VVo8Jh=VVo8Jh, VVKFgA=VVKFgA
     , VVU4bo="#0a00292B", VVdq78="#0a002126", VVWGqy="#0a002126", VVpoY2="#00000000", VVcNyk=True, searchCol=1)
  else:
   if mode == self.VVHrFh: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFh60c(self, err)
 def VVZlAo(self, VV5PsO, title, txt, colList):
  self.VV5PsO = VV5PsO
 def VVIeul(self, VV5PsO, title, txt, colList):
  VVY9NT = []
  VVY9NT.append(("Add Current List to a New Bouquet"    , "VVxGD4"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Change Current List References to Unique Codes" , "VV73nJ"))
  VVY9NT.append(("Change Current List References to Identical Codes", "VVVsRC_rows" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Share Reference with DVB Service (manual entry)" , "VVF99C"   ))
  VVY9NT.append(("Share Reference with DVB Service (auto-find)"  , "VVIb0s"   ))
  FFaJ04(self, self.VVn6j2, title="IPTV Tools", VVY9NT=VVY9NT)
 def VVnQfO(self, VV5PsO, title, txt, colList):
  VVY9NT = []
  VVY9NT.append(("All"         , "all"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Prefix of Selected Channel"   , "sameName" ))
  VVY9NT.append(("Suggest Words from Selected Channel" , "partName" ))
  VVY9NT.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVY9NT.append(("Duplicate References"     , "depRef"  ))
  VVY9NT.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVY9NT.append(("Stream Relay"       , "SRelay"  ))
  VVY9NT.append(FF9lRG("Category"))
  VVY9NT.append(("Live TV"        , "live"  ))
  VVY9NT.append(("VOD"         , "vod"   ))
  VVY9NT.append(("Series"        , "series"  ))
  VVY9NT.append(("Uncategorised"      , "uncat"  ))
  VVY9NT.append(FF9lRG("Media"))
  VVY9NT.append(("Video"        , "video"  ))
  VVY9NT.append(("Audio"        , "audio"  ))
  VVY9NT.append(FF9lRG("File Type"))
  VVY9NT.append(("MKV"         , "MKV"   ))
  VVY9NT.append(("MP4"         , "MP4"   ))
  VVY9NT.append(("MP3"         , "MP3"   ))
  VVY9NT.append(("AVI"         , "AVI"   ))
  VVY9NT.append(("FLV"         , "FLV"   ))
  VVY9NT.extend(CCgBRx.VVVi7P(prefix="__b__"))
  inFilterFnc = BF(self.VVC0Zm, VV5PsO) if VV5PsO.VV8zJV().startswith("IPTV Filter ") else None
  filterObj = CCxD0c(self)
  filterObj.VVc8kI(VVY9NT, VVY9NT, BF(self.VVGNSg, VV5PsO, False), inFilterFnc=inFilterFnc)
 def VVC0Zm(self, VV5PsO, menuInstance, item):
  self.VVGNSg(VV5PsO, True, item)
 def VVGNSg(self, VV5PsO, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VV5PsO.VVEOMp(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVOI62 , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVEK5R , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVuvCD , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVPVdf , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVgVWj  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVkCGx  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVHru8  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVHrFh  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVxJdA   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVwxHd  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVMGH6  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVOdCW  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVj7II  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVAtek   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVWax4   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVuN1M   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVicvm   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVd0qa   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVFf3T  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVi8Rr  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVuvCD:
   VVY9NT = []
   chName = VV5PsO.VVEOMp(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVY9NT.append((item, item))
    if not VVY9NT and chName:
     VVY9NT.append((chName, chName))
    FFaJ04(self, BF(self.VVvupc, title), title="Words from Current Selection", VVY9NT=VVY9NT)
   else:
    VV5PsO.VViaMT("Invalid Channel Name")
  else:
   words, asPrefix = CCxD0c.VVuVDQ(words)
   if not words and mode in (self.VVFf3T, self.VVi8Rr):
    FFZWPu(self.VV5PsO, "Incorrect filter", 2000)
   else:
    FFDKj1(self.VV5PsO, BF(self.VVLuTp, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVvupc(self, title, word=None):
  if word:
   words = [word.lower()]
   FFDKj1(self.VV5PsO, BF(self.VVLuTp, self.VVuvCD, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVWeG1(txt):
  return "#f#11ffff00#" + txt
 def VVLuTp(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVJnaJ = self.VVSzwg(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVJnaJ = self.VVKNTR(mode=mode, words=words, asPrefix=asPrefix)
  if VVJnaJ : self.VV5PsO.VVQNRz(VVJnaJ, title)
  else  : self.VV5PsO.VViaMT("Not found")
 def VVSzwg(self, mode=0, words=None, asPrefix=False):
  VVJnaJ = []
  for row in self.VV5PsO.VVexgG():
   row = list(map(str.strip, row))
   chNum, chName, VVEFj2, chType, refCode, url = row
   if self.VVa0yd(mode, refCode, FFhKb1(url).lower(), chName, words, VVEFj2.lower(), asPrefix):
    VVJnaJ.append(row)
  VVJnaJ = self.VVJyoc(mode, VVJnaJ)
  return VVJnaJ
 def VVKNTR(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVJnaJ = []
  files  = self.VVn1Z5()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFvr8J(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVEFj2 = span.group(1)
    else : VVEFj2 = ""
    VVEFj2_lCase = VVEFj2.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV0slf(chName): chNameMod = self.VVWeG1(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVEFj2, chType + (" SRel" if FFuuGZ(url) else ""), refCode, url)
     if self.VVa0yd(mode, refCode, FFhKb1(url).lower(), chName, words, VVEFj2_lCase, asPrefix):
      VVJnaJ.append(row)
      chNum += 1
  VVJnaJ = self.VVJyoc(mode, VVJnaJ)
  return VVJnaJ
 def VVJyoc(self, mode, VVJnaJ):
  newRows = []
  if VVJnaJ and mode == self.VVgVWj:
   counted  = iCounter(elem[4] for elem in VVJnaJ)
   for item in VVJnaJ:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVJnaJ
 def VVa0yd(self, mode, refCode, tUrl, chName, words, VVEFj2_lCase, asPrefix):
  if   mode == self.VVOI62 : return True
  elif mode == self.VVgVWj : return True
  elif mode == self.VVkCGx  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVHru8 : return FFuuGZ(tUrl)
  elif mode == self.VVOdCW  : return CCHli4.VVBGBM(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVj7II  : return CCHli4.VVBGBM(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVHrFh  : return CCHli4.VVBGBM(tUrl, compareType="live")
  elif mode == self.VVxJdA  : return CCHli4.VVBGBM(tUrl, compareType="movie")
  elif mode == self.VVwxHd : return CCHli4.VVBGBM(tUrl, compareType="series")
  elif mode == self.VVMGH6  : return CCHli4.VVBGBM(tUrl, compareType="")
  elif mode == self.VVAtek  : return CCHli4.VVBGBM(tUrl, compareExt="mkv")
  elif mode == self.VVWax4  : return CCHli4.VVBGBM(tUrl, compareExt="mp4")
  elif mode == self.VVuN1M  : return CCHli4.VVBGBM(tUrl, compareExt="mp3")
  elif mode == self.VVicvm  : return CCHli4.VVBGBM(tUrl, compareExt="avi")
  elif mode == self.VVd0qa  : return CCHli4.VVBGBM(tUrl, compareExt="flv")
  elif mode == self.VVEK5R: return chName.lower().startswith(words[0])
  elif mode == self.VVuvCD: return words[0] in chName.lower()
  elif mode == self.VVPVdf: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVFf3T : return words[0] == VVEFj2_lCase
  elif mode == self.VVi8Rr :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVxGD4(self):
  picker = CCgBRx(self, self.VV5PsO, "Add to Bouquet", self.VVmQ3P)
 def VVmQ3P(self):
  chUrlLst = []
  for row in self.VV5PsO.VVexgG():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVLgGW(self):
  c1 = VVPWV9
  t1 = FFbRJw("Bouquet", VVFaDd)
  t2 = FFbRJw("ALL", VVFaDd)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVY9NT = []
  VVY9NT.append((c1 + "Check System Acceptable Reference Types" , "VVM7YP"    ))
  if self.iptvFileAvailable:
   VVY9NT.append((c1 + "Check Reference Codes Format"  , "VVrmb2"    ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVATvc" ))
  VVY9NT.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVxAv8_all"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Change %s References to Unique Codes" % t2 , "VVxfCX"  ))
  VVY9NT.append(("Change %s References to Identical Codes" % t2 , "VVVsRC_all"  ))
  OKBtnFnc = self.VV5D8i
  FFaJ04(self, None, width=1200, title="Reference Tools", VVY9NT=VVY9NT, OKBtnFnc=OKBtnFnc)
 def VV5D8i(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVM7YP"    : FFDKj1(menuInstance, self.VVM7YP)
   elif item == "VVrmb2"     : FFDKj1(menuInstance, self.VVrmb2)
   elif item == "VVATvc" : self.VVATvc(menuInstance)
   elif item == "VVxAv8_all"  : self.VVkbTg(menuInstance, None, None)
   elif item == "VVxfCX"  : FFe4rI(self, BF(self.VVxfCX , menuInstance, txt), title=txt, VVT00f=ques)
   elif item == "VVVsRC_all"  : FFe4rI(self, BF(FFDKj1, menuInstance, self.VVVsRC), title=txt, VVT00f=ques)
 def VVkbTg(self, menuInstance, bName, bPath):
  VVY9NT = []
  for rt in CCHli4.VVZTvU():
   VVY9NT.append(("%s\t ... %s" % (rt, CCHli4.VV6LaB(rt)), rt))
  FFaJ04(self, BF(self.VVfnvA, menuInstance, bName, bPath), VVY9NT=VVY9NT, width=800, title="Change Reference Types to:")
 def VVfnvA(self, menuInstance, bName, bPath, rType=None):
  if rType:
   self.VV2UKS(menuInstance, bName, bPath, rType)
 def VVATvc(self, menuInstance):
  VVY9NT = CCgBRx.VVVi7P()
  if VVY9NT:
   FFaJ04(self, BF(self.VVwbnD, menuInstance), VVY9NT=VVY9NT, title="IPTV Bouquets", VVNDcU=True)
  else:
   FFZWPu(menuInstance, "No bouquets Found !", 1500)
 def VVwbnD(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVn6iK + span.group(1)
    if fileExists(bPath): self.VVkbTg(menuInstance, bName, bPath)
    else    : FFZWPu(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFZWPu(menuInstance, "Cannot process bouquet !", 2000)
 def VV2UKS(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFbRJw(bName, VVOpMG)
  else : title = "Change for %s" % FFbRJw("All IPTV Services", VVOpMG)
  FFe4rI(self, BF(FFDKj1, menuInstance, BF(self.VVk4lu, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFbRJw(rType, VVOpMG), title=title)
 def VVk4lu(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVn1Z5()
  if files:
   newRType = rType + ":"
   piconPath = CCZBEU.VV0FjB()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCVdBH.VVoq5s(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFh60c(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FF75pk("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FF75pk(cmd))
  self.VVFfdu(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVBLyG(self):
  totFiles = 0
  files  = self.VVn1Z5()
  if files:
   totFiles = len(files)
  totChans = 0
  VVJnaJ = self.VVKNTR()
  if VVJnaJ:
   totChans = len(VVJnaJ)
  FFHdWy(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVrmb2(self):
  files  = self.VVn1Z5()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFvr8J(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVlwDq
   else    : color = VVLO3F
   totInvalid = FFbRJw(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFbRJw("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFHdWy(self, txt, title="Check IPTV References")
 def VVM7YP(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCHli4.VVZTvU()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCgBRx.VVId9J(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVBXQD = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVBXQD:
   VVIHCe = FFrlgz(VVBXQD)
   if VVIHCe:
    for service in VVIHCe:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVn6iK + userBName
  bFile = VVn6iK + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FF75pk("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FF75pk("rm -f '%s'" % path)
  os.system(cmd)
  FFMABX()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVlwDq
    else     : res, color = "No" , VVLO3F
    pl = CCHli4.VV6LaB(item)
    txt += "    %s\t: %s%s\n" % (item, FFbRJw(res, color), FFbRJw("\t... %s" % pl, VVlhbS) if pl else "")
   FFHdWy(self, txt, title=title)
  else:
   txt = FFh60c(self, "Could not complete the test on your system!", title=title)
 def VVtUbU(self):
  VVclLC, err = CCwvQw.VVz7ZO(self, CCwvQw.VVr00s)
  if VVclLC:
   totChannels = 0
   totChange = 0
   for path in self.VVn1Z5():
    toSave = False
    txt = FFvr8J(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVclLC.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVFfdu(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFh60c(self, 'No channels in "lamedb" !')
 def VVxfCX(self, menuInstance, title):
  bFiles = self.VVn1Z5()
  if bFiles:
   self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVnmvN, bFiles)
       , VVsfO0 = BF(self.VVsIl1, title))
  else:
   FFZWPu(menuInstance, "No bouquets files !", 1500)
 def VVnmvN(self, bFiles, VVq6PE):
  VVq6PE.VVwxC6 = ""
  VVq6PE.VVryiB("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFun41(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVq6PE or VVq6PE.isCancelled:
   return
  elif not totLines:
   VVq6PE.VVwxC6 = "No IPTV Services !"
   return
  else:
   VVq6PE.VVlEfz(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVq6PE or VVq6PE.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFun41(path)
    for ndx, line in enumerate(lines):
     if not VVq6PE or VVq6PE.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVq6PE:
       VVq6PE.VVryiB("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVq6PE:
       VVq6PE.VVA8Cz(1)
      refCode, startId, startNS = CCgBRx.VVdgBU(rType, CCgBRx.VVg4kP, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVq6PE:
        VVq6PE.VVwxC6 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVsIl1(self, title, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVwxC6:
   txt += "\n\n%s\n%s" % (FFbRJw("Ended with Error:", VVLO3F), VVwxC6)
  self.VVFfdu(True, title, txt)
 def VV73nJ(self):
  bFiles = self.VVn1Z5()
  if not bFiles:
   FFZWPu(self.VV5PsO, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VV5PsO.VVexgG():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFZWPu(self.VV5PsO, "Cannot read list", 1500)
   return
  self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVm4wR, bFiles, tableRefList)
      , VVsfO0 = BF(self.VVsIl1, "Change Current List References to Unique Codes"))
 def VVm4wR(self, bFiles, tableRefList, VVq6PE):
  VVq6PE.VVwxC6 = ""
  VVq6PE.VVryiB("Reading System References ...")
  refLst = CCgBRx.VV6P9I(CCgBRx.VVg4kP, stripRType=True)
  if not VVq6PE or VVq6PE.isCancelled:
   return
  VVq6PE.VVlEfz(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVq6PE or VVq6PE.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFvr8J(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVq6PE or VVq6PE.isCancelled:
     return
    VVq6PE.VVryiB("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVq6PE or VVq6PE.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVq6PE.VVA8Cz(1)
      refCode, startId, startNS = CCgBRx.VVdgBU(rType, CCgBRx.VVg4kP, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVq6PE:
        VVq6PE.VVwxC6 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVVsRC(self):
  list = None
  if self.VV5PsO:
   list = []
   for row in self.VV5PsO.VVexgG():
    list.append(row[4] + row[5])
  files  = self.VVn1Z5()
  totChange = 0
  if files:
   for path in files:
    lines = FFun41(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVFfdu(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVFfdu(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFMABX()
   if refreshTable and self.VV5PsO:
    VVJnaJ = self.VVKNTR()
    if VVJnaJ and self.VV5PsO:
     self.VV5PsO.VVQNRz(VVJnaJ, self.tableTitle)
     self.VV5PsO.VViaMT(txt)
   FFHdWy(self, txt, title=title)
  else:
   FFNvXQ(self, "No changes.")
 def VVn1Z5(self):
  return CCHli4.VVwfQF()
 @staticmethod
 def VVwfQF(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVn6iK + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFvr8J(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVWOgZ(self, VV5PsO, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFhKb1(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFuQxT(self, fncMode=CC8xkn.VVP4Xk, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVeRzi(self, VV5PsO, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVvHXi(self, VV5PsO, title, txt, colList):
  chName, chUrl = self.VVeRzi(VV5PsO, colList)
  self.VVeFEH(VV5PsO, chName, chUrl, "localIptv")
 def VVtMBC(self, mode, VV5PsO, colList):
  chName, chUrl, picUrl, refCode = self.VVM8tE(mode, colList)
  return chName, chUrl
 def VV1YHn(self, mode, VV5PsO, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVM8tE(mode, colList)
  self.VVeFEH(VV5PsO, chName, chUrl, mode)
 def VVeFEH(self, VV5PsO, chName, chUrl, playerFlag):
  chName = FFUkF8(chName)
  if self.VV0slf(chName):
   FFZWPu(VV5PsO, "This is a marker!", 300)
  else:
   FFDKj1(VV5PsO, BF(self.VVzfpy, VV5PsO, chUrl, playerFlag), title="Playing ...")
 def VVzfpy(self, VV5PsO, chUrl, playerFlag):
  FFqoI8(self, chUrl, VVLrHC=False)
  CC0rhb.VVpY9t(self.session, iptvTableParams=(self, VV5PsO, playerFlag))
 @staticmethod
 def VV0slf(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVwymK(self, VV5PsO, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  if refCode:
   url1 = FFhKb1(origUrl.strip())
   for ndx, row in enumerate(VV5PsO.VVexgG()):
    if refCode in row[4]:
     tableRow = FFhKb1(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VV5PsO.VVyOnh(ndx)
      break
   else:
    FFZWPu(VV5PsO, "No found", 1000)
 def VVCJA2(self, m3uMode):
  lines = self.VVljn7(3)
  if lines:
   lines.sort()
   VVY9NT = []
   for line in lines:
    VVY9NT.append((line, line))
   if m3uMode == CCHli4.VVbYE7:
    title = "Browse Server from M3U URLs"
    VV8vtf = ("All to Playlist", self.VVZC9I)
   else:
    title = "M3U/M3U8 File Browser"
    VV8vtf = None
   OKBtnFnc = BF(self.VVEX9k, m3uMode, title)
   infoBtnFnc = self.VV4Zu7
   FFaJ04(self, None, title=title, VVY9NT=VVY9NT, width=1200, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="", VV8vtf=VV8vtf, VVU4bo="#11221122", VVdq78="#11221122")
 def VVEX9k(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == CCHli4.VVbYE7:
    FFDKj1(menuInstance, BF(self.VVv5UW, title, path))
   else:
    FFDKj1(menuInstance, BF(self.VVjxff, path))
 def VVjxff(self, path, m3uFilterParam=None, VV5PsO=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFvr8J(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  VVPC0A = CCcmOV()
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVnKNc(propLine, "group-title") or "-"
   if not group == "-" and VVPC0A.VVoeR0(group):
    if not chName or VVPC0A.VVpiAI(chName):
     if self.VVa0yd(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVJnaJ = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVJnaJ.append((name, str(tot), name))
    totAll += tot
   VVJnaJ.sort(key=lambda x: x[0].lower())
   VVJnaJ.insert(0, ("ALL", str(totAll), ""))
  if VVJnaJ:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VV5PsO:
    VV5PsO.VVQNRz(VVJnaJ, newTitle=title, VVbcbWMsg=True)
   else:
    VVo9Gm = self.VVSRUc
    VVNiXY  = ("Select" , BF(self.VVkYvy, path, m3uFilterParam)  , [])
    VVNlag = ("Filter" , BF(self.VVzVUZ, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VV3dzh  = (LEFT  , CENTER , LEFT )
    FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, width= 1400, height= 1000, VVfp7o=28, VVNiXY=VVNiXY, VVNlag=VVNlag, VVo9Gm=VVo9Gm, lastFindConfigObj=CFG.lastFindIptv
      , VVU4bo="#11110022", VVdq78="#11110022", VVWGqy="#11110022", VVpoY2="#00444400")
  elif VV5PsO:
   FFcw7s(VV5PsO, "Not found !", 1500)
  else:
   self.VVOaSl(FFvr8J(path), "", m3uFilterParam)
 def VVkYvy(self, path, m3uFilterParam, VV5PsO, title, txt, colList):
  self.VVOaSl(FFvr8J(path), colList[2], m3uFilterParam)
 def VVzVUZ(self, path, m3uFilterParam, VV5PsO, title, txt, colList):
  VVY9NT = []
  VVY9NT.append(("All"      , "all"  ))
  VVY9NT.append(FF9lRG("Category"))
  VVY9NT.append(("Live TV"     , "live" ))
  VVY9NT.append(("VOD"      , "vod"  ))
  VVY9NT.append(("Series"     , "series" ))
  VVY9NT.append(("Uncategorised"   , "uncat" ))
  VVY9NT.append(FF9lRG("Media"))
  VVY9NT.append(("Video"     , "video" ))
  VVY9NT.append(("Audio"     , "audio" ))
  VVY9NT.append(FF9lRG("File Type"))
  VVY9NT.append(("MKV"      , "MKV"  ))
  VVY9NT.append(("MP4"      , "MP4"  ))
  VVY9NT.append(("MP3"      , "MP3"  ))
  VVY9NT.append(("AVI"      , "AVI"  ))
  VVY9NT.append(("FLV"      , "FLV"  ))
  filterObj = CCxD0c(self, VVU4bo="#11332244", VVdq78="#11222244")
  filterObj.VVc8kI(VVY9NT, [], BF(self.VVO6qv, VV5PsO, path), inFilterFnc=None)
 def VVO6qv(self, VV5PsO, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVOI62 , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVHrFh  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVxJdA  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVwxHd  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVMGH6  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVOdCW  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVj7II  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVAtek  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVWax4  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVuN1M  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVicvm  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVd0qa  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVi8Rr  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCxD0c.VVuVDQ(words)
   if not mode == self.VVOI62:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFbRJw(fTitle, VVlhbS)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFDKj1(VV5PsO, BF(self.VVjxff, path, m3uFilterParam, VV5PsO), title="Filtering ...")
 def VVOaSl(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCRrSr, barTheme=CCRrSr.VVHTAa
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVD4PI, lst, filterGroup, m3uFilterParam)
       , VVsfO0 = BF(self.VVcjis, title, bName))
  else:
   self.VV8NB1("No valid lines found !", title)
 def VVD4PI(self, lst, filterGroup, m3uFilterParam, VVq6PE):
  VVq6PE.VVwxC6 = []
  VVq6PE.VVlEfz(len(lst))
  VVPC0A = CCcmOV()
  num = 0
  for cols in lst:
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVA8Cz(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVnKNc(propLine, "group-title") or "-"
   picon = self.VVnKNc(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VVPC0A.VVoeR0(group) : skip = True
    elif chName and not VVPC0A.VVpiAI(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVa0yd(mode, "", FFhKb1(url).lower(), chName, words, "", asPrefix)
    if not skip and VVq6PE:
     num += 1
     VVq6PE.VVwxC6.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVcjis(self, title, bName, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if VVwxC6:
   VVo9Gm = self.VVSRUc
   VVNiXY  = ("Select"   , BF(self.VVVVLc, title)   , [])
   VVo8Jh = (""    , self.VV7qES        , [])
   VVY2vy = ("Download PIcons", self.VVDsWO       , [])
   VVuKTt = ("Options"  , BF(self.VVEYM1, "m3Ch", "", bName) , [])
   VVNlag = ("Posters Mode" , BF(self.VVI27h, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV3dzh  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVwxC6, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, VVNiXY=VVNiXY, VVo9Gm=VVo9Gm, VVo8Jh=VVo8Jh, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindIptv, VVcNyk=True, searchCol=1
     , VVU4bo="#0a00192B", VVdq78="#0a00192B", VVWGqy="#0a00192B", VVpoY2="#00000000")
  else:
   self.VV8NB1("Not found !", title)
 def VVDsWO(self, VV5PsO, title, txt, colList):
  self.VVxy2C(VV5PsO, "m3u/m3u8")
 def VVe1zY(self, rowNum, url, chName):
  refCode = self.VVNyka(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFeaA3(url), chName)
  return chUrl
 def VVNyka(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVERJx(catID, stID, chNum)
  return refCode
 def VVnKNc(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVVVLc(self, Title, VV5PsO, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFDKj1(VV5PsO, BF(self.VVDlny, Title, VV5PsO, colList), title="Checking Server ...")
  else:
   self.VVFvfV(VV5PsO, url, chName)
 def VVDlny(self, title, VV5PsO, colList):
  if not CCWQxC.VVTp8Y(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCQ0t1.VVYnhy(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVY9NT = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCHli4.VVCX17(url, fPath)
     VVY9NT.append((resol, fullUrl))
    if VVY9NT:
     if len(VVY9NT) > 1:
      FFaJ04(self, BF(self.VVDLwi, VV5PsO, chName), VVY9NT=VVY9NT, title="Resolution", VVNDcU=True, VVFP3k=True)
     else:
      self.VVFvfV(VV5PsO, VVY9NT[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVFvfV(VV5PsO, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCHli4.VVCX17(url, span.group(1))
       self.VVFvfV(VV5PsO, fullUrl, chName)
      else:
       self.VVELFw("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVOaSl(txt, filterGroup="")
      return
    self.VVFvfV(VV5PsO, url, chName)
   else:
    self.VV8NB1("Cannot process this channel !", title)
  else:
   self.VV8NB1(err, title)
 def VVDLwi(self, VV5PsO, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVFvfV(VV5PsO, resolUrl, chName)
 def VVFvfV(self, VV5PsO, url, chName):
  FFDKj1(VV5PsO, BF(self.VVcCLu, VV5PsO, url, chName), title="Playing ...")
 def VVcCLu(self, VV5PsO, url, chName):
  chUrl = self.VVe1zY(VV5PsO.VV3w14(), url, chName)
  FFqoI8(self, chUrl, VVLrHC=False)
  CC0rhb.VVpY9t(self.session, iptvTableParams=(self, VV5PsO, "m3u/m3u8"))
 def VV9Afe(self, VV5PsO, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVe1zY(VV5PsO.VV3w14(), url, chName)
  return chName, chUrl
 def VV7qES(self, VV5PsO, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFuQxT(self, fncMode=CC8xkn.VVP4Xk, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VV8NB1(self, err, title):
  FFh60c(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVSRUc(self, VV5PsO):
  if self.m3uOrM3u8File:
   self.close()
  VV5PsO.cancel()
 def VVZC9I(self, VVELdAObj, item=None):
  FFDKj1(VVELdAObj, BF(self.VVv08f, VVELdAObj, item))
 def VVv08f(self, VVELdAObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVELdAObj.VVY9NT):
    path = item[1]
    if fileExists(path):
     enc = CCORAx.VV7Rit(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCHli4.VVO7TX(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCHli4.VVhmfD()
    pListF = "%sPlaylist_%s.txt" % (path, FFDaMH())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVELdAObj.VVY9NT)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFHdWy(self, txt, title=title)
   else:
    FFh60c(self, "Could not obtain URLs from this file list !", title=title)
 def VVNcFT(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVOBX6
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVaZpA
  lines = self.VVljn7(mode)
  if lines:
   lines.sort()
   VVY9NT = []
   for line in lines:
    VVY9NT.append((FFbRJw(line, VVmuI1) if "Bookmarks" in line else line, line))
   infoBtnFnc = self.VV4Zu7
   FFaJ04(self, None, title=title, VVY9NT=VVY9NT, width=1200, OKBtnFnc=okFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="")
 def VV4Zu7(self, menuInstance, txt, ref, ndx):
  txt = ref
  sz = FFtDuT(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCVdBH.VVFJRm(sz)
  FFHdWy(self, txt, title="File Path")
 def VVOBX6(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFDKj1(menuInstance, BF(self.VVwAzk, menuInstance, path), title="Processing File ...")
 def VVwAzk(self, VVULmP, path):
  enc = CCORAx.VV7Rit(path, self)
  if enc == -1:
   return
  VVJnaJ = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFd5Wt(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCHli4.VVCUqs(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVJnaJ:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVJnaJ.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVJnaJ:
   title = "Playlist File : %s" % os.path.basename(path)
   VVNiXY  = ("Start"    , BF(self.VVbc4S, "Playlist File")      , [])
   VVNxWT = ("Home Menu"   , FFcLLG             , [])
   VVY2vy = ("Download M3U File" , self.VVaJ6w         , [])
   VVuKTt = ("Edit File"   , BF(self.VVxDZR, path)        , [])
   VVNlag = ("Check & Filter"  , BF(self.VVWdqJ, VVULmP, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV3dzh  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVNxWT=VVNxWT, VVNlag=VVNlag, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVU4bo="#11001116", VVdq78="#11001116", VVWGqy="#11001116", VVpoY2="#00003635", VVUWnf="#0a333333", VVwS5R="#11331100", VVcNyk=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFh60c(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVaJ6w(self, VV5PsO, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFe4rI(self, BF(FFDKj1, VV5PsO, BF(self.VV20CY, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV20CY(self, title, url):
  path, err = FFzm7R(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFh60c(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFvr8J(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFiHj6(path)
    FFh60c(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFiHj6(path)
    FFh60c(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCHli4.VVhmfD() + fName
    os.system(FF75pk("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFNvXQ(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFh60c(self, "Could not download the M3U file!", title=errTitle)
 def VVbc4S(self, Title, VV5PsO, title, txt, colList):
  url = colList[6]
  FFDKj1(VV5PsO, BF(self.VV7FIE, Title, url), title="Checking Server ...")
 def VVxDZR(self, path, VV5PsO, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCbHA8(self, path, VVsfO0=BF(self.VV5rKh, VV5PsO), curRowNum=rowNum)
  else    : FFCpVp(self, path)
 def VV5rKh(self, VV5PsO, fileChanged):
  if fileChanged:
   VV5PsO.cancel()
 def VVF99C(self, title):
  curChName = self.VV5PsO.VVEOMp(1)
  FF5ZDh(self, BF(self.VVSy4w, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVSy4w(self, title, name):
  if name:
   VVclLC, err = CCwvQw.VVz7ZO(self, CCwvQw.VVk7oL, VVwD2U=False, VVsFr5=False)
   list = []
   if VVclLC:
    VVPC0A = CCcmOV()
    name = VVPC0A.VVoOYr(name)
    ratio = "1"
    for item in VVclLC:
     if name in item[0].lower():
      list.append((item[0], FFoB4N(item[2]), item[3], ratio))
   if list : self.VVK4VC(list, title)
   else : FFh60c(self, "Not found:\n\n%s" % name, title=title)
 def VVIb0s(self, title):
  curChName = self.VV5PsO.VVEOMp(1)
  self.session.open(CCRrSr, barTheme=CCRrSr.VVHTAa
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVfYsm
      , VVsfO0 = BF(self.VVkRG2, title, curChName))
 def VVfYsm(self, VVq6PE):
  curChName = self.VV5PsO.VVEOMp(1)
  VVclLC, err = CCwvQw.VVz7ZO(self, CCwvQw.VVHDST, VVwD2U=False, VVsFr5=False)
  if not VVclLC or not VVq6PE or VVq6PE.isCancelled:
   return
  VVq6PE.VVwxC6 = []
  VVq6PE.VVlEfz(len(VVclLC))
  VVPC0A = CCcmOV()
  curCh = VVPC0A.VVoOYr(curChName)
  for refCode in VVclLC:
   chName, sat, inDB = VVclLC.get(refCode, ("", "", 0))
   ratio = CCZBEU.VVUSiA(chName.lower(), curCh)
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVA8Cz(1, True)
   if VVq6PE and ratio > 50:
    VVq6PE.VVwxC6.append((chName, FFoB4N(sat), refCode.replace("_", ":"), str(ratio)))
 def VVkRG2(self, title, curChName, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if VVwxC6: self.VVK4VC(VVwxC6, title)
  elif VVWVbF: FFh60c(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVK4VC(self, VVJnaJ, title):
  curChName = self.VV5PsO.VVEOMp(1)
  VVJfi5 = self.VV5PsO.VVEOMp(4)
  curUrl  = self.VV5PsO.VVEOMp(5)
  VVJnaJ.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVNiXY  = ("Share Sat/C/T Ref.", BF(self.VV5VRi, title, curChName, VVJfi5, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVU4bo="#0a00112B", VVdq78="#0a001126", VVWGqy="#0a001126", VVpoY2="#00000000")
 def VV5VRi(self, newtitle, curChName, VVJfi5, curUrl, VV5PsO, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVJfi5, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFe4rI(self.VV5PsO, BF(FFDKj1, self.VV5PsO, BF(self.VVWfme, VV5PsO, data)), ques, title=newtitle, VVRAK2=True)
 def VVWfme(self, VV5PsO, data):
  VV5PsO.cancel()
  title, curChName, VVJfi5, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVJfi5 = VVJfi5.strip()
  newRefCode = newRefCode.strip()
  if not VVJfi5.endswith(":") : VVJfi5 += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVJfi5, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVJfi5 + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVn1Z5():
    txt = FFvr8J(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFMABX()
    newRow = []
    for i in range(6):
     newRow.append(self.VV5PsO.VVEOMp(i))
    newRow[4] = newRefCode
    done = self.VV5PsO.VVvHOE(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFcigO(BF(FFNvXQ , self, resTxt, title=title))
  elif resErr: FFcigO(BF(FFh60c, self, resErr, title=title))
 def VVWdqJ(self, VVULmP, path, VV5PsO, title, txt, colList):
  self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVgCP6, VV5PsO)
      , VVsfO0 = BF(self.VVuZl0, VVULmP, path, VV5PsO))
 def VVgCP6(self, VV5PsO, VVq6PE):
  VVq6PE.VVlEfz(VV5PsO.VVEYr6())
  VVq6PE.VVwxC6 = []
  for row in VV5PsO.VVexgG():
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVA8Cz(1, True)
   qUrl = self.VV2l0K(self.VV6v9H, row[6])
   txt, err = self.VVgnJH(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVCns1(item, "auth") == "0":
       VVq6PE.VVwxC6.append(qUrl)
    except:
     pass
 def VVuZl0(self, VVULmP, path, VV5PsO, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if VVWVbF:
   list = VVwxC6
   title = "Authorized Servers"
   if list:
    totChk = VV5PsO.VVEYr6()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFDaMH()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVNcFT(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFbRJw(str(totAuth), VVlwDq)
     txt += "%s\n\n%s"    %  (FFbRJw("Result File:", VVmuI1), newPath)
     FFHdWy(self, txt, title=title)
     VV5PsO.close()
     VVULmP.close()
    else:
     FFNvXQ(self, "All URLs are authorized.", title=title)
   else:
    FFh60c(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVgnJH(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVCUqs(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVBGBM(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCRrOq.VVhZIz()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVlvSy(decodedUrl):
  return CCHli4.VVBGBM(decodedUrl, justRetDotExt=True)
 def VV2l0K(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVCUqs(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV6v9H   : return "%s"            % url
  elif mode == self.VVO5De   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVvL0Y   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVVboQ  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV8zB6  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVgxDb : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVYsqd   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVkCEu    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV5y6y  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVEJJ1 : return "%s&action=get_live_streams"      % url
  elif mode == self.VV6X9Z  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVCns1(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF2gB8(int(val))
    elif is_base64 : val = FFTy1z(val)
    elif isToHHMMSS : val = FF8ZP4(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVv5UW(self, title, path):
  if fileExists(path):
   enc = CCORAx.VV7Rit(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCHli4.VVO7TX(line)
     if qUrl:
      break
   if qUrl : self.VV7FIE(title, qUrl)
   else : FFh60c(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFh60c(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVqWnS(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCHli4.VVdZu8(self)
  if qUrl or "chCode" in iptvRef:
   p = CCQ0t1()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVdlsC(iptvRef)
   if valid:
    self.VVEBS2(self, host, mac)
    return
   elif qUrl:
    FFDKj1(self, BF(self.VV7FIE, title, qUrl), title="Checking Server ...")
    return
  FFh60c(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVdZu8(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF)
  qUrl = CCHli4.VVO7TX(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVO7TX(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VV7FIE(self, title, url):
  self.curUrl = url
  self.VVOdMwData = {}
  qUrl = self.VV2l0K(self.VV6v9H, url)
  txt, err = self.VVgnJH(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVOdMwData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVOdMwData["username"    ] = self.VVCns1(item, "username"        )
    self.VVOdMwData["password"    ] = self.VVCns1(item, "password"        )
    self.VVOdMwData["message"    ] = self.VVCns1(item, "message"        )
    self.VVOdMwData["auth"     ] = self.VVCns1(item, "auth"         )
    self.VVOdMwData["status"    ] = self.VVCns1(item, "status"        )
    self.VVOdMwData["exp_date"    ] = self.VVCns1(item, "exp_date"    , isDate=True )
    self.VVOdMwData["is_trial"    ] = self.VVCns1(item, "is_trial"        )
    self.VVOdMwData["active_cons"   ] = self.VVCns1(item, "active_cons"       )
    self.VVOdMwData["created_at"   ] = self.VVCns1(item, "created_at"   , isDate=True )
    self.VVOdMwData["max_connections"  ] = self.VVCns1(item, "max_connections"      )
    self.VVOdMwData["allowed_output_formats"] = self.VVCns1(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVOdMwData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVOdMwData["url"    ] = self.VVCns1(item, "url"        )
    self.VVOdMwData["port"    ] = self.VVCns1(item, "port"        )
    self.VVOdMwData["https_port"  ] = self.VVCns1(item, "https_port"      )
    self.VVOdMwData["server_protocol" ] = self.VVCns1(item, "server_protocol"     )
    self.VVOdMwData["rtmp_port"   ] = self.VVCns1(item, "rtmp_port"       )
    self.VVOdMwData["timezone"   ] = self.VVCns1(item, "timezone"       )
    self.VVOdMwData["timestamp_now"  ] = self.VVCns1(item, "timestamp_now"  , isDate=True )
    self.VVOdMwData["time_now"   ] = self.VVCns1(item, "time_now"       )
    VVY9NT  = self.VVCuaq(True)
    OKBtnFnc = self.VVX1SY
    infoBtnFnc = self.VVCGxt
    VVtVox = ("Home Menu", FFcLLG)
    VVMxmU= ("Add to Menu", BF(CCHli4.VVu7aL, self, False, self.VVOdMwData["playListURL"]))
    VV8vtf = ("Bookmark Server", BF(CCHli4.VVJQvK, self, False, self.VVOdMwData["playListURL"]))
    FFaJ04(self, None, title="IPTV Server Resources", VVY9NT=VVY9NT, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVtVox=VVtVox, VVMxmU=VVMxmU, VV8vtf=VV8vtf)
   else:
    err = "Could not get data from server !"
  if err:
   FFh60c(self, err, title=title)
  FFZWPu(self)
 def VVX1SY(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFDKj1(menuInstance, BF(self.VVQVbe, self.VVO5De  , title=title), title=wTxt)
   elif ref == "vod"   : FFDKj1(menuInstance, BF(self.VVQVbe, self.VVvL0Y  , title=title), title=wTxt)
   elif ref == "series"  : FFDKj1(menuInstance, BF(self.VVQVbe, self.VVVboQ , title=title), title=wTxt)
   elif ref == "catchup"  : FFDKj1(menuInstance, BF(self.VVQVbe, self.VV8zB6 , title=title), title=wTxt)
   elif ref == "accountInfo" : FFDKj1(menuInstance, BF(self.VVJCUo           , title=title), title=wTxt)
 def VVCGxt(self, menuInstance, txt, ref, ndx):
  FFDKj1(menuInstance, self.VV8t0I)
 def VV8t0I(self):
  txt = self.curUrl
  if VVnusr:
   ver, err = self.VVLda5(self.VVHtgM())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVKBxA
   txt += "PHP\t: %s\n"  % self.VVLFqR
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVRkA3, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFHdWy(self, txt, title="Current Server URL")
 def VVJCUo(self, title):
  rows = []
  for key, val in self.VVOdMwData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVu8U1
   else:
    num, part = "1", self.VVC0OG
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVNxWT  = ("Home Menu", FFcLLG, [])
  VVY2vy  = None
  if VVnusr:
   VVY2vy = ("Get JS" , BF(self.VV70Aj, "/".join(self.VVOdMwData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFXBR7(self, None, title=title, width=1200, header=header, VV0wO4=rows, VVgZrM=widths, VVfp7o=26, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVU4bo="#0a00292B", VVdq78="#0a002126", VVWGqy="#0a002126", VVpoY2="#00000000", searchCol=2)
 def VVWJQS(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVPC0A = CCcmOV()
    if mode in (self.VVYsqd, self.VV6X9Z):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVCns1(item, "num"         )
      name     = self.VVCns1(item, "name"        )
      stream_id    = self.VVCns1(item, "stream_id"       )
      stream_icon    = self.VVCns1(item, "stream_icon"       )
      epg_channel_id   = self.VVCns1(item, "epg_channel_id"      )
      added     = self.VVCns1(item, "added"    , isDate=True )
      is_adult    = self.VVCns1(item, "is_adult"       )
      category_id    = self.VVCns1(item, "category_id"       )
      tv_archive    = self.VVCns1(item, "tv_archive"       )
      direct_source   = self.VVCns1(item, "direct_source"      )
      tv_archive_duration  = self.VVCns1(item, "tv_archive_duration"     )
      name = VVPC0A.VVpiAI(name, is_adult)
      if name:
       if mode == self.VVYsqd or mode == self.VV6X9Z and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVkCEu:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVCns1(item, "num"         )
      name    = self.VVCns1(item, "name"        )
      stream_id   = self.VVCns1(item, "stream_id"       )
      stream_icon   = self.VVCns1(item, "stream_icon"       )
      added    = self.VVCns1(item, "added"    , isDate=True )
      is_adult   = self.VVCns1(item, "is_adult"       )
      category_id   = self.VVCns1(item, "category_id"       )
      container_extension = self.VVCns1(item, "container_extension"     ) or "mp4"
      name = VVPC0A.VVpiAI(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VV5y6y:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVCns1(item, "num"        )
      name    = self.VVCns1(item, "name"       )
      series_id   = self.VVCns1(item, "series_id"      )
      cover    = self.VVCns1(item, "cover"       )
      genre    = self.VVCns1(item, "genre"       )
      episode_run_time = self.VVCns1(item, "episode_run_time"    )
      category_id   = self.VVCns1(item, "category_id"      )
      container_extension = self.VVCns1(item, "container_extension"    ) or "mp4"
      name = VVPC0A.VVpiAI(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVQVbe(self, mode, title):
  cList, err = self.VVTgsf(mode)
  if cList and mode == self.VV8zB6:
   cList = self.VVZSbm(cList)
  if err:
   FFh60c(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9(mode)
   mName = self.VVyhdN(mode)
   if   mode == self.VVO5De  : fMode = self.VVYsqd
   elif mode == self.VVvL0Y  : fMode = self.VVkCEu
   elif mode == self.VVVboQ : fMode = self.VV5y6y
   elif mode == self.VV8zB6 : fMode = self.VV6X9Z
   if mode == self.VV8zB6:
    VVuKTt = None
    VVNlag = None
   else:
    VVuKTt = ("Find in %s" % mName , BF(self.VV1Z8y, fMode, True) , [])
    VVNlag = ("Find in Selected" , BF(self.VV1Z8y, fMode, False) , [])
   VVNiXY   = ("Show List"   , BF(self.VVwriM, mode)  , [])
   VVNxWT  = ("Home Menu"   , FFcLLG         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFXBR7(self, None, title=title, width=1200, header=header, VV0wO4=cList, VVgZrM=widths, VVfp7o=30, VVNxWT=VVNxWT, VVuKTt=VVuKTt, VVNlag=VVNlag, VVNiXY=VVNiXY, VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVWGqy, VVpoY2=VVpoY2, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFh60c(self, "No list from server !", title=title)
  FFZWPu(self)
 def VVTgsf(self, mode):
  qUrl  = self.VV2l0K(mode, self.VVOdMwData["playListURL"])
  txt, err = self.VVgnJH(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVPC0A = CCcmOV()
    for item in tDict:
     category_id  = self.VVCns1(item, "category_id"  )
     category_name = self.VVCns1(item, "category_name" )
     parent_id  = self.VVCns1(item, "parent_id"  )
     category_name = VVPC0A.VVoeR0(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVZSbm(self, catList):
  mode  = self.VV6X9Z
  qUrl  = self.VV2l0K(mode, self.VVOdMwData["playListURL"])
  txt, err = self.VVgnJH(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVWJQS(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVwriM(self, mode, VV5PsO, title, txt, colList):
  title = colList[1]
  FFDKj1(VV5PsO, BF(self.VVLPpi, mode, VV5PsO, title, txt, colList), title="Downloading ...")
 def VVLPpi(self, mode, VV5PsO, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVyhdN(mode) + " : "+ bName
  if   mode == self.VVO5De  : mode = self.VVYsqd
  elif mode == self.VVvL0Y  : mode = self.VVkCEu
  elif mode == self.VVVboQ : mode = self.VV5y6y
  elif mode == self.VV8zB6 : mode = self.VV6X9Z
  qUrl  = self.VV2l0K(mode, self.VVOdMwData["playListURL"], catID)
  txt, err = self.VVgnJH(qUrl)
  list  = []
  if not err and mode in (self.VVYsqd, self.VVkCEu, self.VV5y6y, self.VV6X9Z):
   list, err = self.VVWJQS(mode, txt)
  if err:
   FFh60c(self, err, title=title)
  elif list:
   VVNxWT  = ("Home Menu"   , FFcLLG            , [])
   if mode in (self.VVYsqd, self.VV6X9Z):
    VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9(mode)
    VVo8Jh = (""     , BF(self.VV0gEO, mode)      , [])
    VVY2vy = ("Download Options" , BF(self.VVKOXG, mode, "", "")   , [])
    VVuKTt = ("Options"   , BF(self.VVEYM1, "lv", mode, bName)   , [])
    VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, False)     , [])
    if mode == self.VVYsqd:
     VVNiXY = ("Play"    , BF(self.VV1YHn, mode)       , [])
    else:
     VVNiXY = ("Programs"   , BF(self.VVPUF7, mode, bName) , [])
   elif mode == self.VVkCEu:
    VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9(mode)
    VVNiXY  = ("Play"    , BF(self.VV1YHn, mode)       , [])
    VVo8Jh = (""     , BF(self.VV0gEO, mode)      , [])
    VVY2vy = ("Download Options" , BF(self.VVKOXG, mode, "v", "")   , [])
    VVuKTt = ("Options"   , BF(self.VVEYM1, "v", mode, bName)   , [])
    VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, False)     , [])
   elif mode == self.VV5y6y:
    VVU4bo, VVdq78, VVWGqy, VVpoY2 = self.VVxVI9("series2")
    VVNiXY  = ("Show Seasons"  , BF(self.VVz8cB, mode)       , [])
    VVo8Jh = (""     , BF(self.VVMm7j, mode)     , [])
    VVY2vy = None
    VVuKTt = None
    VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, True)      , [])
   header, widths, VV3dzh = self.VV7WGN(mode)
   FFXBR7(self, None, title=title, header=header, VV0wO4=list, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindIptv, VVo8Jh=VVo8Jh, VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVWGqy, VVpoY2=VVpoY2, VVcNyk=True, searchCol=1)
  else:
   FFh60c(self, "No Channels found !", title=title)
  FFZWPu(self)
 def VV7WGN(self, mode):
  if mode in (self.VVYsqd, self.VV6X9Z):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VV3dzh  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVkCEu:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VV3dzh  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VV5y6y:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VV3dzh  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VV3dzh
 def VVPUF7(self, mode, bName, VV5PsO, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVOdMwData["playListURL"]
  ok_fnc  = BF(self.VVm3I2, hostUrl, chName, catId, streamId)
  FFDKj1(VV5PsO, BF(CCHli4.VV9tkY, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVm3I2(self, chUrl, chName, catId, streamId, VV5PsO, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCHli4.VVCUqs(chUrl)
   chNum = "333"
   refCode = CCHli4.VVERJx(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFqoI8(self, chUrl, VVLrHC=False)
   CC0rhb.VVpY9t(self.session)
  else:
   FFh60c(self, "Incorrect Timestamp", pTitle)
 def VVz8cB(self, mode, VV5PsO, title, txt, colList):
  title = colList[1]
  FFDKj1(VV5PsO, BF(self.VVt0YS, mode, VV5PsO, title, txt, colList), title="Downloading ...")
 def VVt0YS(self, mode, VV5PsO, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV2l0K(self.VVgxDb, self.VVOdMwData["playListURL"], series_id)
  txt, err = self.VVgnJH(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVCns1(tDict["info"], "name"   )
      category_id = self.VVCns1(tDict["info"], "category_id" )
      icon  = self.VVCns1(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVPC0A = CCcmOV()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVCns1(EP, "id"     )
        episode_num   = self.VVCns1(EP, "episode_num"   )
        epTitle    = self.VVCns1(EP, "title"     )
        container_extension = self.VVCns1(EP, "container_extension" )
        seasonNum   = self.VVCns1(EP, "season"    )
        epTitle = VVPC0A.VVpiAI(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFh60c(self, err, title=title)
  elif list:
   VVNxWT = ("Home Menu"   , FFcLLG          , [])
   VVY2vy = ("Download Options" , BF(self.VVKOXG, mode, "s", title), [])
   VVuKTt = ("Options"   , BF(self.VVEYM1, "s", mode, title) , [])
   VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, False)   , [])
   VVo8Jh = (""     , BF(self.VV0gEO, mode)    , [])
   VVNiXY  = ("Play"    , BF(self.VV1YHn, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV3dzh  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFXBR7(self, None, title=title, header=header, VV0wO4=list, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVuKTt=VVuKTt, VVNlag=VVNlag, lastFindConfigObj=CFG.lastFindIptv, VVU4bo="#0a00292B", VVdq78="#0a002126", VVWGqy="#0a002126", VVpoY2="#00000000")
  else:
   FFh60c(self, "No Channels found !", title=title)
  FFZWPu(self)
 def VV1Z8y(self, mode, isAll, VV5PsO, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVY9NT = []
  VVY9NT.append(("Keyboard"  , "manualEntry"))
  VVY9NT.append(("From Filter" , "fromFilter"))
  FFaJ04(self, BF(self.VVmZlU, VV5PsO, mode, onlyCatID), title="Input Type", VVY9NT=VVY9NT, width=400)
 def VVmZlU(self, VV5PsO, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF5ZDh(self, BF(self.VV5jGt, VV5PsO, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCxD0c(self)
    filterObj.VV4ACb(BF(self.VV5jGt, VV5PsO, mode, onlyCatID))
 def VV5jGt(self, VV5PsO, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFoBdB(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCxD0c.VVuVDQ(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFh60c(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFh60c(self, "All words must be at least 3 characters !", title=title)
        return
     VVPC0A = CCcmOV()
     if CFG.hideIptvServerAdultWords.getValue() and VVPC0A.VVpGAi(words):
      FFh60c(self, VVPC0A.VVN72B(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCRrSr, barTheme=CCRrSr.VVHTAa
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVrpyz, VV5PsO, mode, onlyCatID, title, words, toFind, asPrefix, VVPC0A)
          , VVsfO0 = BF(self.VVQL0J, mode, toFind, title))
   if not words:
    FFZWPu(VV5PsO, "Nothing to find !", 1500)
 def VVrpyz(self, VV5PsO, mode, onlyCatID, title, words, toFind, asPrefix, VVPC0A, VVq6PE):
  VVq6PE.VVlEfz(VV5PsO.VVbwlY() if onlyCatID is None else 1)
  VVq6PE.VVwxC6 = []
  for row in VV5PsO.VVexgG():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVA8Cz(1)
   VVq6PE.VVVLSv(catName)
   qUrl  = self.VV2l0K(mode, self.VVOdMwData["playListURL"], catID)
   txt, err = self.VVgnJH(qUrl)
   if not err:
    tList, err = self.VVWJQS(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVPC0A.VVpiAI(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVq6PE.VVwxC6.append(item)
 def VVQL0J(self, mode, toFind, title, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if VVwxC6:
   title = self.VVGUdI(mode, toFind)
   if mode == self.VVYsqd or mode == self.VVkCEu:
    if mode == self.VVkCEu : typ = "v"
    else          : typ = ""
    bName   = CCHli4.VVaBJI(toFind)
    VVNiXY  = ("Play"     , BF(self.VV1YHn, mode)     , [])
    VVY2vy = ("Download Options" , BF(self.VVKOXG, mode, typ, "") , [])
    VVuKTt = ("Options"   , BF(self.VVEYM1, "fnd", mode, bName), [])
    VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, False)   , [])
    VVo8Jh = (""     , BF(self.VV0gEO, mode)    , [])
   elif mode == self.VV5y6y:
    VVNiXY  = ("Show Seasons"  , BF(self.VVz8cB, mode)     , [])
    VVuKTt = None
    VVY2vy = None
    VVNlag = ("Posters Mode"  , BF(self.VVI27h, mode, True)    , [])
    VVo8Jh = (""     , BF(self.VVMm7j, mode)   , [])
   VVNxWT  = ("Home Menu"   , FFcLLG          , [])
   header, widths, VV3dzh = self.VV7WGN(mode)
   VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVwxC6, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, VVo8Jh=VVo8Jh, VVU4bo="#0a00292B", VVdq78="#0a002126", VVWGqy="#0a002126", VVpoY2="#00000000", VVcNyk=True, searchCol=1)
   if not VVWVbF:
    FFZWPu(VV5PsO, "Stopped" , 1000)
  else:
   if VVWVbF:
    FFh60c(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVM8tE(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVYsqd, self.VV6X9Z):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVkCEu:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFUkF8(chName)
  url = self.VVOdMwData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVCUqs(url)
  refCode = self.VVERJx(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV0gEO(self, mode, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VVz3LH, mode, VV5PsO, title, txt, colList))
 def VVz3LH(self, mode, VV5PsO, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVM8tE(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFuQxT(self, fncMode=CC8xkn.VVoAkz, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVMm7j(self, mode, VV5PsO, title, txt, colList):
  FFDKj1(VV5PsO, BF(self.VV4H6O, mode, VV5PsO, title, txt, colList))
 def VV4H6O(self, mode, VV5PsO, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFuQxT(self, fncMode=CC8xkn.VVoEp8, chName=name, text=txt, picUrl=Cover)
 def VVI27h(self, mode, isSerNames, VV5PsO, title, txt, colList):
  if   mode in ("itv"  , CCHli4.VVYsqd, CCHli4.VV6X9Z): category = "live"
  elif mode in ("vod"  , CCHli4.VVkCEu )          : category = "vod"
  elif mode in ("series" , CCHli4.VV5y6y)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVYsqd : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV6X9Z : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVkCEu  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV5y6y : picCol, descCol, descTxt = 5, 0, "Season"
  FFDKj1(VV5PsO, BF(self.session.open, CCjb9u, VV5PsO, category, nameCol, picCol, descCol, descTxt))
 def VVKOXG(self, mode, typ, seriesName, VV5PsO, title, txt, colList):
  VVY9NT = []
  isMulti = VV5PsO.VVSQQE
  tot  = VV5PsO.VVkjUl()
  if isMulti:
   if tot < 1:
    FFZWPu(VV5PsO, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVY9NT.append(("Download %s PIcon%s" % (name, FF10dh(tot)), "dnldPicons" ))
  if typ:
   VVY9NT.append(VVXMhc)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVY9NT.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVY9NT.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVY9NT.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCPWpb.VVBS71():
    VVY9NT.append(VVXMhc)
    VVY9NT.append(("Download Manager"      , "dload_stat" ))
  FFaJ04(self, BF(self.VVoOEI, VV5PsO, mode, typ, seriesName, colList), title="Download Options", VVY9NT=VVY9NT)
 def VVoOEI(self, VV5PsO, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVxy2C(VV5PsO, mode)
   elif item == "dnldSel"  : self.VVPUn3(VV5PsO, mode, typ, colList, True)
   elif item == "addSel"  : self.VVPUn3(VV5PsO, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVhew4(VV5PsO, mode, typ, seriesName)
   elif item == "dload_stat" : CCPWpb.VVmwfS(self)
 def VVPUn3(self, VV5PsO, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VV7gGW(mode, typ, colList)
  if startDnld:
   CCPWpb.VVtaF9(self, decodedUrl)
  else:
   self.VVWvUC(VV5PsO, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVhew4(self, VV5PsO, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VV5PsO.VVexgG():
   chName, decodedUrl = self.VV7gGW(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVWvUC(VV5PsO, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVWvUC(self, VV5PsO, title, chName, decodedUrl_list, startDnld):
  FFe4rI(self, BF(self.VVLxCx, VV5PsO, decodedUrl_list, startDnld), chName, title=title)
 def VVLxCx(self, VV5PsO, decodedUrl_list, startDnld):
  added, skipped = CCPWpb.VV4e8S(decodedUrl_list)
  FFZWPu(VV5PsO, "Added", 1000)
 def VV7gGW(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVM8tE(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVo2nq(mode, colList)
   refCode, chUrl = self.VVNcNK(self.VVKBxA, self.VVJQVO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFE7jz(chUrl)
  return chName, decodedUrl
 def VVxy2C(self, VV5PsO, mode):
  if os.system(FF75pk("which ffmpeg")) == 0:
   self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VV7FTW, VV5PsO, mode)
       , VVsfO0 = self.VVl6q0)
  else:
   FFe4rI(self, BF(CCHli4.VVGbqB, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVl6q0(self, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVwxC6["proces"], VVwxC6["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVwxC6["ok"], VVwxC6["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVwxC6["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVwxC6["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVwxC6["badURL"]
  txt += "Download Failure\t: %d\n"   % VVwxC6["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVwxC6["path"]
  if not VVWVbF  : color = "#11402000"
  elif VVwxC6["err"]: color = "#11201000"
  else     : color = None
  if VVwxC6["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVwxC6["err"], txt)
  title = "PIcons Download Result"
  if not VVWVbF:
   title += "  (cancelled)"
  FFHdWy(self, txt, title=title, VVWGqy=color)
 def VV7FTW(self, VV5PsO, mode, VVq6PE):
  isMulti = VV5PsO.VVSQQE
  if isMulti : totRows = VV5PsO.VVkjUl()
  else  : totRows = VV5PsO.VVbwlY()
  VVq6PE.VVlEfz(totRows)
  VVq6PE.VVhtuG(0)
  counter     = VVq6PE.counter
  maxValue    = VVq6PE.maxValue
  pPath     = CCZBEU.VV0FjB()
  VVq6PE.VVwxC6 = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VV5PsO.VVexgG()):
    if VVq6PE.isCancelled:
     break
    if not isMulti or VV5PsO.VVPLKO(rowNum):
     VVq6PE.VVwxC6["proces"] += 1
     VVq6PE.VVA8Cz(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVo2nq(mode, row)
      refCode = CCHli4.VVERJx(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVNyka(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVM8tE(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVq6PE.VVwxC6["attempt"] += 1
       path, err = FFzm7R(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVq6PE:
         VVq6PE.VVwxC6["ok"] += 1
         VVq6PE.VVhtuG(VVq6PE.VVwxC6["ok"])
        if FFtDuT(path) > 0:
         cmd = CC8xkn.VVBBqL(path)
         cmd += FF75pk("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVq6PE:
          VVq6PE.VVwxC6["size0"] += 1
         FFiHj6(path)
       elif err:
        if VVq6PE:
         VVq6PE.VVwxC6["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVq6PE:
          VVq6PE.VVwxC6["err"] = err.title()
         break
      else:
       if VVq6PE:
        VVq6PE.VVwxC6["exist"] += 1
     else:
      if VVq6PE:
       VVq6PE.VVwxC6["badURL"] += 1
  except:
   pass
 def VVY28o(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FF75pk("which ffmpeg")) == 0:
   self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
       , titlePrefix = ""
       , fncToRun  = self.VVwrfd
       , VVsfO0 = BF(self.VVseFE, title))
  else:
   FFe4rI(self, BF(CCHli4.VVGbqB, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVwrfd(self, VVq6PE):
  bName = CCgBRx.VVZoC3()
  pPath = CCZBEU.VV0FjB()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVq6PE.VVwxC6 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCgBRx.VVfS8X()
  if not VVq6PE or VVq6PE.isCancelled:
   return
  if not services or len(services) == 0:
   VVq6PE.VVwxC6 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVq6PE.VVlEfz(totCh)
  VVq6PE.VVhtuG(0)
  for serv in services:
   if not VVq6PE or VVq6PE.isCancelled:
    return
   VVq6PE.VVwxC6 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVq6PE.VVA8Cz(1)
   VVq6PE.VVhtuG(totPic)
   fullRef  = serv[0]
   if FFpHD4(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFE7jz(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCQ0t1.VVpjeF(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCHli4.VVBGBM(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCHli4.VVgnJH(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CC8xkn.VVofSC(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFzm7R(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVq6PE:
     VVq6PE.VVhtuG(totPic)
    if FFtDuT(path) > 0:
     cmd = CC8xkn.VVBBqL(path)
     cmd += FF75pk("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFiHj6(path)
  if VVq6PE:
   VVq6PE.VVwxC6 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVseFE(self, title, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVwxC6
  if err:
   FFh60c(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFbRJw(str(totExist)  , VVLO3F)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFbRJw(str(totNotIptv)  , VVLO3F)
    if totServErr : txt += "Server Errors\t: %s\n" % FFbRJw(str(totServErr) + t1, VVLO3F)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFbRJw(str(totParseErr) , VVLO3F)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFbRJw(str(totInvServ)  , VVLO3F)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFbRJw(str(totInvPicUrl) , VVLO3F)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFbRJw(str(totSize0)  , VVLO3F)
   if not VVWVbF:
    title += "  (stopped)"
   FFHdWy(self, txt, title=title)
 @staticmethod
 def VVGbqB(SELF):
  cmd = FFXUpj(VVzo0S, "ffmpeg")
  if cmd : FFx5HE(SELF, cmd, title="Installing FFmpeg")
  else : FFhvmT(SELF)
 @staticmethod
 def VVkHjN(SELF):
  SELF.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE
      , titlePrefix = ""
      , fncToRun  = CCHli4.VV5AeW
      , VVsfO0 = BF(CCHli4.VVCaAl, SELF))
 @staticmethod
 def VV5AeW(VVq6PE):
  bName = CCgBRx.VVZoC3()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVq6PE.VVwxC6 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCgBRx.VVfS8X()
  if not VVq6PE or VVq6PE.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVq6PE.VVlEfz(totCh)
   for serv in services:
    if not VVq6PE or VVq6PE.isCancelled:
     return
    VVq6PE.VVA8Cz(1)
    fullRef = serv[0]
    if FFpHD4(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFE7jz(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCQ0t1.VVpjeF(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCHli4.VVBGBM(m3u_Url)
     if VVq6PE:
      VVq6PE.VVuB38(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCHli4.VVVxia(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCI7Ct.VVqv7L(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVq6PE:
     VVq6PE.VVwxC6 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVq6PE.VVwxC6 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVCaAl(SELF, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVwxC6
  title = "IPTV EPG Import"
  if err:
   FFh60c(SELF, err, title=title)
  else:
   if VVWVbF and totEpgOK > 0:
    CCI7Ct.VVEUm5()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFbRJw(str(totNotIptv), VVLO3F)
    if totServErr : txt += "Server Errors\t: %s\n" % FFbRJw(str(totServErr) + t1, VVLO3F)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFbRJw(str(totInv), VVLO3F)
   if not VVWVbF:
    title += "  (stopped)"
   FFHdWy(SELF, txt, title=title)
 @staticmethod
 def VVVxia(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCHli4.VVCUqs(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCHli4.VVgnJH(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCHli4.VVCns1(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCHli4.VVCns1(item, "lang"        ).upper()
    now_playing   = CCHli4.VVCns1(item, "now_playing"      )
    start    = CCHli4.VVCns1(item, "start"        )
    start_timestamp  = CCHli4.VVCns1(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCHli4.VVCns1(item, "start_timestamp"     )
    stop_timestamp  = CCHli4.VVCns1(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCHli4.VVCns1(item, "stop_timestamp"      )
    tTitle    = CCHli4.VVCns1(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVERJx(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCHli4.VVLNoJ(catID, MAX_4b)
  TSID = CCHli4.VVLNoJ(chNum, MAX_4b)
  ONID = CCHli4.VVLNoJ(chNum, MAX_4b)
  NS  = CCHli4.VVLNoJ(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVLNoJ(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVaBJI(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVxVI9(mode):
  if   mode in ("itv"  , CCHli4.VVO5De)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCHli4.VVvL0Y)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCHli4.VVVboQ) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCHli4.VV8zB6) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCHli4.VV6X9Z    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVljn7(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVgLsZ:
   excl = FFNjJC(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFh60c(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFLYXX('find %s %s %s' % (path, excl, par))
  if files:
   err = CCVdBH.VVTfqS(files)
   if err : FFh60c(self, err + FFbRJw('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVmuI1))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFh60c(self, err)
  return []
 @staticmethod
 def VVhmfD():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFd5Wt(path)
  return "/"
 @staticmethod
 def VV9tkY(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCHli4.VVVxia(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFh60c(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVU4bo, VVdq78, VVWGqy, VVpoY2 = CCHli4.VVxVI9("")
   VVNxWT = ("Home Menu" , FFcLLG, [])
   VVNiXY  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV3dzh  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFXBR7(SELF, None, title="Programs for : " + chName, header=header, VV0wO4=pList, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=24, VVNiXY=VVNiXY, VVNxWT=VVNxWT, VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVWGqy, VVpoY2=VVpoY2)
  else:
   FFh60c(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVCX17(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVu7aL(self, isPortal, line, VVELdAObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFe4rI(self, BF(self.VV08sL, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFoBdB(confItem, line)
   FFNvXQ(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV08sL(self, title, confItem):
  FFoBdB(confItem, "")
  FFNvXQ(self, "Removed from IPTV Menu.", title=title)
 def VVjDWe(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVEBS2(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFDKj1(self, BF(self.VV7FIE, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFh60c(self, "Incorrect server data !")
 @staticmethod
 def VVJQvK(SELF, isPortal, line, VVELdAObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCHli4.VVhmfD()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFh60c(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFNvXQ(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFh60c(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVEYM1(self, source, mode, curBName, VV5PsO, title, txt, colList):
  isMulti = VV5PsO.VVSQQE
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VV5PsO.VVkjUl()
   totTxt = "%d Service%s" % (tot, FF10dh(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFbRJw(totTxt, VVmuI1)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCkpOx(self, VV5PsO, addSep=False)
  thTxt = "Adding Services ..."
  VVY9NT, cbFncDict = [], None
  VVY9NT.append(VVXMhc)
  if itemsOK:
   VVY9NT.append(("Add %s to New Bouquet : %s"    % (totTxt, FFbRJw(curBName , VVlwDq)), "addToCur1"))
   if curBName2: VVY9NT.append(("Add %s to New Bouquet : %s" % (totTxt, FFbRJw(curBName2, VV619a)) , "addToCur2"))
   VVY9NT.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFDKj1, mSel.VV5PsO, BF(self.VVxAL0,source, mode, curBName , VV5PsO, title), title=thTxt)
      , "addToCur2": BF(FFDKj1, mSel.VV5PsO, BF(self.VVxAL0,source, mode, curBName2, VV5PsO, title), title=thTxt)
      , "addToNew" : BF(self.VVK4NT, source, mode, curBName, VV5PsO, title)
      }
  else:
   VVY9NT.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVUhFW(VVY9NT, cbFncDict, width=1200)
 def VVxAL0(self, source, mode, curBName, VV5PsO, Title):
  chUrlLst = self.VVybvn(source, mode, VV5PsO)
  CCgBRx.VVId9J(self, Title, curBName, "", chUrlLst)
 def VVK4NT(self, source, mode, curBName, VV5PsO, Title):
  picker = CCgBRx(self, VV5PsO, Title, BF(self.VVybvn, source, mode, VV5PsO), defBName=curBName)
 def VVybvn(self, source, mode, VV5PsO):
  totChange = 0
  isMulti = VV5PsO.VVSQQE
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VV5PsO.VVexgG()):
   if not isMulti or VV5PsO.VVPLKO(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVo2nq(mode, row)
     refCode, chUrl = self.VVNcNK(self.VVKBxA, self.VVJQVO, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVe1zY(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVM8tE(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVzCFp():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVZTvU():
  return sorted(tuple(CCHli4.VVzCFp()))
 @staticmethod
 def VV6LaB(rt):
  return CCHli4.VVzCFp().get(str(rt), "")
 @staticmethod
 def VV3EYE(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCHli4.VV6LaB(span.group(1)) if span else ""
 @staticmethod
 def VVAMy8(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVtiEZ():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVY9NT = []
  for ndx, rt in enumerate(CCHli4.VVZTvU()):
   txt = "%s\t... %s" % ((VVPWV9 if rt == defRt else "") + CCHli4.VV6LaB(rt), rt)
   if CCHli4.VVAMy8(rt): VVY9NT.append((txt, rt))
   else       : VVY9NT.append((txt, ))
   if ndx < 4 and ndx % 2: VVY9NT.append(VVXMhc)
  return VVY9NT
class CCHNjG(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVeaZu(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFRkaP(self.frm, frmColor)
  FFRkaP(self.bak, bakColor)
  FFRkaP(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VV5ehE(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFo5AX(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCZNEG(CCHNjG):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCHNjG.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VV4Qja()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VVS2uh   ,
   "down" : self.VV4dKD  ,
   "left" : self.VVBeVJ  ,
   "right" : self.VVk9Xp  ,
   "next" : self.VVlyUD ,
   "last" : self.VV5z7c
  }, -1)
 def VVArb1(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVeaZu(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVG3WE()
 def VVPUqI(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVS2uh(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVr3FZ()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV2XPD()
 def VV4dKD(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV70gr()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV2XPD()
 def VVBeVJ(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVr3FZ()
  else:
   self.curCol -= 1
   self.VV2XPD()
 def VVk9Xp(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV70gr()
  else:
   self.curCol += 1
   self.VV2XPD()
 def VV5z7c(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV2XPD(oldPage != self.curPage)
 def VVlyUD(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV2XPD(oldPage != self.curPage)
 def VV70gr(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV2XPD(force)
 def VVr3FZ(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV2XPD(force)
 def VV2XPD(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVALlf = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVALlf: self.curPage = VVALlf
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVGyRD()
  self["myPiconPtr"].hide()
  self.VV5ehE(self.curPage + 1, self.totalPages)
  FFcigO(BF(self.VV1XjX, force or not oldPage == self.curPage, VVALlf))
 def VV1XjX(self, force, VVALlf):
  try:
   if force:
    self.VV8QKT()
   if self.curPage == VVALlf:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVGyRD()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
   self["myPiconPtr"].show()
  except:
   pass
  self["myPiconPtr"].show()
 def VVwq7z(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV2XPD(False if oldPage == self.curPage else True)
  else:
   FFZWPu(self, "Not found", 1000)
 def VVaZTg(self):
  self.VVwq7z(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVclfN(self):
  self["myPiconPtr"].hide()
 def VV4Qja(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVF7B7(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVfqcw, CCYdfZ, defFG=fg, defBG=bg, onlyBG=True)
 def VVfqcw(self, fg, bg):
  if self.colorCfg and bg:
   FFoBdB(self.colorCfg, bg)
   self.VVG3WE()
 def VVG3WE(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFRkaP(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VV3HyM(self, lbl, txt, color=""):
  CCZNEG.VVWZsX(lbl, txt, color)
 @staticmethod
 def VVWZsX(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVKFKt(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCjb9u(Screen, CCZNEG):
 def __init__(self, session, VV5PsO, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFWDRO(VVPeyn, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VV5PsO  = VV5PsO
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VV0wO4    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFsd9n(self, self.Title)
  CCZNEG.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVPUYO, subPath)
  if not pathExists(self.pPath):
   os.system(FF75pk("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVz6TU    ,
   "cancel": self.close    ,
   "menu" : self.VVfiTX ,
   "info" : self.VV4gN0  ,
   "0"  : self.VVaZTg
  })
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  FF4AQy(self)
  self.VVArb1()
  self.VVUZ9N()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVfiTX(self):
  chName, subj, desc, fName, picUrl = self.VV0wO4[self.curIndex]
  VVY9NT = []
  txt1 = "Show Selected Picture"
  txt2 = "Copy Selected Picture to Export-Directory"
  txt3 = "Set Selected Picture as a Poster for a Local Media"
  if fName:
   VVY9NT.append((txt1, "VVIHXz"   ))
   VVY9NT.append((txt2, "VVS3Dj"  ))
   VVY9NT.append((txt3, "VVXaof" ))
  else:
   VVY9NT.append((txt1, ))
   VVY9NT.append((txt2, ))
   VVY9NT.append((txt3, ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Cache details"       , "VV1log"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Change Poster/Picon Transparency Color" , "VVF7B7" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Help (Keys)"        , "help"     ))
  FFaJ04(self, self.VVmVIR, title=self.Title, VVY9NT=VVY9NT)
 def VVmVIR(self, item=None):
  if item is not None:
   if   item == "VVIHXz"   : self.VVIHXz()
   elif item == "VVS3Dj"   : self.VVS3Dj()
   elif item == "VVXaof"  : self.VVXaof()
   elif item == "VV1log"  : FFDKj1(self, self.VV1log, title="Calculating ...")
   elif item == "VVF7B7": self.VVF7B7()
   elif item == "help"     : FFv9kY(self, "_help_servBr", "Server Browser (Keys)")
 def VVz6TU(self):
  self.VV5PsO.VVyOnh(self.curIndex)
  self.VV5PsO.VV5JVt()
 def VV4gN0(self):
  self.VV5PsO.VVyOnh(self.curIndex)
  self.VV5PsO.VVTXjl()
 def VVUZ9N(self):
  for colList in self.VV5PsO.VVexgG():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VV0wO4.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VV0wO4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VV5PsO.VV3w14()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VV2XPD(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV0bvs)
  except:
   self.timer.callback.append(self.VV0bvs)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV4aYs)
  self.myThread.start()
 def VV4aYs(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VV0wO4):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFzm7R(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FF75pk("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VV0wO4[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VV0bvs(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVzF5b + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VV0wO4[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VV0wO4[ndx] = (chName, subj, desc, fName, "")
     CCZNEG.VVKFKt(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV8QKT(self):
  self.VV4Qja()
  f1, f2 = self.VVPUqI()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VV0wO4[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV3HyM(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVE5ib + "iptv.png"
   CCZNEG.VVKFKt(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVGyRD(self):
  chName, subj, desc, fName, picUrl = self.VV0wO4[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVIHXz(self):
  chName, subj, desc, fName, picUrl = self.VV0wO4[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCG5Yr.VV12Wn(self, self.pPath + fName)
  else          : FFZWPu(self, "File not found", 1500)
 def VVS3Dj(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VV0wO4[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FF75pk("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FFNvXQ(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFh60c(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFh60c(self, "No Poster/PIcon found", title=title)
 def VVXaof(self):
  self.session.openWithCallback(self.VV2S0G, BF(CCVdBH, patternMode="movies", VVWic9=CFG.MovieDownloadPath.getValue()))
 def VV2S0G(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VV0wO4[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    res = os.system(FF75pk("cp -f '%s' '%s'" % (srcF, dstF)))
    if res == 0 : FFNvXQ(self, "File copied to:\n\n%s" % dstF, title=title)
    else  : FFh60c(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCGed9.VVYpTw(dstF)
   else:
    FFh60c(self, "No Poster/PIcon found", title=title)
 def VV1log(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVPUYO, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFA2wB("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCVdBH.VVFJRm(size)
   txt += "%s\n    %s\n\n" % (FFbRJw(path, VVmuI1), size)
  mainPath = "%sPosters" % VVPUYO
  totFiles = FFA2wB("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FF10dh(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFbRJw("Total space used by Posters/PIcons%s:" % totFTxt, VVOpMG), CCVdBH.VVFJRm(totSize))
  mountPath = CCVdBH.VVBH9G(mainPath)
  if pathExists(mountPath):
   totSize  = CCVdBH.VVFQUX(mountPath)
   freeSize = CCVdBH.VVnPRW(mountPath)
   usedSize = CCVdBH.VVFJRm(totSize - freeSize)
   totSize  = CCVdBH.VVFJRm(totSize)
   freeSize = CCVdBH.VVFJRm(freeSize)
   txt += "%s\n" % VVwtEz
   txt += FFbRJw("Media Space:\n", VVFaDd)
   txt += "    Media Path\t: %s\n" % FFbRJw(mountPath, VVDopz)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFHdWy(self, txt, title="Cache Used Size", height=1000)
class CCGed9(Screen, CCZNEG):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFWDRO(VVDOHw, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VV0wO4    = lst
  FFsd9n(self, self.Title)
  CCZNEG.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVz6TU    ,
   "cancel": self.close    ,
   "menu" : self.VVk2lS ,
   "info" : self.VVZw3X  ,
   "0"  : self.VVaZTg
  })
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  FF4AQy(self)
  self.VVArb1()
  self.totalItems = len(self.VV0wO4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV2XPD(True)
 def VV8QKT(self):
  self.VV4Qja()
  f1, f2 = self.VVPUqI()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VV0wO4[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVE5ib + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV3HyM(lbl, os.path.splitext(os.path.basename(path))[0])
   CCZNEG.VVKFKt(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVzZ82(self):
  path, movie, poster = self.VV0wO4[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVGyRD(self):
  path, poster = self.VVzZ82()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVk2lS(self):
  path, poster = self.VVzZ82()
  VVY9NT = []
  VVY9NT.append(("Go to movie ...", "VVB0rn"))
  VVY9NT.append(VVXMhc)
  txt1 = "Show Poster"
  txt2 = "Copy Poster to Export-Directory"
  if poster:
   VVY9NT.append((txt1, "VVIHXz" ))
   VVY9NT.append((txt2, "VVS3Dj"))
  else:
   VVY9NT.append((txt1, ))
   VVY9NT.append((txt2, ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Change Poster/Picon Transparency Color"  , "VVF7B7" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Change Poster (from current movie path) ..." , "VVRnbO1"  ))
  VVY9NT.append(("Change Poster (locate manually) ..."   , "VVRnbO2"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Help (Keys)"         , "help"     ))
  FFaJ04(self, self.VVtuK1, title=self.Title, VVY9NT=VVY9NT)
 def VVtuK1(self, item=None):
  if item is not None:
   if   item == "VVB0rn"    : self.VVB0rn()
   elif item == "VVS3Dj"    : self.VVS3Dj()
   elif item == "VVIHXz"    : self.VVIHXz()
   elif item == "VVF7B7" : self.VVF7B7()
   elif item == "VVRnbO1"  : self.VVRnbO()
   elif item == "VVRnbO2"  : self.VVRnbO(True)
   elif item == "help"      : FFv9kY(self, "_help_movBr", "Movies Browser (Keys)")
 def VVB0rn(self):
  VVJnaJ = []
  for ndx, item in enumerate(self.VV0wO4):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVJnaJ.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVJnaJ.sort(key=lambda x: x[0].lower())
  VVNiXY = ("Select" , self.VV3UgB, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFXBR7(self, None, title="Select Movie", width=1800, height=1000, header=header, VV0wO4=VVJnaJ, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, lastFindConfigObj=CFG.lastFindMovie)
 def VV3UgB(self, VV5PsO, title, txt, colList):
  self.VVwq7z(int(colList[2].strip()))
  VV5PsO.cancel()
 def VVz6TU(self):
  path, poster = self.VVzZ82()
  FFDKj1(self, BF(CCVdBH.VVe3wa, self, path), title="Playing Media ...")
 def VVZw3X(self):
  path, poster = self.VVzZ82()
  txt = "%s:\n%s\n\n" % (FFbRJw("Path", VVmuI1), path)
  size = FFtDuT(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFbRJw("File Size", VVmuI1), CCVdBH.VVFJRm(size))
  if poster:
   txt += "%s:\n%s" % (FFbRJw("Poster", VVmuI1), poster)
  FFHdWy(self, txt, title="Media File Information")
 def VVIHXz(self):
  path, poster = self.VVzZ82()
  if fileExists(poster): CCG5Yr.VV12Wn(self, poster)
  else     : FFZWPu(self, "No Poster", 1500)
 def VVS3Dj(self):
  title = "Copy Poster"
  path, poster = self.VVzZ82()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   res = os.system(FF75pk("cp -f '%s' '%s'" % (poster, dstF)))
   if res == 0 : FFNvXQ(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFh60c(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFZWPu(self, "No Poster", 1500)
 def VVRnbO(self, isManual=False):
  path, poster = self.VVzZ82()
  sDir = FFd5Wt(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVCgf1, sDir, path), BF(CCVdBH, patternMode="poster", VVWic9=sDir))
  else:
   VVY9NT = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVY9NT.append((os.path.basename(item), sDir + item))
   if VVY9NT:
    VVY9NT.sort(key=lambda x: x[0].lower())
    infoBtnFnc = self.VVvg7n
    FFaJ04(self, BF(self.VVCgf1, sDir, path), VVY9NT=VVY9NT, title="Posters", infoBtnFnc=infoBtnFnc, yellowBasePath=sDir)
   else:
    FFZWPu(self, "No jpg/png in current dir", 1500)
 def VVvg7n(self, menuInstance, txt, ref, ndx):
  CCG5Yr.VV12Wn(self, VVPYo2=ref)
 def VVCgf1(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   res = os.system(FF75pk("cp -f '%s' '%s'" % (pPath, newPath)))
   if res == 0 or pPath == newPath:
    self.VV0wO4[self.curIndex] = (self.VV0wO4[self.curIndex][0], self.VV0wO4[self.curIndex][1], os.path.basename(newPath))
    FFDKj1(self, self.VV8QKT)
    CCGed9.VVYpTw(newPath)
   else:
    FFZWPu(self, "Cannot copy file", 1000)
 @staticmethod
 def VVYpTw(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    os.system(FF75pk("mv -f '%s' '%s'" % (jpgF, newF)))
 @staticmethod
 def VVicEA(SELF):
  eLst = CCRrOq.VVhZIz()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCGed9, title, lst)
  else  : FFh60c(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CC3Ob2(Screen, CCZNEG):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFWDRO(VVppbz, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VV0wO4    = lst
  self.pPath    = CCZBEU.VV0FjB()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFsd9n(self, self.Title)
  FFKpuS(self["keyRed"] , "OK = Zap (Review)")
  FFKpuS(self["keyGreen"] , "Zap & Exit")
  FFKpuS(self["keyYellow"], "Find Current Service")
  CCZNEG.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVmbhK, False),
   "cancel" : self.VVNdWb      ,
   "menu"  : self.VVCs1s   ,
   "red"  : self.VVNdWb      ,
   "green"  : BF(self.VVmbhK, True) ,
   "yellow" : BF(self.VVBoTi, True)  ,
   "0"   : self.VVaZTg
  })
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFnx82(self)
   FF4AQy(self)
   FFRkaP(self["keyRed"], "#0a333333")
   self.VVArb1()
  else:
   pName, srvLst = CC3Ob2.VVR6Ef()
   if srvLst and not srvLst == self.VV0wO4:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VV0wO4 = srvLst
   else:
    force = False
  self.totalItems = len(self.VV0wO4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV2XPD(force)
  self.VVBoTi()
 def VVCs1s(self):
  VVY9NT = []
  VVY9NT.append(("Find Name (sorted list)"   , "findSrt"  ))
  VVY9NT.append(("Find Name (as listed)"   , "findNoSrt"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Change Background Color"   , "VVF7B7"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Help (Keys)", "help"))
  FFaJ04(self, self.VVkIjk, title="Options", VVY9NT=VVY9NT)
 def VVkIjk(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVDPz4(True)
   elif item == "findNoSrt"   : self.VVDPz4(False)
   elif item == "VVF7B7": self.VVF7B7()
   elif item == "help"     : FFv9kY(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVDPz4(self, isSort):
  VVY9NT = []
  for ndx, item in enumerate(self.VV0wO4):
   VVY9NT.append((item[1], ndx))
  if isSort:
   VVY9NT.sort(key=lambda x: x[0].lower())
  FFaJ04(self, self.VVTYdZ, title="Find Name", VVY9NT=VVY9NT, width=1300)
 def VVTYdZ(self, ndx=None):
  if ndx is not None:
   self.VVwq7z(ndx)
 def VVNdWb(self):
  if self.shown: self.close()
  else   : self.show()
 def VVmbhK(self, isExit):
  FFDKj1(self, BF(self.VVE7y2, isExit), title="Starting ...")
 def VVE7y2(self, isExit):
  try:
   if self.shown:
    FFqoI8(self, self.VV0wO4[self.curIndex][0], VVLrHC=False)
    if isExit: self.close()
    else  : CC0rhb.VVpY9t(self.session)
   else:
    self.show()
  except:
   pass
 def VVBoTi(self, VVyRz1=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VV0wO4):
    if curRef == item[0]:
     self.VVwq7z(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVyRz1 and err:
   FFZWPu(self, err, 500)
  return -1
 def VV8QKT(self):
  self.VV4Qja()
  f1, f2 = self.VVPUqI()
  row = col = 0
  noPos = VVE5ib + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VV0wO4[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV3HyM(lbl, name)
   path = CCZBEU.VVXn2v(self.pPath, ref, name) or noPos
   CCZNEG.VVKFKt(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVGyRD(self):
  ref, name = self.VV0wO4[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVVH1m():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVXVyg = InfoBar.instance
  if VVXVyg:
   csel = VVXVyg.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFiUHq(rootRef)
    refName  = FFiUHq(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVR6Ef(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CC3Ob2.VVVH1m()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFrlgz(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCgBRx.VVfS8X()
   pName  = CCgBRx.VVZoC3() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VV1I99(SELF):
  pName, srvLst = CC3Ob2.VVR6Ef()
  if srvLst: SELF.session.open(CC3Ob2, pName, srvLst)
  else  : FFh60c(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCFx66(Screen, CCZNEG):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFWDRO(VVoarh, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VV0wO4    = CCFx66.VVAVC9(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFsd9n(self, self.Title)
  FFKpuS(self["keyRed"] , "OK = Start Plugin")
  FFKpuS(self["keyYellow"], "Package Info.")
  FFKpuS(self["keyBlue"] , "Plugins Group")
  CCZNEG.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVRURq   ,
   "cancel" : self.VVNdWb    ,
   "menu"  : self.VVUevY ,
   "info"  : self.VVCxQI  ,
   "red"  : self.VVNdWb    ,
   "yellow" : BF(FFDKj1, self, self.VVv3J2),
   "blue"  : self.VVxzUk  ,
   "0"   : self.VVaZTg
  })
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  FF4AQy(self)
  FFRkaP(self["keyRed"], "#0a333333")
  self.VVArb1()
  self.totalItems = len(self.VV0wO4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV2XPD(True)
 def VVNdWb(self):
  self.close()
 def VVRURq(self):
  name, desc = self.VVyuZt(self.curIndex)
  if name == PLUGIN_NAME:
   FFZWPu(self, "Already running.", 500)
  else:
   try:
    p = self.VV0wO4[self.curIndex]
    p(session=self.session)
   except:
    FFh60c(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVCxQI(self):
  def VVg0pA(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VV0wO4[self.curIndex]
  txt = ""
  try:
   txt += VVg0pA("Path"  , p.path  )
   txt += VVg0pA("Description" , p.description )
   txt += VVg0pA("Icon"  , p.iconstr  )
   txt += VVg0pA("Wakeup Fnc" , p.wakeupfnc )
   txt += VVg0pA("NeedsRestart", p.needsRestart)
   txt += VVg0pA("Internal" , p.internal )
   txt += VVg0pA("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVyuZt(self.curIndex)
  if txt : FFHdWy(self, txt, title=name)
  else : FFh60c(self, "Could not read plugin info.", title=name)
 def VVv3J2(self):
  p = self.VV0wO4[self.curIndex]
  name, desc = self.VVyuZt(self.curIndex)
  path = p.path
  pkg, err = CCHlgZ.VVKB7l(path)
  if pkg : CCHlgZ.VVdFcI(self, pkg, name)
  else : FFcw7s(self, err, 1000)
 def VVUevY(self):
  path = self.VV0wO4[self.curIndex].path
  VVY9NT = []
  txt = "Open Plugin Path in File Manager"
  if pathExists(path) : VVY9NT.append((txt, "inFileMan"))
  else    : VVY9NT.append((txt, ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Use Original Icon Size", "setOrigSize"))
  FFaJ04(self, self.VVKFpt, title="Plugins Group", VVY9NT=VVY9NT)
 def VVKFpt(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCVdBH, mode=CCVdBH.VVH3fb, VVWic9=self.VV0wO4[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VV2XPD(True)
 def VVxzUk(self):
  FFaJ04(self, self.VViQyQ, title="Plugins Group", VVY9NT=CCFx66.VVTUKA(True, True), width=700, VVNDcU=True)
 def VViQyQ(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCFx66.VVZtJt(where)
   if lst:
    self.VV0wO4 = CCFx66.VVAVC9(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VV0wO4)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VV2XPD(True)
   else:
    FFh60c(self, "Not found !", title=self.Title)
 def VV8QKT(self):
  self.VV4Qja()
  f1, f2 = self.VVPUqI()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVyuZt(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV3HyM(lbl, name)
   iconOk = False
   pngSz = None
   if self.VV0wO4[ndx].icon:
    try:
     pngSz = self.VV0wO4[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VV0wO4[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VV0wO4[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVE5ib + "plugin.png")
    for path in icons:
     pixMap = CCZNEG.VVKFKt(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVyuZt(self, ndx):
  name = str(self.VV0wO4[ndx].name).strip()
  desc = str(self.VV0wO4[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFjufa(self.VV0wO4[ndx].path)
  return name, desc
 def VVGyRD(self):
  name, desc = self.VVyuZt(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVTUKA(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCFx66.VVZtJt(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVlhbS, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVXMhc)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVZtJt(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVAVC9(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFjufa(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VV1I99(SELF):
  title = "Plugins Browser"
  lst = CCFx66.VVZtJt(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCFx66, title, lst)
  else : FFh60c(SELF, "No plugins found !", title=title)
class CCAmZo(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFWDRO(VVG5k0, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVw2L8  = 0
  self.VVEPCJ = 1
  self.VVIgxX  = 2
  VVY9NT = []
  VVY9NT.append(("Find in All Service (from filter)" , "VVYClM" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Find in All (Manual Entry)"   , "VVB6Ld"    ))
  VVY9NT.append(("Find in TV"       , "VVpj6P"    ))
  VVY9NT.append(("Find in Radio"      , "VVjQFH"   ))
  if self.VVDgkK():
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Hide Channel: %s" % self.servName , "VVwbd7"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Zap History"       , "VVgy6R"    ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("IPTV Tools"       , "iptv"      ))
  VVY9NT.append(("PIcons Tools"       , "PIconsTools"     ))
  VVY9NT.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVY9NT.append(("EPG Tools"       , "epgTools"     ))
  FFsd9n(self, VVY9NT=VVY9NT, title=title)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self)
  if self.isFindMode:
   self.VVn73r(self.VVkMEM())
 def VVz6TU(self):
  global VVLN9R
  VVLN9R = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVB6Ld"    : self.VVB6Ld()
   elif item == "VVYClM" : self.VVYClM()
   elif item == "VVpj6P"    : self.VVpj6P()
   elif item == "VVjQFH"   : self.VVjQFH()
   elif item == "VVwbd7"   : self.VVwbd7()
   elif item == "VVgy6R"    : self.VVgy6R()
   elif item == "iptv"       : self.session.open(CCHli4)
   elif item == "PIconsTools"     : self.session.open(CCZBEU)
   elif item == "ChannelsTools"    : self.session.open(CCwvQw)
   elif item == "epgTools"      : self.session.open(CCI7Ct)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVpj6P(self) : self.VVn73r(self.VVw2L8)
 def VVjQFH(self) : self.VVn73r(self.VVEPCJ)
 def VVB6Ld(self) : self.VVn73r(self.VVIgxX)
 def VVn73r(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF5ZDh(self, BF(self.VVYsXr, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVYClM(self):
  filterObj = CCxD0c(self)
  filterObj.VV4ACb(self.VVG6xk)
 def VVG6xk(self, item):
  self.VVYsXr(self.VVIgxX, item)
 def VVDgkK(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFpHD4(self.refCode)        : return False
  return True
 def VVYsXr(self, mode, VV3W2M):
  FFDKj1(self, BF(self.VVytgt, mode, VV3W2M), title="Searching ...")
 def VVytgt(self, mode, VV3W2M):
  if VV3W2M:
   VV3W2M = VV3W2M.strip()
  if VV3W2M:
   self.findTxt = VV3W2M
   CFG.lastFindContextFind.setValue(VV3W2M)
   if   mode == self.VVw2L8  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVEPCJ : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV3W2M)
   if len(title) > 55:
    title = title[:55] + ".."
   VVJnaJ = self.VVma9t(VV3W2M, servTypes)
   if self.isFindMode or mode == self.VVIgxX:
    VVJnaJ += self.VVG80d(VV3W2M)
   if VVJnaJ:
    VVJnaJ.sort(key=lambda x: x[0].lower())
    VVo9Gm = self.VVgbwL
    VVNiXY  = ("Zap"   , self.VV37EN    , [])
    VVY2vy = ("Current Service", self.VVAmPl , [])
    VVuKTt = ("Options"  , self.VVUTWm , [])
    VVo8Jh = (""    , self.VVRVTK , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV3dzh  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo9Gm=VVo9Gm, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVo8Jh=VVo8Jh, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVn73r(self.VVkMEM())
    FFNvXQ(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVma9t(self, VV3W2M, servTypes):
  VV0wO4 = CCwvQw.VVmiFv(servTypes)
  VVJnaJ = []
  if VV0wO4:
   VVcAst, VVF6pL = FFtgvA()
   tp = CCsRkT()
   words, asPrefix = CCxD0c.VVuVDQ(VV3W2M)
   colorYellow  = CCwVjJ.VVkM5Z(VVOpMG)
   colorWhite  = CCwVjJ.VVkM5Z(VVViAb)
   for s in VV0wO4:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FF8b2s(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVcAst:
        STYPE = VVF6pL[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVW1mB(refCode)
       if not "-S" in syst:
        sat = syst
       VVJnaJ.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVJnaJ
 def VVG80d(self, VV3W2M):
  VV3W2M = VV3W2M.lower()
  VVJnaJ = []
  colorYellow  = CCwVjJ.VVkM5Z(VVOpMG)
  colorWhite  = CCwVjJ.VVkM5Z(VVViAb)
  for b in CCgBRx.VVid2G():
   VVEFj2  = b[0]
   VVhdlg  = b[1].toString()
   VVBXQD = eServiceReference(VVhdlg)
   VVIHCe = FFrlgz(VVBXQD)
   for service in VVIHCe:
    refCode  = service[0]
    if FFpHD4(refCode):
     servName = service[1]
     if VV3W2M in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VV3W2M), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVJnaJ.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVJnaJ
 def VVkMEM(self):
  VVXVyg = InfoBar.instance
  if VVXVyg:
   VVCDrX = VVXVyg.servicelist
   if VVCDrX:
    return VVCDrX.mode == 1
  return self.VVIgxX
 def VVgbwL(self, VV5PsO):
  self.close()
  VV5PsO.cancel()
 def VV37EN(self, VV5PsO, title, txt, colList):
  FFqoI8(VV5PsO, colList[2], VVLrHC=False, checkParentalControl=True)
 def VVAmPl(self, VV5PsO, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(VV5PsO)
  if refCode:
   VV5PsO.VVIg0J(2, FFJQVB(refCode, iptvRef, chName), True)
 def VVUTWm(self, VV5PsO, title, txt, colList):
  servName = colList[0]
  mSel = CCkpOx(self, VV5PsO)
  VVY9NT, cbFncDict = CCwvQw.VVfY3u(self, VV5PsO, servName, 2)
  mSel.VVUhFW(VVY9NT, cbFncDict)
 def VVRVTK(self, VV5PsO, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFuQxT(self, fncMode=CC8xkn.VV5nWo, refCode=refCode, chName=chName, text=txt)
 def VVwbd7(self):
  FFe4rI(self, self.VV1ymc, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV1ymc(self):
  ret = FFD1OO(self.refCode, True)
  if ret:
   self.VVIiJz()
   self.close()
  else:
   FFZWPu(self, "Cannot change state" , 1000)
 def VVIiJz(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVuY0s()
  except:
   self.VV7XBr()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFR47V(self, serviceRef)
 def VVuY0s(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVXVyg = InfoBar.instance
   if VVXVyg:
    VVCDrX = VVXVyg.servicelist
    if VVCDrX:
     hList = VVCDrX.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVCDrX.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVCDrX.history  = newList
       VVCDrX.history_pos = pos
 def VV7XBr(self):
  VVXVyg = InfoBar.instance
  if VVXVyg:
   VVCDrX = VVXVyg.servicelist
   if VVCDrX:
    VVCDrX.history  = []
    VVCDrX.history_pos = 0
 def VVgy6R(self):
  VVXVyg = InfoBar.instance
  VVJnaJ = []
  if VVXVyg:
   VVCDrX = VVXVyg.servicelist
   if VVCDrX:
    VVcAst, VVF6pL = FFtgvA()
    for serv in VVCDrX.history:
     refCode = serv[-1].toString()
     chName = FFiUHq(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFpHD4(refCode)
     isSRel = FFuuGZ(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FF8b2s(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVcAst:
       STYPE = VVF6pL[sTypeInt]
     VVJnaJ.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVJnaJ:
   VVNiXY  = ("Zap"   , self.VV7J6d   , [])
   VVuKTt = ("Clear History" , self.VVmHvU   , [])
   VVo8Jh = (""    , self.VVaWRv , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV3dzh  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, VVNiXY=VVNiXY, VVuKTt=VVuKTt, VVo8Jh=VVo8Jh)
  else:
   FFNvXQ(self, "History is empty.", title=title)
 def VV7J6d(self, VV5PsO, title, txt, colList):
  FFqoI8(VV5PsO, colList[3], VVLrHC=False, checkParentalControl=True)
 def VVmHvU(self, VV5PsO, title, txt, colList):
  FFe4rI(self, BF(self.VVKdIw, VV5PsO), "Clear Zap History ?")
 def VVKdIw(self, VV5PsO):
  self.VV7XBr()
  VV5PsO.cancel()
 def VVaWRv(self, VV5PsO, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFuQxT(self, fncMode=CC8xkn.VVW4bO, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVp2mZ():
  try:
   global VVmdbp
   if VVmdbp is None:
    VVmdbp    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCAmZo.VVqJG7
   ChannelContextMenu.VVGUyI = CCAmZo.VVGUyI
  except:
   pass
 @staticmethod
 def VVqJG7(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVmdbp(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   t = ( PLUGIN_NAME + " - Channels Browser"
    , PLUGIN_NAME + " - Find"
    , PLUGIN_NAME + " - Channels Tools"  )
   for i in range(3):
    SELF["menu"].list.insert(i, ChoiceEntryComponent(key=" ", text=(t[i] , BF(SELF.VVGUyI, t[i], csel, mode=i))))
 @staticmethod
 def VVGUyI(self, title, csel, mode):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFiUHq(refCode)
  except:
   refCode = refName = ""
  if mode == 0: CC3Ob2.VV1I99(self)
  else  : self.session.open(BF(CCAmZo, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False))
  self.close()
class CCZBEU(Screen, CCZNEG):
 VVNIl0   = 0
 VVJGVE  = 1
 VVp807  = 2
 VVxpeC  = 3
 VVi0jG  = 4
 VVICNr  = 5
 VVY1Fo  = 6
 VVSQXR  = 7
 VVikYQ = 8
 VVFct3 = 9
 VVeqyX = 10
 VVDSq9 = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVZcl5, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCZBEU.VV0FjB()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV0wO4    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFsd9n(self, self.Title)
  FFKpuS(self["keyRed"] , "OK = Zap")
  FFKpuS(self["keyGreen"] , "Current Service")
  FFKpuS(self["keyYellow"], "Page Options")
  FFKpuS(self["keyBlue"] , "Filter")
  CCZNEG.__init__(self, 5, 7, CFG.transpColorPicons)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVhi6t     ,
   "green"  : self.VVfDt3    ,
   "yellow" : self.VVDtDe     ,
   "blue"  : self.VVQPzV     ,
   "menu"  : self.VVqL9W     ,
   "info"  : self.VVwFqL    ,
   "pageUp" : BF(self.VV4bbQ, True) ,
   "chanUp" : BF(self.VV4bbQ, True) ,
   "pageDown" : BF(self.VV4bbQ, False) ,
   "chanDown" : BF(self.VV4bbQ, False) ,
   "0"   : self.VVaZTg  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  FF4AQy(self)
  FFRkaP(self["keyRed"], "#0a333333")
  self.VVArb1()
  self.VVclfN()
  FFDKj1(self, BF(self.VV8WU0, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVqL9W(self):
  if not self.isBusy:
   VVY9NT = []
   VVY9NT.append(("Statistics"           , "VV5YNQ"    ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Suggest PIcons for Current Channel"     , "VVJOgC"   ))
   VVY9NT.append(("Set to Current Channel (copy file)"     , "VVF60N_file"  ))
   VVY9NT.append(("Set to Current Channel (as SymLink)"     , "VVF60N_link"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Export Current File Names List"      , "VVN0BG" ))
   VVY9NT.append(CCZBEU.VV0Gov())
   VVY9NT.append(VVXMhc)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVxsyh
    VVY9NT.append((c + movTxt           , "VVedJl"  ))
    VVY9NT.append((c + delTxt           , "VV1N3t" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVY9NT.append((movTxt + disTxt         ,       ))
    VVY9NT.append((delTxt + disTxt         ,       ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VViW7t"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT += CCZBEU.VVKEPJ()
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Change Poster/Picon Transparency Color"    , "VVF7B7" ))
   VVY9NT.append(("Keys Help"           , "VVp78A"    ))
   FFaJ04(self, self.VVn6j2, width=1100, height=1050, title=self.Title, VVY9NT=VVY9NT)
 def VVn6j2(self, item=None):
  if item is not None:
   if   item == "VV5YNQ"    : self.VV5YNQ()
   elif item == "VVJOgC"   : self.VVJOgC()
   elif item == "VVF60N_file"  : self.VVF60N(0)
   elif item == "VVF60N_link"  : self.VVF60N(1)
   elif item == "VVN0BG"  : self.VVN0BG()
   elif item == "VVyCBm"  : CCZBEU.VVyCBm(self)
   elif item == "VVedJl"   : self.VVedJl()
   elif item == "VV1N3t"  : self.VV1N3t()
   elif item == "VViW7t"  : self.VViW7t()
   elif item == "VVMeKe"  : CCZBEU.VVMeKe(self)
   elif item == "findPiconBrokenSymLinks" : CCZBEU.VVHTCl(self, True)
   elif item == "FindAllBrokenSymLinks" : CCZBEU.VVHTCl(self, False)
   elif item == "VVF7B7" : self.VVF7B7()
   elif item == "VVp78A"     : FFv9kY(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVDtDe(self):
  if not self.isBusy:
   VVY9NT = []
   VVY9NT.append(("Go to First PIcon"  , "VV70gr"  ))
   VVY9NT.append(("Go to Last PIcon"   , "VVr3FZ"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Sort by Channel Name"     , "sortByChan" ))
   VVY9NT.append(("Sort by File Name"  , "sortByFile" ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Find from File List .." , "VVUqRa" ))
   FFaJ04(self, self.VVuLvd, title=self.Title, VVY9NT=VVY9NT)
 def VVuLvd(self, item=None):
  if item is not None:
   if   item == "VV70gr"   : self.VV70gr()
   elif item == "VVr3FZ"   : self.VVr3FZ()
   elif item == "sortByChan"  : self.VVxOYS(2)
   elif item == "sortByFile"  : self.VVxOYS(0)
   elif item == "VVUqRa"  : self.VVUqRa()
 def VVUqRa(self):
  VVY9NT = []
  for item in self.VV0wO4:
   VVY9NT.append((item[0], item[0]))
  FFaJ04(self, self.VVs8JG, title='PIcons ".png" Files', VVY9NT=VVY9NT, VVNDcU=True)
 def VVs8JG(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVwq7z(ndx)
 def VVhi6t(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVymkb()
   if refCode:
    FFqoI8(self, refCode)
    self.VVYnxf()
    self.VVGyRD()
 def VV4bbQ(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVYnxf()
   self.VVGyRD()
  except:
   pass
 def VVfDt3(self):
  if self["keyGreen"].getVisible():
   self.VVwq7z(self.curChanIndex)
 def VVxOYS(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFDKj1(self, BF(self.VV8WU0, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVF60N(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVymkb()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVY9NT = []
     VVY9NT.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVY9NT.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFaJ04(self, BF(self.VVn6bT, mode, curChF, selPiconF), VVY9NT=VVY9NT, title="Current Channel PIcon (already exists)")
    else:
     self.VVn6bT(mode, curChF, selPiconF, "overwrite")
   else:
    FFh60c(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFh60c(self, "Could not read current channel info. !", title=title)
 def VVn6bT(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFDKj1(self, BF(self.VV8WU0, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVedJl(self):
  defDir = FFd5Wt(CCZBEU.VV0FjB() + "picons_backup")
  os.system(FF75pk("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVl6un, defDir), BF(CCVdBH
         , mode=CCVdBH.VVHQKD, VVWic9=CCZBEU.VV0FjB()))
 def VVl6un(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCZBEU.VV0FjB():
    FFh60c(self, "Cannot move to same directory !", title=title)
   else:
    if not FFd5Wt(path) == FFd5Wt(defDir):
     self.VVvkIu(defDir)
    FFe4rI(self, BF(FFDKj1, self, BF(self.VVm8Vr, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV0wO4), path), title=title)
  else:
   self.VVvkIu(defDir)
 def VVm8Vr(self, title, defDir, toPath):
  if not iMove:
   self.VVvkIu(defDir)
   FFh60c(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFd5Wt(toPath)
  pPath = CCZBEU.VV0FjB()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV0wO4:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV0wO4)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFHdWy(self, txt, title=title, VVWGqy="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVRrKt("all")
 def VVvkIu(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV1N3t(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV0wO4)
  FFe4rI(self, BF(FFDKj1, self, BF(self.VVwgN5, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FF10dh(tot)), title=title)
 def VVwgN5(self, title):
  pPath = CCZBEU.VV0FjB()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV0wO4:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV0wO4)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFbRJw(str(totErr), VVLO3F)
  FFHdWy(self, txt, title=title)
 def VViW7t(self):
  lines = FFLYXX("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFe4rI(self, BF(self.VVioRo, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FF10dh(tot)), VVRAK2=True)
  else:
   FFNvXQ(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVioRo(self, fList):
  os.system(FF75pk("find -L '%s' -type l -delete" % self.pPath))
  FFNvXQ(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVwFqL(self):
  FFDKj1(self, self.VVciHw)
 def VVciHw(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVymkb()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFbRJw("PIcon Directory:\n", VV619a)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFfb1b(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFfb1b(path)
   txt += FFbRJw("PIcon File:\n", VV619a)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFbRJw("Found %d SymLink%s to this file from:\n" % (tot, FF10dh(tot)), VV619a)
     for fPath in slLst:
      txt += "  %s\n" % FFbRJw(fPath, VVlhbS)
     txt += "\n"
   if chName:
    txt += FFbRJw("Channel:\n", VV619a)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFbRJw(chName, VVlwDq)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFbRJw("Remarks:\n", VV619a)
    txt += "  %s\n" % FFbRJw("Unused", VVLO3F)
  else:
   txt = "No info found"
  FFuQxT(self, fncMode=CC8xkn.VVpcWZ, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVymkb(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VV0wO4[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFoB4N(sat)
  return fName, refCode, chName, sat, inDB
 def VVYnxf(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV0wO4):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVGyRD(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVymkb()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFbRJw("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV619a))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVymkb()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFuuGZ(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFbRJw(self.curChanName, VVOpMG)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVymkb()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV5YNQ(self):
  VVcAst, VVF6pL = FFtgvA()
  sTypeNameDict = {}
  for key, val in VVF6pL.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VV0wO4:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVF6pL: sTypeDict[VVF6pL[stNum]] = sTypeDict.get(VVF6pL[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFA2wB("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVJnaJ = []
  c = "#b#11003333#"
  VVJnaJ.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVJnaJ.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVJnaJ.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVJnaJ.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVJnaJ.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVJnaJ.append((c + "Satellites"    , str(len(self.nsList))))
  VVJnaJ.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVJnaJ.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVJnaJ.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVJnaJ.extend(sTypeRows)
  FFXBR7(self, None, title=self.Title, VV0wO4=VVJnaJ, VVfp7o=28, VVpoY2="#00003333", VVUWnf="#00222222")
 def VVN0BG(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFd5Wt(CFG.exportedTablesPath.getValue()), txt, FFDaMH())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VV0wO4:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFNvXQ(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVQPzV(self):
  if not self.isBusy:
   VVY9NT = []
   VVY9NT.append(("All"        , "all"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Used by Channels"     , "used" ))
   VVY9NT.append(("Unused PIcons"     , "unused" ))
   VVY9NT.append(("IPTV PIcons"      , "iptv" ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("PIcons Files"      , "pFiles" ))
   VVY9NT.append(("SymLinks to PIcons"    , "pLinks" ))
   VVY9NT.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVY9NT.append(("By Files Date ..."    , "pDate" ))
   VVY9NT.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVY9NT.append(FF9lRG("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFeCPs(val)
      VVY9NT.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCxD0c(self)
   filterObj.VVc8kI(VVY9NT, self.nsList, self.VVxzLg)
 def VVxzLg(self, item=None):
  if item is not None:
   self.VVRrKt(item)
 def VVRrKt(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVNIl0   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVJGVE   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVp807  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVY1Fo   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVxpeC  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVi0jG  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVICNr  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVeqyX , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVDSq9 , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVSQXR   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVikYQ , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVICNr:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFLYXX("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFjufa(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFZWPu(self, "Not found", 1000)
     return
   elif mode == self.VVeqyX:
    self.VVEBQX(mode)
    return
   elif mode == self.VVDSq9:
    self.VVergJ(mode)
    return
   elif mode == self.VVFct3:
    return
   else:
    words, asPrefix = CCxD0c.VVuVDQ(words)
   if not words and mode in (self.VVSQXR, self.VVikYQ):
    FFZWPu(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFDKj1(self, BF(self.VV8WU0, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVEBQX(self, mode):
  VVY9NT = []
  VVY9NT.append(("Today"   , "today" ))
  VVY9NT.append(("Since Yesterday" , "yest" ))
  VVY9NT.append(("Since 7 days"  , "week" ))
  FFaJ04(self, BF(self.VVEvLh, mode), VVY9NT=VVY9NT, title="Filter by Added/Modified Date")
 def VVEvLh(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FF9pmh(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FF9pmh(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FF9pmh(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFDKj1(self, BF(self.VV8WU0, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVergJ(self, mode):
  VVcAst, VVF6pL = FFtgvA()
  lst = set()
  for key, val in VVF6pL.items():
   lst.add(val)
  VVY9NT = []
  for item in lst:
   VVY9NT.append((item, item))
  VVY9NT.sort(key=lambda x: x[0])
  FFaJ04(self, BF(self.VVCbCt, mode), VVY9NT=VVY9NT, title="Filter by Service Type")
 def VVCbCt(self, mode, item=None):
  if item:
   VVcAst, VVF6pL = FFtgvA()
   sTypeList = []
   for key, val in VVF6pL.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFDKj1(self, BF(self.VV8WU0, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVJOgC(self):
  self.session.open(CCRrSr, barTheme=CCRrSr.VVHTAa
      , titlePrefix = ""
      , fncToRun  = self.VVRNwU
      , VVsfO0 = self.VVRyF5)
 def VVRNwU(self, VVq6PE):
  VVclLC, err = CCwvQw.VVz7ZO(self, CCwvQw.VVHDST, VVwD2U=False, VVsFr5=False)
  files = []
  words = []
  if not VVq6PE or VVq6PE.isCancelled:
   return
  VVq6PE.VVwxC6 = []
  VVq6PE.VVlEfz(len(VVclLC))
  if VVclLC:
   VVPC0A = CCcmOV()
   curCh = VVPC0A.VVoOYr(self.curChanName)
   for refCode in VVclLC:
    if not VVq6PE or VVq6PE.isCancelled:
     return
    VVq6PE.VVA8Cz(1, True)
    chName, sat, inDB = VVclLC.get(refCode, ("", "", 0))
    ratio = CCZBEU.VVUSiA(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCZBEU.VVV2Lk(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFjufa(f)
       fil = f.replace(".png", "")
       if not fil in VVq6PE.VVwxC6:
        VVq6PE.VVwxC6.append(fil)
 def VVRyF5(self, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  if VVwxC6 : FFDKj1(self, BF(self.VV8WU0, mode=self.VVFct3, words=VVwxC6), title="Loading ...")
  else   : FFZWPu(self, "Not found", 2000)
 def VV8WU0(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVxMsU(isFirstTime):
   return
  self.isBusy = True
  VVsFr5 = True if isFirstTime else False
  VVclLC, err = CCwvQw.VVz7ZO(self, CCwvQw.VVHDST, VVwD2U=False, VVsFr5=VVsFr5)
  if err:
   self.close()
  iptvRefList = self.VVjWn7()
  tList = []
  for fName, fType in CCZBEU.VVGoX4(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVclLC:
    if fName in VVclLC:
     chName, sat, inDB = VVclLC.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVNIl0:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVJGVE  and chName         : isAdd = True
   elif mode == self.VVp807 and not chName        : isAdd = True
   elif mode == self.VVxpeC  and fType == 0        : isAdd = True
   elif mode == self.VVi0jG  and fType == 1        : isAdd = True
   elif mode == self.VVICNr  and fName in words       : isAdd = True
   elif mode == self.VVFct3 and fName in words       : isAdd = True
   elif mode == self.VVY1Fo  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVSQXR  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVikYQ:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVeqyX:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVDSq9:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV0wO4   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFZWPu(self)
  else:
   self.isBusy = False
   FFZWPu(self, "Not found", 1000)
   return
  self.VV0wO4.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVYnxf()
  self.totalItems = len(self.VV0wO4)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VV2XPD(True)
 def VVxMsU(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCZBEU.VVGoX4(self.pPath):
    if fName:
     return True
   if isFirstTime : FFh60c(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFZWPu(self, "Not found", 1000)
  else:
   FFh60c(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVjWn7(self):
  VVJnaJ = {}
  files  = CCHli4.VVwfQF()
  if files:
   for path in files:
    txt = FFvr8J(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVJnaJ[refCode] = item[1]
  return VVJnaJ
 def VV8QKT(self):
  self.VV4Qja()
  f1, f2 = self.VVPUqI()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV0wO4[ndx]
   fName = self.VV0wO4[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCZNEG.VVKFKt(pic, path) : color = VVlwDq if inDB else ""
   elif not chName           : color = ""
   else             : color = VVW5KH
   self.VV3HyM(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVUSiA(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV0Gov():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVyCBm")
 @staticmethod
 def VVKEPJ():
  VVY9NT = []
  VVY9NT.append(("Find SymLinks (to PIcon Directory)"   , "VVMeKe"  ))
  VVY9NT.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVY9NT.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVY9NT
 @staticmethod
 def VVyCBm(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF)
  png, path = CCZBEU.VVdaFl(refCode)
  if path : CCZBEU.VVIUqf(SELF, png, path)
  else : FFh60c(SELF, "No PIcon found for current channel in:\n\n%s" % CCZBEU.VV0FjB())
 @staticmethod
 def VVMeKe(SELF):
  if VVOpMG:
   sed1 = FFs7EJ("->", VVOpMG)
   sed2 = FFs7EJ("picon", VVLO3F)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVW5KH, VVViAb)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFQHMr(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFNjJC(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVHTCl(SELF, isPIcon):
  sed1 = FFs7EJ("->", VVW5KH)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFs7EJ("picon", VVLO3F)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFQHMr(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFNjJC(), grep, sed1, sed2))
 @staticmethod
 def VVIUqf(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFs7EJ("%s%s" % (dest, png), VVlwDq))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFs7EJ(errTxt, VVzF5b))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFOm4Z(SELF, cmd)
 @staticmethod
 def VVGoX4(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV0FjB():
  path = CFG.PIconsPath.getValue()
  return FFd5Wt(path)
 @staticmethod
 def VVdaFl(refCode, chName=None):
  if FFpHD4(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFE7jz(refCode)
  allPath, fName, refCodeFile, pList = CCZBEU.VVV2Lk(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVXn2v(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCHli4.VVZTvU():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFUkF8(chName)
   for ext in exts:
    path = "%s%s.%s" % (pPath, chName, ext)
    if fileExists(path):
     return path
  return ""
 @staticmethod
 def VVV2Lk(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCZBEU.VV0FjB()
   pList = []
   lst = FFzuBj(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFUkF8(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFjufa(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCJ54U():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVVEkl  = None
  self.VVL1Rq = ""
  self.VVUqHo  = noService
  self.VVPLYK = 0
  self.VVHW8j  = noService
  self.VV1mQx = 0
  self.VVdQIT  = "-"
  self.VVyHNv = 0
  self.VVl1xE  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVfASa(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVVEkl = frontEndStatus
     self.VVnUS9()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVnUS9(self):
  if self.VVVEkl:
   val = self.VVVEkl.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVL1Rq = "%3.02f dB" % (val / 100.0)
   else         : self.VVL1Rq = ""
   val = self.VVVEkl.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVPLYK = int(val)
   self.VVUqHo  = "%d%%" % val
   val = self.VVVEkl.get("tuner_signal_power" , 0) * 100 / 65536
   self.VV1mQx = int(val)
   self.VVHW8j  = "%d%%" % val
   val = self.VVVEkl.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVdQIT  = "%d" % val
   val = int(val * 100 / 500)
   self.VVyHNv = min(500, val)
   val = self.VVVEkl.get("tuner_locked", 0)
   if val == 1 : self.VVl1xE = "Locked"
   else  : self.VVl1xE = "Not locked"
 def VVnMOn(self)   : return self.VVL1Rq
 def VVQrP9(self)   : return self.VVUqHo
 def VVADrX(self)  : return self.VVPLYK
 def VVHBvP(self)   : return self.VVHW8j
 def VVnKyO(self)  : return self.VV1mQx
 def VV2SVS(self)   : return self.VVdQIT
 def VVROci(self)  : return self.VVyHNv
 def VVlSrN(self)   : return self.VVl1xE
 def VVKMfW(self) : return self.serviceName
class CCsRkT():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVhexk(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFQKyU(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVpIAi(self.ORPOS  , mod=1   )
      self.sat2  = self.VVpIAi(self.ORPOS  , mod=2   )
      self.freq  = self.VVpIAi(self.FREQ  , mod=3   )
      self.sr   = self.VVpIAi(self.SR   , mod=4   )
      self.inv  = self.VVpIAi(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVpIAi(self.POL  , self.D_POL )
      self.fec  = self.VVpIAi(self.FEC  , self.D_FEC )
      self.syst  = self.VVpIAi(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVpIAi("modulation" , self.D_MOD )
       self.rolof = self.VVpIAi("rolloff"  , self.D_ROLOF )
       self.pil = self.VVpIAi("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVpIAi("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVpIAi("pls_code"  )
       self.iStId = self.VVpIAi("is_id"   )
       self.t2PlId = self.VVpIAi("t2mi_plp_id" )
       self.t2PId = self.VVpIAi("t2mi_pid"  )
 def VVpIAi(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFeCPs(val)
  elif mod == 2   : return FFZmN3(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVMAaV(self, refCode):
  txt = ""
  self.VVhexk(refCode)
  if self.data:
   def VVg0pA(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVg0pA("System"   , self.syst)
    txt += VVg0pA("Satellite"  , self.sat2)
    txt += VVg0pA("Frequency"  , self.freq)
    txt += VVg0pA("Inversion"  , self.inv)
    txt += VVg0pA("Symbol Rate"  , self.sr)
    txt += VVg0pA("Polarization" , self.pol)
    txt += VVg0pA("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVg0pA("Modulation" , self.mod)
     txt += VVg0pA("Roll-Off" , self.rolof)
     txt += VVg0pA("Pilot"  , self.pil)
     txt += VVg0pA("Input Stream", self.iStId)
     txt += VVg0pA("T2MI PLP ID" , self.t2PlId)
     txt += VVg0pA("T2MI PID" , self.t2PId)
     txt += VVg0pA("PLS Mode" , self.plsMod)
     txt += VVg0pA("PLS Code" , self.plsCod)
   else:
    txt += VVg0pA("System"   , self.txMedia)
    txt += VVg0pA("Frequency"  , self.freq)
  return txt, self.namespace
 def VVv59C(self, refCode):
  txt = "Transpoder : ?"
  self.VVhexk(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVW1mB(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFQKyU(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVpIAi(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVpIAi(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVpIAi(self.SYST, self.D_SYS_S)
     freq = self.VVpIAi(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVpIAi(self.POL , self.D_POL)
      fec = self.VVpIAi(self.FEC , self.D_FEC)
      sr = self.VVpIAi(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVq425(self, refCode):
  self.data = None
  self.VVhexk(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCbHA8():
 def __init__(self, VVRrzd, path, VVsfO0=None, curRowNum=-1):
  self.VVRrzd  = VVRrzd
  self.origFile   = path
  self.Title    = "File Editor: " + FFjufa(path)
  self.VVsfO0  = VVsfO0
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FF75pk("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VV44bn(curRowNum)
  else:
   FFh60c(self.VVRrzd, "Error while preparing edit!")
 def VV44bn(self, curRowNum):
  VVJnaJ = self.VVdz7Y()
  VVY2vy = ("Save Changes" , self.VVoqcA   , [])
  VVNiXY  = ("Edit Line"  , self.VVcACG    , [])
  VVuKTt = ("Go to Line Num" , self.VVsrTw   , [])
  VVNlag = ("Line Options" , self.VVezcs   , [])
  VVKFgA = (""    , self.VV0AH2 , [])
  VVo9Gm = self.VVbdyO
  VVzoEZ  = self.VVtBtz
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV3dzh  = (CENTER  , LEFT  )
  VV5PsO = FFXBR7(self.VVRrzd, None, title=self.Title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVY2vy=VVY2vy, VVNiXY=VVNiXY, VVuKTt=VVuKTt, VVNlag=VVNlag, VVo9Gm=VVo9Gm, VVzoEZ=VVzoEZ, VVKFgA=VVKFgA, VVcNyk=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVU4bo   = "#11001111"
    , VVdq78   = "#11001111"
    , VVWGqy   = "#11001111"
    , VVpoY2  = "#05333333"
    , VVUWnf  = "#00222222"
    , VVwS5R  = "#11331133"
    )
  VV5PsO.VVyOnh(curRowNum)
 def VVsrTw(self, VV5PsO, title, txt, colList):
  totRows = VV5PsO.VVbwlY()
  lineNum = VV5PsO.VV3w14() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FF5ZDh(self.VVRrzd, BF(self.VVvVeP, VV5PsO, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVvVeP(self, VV5PsO, lineNum, totRows, VVHzlS):
  if VVHzlS:
   VVHzlS = VVHzlS.strip()
   if VVHzlS.isdigit():
    num = FFiWjh(int(VVHzlS) - 1, 0, totRows)
    VV5PsO.VVyOnh(num)
    self.lastLineNum = num + 1
   else:
    FFZWPu(VV5PsO, "Incorrect number", 1500)
 def VVezcs(self, VV5PsO, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VV5PsO.VVEYr6()
  VVY9NT = []
  VVY9NT.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVY9NT.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVYrjB"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VV48L0:
   VVY9NT.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(  ("Delete Line"         , "deleteLine"   ))
  FFaJ04(self.VVRrzd, BF(self.VVVJGK, VV5PsO, lineNum), VVY9NT=VVY9NT, title="Line Options")
 def VVVJGK(self, VV5PsO, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV4Ztm("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VV5PsO)
   elif item == "VVYrjB"  : self.VVYrjB(VV5PsO, lineNum)
   elif item == "copyToClipboard"  : self.VVfym0(VV5PsO, lineNum)
   elif item == "pasteFromClipboard" : self.VVn9XD(VV5PsO, lineNum)
   elif item == "deleteLine"   : self.VV4Ztm("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VV5PsO)
 def VVtBtz(self, VV5PsO):
  VV5PsO.VVxErJ()
 def VV0AH2(self, VV5PsO, title, txt, colList):
  if   self.insertMode == 1: VV5PsO.VVoI9j()
  elif self.insertMode == 2: VV5PsO.VVqv7q()
  self.insertMode = 0
 def VVYrjB(self, VV5PsO, lineNum):
  if lineNum == VV5PsO.VVEYr6():
   self.insertMode = 1
   self.VV4Ztm("echo '' >> '%s'" % self.tmpFile, VV5PsO)
  else:
   self.insertMode = 2
   self.VV4Ztm("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VV5PsO)
 def VVfym0(self, VV5PsO, lineNum):
  global VV48L0
  VV48L0 = FFA2wB("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VV5PsO.VViaMT("Copied to clipboard")
 def VVoqcA(self, VV5PsO, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FF75pk("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FF75pk("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VV5PsO.VViaMT("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VV5PsO.VVxErJ()
    else:
     FFh60c(self.VVRrzd, "Cannot save file!")
   else:
    FFh60c(self.VVRrzd, "Cannot create backup copy of original file!")
 def VVbdyO(self, VV5PsO):
  if self.fileChanged:
   FFe4rI(self.VVRrzd, BF(self.VVqvrH, VV5PsO), "Cancel changes ?")
  else:
   finalOK = os.system(FF75pk("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVqvrH(VV5PsO)
 def VVqvrH(self, VV5PsO):
  VV5PsO.cancel()
  FFiHj6(self.tmpFile)
  if self.VVsfO0:
   self.VVsfO0(self.fileSaved)
 def VVcACG(self, VV5PsO, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVViAb + "ORIGINAL TEXT:\n" + VVlhbS + lineTxt
  FF5ZDh(self.VVRrzd, BF(self.VV32Ap, lineNum, VV5PsO), title="File Line", defaultText=lineTxt, message=message)
 def VV32Ap(self, lineNum, VV5PsO, VVHzlS):
  if not VVHzlS is None:
   if VV5PsO.VVEYr6() <= 1:
    self.VV4Ztm("echo %s > '%s'" % (VVHzlS, self.tmpFile), VV5PsO)
   else:
    self.VV7ZBM(VV5PsO, lineNum, VVHzlS)
 def VVn9XD(self, VV5PsO, lineNum):
  if lineNum == VV5PsO.VVEYr6() and VV5PsO.VVEYr6() == 1:
   self.VV4Ztm("echo %s >> '%s'" % (VV48L0, self.tmpFile), VV5PsO)
  else:
   self.VV7ZBM(VV5PsO, lineNum, VV48L0)
 def VV7ZBM(self, VV5PsO, lineNum, newTxt):
  VV5PsO.VVfxtU("Saving ...")
  lines = FFun41(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VV5PsO.VVEejY()
  VVJnaJ = self.VVdz7Y()
  VV5PsO.VVQNRz(VVJnaJ)
 def VV4Ztm(self, cmd, VV5PsO):
  tCons = CC6TQl()
  tCons.ePopen(cmd, BF(self.VVZM7h, VV5PsO))
  self.fileChanged = True
  VV5PsO.VVEejY()
 def VVZM7h(self, VV5PsO, result, retval):
  VVJnaJ = self.VVdz7Y()
  VV5PsO.VVQNRz(VVJnaJ)
 def VVdz7Y(self):
  if fileExists(self.tmpFile):
   lines = FFun41(self.tmpFile)
   VVJnaJ = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVJnaJ.append((str(ndx), line.strip()))
   if not VVJnaJ:
    VVJnaJ.append((str(1), ""))
   return VVJnaJ
  else:
   FFCpVp(self.VVRrzd, self.tmpFile)
class CCxD0c():
 def __init__(self, callingSELF, VVU4bo="#22003344", VVdq78="#22002233"):
  self.callingSELF = callingSELF
  self.VVY9NT  = []
  self.satList  = []
  self.VVU4bo  = VVU4bo
  self.VVdq78   = VVdq78
 def VV4ACb(self, VVsfO0):
  self.VVY9NT = []
  VVY9NT, VVhHi9 = CCxD0c.VVOPzW(self.callingSELF, False, True)
  if VVY9NT:
   self.VVY9NT += VVY9NT
   self.VVzySq(VVsfO0, VVhHi9)
 def VVnDc0(self, mode, VV5PsO, satCol, VVsfO0, inFilterFnc=None):
  VV5PsO.VVfxtU("Loading Filters ...")
  self.VVY9NT = []
  self.VVY9NT.append(("All Services" , "all"))
  if mode == 1:
   self.VVY9NT.append(VVXMhc)
   self.VVY9NT.append(("Parental Control", "parentalControl"))
   self.VVY9NT.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVY9NT.append(VVXMhc)
   self.VVY9NT.append(("Selected Transponder"   , "selectedTP" ))
   self.VVY9NT.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVcFr9(VV5PsO, satCol)
  VVY9NT, VVhHi9 = CCxD0c.VVOPzW(self.callingSELF, True, False)
  if VVY9NT:
   VVY9NT.insert(0, FF9lRG("Custom Words"))
   self.VVY9NT += VVY9NT
  VV5PsO.VVxwzS()
  self.VVzySq(VVsfO0, VVhHi9, inFilterFnc)
 def VVc8kI(self, VVY9NT, sats, VVsfO0, inFilterFnc=None):
  self.VVY9NT = VVY9NT
  VVY9NT, VVhHi9 = CCxD0c.VVOPzW(self.callingSELF, True, False)
  if VVY9NT:
   self.VVY9NT.append(FF9lRG("Custom Words"))
   self.VVY9NT += VVY9NT
  self.VVzySq(VVsfO0, VVhHi9, inFilterFnc)
 def VVzySq(self, VVsfO0, VVhHi9, inFilterFnc=None):
  VV0Xwe  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVMxmU = ("Edit Filter"  , BF(self.VVRwXz, VVhHi9))
  VV8vtf  = ("Filter Help"  , BF(self.VVgnQG, VVhHi9))
  FFaJ04(self.callingSELF, BF(self.VVWrtG, VVsfO0), VVY9NT=self.VVY9NT, title="Select Filter", VV0Xwe=VV0Xwe, VVMxmU=VVMxmU, VV8vtf=VV8vtf, VVFP3k=True, VVU4bo=self.VVU4bo, VVdq78=self.VVdq78)
 def VVWrtG(self, VVsfO0, item):
  if item:
   VVsfO0(item)
 def VVRwXz(self, VVhHi9, VVELdAObj, sel):
  if fileExists(VVhHi9) : CCbHA8(self.callingSELF, VVhHi9, VVsfO0=None)
  else       : FFCpVp(self.callingSELF, VVhHi9)
  VVELdAObj.cancel()
 def VVgnQG(self, VVhHi9, VVELdAObj, sel):
  FFv9kY(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVcFr9(self, VV5PsO, satColNum):
  if not self.satList:
   satList = VV5PsO.VVGSQw(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFoB4N(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FF9lRG("Satellites"))
  if self.VVY9NT:
   self.VVY9NT += self.satList
 @staticmethod
 def VVOPzW(SELF, addTag, VVyRz1):
  FFNERR()
  fileName  = "ajpanel_services_filter"
  VVhHi9 = VVPUYO + fileName
  VVY9NT  = []
  if not fileExists(VVhHi9):
   os.system(FF75pk("cp -f '%s' '%s'" % (VVE5ib + fileName, VVhHi9)))
  fileFound = False
  if fileExists(VVhHi9):
   fileFound = True
   lines = FFun41(VVhHi9)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVY9NT.append((line, "__w__" + line))
       else  : VVY9NT.append((line, line))
  if VVyRz1:
   if   not fileFound : FFCpVp(SELF, VVhHi9)
   elif not VVY9NT : FFUVcy(SELF, VVhHi9)
  return VVY9NT, VVhHi9
 @staticmethod
 def VVuVDQ(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCkpOx():
 def __init__(self, callingSELF, VV5PsO, addSep=True):
  self.callingSELF = callingSELF
  self.VV5PsO = VV5PsO
  self.VVY9NT = []
  iMulSel = self.VV5PsO.VVlhHr()
  if iMulSel : self.VVY9NT.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVY9NT.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VV5PsO.VVkjUl()
  self.VVY9NT.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVY9NT.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVY9NT.append(VVXMhc)
 def VVUhFW(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVY9NT.extend(extraMenu)
  FFaJ04(self.callingSELF, BF(self.VVmQih, cbFncDict, okFnc), width=width, title="Options", VVY9NT=self.VVY9NT)
 def VVmQih(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VV5PsO.VVho3y(True)
   elif item == "MultSelDisab" : self.VV5PsO.VVho3y(False)
   elif item == "selectAll" : self.VV5PsO.VVhxjl()
   elif item == "unselectAll" : self.VV5PsO.VVHIWx()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCWNSr(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVyLlF, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFsd9n(self)
  FFKpuS(self["keyRed"]  , "Exit")
  FFKpuS(self["keyGreen"]  , "Save")
  FFKpuS(self["keyYellow"] , "Refresh")
  FFKpuS(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVYZRn  ,
   "green" : self.VVKEHr ,
   "yellow": self.VVMelM  ,
   "blue" : self.VVAmA2   ,
   "up" : self.VVS2uh    ,
   "down" : self.VV4dKD   ,
   "left" : self.VVBeVJ   ,
   "right" : self.VVk9Xp   ,
   "cancel": self.VVYZRn
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self.VVMelM()
  self.VVbUZh()
  FF4AQy(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvN4R)
  except:
   self.timer.callback.append(self.VVvN4R)
  self.timer.start(1000, False)
  self.VVvN4R()
 def onExit(self):
  self.timer.stop()
 def VVYZRn(self) : self.close(True)
 def VVmMZ2(self) : self.close(False)
 def VVAmA2(self):
  self.session.openWithCallback(self.VVT0js, BF(CCNhkQ))
 def VVT0js(self, closeAll):
  if closeAll:
   self.close()
 def VVvN4R(self):
  self["curTime"].setText(str(FF2gB8(iTime())))
 def VVS2uh(self):
  self.VVjwfZ(1)
 def VV4dKD(self):
  self.VVjwfZ(-1)
 def VVBeVJ(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVbUZh()
 def VVk9Xp(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVbUZh()
 def VVjwfZ(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVU3GU(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVU3GU(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVU3GU(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVRNq0(year)):
   days += 1
  return days
 def VVRNq0(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVbUZh(self):
  for obj in self.list:
   FFRkaP(obj, "#11404040")
  FFRkaP(self.list[self.index], "#11ff8000")
 def VVMelM(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVKEHr(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC6TQl()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVtYGE)
 def VVtYGE(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFNvXQ(self, "Nothing returned from the system!")
  else:
   FFNvXQ(self, str(result))
class CCNhkQ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VV181V, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFsd9n(self, addLabel=True)
  FFKpuS(self["keyRed"]  , "Exit")
  FFKpuS(self["keyGreen"]  , "Sync")
  FFKpuS(self["keyYellow"] , "Refresh")
  FFKpuS(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVYZRn   ,
   "green" : self.VVbb7j  ,
   "yellow": self.VV6X59 ,
   "blue" : self.VVJJQ0  ,
   "cancel": self.VVYZRn
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVbcbW()
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  FF4AQy(self)
  FFcigO(self.VVIsWb)
 def VVIsWb(self):
  self.VVaiLm()
  self.VVOUfD(False)
 def VVYZRn(self)  : self.close(True)
 def VVJJQ0(self) : self.close(False)
 def VVbcbW(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVaiLm(self):
  self.VVdhBV()
  self.VVdqYU()
  self.VVUUaw()
  self.VVIe6t()
 def VV6X59(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVbcbW()
   self.VVaiLm()
   FFcigO(self.VVIsWb)
 def VVbb7j(self):
  if len(self["keyGreen"].getText()) > 0:
   FFe4rI(self, self.VVSQkH, "Synchronize with Internet Date/Time ?")
 def VVSQkH(self):
  self.VVaiLm()
  FFcigO(BF(self.VVOUfD, True))
 def VVdhBV(self)  : self["keyRed"].show()
 def VV9Rii(self)  : self["keyGreen"].show()
 def VVtoPM(self) : self["keyYellow"].show()
 def VVqXho(self)  : self["keyBlue"].show()
 def VVdqYU(self)  : self["keyGreen"].hide()
 def VVUUaw(self) : self["keyYellow"].hide()
 def VVIe6t(self)  : self["keyBlue"].hide()
 def VVOUfD(self, sync):
  localTime = FF4W6Q()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVIr7D(server)
   if epoch_time is not None:
    ntpTime = FF2gB8(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC6TQl()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVtYGE, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVtoPM()
  self.VVqXho()
  if ok:
   self.VV9Rii()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVtYGE(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVOUfD(False)
  except:
   pass
 def VVIr7D(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCo7Gj.VVHLsi():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCTX3s(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFWDRO(VVt3UW, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFsd9n(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFcigO(self.VVYwXs)
 def VVYwXs(self):
  if CCo7Gj.VVHLsi() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFRkaP(self["myBody"], color)
   FFRkaP(self["myLabel"], color)
  except:
   pass
class CCkbMr(Screen):
 VVpvKD = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FF7Vv0()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFWDRO(VVXc0G, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCSqwD(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCSqwD(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCSqwD(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCJ54U()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFsd9n(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVS2uh       ,
   "down"  : self.VV4dKD      ,
   "left"  : self.VVBeVJ      ,
   "right"  : self.VVk9Xp      ,
   "info"  : self.VVB9Du     ,
   "epg"  : self.VVB9Du     ,
   "menu"  : self.VVp78A      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVzeGs, -1)  ,
   "next"  : BF(self.VVzeGs, 1)  ,
   "pageUp" : BF(self.VVbAs7, True) ,
   "chanUp" : BF(self.VVbAs7, True) ,
   "pageDown" : BF(self.VVbAs7, False) ,
   "chanDown" : BF(self.VVbAs7, False) ,
   "0"   : BF(self.VVzeGs, 0)  ,
   "1"   : BF(self.VVyUYD, pos=1) ,
   "2"   : BF(self.VVyUYD, pos=2) ,
   "3"   : BF(self.VVyUYD, pos=3) ,
   "4"   : BF(self.VVyUYD, pos=4) ,
   "5"   : BF(self.VVyUYD, pos=5) ,
   "6"   : BF(self.VVyUYD, pos=6) ,
   "7"   : BF(self.VVyUYD, pos=7) ,
   "8"   : BF(self.VVyUYD, pos=8) ,
   "9"   : BF(self.VVyUYD, pos=9) ,
  }, -1)
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  if not CCkbMr.VVpvKD:
   CCkbMr.VVpvKD = self
  self.sliderSNR.VVVbgc()
  self.sliderAGC.VVVbgc()
  self.sliderBER.VVVbgc(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVyUYD()
  self.VVBSpF()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVhbYZ)
  except:
   self.timer.callback.append(self.VVhbYZ)
  self.timer.start(500, False)
 def VVBSpF(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVfASa(service)
  serviceName = self.tunerInfo.VVKMfW()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  tp = CCsRkT()
  tpTxt, satTxt = tp.VVv59C(refCode)
  if tpTxt == "?" :
   tpTxt = FFbRJw("NO SIGNAL", VVxsyh)
  self["myTPInfo"].setText(tpTxt + "  " + FFbRJw(satTxt, VVmuI1))
 def VVhbYZ(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVfASa(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVnMOn())
   self["mySNR"].setText(self.tunerInfo.VVQrP9())
   self["myAGC"].setText(self.tunerInfo.VVHBvP())
   self["myBER"].setText(self.tunerInfo.VV2SVS())
   self.sliderSNR.VV5YsX(self.tunerInfo.VVADrX())
   self.sliderAGC.VV5YsX(self.tunerInfo.VVnKyO())
   self.sliderBER.VV5YsX(self.tunerInfo.VVROci())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VV5YsX(0)
   self.sliderAGC.VV5YsX(0)
   self.sliderBER.VV5YsX(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
    if state and not state == "Tuned":
     FFZWPu(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVB9Du(self):
  FFuQxT(self, fncMode=CC8xkn.VVlCSN)
 def VVp78A(self):
  FFv9kY(self, "_help_signal", "Signal Monitor (Keys)")
 def VVS2uh(self)  : self.VVyUYD(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV4dKD(self) : self.VVyUYD(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVBeVJ(self) : self.VVyUYD(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVk9Xp(self) : self.VVyUYD(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVyUYD(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFoBdB(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVzeGs(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFiWjh(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFoBdB(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCkbMr.VVpvKD = None
 def VVbAs7(self, isUp):
  FFZWPu(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVBSpF()
  except:
   pass
class CCSqwD(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVVbgc(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFRkaP(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVE5ib +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFRkaP(self.covObj, self.covColor)
   else:
    FFRkaP(self.covObj, "#00006688")
    self.isColormode = True
  self.VV5YsX(0)
 def VV5YsX(self, val):
  val  = FFiWjh(val, self.minN, self.maxN)
  width = int(FFo5AX(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFiWjh(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCRrSr(Screen):
 VVHTAa    = 0
 VVNbOE = 1
 VVazpN = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVsfO0=None, barTheme=VVHTAa, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVGos2(barTheme)
  self.skin, self.skinParam = FFWDRO(VV6PU3, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVsfO0 = VVsfO0
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVwxC6 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFsd9n(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self.VVlxSR()
  self["myProgBarVal"].setText("0%")
  FFRkaP(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVkr1r()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVkr1r)
  except:
   self.timer.callback.append(self.VVkr1r)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVlEfz(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVVLSv(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVwxC6), self.counter, self.maxValue, catName)
 def VVuB38(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVhtuG(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VV0BdB(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVQgdO(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VV7jHd(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVryiB(self, txt):
  self.newTitle = txt
 def VVA8Cz(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVwxC6), self.counter, self.maxValue)
  except:
   pass
 def VVDRNh(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVGcoz(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVzQYG(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFZWPu(self, "Cancelling ...")
  self.isCancelled = True
  self.VVKrqE(False)
 def VVKrqE(self, isDone):
  FFcigO(BF(self.VVByPV, isDone))
 def VVByPV(self, isDone):
  if self.VVsfO0:
   self.VVsfO0(isDone, self.VVwxC6, self.counter, self.maxValue, self.isError)
  self.close()
 def VVkr1r(self):
  val = FFiWjh(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFo5AX(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVKrqE(True)
 def VVlxSR(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVNbOE, self.VVazpN):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVGos2(self, barTheme):
  if   barTheme == self.VVNbOE : return 0.7
  if   barTheme == self.VVazpN : return 0.5
  else             : return 1
class CC6TQl(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVsfO0 = {}
  self.commandRunning = False
  self.VVqneK  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVsfO0, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVsfO0[name] = VVsfO0
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVqneK:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVUFOO, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVFcKA , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVUFOO, name))
    self.appContainers[name].appClosed.append(BF(self.VVFcKA , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVFcKA(name, retval)
  return True
 def VVUFOO(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFbRJw("[UN-DECODED STRING]", VVxsyh))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVFcKA(self, name, retval):
  if not self.VVqneK:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVsfO0[name]:
   self.VVsfO0[name](self.appResults[name], retval)
  del self.VVsfO0[name]
 def VV1jpK(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CC2Jby(Screen):
 def __init__(self, session, title="", VVelZe=None, VVXjb4=False, VVMIrb=False, VVjtjK=False, VVupuq=False, VVa6xF=False, VVW4f4=False, VVQY0S=VVT5lQ, VV54cX=None, VVdPIw=False, VV3Zt2=None, VVTGFI="", checkNetAccess=False, VVfp7o=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFWDRO(VVKV47, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVfp7o, usefixedFont=consFont)
  self.session   = session
  self.VVTGFI = VVTGFI
  FFsd9n(self, addScrollLabel=True)
  self.VVXjb4   = VVXjb4
  self.VVMIrb   = VVMIrb
  self.VVjtjK   = VVjtjK
  self.VVupuq  = VVupuq
  self.VVa6xF = VVa6xF
  self.VVW4f4 = VVW4f4
  self.VVQY0S   = VVQY0S
  self.VV54cX = VV54cX
  self.VVdPIw  = VVdPIw
  self.VV3Zt2  = VV3Zt2
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC6TQl()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFKcKn()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVelZe, str):
   self.VVelZe = [VVelZe]
  else:
   self.VVelZe = VVelZe
  if self.VVjtjK or self.VVupuq:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVwtEz, VVwtEz)
   self.VVelZe.append("echo -e '\n%s\n' %s" % (restartNote, FFs7EJ(restartNote, VVOpMG)))
   if self.VVjtjK:
    self.VVelZe.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVelZe.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVa6xF:
   FFZWPu(self, "Processing ...")
  self.onLayoutFinish.append(self.VVb8q5)
  self.onClose.append(self.VVbuhs)
 def VVb8q5(self):
  self["myLabel"].VVxoM0(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVTGFI or "Processing ..."))
  if self.VVXjb4:
   self["myLabel"].VVDPfH()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVaaqC()
  else:
   self.VVHxpW()
 def VVaaqC(self):
  if CCo7Gj.VVHLsi():
   self["myLabel"].setText("Processing ...")
   self.VVHxpW()
  else:
   self["myLabel"].setText(FFbRJw("\n   No connection to internet!", VVLO3F))
 def VVHxpW(self):
  allOK = self.container.ePopen(self.VVelZe[0], self.VVVPE0, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVVPE0("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVW4f4 or self.VVjtjK or self.VVupuq:
    self["myLabel"].setText(FFF2CM("STARTED", VVOpMG) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV3Zt2:
   colorWhite = CCwVjJ.VVkM5Z(VVViAb)
   color  = CCwVjJ.VVkM5Z(self.VV3Zt2[0])
   words  = self.VV3Zt2[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVQY0S=self.VVQY0S)
 def VVVPE0(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVelZe):
   allOK = self.container.ePopen(self.VVelZe[self.cmdNum], self.VVVPE0, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVVPE0("Cannot connect to Console!", -1)
  else:
   if self.VVa6xF and FFDQOc(self):
    FFZWPu(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVW4f4:
    self["myLabel"].appendText("\n" + FFF2CM("FINISHED", VVOpMG), self.VVQY0S)
   if self.VVXjb4 or self.VVMIrb:
    self["myLabel"].VVDPfH()
   if self.VV54cX is not None:
    self.VV54cX()
   if not retval and self.VVdPIw:
    self.VVbuhs()
 def VVbuhs(self):
  if self.container.VV1jpK():
   self.container.killAll()
class CC7PJi(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVKV47, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVPUYO + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFA2wB("pwd") or "/home/root"
  self.container   = CC6TQl()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFsd9n(self, title="Terminal", addScrollLabel=True)
  FFKpuS(self["keyRed"] , self.exitBtnText)
  FFKpuS(self["keyGreen"] , "OK = History")
  FFKpuS(self["keyYellow"], "Menu = Custom Cmds")
  FFKpuS(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVrJRt ,
   "cancel": self.VVzsPZ  ,
   "menu" : self.VVHOHE ,
   "last" : self.VVY0Q9  ,
   "next" : self.VVY0Q9  ,
   "1"  : self.VVY0Q9  ,
   "2"  : self.VVY0Q9  ,
   "3"  : self.VVY0Q9  ,
   "4"  : self.VVY0Q9  ,
   "5"  : self.VVY0Q9  ,
   "6"  : self.VVY0Q9  ,
   "7"  : self.VVY0Q9  ,
   "8"  : self.VVY0Q9  ,
   "9"  : self.VVY0Q9  ,
   "0"  : self.VVY0Q9
  })
  self.onLayoutFinish.append(self.VVrYby)
  self.onClose.append(self.VVNuzr)
 def VVrYby(self):
  self["myLabel"].VVxoM0(isResizable=False, outputFileToSave="terminal")
  FFR9H9(self["keyRed"]  , "#00ff8000")
  FFRkaP(self["keyRed"]  , self.skinParam["titleColor"])
  FFRkaP(self["keyGreen"]  , self.skinParam["titleColor"])
  FFRkaP(self["keyYellow"] , self.skinParam["titleColor"])
  FFRkaP(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVR8eD(FFA2wB("date"), 5)
  result = FFA2wB("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVXm06()
  self.VVMxGj()
 def VVMxGj(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVPUYO + "LinuxCommands.lst"
  templPath = VVE5ib + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   res = os.system(FF75pk("cp -f '%s' '%s'" % (templPath, alterFile)))
   if not res == 0:
    with open(alterFile, "w") as f:
     f.write("pwd\ncd\ncd /tmp\nls\nls -ls\n")
   self.customCommandsFile = alterFile
 def VVNuzr(self):
  if self.container.VV1jpK():
   self.container.killAll()
   self.VVR8eD("Process killed\n", 4)
   self.VVXm06()
 def VVzsPZ(self):
  if self.container.VV1jpK():
   self.VVNuzr()
  else:
   FFe4rI(self, self.close, "Exit ?", VVmqJ5=False)
 def VVXm06(self):
  self.VVR8eD(self.prompt, 1)
  self["keyRed"].hide()
 def VVR8eD(self, txt, mode):
  if   mode == 1 : color = VVOpMG
  elif mode == 2 : color = VV619a
  elif mode == 3 : color = VVViAb
  elif mode == 4 : color = VVLO3F
  elif mode == 5 : color = VVlhbS
  elif mode == 6 : color = VVtUHQ
  else   : color = VVViAb
  try:
   self["myLabel"].appendText(FFbRJw(txt, color))
  except:
   pass
 def VVrJRt(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVOfpl() == "":
   self.VV3x1G("cd /tmp")
   self.VV3x1G("ls")
  VVJnaJ = []
  if fileExists(self.commandHistoryFile):
   lines  = FFun41(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVJnaJ.append((str(c), line, str(lNum)))
   self.VVXSs9(VVJnaJ, title, self.commandHistoryFile, isHistory=True)
  else:
   FFCpVp(self, self.commandHistoryFile, title=title)
 def VVOfpl(self):
  lastLine = FFA2wB("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV3x1G(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVHOHE(self, VV5PsO=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFun41(self.customCommandsFile)
   VVJnaJ = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVJnaJ.append((str(c), line, str(lNum)))
   if VV5PsO:
    VV5PsO.VVQNRz(VVJnaJ)
    VV5PsO.VVyOnh(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVXSs9(VVJnaJ, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFCpVp(self, self.customCommandsFile, title=title)
 def VVXSs9(self, VVJnaJ, title, filePath=None, isHistory=False):
  if VVJnaJ:
   VVpoY2 = "#05333333"
   if isHistory: VVU4bo = VVdq78 = VVWGqy = "#11000020"
   else  : VVU4bo = VVdq78 = VVWGqy = "#06002020"
   VVNiXY   = ("Send"   , BF(self.VVbZ4k, isHistory)  , [])
   VVY2vy  = ("Modify & Send" , self.VVsfAU     , [])
   if isHistory:
    VVuKTt = ("Clear History" , self.VVB6Ys     , [])
    VVNlag = None
    VVo8Jh = None
   elif filePath:
    VVuKTt = ("Options"  , self.VVttKs      , [])
    VVNlag = ("Edit File"  , BF(self.VVscsA, filePath) , [])
    VVo8Jh = (""    , self.VVAfk2     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VV3dzh = (CENTER , LEFT   , CENTER )
   VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag, VVo8Jh=VVo8Jh, lastFindConfigObj=CFG.lastFindTerminal, VVcNyk=True, searchCol=1
         , VVU4bo=VVU4bo, VVdq78=VVdq78, VVWGqy=VVWGqy, VVjOuo="#05ffff00", VVpoY2=VVpoY2)
   if not isHistory:
    VV5PsO.VVyOnh(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFe4rI(self, BF(self.VVrVvE, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVAfk2(self, VV5PsO, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFbRJw("Command:", VVmuI1), colList[1])
  txt += "%s\n%s\n\n" % (FFbRJw("Line %s in File:" % colList[2], VVmuI1), self.customCommandsFile)
  FFHdWy(self, txt, title=title)
 def VVttKs(self, VV5PsO, title, txt, colList):
  mSel = CCkpOx(self, VV5PsO)
  VVY9NT = []
  txt1 = "Change Custom Commands File"
  if VV5PsO.VVSQQE:
   VVY9NT.append((txt1, ))
   VVY9NT.append(VVXMhc)
   totSel = VV5PsO.VVkjUl()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFbRJw(totTxt, VVOpMG) if totSel else totTxt, FF10dh(totSel))
   VVY9NT.append((txt2, "send") if totSel else (txt2,))
  else:
   VVY9NT.append((txt1, "newFile"))
   VVY9NT.append(VVXMhc)
   txt2 = "Send current line"
   VVY9NT.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVrVvE, VV5PsO, txt1)
     , "send" : BF(self.VVbZ4k, False, VV5PsO, title, txt2, colList) }
  mSel.VVUhFW(VVY9NT, cbFncDict, okFnc=BF(self.VVgjEr, VV5PsO))
 def VVrVvE(self, VV5PsO, title):
  VVY9NT = []
  for fName in os.listdir(VVPUYO):
   path = os.path.join(VVPUYO, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVY9NT.append((fName, path))
  VVY9NT.sort(key=lambda x: x[0].lower())
  if VVY9NT : FFaJ04(self, BF(self.VV8AI5, VV5PsO, title), VVY9NT=VVY9NT, title=title, minRows=3, VVU4bo="#11220000", VVdq78="#11220000")
  else  : FFh60c(self, "No valid files found in:\n\n%s" % VVPUYO, title=title)
 def VV8AI5(self, VV5PsO, title, path=None):
  if path:
   if CCVdBH.VVljcj(path):
    FFh60c(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFun41(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFoBdB(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFoBdB(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVHOHE(VV5PsO)
      break
    else:
     FFh60c(self, "File is empty:\n\n%s" % path, title=title)
 def VVgjEr(self, VV5PsO):
  if VV5PsO.VVSQQE : VV5PsO.VVxErJ()
  else        : VV5PsO.VVEejY()
 def VVbZ4k(self, isHistory, VV5PsO, title, txt, colList):
  if VV5PsO.VVSQQE:
   lst = VV5PsO.VVETD3(1)
   curNdx = VV5PsO.VVOekD()
  else:
   lst = [colList[1]]
   curNdx = VV5PsO.VV3w14()
  if not isHistory:
   FFoBdB(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VV5PsO.cancel()
  FFcigO(self.VVlWVr)
 def VVlWVr(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVR8eD("\n%s\n" % cmd, 6)
    self.VVR8eD(self.prompt, 1)
    self.VVlWVr()
   else:
    self.VVsplu(cmd)
 def VVsplu(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVR8eD(cmd, 2)
   self.VVR8eD("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVR8eD(ch, 0)
   self.VVR8eD("\nor\n", 4)
   self.VVR8eD("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVXm06()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFbRJw(parts[0].strip(), VV619a)
    right = FFbRJw("#" + parts[1].strip(), VVtUHQ)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVR8eD(txt, 2)
   lastLine = self.VVOfpl()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV3x1G(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVVPE0, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFh60c(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVR8eD(data, 3)
 def VVVPE0(self, data, retval):
  if not retval == 0:
   self.VVR8eD("Exit Code : %d\n" % retval, 4)
  self.VVXm06()
  if self.commandsList:
   self.VVlWVr()
 def VVsfAU(self, VV5PsO, title, txt, colList):
  if VV5PsO.VVPPRT():
   cmd = colList[1]
   self.VVeH3w(VV5PsO, cmd)
 def VVB6Ys(self, VV5PsO, title, txt, colList):
  FFe4rI(self, BF(self.VVkHA3, VV5PsO), "Reset History File ?", title="Command History")
 def VVkHA3(self, VV5PsO):
  os.system(FF75pk("echo '' > %s" % self.commandHistoryFile))
  VV5PsO.cancel()
 def VVscsA(self, filePath, VV5PsO, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCbHA8(self, filePath, VVsfO0=BF(self.VVTvOK, VV5PsO), curRowNum=rowNum)
  else     : FFCpVp(self, filePath)
 def VVTvOK(self, VV5PsO, fileChanged):
  if fileChanged:
   VV5PsO.cancel()
   FFcigO(self.VVHOHE)
 def VVY0Q9(self):
  self.VVeH3w(None, self.lastCommand)
 def VVeH3w(self, VV5PsO, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF5ZDh(self, BF(self.VV2v0B, VV5PsO), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VV2v0B(self, VV5PsO, cmd):
  if cmd and len(cmd) > 0:
   self.VVsplu(cmd)
   if VV5PsO:
    VV5PsO.cancel()
class CCqAwn(Screen):
 def __init__(self, session, title="", message="", VVQY0S=VVT5lQ, width=1400, height=900, VVMebt=False, titleBg="#22002020", VVWGqy="#22001122", VVfp7o=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFWDRO(VVKV47, width, height, titleFontSize, 30, 20, titleBg, VVWGqy, VVfp7o)
  self.session   = session
  FFsd9n(self, title, addScrollLabel=True)
  self.VVQY0S   = VVQY0S
  self.VVMebt   = VVMebt
  self.VVWGqy   = VVWGqy
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self["myLabel"].VVxoM0(VVMebt=self.VVMebt, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVQY0S)
  self["myLabel"].VVDPfH()
class CCJVXf(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFWDRO(VV6FtF, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFsd9n(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFSGau(self["errPic"], "err")
class CCc3YV(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFWDRO(VVFovP, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFsd9n(self, " ", addCloser=True)
class CCtonn():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.win = session.instantiateDialog(CCc3YV, txt, fonSize)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FF5Gbi(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVhjRQ)
  except:
   self.timer.callback.append(self.VVhjRQ)
  self.timer.start(timeout, True)
 def VVhjRQ(self):
  self.session.deleteDialog(self.win)
class CCPWpb():
 VVQA5X    = 0
 VV47M3  = 1
 VVBM0M   = ""
 VVV2Zy    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VV5PsO   = None
  self.timer     = eTimer()
  self.VV6eia   = 0
  self.VVMNkd  = 1
  self.VVUfnU  = 2
  self.VVQLfr   = 3
  self.VV9PgJ   = 4
  VVJnaJ = self.VVtykW()
  if VVJnaJ:
   self.VV5PsO = self.VVJWIP(VVJnaJ)
  if not VVJnaJ and mode == self.VVQA5X:
   self.VVELFw("Download list is empty !")
   self.cancel()
  if mode == self.VV47M3:
   FFDKj1(self.VV5PsO or self.SELF, BF(self.VVI7Ze, startDnld, decodedUrl), title="Checking Server ...")
  self.VV2H75(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV2H75)
  except:
   self.timer.callback.append(self.VV2H75)
  self.timer.start(1000, False)
 def VVJWIP(self, VVJnaJ):
  VVJnaJ.sort(key=lambda x: int(x[0]))
  VVo9Gm = self.VVHPew
  VVNiXY  = ("Play"  , self.VV6iq2 , [])
  VVo8Jh = (""   , self.VVhx5U  , [])
  VVNxWT = ("Stop"  , self.VVlMH2  , [])
  VVY2vy = ("Resume"  , self.VV4Omw , [])
  VVuKTt = ("Options" , self.VVqL9W  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV3dzh  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFXBR7(self.SELF, None, title=self.Title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVNiXY=VVNiXY, VVo8Jh=VVo8Jh, VVo9Gm=VVo9Gm, VVNxWT=VVNxWT, VVY2vy=VVY2vy, VVuKTt=VVuKTt, lastFindConfigObj=CFG.lastFindIptv, VVU4bo="#11220022", VVdq78="#11110011", VVWGqy="#11110011", VVjOuo="#00ffff00", VVpoY2="#00223025", VVUWnf="#0a333333", VVwS5R="#0a400040", VVcNyk=True, searchCol=1)
 def VVtykW(self):
  lines = CCPWpb.VVA3Uo()
  VVJnaJ = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVnwvA(decodedUrl)
      if fName:
       if   FFHZVk(decodedUrl) : sType = "Movie"
       elif FFCYCF(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVenSH(decodedUrl, fName)
       if size > -1: sizeTxt = CCVdBH.VVFJRm(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVJnaJ.append((str(len(VVJnaJ) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVJnaJ
 def VVx1Cj(self):
  VVJnaJ = self.VVtykW()
  if VVJnaJ:
   if self.VV5PsO : self.VV5PsO.VVQNRz(VVJnaJ, VVbcbWMsg=False)
   else     : self.VV5PsO = self.VVJWIP(VVJnaJ)
  else:
   self.cancel()
 def VV2H75(self, force=False):
  if self.VV5PsO:
   thrListUrls = self.VVtzB5()
   VVJnaJ = []
   changed = False
   for ndx, row in enumerate(self.VV5PsO.VVexgG()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV6eia
    if m3u8Log:
     percent = CCPWpb.VVtWOQ(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVQLfr , "%.2f %%" % percent
      else   : flag, progr = self.VV9PgJ , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFtDuT(mPath)
     if curSize > -1:
      fSize = CCVdBH.VVFJRm(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCVdBH.VVFJRm(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFtDuT(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVQLfr , "%.2f %%" % percent
       else   : flag, progr = self.VV9PgJ , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCVdBH.VVFJRm(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVUfnU
     if m3u8Log :
      if not speed and not force : flag = self.VVMNkd
      elif curSize == -1   : self.VVcRMB(False)
    elif flag == self.VV6eia  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV6eia  : color2 = "#f#00555555#"
    elif flag == self.VVMNkd : color2 = "#f#0000FFFF#"
    elif flag == self.VVUfnU : color2 = "#f#0000FFFF#"
    elif flag == self.VVQLfr  : color2 = "#f#00FF8000#"
    elif flag == self.VV9PgJ  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVwInu(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVJnaJ.append(row)
   if changed or force:
    self.VV5PsO.VVQNRz(VVJnaJ, VVbcbWMsg=False)
 def VVwInu(self, flag):
  tDict = self.VVWUuN()
  return tDict.get(flag, "?")
 def VVcNkt(self, state):
  for flag, txt in self.VVWUuN().items():
   if txt == state:
    return flag
  return -1
 def VVWUuN(self):
  return { self.VV6eia: "Not started", self.VVMNkd: "Connecting", self.VVUfnU: "Downloading", self.VVQLfr: "Stopped", self.VV9PgJ: "Completed" }
 def VVaFUr(self, title):
  colList = self.VV5PsO.VVkll0()
  path = colList[6]
  url  = colList[8]
  if self.VVzvu0() : self.VVELFw("Cannot delete !\n\nFile is downloading.")
  else      : FFe4rI(self.SELF, BF(self.VVAOgE, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVAOgE(self, path, url):
  m3u8Log = self.VV5PsO.VVkll0()[12]
  if m3u8Log : os.system(FF75pk("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FF75pk("rm -r '%s'" % path))
  self.VVi2pF(False)
  self.VVx1Cj()
 def VVi2pF(self, VVyRz1=True):
  if self.VVzvu0():
   FFZWPu(self.VV5PsO, self.VVwInu(self.VVUfnU), 500)
  else:
   colList  = self.VV5PsO.VVkll0()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVcNkt(state) in (self.VV6eia, self.VV9PgJ, self.VVQLfr):
    lines = CCPWpb.VVA3Uo()
    newLines = []
    found = False
    for line in lines:
     if CCPWpb.VVHXwu(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVvm9S(newLines)
     self.VVx1Cj()
     FFZWPu(self.VV5PsO, "Removed.", 1000)
    else:
     FFZWPu(self.VV5PsO, "Not found.", 1000)
   elif VVyRz1:
    self.VVELFw("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVtyNs(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFe4rI(self.SELF, BF(self.VVPxZu, flag), ques, title=title)
 def VVPxZu(self, flag):
  list = []
  for ndx, row in enumerate(self.VV5PsO.VVexgG()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVcNkt(state)
   if   flag == flagVal == self.VV9PgJ: list.append(decodedUrl)
   elif flag == flagVal == self.VV6eia : list.append(decodedUrl)
  lines = CCPWpb.VVA3Uo()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVvm9S(newLines)
   self.VVx1Cj()
   FFZWPu(self.VV5PsO, "%d removed." % totRem, 1000)
  else:
   FFZWPu(self.VV5PsO, "Not found.", 1000)
 def VVTAsE(self):
  colList  = self.VV5PsO.VVkll0()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFZWPu(self.VV5PsO, "Poster exists", 1500)
  else    : FFDKj1(self.VV5PsO, BF(self.VVHudr, decodedUrl, path, png), title="Checking Server ...")
 def VVHudr(self, decodedUrl, path, png):
  err = self.VVnBOr(decodedUrl, path, png)
  if err:
   FFh60c(self.SELF, err, title="Poster Download")
 def VVnBOr(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCQ0t1.VVFJfy(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCHli4.VVBGBM(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCHli4.VVgnJH(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCHli4.VVCns1(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFzm7R(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FF75pk("mv -f '%s' '%s'" % (tPath, png)))
   CCG5Yr.VV12Wn(self.SELF, VVPYo2=png, showGrnMsg="Downloaded")
   return ""
 def VVhx5U(self, VV5PsO, title, txt, colList):
  def VVmzbD(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVg0pA(key, val) : return "\n%s:\n%s\n" % (FFbRJw(key, VVmuI1), val.strip())
  heads  = self.VV5PsO.VVFYOn()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVmzbD(heads[i]  , CCVdBH.VVFJRm(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVmzbD("Downloaded" , CCVdBH.VVFJRm(int(curSize), mode=0))
   else:
    txt += VVmzbD(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVg0pA(heads[i], colList[i])
  FFHdWy(self.SELF, txt, title=title)
 def VV6iq2(self, VV5PsO, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCVdBH.VVe3wa(self.SELF, path)
  else    : FFZWPu(self.VV5PsO, "File not found", 1000)
 def VVHPew(self, VV5PsO):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VV5PsO:
   self.VV5PsO.cancel()
  del self
 def VVqL9W(self, VV5PsO, title, txt, colList):
  c1, c2, c3 = VVFaDd, VVLO3F, VVmuI1
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVY9NT = []
  VVY9NT.append((c1 + "Remove current row"       , "VVi2pF" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVY9NT.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c2 + "Delete the file (and remove from list)"  , "VVaFUr"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((resumeTxt + " Auto Resume"       , "VVTFat" ))
  VVY9NT.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVY9NT.append(VVXMhc)
  t = "Download Movie Poster "
  if FFHZVk(decodedUrl): VVY9NT.append((c3 + "%s(from server)" % t , "VVTAsE"  ))
  else      : VVY9NT.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVY9NT.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVY9NT.append(("Open in File Manager"  ,      ))
  FFaJ04(self.SELF, BF(self.VVXGMx, VV5PsO), VVY9NT=VVY9NT, title=self.Title, VVNDcU=True, width=800, VVFP3k=True, VVU4bo="#1a001122", VVdq78="#1a001122")
 def VVXGMx(self, VV5PsO, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVi2pF"  : self.VVi2pF()
   elif ref == "remFinished"   : self.VVtyNs(self.VV9PgJ, txt)
   elif ref == "remPending"   : self.VVtyNs(self.VV6eia, txt)
   elif ref == "VVaFUr" : self.VVaFUr(txt)
   elif ref == "VVTAsE"  : self.VVTAsE()
   elif ref == "VVTFat"  : FFoBdB(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFoBdB(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCVdBH, mode=CCVdBH.VVzfS9, jumpToFile=path)
    else    : FFZWPu(VV5PsO, "Path not found !", 1500)
 def VVI7Ze(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCQ0t1.VVFJfy(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVELFw("Could not get download link !\n\nTry again later.")
     return
  for line in CCPWpb.VVA3Uo():
   if CCPWpb.VVHXwu(decodedUrl, line):
    if self.VV5PsO:
     self.VVb4BP(decodedUrl)
     FFcigO(BF(FFZWPu, self.VV5PsO, "Already listed !", 2000))
    break
  else:
   params = self.VVoq1y(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVELFw(params[0])
   elif len(params) == 2:
    FFe4rI(self.SELF, BF(self.VVQkDE, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCVdBH.VVFJRm(fSize)
    FFe4rI(self.SELF, BF(self.VV8q7y, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV8q7y(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCPWpb.VViHOW(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVx1Cj()
  if self.VV5PsO:
   self.VV5PsO.VVqv7q()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCPWpb.VVV2Zy, path, decodedUrl)
   self.VVk7a0(threadName, url, decodedUrl, path, resp)
 def VVb4BP(self, decodedUrl):
  if self.VV5PsO:
   for ndx, row in enumerate(self.VV5PsO.VVexgG()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VV5PsO:
     self.VV5PsO.VVyOnh(ndx)
     break
 def VVoq1y(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVnwvA(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVenSH(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCQ0t1.VVFJfy(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCQ0t1.VVR1NX()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCPWpb.VVCRm0(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCPWpb.VVF7dv(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVQkDE(self, resp, decodedUrl):
  if not os.system(FF75pk("which ffmpeg")) == 0:
   FFe4rI(self.SELF, BF(CCHli4.VVGbqB, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVnwvA(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVSsZi(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFe4rI(self.SELF, BF(self.VVMjYB, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVMjYB(rTxt, rUrl)
  else:
   self.VVELFw("Cannot process m3u8 file !")
 def VVSsZi(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVY9NT = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCHli4.VVCX17(rUrl, fPath)
   VVY9NT.append((resol, fullUrl))
  if VVY9NT:
   FFaJ04(self.SELF, self.VVphC0, VVY9NT=VVY9NT, title="Resolution", VVNDcU=True, VVFP3k=True)
  else:
   self.VVELFw("Cannot get Resolutions list from server !")
 def VVphC0(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFe4rI(self.SELF, BF(FFcigO, BF(self.VVMsab, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFcigO(BF(self.VVMsab, resolUrl))
 def VVMsab(self, resolUrl):
  txt, err = CCQ0t1.VVYnhy(resolUrl)
  if err : self.VVELFw(err)
  else : self.VVMjYB(txt, resolUrl)
 def VV4L00(self, logF, decodedUrl):
  found = False
  lines = CCPWpb.VVA3Uo()
  with open(CCPWpb.VViHOW(), "w") as f:
   for line in lines:
    if CCPWpb.VVHXwu(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCPWpb.VViHOW(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVx1Cj()
  if self.VV5PsO:
   self.VV5PsO.VVqv7q()
 def VVMjYB(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCHli4.VVCX17(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVELFw("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV4L00(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FF75pk("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCPWpb.VVV2Zy, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVtWOQ(dnldLog):
  if fileExists(dnldLog):
   dur = CCPWpb.VVqSlz(dnldLog)
   if dur > -1:
    tim = CCPWpb.VVM2MC(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVqSlz(dnldLog):
  lines = FFLYXX("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVM2MC(dnldLog):
  lines = FFLYXX("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVenSH(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFCYCF(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FF75pk("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVk7a0(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VV5PsO.VVkll0()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVlYxr, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVlYxr(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVBM0M == path:
       break
     else:
      break
  except:
   return
  if CCPWpb.VVBM0M:
   CCPWpb.VVBM0M = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFtDuT(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVoq1y(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVlYxr(url, decodedUrl, path, resp, totFileSize, True)
 def VVlMH2(self, VV5PsO, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVqShW() : FFZWPu(self.VV5PsO, self.VVwInu(self.VV9PgJ), 500)
  elif not self.VVzvu0() : FFZWPu(self.VV5PsO, self.VVwInu(self.VVQLfr), 500)
  elif m3u8Log      : FFe4rI(self.SELF, self.VVcRMB, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVtzB5():
    CCPWpb.VVBM0M = colList[6]
    FFZWPu(self.VV5PsO, "Stopping ...", 1000)
   else:
    FFZWPu(self.VV5PsO, "Stopped", 500)
 def VVcRMB(self, withMsg=True):
  if withMsg:
   FFZWPu(self.VV5PsO, "Stopping ...", 1000)
  os.system(FF75pk("killall -INT ffmpeg"))
 def VV4Omw(self, *args):
  if   self.VVqShW() : FFZWPu(self.VV5PsO, self.VVwInu(self.VV9PgJ) , 500)
  elif self.VVzvu0() : FFZWPu(self.VV5PsO, self.VVwInu(self.VVUfnU), 500)
  else:
   resume = False
   m3u8Log = self.VV5PsO.VVkll0()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFe4rI(self.SELF, BF(self.VVPHc9, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVXbSa():
    resume = True
   if resume: FFDKj1(self.VV5PsO, BF(self.VVczgG), title="Checking Server ...")
   else  : FFZWPu(self.VV5PsO, "Cannot resume !", 500)
 def VVPHc9(self, m3u8Log):
  os.system(FF75pk("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFDKj1(self.VV5PsO, BF(self.VVczgG), title="Checking Server ...")
 def VVczgG(self):
  colList  = self.VV5PsO.VVkll0()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCQ0t1.VVFJfy(decodedUrl)
   if url:
    decodedUrl = self.VVXTRG(decodedUrl, url)
   else:
    self.VVELFw("Could not get download link !\n\nTry again later.")
    return
  curSize = FFtDuT(path)
  params = self.VVoq1y(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVELFw(params[0])
   return
  elif len(params) == 2:
   self.VVQkDE(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVXTRG(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCPWpb.VVV2Zy, path, decodedUrl)
  if resumable: self.VVk7a0(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVELFw("Cannot resume from server !")
 def VVnwvA(self, decodedUrl):
  fileExt = CCHli4.VVlvSy(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFxp0h(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVELFw(self, txt):
  FFh60c(self.SELF, txt, title=self.Title)
 def VVtzB5(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCPWpb.VVV2Zy, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVzvu0(self):
  decodedUrl = self.VV5PsO.VVkll0()[9]
  return decodedUrl in self.VVtzB5()
 def VVqShW(self):
  colList = self.VV5PsO.VVkll0()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFtDuT(path)) == size
 def VVXbSa(self):
  colList = self.VV5PsO.VVkll0()
  path = colList[6]
  size = int(colList[7])
  curSize = FFtDuT(path)
  if curSize > -1:
   size -= curSize
  err = CCPWpb.VVF7dv(size)
  if err:
   FFh60c(self.SELF, err, title=self.Title)
   return False
  return True
 def VVvm9S(self, list):
  with open(CCPWpb.VViHOW(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVXTRG(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCPWpb.VVA3Uo()
  url = decodedUrl
  with open(CCPWpb.VViHOW(), "w") as f:
   for line in lines:
    if CCPWpb.VVHXwu(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVx1Cj()
  return url
 @staticmethod
 def VVA3Uo():
  list = []
  if fileExists(CCPWpb.VViHOW()):
   for line in FFun41(CCPWpb.VViHOW()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVHXwu(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVF7dv(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCVdBH.VVnPRW(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCVdBH.VVFJRm(size), CCVdBH.VVFJRm(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVNdTb(SELF):
  tot = CCPWpb.VVmwfb()
  if tot:
   FFh60c(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVmwfb():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCPWpb.VVV2Zy):
    c += 1
  return c
 @staticmethod
 def VVMKM1():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCPWpb.VVV2Zy, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVBS71():
  return len(CCPWpb.VVA3Uo()) == 0
 @staticmethod
 def VVYnrH():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VV4J6u():
  mPoints = CCPWpb.VVYnrH()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FF75pk("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VViHOW():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVmwfS(SELF):
  CCPWpb.VV5Ikz(SELF, CCPWpb.VVQA5X)
 @staticmethod
 def VVxUVW(SELF):
  CCPWpb.VV5Ikz(SELF, CCPWpb.VV47M3, startDnld=True)
 @staticmethod
 def VVtaF9(SELF, url):
  CCPWpb.VV5Ikz(SELF, CCPWpb.VV47M3, startDnld=True, decodedUrl=url)
 @staticmethod
 def VV6601(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF)
  added, skipped = CCPWpb.VV4e8S([decodedUrl])
  FFZWPu(SELF, "Added", 1000)
 @staticmethod
 def VV4e8S(list):
  added = skipped = 0
  for line in CCPWpb.VVA3Uo():
   for ndx, url in enumerate(list):
    if url and CCPWpb.VVHXwu(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCPWpb.VViHOW(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV5Ikz(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCWQxC.VVTp8Y(SELF):
   return
  if mode == CCPWpb.VVQA5X and CCPWpb.VVBS71():
   FFh60c(SELF, "Download list is empty !", title=title)
  else:
   inst = CCPWpb(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVCRm0(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CC0rhb(Screen, CCNJgc):
 VVuHV5 = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFWDRO(VVAn5e, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCNJgc.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFsd9n(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVUXiy())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVz6TU       ,
   "info"  : self.VVB9Du      ,
   "epg"  : self.VVB9Du      ,
   "menu"  : self.VVk8v8     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVuc8x   ,
   "green"  : self.VVHUuD  ,
   "blue"  : self.VVUNeZ      ,
   "yellow" : self.VVZVB3 ,
   "left"  : BF(self.VVQOZm, -1)    ,
   "right"  : BF(self.VVQOZm,  1)    ,
   "play"  : self.VVguWI      ,
   "pause"  : self.VVguWI      ,
   "playPause" : self.VVguWI      ,
   "stop"  : self.VVguWI      ,
   "rewind" : self.VVVuvG      ,
   "forward" : self.VVIxaL      ,
   "rewindDm" : self.VVVuvG      ,
   "forwardDm" : self.VVIxaL      ,
   "last"  : self.VVGRxz      ,
   "next"  : self.VVTj6J      ,
   "pageUp" : BF(self.VVQHgb, True)  ,
   "pageDown" : BF(self.VVQHgb, False)  ,
   "chanUp" : BF(self.VVQHgb, True)  ,
   "chanDown" : BF(self.VVQHgb, False)  ,
   "up"  : BF(self.VVQHgb, True)  ,
   "down"  : BF(self.VVQHgb, False)  ,
   "audio"  : BF(self.VVkvHm, True)  ,
   "subtitle" : BF(self.VVkvHm, False)  ,
   "text"  : self.VVrWdc  ,
   "0"   : BF(self.VVUJTE , 10)   ,
   "1"   : BF(self.VVUJTE , 1)   ,
   "2"   : BF(self.VVUJTE , 2)   ,
   "3"   : BF(self.VVUJTE , 3)   ,
   "4"   : BF(self.VVUJTE , 4)   ,
   "5"   : BF(self.VVUJTE , 5)   ,
   "6"   : BF(self.VVUJTE , 6)   ,
   "7"   : BF(self.VVUJTE , 7)   ,
   "8"   : BF(self.VVUJTE , 8)   ,
   "9"   : BF(self.VVUJTE , 9)
  }, -1)
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  if not CC0rhb.VVuHV5:
   CC0rhb.VVuHV5 = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFSGau(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFSGau(self["myPlayRpt"], "rpt")
  self.VV7vre()
  self.instance.move(ePoint(40, 40))
  self.VVqPHw(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVP1iz)
  except:
   self.timer.callback.append(self.VVP1iz)
  self.timer.start(250, False)
  self.VVP1iz("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVCBQp()
 def VVHUuD(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  self.lastSubtitle = CC88r6.VV8xrD()
  if "chCode" in iptvRef:
   if CCWQxC.VVTp8Y(self):
    self.VVCBQp(True)
  else:
   self.VVP1iz("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VV7vre(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwAH0()
  chName = FFUkF8(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVxsyh + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFRkaP(self["myTitle"], tColor)
  FFRkaP(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFRkaP(self["myPlay%s" % item], tColor)
  picFile = CC8xkn.VV0iot(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CC8xkn.VVhaUo(self)
  cl = CCbSSH.VVZDD9(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVP1iz(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCPWpb.VVmwfb()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwAH0()
  if evName:
   evName = "    %s    " % FFbRJw(evName, VVlhbS)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVnwOH():
   FFR9H9(self["myPlayBlu"], "#00FFFFFF")
   FFRkaP(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFR9H9(self["myPlayBlu"], "#00FFFF88")
   FFRkaP(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCHli4.VV3EYE(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVtUHQ + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFRkaP(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFiWjh(percVal, 0, 100)
   width = int(FFo5AX(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFRkaP(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFR9H9(self["myPlayMsg"], "#0000ffff")
   else  : FFR9H9(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFR9H9(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFR9H9(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV3XyW()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVHLeL(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CC88r6.VVZq6I(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVGRxz()
  state = self.VVMuvE()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFR9H9(self["myPlayMsg"], "#0000ff00")
  else     : FFR9H9(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVwAH0(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF02Rs(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CC8xkn.VVWLqa(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCsRkT()
   tpTxt, satTxt = tp.VVv59C(refCode)
   self.satInfo_TP = tpTxt + "  " + FFbRJw(satTxt, VVDopz)
  evName = evNameNext = ""
  evLst = CCI7Ct.VVmMR6(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFVMAI(info, iServiceInformation.sVideoWidth) or -1
   h = FFVMAI(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFVMAI(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CC8xkn.VVJTNX(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVEzEe(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF8ZP4(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF8ZP4(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FF8ZP4(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVk8v8(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwAH0()
  FFHZVkSeries = FFxp0h(decodedUrl)
  VVY9NT = []
  if self.isFromExternal:
   VVY9NT.append((VVDopz + "IPTV Menu", "iptv"))
   VVY9NT.append(VVXMhc)
  if isIptv and not "&end=" in decodedUrl and not FFHZVkSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCHli4.VVBGBM(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVY9NT.append((VVDopz + "Catchup Programs", "catchup" ))
    VVY9NT.append(VVXMhc)
  if refCode:
   c = VVxsyh
   VVY9NT.append((c + "Stop Current Service"  , "stop"  ))
   VVY9NT.append((c + "Restart Current Service" , "restart"  ))
   txt = "Replay with ..."
   if isDvb: VVY9NT.append((txt     ,    ))
   else : VVY9NT.append((c + txt    , "replayWith" ))
   VVY9NT.append(VVXMhc)
  if FFHZVkSeries:
   VVY9NT.append((VVDopz + "File Size (on server)", "fileSize" ))
   VVY9NT.append(VVXMhc)
  if self.enableDownloadMenu:
   c = VVDopz
   addSep = False
   if isIptv and FFHZVkSeries:
    VVY9NT.append((c + "Start Download"  , "dload_cur" ))
    VVY9NT.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCPWpb.VVBS71():
    VVY9NT.append((VVDopz + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVY9NT.append(VVXMhc)
  fPath, fDir, fName = CCVdBH.VV950I(self)
  if fPath:
   c = VVPWV9
   if self.enableOpenInFMan and not CCVdBH.VVkF4O:
    VVY9NT.append((c + "Open path in File Manager", "VVVHFq"))
   VVY9NT.append((c + "Add to Bouquet"             , "VV3TfL" ))
   VVY9NT.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVvHOT"  ))
   VVY9NT.append(VVXMhc)
  elif isFtp:
   VVY9NT.append((VVmuI1 + "Add FTP Media to Bouquet"     , "VVa9yq"))
  if isDvb:
   VVY9NT.append((VVDopz + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVY9NT.append((VVmuI1 + "Start Subtitle", "VV39WC"))
   VVY9NT.append(VVXMhc)
  if CFG.playerPos.getValue() : VVY9NT.append(("Move Bar to Bottom" , "botm"))
  else      : VVY9NT.append(("Move Bar to Top" , "top" ))
  VVY9NT.append(("Help", "help"))
  FFaJ04(self, self.VVjkmb, VVY9NT=VVY9NT, width=600, title="Options")
 def VVjkmb(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVZVB3()
   elif item == "stop"     : self.VVMDWi(0)
   elif item == "restart"    : self.VVMDWi(1)
   elif item == "replayWith"   : self.VVQ0wN()
   elif item == "fileSize"    : FFDKj1(self, BF(CC8xkn.VVe18A, self), title="Checking Server")
   elif item == "dload_cur"   : CCPWpb.VVxUVW(self)
   elif item == "addToDload"   : CCPWpb.VV6601(self)
   elif item == "dload_stat"   : CCPWpb.VVmwfS(self)
   elif item == "VVVHFq" : self.close("close_openInFileMan")
   elif item == "VV3TfL" : self.VV3TfL()
   elif item == "VVa9yq" : self.VVa9yq()
   elif item == "VV39WC"  : self.VVY4eo()
   elif item == "VVvHOT"  : self.VVvHOT()
   elif item == "botm"     : self.VVqPHw(0)
   elif item == "top"     : self.VVqPHw(1)
   elif item == "sigMon"    : self.VVuc8x()
   elif item == "help"     : FFv9kY(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CC0rhb.VVuHV5 = None
 def VVMDWi(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VV7vre()
   elif typ == 1:
    self.VVP1iz("Restarting Service ...")
    FFcigO(BF(self.VVp7Px, serv))
 def VVp7Px(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  if "&end=" in decodedUrl: BF(self.VVCBQp, True)
  else     : self.session.nav.playService(serv)
 def VVQ0wN(self):
  FFaJ04(self, self.VVPBnJ, VVY9NT=CCHli4.VVtiEZ(), width=650, title="Select Player", VVU4bo="#11220000", VVdq78="#11220000")
 def VVPBnJ(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFR47V(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVP1iz("No active service !")
 def VV3TfL(self):
  fPath, fDir, fName = CCVdBH.VV950I(self)
  if fPath: picker = CCgBRx(self, self, "Add Current Movie to a Bouquet", BF(self.VV7kgt, [fPath]))
  else : FFZWPu(self, "Path not found !", 1500)
 def VV7kgt(self, pathLst):
  return CCgBRx.VV4usi(pathLst)
 def VVa9yq(self):
  picker = CCgBRx(self, self, "Add FTP Media to Bouquet", self.VVF7g9)
 def VVF7g9(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  return CCgBRx.VV4usi([origUrl], rType=refCode.split(":", 1)[0])
 def VVvHOT(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVP1iz(txt, highlight=ok)
 def VVqPHw(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFoBdB(CFG.playerPos, pos)
 def VVuc8x(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CC8xkn.VVWLqa(serv)
   if isDvb: self.close("close_sig")
   else : self.VVP1iz("No Signal for Current Service")
 def VVY4eo(self):
  self.session.openWithCallback(self.VVGxLf, BF(CC88r6))
 def VVrWdc(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwAH0()
   if posTxt and durTxt: self.VVY4eo()
   else    : self.VVP1iz("No duration Info. !")
 def VVGxLf(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVQHgb(True)
  elif reason == "subtZapDn" : self.VVQHgb(False)
  elif reason == "pause"  : self.VVguWI()
  elif reason == "audio"  : self.VVkvHm(True)
  elif reason == "subtitle" : self.VVkvHm(False)
  elif reason == "rewind"     : self.VVVuvG()
  elif reason == "forward" : self.VVIxaL()
  elif reason == "rewindDm" : self.VVVuvG()
  elif reason == "forwardDm" : self.VVIxaL()
  else      : txt = reason
  if txt:
   FFZWPu(self, txt, 2000)
 def VVz6TU(self):
  if self.isManualSeek:
   self.VVjiK8()
   self.VVHLeL(self.manualSeekPts)
  elif self.shown:
   if CC88r6.VVs8Sf(self): self.VVY4eo()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVjiK8()
  else    : self.close()
 def VVB9Du(self):
  FFuQxT(self, fncMode=CC8xkn.VVByzx)
 def VVguWI(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVP1iz("Toggling Play/Pause ...")
 def VVjiK8(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVQOZm(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VV1bwg()
   else:
    self.manualSeekSec += direc * self.VV1bwg()
    self.manualSeekSec = FFiWjh(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFo5AX(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FF8ZP4(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVUJTE(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVUXiy())
   FFoBdB(CFG.playerJumpMin, self.jumpMinutes)
  self.VVP1iz("Changed Seek Time to : %d%s" % (val, self.VVGk4c()))
 def VVUXiy(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVGk4c())
 def VVGk4c(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVXk1B(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VV1bwg(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV3XyW(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVUNeZ(self):
  cList = self.VVnwOH()
  if cList:
   VVY9NT = []
   for pts, what in cList:
    txt = FF8ZP4(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVY9NT.append((txt, pts))
   FFaJ04(self, self.VVfBLd, VVY9NT=VVY9NT, title="Cut List")
  else:
   self.VVP1iz("No Cut-List for this channel !")
 def VVfBLd(self, item=None):
  if item:
   self.VVHLeL(item)
 def VVnwOH(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVIxaL(self) : self.VViyhd(1)
 def VVVuvG(self) : self.VViyhd(-1)
 def VViyhd(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VV1bwg() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVXk1B())
    self.VVP1iz(txt)
  except:
   self.VVP1iz("Cannot jump")
 def VVHLeL(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVP1iz("Changing Time ...")
 def VVGRxz(self):
  self.VVMDWi(1)
  self.VVP1iz("Replaying ...")
  self.VVjiK8()
 def VVTj6J(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVP1iz("Jumping to end ...")
  except:
   pass
 def VVMuvE(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVQHgb(self, isUp):
  if self.enableZapping:
   self.VVP1iz("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVjiK8()
   if self.iptvTableParams:
    FFcigO(BF(self.VVaoe2, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
    if "/timeshift/" in decodedUrl:
     self.VVP1iz("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVfu1u()
  else:
   self.VVP1iz("Zap Disabled !")
 def VVfu1u(self):
  self.lastPlayPos = 0
  self.VV7vre()
  self.VVCBQp()
 def VVaoe2(self, isUp):
  CCHli4_inatance, VV5PsO, mode = self.iptvTableParams
  if isUp : VV5PsO.VV8aKe()
  else : VV5PsO.VVIiCj()
  colList = VV5PsO.VVkll0()
  if mode == "localIptv":
   chName, chUrl = CCHli4_inatance.VVeRzi(VV5PsO, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCHli4_inatance.VV9Afe(VV5PsO, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCHli4_inatance.VVtMBC(mode, VV5PsO, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCHli4_inatance.VVi8eb(mode, VV5PsO, colList)
  else:
   self.VVP1iz("Cannot Zap")
   return
  FFqoI8(self, chUrl, VVLrHC=False)
  self.VVfu1u()
 def VVCBQp(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
   if not self.VVVvef(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVP1iz("Refreshing Portal")
   FFcigO(self.VVLcRK)
  except:
   pass
 def VVLcRK(self):
  self.restoreLastPlayPos = self.VVt6FJ()
 def VVZVB3(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
  if not decodedUrl or FFxp0h(decodedUrl):
   self.VVP1iz("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCHli4.VVBGBM(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVP1iz("Reading Program List ...")
   ok_fnc = BF(self.VV5K4o, refCode, chName, streamId, uHost, uUser, uPass)
   FFcigO(BF(CCHli4.VV9tkY, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVP1iz("Cannot process this channel")
 def VV5K4o(self, refCode, chName, streamId, uHost, uUser, uPass, VV5PsO, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VV5PsO.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVP1iz("Changing Program ...")
   FFcigO(BF(self.VVoX8J, chUrl))
  else:
   self.VVP1iz("Incorrect Timestamp !")
 def VVoX8J(self, chUrl):
  FFqoI8(self, chUrl, VVLrHC=False)
  self.lastPlayPos = 0
  self.VV7vre()
 def VVkvHm(self, isAudio):
  try:
   VVXVyg = InfoBar.instance
   if VVXVyg:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVXVyg)
    else  : self.session.open(SubtitleSelection, VVXVyg)
  except:
   pass
 @staticmethod
 def VVant0(session, mode=None):
  if   mode == "close_sig"   : FFhpkO(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCHli4)
  elif mode == "close_openInFileMan" : session.open(CCVdBH, gotoMovie=True)
 @staticmethod
 def VVpY9t(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CC0rhb.VVant0, session), CC0rhb, isFromExternal=isFromExternal, **kwargs)
class CCoKTm(Screen):
 def __init__(self, session, title="", VVT00f="Continue?", VVmqJ5=True, VVRAK2=False):
  self.skin, self.skinParam = FFWDRO(VVRHe2, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVT00f = VVT00f
  self.VVRAK2 = VVRAK2
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVmqJ5 : VVY9NT = [no , yes]
  else   : VVY9NT = [yes, no ]
  FFsd9n(self, title, VVY9NT=VVY9NT, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVz6TU ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVT00f)
  if self.VVRAK2:
   self["myLabel"].instance.setHAlign(0)
  self.VVnucX()
  FFR6rJ(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFRQX6(self["myMenu"])
  FFaVeS(self, self["myMenu"])
 def VVz6TU(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVnucX(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC9Nqc(Screen):
 def __init__(self, session, title="", VVY9NT=None, width=1000, height=850, VVfp7o=30, barText="", minRows=1, OKBtnFnc=None, infoBtnFnc=None, VVtVox=None, VV0Xwe=None, VVMxmU=None, VV8vtf=None, VVNDcU=False, VVFP3k=False, yellowBasePath=None, rcuSearch=True, VVU4bo="#22003344", VVdq78="#22002233"):
  self.skin, self.skinParam = FFWDRO(VVG5k0, width, height, 50, 40, 30, VVU4bo, VVdq78, VVfp7o, barHeight=40, topRightBtns=3 if infoBtnFnc else 0)
  self.session   = session
  self.VVY9NT   = VVY9NT
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.infoBtnFnc   = infoBtnFnc
  self.VVtVox   = VVtVox
  self.VV0Xwe  = VV0Xwe
  self.VVMxmU  = ("Delete File", BF(self.VVaKnt, yellowBasePath)) if not yellowBasePath is None else VVMxmU
  self.VV8vtf   = VV8vtf
  self.VVNDcU  = VVNDcU
  self.VVFP3k  = VVFP3k
  self.Title    = title
  FFsd9n(self, title, VVY9NT=VVY9NT)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVz6TU    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVKsXK   ,
   "red"  : self.VVRvaL   ,
   "green"  : self.VVvXjb   ,
   "yellow" : self.VVrLs2   ,
   "blue"  : self.VViHBV   ,
   "pageUp" : self.VVok5u ,
   "chanUp" : self.VVok5u ,
   "pageDown" : self.VVrAnr  ,
   "chanDown" : self.VVrAnr  ,
   "0"   : BF(self.VVanL3, 0) ,
   "1"   : BF(self.VVanL3, 1) ,
   "2"   : BF(self.VVanL3, 2) ,
   "3"   : BF(self.VVanL3, 3) ,
   "4"   : BF(self.VVanL3, 4) ,
   "5"   : BF(self.VVanL3, 5) ,
   "6"   : BF(self.VVanL3, 6) ,
   "7"   : BF(self.VVanL3, 7) ,
   "8"   : BF(self.VVanL3, 8) ,
   "9"   : BF(self.VVanL3, 9)
  }, -1)
  if rcuSearch:
   FFgZsx(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFR6rJ(self["myMenu"])
  FFEPLV(self, minRows=self.minRows)
  FFnx82(self)
  self.VVWnFI(self["keyRed"]  , self.VVtVox )
  self.VVWnFI(self["keyGreen"] , self.VV0Xwe )
  self.VVWnFI(self["keyYellow"] , self.VVMxmU )
  self.VVWnFI(self["keyBlue"]  , self.VV8vtf )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF4AQy(self)
 def VVWnFI(self, btnObj, btnFnc):
  if btnFnc:
   FFKpuS(btnObj, btnFnc[0])
 def VVIIgL(self, fnc=None):
  self.VV0Xwe = fnc
  if fnc : self.VVWnFI(self["keyGreen"], self.VV0Xwe)
  else : self["keyGreen"].hide()
 def VVanL3(self, digit):
  digit = str(digit)
  VVY9NT = self["myMenu"].list
  for ndx, item in enumerate(VVY9NT):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFUkF8(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVsNwl(ndx)
     self.VVz6TU()
     break
 def VVz6TU(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVNDcU: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVKsXK(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.infoBtnFnc and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.infoBtnFnc(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVRvaL(self)  : self.VVnzeB(self.VVtVox)
 def VVvXjb(self) : self.VVnzeB(self.VV0Xwe)
 def VVrLs2(self) : self.VVnzeB(self.VVMxmU)
 def VViHBV(self) : self.VVnzeB(self.VV8vtf)
 def VVnzeB(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVFP3k:
    self.cancel()
 def VVQyjg(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVY9NT = self["myMenu"].list
  VVY9NT.pop(ndx)
  if len(VVY9NT) > 0: self["myMenu"].setList(VVY9NT)
  else    : self.close()
 def VVaKnt(self, basePath, menuObj, fName):
  FFe4rI(self, BF(self.VV7Fs9, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VV7Fs9(self, path):
  FFiHj6(path)
  if fileExists(path) : FFZWPu(self, "Not deleted", 1000)
  else    : self.VVQyjg()
 def VV2zjf(self, VVY9NT):
  if len(VVY9NT) > 0:
   newList = []
   for item in VVY9NT:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFEPLV(self, minRows=self.minRows)
  else:
   self.close("")
 def VViBv5(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFEPLV(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVwYKV(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVsNwl(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVngI3(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVsNwl(ndx)
    break
 def VVok5u(self) : self["myMenu"].moveToIndex(0)
 def VVrAnr(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCugyq(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VV0wO4=None, VV3dzh=None, VVgZrM=None, VVfp7o=26, VVcNyk=False, VVBgr7=0, VVNiXY=None, VVo8Jh=None, VVNxWT=None, VVY2vy=None, VVuKTt=None, VVNlag=None, VVzoEZ=None, VVKFgA=None, VVo9Gm=None, VVlPOg=-1, VVu0ZD=0, searchCol=0, lastFindConfigObj=None, VVU4bo=None, VVdq78=None, VV6yhZ="#00dddddd", VVWGqy="#11002233", VVjOuo="#00ff8833", VVpoY2="#11111111", VVUWnf="#0a555555", VVue8x="#0affffff", VVwS5R="#11552200", VVo9mM="#0055ff55", VVo9mMRev="#0000bbff"):
  self.skin, self.skinParam = FFWDRO(VVoBnl, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFsd9n(self, title)
  self.Title     = title
  self.header     = header
  self.VV0wO4     = VV0wO4
  self.totalCols    = len(VV0wO4[0])
  self.VVBgr7   = VVBgr7
  self.lastSortModeIsReverese = False
  self.VVcNyk   = VVcNyk
  self.VVbAj9   = 0.01
  self.VVh9Rh   = 0.02
  self.VV4Zrb = 0.03
  self.VVcyyA  = 1
  self.VVgZrM = VVgZrM
  self.colWidthPixels   = []
  self.VVNiXY   = VVNiXY
  self.OKButtonObj   = None
  self.VVo8Jh   = VVo8Jh
  self.VVNxWT   = VVNxWT
  self.VVY2vy   = VVY2vy
  self.VVuKTt  = VVuKTt
  self.VVNlag   = VVNlag
  self.VVzoEZ    = VVzoEZ
  self.VVKFgA   = VVKFgA
  self.tableRefreshCB   = None
  self.VVo9Gm  = VVo9Gm
  self.VVlPOg    = VVlPOg
  self.VVu0ZD   = VVu0ZD
  self.searchCol    = searchCol
  self.VV3dzh    = VV3dzh
  self.keyPressed    = -1
  self.VVfp7o    = FFX8wo(VVfp7o)
  self.VVbjgU    = FFUpYz(self.VVfp7o, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVU4bo    = VVU4bo
  self.VVdq78      = VVdq78
  self.VV6yhZ    = FFa79O(VV6yhZ)
  self.VVWGqy    = FFa79O(VVWGqy)
  self.VVjOuo    = FFa79O(VVjOuo)
  self.VVpoY2    = FFa79O(VVpoY2)
  self.VVUWnf   = FFa79O(VVUWnf)
  self.VVue8x    = FFa79O(VVue8x)
  self.VVwS5R    = FFa79O(VVwS5R)
  self.VVo9mM   = FFa79O(VVo9mM)
  self.VVo9mMRev  = FFa79O(VVo9mMRev)
  self.VVSQQE  = False
  self.selectedItems   = 0
  self.VVn8Vx   = FFa79O("#01fefe01")
  self.VVK2JG   = FFa79O("#11400040")
  self.VVCU3f  = self.VVn8Vx
  self.VVfhKt  = self.VVpoY2
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVu0ZD:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVu0ZD == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV5JVt  ,
   "red"  : self.VVZ5i6  ,
   "green"  : self.VV2Aji ,
   "yellow" : self.VVll8d ,
   "blue"  : self.VVgiJ2  ,
   "menu"  : self.VVXCp1 ,
   "info"  : self.VVTXjl  ,
   "cancel" : self.VVfgoh  ,
   "up"  : self.VVIiCj    ,
   "down"  : self.VV8aKe  ,
   "left"  : self.VV5z7c   ,
   "right"  : self.VVlyUD  ,
   "next"  : self.VV56oG  ,
   "last"  : self.VVZQZl  ,
   "home"  : self.VVynVm  ,
   "pageUp" : self.VVynVm  ,
   "chanUp" : self.VVynVm  ,
   "end"  : self.VVqv7q  ,
   "pageDown" : self.VVqv7q  ,
   "chanDown" : self.VVqv7q
  }, -1)
  FFgZsx(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  try:
   self.VVzLe2()
  except Exception as e:
   FFh60c(self, str(e), title=self.Title)
   self.close(None)
 def VVzLe2(self):
  FF4AQy(self)
  if self.VVU4bo:
   FFRkaP(self["myTitle"], self.VVU4bo)
  if self.VVdq78:
   FFRkaP(self["myBody"] , self.VVdq78)
   FFRkaP(self["myTableH"] , self.VVdq78)
   FFRkaP(self["myTable"] , self.VVdq78)
   FFRkaP(self["myBar"]  , self.VVdq78)
  self.VVWnFI(self.VVNxWT  , self["keyRed"])
  self.VVWnFI(self.VVY2vy  , self["keyGreen"])
  self.VVWnFI(self.VVuKTt , self["keyYellow"])
  self.VVWnFI(self.VVNlag  , self["keyBlue"])
  if self.VVNiXY:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVNiXY[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVNiXY[0])
    FFRkaP(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVbjgU)
  self["myTableH"].l.setFont(0, gFont(VVrHrQ, self.VVfp7o))
  self["myTable"].l.setItemHeight(self.VVbjgU)
  self["myTable"].l.setFont(0, gFont(VVrHrQ, self.VVfp7o))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVbjgU)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVbjgU))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVbjgU)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVbjgU
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVbjgU * len(self.VV0wO4) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVgZrM:
   self.VVgZrM = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVgZrM)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV3dzh:
   self.VV3dzh = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV3dzh
   self.VV3dzh = []
   for item in tmpList:
    self.VV3dzh.append(item | RT_VALIGN_CENTER)
  self.VVZiji()
  if self.VVzoEZ:
   self.VVzoEZ(self)
 def VVWnFI(self, btnFnc, btn):
  if btnFnc : FFKpuS(btn, btnFnc[0])
  else  : FFKpuS(btn, "")
 def VVzMrh(self, waitTxt):
  FFDKj1(self, self.VVZiji, title=waitTxt)
 def VVZiji(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVo9mMRev if self.lastSortModeIsReverese else self.VVo9mM
    self["myTableH"].setList([self.VVYuYA(0, self.header, self.VVue8x, self.VVwS5R, self.VVue8x, self.VVwS5R, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VV0wO4):
    self["myTable"].list.append(self.VVYuYA(c, row, self.VV6yhZ, self.VVWGqy, self.VVjOuo, self.VVpoY2, None))
   self.VV0wO4 = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVlPOg > -1:
    self["myTable"].moveToIndex(self.VVlPOg )
   self.VVczrJ()
   if self.VVu0ZD:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVbjgU * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FF02bi(self, width, newH)
   if self.VVKFgA:
    self.VVnzeB(self.VVKFgA, None)
   if self.tableRefreshCB:
    self.VVnzeB(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFh60c(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVYuYA(self, keyIndex, columns, VV6yhZ, VVWGqy, VVjOuo, VVpoY2, VVo9mM):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVo9mM and ndx == self.VVBgr7 : textColor = VVo9mM
   else           : textColor = VV6yhZ
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFa79O(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVWGqy = c
    entry = span.group(3)
   if self.VV3dzh[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVbjgU)
           , font   = 0
           , flags   = self.VV3dzh[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVWGqy
           , color_sel  = VVjOuo
           , backcolor_sel = VVpoY2
           , border_width = 1
           , border_color = self.VVUWnf
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVTXjl(self):
  rowData = self.VVgln6()
  if rowData:
   title, txt, colList = rowData
   if self.VVo8Jh:
    fnc  = self.VVo8Jh[1]
    params = self.VVo8Jh[2]
    fnc(self, title, txt, colList)
   else:
    FFHdWy(self, txt, title)
 def VV5JVt(self):
  if   self.VVSQQE : self.VVAtJp(self.VV3w14(), mode=2)
  elif self.VVNiXY  : self.VVnzeB(self.VVNiXY, None)
  else      : self.VVTXjl()
 def VVZ5i6(self) : self.VVnzeB(self.VVNxWT , self["keyRed"])
 def VV2Aji(self) : self.VVnzeB(self.VVY2vy , self["keyGreen"])
 def VVll8d(self): self.VVnzeB(self.VVuKTt , self["keyYellow"])
 def VVgiJ2(self) : self.VVnzeB(self.VVNlag , self["keyBlue"])
 def VVnzeB(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFZWPu(self, buttonFnc[3])
    FFcigO(BF(self.VV3YgF, buttonFnc))
   else:
    self.VV3YgF(buttonFnc)
 def VV3YgF(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVgln6()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVAtJp(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVn8Vx
   newRow = self.VVkll0()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVYuYA(ndx, newRow, self.VV6yhZ, self.VVWGqy, self.VVjOuo, self.VVpoY2, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVYuYA(ndx, newRow, self.VVn8Vx, self.VVK2JG, self.VVCU3f, self.VVfhKt, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VV3w14() < len(self["myTable"].list) - 1:
    self.VV8aKe()
   else:
    self.VVczrJ()
 def VVhxjl(self)  : FFDKj1(self, BF(self.VVJRH5, True ), title="Selecting all ..."  )
 def VVHIWx(self) : FFDKj1(self, BF(self.VVJRH5, False), title="Unselecting all ...")
 def VVJRH5(self, isSel=True):
  if isSel:
   fg, bg = self.VVn8Vx, self.VVK2JG
   self.selectedItems = len(self["myTable"].list)
   self.VVho3y(True)
  else:
   fg, bg = self.VV6yhZ, self.VVWGqy
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVn8Vx
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVgln6(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVgZrM[i] > 1 or self.VVgZrM[i] == self.VVbAj9 or self.VVgZrM[i] == self.VV4Zrb:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVfgoh(self):
  if self.VVo9Gm : self.VVo9Gm(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VV8zJV(self):
  return self["myTitle"].getText().strip()
 def VVFYOn(self):
  return self.header
 def VVNXg7(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVUoWD(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFR9H9(self["myBar"], color)
 def VVfxtU(self, txt):
  FFZWPu(self, txt)
 def VViaMT(self, txt, Time=1000):
  FFZWPu(self, txt, Time)
 def VVEejY(self): self["keyGreen"].show()
 def VVxErJ(self): self["keyGreen"].hide()
 def VVPPRT(self): return self["keyGreen"].visible
 def VVxwzS(self):
  FFZWPu(self)
 def VVwkUY(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVEYr6(self):
  return len(self["myTable"].list)
 def VV3w14(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVbwlY(self):
  return len(self["myTable"].list)
 def VVho3y(self, isOn):
  self.VVSQQE = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVNlag: self["keyBlue"].hide()
   if self.VVNiXY and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVNlag: self["keyBlue"].show()
   if self.VVNiXY and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVNiXY[0])
   self.VVHIWx()
  FFRkaP(self["myTitle"], color)
  FFRkaP(self["myBar"]  , color)
 def VVlhHr(self):
  return self.VVSQQE
 def VVkjUl(self):
  return self.selectedItems
 def VVoI9j(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVczrJ()
 def VVnZTe(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVcShh(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVEYr6()
  txt += FFF2CM("Total Unique Items", VVLO3F)
  for i in range(self.totalCols):
   if self.VVgZrM[i - 1] > 1 or self.VVgZrM[i - 1] == self.VVbAj9 or self.VVgZrM[i - 1] == self.VV4Zrb:
    name, tot = self.VVnZTe(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFHdWy(self, txt)
 def VVEOMp(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVkll0(self):
  return self.VVAxC0(self["myTable"].l.getCurrentSelectionIndex())
 def VVAxC0(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVQNRz(self, newList, newTitle="", VVbcbWMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VVNXg7(newTitle)
  if newList:
   self.VV0wO4 = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVcNyk and self.VVBgr7 == 0:
    isNum = True
   else:
    for cols in self.VV0wO4:
     if not FFEu9e(cols[self.VVBgr7]): break
    else:
     isNum = True
   if isNum: self.VV0wO4.sort(key=lambda x: int(x[self.VVBgr7])  , reverse=self.lastSortModeIsReverese)
   else : self.VV0wO4.sort(key=lambda x: x[self.VVBgr7].lower() , reverse=self.lastSortModeIsReverese)
   if VVbcbWMsg : self.VVzMrh("Refreshing ...")
   else   : self.VVZiji()
  else:
   FFh60c(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVvWTa(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVYuYA(self.VVbwlY(), row, self.VV6yhZ, self.VVWGqy, self.VVjOuo, self.VVpoY2, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVqv7q()
 def VVghx6(self):
  self["myTable"].list.pop(self.VV3w14())
  self["myTable"].l.setList(self["myTable"].list)
 def VVvHOE(self, data):
  ndx = self.VV3w14()
  newRow = self.VVYuYA(ndx, data, self.VV6yhZ, self.VVWGqy, self.VVjOuo, self.VVpoY2, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVczrJ()
   return True
  else:
   return False
 def VVp8Vc(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVYuYA(ndx, data, self.VV6yhZ, self.VVWGqy, self.VVjOuo, self.VVpoY2, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVc2O2()
 def VVc2O2(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVC4SC(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVIg0J(self, colNum, textToFind, VVyRz1=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVczrJ()
    break
  else:
   if VVyRz1:
    FFZWPu(self, "Not found", 1000)
 def VVz1sS(self, colDict, VVyRz1=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVczrJ()
    return
  if VVyRz1:
   FFZWPu(self, "Not found", 1000)
 def VVGSQw(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV5BYl(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFEu9e(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVETD3(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVn8Vx:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVOekD(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVn8Vx:
     return ndx
  return -1
 def VVlMWX(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVn8Vx:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVPLKO(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVn8Vx: return True
  else        : return False
 def VVexgG(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVXCp1(self):
  if not self["keyMenu"].getVisible() or self.VVu0ZD:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VV3w14()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVY9NT1, VVhHi9 = CCxD0c.VVOPzW(self, False, False)
  VVY9NT = []
  VVY9NT.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVY9NT.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVY9NT.append(("Find ...\t\t%s" % (FFbRJw(txt, VV619a) if txt else ""), "findNew"   ))
  VVY9NT.append(itemOf(bool(VVY9NT1)    , "Find (from Filter) ..."   , "filter"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Table Statistcis"             , "tableStat"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((FFbRJw("Export Table to .html"     , VVLO3F) , "VVClG9" ))
  VVY9NT.append((FFbRJw("Export Table to .csv"     , VVLO3F) , "VVtxlq" ))
  VVY9NT.append((FFbRJw("Export Table to .txt (Tab Separated)", VVLO3F) , "VVsL6e" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVgZrM[i] > 1 or self.VVgZrM[i] == self.VVh9Rh:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVY9NT.append(VVXMhc)
   if tot == 1 : VVY9NT.append(("Sort", sList[0][1]))
   else  : VVY9NT += sList
  VV8vtf = ("Keys Help", self.FFXBR7Help)
  FFaJ04(self, self.VVUVJt, VVY9NT=VVY9NT, title=self.VV8zJV(), VV8vtf=VV8vtf)
 def VVUVJt(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVyWau()
   elif item == "findPrev"  : self.VVyWau(isPrev=True)
   elif item == "findNew"  : self.VVBB70()
   elif item == "filter"  : self.VVDYEk()
   elif item == "tableStat" : self.VVcShh()
   elif item == "VVClG9": FFDKj1(self, self.VVClG9, title=title)
   elif item == "VVtxlq" : FFDKj1(self, self.VVtxlq , title=title)
   elif item == "VVsL6e" : FFDKj1(self, self.VVsL6e , title=title)
   else:
    if self.VVBgr7 == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVBgr7, self.lastSortModeIsReverese = item, False
    if self.VVcNyk and self.VVBgr7 == 0 or self.VV5BYl(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVZiji(onlyHeader=True)
 def FFXBR7Help(self, menuInstance, path):
  FFv9kY(self, "_help_table", "Table (Keys Help)")
 def VVIiCj(self):
  self["myTable"].up()
  self.VVczrJ()
 def VV8aKe(self):
  self["myTable"].down()
  self.VVczrJ()
 def VV5z7c(self):
  self["myTable"].pageUp()
  self.VVczrJ()
 def VVlyUD(self):
  self["myTable"].pageDown()
  self.VVczrJ()
 def VVynVm(self):
  self["myTable"].moveToIndex(0)
  self.VVczrJ()
 def VVqv7q(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVczrJ()
 def VVyOnh(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVczrJ()
 def VV56oG(self):
  if self.lastFindConfigObj.getValue():
   if self.VV3w14() == len(self["myTable"].list) - 1 : FFZWPu(self, "End reached", 1000)
   else              : self.VVyWau()
  else:
   FFZWPu(self, 'Set "Find" in Menu', 1500)
 def VVZQZl(self):
  if self.lastFindConfigObj.getValue():
   if self.VV3w14() == 0 : FFZWPu(self, "Top reached", 1000)
   else       : self.VVyWau(isPrev=True)
  else:
   FFZWPu(self, 'Set "Find" in Menu', 1500)
 def VV3CXf(self, txt):
  FFoBdB(self.lastFindConfigObj, txt)
 def VVBB70(self):
  FF5ZDh(self, self.VVHdIn, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVHdIn(self, VVHzlS):
  if not VVHzlS is None:
   txt = VVHzlS.strip()
   self.VV3CXf(txt)
   if VVHzlS: self.VVyWau(reset=True)
   else  : FFZWPu(self, "Nothing to find !", 1500)
 def VVDYEk(self):
  VVY9NT, VVhHi9 = CCxD0c.VVOPzW(self, False, False)
  VVMxmU = ("Edit Filter", BF(self.VV1OX1, VVhHi9))
  if VVY9NT : FFaJ04(self, self.VV9LHa, VVY9NT=VVY9NT, VVMxmU=VVMxmU, title="Find from Filter")
  else  : FFZWPu(self, "Filter Error !", 1500)
 def VV9LHa(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VV3CXf(txt)
    self.VVyWau(reset=True)
   else:
    FFZWPu(self, "No entry !", 1500)
 def VV1OX1(self, VVhHi9, VVELdAObj, sel):
  if fileExists(VVhHi9) : CCbHA8(self, VVhHi9, VVsfO0=None)
  else       : FFCpVp(self, VVhHi9)
  VVELdAObj.cancel()
 def VVyWau(self, reset=False, isPrev=False):
  curRow = self.VV3w14()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCxD0c.VVuVDQ(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVyOnh(i)
      break
    elif any(x in line for x in tupl):
     self.VVyOnh(i)
     break
   else:
    FFZWPu(self, "Not found", 1000)
  else:
   FFZWPu(self, "Check your query", 1500)
 def VVsL6e(self):
  expFile = self.VVZWAq() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVEYHL()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVAxC0(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVgZrM[ndx] > self.VVcyyA or self.VVgZrM[ndx] == self.VV4Zrb:
      col = self.VV6dpb(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVkvJf(expFile)
 def VVtxlq(self):
  expFile = self.VVZWAq() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVEYHL()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVAxC0(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVgZrM[ndx] > self.VVcyyA or self.VVgZrM[ndx] == self.VV4Zrb:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VV6dpb(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVkvJf(expFile)
 def VVClG9(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV8zJV(), PLUGIN_NAME, VVX28J)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV8zJV()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVEYHL()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVgZrM:
   colgroup += '   <colgroup>'
   for w in self.VVgZrM:
    if w > self.VVcyyA or w == self.VV4Zrb:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVZWAq() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVAxC0(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVgZrM[ndx] > self.VVcyyA or self.VVgZrM[ndx] == self.VV4Zrb:
      col = self.VV6dpb(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVkvJf(expFile)
 def VVEYHL(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVgZrM[ndx] > self.VVcyyA or self.VVgZrM[ndx] == self.VV4Zrb:
     newRow.append(col.strip())
  return newRow
 def VV6dpb(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFUkF8(col)
 def VVZWAq(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV8zJV())
  fileName = fileName.replace("__", "_")
  path  = FFd5Wt(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFDaMH()
  return expFile
 def VVkvJf(self, expFile):
  FFNvXQ(self, "File exported to:\n\n%s" % expFile, title=self.VV8zJV())
 def VVczrJ(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCbSSH():
 def __init__(self, pixmapObj, picPath, VVWGqy=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVWGqy  = VVWGqy or "#2200002a"
 def VV5vR8(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVlQZq)
    except:
     self.picLoad.PictureData.get().append(self.VVlQZq)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVWGqy])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVlQZq(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVm6n5(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVZDD9(pixmapObj, path, VVWGqy=None):
  cl = CCbSSH(pixmapObj, path, VVWGqy)
  ok = cl.VV5vR8()
  if ok: return cl
  else : return None
class CCG5Yr(Screen):
 def __init__(self, session, VVPYo2, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FF7Vv0()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFWDRO(VV1bMC, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVPYo2 = VVPYo2
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFsd9n(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVhjzP  ,
   "up" : BF(self.VVCaNf, -1),
   "down" : BF(self.VVCaNf,  1),
   "left" : BF(self.VVCaNf, -1),
   "right" : BF(self.VVCaNf,  1)
  }, -1)
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  self.VVRj07()
  self.picViewer = CCbSSH.VVZDD9(self["myPic"], self.VVPYo2)
  if self.picViewer:
   if self.showGrnMsg:
    FFZWPu(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFh60c(self, "Cannot view picture file:\n\n%s" % self.VVPYo2)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVm6n5()
  if self.cbFnc  : self.cbFnc(self.VVPYo2)
 def VVCaNf(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVPYo2 = FFd5Wt(os.path.dirname(self.VVPYo2)) + fName
    self.picViewer.picPath = self.VVPYo2
    self.picViewer.VV5vR8()
    self.VVRj07()
 def VVhjzP(self):
  txt = "%s:\n  %s" % (FFbRJw("Path", VVmuI1), self.fakePath or self.VVPYo2)
  size, sizeTxt, resTxt, form, mode = CC1HIn.VVG0aD(self.VVPYo2)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFbRJw("Properties", VVmuI1)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFHdWy(self, txt, title="File Information")
 def VVRj07(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVPYo2)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VV12Wn(SELF, VVPYo2, **kwargs):
  SELF.session.open(CCG5Yr, VVPYo2, **kwargs)
class CCGkpt(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFWDRO(VV8xeD, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFsd9n(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.onExit)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FF75pk("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVwDY6(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCGkpt.VVmrFQ, SELF), CCGkpt, mviFile)
 @staticmethod
 def VVmrFQ(SELF, reason=None):
  if reason == -1: FFh60c(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CC0lek(Screen, ConfigListScreen):
 VVpac4 = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVqSrQ, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFsd9n(self, title=self.Title)
  FFKpuS(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (for File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(VVwtEz *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVwtEz *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVwtEz *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVnsjj()
  self.onShown.append(self.VVrYby)
 def VVnsjj(self):
  kList = {
    "ok" : self.VVz6TU   ,
    "green" : self.VVmQit ,
    "menu" : self.VV0ZTh ,
    "cancel": self.VVFjgb ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VV3vGd, 0)
     kList["chanDown"] = BF(self["config"].VV3vGd, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FFnx82(self)
  FFR6rJ(self["config"])
  FFEPLV(self, self["config"])
  FF4AQy(self)
  self["config"].onSelectionChanged.append(self.VVSpcR)
  FFRkaP(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VVSpcR()
 def VVSpcR(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVz6TU(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVswST()
   elif item == CFG.MovieDownloadPath   : self.VV3n7q(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVEkn6()
   elif isinstance(item, ConfigDirectory) : self.VVSu1K(item)
   else         : CC0lek.VVqlFw(self, item, title)
 @staticmethod
 def VVqlFw(SELF, confItem, title, lst=None, cbFnc=None):
  isBool = isinstance(confItem, ConfigYesNo)
  isLst  = isinstance(confItem, ConfigSelection)
  isTxt  = isinstance(confItem, ConfigText)
  if not lst:
   if   isBool : lst = [(True, "ON"), (False, "OFF")]
   elif isLst : lst = confItem.choices.choices
   else  : return
  curNdx = defNdx = -1
  VVY9NT = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",VVwtEz)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VV619a + txt
    elif val == confItem.default: defNdx, txt = ndx, VVOpMG + txt
   VVY9NT.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VV8vtf  = ("Current", BF(CC0lek.VVUiTG, curNdx))
  VVMxmU = ("Default", BF(CC0lek.VVUiTG, defNdx))
  menuInstance = FFaJ04(SELF, BF(CC0lek.VVYSBY, confItem, cbFnc), VVY9NT=VVY9NT, width=1200, VVMxmU=VVMxmU, VV8vtf=VV8vtf, title=title, VVU4bo="#33221111", VVdq78="#33110011")
  menuInstance.VVsNwl(curNdx)
 @staticmethod
 def VVYSBY(confItem, cbFnc, item=None):
  if not item is None:
   FFoBdB(confItem, item)
   if cbFnc:
    cbFnc()
 @staticmethod
 def VVUiTG(ndx, VVELdAObj, item):
  VVELdAObj.VVsNwl(ndx)
 @staticmethod
 def VVEWvE(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VV3n7q(self, item, title):
  tot = CCPWpb.VVmwfb()
  if tot : FFh60c(self, "Cannot change while downloading.", title=title)
  else : self.VVSu1K(item)
 def VVEkn6(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCORAx.VVZ1RP(self, "", curEnc)
  if lst:
   VVMxmU = ("Default", self.VV2y7h)
   VV8vtf  = ("Current", self.VV8dpp)
   menuInstance = FFaJ04(self, self.VVTI8I, title="Select Priority Encoding", VVY9NT=lst, width=1000, height=1000, VV8vtf=VV8vtf, VVMxmU=VVMxmU, VVU4bo="#22220000", VVdq78="#22220000", VVNDcU=True)
   menuInstance.VVngI3(curEnc)
 def VVTI8I(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VV2y7h(self, menuInstance, item): menuInstance.VVngI3(VVJAPg)
 def VV8dpp(self, menuInstance, item): menuInstance.VVngI3(CFG.subtDefaultEnc.getValue())
 def VVswST(self):
  VVY9NT = []
  VVY9NT.append(("Auto Find" , "auto"))
  VVY9NT.append(("Custom Path" , "cust"))
  FFaJ04(self, self.VVRYuv, VVY9NT=VVY9NT, title="IPTV Hosts Files Path")
 def VVRYuv(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVgLsZ)
   elif item == "cust":
    VVJnaJ = self.VV0jX0()
    if VVJnaJ : self.VVIKKR(VVJnaJ)
    else  : self.session.openWithCallback(self.VVbCPG, BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9="/"))
 def VVIKKR(self, VVJnaJ):
  VVo9Gm = self.VVNfyf
  VVNxWT = ("Remove"  , self.VVDfMQ , [])
  VVuKTt = ("Add "  , self.VV52Jh, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VV3dzh  = (LEFT   , LEFT  )
  FFXBR7(self, None, title="IPTV Hosts Search Paths", header=header, VV0wO4=VVJnaJ, width=1200, height=700, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=26, VVo9Gm=VVo9Gm, VVNxWT=VVNxWT, VVuKTt=VVuKTt
    , VVU4bo="#22220000", VVdq78="#22110000", VVWGqy="#22110011", VVjOuo="#11ffff00", VVpoY2="#11223025", VVUWnf="#0a333333", VVwS5R="#11400040")
 def VVNfyf(self, VV5PsO):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVjsUk)
  VV5PsO.cancel()
 def VVbCPG(self, path):
  if path:
   FFoBdB(CFG.iptvHostsDirs, FFd5Wt(path.strip()))
   VVJnaJ = self.VV0jX0()
   if VVJnaJ : self.VVIKKR(VVJnaJ)
   else  : FFZWPu(self, "Cannot add dir", 1500)
 def VVsCbF(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVgLsZ:
   return []
  return lst
 def VV0jX0(self):
  lst = self.VVsCbF()
  if lst:
   VVJnaJ = []
   for Dir in lst:
    VVJnaJ.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVJnaJ.sort(key=lambda x: x[0].lower())
   return VVJnaJ
  else:
   return []
 def VV52Jh(self, VV5PsO, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVVbja, VV5PsO)
         , BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9=sDir))
 def VVVbja(self, VV5PsO, path):
  if path:
   path = FFd5Wt(path.strip())
   if self.VVo3Jj(VV5PsO, path):
    FFZWPu(VV5PsO, "Already added", 1500)
   else:
    lst = self.VVsCbF()
    lst.append(path)
    FFoBdB(CFG.iptvHostsDirs, ",".join(lst))
    VVJnaJ = self.VV0jX0()
    VV5PsO.VVQNRz(VVJnaJ, tableRefreshCB=BF(self.VVpQcY, path))
 def VVpQcY(self, path, VV5PsO, title, txt, colList):
  self.VVo3Jj(VV5PsO, path)
 def VVo3Jj(self, VV5PsO, path):
  for ndx, row in enumerate(VV5PsO.VVexgG()):
   if row[0].strip() == path.strip():
    VV5PsO.VVyOnh(ndx)
    return True
  return False
 def VVDfMQ(self, VV5PsO, title, txt, colList):
  path = colList[0]
  FFe4rI(self, BF(self.VVvedJ, VV5PsO), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVvedJ(self, VV5PsO):
  row = VV5PsO.VVkll0()
  path, rem = row[0], row[1]
  VVJnaJ = []
  lst = []
  for ndx, row in enumerate(VV5PsO.VVexgG()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVJnaJ.append((tPath, tRem))
  if len(VVJnaJ) > 0:
   FFoBdB(CFG.iptvHostsDirs, ",".join(lst))
   VV5PsO.VVQNRz(VVJnaJ)
   FFZWPu(VV5PsO, "Deleted", 1500)
  else:
   FFoBdB(CFG.iptvHostsMode, VVgLsZ)
   FFoBdB(CFG.iptvHostsDirs, "")
   VV5PsO.cancel()
   FFcigO(BF(FFZWPu, self, "Changed to Auto-Find", 1500))
 def VVSu1K(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVqUVX, configObj)
         , BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9=sDir))
 def VVqUVX(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVFjgb(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFe4rI(self, self.VVmQit, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVmQit(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVM0vL()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV0ZTh(self):
  VVY9NT = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVY9NT.append((txt    , "VVeAHo"   ))
  else        : VVY9NT.append((txt    ,       ))
  VVY9NT.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Reset %s Settings" % PLUGIN_NAME      , "VVLrwT"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Backup %s Settings" % PLUGIN_NAME      , "VVgal9"  ))
  VVY9NT.append(("Restore %s Settings" % PLUGIN_NAME     , "VVZApg"  ))
  if fileExists(VVPUYO + CC0lek.VVpac4):
   VVY9NT.append(VVXMhc)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVY9NT.append(('%s Checking for Update' % txt1     , txt2     ))
   VVY9NT.append(("Reinstall %s" % PLUGIN_NAME      , "VVhMTs"  ))
   VVY9NT.append(("Update %s" % PLUGIN_NAME      , "VVd5SF"   ))
  FFaJ04(self, self.VVotJK, VVY9NT=VVY9NT, title="Config. Options")
 def VVotJK(self, item=None):
  if item:
   if   item == "VVeAHo"  : FFe4rI(self, self.VVeAHo , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCwVjJ)
   elif item == "VVLrwT"  : FFe4rI(self, BF(self.VVLrwT, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVgal9" : self.VVgal9()
   elif item == "VVZApg" : FFDKj1(self, self.VVZApg, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFoBdB(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFoBdB(CFG.checkForUpdateAtStartup, False)
   elif item == "VVhMTs" : FFDKj1(self, BF(self.VVoWCo, True ), "Checking Server ...")
   elif item == "VVd5SF"  : FFDKj1(self, BF(self.VVoWCo, False), "Checking Server ...")
 def VVgal9(self):
  path = "%sajpanel_settings_%s" % (VVPUYO, FFDaMH())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVn6iK, path))
  FFNvXQ(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVZApg(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFLYXX("find / %s -iname '%s*' | grep %s" % (FFNjJC(1), name, name))
  if files:
   err = CCVdBH.VVTfqS(files)
   if err:
    FFe4rI(self, BF(self.VV7QpX, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVY9NT = []
    for line in files:
     VVY9NT.append((line, line))
    FFaJ04(self, BF(self.VVuPFl, title), title=title, VVY9NT=VVY9NT, width=1200, yellowBasePath="")
  else:
   FFh60c(self, "No settings files found !", title=title)
 def VV7QpX(self, title, path=None):
  sDir = "/"
  for path in (VVPUYO, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVuPFl, title), BF(CCVdBH, patternMode="ajpSet", VVWic9=sDir))
 def VVuPFl(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFun41(path)
    self.VVLrwT()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVM0vL()
    FFNERR()
    FFZWPu(self, "Apllied", 1500, isGrn=True)
   else:
    FFCpVp(self, path, title=title)
 def VVeAHo(self):
  newPath = FFd5Wt(VVPUYO)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVM0vL()
 @staticmethod
 def VVAVMo():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVLrwT(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVM0vL()
  if exit:
   self.close()
 def VVM0vL(self):
  configfile.save()
  global VVPUYO
  VVPUYO = CFG.backupPath.getValue()
  FFZFvW()
 def VVoWCo(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CC0lek.VVNUdC()
  if   err    : FFh60c(self, err, title)
  elif isHigher or force : FFe4rI(self, BF(FFDKj1, self, BF(self.VVIMCI, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFNvXQ(self, FFbRJw("No update required.", VVlwDq) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVIMCI(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFaz01() == "dpkg" else "ipk")
  path, err = FFzm7R(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFXUpj(VVPgiB, path)
   else : cmd = FFXUpj(VVftKI, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
    FFx5HE(self, cmd, title=title)
   else:
    FFhvmT(self, title=title)
  else:
   FFh60c(self, err, title=title)
 @staticmethod
 def VVNUdC():
  span = iSearch(r"v*(\d.\d.\d)", VVX28J, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVPUYO + CC0lek.VVpac4
  if fileExists(path):
   span = iSearch(r"(http.+)", FFvr8J(path), IGNORECASE)
   if span : url = FFd5Wt(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFzm7R(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFvr8J(path).strip().replace(" ", "")
   FFiHj6(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCwVjJ(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVmUKz, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVsQSI
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFsd9n(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VV8ZlT("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VV8ZlT("\c00888888", i) + sp + "GREY\n"
   txt += self.VV8ZlT("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VV8ZlT("\c00FF0000", i) + sp + "RED\n"
   txt += self.VV8ZlT("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VV8ZlT("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VV8ZlT("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VV8ZlT("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VV8ZlT("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VV8ZlT("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VV8ZlT("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VV8ZlT("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVz6TU ,
   "green" : self.VVz6TU ,
   "left" : self.VVBeVJ ,
   "right" : self.VVk9Xp ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  self.VV4YRC()
 def VVz6TU(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFe4rI(self, self.VVyxev, "Change to : %s" % txt, title=self.Title)
 def VVyxev(self):
  FFoBdB(CFG.mixedColorScheme, self.cursorPos)
  global VVsQSI
  VVsQSI = self.cursorPos
  self.VVxJPl()
  self.close()
 def VVBeVJ(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV4YRC()
 def VVk9Xp(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV4YRC()
 def VV4YRC(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VV8ZlT(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVkM5Z(color):
  if VVOpMG: return "\\" + color
  else    : return ""
 @staticmethod
 def VVxJPl():
  global VVtUHQ, VVlhbS, VVzF5b, VVxsyh, VVLO3F, VVFaDd, VVyFNv, VVkPll, VVlwDq, VVPWV9, VVOpMG, VVmuI1, VV619a, VVDopz, VVW5KH, VVViAb
  VVViAb   = CCwVjJ.VV8ZlT("\c00FFFFFF", VVsQSI)
  VVlhbS    = CCwVjJ.VV8ZlT("\c00888888", VVsQSI)
  VVtUHQ  = CCwVjJ.VV8ZlT("\c005A5A5A", VVsQSI)
  VVkPll    = CCwVjJ.VV8ZlT("\c00FF0000", VVsQSI)
  VVzF5b   = CCwVjJ.VV8ZlT("\c00FF5000", VVsQSI)
  VVxsyh   = CCwVjJ.VV8ZlT("\c00FFBB66", VVsQSI)
  VVOpMG   = CCwVjJ.VV8ZlT("\c00FFFF00", VVsQSI)
  VVmuI1 = CCwVjJ.VV8ZlT("\c00FFFFAA", VVsQSI)
  VVlwDq   = CCwVjJ.VV8ZlT("\c0000FF00", VVsQSI)
  VVPWV9  = CCwVjJ.VV8ZlT("\c00AAFFAA", VVsQSI)
  VVyFNv    = CCwVjJ.VV8ZlT("\c000066FF", VVsQSI)
  VV619a    = CCwVjJ.VV8ZlT("\c0000FFFF", VVsQSI)
  VVDopz  = CCwVjJ.VV8ZlT("\c00AAFFFF", VVsQSI)  #
  VVW5KH   = CCwVjJ.VV8ZlT("\c00FA55E7", VVsQSI)
  VVLO3F    = CCwVjJ.VV8ZlT("\c00FF8F5F", VVsQSI)
  VVFaDd  = CCwVjJ.VV8ZlT("\c00FFC0C0", VVsQSI)
CCwVjJ.VVxJPl()
class CC0rPh(Screen):
 def __init__(self, session, path, VVqneK):
  self.skin, self.skinParam = FFWDRO(VV181V, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VV8WqM   = path
  self.VVYoMC   = ""
  self.VVgfRi   = ""
  self.VVqneK    = VVqneK
  self.VVEEbc    = ""
  self.VVHv02  = ""
  self.VV8Uei    = False
  self.VVMPJP  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VV78QQ  = "enigma2-plugin-extensions-"
  self.VVCJCv  = "enigma2-plugin-systemplugins-"
  self.VV35So = "enigma2-"
  self.VVx5jZ  = 0
  self.VVHFse  = 1
  self.VVigwO  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVLnai = "DEBIAN"
  else        : self.VVLnai = "CONTROL"
  self.controlPath = self.Path + self.VVLnai
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVqneK:
   self.packageExt  = ".deb"
   self.VVWGqy  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVWGqy  = "#11001020"
  FFsd9n(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFKpuS(self["keyRed"] , "Create")
  FFKpuS(self["keyGreen"] , "Post Install")
  FFKpuS(self["keyYellow"], "Installation Path")
  FFKpuS(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVOxer  ,
   "green"   : self.VVQDnh ,
   "yellow"  : self.VVunzl  ,
   "blue"   : self.VVxp88  ,
   "cancel"  : self.VVYZRn
  }, -1)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FF4AQy(self)
  if self.VVWGqy:
   FFRkaP(self["myBody"], self.VVWGqy)
   FFRkaP(self["myLabel"], self.VVWGqy)
  self.VVnBcL(True)
  self.VVpH1d(True)
 def VVpH1d(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVsypV()
  if isFirstTime:
   if   package.startswith(self.VV78QQ) : self.VV8WqM = VV9hRJ + self.VVEEbc + "/"
   elif package.startswith(self.VVCJCv) : self.VV8WqM = VV4ItM + self.VVEEbc + "/"
   else            : self.VV8WqM = self.Path
  if self.VV8Uei : myColor = VVLO3F
  else    : myColor = VVViAb
  txt  = ""
  txt += "Source Path\t: %s\n" % FFbRJw(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFbRJw(self.VV8WqM, VVOpMG)
  if self.VVgfRi : txt += "Package File\t: %s\n" % FFbRJw(self.VVgfRi, VVlhbS)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFbRJw("Check Control File fields : %s" % errTxt, VVzF5b)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFbRJw("Restart GUI", VVLO3F)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFbRJw("Reboot Device", VVLO3F)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFbRJw("Post Install", VVlwDq), act)
  if not errTxt and VVzF5b in controlInfo:
   txt += "Warning\t: %s\n" % FFbRJw("Errors in control file may affect the result package.", VVzF5b)
  txt += "\nControl File\t: %s\n" % FFbRJw(self.controlFile, VVlhbS)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVQDnh(self):
  if self["keyGreen"].getVisible():
   VVY9NT = []
   VVY9NT.append(("No Action"    , "noAction"  ))
   VVY9NT.append(("Restart GUI"    , "VVjtjK"  ))
   VVY9NT.append(("Reboot Device"   , "rebootDev"  ))
   FFaJ04(self, self.VVkl4b, title="Package Installation Option (after completing installation)", VVY9NT=VVY9NT)
 def VVkl4b(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVjtjK"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVnBcL(False)
   self.VVpH1d()
 def VVunzl(self):
  rootPath = FFbRJw("/%s/" % self.VVEEbc, VVmuI1)
  VVY9NT = []
  VVY9NT.append(("Current Path"        , "toCurrent"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Extension Path"       , "toExtensions" ))
  VVY9NT.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVY9NT.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFaJ04(self, self.VVb6Bh, title="Installation Path", VVY9NT=VVY9NT)
 def VVb6Bh(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVgL2H(FFBCGr(self.Path, True))
   elif item == "toExtensions"  : self.VVgL2H(VV9hRJ)
   elif item == "toSystemPlugins" : self.VVgL2H(VV4ItM)
   elif item == "toRootPath"  : self.VVgL2H("/")
   elif item == "toRoot"   : self.VVgL2H("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV03Rb, BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9=VVPUYO))
 def VV03Rb(self, path):
  if len(path) > 0:
   self.VVgL2H(path)
 def VVgL2H(self, parent, withPackageName=True):
  if withPackageName : self.VV8WqM = parent + self.VVEEbc + "/"
  else    : self.VV8WqM = "/"
  mode = self.VV1pa9()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV4Crj(mode), self.controlFile))
  self.VVpH1d()
 def VVxp88(self):
  if fileExists(self.controlFile):
   lines = FFun41(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF5ZDh(self, self.VVQuII, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFh60c(self, "Version not found or incorrectly set !")
  else:
   FFCpVp(self, self.controlFile)
 def VVQuII(self, VVHzlS):
  if VVHzlS:
   version, color = self.VVlAio(VVHzlS, False)
   if color == VV619a:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVHzlS, self.controlFile))
    self.VVpH1d()
   else:
    FFh60c(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVYZRn(self):
  if self.newControlPath:
   if self.VV8Uei:
    self.VV7MaX()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFbRJw(self.newControlPath, VVlhbS)
    txt += FFbRJw("Do you want to keep these files ?", VVOpMG)
    FFe4rI(self, self.close, txt, callBack_No=self.VV7MaX, title="Create Package", VVRAK2=True)
  else:
   self.close()
 def VV7MaX(self):
  os.system(FF75pk("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV4Crj(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVHv02
  if package.startswith(self.VV35So):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VV35So, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVHFse : prefix = self.VV78QQ
  elif mode == self.VVigwO : prefix = self.VVCJCv
  return (prefix + name).lower()
 def VV1pa9(self):
  if   self.VV8WqM.startswith(VV9hRJ) : return self.VVHFse
  elif self.VV8WqM.startswith(VV4ItM) : return self.VVigwO
  else            : return self.VVx5jZ
 def VVnBcL(self, isFirstTime):
  self.VVEEbc   = FFjufa(self.Path)
  self.VVEEbc   = "_".join(self.VVEEbc.split())
  self.VVHv02 = self.VVEEbc.lower()
  self.VV8Uei = self.VVHv02 == VVblf7.lower()
  if self.VV8Uei and self.VVHv02.endswith("ajpan"):
   self.VVHv02 += "el"
  if self.VV8Uei : self.VVYoMC = VVPUYO
  else    : self.VVYoMC = CFG.packageOutputPath.getValue()
  self.VVYoMC = FFd5Wt(self.VVYoMC)
  if not pathExists(self.controlPath):
   os.system(FF75pk("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VV1pa9()
  if fileExists(self.controlFile):
   lines = FFun41(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VV8Uei : version, descripton, maintainer = VVX28J , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVEEbc , self.VVEEbc
   txt = ""
   txt += "Package: %s\n"  % self.VV4Crj(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VV8Uei : t = PLUGIN_NAME
  else    : t = self.VVEEbc
  self.VVbL52(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVbL52(self.postrmFile, "echo 'Package removed.'\n")
  if self.VV8Uei : self.VVbL52(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVX28J))
  else    : self.VVbL52(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVEEbc)
  if isFirstTime and not mode == self.VVx5jZ:
   self.postInstAcion = 1
  txt = self.VVFpmp(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFvr8J(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVFpmp(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FF75pk("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVbL52(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVFpmp(self, action):
  sep  = "echo '%s'\n" % VVwtEz
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVsypV(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFun41(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFbRJw(line, VVzF5b)
     elif not line.startswith(" ")    : line = FFbRJw(line, VVzF5b)
     else          : line = FFbRJw(line, VV619a)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV619a
   else   : color = VVzF5b
   descr = FFbRJw(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVzF5b
     elif line.startswith((" ", "\t")) : color = VVzF5b
     elif line.startswith("#")   : color = VVlhbS
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVlAio(val, True)
      elif key == "Version"  : version, color = self.VVlAio(val, False)
      elif key == "Maintainer" : maint  , color = val, VV619a
      elif key == "Architecture" : arch  , color = val, VV619a
      else:
       color = VV619a
      if not key == "OE" and not key.istitle():
       color = VVzF5b
     else:
      color = VVLO3F
     txt += FFbRJw(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVgfRi = self.VVYoMC + packageName
   self.VVMPJP = True
   errTxt = ""
  else:
   self.VVgfRi  = ""
   self.VVMPJP = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVlAio(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV619a
  else          : return val, VVzF5b
 def VVOxer(self):
  if not self.VVMPJP:
   FFh60c(self, "Please fix Control File errors first.")
   return
  if self.VVqneK: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFBCGr(self.VV8WqM, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVEEbc
  symlinkTo  = FFUEil(self.Path)
  dataDir   = self.VV8WqM.rstrip("/")
  removePorjDir = FF75pk("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FF75pk("rm -f '%s'" % self.VVgfRi) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFYhIs()
  if self.VVqneK:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFKkrr("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV8Uei:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VV8WqM == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVLnai)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVgfRi, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVgfRi
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVgfRi, FFs7EJ(result  , VVlwDq))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VV8WqM, FFs7EJ(instPath, VV619a))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFs7EJ(failed, VVzF5b))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFx5HE(self, cmd)
class CCgBRx():
 VVK1D9  = "666"
 VVg4kP   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VVs97K()
 def VVs97K(self):
  VVY9NT = CCgBRx.VVVi7P()
  if VVY9NT:
   VVMxmU = ("Create New", self.VVVUzm)
   self.menuInstance = FFaJ04(self.SELF, self.VVpeRT, VVY9NT=VVY9NT, title=self.Title, VVMxmU=VVMxmU, VVNDcU=True, VVU4bo="#22222233", VVdq78="#22222233")
  else:
   self.VVVUzm()
 def VVpeRT(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVCljv(bName, bRef)
  else:
   CCgBRx.VVdDZc(self)
 def VVVUzm(self, VVELdAObj=None, item=None):
  FF5ZDh(self.SELF, BF(self.VV6qE1), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV6qE1(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VVCljv(bName, "")
   else:
    FFZWPu(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CCgBRx.VVdDZc(self)
 def VVCljv(self, bName, bRef):
  FFDKj1(self.waitMsgSELF, BF(self.VVcPAF, bName, bRef), title="Adding Services ...")
 def VVcPAF(self, bName, bRef):
  CCgBRx.VVId9J(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVdDZc(classObj):
  del classObj
 @staticmethod
 def VVId9J(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFh60c(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVn6iK + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFCpVp(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCgBRx.VVUWsQ(bRef)
   bPath = VVn6iK + bFile
  else:
   fName = CCHli4.VVaBJI(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVn6iK + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVn6iK + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CCgBRx.VV8R3u(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CCgBRx.VV8R3u(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCZBEU.VV0FjB()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FF75pk("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CC8xkn.VVBBqL(picon))
       break
  FFMABX()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFHdWy(SELF, txt, title=title)
 @staticmethod
 def VVVi7P(mode=2, showTitle=True, prefix=""):
  VVY9NT = []
  if mode in (0, 2): VVY9NT.extend(CCgBRx.VVRyaO(0, showTitle, prefix))
  if mode in (1, 2): VVY9NT.extend(CCgBRx.VVRyaO(1, showTitle, prefix))
  return VVY9NT
 @staticmethod
 def VVRyaO(mode, showTitle, prefix):
  VVY9NT = []
  lst = CCgBRx.VVKZni(mode)
  if lst:
   if showTitle:
    VVY9NT.append(FF9lRG("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVY9NT.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVY9NT.append((item[0], item[1].toString()))
  return VVY9NT
 @staticmethod
 def VVid2G():
  bLise = CCgBRx.VVKZni(0)
  bLise.extend(CCgBRx.VVKZni(1))
  return bLise
 @staticmethod
 def VVKZni(mode=0):
  bList = []
  VVXVyg = InfoBar.instance
  VVCDrX = VVXVyg and VVXVyg.servicelist
  if VVCDrX:
   curMode = VVCDrX.mode
   CCgBRx.VVPGm3(VVCDrX, mode)
   bList.extend(VVCDrX.getBouquetList() or [])
   CCgBRx.VVPGm3(VVCDrX, curMode)
  return bList
 @staticmethod
 def VVPGm3(VVCDrX, mode):
  if not mode == VVCDrX.mode:
   if   mode == 0: VVCDrX.setModeTv()
   elif mode == 1: VVCDrX.setModeRadio()
 @staticmethod
 def VV8R3u(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVUWsQ(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVJ0V1():
  try:
   fName = CCgBRx.VVUWsQ(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVn6iK, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVZoC3():
  path = CCgBRx.VVJ0V1()
  if path:
   txt = FFvr8J(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVfS8X():
  return FFrlgz(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVNAEY():
  lst = []
  for b in CCgBRx.VVid2G():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVn6iK + CCgBRx.VVUWsQ(bRef)
   if fileExists(path):
    lines = FFun41(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVrF2v(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VV6P9I(SID="", stripRType=False):
  if SID : patt = CCgBRx.VVrF2v(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCgBRx.VVid2G():
   for service in FFrlgz(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVTY57():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCgBRx.VVid2G():
   for service in FFrlgz(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVdgBU(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VV4usi(pathLst, rType=""):
  refLst = CCgBRx.VV6P9I(CCgBRx.VVK1D9, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCgBRx.VVdgBU(rType, CCgBRx.VVK1D9, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCVdBH(Screen):
 VVzfS9   = 0
 VVH3fb  = 1
 VVHQKD  = 2
 VVQ9Xy = 3
 VVNi7Z    = 20
 VVkF4O  = None
 VVc5nL   = 0
 VVbgJw   = 1
 VVWd2n   = 2
 def __init__(self, session, VVWic9="/", mode=VVzfS9, VVJO71="Select", width=1400, height=920, VVfp7o=30, VVU4bo="#22001111", VVdq78="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFWDRO(VVG5k0, width, height, 30, 40, 20, VVU4bo, VVdq78, VVfp7o, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVU4bo   = VVU4bo
  self.VVdq78    = VVdq78
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFsd9n(self)
  FFKpuS(self["keyRed"] , "Exit")
  FFKpuS(self["keyYellow"], "More Options")
  FFKpuS(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVJO71 = VVJO71
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  CCVdBH.VVkF4O = self
  VV1KUp = None
  if patternMode:
   self.mode = self.VVQ9Xy
   if   patternMode == "srt"   : VV1KUp = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet": VV1KUp = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster": VV1KUp = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "movies": VV1KUp = ("^.*\.(%s)$" % "|".join(CCRrOq.VVhZIz()["mov"]), IGNORECASE)
   else      : VV1KUp = None
  if self.mode in (self.VVHQKD, self.VVQ9Xy):
   FFKpuS(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVSuut, self.VVWic9 = True , FFBCGr(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVSuut, self.VVWic9 = True , CCVdBH.VV950I(self)[1] or "/"
  elif self.mode == self.VVzfS9  : VVSuut, self.VVWic9 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVHQKD : VVSuut, self.VVWic9 = False, VVWic9
  elif self.mode == self.VVQ9Xy : VVSuut, self.VVWic9 = True , VVWic9
  else           : VVSuut, self.VVWic9 = True , VVWic9
  self.VVWic9 = FFd5Wt(self.VVWic9)
  self["myMenu"] = CCRrOq(  directory   = None
         , VV1KUp = VV1KUp
         , VVSuut   = VVSuut
         , VVNARW = True
         , VVkElI = True
         , VVHDWp   = self.skinParam["width"]
         , VVfp7o   = self.skinParam["bodyFontSize"]
         , VVbjgU  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVz6TU    ,
   "red" : self.VVcznX   ,
   "green" : self.VV4wW6,
   "yellow": self.VVUpbc  ,
   "blue" : self.VV1QYa ,
   "menu" : self.VVBMab  ,
   "info" : self.VVwB5t  ,
   "cancel": self.VVA2HF    ,
   "pageUp": self.VVKo6y   ,
   "chanUp": self.VVKo6y
  }, -1)
  FFgZsx(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVbUZh)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  CCVdBH.VVkF4O = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVbUZh)
  FFnx82(self)
  FFR6rJ(self["myMenu"], bg=self.cursorBG)
  FF4AQy(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVHQKD, self.VVQ9Xy):
   FFKpuS(self["keyGreen"], self.VVJO71)
   self.VV9Riq(self.VVbgJw)
  self.VVbUZh()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVDvTp(self.VVWic9) > self.bigDirSize: FFDKj1(self, self.VVv5Ta, title="Changing directory...")
  else              : self.VVv5Ta()
 def VVv5Ta(self):
  if self.jumpToFile : self.VVppN1(self.jumpToFile)
  elif self.gotoMovie : self.VVg351(chDir=False)
  else    : self["myMenu"].VVxD9b(self.VVWic9)
 def VVyOnh(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVwce4(self):
  FFDKj1(self, self.VVHZI3, title="Refreshing list ...")
 def VVHZI3(self):
  isSel = self["myMenu"].VVgJud()
  if not isSel:
   self.VVcE0N(False)
  FFgh2b()
 def VVDvTp(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVz6TU(self):
  if self.multiSelectState:
   ok = self["myMenu"].VV3HZK()
   if ok : self["keyBlue"].setText(self.VViyGj())
   else : FFZWPu(self, "Cannot select item", 500)
  elif self["myMenu"].VVKn9x(): self.VVmE2Q()
  else       : self.VV6PeB()
 def VVKo6y(self):
  if self.multiSelectState:
   FFZWPu(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVN1OQ():
    self.VVmE2Q()
 def VVmE2Q(self, isDirUp=False):
  if self["myMenu"].VVKn9x():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVgRRg(self.VVELdA())
   if self.VVDvTp(path) > self.bigDirSize : FFDKj1(self, self.VVfoT6, title="Changing directory...")
   else           : self.VVfoT6()
 def VVfoT6(self):
  self["myMenu"].descent()
  self.VVbUZh()
 def VVA2HF(self):
  if   self.multiSelectState     : self.VVcE0N(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVcznX()
  else          : self.VVKo6y()
 def VVcznX(self):
  if not FFDQOc(self):
   self.close("")
 def VV4wW6(self):
  path = self.VVgRRg(self.VVELdA())
  if self.mode == self.VVHQKD:
   self.close(path)
  elif self.mode == self.VVQ9Xy:
   if os.path.isfile(path) : self.close(path)
   else     : FFZWPu(self, "Cannot access this file", 1000)
 def VVwB5t(self):
  FFDKj1(self, self.VVHdzy, title="Calculating size ...")
 def VVHdzy(self):
  path = self.VVgRRg(self.VVELdA())
  param = self.VVzl8s(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFA2wB("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCVdBH.VVFQUX(path)
     freeSize = CCVdBH.VVnPRW(path)
     size = totSize - freeSize
     totSize  = CCVdBH.VVFJRm(totSize)
     freeSize = CCVdBH.VVFJRm(freeSize)
    else:
     size = FF1rjx(path)
   usedSize = CCVdBH.VVFJRm(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFbRJw(pathTxt, VVLO3F) + "\n"
   if slBroken : fileTime = self.VVHGE4(path)
   else  : fileTime = self.VVvzkz(path)
   def VVmzbD(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVmzbD("Path"    , pathTxt)
   txt += VVmzbD("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVmzbD("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVmzbD("Total Size"   , "%s" % totSize)
    txt += VVmzbD("Used Size"   , "%s" % usedSize)
    txt += VVmzbD("Free Size"   , "%s" % freeSize)
   else:
    txt += VVmzbD("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVmzbD("Owner"    , owner)
   txt += VVmzbD("Group"    , group)
   txt += VVmzbD("Perm. (User)"  , permUser)
   txt += VVmzbD("Perm. (Group)"  , permGroup)
   txt += VVmzbD("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVmzbD("Perm. (Ext.)" , permExtra)
   txt += VVmzbD("iNode"    , iNode)
   txt += VVmzbD("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVwtEz, VVwtEz)
    txt += hLinkedFiles
   txt += self.VVA3iq(path)
  else:
   FFh60c(self, "Cannot access information !")
  if len(txt) > 0:
   FFHdWy(self, txt)
 def VVzl8s(self, path):
  path = path.strip()
  path = FFUEil(path)
  result = FFA2wB("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVoGp3(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVoGp3(perm, 1, 4)
   permGroup = VVoGp3(perm, 4, 7)
   permOther = VVoGp3(perm, 7, 10)
   permExtra = VVoGp3(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFJ6lf("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVA3iq(self, path):
  txt  = ""
  res  = FFA2wB("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFbRJw("File Attributes:", VVW5KH), txt)
  return txt
 def VVvzkz(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF2gB8(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF2gB8(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF2gB8(os.path.getctime(path))
  return txt
 def VVHGE4(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFA2wB("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFA2wB("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFA2wB("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVgRRg(self, currentSel):
  currentDir  = self["myMenu"].VVeIrD()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVKn9x():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVELdA(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVbUZh(self):
  path = self.VVgRRg(self.VVELdA())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVnGZe()
  if self.mode == self.VVzfS9:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVQ9Xy:
   path = self.VVgRRg(self.VVELdA())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVBMab(self):
  color1 = VVFaDd
  color2 = VVmuI1
  color3 = VVDopz
  totSel = 0
  menuW = 1000
  title = "Options"
  VVY9NT= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVJf4U()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FF10dh(totSel))
     VVY9NT.append((color1 + txt1     , "VVRFHS1" ))
     VVY9NT.append((color1 + txt1 + txt2   , "VVRFHS2" ))
     VVY9NT.append(VVXMhc)
    VVY9NT.append(("[6] Copy"       , "copyBulk" ))
    VVY9NT.append(("[7] Move"       , "moveBulk" ))
    VVY9NT.append(("[8] %sDELETE" % VVLO3F , "VV7b2z" ))
   else:
    FFZWPu(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVHQKD, self.VVQ9Xy):
   VVY9NT.append(("Properties"           , "properties" ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVgRRg(self.VVELdA())
   isEditable = self["myMenu"].VVxQkZ()
   VVY9NT.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVY9NT.append(VVXMhc)
     VVY9NT.append((color1 + "Archiving / Packaging", "VVYRTl_dir"))
   elif os.path.isfile(path):
    selFile = self.VVELdA()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVY9NT.append((color1 + "Archive ...", "VVYRTl_file"))
    isText = False
    txt = ""
    if   isArch            : VVY9NT.extend(self.VV10vW(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVY9NT.extend(self.VVXwlS(True))
    elif selFile.endswith(".sh"):
     VVY9NT.extend(self.VVUh4N(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCVdBH.VVljcj(path):
     VVY9NT.append(VVXMhc)
     VVY9NT.append((color2 + "View"     , "textView_def"))
     VVY9NT.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVY9NT.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVkhAa(path) == "pic":
     VVY9NT.append(VVXMhc)
     VVY9NT.append((color2 + "Set as PIcon for current channel" , "VVXTbo" ))
     if FF1yPm("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVY9NT.append(VVXMhc)
      VVY9NT.append((color2 + "Convert to MVI (1280 x 720 )" , "VVXvMgHd"   ))
      VVY9NT.append((color2 + "Convert to MVI (1920 x 1080)" , "VVXvMgFhd"   ))
    elif selFile.endswith(CCVdBH.VVYz3P()):
     if selFile.endswith(".mvi"):
      if FF1yPm("showiframe"):
       VVY9NT.append(VVXMhc)
       VVY9NT.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVY9NT.append(VVXMhc)
      VVY9NT.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVY9NT.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVY9NT.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVY9NT.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVY9NT.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVY9NT.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVvvr3" ))
    if len(txt) > 0:
     VVY9NT.append(VVXMhc)
     VVY9NT.append((color1 + txt, "VV6PeB"))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("[4] Create SymLink", "VV5tt0"))
   if isEditable:
    VVY9NT.append(("[5] Rename"      , "VVD5h8" ))
    VVY9NT.append(("[6] Copy"       , "copyFileOrDir" ))
    VVY9NT.append(("[7] Move"       , "moveFileOrDir" ))
    VVY9NT.append(("[8] %sDELETE" % VVLO3F , "VVHTkH" ))
    if fileExists(path):
     VVY9NT.append(VVXMhc)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVY9NT.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVY9NT.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVY9NT.append((chmodTxt + "777)", "chmod777"))
   VVY9NT.append(VVXMhc)
   VVY9NT.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVY9NT.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCVdBH.VV950I(self)
   if fPath:
    VVY9NT.append(VVXMhc)
    VVY9NT.append((color2 + "Go to Current Movie Dir", "VVg351"))
  FFaJ04(self, self.VVS58K, width=menuW, height=1050, title=title, VVY9NT=VVY9NT, rcuSearch=False, VVU4bo="#00101020", VVdq78="#00101A2A")
 def VVS58K(self, item=None):
  if item is not None:
   path = self.VVgRRg(self.VVELdA())
   selFile = self.VVELdA()
   if   item == "VVRFHS1"    : self.VVRFHS(False)
   if   item == "VVRFHS2"    : self.VVRFHS(True)
   elif item == "copyBulk"     : self.VVyogk(False)
   elif item == "moveBulk"     : self.VVyogk(True)
   elif item == "VV7b2z"    : self.VV7b2z()
   elif item == "properties"    : self.VVwB5t()
   elif item == "VVYRTl_dir" : self.VVYRTl(path, True)
   elif item == "VVYRTl_file" : self.VVYRTl(path, False)
   elif item == "VVRx3U"  : self.VVRx3U(path)
   elif item == "VVHAlL"  : self.VVHAlL(path)
   elif item.startswith("extract_")  : self.VVwYwF(path, selFile, item)
   elif item.startswith("script_")   : self.VVQFgu(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVBnfn(path, selFile, item)
   elif item.startswith("textView_def") : FF2tbi(self, path)
   elif item.startswith("textView_enc") : self.VVSvTa(path)
   elif item.startswith("text_Edit")  : FFDKj1(self, BF(CCbHA8, self, path), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVbZpd(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVbZpd(path, "Save as Other Encoding", False)
   elif item.startswith("VVvvr3") : self.VVvvr3(path)
   elif item == "viewAsBootlogo"   : self.VVvmCS(path, True)
   elif item == "addMovieToBouquet"  : self.VVKJfb(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVKJfb(path, True)
   elif item == "playWith"     : self.VVhbc7(path)
   elif item == "VVXTbo" : self.VVXTbo(path)
   elif item == "VVXvMgHd"   : FFDKj1(self, BF(self.VVXvMg, path, False))
   elif item == "VVXvMgFhd"   : FFDKj1(self, BF(self.VVXvMg, path, True))
   elif item == "VV5tt0"   : self.VV5tt0(path, selFile)
   elif item == "VVD5h8"   : self.VVD5h8(path, selFile)
   elif item == "copyFileOrDir"   : self.VVzDJP(path, False)
   elif item == "moveFileOrDir"   : self.VVzDJP(path, True)
   elif item == "VVHTkH"   : self.VVHTkH(path, selFile)
   elif item == "chmod644"     : self.VVaYZb(path, selFile, "644")
   elif item == "chmod755"     : self.VVaYZb(path, selFile, "755")
   elif item == "chmod777"     : self.VVaYZb(path, selFile, "777")
   elif item == "createNewFile"   : self.VVHUjI(path, True)
   elif item == "createNewDir"    : self.VVHUjI(path, False)
   elif item == "VVg351"   : self.VVg351()
   elif item == "VV6PeB"    : self.VV6PeB()
 def VV6PeB(self):
  if self.mode == self.VVQ9Xy and not self.patternMode == "poster":
   return
  selFile = self.VVELdA()
  path  = self.VVgRRg(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVkhAa(path)
   if   cat == "pic"       : self.VVF83y(path)
   elif cat == "txt"       : FF2tbi(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVvCls(path, selFile)
   elif cat == "scr"       : self.VVHMy5(path, selFile)
   elif cat == "m3u"       : self.VVmEY9(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVvPwo(path, selFile)
   elif cat in ("mov", "mus")     : self.VVvmCS(path)
   elif not CCVdBH.VVljcj(path) : FF2tbi(self, path)
 def VVF83y(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVkhAa(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCG5Yr.VV12Wn(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVrDQN)
 def VVrDQN(self, path):
  self.VVppN1(path)
 def VVvmCS(self, path, asLogo=False):
  if asLogo : CCGkpt.VVwDY6(self, path)
  else  : FFDKj1(self, BF(self.VVe3wa, self, path), title="Playing Media ...")
 def VV1QYa(self):
  if self["keyBlue"].getVisible():
   VV0wO4 = self.VVcxHB()
   if VV0wO4:
    path = self.VVgRRg(self.VVELdA())
    enableGreenBtn = False if path in self.VVcxHB() else True
    newList = []
    for line in VV0wO4:
     newList.append((line, line))
    VVtVox  = ("Delete"    , self.VVB6Zi    )
    VV0Xwe  = ("Add Current Dir"   , BF(self.VVy5El, path) ) if enableGreenBtn else None
    VVMxmU = ("Move Up"     , self.VVqWrg    )
    VV8vtf  = ("Move Down"   , self.VVqXqa    )
    self.bookmarkMenu = FFaJ04(self, self.VVvsTo, width=1200, title="Bookmarks", VVY9NT=newList, minRows=10 ,VVtVox=VVtVox, VV0Xwe=VV0Xwe, VVMxmU=VVMxmU, VV8vtf=VV8vtf, VVU4bo="#00000022", VVdq78="#00000022")
 def VVB6Zi(self, menuInstance=None, path=None):
  VV0wO4 = self.VVcxHB()
  if VV0wO4:
   while path in VV0wO4:
    VV0wO4.remove(path)
   self.VVdB2Y(VV0wO4)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV2zjf(VV0wO4)
   self.bookmarkMenu.VVIIgL(("Add Current Dir", BF(self.VVy5El, path)))
  else:
   FFZWPu(self, "Removed", 800)
  self.VVnGZe()
 def VVy5El(self, path, menuInstance=None, item=None):
  VV0wO4 = self.VVcxHB()
  if len(VV0wO4) >= self.VVNi7Z:
   FFh60c(SELF, "Max bookmarks reached (max=%d)." % self.VVNi7Z)
  elif not path in VV0wO4:
   if not os.path.isdir(path):
    path = FFBCGr(path, True)
   newList = [path] + VV0wO4
   self.VVdB2Y(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV2zjf(newList)
    self.bookmarkMenu.VVIIgL()
   else:
    FFZWPu(self, "Added", 800)
  self.VVnGZe()
 def VVqWrg(self, VVELdAObj, path):
  if self.bookmarkMenu:
   VV0wO4 = self.bookmarkMenu.VVwYKV(True)
   if VV0wO4:
    self.VVdB2Y(VV0wO4)
 def VVqXqa(self, VVELdAObj, path):
  if self.bookmarkMenu:
   VV0wO4 = self.bookmarkMenu.VVwYKV(False)
   if VV0wO4:
    self.VVdB2Y(VV0wO4)
 def VVvsTo(self, folder=None):
  if folder:
   folder = FFd5Wt(folder)
   self["myMenu"].VVxD9b(folder)
   self["myMenu"].moveToIndex(0)
  self.VVbUZh()
 def VVcxHB(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV85Dd(self):
  return True if VVcxHB() else False
 def VVdB2Y(self, VV0wO4):
  line = ",".join(VV0wO4)
  FFoBdB(CFG.browserBookmarks, line)
 def VVppN1(self, path):
  if fileExists(path):
   fDir  = FFd5Wt(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVxD9b(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFZWPu(self, "Not found", 1000)
 def VVg351(self, chDir=True):
  fPath, fDir, fName = CCVdBH.VV950I(self)
  self.VVppN1(fPath)
 def VVUpbc(self):
  path = self.VVgRRg(self.VVELdA())
  isAdd = False if path in self.VVcxHB() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VV619a, VVPWV9, VVmuI1
  VVY9NT = []
  VVY9NT.append(("Find Files ..." , "find"))
  VVY9NT.append(("Sort ..."   , "sort"))
  VVY9NT.append(VVXMhc)
  if isAdd: VVY9NT.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVY9NT.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVzfS9:
   VVY9NT.append(VVXMhc)
   if self.multiSelectState: VVY9NT.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVY9NT.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVY9NT.append(       (c3 + "Select all"    , "selAll"  ))
  FFaJ04(self, BF(self.VVPlsr, path), width=750, title="More Options", VVY9NT=VVY9NT, VVU4bo="#00221111", VVdq78="#00221111")
 def VVPlsr(self, path, item):
  if item:
   if   item == "find"  : self.VV3hrL(path)
   elif item == "sort"  : self.VVUstH()
   elif item == "addBM" : self.VVy5El(path)
   elif item == "remBM" : self.VVB6Zi(None, path)
   elif item == "start" : self.VVLKif(path)
   elif item == "multiOn" : self.VVcE0N(True)
   elif item == "multiOff" : self.VVcE0N(False)
   elif item == "selAll" : self.VVcE0N(True, True)
 def VVcE0N(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFDKj1(self, BF(self["myMenu"].VV7PM0, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VV9Riq(self.VVWd2n if isOn else self.VVc5nL)
 def VV9Riq(self, mode=0):
  if   mode == self.VVbgJw : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVWd2n: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVU4bo, self.VVdq78
  FFRkaP(self["myTitle"], titBg)
  FFRkaP(self["myBar"], titBg)
  FFRkaP(self["myBody"], bodBg)
  FFRkaP(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VViyGj()
  else     : bg, txt = VVkhZN[3], "Bookmarks"
  FFKpuS(self["keyBlue"], txt)
  FFRkaP(self["keyBlue"], bg)
  self.VVnGZe()
 def VViyGj(self):
  return "Selected Items = %d" % self["myMenu"].VVJf4U()
 def VVnGZe(self):
  if self.VVcxHB() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VV3hrL(self, path):
  VVY9NT = []
  VVY9NT.append(("Find in Current Directory"    , "findCur"  ))
  VVY9NT.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVY9NT.append(("Find in all Storage Systems"    , "findAll"  ))
  FFaJ04(self, BF(self.VVe29P, path), width=700, title="Find File/Pattern", VVY9NT=VVY9NT, VVNDcU=True, VVFP3k=True, VVU4bo="#00221111", VVdq78="#00221111")
 def VVe29P(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVCqZG(0, path, title)
   elif item == "findCurR" : self.VVCqZG(1, path, title)
   elif item == "findAll" : self.VVCqZG(2, path, title)
 def VVCqZG(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FF5ZDh(self, BF(self.VV44iu, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VV44iu(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFoBdB(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFZWPu(self, "No entery", 1500)
   elif badLst  : FFZWPu(self, "Too many file !", 1500)
   else   : FFDKj1(self, BF(self.VVZ5bC, mode, path, title, filePatt), title="Searching ...")
 def VVZ5bC(self, mode, path, title, filePatt):
  lst = FFLYXX(FFJvZy("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCVdBH.VVTfqS(lst)
   if err:
    FFh60c(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVo8Jh = (""     , self.VVf4EA , [])
    VVY2vy = ("Go to File Location", self.VVV7j2  , [])
    FFXBR7(self, None, title="%s : %s" % (title, filePatt), header=header, VV0wO4=lst, VVgZrM=widths, VVfp7o=26, VVo8Jh=VVo8Jh, VVY2vy=VVY2vy)
  else:
   FFcw7s(self, "Not found !", 2000)
 def VVV7j2(self, VV5PsO, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VV5PsO.cancel()
   self.VVppN1(path)
  else:
   FFZWPu(VV5PsO, "Path not found !", 1000)
 def VVf4EA(self, VV5PsO, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFbRJw("File:"  , VVmuI1), colList[0])
  txt += "%s\n%s"  % (FFbRJw("Directory:", VVmuI1), FFd5Wt(colList[1]))
  FFHdWy(VV5PsO, txt, title=title)
 def VVUstH(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVWqJF()
  VVY9NT = []
  VVY9NT.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVY9NT.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVY9NT.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVY9NT.append(("Type\t%s" % typeTxt, "typeAlp"))
  VV8vtf = ("Mix", BF(self.VV6v8k, True))
  FFaJ04(self, BF(self.VVDOLZ, False), barText=txt, width=650, title="Sort Options", VVY9NT=VVY9NT, VV8vtf=VV8vtf, VVFP3k=True, VVU4bo="#00221111", VVdq78="#00221111")
 def VV6v8k(self, isMix, menuInstance, item):
  self.VVDOLZ(True, item)
 def VVDOLZ(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVWqJF()
   title = "Sorting ... "
   if   item == "nameAlp": FFDKj1(self, BF(self["myMenu"].VV3YX1, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFDKj1(self, BF(self["myMenu"].VV3YX1, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFDKj1(self, BF(self["myMenu"].VV3YX1, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFDKj1(self, BF(self["myMenu"].VV3YX1, typeMode , isMix, False), title=title)
 def VVLKif(self, path):
  if not os.path.isdir(path):
   path = FFBCGr(path, True)
  FFoBdB(CFG.browserStartPath, path)
  FFZWPu(self, "Done", 500)
 def VVy0F9(self, selFile, VVT00f, command):
  FFe4rI(self, BF(FFx5HE, self, command, VV54cX=self.VVwce4), "%s\n\n%s" % (VVT00f, selFile))
 def VV10vW(self, path, calledFromMenu):
  destPath = self.VVwWuC(path)
  lastPart = FFjufa(destPath)
  color = VVmuI1 if calledFromMenu else ""
  VVY9NT = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVY9NT.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVY9NT.append(VVXMhc)
   VVY9NT.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVY9NT.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVY9NT.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVY9NT.append(VVXMhc)
     VVY9NT.append((color + "Convert .zip to .tar.gz"       , "VVRx3U" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVY9NT.append(VVXMhc)
     VVY9NT.append((color + "Convert .tar.gz to .zip"       , "VVHAlL" ))
  return VVY9NT
 def VVvCls(self, path, selFile):
  FFaJ04(self, BF(self.VVwYwF, path, selFile), title="Compressed File Options", VVY9NT=self.VV10vW(path, False))
 def VVwYwF(self, path, selFile, item=None):
  if item is not None:
   parent  = FFBCGr(path, False)
   destPath = self.VVwWuC(path)
   lastPart = FFjufa(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVwtEz
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFKkrr("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFKkrr("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVwtEz, VVwtEz)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFQHMr(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVRx3U" : self.VVRx3U(path)
    else       : self.VVcO6l(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVHAlL" and path.endswith(".tar.gz"):
    self.VVHAlL(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFA2wB("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFNvXQ(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVwce4()
    else:
     FFh60c(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVMH5E(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FF75pk("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVy0F9(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVy0F9(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFBCGr(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVy0F9(selFile, "Extract Here ?"      , cmd)
 def VVwWuC(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVcO6l(self, item, path, parent, destPath, VVT00f):
  FFe4rI(self, BF(self.VV3fOk, item, path, parent, destPath), VVT00f)
 def VV3fOk(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVwtEz
  cmd  = FFKkrr("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFs7EJ(destPath, VVlwDq))
  cmd +=   sep
  cmd += "fi;"
  FF7o6J(self, cmd, VV54cX=self.VVwce4)
 def VVMH5E(self, item, path, parent, destPath, VVT00f):
  FFe4rI(self, BF(self.VVINgI, item, path, parent, destPath), VVT00f)
 def VVINgI(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFd5Wt(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVwtEz
  cmd  = FFKkrr("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFs7EJ(destPath, VVlwDq))
  cmd +=   sep
  cmd += "fi;"
  FF7o6J(self, cmd, VV54cX=self.VVwce4)
 def VVUh4N(self, addSep=False):
  VVY9NT = []
  if addSep:
   VVY9NT.append(VVXMhc)
  VVY9NT.append((VVmuI1 + "View Script File"  , "script_View"  ))
  VVY9NT.append((VVmuI1 + "Execute Script File" , "script_Execute" ))
  VVY9NT.append((VVmuI1 + "Edit"     , "script_Edit"  ))
  return VVY9NT
 def VVHMy5(self, path, selFile):
  FFaJ04(self, BF(self.VVQFgu, path, selFile), title="Script File Options", VVY9NT=self.VVUh4N())
 def VVQFgu(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF2tbi(self, path)
   elif item == "script_Execute" : self.VVy0F9(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCbHA8(self, path)
 def VVXwlS(self, addSep=False):
  VVY9NT = []
  if addSep:
   VVY9NT.append(VVXMhc)
  VVY9NT.append((VVmuI1 + "Browse IPTV Channels" , "m3u_Browse" ))
  VVY9NT.append((VVmuI1 + "Edit"     , "m3u_Edit" ))
  VVY9NT.append((VVmuI1 + "View"     , "m3u_View" ))
  return VVY9NT
 def VVmEY9(self, path, selFile):
  FFaJ04(self, BF(self.VVBnfn, path, selFile), title="M3U/M3U8 File Options", VVY9NT=self.VVXwlS())
 def VVBnfn(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFDKj1(self, BF(self.session.open, CCHli4, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCbHA8(self, path)
   elif item == "m3u_View"  : FF2tbi(self, path)
 def VVSvTa(self, path):
  if fileExists(path) : FFDKj1(self, BF(CCORAx.VV4EMY, self, path, BF(self.VVC07g, path)), title="Loading Codecs ...")
  else    : FFCpVp(self, path)
 def VVC07g(self, path, item=None):
  if item:
   FF2tbi(self, path, encLst=item)
 def VVbZpd(self, path, title, asUtf8):
  if fileExists(path) : FFDKj1(self, BF(CCORAx.VV4EMY, self, path, BF(self.VVWkI1, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFCpVp(self, path)
 def VVWkI1(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVrdql(path, title, fromEnc, "UTF-8")
   else  : CCORAx.VVk8x7(self, BF(self.VVrdql, path, title, fromEnc), title="Convert to Encoding")
 def VVrdql(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFbRJw("Successful\n\n", VVlwDq)
      txt += FFbRJw("From Encoding (%s):\n" % fromEnc, VVOpMG)
      txt += "%s\n\n" % path
      txt += FFbRJw("To Encoding (%s):\n" % toEnc, VVOpMG)
      txt += "%s\n\n" % outFile
      FFHdWy(self, txt, title=title)
    except:
     FFh60c(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFZWPu(self, "Cannot open file", 2000)
   self.VVwce4()
 def VVvvr3(self, path):
  title = "File Line-Break Conversion"
  FFe4rI(self, BF(self.VVcObV, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVcObV(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFbRJw("File converted:", VVlwDq), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFNvXQ(self, txt, title=title)
  else:
   FFCpVp(self, path, title=title)
 def VVaYZb(self, path, selFile, newChmod):
  FFe4rI(self, BF(self.VVF0RP, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVF0RP(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVENt5)
  result = FFA2wB(cmd)
  if result == "Successful" : FFNvXQ(self, result)
  else      : FFh60c(self, result)
 def VV5tt0(self, path, selFile):
  parent = FFBCGr(path, False)
  self.session.openWithCallback(self.VV3DB5, BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9=parent, VVJO71="Create Symlink here"))
 def VV3DB5(self, newPath):
  if len(newPath) > 0:
   target = self.VVgRRg(self.VVELdA())
   target = FFUEil(target)
   linkName = FFjufa(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFd5Wt(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFh60c(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFe4rI(self, BF(self.VVbpxQ, target, link), "Create Soft Link ?\n\n%s" % txt, VVRAK2=True)
 def VVbpxQ(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVENt5)
  result = FFA2wB(cmd)
  if result == "Successful" : FFNvXQ(self, result)
  else      : FFh60c(self, result)
 def VVD5h8(self, path, selFile):
  lastPart = FFjufa(path)
  FF5ZDh(self, BF(self.VVGcO3, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVGcO3(self, path, selFile, VVHzlS):
  if VVHzlS:
   parent = FFBCGr(path, True)
   if os.path.isdir(path):
    path = FFUEil(path)
   newName = parent + VVHzlS
   cmd = "mv '%s' '%s' %s" % (path, newName, VVENt5)
   if VVHzlS:
    if selFile != VVHzlS:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFe4rI(self, BF(self.VV6O4N, cmd), message, title="Rename file?")
    else:
     FFh60c(self, "Cannot use same name!", title="Rename")
 def VV6O4N(self, cmd):
  result = FFA2wB(cmd)
  if "Fail" in result:
   FFh60c(self, result)
  self.VVwce4()
 def VVRFHS(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVbjEK, title, preserve)
      , VVsfO0 = BF(self.VViTVC, title))
 def VVbjEK(self, title, preserve, VVq6PE):
  totSel = self["myMenu"].VVJf4U()
  totOk = totFail = 0
  VVq6PE.VVlEfz(totSel)
  VVq6PE.VVwxC6 = ["", totSel, totOk, totFail, ""]
  VVq6PE.VVryiB("Prepareing targz file")
  curDir = self["myMenu"].VVeIrD()
  lastPart = FFjufa(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVq6PE or VVq6PE.isCancelled:
      return
     if row[2][6]:
      VVq6PE.VVA8Cz(1)
      name  = FFUEil(row[0][0])
      lastPath = FFjufa(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVq6PE:
       VVq6PE.VVwxC6 = [outF, totSel, totOk, totFail, path]
       VVq6PE.VV7jHd(totOk, lastPath)
  except:
   totFail += 1
   if VVq6PE:
    VVq6PE.VVwxC6 = [outF, totSel, totOk, totFail, path]
 def VViTVC(self, title, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVwxC6
  txt  = "%s:\n%s\n\n"   % (FFbRJw("Output File", VVlwDq), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFbRJw("Failed\t: %d\n" % totFail, VVLO3F)
  if not VVWVbF: txt += "%s\n%s" % (FFbRJw("\nCancelled while copying:", VVLO3F), path)
  FFHdWy(self, txt, title=title)
  self.VVwce4()
 def VVyogk(self, isMove):
  self.session.openWithCallback(BF(self.VVofuz, isMove), BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9=self["myMenu"].VVeIrD(), VVJO71="Move to here" if isMove else "Paste here"))
 def VVofuz(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VV9EMB, title, action, isMove, newPath)
       , VVsfO0 = BF(self.VVuIYh, title, action, isMove, newPath))
 def VV9EMB(self, title, action, isMove, newPath, VVq6PE):
  curDir = self["myMenu"].VVeIrD()
  totOk = totFail = 0
  totSel = self["myMenu"].VVJf4U()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVq6PE.VVlEfz(totSel)
  VVq6PE.VVwxC6 = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVq6PE or VVq6PE.isCancelled:
    return
   if row[2][6]:
    VVq6PE.VVA8Cz(1)
    VVq6PE.VVQgdO(action, totOk, FFjufa(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFjufa(path)
    if os.path.isdir(path): path = FFUEil(path)
    dest = os.path.join(newPath, lastPart)
    res = os.system(FF75pk("%s '%s' '%s'" % (cmd, path, dest)))
    if res == 0 : totOk += 1
    else  : totFail += 1
    if VVq6PE:
     VVq6PE.VVwxC6 = [totSel, totOk, totFail, path]
     VVq6PE.VVQgdO(action, totOk, FFjufa(row[0][0]))
 def VVuIYh(self, title, action, isMove, newPath, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVwxC6
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFbRJw("Failed\t: %d\n" % totFail, VVLO3F)
  if not VVWVbF: txt += "%s\n%s" % (FFbRJw("\nCancelled while copying:", VVLO3F), path)
  FFHdWy(self, txt, title=title)
  self.VVwce4()
 def VV7b2z(self):
  tot = self["myMenu"].VVJf4U()
  FFe4rI(self, BF(FFDKj1, self, self.VVvVTR, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FF10dh(tot)), title="Delete Selection")
 def VVvVTR(self):
  path = self["myMenu"].VVeIrD()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFoJ7V(os.path.join(path, row[0][0]))
  FFZWPu(self)
  self.VVwce4()
 def VVzDJP(self, path, isMove):
  self.session.openWithCallback(BF(self.VVZ7lM, isMove, path), BF(CCVdBH, mode=CCVdBH.VVHQKD, VVWic9=FFBCGr(path, False), VVJO71="Move to here" if isMove else "Paste here"))
 def VVZ7lM(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFUEil(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFUEil(src)
  dst = os.path.join(dst, FFjufa(src))
  if src == dst:
   FFh60c(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFe4rI(self, BF(self.VVlg4s, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFe4rI(self, BF(self.VVlg4s, prams), "Overwrite Destination Files", title=title)
  else         : self.VVlg4s(prams)
 def VVlg4s(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCVdBH.VVBH9G(src) == CCVdBH.VVBH9G(dst):
   FFDKj1(self, BF(self.VVwMNR, prams), title="Moving %s ..." % srcSubj)
  else:
   FFDKj1(self, BF(self.VV9JLz, prams), title="Calculating Size ...")
 def VVwMNR(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFA2wB("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVwce4()
  else:
   FFh60c(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VV9JLz(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFtDuT(src)
  else  : size = FF1rjx(src)
  if size > -1:
   self.session.open(CCRrSr, barTheme=CCRrSr.VVNbOE, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVSpus, prams, size)
       , VVsfO0 = BF(self.VVwOiI, prams))
  else:
   FFh60c(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVSpus(self, prams, size, VVq6PE):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVq6PE.VVlEfz(size)
  VVq6PE.VVwxC6 = ("", "", False)
  def VVhPOT(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFiHj6(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVq6PE or VVq6PE.isCancelled:
        VVq6PE.VVwxC6 = (srcFile, "", True)
        FFiHj6(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVq6PE.VVA8Cz(len(data))
       except Exception as e:
        VVq6PE.VVwxC6 = (srcFile, str(e), False)
        FFiHj6(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFiHj6(srcFile)
   return True
  if isFile:
   tot = 1
   VVhPOT(src, dst)
  else:
   VVq6PE.VVryiB("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FF0U10(src)
   if not VVq6PE or VVq6PE.isCancelled:
    VVq6PE.VVwxC6 = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVq6PE.VVwxC6 = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVq6PE.VVryiB("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVhPOT(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     os.system(FF75pk("rm -fr '%s'" % Dir))
   if isMove:
    os.system(FF75pk("rm -fr '%s'" % src))
 def VVwOiI(self, prams, VVWVbF, VVwxC6, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVwxC6
  if err:
   FFh60c(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFZWPu(self, "Canelled", 1000)
   else  : FFh60c(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFZWPu(self, "Done", 1500, isGrn=True)
  if VVWVbF and isMove:
   self.VVwce4()
 def VVHTkH(self, path, fileName):
  path = FFUEil(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFe4rI(self, BF(FFDKj1, self, BF(self.VV52sP, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV52sP(self, path):
  FFoJ7V(path)
  FFZWPu(self)
  self.VVwce4()
 def VVHUjI(self, path, isFile):
  dirName = FFd5Wt(os.path.dirname(path))
  if isFile : objName, VVHzlS = "File"  , self.edited_newFile
  else  : objName, VVHzlS = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF5ZDh(self, BF(self.VVsDFC, dirName, isFile, title), title=title, defaultText=VVHzlS, message="Enter %s Name:" % objName)
 def VVsDFC(self, dirName, isFile, title, VVHzlS):
  if VVHzlS:
   if isFile : self.edited_newFile = VVHzlS
   else  : self.edited_newDir  = VVHzlS
   path = dirName + VVHzlS
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVENt5)
    else  : cmd = "mkdir '%s' %s" % (path, VVENt5)
    result = FFA2wB(cmd)
    if "Fail" in result:
     FFh60c(self, result)
    self.VVwce4()
   else:
    FFh60c(self, "Name already exists !\n\n%s" % path, title)
 def VVvPwo(self, path, selFile):
  c1, c2, c3 = VVPWV9, VVmuI1, VVFaDd
  VVY9NT = []
  VVY9NT.append((c1 + "List Package Files"         , "VVtdSV"     ))
  VVY9NT.append((c1 + "Package Information"         , "VVwsPB"     ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c2 + "Install Package"          , "VVHieQ_CheckVersion" ))
  VVY9NT.append((c2 + "Install Package (force reinstall)"     , "VVHieQ_ForceReinstall" ))
  VVY9NT.append((c2 + "Install Package (force overwrite)"     , "VVHieQ_ForceOverwrite" ))
  VVY9NT.append((c2 + "Install Package (force downgrade)"     , "VVHieQ_ForceDowngrade" ))
  VVY9NT.append((c2 + "Install Package (ignore failed dependencies)"  , "VVHieQ_IgnoreDepends" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c3 + "Remove Related Package"        , "VVMbQp_ExistingPackage" ))
  VVY9NT.append((c3 + "Remove Related Package (force remove)"    , "VVMbQp_ForceRemove"  ))
  VVY9NT.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVMbQp_IgnoreDepends" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Extract Files"           , "VVojfd"     ))
  VVY9NT.append(("Unbuild Package"           , "VV4Fxo"     ))
  FFaJ04(self, BF(self.VVeSTW, path, selFile), VVY9NT=VVY9NT)
 def VVeSTW(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVtdSV"      : self.VVtdSV(path, selFile)
   elif item == "VVwsPB"      : self.VVwsPB(path)
   elif item == "VVHieQ_CheckVersion"  : self.VVHieQ(path, selFile, VVzo0S     )
   elif item == "VVHieQ_ForceReinstall" : self.VVHieQ(path, selFile, VVPgiB )
   elif item == "VVHieQ_ForceOverwrite" : self.VVHieQ(path, selFile, VVftKI )
   elif item == "VVHieQ_ForceDowngrade" : self.VVHieQ(path, selFile, VV2nWE )
   elif item == "VVHieQ_IgnoreDepends" : self.VVHieQ(path, selFile, VVONbh )
   elif item == "VVMbQp_ExistingPackage" : self.VVMbQp(path, selFile, VVFsUb     )
   elif item == "VVMbQp_ForceRemove"  : self.VVMbQp(path, selFile, VVChqD  )
   elif item == "VVMbQp_IgnoreDepends"  : self.VVMbQp(path, selFile, VVKfEX )
   elif item == "VVojfd"     : self.VVojfd(path, selFile)
   elif item == "VV4Fxo"     : self.VV4Fxo(path, selFile)
   else           : self.close()
 def VVtdSV(self, path, selFile):
  if FF1yPm("ar") : cmd = "allOK='1';"
  else    : cmd  = FFYhIs()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVwtEz, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVwtEz, VVwtEz)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFb5TJ(self, cmd, VV54cX=self.VVwce4)
 def VVojfd(self, path, selFile):
  lastPart = FFjufa(path)
  dest  = FFBCGr(path, True) + selFile[:-4]
  cmd  =  FFYhIs()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FF75pk("mkdir '%s'" % dest) + ";"
  cmd +=    FF75pk("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFs7EJ(dest, VVlwDq))
  cmd += "fi;"
  FFx5HE(self, cmd, VV54cX=self.VVwce4)
 def VV4Fxo(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV8Pva = os.path.splitext(path)[0]
  else        : VV8Pva = path + "_"
  if path.endswith(".deb")   : VVLnai = "DEBIAN"
  else        : VVLnai = "CONTROL"
  cmd  = FFYhIs()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV8Pva, FFDyJa())
  cmd += "  mkdir '%s';"    % VV8Pva
  cmd += "  CONTPATH='%s/%s';"  % (VV8Pva, VVLnai)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV8Pva
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV8Pva, VV8Pva)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV8Pva
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV8Pva, VV8Pva)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV8Pva
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV8Pva
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV8Pva, FFs7EJ(VV8Pva, VVlwDq))
  cmd += "fi;"
  FFx5HE(self, cmd, VV54cX=self.VVwce4)
 def VVwsPB(self, path):
  listCmd  = FFv5Rb(VV5YBB, "")
  infoCmd  = FFXUpj(VVihTi , "")
  filesCmd = FFXUpj(VVgD1q, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFmquk(VVOpMG)
   notInst = "Package not installed."
   cmd  = FFsHvy("File Info", VVOpMG)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFsHvy("System Info", VVOpMG)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFs7EJ(notInst, VVLO3F))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFsHvy("Related Files", VVOpMG)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFQHMr(self, cmd)
  else:
   FFhvmT(self)
 def VVHieQ(self, path, selFile, cmdOpt):
  cmd = FFXUpj(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFe4rI(self, BF(FFx5HE, self, cmd, VV54cX=FFgh2b), "Install Package ?\n\n%s" % selFile)
  else:
   FFhvmT(self)
 def VVMbQp(self, path, selFile, cmdOpt):
  listCmd  = FFv5Rb(VV5YBB, "")
  infoCmd  = FFXUpj(VVihTi, "")
  instRemCmd = FFXUpj(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFs7EJ(errTxt, VVLO3F))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFs7EJ(cannotTxt, VVLO3F))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFs7EJ(tryTxt, VVLO3F))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFe4rI(self, BF(FFx5HE, self, cmd, VV54cX=FFgh2b), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFhvmT(self)
 def VVB7tv(self, path):
  hostName = FFA2wB("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVYRTl(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVY9NT = []
  VVY9NT.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVY9NT.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVY9NT.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVY9NT.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVY9NT.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVY9NT.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVY9NT.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVY9NT.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVY9NT.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVY9NT.append(VVXMhc)
   VVY9NT.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVY9NT.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFaJ04(self, BF(self.VVqYjS, path, isDir, title), VVY9NT=VVY9NT, title=title, VVU4bo=c1, VVdq78=c2)
 def VVqYjS(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVBU4u(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVBU4u(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVBU4u(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVBU4u(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVBU4u(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVBU4u(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVBU4u(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVBU4u(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVBU4u(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVBU4u(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVQ2D0(path, False)
   elif item == "convertDirToDeb" : self.VVQ2D0(path, True)
 def VVQ2D0(self, path, VVqneK):
  self.session.openWithCallback(self.VVwce4, BF(CC0rPh, path=path, VVqneK=VVqneK))
 def VVBU4u(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFBCGr(path, True)
  lastPart = FFjufa(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFKkrr("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFKkrr("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFKkrr("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVwtEz
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FF75pk("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFs7EJ(failed, VVxsyh))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFs7EJ(srcTxt, VV619a))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFs7EJ("Output", VVlwDq))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFs7EJ(failed, VVzF5b))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFb5TJ(self, cmd, VV54cX=self.VVwce4, title=title)
 def VVKJfb(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCVdBH.VVYDtv(FFBCGr(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCgBRx(self, self, title, BF(self.VV7kgt, pathLst))
 def VV7kgt(self, pathLst):
  return CCgBRx.VV4usi(pathLst)
 def VVRx3U(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VV4d9Q, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFe4rI(self, BF(FFDKj1, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFDKj1(self, fnc, title=txt)
  else:
   FFh60c(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VV4d9Q(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFHdWy(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVwce4()
  else:
   FFiHj6(tarPath)
   FFh60c(self, "Error while converting.", title=title)
 def VVHAlL(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVh5Uq, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFe4rI(self, BF(FFDKj1, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFDKj1(self, fnc, title=txt)
  else:
   FFh60c(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVh5Uq(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFHdWy(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVwce4()
  else:
   FFiHj6(zipPath)
   FFh60c(self, "Error while converting.", title=title)
 def VVXvMg(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFd5Wt(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FF75pk("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FF75pk("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FF75pk("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VVwce4()
   FFNvXQ(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFh60c(self, "Cannot convert this file !", title=title)
 def VVXTbo(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCZBEU.VV0FjB()
  if pathExists(pPath):
   if CC1HIn.VV4AmA(self, title, False, cbFnc=BF(self.VVXTbo, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVY9NT = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVY9NT.append(("%d x %d" % (item), item))
    infoBtnFnc = self.VVmyrX
    VV8vtf = ("Stretch", BF(self.VVXnOA, title, path, picon))
    menuInstance = FFaJ04(self, BF(self.VVAibX, title, path, picon, False), VVY9NT=VVY9NT, width=700, title='PIcon Max. Size', infoBtnFnc=infoBtnFnc, VV8vtf=VV8vtf, barText="OK = Fit within size")
    menuInstance.VVsNwl(3)
  else:
   FFh60c(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVXnOA(self, title, path, picon, VVELdAObj, item):
  self.VVAibX(title, path, picon, True, item)
  VVELdAObj.cancel()
 def VVAibX(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFuQxT(self, fncMode=CC8xkn.VVjn7L)
   except Exception as e:
    FFh60c(self, "Image Processing error:\n\n%s" % e)
 def VVmyrX(self, menuInstance, txt, ref, ndx):
  FFv9kY(self, "_help_resize", "Picture File Resizing")
 def VVhbc7(self, path):
  FFaJ04(self, BF(self.VVgISV, path), VVY9NT=CCHli4.VVtiEZ(), width=650, title="Select Player", VVU4bo="#11220000", VVdq78="#11220000")
 def VVgISV(self, path, rType=None):
  if rType:
   FFDKj1(self, BF(self.VVe3wa, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVe3wa(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CC0rhb.VVpY9t(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VV950I(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFd5Wt(fDir), fName
  return "", "", ""
 @staticmethod
 def VVFQUX(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVnPRW(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVFJRm(size, mode=0):
  txt = CCVdBH.VVSyII(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVSyII(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVljcj(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVoq5s(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFh60c(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVYz3P():
  tDict = CCRrOq.VVhZIz()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVYDtv(path):
  lst = []
  for ext in CCVdBH.VVYz3P():
   lst.extend(FFzuBj(path, "*.%s" % ext))
  return sorted(lst, key=FFKPxS(FFSOId))
 @staticmethod
 def VVAhRE(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVBH9G(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVTfqS(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVwdtR:
   return VVwdtR
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCRrOq(MenuList):
 VVxojc   = 0
 VVoWFG   = 1
 VVwett   = 2
 VVQbOI   = 3
 VV2Qr2   = 4
 VVZBqS   = 5
 VVDOcz   = 6
 VVnjRl   = 7
 VV842X   = "<List of Storage Devices>"
 VVq03P  = "<Parent Directory>"
 VVkj0r   = 0
 VVKc26   = 1
 VVl34u = 2
 VVq5R5  = 3
 VV6C9s   = 4
 VV8vvw   = 5
 FILE_TYPE_LINK   = 6
 VVwDdW  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVkElI=False, directory="/", VVXqjy=True, VVSuut=True, VVNARW=True, VV1KUp=None, VV8fcU=False, VV0P7j=False, VVQqhv=False, isTop=False, VVetSU=None, VVHDWp=1000, VVfp7o=30, VVbjgU=30):
  MenuList.__init__(self, list, VVkElI, eListboxPythonMultiContent)
  self.VVXqjy  = VVXqjy
  self.VVSuut    = VVSuut
  self.VVNARW  = VVNARW
  self.VV1KUp  = VV1KUp
  self.VV8fcU   = VV8fcU
  self.VV0P7j   = VV0P7j or []
  self.VVQqhv   = VVQqhv or []
  self.isTop     = isTop
  self.additional_extensions = VVetSU
  self.VVHDWp    = VVHDWp
  self.VVfp7o    = VVfp7o
  self.VVbjgU    = VVbjgU
  self.EXTENSIONS    = CCRrOq.VVhZIz()
  self.VVfpZj   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFa79O("#11ff4444")
  self.l.setFont(0, gFont(VVrHrQ, self.VVfp7o))
  self.l.setItemHeight(self.VVbjgU)
  self.png_mem   = CCRrOq.VVPbiG("mem")
  self.png_usb   = CCRrOq.VVPbiG("usb")
  self.png_fil   = CCRrOq.VVPbiG("fil")
  self.png_dir   = CCRrOq.VVPbiG("dir")
  self.png_dirup   = CCRrOq.VVPbiG("dirup")
  self.png_srv   = CCRrOq.VVPbiG("srv")
  self.png_slwfil   = CCRrOq.VVPbiG("slwfil")
  self.png_slbfil   = CCRrOq.VVPbiG("slbfil")
  self.png_slwdir   = CCRrOq.VVPbiG("slwdir")
  self.VVdw9a()
  self.VVxD9b(directory)
 @staticmethod
 def VVPbiG(category):
  return LoadPixmap("%s%s.png" % (VVE5ib, category), getDesktop(0))
 @staticmethod
 def VVhZIz():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVzEpb(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFUEil(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFbRJw(" -> " , VVOpMG) + FFbRJw(os.readlink(path), VVlwDq)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVbjgU + 10, 0, self.VVHDWp, self.VVbjgU, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVmqKk: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVbjgU-4, self.VVbjgU-4, png, None, None, VVmqKk))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVbjgU-4, self.VVbjgU-4, png, None, None))
  return tableRow
 def VVkhAa(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVdw9a(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVkLD3(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV1F7E(self, file):
  if os.path.realpath(file) == file:
   return self.VVkLD3(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVkLD3(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVkLD3(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VV3HZK(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVs72H(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VV7PM0(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVs72H(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVs72H(self, row, bg):
  if self.VV7IlP(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VV7IlP(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VV8vvw, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VV6C9s:
    if   VVRR1W           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVxQkZ(self):
  return self.VV7IlP(self.list[self.l.getCurrentSelectionIndex()])
 def VVJf4U(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVSGBc(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVxD9b(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVNARW:
    self.current_mountpoint = self.VV1F7E(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVNARW:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVQqhv and not self.VVSGBc(path, self.VV0P7j):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVzEpb(name=p.description, absolute=path, isDir=True, typ=self.VVkj0r, png=png))
    path = "/"
    if path not in self.VVQqhv and not self.VVSGBc(path, self.VV0P7j):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVzEpb(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVKc26, png=self.png_mem))
  elif self.VV8fcU:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVfpZj = eServiceCenter.getInstance()
   list = VVfpZj.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVXqjy and not self.isTop:
   if directory == self.current_mountpoint and self.VVNARW:
    self.list.append(self.VVzEpb(name=self.VV842X, absolute=None, isDir=True, typ=self.VVl34u, png=self.png_dirup))
   elif (directory != "/") and not (self.VVQqhv and self.VVkLD3(directory) in self.VVQqhv):
    self.list.append(self.VVzEpb(name=self.VVq03P, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVq5R5, png=self.png_dirup))
  if self.VVXqjy:
   for x in directories:
    if not (self.VVQqhv and self.VVkLD3(x) in self.VVQqhv) and not self.VVSGBc(x, self.VV0P7j):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVzEpb(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFUEil(x)) else self.VV6C9s, png=png))
  if self.VVSuut:
   for x in files:
    if self.VV8fcU:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFbRJw(" -> " , VVOpMG) + FFbRJw(target, VVlwDq)
       else:
        png = self.png_slbfil
        name += FFbRJw(" -> " , VVOpMG) + FFbRJw(target, VVzF5b)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVkhAa(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVE5ib, category))
    if (self.VV1KUp is None) or iCompile(self.VV1KUp[0], flags=self.VV1KUp[1]).search(path):
     self.list.append(self.VVzEpb(name=name, absolute=x , isDir=False, typ=self.VV8vvw, png=png))
  if self.VVNARW and len(self.list) == 0:
   self.list.append(self.VVzEpb(name=FFbRJw("No USB connected", VVlhbS), absolute=None, isDir=False, typ=self.VVwDdW, png=self.png_usb))
  self.l.setList(self.list)
  self.VV3YX1()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVeIrD(self):
  return self.current_directory
 def VVKn9x(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVN1OQ(self):
  return self.VVbVcD() and self.VVeIrD()
 def VVbVcD(self):
  return self.list[0][1][7] in (self.VV842X, self.VVq03P)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVxD9b(self.getSelection()[0], self.current_directory)
 def VVjV0s(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVaPWU)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVaPWU)
 def VVaPWU(self, action, device):
  self.VVdw9a()
  if self.current_directory is None:
   self.VVgJud()
 def VVgJud(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVxD9b(self.current_directory, self.VVjV0s())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVWqJF(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVxojc : nameAlpMode, nameAlpTxt = self.VVoWFG, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVxojc, sAZ
  if mode == self.VVwett : nameNumMode, nameNumTxt = self.VVQbOI, s90
  else       : nameNumMode, nameNumTxt = self.VVwett, s09
  if mode == self.VV2Qr2 : dateMode, dateTxt = self.VVZBqS, sON
  else       : dateMode, dateTxt = self.VV2Qr2, sNO
  if mode == self.VVDOcz : typeMode, typeTxt = self.VVnjRl, sZA
  else       : typeMode, typeTxt = self.VVDOcz, sAZ
  if   mode in (self.VVxojc, self.VVoWFG): txt = "Name (%s)" % (sAZ if mode == self.VVxojc else sZA)
  elif mode in (self.VVwett, self.VVQbOI): txt = "Name (%s)" % (s09 if mode == self.VVxojc else s90)
  elif mode in (self.VV2Qr2, self.VVZBqS): txt = "Date (%s)" % (sNO if mode == self.VV2Qr2 else sON)
  elif mode in (self.VVDOcz, self.VVnjRl): txt = "Type (%s)" % (sAZ if mode == self.VVDOcz else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VV3YX1(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFoBdB(CFG.browserSortMode, mode)
   FFoBdB(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVbVcD() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVxojc, self.VVoWFG):
    rev = True if mode == self.VVoWFG else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVwett, self.VVQbOI):
    rev = True if mode == self.VVQbOI else False
    self.list = sorted(self.list[item0:], key=FFKPxS(BF(self.VVBagW, isMix, rev)), reverse=rev)
   elif mode in (self.VV2Qr2, self.VVZBqS):
    rev = True if mode == self.VVZBqS else False
    self.list = sorted(self.list[item0:], key=FFKPxS(BF(self.VVdvHo, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVnjRl else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVBagW(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFSOId(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFggFJ(dir2, dir1) or FFSOId(name1, name2)
 def VVdvHo(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFggFJ(stat2.st_ctime, stat1.st_ctime)
    else : return FFggFJ(dir2, dir1) or FFggFJ(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCYdfZ(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFWDRO(VVZm1S, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV0wO4   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVvKdF(defFG, "#00FFFFFF")
  self.defBG   = self.VVvKdF(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFsd9n(self, self.Title)
  self["keyRed"].show()
  FFKpuS(self["keyGreen"] , "< > Transp.")
  FFKpuS(self["keyYellow"], "Foreground")
  FFKpuS(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVVGuo     ,
   "green"   : self.VVVGuo     ,
   "yellow"  : BF(self.VVtcPy, False)  ,
   "blue"   : BF(self.VVtcPy, True)  ,
   "up"   : self.VVS2uh       ,
   "down"   : self.VV4dKD      ,
   "left"   : self.VVBeVJ      ,
   "right"   : self.VVk9Xp      ,
   "last"   : BF(self.VV8y8g, -5) ,
   "next"   : BF(self.VV8y8g, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVrYby)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFRkaP(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFRkaP(self["keyRed"] , c)
  FFRkaP(self["keyGreen"] , c)
  self.VVmnoU()
  self.VVAPKo()
  FFR9H9(self["myColorTst"], self.defFG)
  FFRkaP(self["myColorTst"], self.defBG)
 def VVvKdF(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVAPKo(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVMuWj(0, 0)
     return
 def VVVGuo(self):
  self.close(self.defFG, self.defBG)
 def VVS2uh(self): self.VVMuWj(-1, 0)
 def VV4dKD(self): self.VVMuWj(1, 0)
 def VVBeVJ(self): self.VVMuWj(0, -1)
 def VVk9Xp(self): self.VVMuWj(0, 1)
 def VVMuWj(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVWegY()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVcCF9()
 def VVmnoU(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVcCF9(self):
  color = self.VVWegY()
  if self.isBgMode: FFRkaP(self["myColorTst"], color)
  else   : FFR9H9(self["myColorTst"], color)
 def VVtcPy(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVmnoU()
   self.VVAPKo()
 def VV8y8g(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVMuWj(0, 0)
 def VVLV8J(self):
  return hex(self.transp)[2:].zfill(2)
 def VVWegY(self):
  return ("#%s%s" % (self.VVLV8J(), self.colors[self.curRow][self.curCol])).upper()
class CC88r6(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFWDRO(VVw6T7, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFsd9n(self, title="%s%s%s" % (self.Title, " " * 10, FFbRJw("Change values with Up , Down, < , 0 , >", VVlhbS)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVz6TU      ,
   "cancel" : self.VVNdWb      ,
   "info"  : self.VVqYKO    ,
   "red"  : self.VVNEy6  ,
   "green"  : self.VVbksr   ,
   "yellow" : BF(self.VVO5S2, 0)  ,
   "blue"  : self.VVDi3O    ,
   "menu"  : self.VVvPMu      ,
   "left"  : self.VVBeVJ      ,
   "right"  : self.VVk9Xp      ,
   "last"  : self.VVwzUh     ,
   "next"  : self.VVGmNX     ,
   "0"   : self.VVMSxS    ,
   "up"  : self.VVS2uh       ,
   "down"  : self.VV4dKD      ,
   "pageUp" : BF(self.VVOGH9, True) ,
   "pageDown" : BF(self.VVOGH9, False) ,
   "chanUp" : BF(self.VVOGH9, True) ,
   "chanDown" : BF(self.VVOGH9, False) ,
   "play"  : BF(self.VVIQbN, "pause")  ,
   "pause"  : BF(self.VVIQbN, "pause")  ,
   "playPause" : BF(self.VVIQbN, "pause")  ,
   "stop"  : BF(self.VVIQbN, "pause")  ,
   "audio"  : BF(self.VVIQbN, "audio")  ,
   "subtitle" : BF(self.VVIQbN, "subtitle") ,
   "rewind" : BF(self.VVIQbN, "rewind" ) ,
   "forward" : BF(self.VVIQbN, "forward" ) ,
   "rewindDm" : BF(self.VVIQbN, "rewindDm") ,
   "forwardDm" : BF(self.VVIQbN, "forwardDm")
  }, -1)
  self.VVm20Z()
  self.onShown.append(self.VVrYby)
  self.onClose.append(self.VVrkBP)
 def VVm20Z(self):
  lst = []
  for fil in FFzuBj(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVnKBD:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVrYby(self):
  self.onShown.remove(self.VVrYby)
  FF4AQy(self)
  FFnx82(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVRJPv()
  self.VVMILi()
  self.VV39WC()
 def VVrkBP(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVo7Rs(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFRkaP(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVzeaA()
 def VVRJPv(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFRkaP(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVz6TU(self):
  if self.settingShown:
   confItem = self.VVsXWp()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVY9NT = []
   if isinstance(lst[0], tuple):
    for item in lst: VVY9NT.append((item[1], item[0]))
   else:
    for item in lst: VVY9NT.append((item, item))
   menuInstance = FFaJ04(self, self.VVrRZs, VVY9NT=VVY9NT, width=700, title=title, VVU4bo="#33221111", VVdq78="#33110011")
   menuInstance.VVsNwl(confItem.getIndex())
  else:
   self.close("subtExit")
 def VVrRZs(self, item=None):
  if item:
   self.VVsXWp()[self.CursorPos].setValue(item)
   self.VVzeaA()
   self.VVMILi()
   self.VVxYBY(True)
 def VVNdWb(self):
  for confItem in self.VVsXWp():
   if confItem.isChanged():
    FFe4rI(self, BF(self.VV1DwU, cbFnc=self.VVKcD2), "Save Changes ?", callBack_No=self.VVAX0m, title=self.Title)
    break
  else:
   self.VVKcD2()
 def VVKcD2(self):
   if self.settingShown: self.VVRJPv()
   else    : self.close("subtExit")
 def VVvPMu(self):
  if self.settingShown: self.VVcno5()
  else    : self.VVo7Rs()
 def VVBeVJ(self): self.VVhwQ9(-1)
 def VVk9Xp(self): self.VVhwQ9(1)
 def VVhwQ9(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVAdHk()
   if pos == -1: ndx = self.VVkHLD(posVal)
   else  : ndx = self.VVBkel(posVal)
   if   ndx < 0      : FFZWPu(self, "Not found" , 500)
   elif ndx == 0      : FFZWPu(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFZWPu(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVE74F(frmSec)
    if allow:
     self.VVO5S2(delay, True)
     self.VVxYBY(force=True)
     CCtonn(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFZWPu(self, "Delay out of range", 800)
 def VVOGH9(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVIQbN(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVwzUh(self) : self.VVXC8R(5)
 def VVGmNX(self) : self.VVXC8R(6)
 def VVMSxS(self) : self.VVXC8R(-1)
 def VVS2uh(self):
  if self.settingShown: self.VVXC8R(1)
  else    : self.VVOGH9(True)
 def VV4dKD(self):
  if self.settingShown: self.VVXC8R(0)
  else    : self.VVOGH9(False)
 def VVXC8R(self, direction):
  if self.settingShown:
   confItem = self.VVsXWp()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVzeaA()
   self.VVMILi()
   self.VVxYBY(True)
 def VVsXWp(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVAX0m(self):
  for confItem in self.VVsXWp(): confItem.cancel()
  self.VVzeaA()
  self.VVMILi()
  self.VVRJPv()
 def VVNEy6(self):
  if self.settingShown:
   FFe4rI(self, self.VVevfx, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVevfx(self):
  for confItem in self.VVsXWp(): confItem.setValue(confItem.default)
  self.VV1DwU()
  self.VVzeaA()
  self.VVMILi()
 def VVO5S2(self, delay, force=False):
  if self.settingShown or force:
   FFoBdB(CFG.subtDelaySec, delay)
   self.VVmvWx()
   self.VVzeaA()
   self.VVMILi()
   if self.settingShown:
    FFZWPu(self, 'Reset to "0"', 800, isGrn=True)
 def VVbksr(self):
  if self.settingShown:
   self.VV1DwU()
   self.VVRJPv()
 def VV1DwU(self, cbFnc=None):
  for confItem in self.VVsXWp(): confItem.save()
  configfile.save()
  self.VVmvWx()
  FFZWPu(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVzeaA(self):
  cfgLst = self.VVsXWp()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVMILi(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FF8ceC(path, fnt, isRepl=1)
  else:
   fnt = VVrHrQ
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFo5AX(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFR9H9(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFRkaP(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFUpYz(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFo5AX(CFG.subtVerticalPos.getValue(), 0, 100, 0, FF7Vv0()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FF02bi(self, winW, winH)
 def VVqYKO(self):
  sp = "    "
  txt  = "%s\n"   % FFbRJw("Subtitle File:", VVmuI1)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFbRJw("Subtitle Settings:", VVmuI1)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVAdHk()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FF8ZP4(frmSec1)
   time2 = FF8ZP4(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFbRJw("Timing:", VVmuI1)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FF8ZP4(durVal)
   txt += sp + "Progress\t: %s\n" % FF8ZP4(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFbRJw("Subtitle end reached.", VVxsyh)
  FFHdWy(self, txt, title="Current Subtitle")
 def VV39WC(self, path="", delay=0, enc=""):
  FFDKj1(self, BF(self.VVdN6y, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVdN6y(self, path="", delay=0, enc=""):
  FFZWPu(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVczac(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVzeaA()
     self.VVqt9v()
   else:
    path, delay, enc = CC88r6.VV1oAZ(self)
    if path:
     self.VV39WC(path=path, delay=delay, enc=enc)
    else:
     self.VVcno5()
  except:
   pass
 def VVqt9v(self):
  posVal, durVal = self.VVAdHk()
  if self.VVoFqP(posVal):
   return
  CC88r6.VVZq6I(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVxYBY)
  except:
   self.timerUpdate.callback.append(self.VVxYBY)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVD2pV)
  except:
   self.timerEndText.callback.append(self.VVD2pV)
  FFZWPu(self, "Subtitle started", 700, isGrn=True)
 def VVoFqP(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CC88r6.VVDnfJ(self)
   FFiHj6(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVcno5(self):
  c1, c2, c3, c4, c5 = "", VVmuI1, VVDopz, VVFaDd, VVxsyh
  VVY9NT = []
  VVY9NT.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVY9NT.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVY9NT.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVY9NT.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVY9NT.append(VVXMhc)
   VVY9NT.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVY9NT.append(VVXMhc)
   VVY9NT.append(("Help (Keys)"        , "help"  ))
  FFaJ04(self, self.VVKlrQ, VVY9NT=VVY9NT, width=700, title='Find Subtitle ".srt" File', VVU4bo="#33221111", VVdq78="#33110011")
 def VVKlrQ(self, item=None):
  if item:
   if   item == "allSrt"   : self.VV9HU1(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VV9HU1(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVPE5N, BF(CCVdBH, patternMode="srt", VVWic9=sDir))
   elif item.startswith("sugSrt") : self.VV9HU1(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFDKj1(self, BF(CCORAx.VV4EMY, self, self.lastSubtFile, self.VV3KDa, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFZWPu(self, "SRT File error", 1000)
   elif item == "disab":
    FFiHj6(CC88r6.VVDnfJ(self))
    self.close("subtExit")
   elif item == "help"    : FFv9kY(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VV3KDa(self, item=None):
  if item:
   FFDKj1(self, BF(self.VV39WC, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVPE5N(self, path):
  if path:
   FFoBdB(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VV39WC(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VV9HU1(self, defSrt="", mode=0, coeff=0.25):
  FFDKj1(self, BF(self.VVGbpu, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVGbpu(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CC88r6.VVXoLd(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFLYXX('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFNjJC(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVCCpA(srtList, coeff)
     if err:
      if self.settingShown: FFcw7s(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVJnaJ = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFd5Wt(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVJnaJ.append((fName, Dir))
   VVNiXY  = ("Select"    , self.VVUrpI     , [])
   VVo9Gm = self.VVuDfM
   VVo8Jh = (""     , self.VVDkt4       , [])
   VVKFgA = (""     , BF(self.VVRem8, defSrt, False) , [])
   VVY2vy = ("Find Current File" , BF(self.VVRem8, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VVgZrM=widths, VVfp7o=28, VVNiXY=VVNiXY, VVo9Gm=VVo9Gm, VVo8Jh=VVo8Jh, VVKFgA=VVKFgA, VVY2vy=VVY2vy, lastFindConfigObj=CFG.lastFindSubtitle
     , VVU4bo="#11002222", VVdq78="#33001111", VVWGqy="#33001111", VVjOuo="#11ffff00", VVpoY2="#11445544", VVUWnf="#22222222", VVwS5R="#11002233")
  elif self.settingShown : FFcw7s(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVuDfM(self, VV5PsO):
  VV5PsO.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVDkt4(self, VV5PsO, title, txt, colList):
  fName, Dir = colList
  FFHdWy(VV5PsO, "%s\n\n%s%s" % (FFbRJw("Path:", VVmuI1), Dir, fName), title=title)
 def VVRem8(self, path, VVyRz1, VV5PsO, title, txt, colList):
  for ndx, row in enumerate(VV5PsO.VVexgG()):
   if path == row[1].strip() + row[0].strip():
    VV5PsO.VVyOnh(ndx)
    break
  else:
   if VVyRz1:
    FFZWPu(VV5PsO, "Not in list !", 1000)
 def VVUrpI(self, VV5PsO, title, txt, colList):
  VV5PsO.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VV39WC(path=path)
 def VVCCpA(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCI7Ct.VV9tjr(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCI7Ct.VVN1y0(evName, "en")[0] or evName
   lst, err = CC88r6.VVZUSx(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVczac(self, path, enc=None):
  if enc and CCORAx.VVttmX(path, enc)      : enc = enc
  elif CCORAx.VVttmX(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFtDuT(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFun41(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVnlUw(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVy2YX(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVmvWx()
  return subtList, ""
 def VVy2YX(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVnlUw(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVmvWx(self):
  path = CC88r6.VVDnfJ(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVxYBY(self, force=False):
  posVal, durVal = self.VVAdHk()
  if self.VVoFqP(posVal):
   return
  curIndex = self.VVOYXZ(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVD2pV()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFR9H9(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVAdHk(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC0rhb.VVEzEe(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCI7Ct.VV9tjr(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVOYXZ(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVkHLD(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVBkel(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVD2pV(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFR9H9(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVDi3O(self):
  FFDKj1(self, self.VVoWM8, title="Loading Lines ...")
 def VVoWM8(self):
  VVJnaJ = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVJnaJ.append((cap, FF8ZP4(frm), str(frm), firstLine))
  if VVJnaJ:
   title = "Select Current Subtitle Line"
   VVzoEZ  = self.VVcCqu
   VVo9Gm = self.VV8dv5
   VVNiXY  = ("Select"   , self.VVogL1 , [title])
   VVY2vy = ("Current Line" , self.VVUtcb , [True])
   VVuKTt = ("Reset Delay" , self.VVAwoZ , [])
   VVNlag = ("New Delay"  , self.VVPTTz   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VV3dzh  = (CENTER , CENTER, CENTER , LEFT    )
   VV5PsO = FFXBR7(self, None, title=title, header=header, VV0wO4=VVJnaJ, VV3dzh=VV3dzh, VVgZrM=widths, VVfp7o=28, VVzoEZ=VVzoEZ, VVo9Gm=VVo9Gm, VVNiXY=VVNiXY, VVY2vy=VVY2vy, VVuKTt=VVuKTt, VVNlag=VVNlag
          , VVU4bo="#33002222", VVdq78="#33001111", VVWGqy="#33110011", VVjOuo="#11ffff00", VVpoY2="#0a334455", VVUWnf="#22222222", VVwS5R="#33002233")
  else:
   FFcw7s(self, "Cannot read lines !", 2000)
 def VVcCqu(self, VV5PsO):
  self.subtLinesTable = VV5PsO
  if CFG.subtDelaySec.getValue():
   VV5PsO["keyYellow"].show()
   VV5PsO["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VV5PsO["keyYellow"].hide()
  VV5PsO["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFRkaP(VV5PsO["keyBlue"], "#22222222")
  VV5PsO.VVwkUY(BF(self.VVBJOE, VV5PsO))
  self.VVUtcb(VV5PsO, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVD4Ax)
  except:
   self.timerSubtLines.callback.append(self.VVD4Ax)
  self.timerSubtLines.start(1000, False)
 def VV8dv5(self, VV5PsO):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VV5PsO.cancel()
 def VVD4Ax(self):
  if self.subtLinesTable:
   VV5PsO = self.subtLinesTable
   posVal, durVal = self.VVAdHk()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVOYXZ(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VV5PsO.VVAxC0(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VV5PsO.VVp8Vc(self.subtLinesTableNdx, row)
     row = VV5PsO.VVAxC0(curIndex)
     row[0] = color + row[0]
     VV5PsO.VVp8Vc(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVogL1(self, VV5PsO, Title):
  delay, color, allow = self.VVJqXQ(VV5PsO)
  if allow:
   self.VV8dv5(VV5PsO)
   self.VVO5S2(delay, True)
  else:
   FFZWPu(VV5PsO, "Delay out of range", 1500)
 def VVUtcb(self, VV5PsO, VVyRz1, onlyColor=False):
  if VV5PsO:
   posVal, durVal = self.VVAdHk()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVOYXZ(posVal)
    if curIndex > -1:
     VV5PsO.VVyOnh(curIndex)
    else:
     ndx = self.VVkHLD(posVal)
     if ndx > -1:
      VV5PsO.VVyOnh(ndx)
 def VVAwoZ(self, VV5PsO, title, txt, colList):
  if VV5PsO["keyYellow"].getVisible():
   self.VVO5S2(0, True)
   VV5PsO["keyYellow"].hide()
   self.VVUtcb(VV5PsO, False)
 def VVBJOE(self, VV5PsO):
  delay, color, allow = self.VVJqXQ(VV5PsO)
  VV5PsO["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVJqXQ(self, VV5PsO):
  lineTime = float(VV5PsO.VVkll0()[2].strip())
  return self.VVE74F(lineTime)
 def VVE74F(self, lineTime):
  posVal, durVal = self.VVAdHk()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVPWV9
   else     : allow, color = False, VVxsyh
   delay = FFiWjh(val, -600, 600)
  return delay, color, allow
 def VVPTTz(self, VV5PsO, title, txt, colList):
  pass
 @staticmethod
 def VVs8Sf(SELF):
  path, delay, enc = CC88r6.VV1oAZ(SELF)
  return True if path else False
 @staticmethod
 def VV1oAZ(SELF):
  path, delay, enc = CC88r6.VV9ve2(SELF)
  if not path:
   path = CC88r6.VVPOWx(SELF)
  return path, delay, enc
 @staticmethod
 def VV9ve2(SELF):
  srtCfgPath = CC88r6.VVDnfJ(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFun41(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVDnfJ(SELF):
  fPath, fDir, fName = CCVdBH.VV950I(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCI7Ct.VV9tjr(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF02Rs(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVPOWx(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCVdBH.VV950I(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CC88r6.VVXoLd(SELF)
    bLst, err = CC88r6.VVZUSx(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVXoLd(SELF):
  fPath, fDir, fName = CCVdBH.VV950I(SELF)
  if pathExists(fDir):
   files = FFzuBj(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVZUSx(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VV8xrD():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVZq6I(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CC88r6.VV9cTm()
 @staticmethod
 def VV9cTm():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCTKZ9(ScrollLabel):
 def __init__(self, parentSELF, text="", VV8i4a=True):
  ScrollLabel.__init__(self, text)
  self.VV8i4a   = VV8i4a
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVbCq6  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVfp7o    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVaYAY ,
   "green"   : self.VVwLgr ,
   "yellow"  : self.VVo6iV ,
   "blue"   : self.VVzt7l ,
   "up"   : self.VV5z7c   ,
   "down"   : self.VVlyUD  ,
   "left"   : self.VV5z7c   ,
   "right"   : self.VVlyUD  ,
   "last"   : BF(self.VVZrnT, 0) ,
   "0"    : BF(self.VVZrnT, 1) ,
   "next"   : BF(self.VVZrnT, 2) ,
   "pageUp"  : self.VVtBnh   ,
   "chanUp"  : self.VVtBnh   ,
   "pageDown"  : self.VVALlf   ,
   "chanDown"  : self.VVALlf
  }, -1)
 def VVxoM0(self, isResizable=True, VVMebt=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFR9H9(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFRkaP(self.parentSELF["keyRedTop"], "#113A5365")
  FF4AQy(self.parentSELF, True)
  self.isResizable = isResizable
  if VVMebt:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVfp7o  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFRkaP(self, color)
 def VVEFsc(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVbjgU  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVbjgU)
  margin   = int(VVbjgU / 6)
  self.pageHeight = int(self.pageLines * VVbjgU)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVbCq6 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVUxs1()
 def VV5z7c(self):
  if self.VVbCq6 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVlyUD(self):
  if self.VVbCq6 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVtBnh(self):
  self.setPos(0)
 def VVALlf(self):
  self.setPos(self.VVbCq6-self.pageHeight)
 def VVxYTK(self):
  return self.VVbCq6 <= self.pageHeight or self.curPos == self.VVbCq6 - self.pageHeight
 def getText(self):
  return self.message
 def VVUxs1(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVbCq6, 3))
   start = int((100 - vis) * self.curPos / (self.VVbCq6 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVQY0S=VVT5lQ):
  old_VVxYTK = self.VVxYTK()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVbCq6 = self.long_text.calculateSize().height()
   if self.VV8i4a and self.VVbCq6 > self.pageHeight:
    self.scrollbar.show()
    self.VVUxs1()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVbCq6))
    self.VVbCq6 = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVbCq6))
   else:
    self.scrollbar.hide()
   if   VVQY0S == VVyHv2: self.setPos(0)
   elif VVQY0S == VVPiyR : self.VVALlf()
   elif old_VVxYTK    : self.VVALlf()
 def appendText(self, text, VVQY0S=VVPiyR):
  self.setText(self.message + str(text), VVQY0S=VVQY0S)
 def VVo6iV(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVHnnp(size)
 def VVzt7l(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVHnnp(size)
 def VVwLgr(self):
  self.VVHnnp(self.VVfp7o)
 def VVHnnp(self, VVfp7o):
  self.long_text.setFont(gFont(self.fontFamily, VVfp7o))
  self.setText(self.message, VVQY0S=VVT5lQ)
  self.VVDPfH()
 def VVZrnT(self, align):
  self.long_text.setHAlign(align)
 def VVaYAY(self):
  VVY9NT = []
  VVY9NT.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Align Left" , "left" ))
  VVY9NT.append(("Align Center" , "center" ))
  VVY9NT.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVY9NT.append(VVXMhc)
   VVY9NT.append((FFbRJw("Save to File", VVmuI1), "save"))
  VVY9NT.append(VVXMhc)
  VVY9NT.append(("Keys (Shortcuts)", "help"))
  FFaJ04(self.parentSELF, self.VVTi01, VVY9NT=VVY9NT, title="Text Option", width=500)
 def VVTi01(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVZrnT(0)
   elif item == "center" : self.VVZrnT(1)
   elif item == "right" : self.VVZrnT(2)
   elif item == "save"  : self.VVslin()
   elif item == "help"  : FFv9kY(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVslin(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFd5Wt(expPath), self.outputFileToSave, FFDaMH())
   with open(outF, "w") as f:
    f.write(FFUkF8(self.message))
   FFNvXQ(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFh60c(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVDPfH(self, minHeight=0):
  if self.isResizable:
   VVbjgU = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVbjgU * (len(self.message.splitlines()) + 1))
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
