import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, sleep as iSleep
from time      import time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VViRxJ   = "v3.1.0"
VVirSa    = "22-10-2021"
VVW45t  = "AJ File Manager"
VVy1xD   = "AJ Live Log (OSCam/NCam)"
EASY_MODE    = 0
VV5bqY   = 0
VVHiZk   = 0
VVXkvT  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVb5jS  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVCWNQ    = "/media/usb/"
VVdxwL    = "/usr/share/enigma2/picon/"
VVGXYV   = "/etc/enigma2/"
VViooG  = "ajpanel_update_url"
VVQbK6   = "AJPan"
VVKt69    = ""
VViB9W    = "Regular"
VVGWwg      = "-" * 80;
VVK4l8    = (VVGWwg, )
VVajY4    = ""
VVX9mL   = " && echo 'Successful' || echo 'Failed!'"
VVxd0m    = []
VVJly5     = 0
VVwLdB    = ""
VVElr3  = False
VVn7sl  = False
VVyfFI     = 0
VVQXyC    = 1
VV0K2n    = 2
VVhKBL   = 3
VVHmfh    = 4
VVwJIf    = 5
VVnnJQ = 6
VVbrPw = 7
VVTTXm  = 8
VVrDJT   = 9
VVEbX0   = 10
VVSc7g   = 11
VVLk86  = 12
VVXRTM  = 13
VVhFmC    = 14
VV1Uct   = 15
VVRMqr   = 16
VVa7Dy  = 15
VVsweO   = 0
VVJGAZ   = 1
VVafWR   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.PIconsPath     = ConfigDirectory(default=VVdxwL, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVCWNQ, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFlwr0():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVhWD1  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVYqa5 = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVhWD1  : return 0
  elif VVYqa5 : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVYaet = FFlwr0()
VVleFh = VVPZsu = VVao2g = VVix4Z = VVcYGL = VV9G5r = VVHsWS = VVL19M = COLOR_CONS_BRIGHT_YELLOW = VV1Zj2 = VVa59G = VVhsuV = ""
def FFusEX(FFusEXText="", addSep=True):
 if VV5bqY:
  txt = VVGWwg + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFusEXText))
  os.system('echo -e "%s"' % txt)
def FFnC2J(txt, isAppend=True, ignoreErr=False):
 if VV5bqY:
  tm   = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFusEX(err)
  FFusEX("Output Log File : %s" % fileName)
VVxd0m = []
def FFHvL6(win):
 global VVxd0m
 if not win in VVxd0m:
  VVxd0m.append(win)
def FFHFZT(*args):
 global VVxd0m
 for win in VVxd0m:
  try:
   win.close()
  except:
   pass
 VVxd0m = []
def FFufe3():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVrXo2 = FFufe3()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFwg5z()     : return getDescriptor(FFtDWp   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFAaVg()  : return getDescriptor(FFtDWp   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFjNQP()  : return getDescriptor(FFQM36 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVW45t)
def FFea7d() : return getDescriptor(FFxVQ0 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVy1xD)
def FFOmdx()    : return getDescriptor(FFEDQc  , [ PluginDescriptor.WHERE_SESSIONSTART  ] )
def FFNEN0()      : return getDescriptor(FFgdP8  , [ PluginDescriptor.WHERE_MENU    ] )
def Plugins(**kwargs):
 result = [ FFwg5z() , FFNEN0() , FFOmdx() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFAaVg())
  result.append(FFjNQP())
  result.append(FFea7d())
 return result
def FFEDQc(reason, **kwargs):
 if reason == 0:
  FFPkci()
  session = kwargs["session"]
  if session:
   FFWRkO(session)
def FFgdP8(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFtDWp, PLUGIN_NAME, 45)]
 else:
  return []
def FFtDWp(session, **kwargs):
 session.open(Main_Menu)
def FFQM36(session, **kwargs):
 session.open(CCXbmU)
def FFxVQ0(session, **kwargs):
 FFGQV4(session, CCNq1P.VVb5b6)
def FFKQ3v():
 pluginList  = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel  = FFAaVg()
 descrFileMan = FFjNQP()
 descrCamLog  = FFea7d()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel    in pluginList : iPlugins.addPlugin(descrPanel)
   if not descrFileMan  in pluginList : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList : iPlugins.addPlugin(descrCamLog)
  else:
   if descrPanel   in pluginList  : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList  : iPlugins.removePlugin(descrFileMan)
   if descrCamLog  in pluginList  : iPlugins.removePlugin(descrCamLog)
 except:
  pass
VVQVbI = None
def FFPkci():
 try:
  global VVQVbI
  if VVQVbI is None:
   VVQVbI    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FF08V4
  ChannelContextMenu.FFbDxT = FFbDxT
 except:
  pass
def FF08V4(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVQVbI(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFbDxT, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFbDxT, title1, csel, isFind=True))))
def FFbDxT(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFpRQc(refCode)
 except:
  pass
 self.session.open(boundFunction(CCAExk, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFWRkO(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FF4tBL, session, "lok")
 hk.actions['longCancel'] = boundFunction(FF4tBL, session, "lesc")
 hk.actions['longRed']  = boundFunction(FF4tBL, session, "lred")
def FF4tBL(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFYt0A(session, isFromSession=True)
def FFxmEB(SELF, title="", addLabel=False, addScrollLabel=False, VVTikG=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFXHTP()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCePyp(SELF)
 if VVTikG:
  SELF["myMenu"] = MenuList(VVTikG)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VV0W2R        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FF1t9f(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFQw4x, SELF, "0") ,
  "1"    : boundFunction(FFQw4x, SELF, "1") ,
  "2"    : boundFunction(FFQw4x, SELF, "2") ,
  "3"    : boundFunction(FFQw4x, SELF, "3") ,
  "4"    : boundFunction(FFQw4x, SELF, "4") ,
  "5"    : boundFunction(FFQw4x, SELF, "5") ,
  "6"    : boundFunction(FFQw4x, SELF, "6") ,
  "7"    : boundFunction(FFQw4x, SELF, "7") ,
  "8"    : boundFunction(FFQw4x, SELF, "8") ,
  "9"    : boundFunction(FFQw4x, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FF728g, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFQw4x(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVhsuV:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVhsuV + SELF.keyPressed + VVPZsu)
    txt = VVPZsu + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFK43o(SELF, txt)
def FF728g(SELF, tableObj, colNum):
 FFK43o(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVLFfv()
     break
 except:
  pass
def FF49MM(SELF, setMenuAction=True):
 if setMenuAction:
  global VVajY4
  VVajY4 = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFXHTP():
 return ("  %s" % VVajY4)
def FFHCfw(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFIQzg(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFzmVi(color):
 return parseColor(color).argb()
def FF5xSe(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFGQmF(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFA2A6(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFXkoO(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVhsuV)
 else:
  return ""
def FFC4in(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVGWwg, word, VVGWwg, VVhsuV)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVGWwg, word, VVGWwg)
def FFNe7q(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVhsuV
def FFtgPs(color):
 if color: return "echo -e '%s' %s;" % (VVGWwg, FFXkoO(VVGWwg, VVL19M))
 else : return "echo -e '%s';" % VVGWwg
def FFQpa3(title, color):
 title = "%s\n%s\n%s\n" % (VVGWwg, title, VVGWwg)
 return FFNe7q(title, color)
def FFWhRj(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFSQc5(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFk91F(callBackFunction):
 tCons = CCtZBs()
 tCons.ePopen("echo", boundFunction(FFXCdd, callBackFunction))
def FFXCdd(callBackFunction, result, retval):
 callBackFunction()
def FFapsE(SELF, fnc, title="Processing ...", clearMsg=True):
 FFK43o(SELF, title)
 tCons = CCtZBs()
 tCons.ePopen("echo", boundFunction(FFqJwH, SELF, fnc, clearMsg))
def FFqJwH(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFK43o(SELF)
def FFoQiW(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFwzkK(cmd):
 txt = FFoQiW(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFVfkZ(cmd):
 lines = FFwzkK(cmd)
 if lines: return lines[0]
 else : return ""
def FFVk5g(SELF, cmd):
 lines = FFwzkK(cmd)
 VVOZgd = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVOZgd.append((key, val))
  elif line:
   VVOZgd.append((line, ""))
 if VVOZgd:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFw32s(SELF, None, header=header, VV26yB=VVOZgd, VVX78s=widths, VV3p9i=22)
 else:
  FFOfw9(SELF, cmd)
def FFOfw9(    SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, VVNbOh=True, VVLxmM=VVJGAZ, **kwargs)
def FFoqGf(  SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, **kwargs)
def FF0iLg(   SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, VVtAKF=True, VVaApu=True, VVLxmM=VVJGAZ, **kwargs)
def FFW0Tm(  SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, VVtAKF=True, VVaApu=True, VVLxmM=VVafWR, **kwargs)
def FFH6Oq(  SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, VVrzXH=True , **kwargs)
def FF156a( SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, VVzoe2=True   , **kwargs)
def FFbCeq( SELF, cmd, **kwargs): SELF.session.open(CCE2bf, VVzSps=cmd, VVvHfg=True  , **kwargs)
def FFOaw3(cmd):
 return cmd + " > /dev/null 2>&1"
def FF2m4A():
 return " > /dev/null 2>&1"
def FFZA91(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFBQjd(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFOVMy():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFVfkZ(cmd)
VVQIHG     = 0
VVSNpE      = 1
VVabbE   = 2
VVg4aK      = 3
VVdmfG      = 4
VVmp1e     = 5
VVgO7i     = 6
VVyAfl  = 7
VV1VTr = 8
VVvJGF  = 9
VVE0pE     = 10
VV4TK6  = 11
VVE1tM  = 12
def FFLJQQ(parmNum, grepTxt):
 if   parmNum == VVQIHG  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVSNpE   : param = ["list"   , "apt list" ]
 elif parmNum == VVabbE: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFOVMy()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFl4YE(parmNum, package):
 if   parmNum == VVg4aK      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVdmfG      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VVmp1e     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVgO7i     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVyAfl  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VV1VTr : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVvJGF  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVE0pE     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VV4TK6  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVE1tM  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFOVMy()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFx0RW():
 result = FFVfkZ("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFl4YE(VVgO7i , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFOaw3("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFOaw3("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFXkoO(failed1, VVL19M))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFXkoO(failed2, VVL19M))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFXkoO(failed3, VVao2g))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFvwoj(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFl4YE(VVgO7i , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFOaw3("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFXkoO(failed1, VVL19M))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFXkoO(failed2, VVao2g))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFhnij(timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect(("1.1.1.1", 53))
  return True
 except:
  return os.system(FFOaw3("wget -q -T %d --spider 1.1.1.1" % timeout)) == 0
def FFjNcO(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFVFca(path, keepends=False, maxSize=-1):
 lines = FFjNcO(path, maxSize)
 return lines.splitlines(keepends)
def FF9reT(SELF, path):
 title = FFXHTP()
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFVFca(path, maxSize=maxSize)
  if lines: FFxYUM(SELF, lines, title=title, VVLxmM=VVJGAZ)
  else : FFYdcr(SELF, path, title=title)
 else:
  FFhkqx(SELF, path, title)
def FF0qcI(SELF, path, title):
 if fileExists(path):
  txt = FFjNcO(path)
  txt = txt.replace("#W#", VVhsuV)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVPZsu)
  txt = txt.replace("#C#", VV1Zj2)
  txt = txt.replace("#P#", VVix4Z)
  FFxYUM(SELF, txt, title=title)
 else:
  FFhkqx(SELF, path, title)
def FFhl50(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFpEn3(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFLTn7(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFgLfR(parent)
 else    : return FFgg7n(parent)
def FFVDP7(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFgLfR(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFgg7n(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFtedn():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVXkvT)
 paths.append(VVXkvT.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFpEn3(ba)
 for p in list:
  p = ba + p + VVXkvT
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVQbK6, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVXkvT, VVQbK6 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVY7i7, VVuSNJ = FFtedn()
def FFoKMu():
 def VV2PIa(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVgEeO  = VV2PIa(CFG.backupPath, CCVRQj.VV4ZnL())
 VVwtNY  = VV2PIa(CFG.downloadedPackagesPath, t)
 VVn42y = VV2PIa(CFG.exportedTablesPath, t)
 VVNK1z = VV2PIa(CFG.exportedPIconsPath, t)
 VVOzhO  = VV2PIa(CFG.packageOutputPath, t)
 global VVCWNQ
 VVCWNQ = FFgLfR(CFG.backupPath.getValue())
 if VVgEeO or VVOzhO or VVwtNY or VVn42y or VVNK1z:
  configfile.save()
 return VVgEeO, VVOzhO, VVwtNY, VVn42y, VVNK1z
def FFxCl6(path):
 path = FFgg7n(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFVzN6(SELF, pathList, tarFileName, addTimeStamp=True):
 VV26yB = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV26yB.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV26yB.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV26yB.append(path)
 if not VV26yB:
  FF3mKe(SELF, "Files not found!")
 elif not pathExists(VVCWNQ):
  FF3mKe(SELF, "Path not found!\n\n%s" % VVCWNQ)
 else:
  VV6h9V = FFgLfR(VVCWNQ)
  tarFileName = "%s%s" % (VV6h9V, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFJ142())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV26yB:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVGWwg
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFXkoO(tarFileName, VVHsWS))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFXkoO(failed, VVHsWS))
  cmd += "fi;"
  cmd +=  sep
  FFoqGf(SELF, cmd)
def FFqol5(SELF, title, VVZrCB):
 SELF.session.open(boundFunction(CCDWEy, Title=title, VVZrCB=VVZrCB))
def FFjIiX(labelObj, VVZrCB):
 if VVZrCB and fileExists(VVZrCB):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVnXHT(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVnXHT)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVZrCB)
   return True
  except:
   pass
 return False
def FFCltT(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFZIIQ(satNum)
  return satName
def FFZIIQ(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFALDD(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFCltT(val)
  else  : sat = FFZIIQ(val)
 return sat
def FF0G5Z(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFCltT(num)
 except:
  pass
 return sat
def FFp151(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF3CkY(SELF, isFromSession=None):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFc4jf(info, iServiceInformation.sServiceref)
   prov = FFc4jf(info, iServiceInformation.sProvider)
   state = str(FFc4jf(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFZjOO(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFXGZ9(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFc4jf(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFrgTu(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFpRQc(refCode):
 info = FFvDYm(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFBWm8(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFNqua(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFvDYm(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVg2N7 = eServiceCenter.getInstance()
  if VVg2N7:
   info = VVg2N7.info(service)
 return info
def FFHTCm(SELF, refCode, VVqXf4=True, checkParentalControl=False):
 if not refCode.endswith(":"):
  refCode += ":"
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  SELF.session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
  if VVqXf4:
   FFYt0A(SELF)
 try:
  VVUF3D = InfoBar.instance
  if VVUF3D:
   VVzpXX = VVUF3D.servicelist
   if VVzpXX:
    servRef = eServiceReference(refCode)
    VVzpXX.saveChannel(servRef)
 except:
  pass
def FFZjOO(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFXGZ9(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFl9uW(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFPDjv(userBfile):
 txt = ""
 bFile = VVGXYV + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVGXYV + userBfile):
  fTxt = FFjNcO(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFVfkZ('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFl9uW(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FF28bV(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFIfm6(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFjf4U(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFJHxZ(txt):
 try:
  return FFIfm6(FFjf4U(txt)) == txt
 except:
  return False
def FFYt0A(SELF, isFromSession=None):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCEwTV)
 else      : FFeqnP(session, reopen=True)
def FFeqnP(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFeqnP, session), CCtjVn)
  except:
   try:
    FF92x4(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFvfLn(refCode):
 tp = CCVmtR()
 if tp.VVTv7n(refCode) : return True
 else        : return False
def FFPEzU(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFWzzi():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFZh4R():
 VVUF3D = InfoBar.instance
 if VVUF3D:
  VVzpXX = VVUF3D.servicelist
  if VVzpXX:
   return VVzpXX.getBouquetList()
 return None
def FFzE8V():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFY8A8():
 path = FFzE8V()
 if path:
  txt = FFjNcO(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FF0qTN(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVg2N7 = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVg2N7.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFPeve():
 VVHm2S = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VV6JRk = list(VVHm2S)
 return VV6JRk, VVHm2S
def FF776W():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFGQV4(session, VVtrzg):
 VVAUlR, VVxTHv, VV4nZn, camCommand = FFlhjv()
 if VVxTHv:
  runLog = False
  if   VVtrzg == CCNq1P.VVFhKz : runLog = True
  elif VVtrzg == CCNq1P.VVzvQS : runLog = True
  elif not VV4nZn          : FF92x4(session, message="SoftCam not started yet!")
  elif fileExists(VV4nZn)        : runLog = True
  else             : FF92x4(session, message="File not found !\n\n%s" % VV4nZn)
  if runLog:
   session.open(boundFunction(CCNq1P, VVAUlR=VVAUlR, VVxTHv=VVxTHv, VV4nZn=VV4nZn, VVtrzg=VVtrzg))
 else:
  FF92x4(session, message="No active OSCam/NCam found !", title="Live Log")
def FFlhjv():
 VVAUlR = "/etc/tuxbox/config/"
 VVxTHv = None
 VV4nZn  = None
 camCommand = FFVfkZ("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVxTHv = "oscam"
 elif "ncam"  in camCommand : VVxTHv = "ncam"
 if VVxTHv:
  path = FFVfkZ(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFgLfR(path)
  if pathExists(path):
   VVAUlR = path
  tFile = VVAUlR + VVxTHv + ".conf"
  tFile = FFVfkZ("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV4nZn = tFile
 return VVAUlR, VVxTHv, VV4nZn, camCommand
def FF2W46(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFr8kC():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFJ142():
 return FFr8kC().replace(" ", "_").replace("-", "").replace(":", "")
def FFwz6F(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFUSMT(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCn3vN.VVM1D4(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCn3vN.VVUE1j(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFOaw3("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFFGcp(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFfeLG(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFOlRy():
 return int(FFoQiW("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFh1lT():
 global VVJly5_TIME, VVwLdB
 VVwLdB  = int(FFOlRy())
 VVJly5_TIME = iTime()
def FF3CqI():
 elapsed = iTime() - VVJly5_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFOlRy() - VVwLdB
 FFusEX(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFX4bs(SELF, message, title=""):
 SELF.session.open(boundFunction(CCVQoF, title=title, message=message, VVcEvx=True))
def FFxYUM(SELF, message, title="", VVLxmM=VVJGAZ, **kwargs):
 SELF.session.open(boundFunction(CCVQoF, title=title, message=message, VVLxmM=VVLxmM, **kwargs))
def FF3mKe(SELF, message, title="")  : FF92x4(SELF.session, message, title)
def FFhkqx(SELF, path, title="") : FF92x4(SELF.session, "File not found !\n\n%s" % path, title)
def FFYdcr(SELF, path, title="") : FF92x4(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFYXW3(SELF, title="")  : FF92x4(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF92x4(session, message, title="") : session.open(boundFunction(CC7mIK, title=title, message=message))
def FFCkFz(SELF, VV6kEn, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VV6kEn, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VV6kEn, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VV6kEn, boundFunction(CCghfF, title=title, message=message, VVD55x=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF3mKe(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFAuNs(SELF, callBack_Yes, VVN4XI, callBack_No=None, title="", VVSmS1=False):
 SELF.session.openWithCallback(boundFunction(FFhkPY, callBack_Yes, callBack_No)
        , boundFunction(CC16dg, title=title, VVN4XI=VVN4XI, VV5OMH=True, VVSmS1=VVSmS1))
def FFhkPY(callBack_Yes, callBack_No, FFAuNsed):
 if FFAuNsed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFK43o(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFVNia(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFJJe1(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
myTimer = eTimer()
def FFVNia(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFcqJ4, SELF))
 try:
  myTimer_conn = myTimer.timeout.connect(boundFunction(FFcqJ4, SELF))
 except:
  myTimer.callback.append(boundFunction(FFcqJ4, SELF))
 myTimer.start(milliSeconds, 1)
def FFcqJ4(SELF):
 myTimer.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFw32s(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCZM1I, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCZM1I, **kwargs))
  FFHvL6(win)
  return win
 except:
  return None
def FFh3ra(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCM32K, **kwargs))
 FFHvL6(win)
 return win
def FFWqlt(SELF, **kwargs):
 SELF.session.open(CCw0CQ, **kwargs)
def FFZ8sT(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFGCsy(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VViB9W, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFtLnH(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFGCsy(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFCHYw():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF0hZe(VV3p9i):
 screenSize  = FFCHYw()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VV3p9i)
 return bodyFontSize
def FFhoJ7(VV3p9i, extraSpace):
 font = gFont(VViB9W, VV3p9i)
 VV6w1K = fontRenderClass.getInstance().getLineHeight(font) or (VV3p9i * 1.25)
 return int(VV6w1K + VV6w1K * extraSpace)
def FFV5Ho(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VViB9W
def FFOSVY(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFCHYw()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVa7Dy)
 bodyFontStr  = 'font="%s;%d"' % (VViB9W, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFhoJ7(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VViB9W, titleFontSize, alignLeftCenter)
 if winType == VVyfFI or winType == VVQXyC:
  if winType == VVQXyC : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVhFmC:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.2)
  b2Left1 = marginLeft
  b2Left2 = b2Left1 + timeW + marginLeft
  b2Left3 = width - marginLeft - timeW
  infW = b2Left3 - b2Left2 - marginLeft
  tmp += '<widget name="myPlayBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="myPlayBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" />'   % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyColor)
  tmp += '<widget name="myPlayBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a005555" />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="myPlayBarM"  position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="myPlayVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="#0a002233" %s %s'   % (bodyFontStr, alignCenter)
  tmp += '<widget name="myPlayPos"  position="%d,%d" size="%d,%d" %s />' % (b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlayMsg"  position="%d,%d" size="%d,%d" %s />' % (b2Left2, b2Top, infW , barH, param)
  tmp += '<widget name="myPlayDur"  position="%d,%d" size="%d,%d" %s />' % (b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep"   position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  names = ["Jmp", "Skp", "Mrk", "Blu", "Inf"]
  b3W  = int((width - marginLeft * 6.0) / 5.0)
  left = marginLeft
  for i in range(5):
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" foregroundColor="#0affffff" backgroundColor="#11222222" %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter)
   left += b3W + marginLeft
 elif winType == VV1Uct:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVHmfh:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV0K2n:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVhKBL:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VViB9W, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VViB9W, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVEbX0:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFX4bsH = int(bodyH * 0.5)
  inpTop = bodyTop + FFX4bsH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFX4bsH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VViB9W, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VViB9W, mapF, alignCenter)
 elif winType == VVSc7g:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVLk86:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VViB9W, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVRMqr:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VViB9W, fontH, alignCenter)
 elif winType == VVXRTM:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VViB9W, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VViB9W, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VViB9W, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 else:
  if   winType == VVbrPw : align = alignLeftCenter
  elif winType == VVnnJQ : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVrDJT:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVwJIf:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVnnJQ:
    fontStr = 'font="%s;%d"' % (FFV5Ho("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VV3p9i = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VViB9W, VV3p9i, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VViB9W, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VViB9W, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VV7My0 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VViB9W, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VV7My0[i], VViB9W, barFont, alignCenter)
   left += btnW + gap
 if winType == VVnnJQ:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VV7My0 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VV7My0[i], VViB9W, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVTikG = []
  if VVHiZk:
   VVTikG.append(("-- MY TEST --"    , "myTest"   ))
  VVTikG.append(("File Manager"      , "FileManager"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Services/Channels"    , "ChannelsTools" ))
  VVTikG.append(("IPTV"        , "IptvTools"  ))
  VVTikG.append(("PIcons"       , "PIconsTools"  ))
  VVTikG.append(("SoftCam"       , "SoftCam"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Plugins"       , "PluginsTools" ))
  VVTikG.append(("Terminal"       , "Terminal"  ))
  VVTikG.append(("Backup & Restore"     , "BackupRestore" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Date/Time"      , "Date_Time"  ))
  VVTikG.append(("Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVTikG)
  FFxmEB(self, VVTikG=VVTikG)
  FFHCfw(self["keyRed"] , "Exit")
  FFHCfw(self["keyGreen"] , "Settings")
  FFHCfw(self["keyYellow"], "Dev. Info.")
  FFHCfw(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVWfyF       ,
   "yellow"  : self.VVWGA6       ,
   "blue"   : self.VVlfcC       ,
   "info"   : self.VVlfcC       ,
   "next"   : self.VV0Hua       ,
   "0"    : boundFunction(self.VV0ZOt, 0) ,
   "1"    : boundFunction(self.VVElZw, 1)   ,
   "2"    : boundFunction(self.VVElZw, 2)   ,
   "3"    : boundFunction(self.VVElZw, 3)   ,
   "4"    : boundFunction(self.VVElZw, 4)   ,
   "5"    : boundFunction(self.VVElZw, 5)   ,
   "6"    : boundFunction(self.VVElZw, 6)   ,
   "7"    : boundFunction(self.VVElZw, 7)   ,
   "8"    : boundFunction(self.VVElZw, 8)   ,
   "9"    : boundFunction(self.VVElZw, 9)
  })
  self.onShown.append(self.VV6NQt)
  self.onClose.append(self.onExit)
  global VVElr3, VVn7sl
  VVElr3 = VVn7sl = False
 def VV0W2R(self):
  item = FF49MM(self)
  self.VVElZw(item)
 def VVElZw(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVYuD5()
   elif item in ("FileManager"  , 1) : self.session.open(CCXbmU)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCdz2s)
   elif item in ("IptvTools"  , 3) : self.session.open(CCn3vN)
   elif item in ("PIconsTools"  , 4) : self.VVcAci()
   elif item in ("SoftCam"   , 5) : self.session.open(CCljEe)
   elif item in ("PluginsTools" , 6) : self.session.open(CCen5J)
   elif item in ("Terminal"  , 7) : self.session.open(CCbDx6)
   elif item in ("BackupRestore" , 8) : self.session.open(CCuxvy)
   elif item in ("Date_Time"  , 9) : self.session.open(CCjNtp)
   elif item in ("CheckInternet" , 10) : self.session.open(CCLehz)
   else         : self.close()
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
  FFZ8sT(self)
  title = "  %s - %s" % (PLUGIN_NAME, VViRxJ)
  self["myTitle"].setText(title)
  VVgEeO, VVOzhO, VVwtNY, VVn42y, VVNK1z = FFoKMu()
  self.VVExlk()
  if VVgEeO or VVOzhO or VVwtNY or VVn42y or VVNK1z:
   VVuxnk = lambda path, subj: "%s:\n%s\n\n" % (subj, FFNe7q(path, VVao2g)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVuxnk(VVgEeO   , "Backup/Restore Path"    )
   txt += VVuxnk(VVOzhO  , "Created Package Files (IPK/DEB)" )
   txt += VVuxnk(VVwtNY  , "Download Packages (from feeds)" )
   txt += VVuxnk(VVn42y , "Exported Tables"     )
   txt += VVuxnk(VVNK1z , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFxYUM(self, txt, title="Settings Paths")
  if (EASY_MODE or VV5bqY or VVHiZk):
   FFGQmF(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFK43o(self, "Welcome", 300)
  FFk91F(boundFunction(self.VVZu4L, title))
 def VVZu4L(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCVRQj.VVZ9Ni()
   if url:
    newWebVer = CCVRQj.VVrGA8(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFOaw3("rm /tmp/ajpanel*"))
 def VV0ZOt(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVElr3
    VVElr3 = True
    FFGQmF(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VV0Hua(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VVn7sl
   VVn7sl = True
   FFGQmF(self["myTitle"], "#dd5588")
 def VVcAci(self):
  found = False
  pPath = CCffqz.VV9UQ6()
  if pathExists(pPath):
   for fName, fType in CCffqz.VVCu9O(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCffqz)
  else:
   VVTikG = []
   VVTikG.append(("PIcons Manager" , "CCffqz" ))
   VVTikG.append(VVK4l8)
   VVTikG.append(CCffqz.VVIoqV())
   VVTikG.append(VVK4l8)
   VVTikG += CCffqz.VViQ1L()
   FFh3ra(self, self.VVWKiL, VVTikG=VVTikG)
 def VVWKiL(self, item=None):
  if item:
   if   item == "CCffqz"   : self.session.open(CCffqz)
   elif item == "VVIv8F"  : CCffqz.VVIv8F(self)
   elif item == "VVj9Ch"  : CCffqz.VVj9Ch(self)
   elif item == "findPiconBrokenSymLinks" : CCffqz.VVLaoE(self, True)
   elif item == "FindAllBrokenSymLinks" : CCffqz.VVLaoE(self, False)
 def VVWfyF(self):
  self.session.open(CCVRQj)
 def VVWGA6(self):
  self.session.open(CCvpBg)
 def VVlfcC(self):
  changeLogFile = VVuSNJ + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFVFca(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFNe7q("\n%s\n%s\n%s" % (VVGWwg, line, VVGWwg), VVix4Z, VVhsuV)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFNe7q(line, VVPZsu, VVhsuV)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFxYUM(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VViRxJ), VV3p9i=26)
 def VVExlk(self):
  p = VVCWNQ + "ajpanel_colors"
  if fileExists(p):
   txt = FFjNcO(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    try:
     if   txt == "main_title_fg" : FF5xSe(self["myTitle"], c)
     elif txt == "main_title_bg" : FFGQmF(self["myTitle"], c)
     elif txt == "main_body_fg" : FF5xSe(self["myMenu"], c)
     elif txt == "main_body_bg" :
      FFGQmF(self["myBody"], c)
      FFGQmF(self["myMenu"], c)
     elif txt == "main_cursor_fg" : self["myMenu"].instance.setForegroundColorSelected(parseColor(c))
     elif txt == "main_cursor_bg" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(c))
     elif txt == "main_bar_bg"  : FFGQmF(self["myBar"], c)
    except:
     pass
 def VVYuD5(self):
  opt = 11
  if   opt ==  0 : FFX4bs(self, "This is My Message.", "Testing")
  elif opt == 11:
   pass
class CCvpBg(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVTikG = []
  VVTikG.append(("Settings File"        , "SettingsFile"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Box Info"          , "VVCEo2"    ))
  VVTikG.append(("Tuners Info"         , "VV9hab"   ))
  VVTikG.append(("Python Version"        , "VVVF76"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Screen Size"         , "ScreenSize"    ))
  VVTikG.append(("Locale"          , "Locale"     ))
  VVTikG.append(("Processor"         , "Processor"    ))
  VVTikG.append(("Operating System"        , "OperatingSystem"   ))
  VVTikG.append(("Drivers"          , "drivers"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("System Users"         , "SystemUsers"    ))
  VVTikG.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVTikG.append(("Uptime"          , "Uptime"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Host Name"         , "HostName"    ))
  VVTikG.append(("MAC Address"         , "MACAddress"    ))
  VVTikG.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVTikG.append(("Network Status"        , "NetworkStatus"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Disk Usage"         , "VV9IdB"    ))
  VVTikG.append(("Mount Points"         , "MountPoints"    ))
  VVTikG.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVTikG.append(("USB Devices"         , "USB_Devices"    ))
  VVTikG.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVTikG.append(("Directory Size"        , "DirectorySize"   ))
  VVTikG.append(("Memory"          , "Memory"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVTikG.append(("Running Processes"       , "RunningProcesses"  ))
  VVTikG.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFxmEB(self, VVTikG=VVTikG, title="Device Information")
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCxcvH)
   elif item == "VVCEo2"    : self.VVCEo2()
   elif item == "VV9hab"   : self.VV9hab()
   elif item == "VVVF76"   : self.VVVF76()
   elif item == "ScreenSize"    : FFxYUM(self, "Width\t: %s\nHeight\t: %s" % (FFCHYw()[0], FFCHYw()[1]))
   elif item == "Locale"     : self.VVObfT()
   elif item == "Processor"    : self.VVVb4m()
   elif item == "OperatingSystem"   : FFOfw9(self, "uname -a"        )
   elif item == "drivers"     : self.VVihiR()
   elif item == "SystemUsers"    : FFOfw9(self, "id"          )
   elif item == "LoggedInUsers"   : FFOfw9(self, "who -a"         )
   elif item == "Uptime"     : FFOfw9(self, "uptime"         )
   elif item == "HostName"     : FFOfw9(self, "hostname"        )
   elif item == "MACAddress"    : self.VVdkEE()
   elif item == "NetworkConfiguration"  : FFOfw9(self, "ifconfig %s %s" % (FFXkoO("HWaddr", VVa59G), FFXkoO("addr:", VVL19M)))
   elif item == "NetworkStatus"   : FFOfw9(self, "netstat -tulpn"       )
   elif item == "VV9IdB"    : self.VV9IdB()
   elif item == "MountPoints"    : FFOfw9(self, "mount %s" % (FFXkoO(" on ", VVL19M)))
   elif item == "FileSystemTable"   : FFOfw9(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFOfw9(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFOfw9(self, "blkid"         )
   elif item == "DirectorySize"   : FFOfw9(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV0k69="Reading size ...")
   elif item == "Memory"     : FFOfw9(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVCSo6()
   elif item == "RunningProcesses"   : FFOfw9(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFOfw9(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVoCgb()
   else         : self.close()
 def VVdkEE(self):
  res = FFoQiW("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFxYUM(self, txt)
  else:
   FFOfw9(self, "ip link")
 def VV21OT(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFwzkK(cmd)
  return lines
 def VVoV5W(self, lines, headerRepl, widths, VVfMBx):
  VVOZgd = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVOZgd.append(parts)
  if VVOZgd and len(header) == len(widths):
   VVOZgd.sort(key=lambda x: x[0].lower())
   FFw32s(self, None, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22, VVZfHP=True)
   return True
  else:
   return False
 def VV9IdB(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VV21OT(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVfMBx = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVoV5W(lines, headerRepl, widths, VVfMBx)
  if not allOK:
   lines = FFwzkK(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFgg7n(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVHsWS:
     note = "\n%s" % FFNe7q("Green = Mounted Partitions", VVHsWS)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVL19M
     elif line.endswith(mountList) : color = VVHsWS
     else       : color = VVPZsu
     txt += FFNe7q(line, color) + "\n"
    FFxYUM(self, txt + note)
   else:
    FF3mKe(self, "Not data from system !")
 def VVCSo6(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV21OT(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVfMBx = (LEFT , CENTER, LEFT )
  allOK = self.VVoV5W(lines, headerRepl, widths, VVfMBx)
  if not allOK:
   FFOfw9(self, cmd)
 def VVObfT(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFxYUM(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVihiR(self):
  cmd = FFLJQQ(VVabbE, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFOfw9(self, cmd)
  else : FFYXW3(self)
 def VVVb4m(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFOfw9(self, cmd)
 def VVoCgb(self):
  cmd = FFLJQQ(VVSNpE, "| grep secondstage")
  if cmd : FFOfw9(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFYXW3(self)
 def VVCEo2(self):
  c = VVHsWS
  VV26yB = []
  VV26yB.append((FFNe7q("Box Type"  , c), FFNe7q(self.VVGrsA("boxtype").upper(), c)))
  VV26yB.append((FFNe7q("Board Version", c), FFNe7q(self.VVGrsA("board_revision") , c)))
  VV26yB.append((FFNe7q("Chipset"  , c), FFNe7q(self.VVGrsA("chipset")  , c)))
  VV26yB.append((FFNe7q("S/N"   , c), FFNe7q(self.VVGrsA("sn")    , c)))
  VV26yB.append((FFNe7q("Version"  , c), FFNe7q(self.VVGrsA("version")  , c)))
  VVGGx3   = []
  VV51VZ = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV51VZ = SystemInfo[key]
     else:
      VVGGx3.append((FFNe7q(str(key), VV1Zj2), FFNe7q(str(SystemInfo[key]), VV1Zj2)))
  except:
   pass
  if VV51VZ:
   VV7dmk = self.VVpJFl(VV51VZ)
   if VV7dmk:
    VV7dmk.sort(key=lambda x: x[0].lower())
    VV26yB += VV7dmk
  if VVGGx3:
   VVGGx3.sort(key=lambda x: x[0].lower())
   VV26yB += VVGGx3
  if VV26yB:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFw32s(self, None, header=header, VV26yB=VV26yB, VVX78s=widths, VV3p9i=22, VVZfHP=True)
  else:
   FFxYUM(self, "Could not read info!")
 def VVGrsA(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFVFca(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVpJFl(self, mbDict):
  try:
   mbList = list(mbDict)
   VV26yB = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV26yB.append((FFNe7q(subject, VVL19M), FFNe7q(value, VVL19M)))
  except:
   pass
  return VV26yB
 def VV9hab(self):
  txt = self.VVrdOc("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVrdOc("/proc/bus/nim_sockets")
  if not txt: txt = self.VVjltC()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFxYUM(self, txt)
 def VVjltC(self):
  txt = ""
  VVuxnk = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVuxnk("Slot Name" , slot.getSlotName())
     txt += FFNe7q(slotName, VVL19M)
     txt += VVuxnk("Description"  , slot.getFullDescription())
     txt += VVuxnk("Frontend ID"  , slot.frontend_id)
     txt += VVuxnk("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVrdOc(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFVFca(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFNe7q(line, VVL19M)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVVF76(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFxYUM(self, txt)
class CCxcvH(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVTikG = []
  VVTikG.append(("Settings (All)"   , "Settings_All"   ))
  VVTikG.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVTikG.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVTikG.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVTikG.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVTikG.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVTikG.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVTikG.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFxmEB(self, VVTikG=VVTikG)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFOfw9(self, cmd                )
   elif item == "Settings_HotKeys"   : FFOfw9(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFOfw9(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFOfw9(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFOfw9(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFOfw9(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFOfw9(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFOfw9(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCljEe(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVAUlR, VVxTHv, VV4nZn, camCommand = FFlhjv()
  self.VVxTHv = VVxTHv
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVTikG = []
  VVTikG.append(("OSCam Files"        , "OSCamFiles"  ))
  VVTikG.append(("NCam Files"        , "NCamFiles"  ))
  VVTikG.append(("CCcam Files"        , "CCcamFiles"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVTikG.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVTikG.append(VVK4l8)
  if VVxTHv:
   if   "oscam" in VVxTHv : camName = "OSCam"
   elif "ncam"  in VVxTHv : camName = "NCam"
   VVTikG.append((camName + " Info."      , "camInfo"   ))
   VVTikG.append((camName + " Live Status"    , "camLiveStatus" ))
   VVTikG.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVTikG.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVTikG.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFxmEB(self, VVTikG=VVTikG)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCBCBU, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCBCBU, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCBCBU, "cccam"))
   elif item == "OSCamReaders"  : self.VVGyvt("os")
   elif item == "NSCamReaders"  : self.VVGyvt("n")
   elif item == "camInfo"   : FFVk5g(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFGQV4(self.session, CCNq1P.VVFhKz)
   elif item == "camLiveReaders" : FFGQV4(self.session, CCNq1P.VVzvQS)
   elif item == "camLiveLog"  : FFGQV4(self.session, CCNq1P.VVb5b6)
   else       : self.close()
 def VVGyvt(self, camPrefix):
  VVOZgd = self.VVKcbC(camPrefix)
  if VVOZgd:
   VVOZgd.sort(key=lambda x: int(x[0]))
   if self.VVxTHv and self.VVxTHv.startswith(camPrefix):
    VVpp6N = ("Toggle State", self.VVycnj, [camPrefix], "Changing State ...")
   else:
    VVpp6N = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVfMBx  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFw32s(self, None, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22, VVpp6N=VVpp6N, VVRCjQ=True)
 def VVKcbC(self, camPrefix):
  readersFile = self.VVAUlR + camPrefix + "cam.server"
  VVOZgd = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFVFca(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVOZgd.append((str(len(VVOZgd) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVOZgd:
    FF3mKe(self, "No readers found !")
  else:
   FFhkqx(self, readersFile)
  return VVOZgd
 def VVycnj(self, VVTGDg, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVAUlR, camPrefix)
  readerState  = VVTGDg.VV7rv1(1)
  readerLabel  = VVTGDg.VV7rv1(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCljEe.VVDxp7(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVTGDg.VVqfpI()
    FF3mKe(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVOZgd = self.VVKcbC(camPrefix)
   if VVOZgd:
    VVTGDg.VV8OPy(VVOZgd)
 @staticmethod
 def VVDxp7(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFVFca(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF3mKe(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF3mKe(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFhkqx(SELF, confFile)
   return None
  if not iRequest:
   FF3mKe(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF3mKe(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF3mKe(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCBCBU(Screen):
 def __init__(self, VVfWyx, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVAUlR, VVxTHv, VV4nZn, camCommand = FFlhjv()
  if   VVfWyx == "ncam" : self.prefix = "n"
  elif VVfWyx == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVTikG = []
  if self.prefix == "":
   VVTikG.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVTikG.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVTikG.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVTikG.append(("constant.cw"         , "x_constant_cw" ))
   VVTikG.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVTikG.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVTikG.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVTikG.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVTikG.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVTikG.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVTikG.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVTikG.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVTikG.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVTikG.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVTikG.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFxmEB(self, VVTikG=VVTikG)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF9reT(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FF9reT(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FF9reT(self, self.VVAUlR + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FF9reT(self, self.VVAUlR + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVga8C("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVga8C("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVga8C("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVga8C("cam.provid"        )
   elif item == "x_cam_server"  : self.VVga8C("cam.server"        )
   elif item == "x_cam_services" : self.VVga8C("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVga8C("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVga8C("cam.user"        )
   elif item == "x_VVGWwg"   : pass
   elif item == "x_SoftCam_Key" : FF9reT(self, self.VVAUlR + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FF9reT(self, self.VVAUlR + "CCcam.cfg"    )
   elif item == "x_VVGWwg"   : pass
   elif item == "x_cam_log"  : FF9reT(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FF9reT(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FF9reT(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVga8C(self, fileName):
  FF9reT(self, self.VVAUlR + self.prefix + fileName)
class CCNq1P(Screen):
 VVFhKz  = 0
 VVzvQS = 1
 VVb5b6 = 2
 def __init__(self, session, VVAUlR="", VVxTHv="", VV4nZn="", VVtrzg=VVFhKz):
  self.skin, self.skinParam = FFOSVY(VVnnJQ, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV4nZn   = VV4nZn
  self.VVtrzg  = VVtrzg
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVAUlR + VVxTHv + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVxTHv : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVAUlR, self.camPrefix)
  if self.VVtrzg == self.VVFhKz:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVtrzg == self.VVzvQS:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFxmEB(self, self.Title, addScrollLabel=True)
  FFHCfw(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV0Q9i
  self.onShown.append(self.VV6NQt)
  self.onClose.append(self.onExit)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self["myLabel"].VVqvJx(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFZ8sT(self)
  self.VV0Q9i()
 def onExit(self):
  self.timer.stop()
 def VVkpKj(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVcTW8)
  except:
   self.timer.callback.append(self.VVcTW8)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFK43o(self, "Started", 1000)
 def VVivmz(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVcTW8)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFK43o(self, "Stopped", 1000)
 def VV0Q9i(self):
  if self.timerRunning:
   self.VVivmz()
  else:
   self.VVkpKj()
   if self.VVtrzg == self.VVFhKz or self.VVtrzg == self.VVzvQS:
    if self.VVtrzg == self.VVFhKz : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCljEe.VVDxp7(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFk91F(self.VVgS1v)
    else:
     self.close()
   else:
    self.VVPGXo()
 def VVcTW8(self):
  if self.timerRunning:
   if   self.VVtrzg == self.VVFhKz : self.VVWuIY()
   elif self.VVtrzg == self.VVzvQS : self.VVWuIY()
   else            : self.VVPGXo()
 def VVPGXo(self):
  if fileExists(self.VV4nZn):
   fTime = FF2W46(os.path.getmtime(self.VV4nZn))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVqBTN(), VVLxmM=VVafWR)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV4nZn)
 def VVgS1v(self):
  self.VVWuIY()
 def VVWuIY(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFNe7q("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVix4Z))
   self.camWebIfErrorFound = True
   self.VVivmz()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVtrzg == self.VVFhKz : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFNe7q("Error while parsing data elements !\n\nError = %s" % str(e), VVao2g)
   self.camWebIfErrorFound = True
   self.VVivmz()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVYMmv(root)
  self["myLabel"].setText(txt, VVLxmM=VVafWR)
  self["myBar"].setText("Last Update : %s" % FFr8kC())
 def VVYMmv(self, rootElement):
  def VVuxnk(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVtrzg == self.VVFhKz:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFNe7q(status, VVHsWS)
    else          : status = FFNe7q(status, VVao2g)
    txt += VVGWwg + "\n"
    txt += VVuxnk("Name"  , name)
    txt += VVuxnk("Description" , desc)
    txt += VVuxnk("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVuxnk("Protocol" , protocol)
    txt += VVuxnk("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFNe7q("Yes", VVHsWS)
    else    : enabTxt = FFNe7q("No", VVao2g)
    txt += VVGWwg + "\n"
    txt += VVuxnk("Label"  , label)
    txt += VVuxnk("Protocol" , protocol)
    txt += VVuxnk("Enabled" , enabTxt)
  return txt
 def VVqBTN(self):
  wordsDict = self.VVlbya()
  color = [ VVL19M, VVa59G, VVHsWS, VVao2g, VV1Zj2, VVcYGL]
  lines = FFwzkK("tail -n %d %s" % (100, self.VV4nZn))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVix4Z + line[:19] + VVPZsu + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVhsuV + line[ndx + 3:] + VVPZsu
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVL19M + line[ndx + 8 : ndx1 + 4] + VVPZsu + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVPZsu)
   elif line.startswith("----") or ">>" in line:
    line = FFNe7q(line, VVL19M)
   txt += line + "\n"
  return txt
 def VVlbya(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFVFca(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCuxvy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVTikG = []
  VVTikG.append(("Backup Channels"        , "VVXOPM"   ))
  VVTikG.append(("Restore Channels"        , "Restore_Channels"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Backup SoftCAM Files"       , "VVwj35" ))
  VVTikG.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVTikG.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVTikG.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Backup Network Settings"      , "VV53FC"   ))
  VVTikG.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVn7sl:
   VVTikG.append(VVK4l8)
   VVTikG.append((VVix4Z + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VV0BFZ"   ))
   VVTikG.append((VVHsWS + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVTikG.append((VVHsWS + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVTikG.append((VV1Zj2 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVTikG.append((VV1Zj2 + "Decode %s Crash Report"   % PLUGIN_NAME , "VVVn04" ))
  FFxmEB(self, VVTikG=VVTikG)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVXOPM"    : self.VVXOPM()
   elif item == "Restore_Channels"    : self.VVlML0("channels_backup*.tar.gz", self.VVjak7)
   elif item == "VVwj35"   : self.VVwj35()
   elif item == "Restore_SoftCAM_Files"  : self.VVlML0("softcam_backup*.tar.gz", self.VVqlcq)
   elif item == "Backup_TunerDiSEqC"   : self.VVErFN("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVlML0("tuner_backup*.backup", boundFunction(self.VVfOpp, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVErFN("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVlML0("hotkey_fhdg17_backup*.backup", boundFunction(self.VVfOpp, "misc"))
   elif item == "VV53FC"    : self.VV53FC()
   elif item == "Restore_Network"    : self.VVlML0("network_backup*.tar.gz", self.VVwf3v)
   elif item == "VV0BFZ"     : FFAuNs(self, boundFunction(FFapsE, self, boundFunction(CCuxvy.VV0BFZ, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVsy5S(False)
   elif item == "createMyDeb"     : self.VVsy5S(True)
   elif item == "createMyTar"     : self.VVXGNT()
   elif item == "VVVn04"   : self.VVVn04()
 @staticmethod
 def VV0BFZ(SELF):
  OBF_Path = VVY7i7 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVY7i7, VViRxJ, VVirSa)
   if err : FF3mKe(SELF, err)
   else : FFxYUM(SELF, txt)
  else:
   FFhkqx(SELF, OBF_Path)
 def VVsy5S(self, VV6C6C):
  OBF_Path = VVY7i7 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF3mKe(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVY7i7)
  os.system("mv -f %s %s" % (VVY7i7 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVY7i7 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVY7i7 + "plugin.py"))
  self.session.openWithCallback(self.VVsy5S1, boundFunction(CCfmbm, path=VVY7i7, VV6C6C=VV6C6C))
 def VVsy5S1(self):
  os.system("mv -f %s %s" % (VVY7i7 + "OBF/main.py"  , VVY7i7))
  os.system("mv -f %s %s" % (VVY7i7 + "OBF/plugin.py" , VVY7i7))
 def VVVn04(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF3mKe(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF3mKe(self, "No log files in:\n\n%s" % path)
   return
  VV26yB = []
  for f in files:
   f = os.path.basename(f)
   VV26yB.append((f, f))
  FFh3ra(self, boundFunction(self.VVdYG2, path), VVTikG=VV26yB)
 def VVdYG2(self, path, item=None):
  if item:
   codF = ""
   cFiles = iGlob("%s*.list" % path)
   if cFiles:
    codF = cFiles[0]
    if fileExists(codF):
     logF = path + item
     if fileExists(logF):
      lst  = []
      lines = FFVFca(codF)
      for line in lines:
       line = line.split(":")[1]
       parts = line.split("->")
       lst.append((parts[1].strip(), parts[0].strip()))
      if lst:
       logTxt = FFjNcO(logF)
       for item in lst:
        logTxt = logTxt.replace(item[0], item[1])
       resF = logF + ".decoded.log"
       with open(resF, "w") as f:
        f.write(logTxt)
       FFX4bs(self, "Output File:\n\n%s" % resF)
      else: FF3mKe(self, "No codes in : %s" % codF)
     else: FFhkqx(self, logF)
   else: FFhkqx(self, codF)
 def VVXGNT(self):
  VV26yB = []
  VV26yB.append("%s%s" % (VVY7i7, "*.py"))
  VV26yB.append("%s%s" % (VVY7i7, "*.png"))
  VV26yB.append("%s%s" % (VVY7i7, "*.xml"))
  VV26yB.append("%s"  % (VVuSNJ))
  FFVzN6(self, VV26yB, "%s_%s" % (PLUGIN_NAME, VViRxJ), addTimeStamp=False)
 def VVXOPM(self):
  path1 = VVGXYV
  path2 = "/etc/tuxbox/"
  VV26yB = []
  VV26yB.append("%s%s" % (path1, "*.tv"))
  VV26yB.append("%s%s" % (path1, "*.radio"))
  VV26yB.append("%s%s" % (path1, "*list"))
  VV26yB.append("%s%s" % (path1, "lamedb*"))
  VV26yB.append("%s%s" % (path2, "*.xml"))
  FFVzN6(self, VV26yB, "channels_backup", addTimeStamp=True)
 def VVwj35(self):
  VV26yB = []
  VV26yB.append("/etc/tuxbox/config/")
  VV26yB.append("/usr/keys/")
  VV26yB.append("/usr/scam/")
  VV26yB.append("/etc/CCcam.cfg")
  FFVzN6(self, VV26yB, "softcam_backup", addTimeStamp=True)
 def VV53FC(self):
  VV26yB = []
  VV26yB.append("/etc/hostname")
  VV26yB.append("/etc/default_gw")
  VV26yB.append("/etc/resolv.conf")
  VV26yB.append("/etc/wpa_supplicant*.conf")
  VV26yB.append("/etc/network/interfaces")
  VV26yB.append("/etc/enigma2/nameserversdns.conf")
  FFVzN6(self, VV26yB, "network_backup", addTimeStamp=True)
 def VVjak7(self, fileName):
  if fileName:
   FFAuNs(self, boundFunction(self.VVHzDB, fileName), "Overwrite current channels ?")
 def VVHzDB(self, fileName):
  path = "%s%s" % (VVCWNQ, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCdz2s.VVPPCo()
   lamedb5File, diabled5File = CCdz2s.VVr3TB()
   cmd = ""
   cmd += FFOaw3("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFOaw3("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFWzzi()
   if res == 0 : FFX4bs(self, "Channels Restored.")
   else  : FF3mKe(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFhkqx(self, path)
 def VVqlcq(self, fileName):
  if fileName:
   FFAuNs(self, boundFunction(self.VVPMdj, fileName), "Overwrite SoftCAM files ?")
 def VVPMdj(self, fileName):
  fileName = "%s%s" % (VVCWNQ, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVGWwg
   note = "You may need to restart your SoftCAM."
   FFW0Tm(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFXkoO(note, VVL19M), sep))
  else:
   FFhkqx(self, fileName)
 def VVwf3v(self, fileName):
  if fileName:
   FFAuNs(self, boundFunction(self.VVYduZ, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVYduZ(self, fileName):
  fileName = "%s%s" % (VVCWNQ, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFH6Oq(self,  cmd)
  else:
   FFhkqx(self, fileName)
 def VVlML0(self, pattern, callBackFunction, isTuner=False):
  title = FFXHTP()
  if pathExists(VVCWNQ):
   myFiles = iGlob("%s%s" % (VVCWNQ, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV26yB = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV26yB.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVmqZr = ("Sat. List", self.VVSg3K)
    else  : VVmqZr = None
    FFh3ra(self, callBackFunction, title=title, VVTikG=VV26yB, VVmqZr=VVmqZr)
   else:
    FF3mKe(self, "No files found in:\n\n%s" % VVCWNQ, title)
  else:
   FF3mKe(self, "Path not found:\n\n%s" % VVCWNQ, title)
 def VVErFN(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCtZBs()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVwIxu, filePrefix))
 def VVwIxu(self, filePrefix, result, retval):
  title = FFXHTP()
  if pathExists(VVCWNQ):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF3mKe(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVCWNQ, filePrefix, FFJ142())
    try:
     VV26yB = str(result.strip()).split()
     if VV26yB:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV26yB:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVGWwg, FFNe7q(fName, VVL19M), VVGWwg)
       FFxYUM(self, txt, title=title, VVLxmM=VVafWR)
      else:
       FF3mKe(self, "File creation failed!", title)
     else:
      FF3mKe(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFOaw3("rm %s" % fName))
     FF3mKe(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFOaw3("rm %s" % fName))
     FF3mKe(self, "Error while writing file.")
  else:
   FF3mKe(self, "Path not found:\n\n%s" % VVCWNQ, title)
 def VVfOpp(self, mode, path):
  if path:
   path = "%s%s" % (VVCWNQ, path)
   if fileExists(path):
    lines = FFVFca(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFAuNs(self, boundFunction(self.VV0nSx, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFYdcr(self, path, title=FFXHTP())
   else:
    FFhkqx(self, path)
 def VV0nSx(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVzSps = []
  VVzSps.append("echo -e 'Reading current settings ...'")
  VVzSps.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVzSps.append("echo -e 'Preparing new settings ...'")
  VVzSps.append(settingsLines)
  VVzSps.append("echo -e 'Applying new settings ...'")
  VVzSps.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFbCeq(self, VVzSps)
 def VVSg3K(self, VVEOjrObj, path):
  if not path:
   return
  path = VVCWNQ + path
  if not fileExists(path):
   FFhkqx(self, path)
   return
  txt = FFjNcO(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV26yB  = []
   for item in satList:
    VV26yB.append("%s\t%s" % (item[0], FFCltT(item[1])))
   FFxYUM(self, VV26yB, title="  Satellites List")
  else:
   FF3mKe(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCen5J(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVTikG = []
  VVTikG.append(("Plugins Browser List"       , "VVsBaV"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVTikG.append(("Remove Packages (show all)"     , "VVxNrFsAll"   ))
  VVTikG.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Update List of Available Packages"   , "VVAM0I"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Packaging Tool"        , "VVwTpo"    ))
  VVTikG.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFxmEB(self, VVTikG=VVTikG)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVsBaV"   : self.VVsBaV()
   elif item == "pluginsDirList"    : self.VVaIO2()
   elif item == "downloadInstallPackages"  : FFapsE(self, boundFunction(self.VVaBuL, 0, ""))
   elif item == "VVxNrFsAll"   : FFapsE(self, boundFunction(self.VVaBuL, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFapsE(self, boundFunction(self.VVaBuL, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVAM0I"   : self.VVAM0I()
   elif item == "VVwTpo"    : self.VVwTpo()
   elif item == "packagesFeeds"    : self.VVkldD()
   else          : self.close()
 def VVaIO2(self):
  extDirs  = FFpEn3(VVXkvT)
  sysDirs  = FFpEn3(VVb5jS)
  VV26yB  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV26yB.append((item, VVXkvT + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV26yB.append((item, VVb5jS + item))
  if VV26yB:
   VV26yB = sorted(VV26yB, key=lambda x: x[0].lower())
   VVtuOR = ("Package Info.", self.VV62vh, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFw32s(self, None, header=header, VV26yB=VV26yB, VVX78s=widths, VV3p9i=28, VVtuOR=VVtuOR)
  else:
   FF3mKe(self, "Nothing found!")
 def VV62vh(self, VVTGDg, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVXkvT) : loc = "extensions"
  elif path.startswith(VVb5jS) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVxpDa(package)
  else:
   FF3mKe(self, "No info!")
 def VVkldD(self):
  pkg = FFOVMy()
  if pkg : FFOfw9(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFYXW3(self)
 def VVsBaV(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVuxnk(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVGWwg + "\n"
    txt += VVuxnk("Number"   , str(c))
    txt += VVuxnk("Name"   , FFNe7q(str(p.name), VVL19M))
    txt += VVuxnk("Path"  , p.path  )
    txt += VVuxnk("Description" , p.description )
    txt += VVuxnk("Icon"  , p.iconstr  )
    txt += VVuxnk("Wakeup Fnc" , p.wakeupfnc )
    txt += VVuxnk("NeedsRestart", p.needsRestart)
    txt += VVuxnk("Internal" , p.internal )
    txt += VVuxnk("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFxYUM(self, txt)
 def VVAM0I(self):
  cmd = FFLJQQ(VVQIHG, "")
  if cmd : FFH6Oq(self, cmd, checkNetAccess=True)
  else : FFYXW3(self)
 def VVwTpo(self):
  pkg = FFOVMy()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFX4bs(self, txt)
 def VVaBuL(self, mode, grep, VVTGDg=None, title=""):
  if   mode == 0: cmd = FFLJQQ(VVSNpE    , grep)
  elif mode == 1: cmd = FFLJQQ(VVabbE , grep)
  elif mode == 2: cmd = FFLJQQ(VVabbE , grep)
  if not cmd:
   FFYXW3(self)
   return
  VVOZgd = FFwzkK(cmd)
  if not VVOZgd:
   if VVTGDg: VVTGDg.VVqfpI()
   FF3mKe(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV26yB  = []
  for item in VVOZgd:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV26yB.append((name, package, version))
  if mode > 0:
   extensions = FFwzkK("ls %s -l | grep '^d' | awk '{print $9}'" % VVXkvT)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV26yB:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV26yB.append((name, VVXkvT + item, "-"))
   systemPlugins = FFwzkK("ls %s -l | grep '^d' | awk '{print $9}'" % VVb5jS)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV26yB:
      if item.lower() == row[0].lower():
       break
     else:
      VV26yB.append((item, VVb5jS + item, "-"))
  if not VV26yB:
   FF3mKe(self, "No packages found!")
   return
  if VVTGDg:
   VV26yB.sort(key=lambda x: x[0].lower())
   VVTGDg.VV8OPy(VV26yB, title)
  else:
   widths = (20, 50, 30)
   VVpp6N = None
   VVwxMC = None
   if mode == 0:
    VVgrOj = ("Install" , self.VVueGM   , [])
    VVpp6N = ("Download" , self.VVLLYZ   , [])
    VVwxMC = ("Filter"  , self.VVzAlN , [])
   elif mode == 1:
    VVgrOj = ("Uninstall", self.VVxNrF, [])
   elif mode == 2:
    VVgrOj = ("Uninstall", self.VVxNrF, [])
    widths= (18, 57, 25)
   VV26yB = sorted(VV26yB, key=lambda x: x[0].lower())
   VVtuOR = ("Package Info.", self.VV1Wx7, [])
   header   = ("Name" ,"Package" , "Version" )
   FFw32s(self, None, header=header, VV26yB=VV26yB, VVX78s=widths, VV3p9i=24, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVwxMC=VVwxMC, VV2PiX=self.lastSelectedRow
     , VVICrB="#22110011", VVMl7F="#22191111", VV7My0="#22191111", VV0ai5="#00003030", VVovon="#00333333")
 def VV1Wx7(self, VVTGDg, title, txt, colList):
  package = colList[1]
  self.VVxpDa(package)
 def VVzAlN(self, VVTGDg, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVTikG = []
  VVTikG.append(("All Packages", "all"))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVTikG.append(VVK4l8)
  for word in words:
   VVTikG.append((word, word))
  FFh3ra(self, boundFunction(self.VVQBaX, VVTGDg), VVTikG=VVTikG, title="Select Filter")
 def VVQBaX(self, VVTGDg, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFapsE(VVTGDg, boundFunction(self.VVaBuL, 0, grep, VVTGDg, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVxNrF(self, VVTGDg, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVXkvT, VVb5jS)):
   FFAuNs(self, boundFunction(self.VVOMEj, VVTGDg, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVTikG = []
   VVTikG.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVTikG.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVTikG.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFh3ra(self, boundFunction(self.VVP8Jm, VVTGDg, package), VVTikG=VVTikG)
 def VVOMEj(self, VVTGDg, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVX9mL)
  FFH6Oq(self, cmd, VV3dyz=boundFunction(self.VV01qb, VVTGDg))
 def VVP8Jm(self, VVTGDg, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVE0pE
   elif item == "remove_ForceRemove"  : cmdOpt = VV4TK6
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVE1tM
   FFAuNs(self, boundFunction(self.VVtgh2, VVTGDg, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVtgh2(self, VVTGDg, package, cmdOpt):
  self.lastSelectedRow = VVTGDg.VVu2q3()
  cmd = FFl4YE(cmdOpt, package)
  if cmd : FFH6Oq(self, cmd, VV3dyz=boundFunction(self.VV01qb, VVTGDg))
  else : FFYXW3(self)
 def VV01qb(self, VVTGDg):
  VVTGDg.cancel()
  FF776W()
 def VVueGM(self, VVTGDg, title, txt, colList):
  package  = colList[1]
  VVTikG = []
  VVTikG.append(("Install Package"         , "install_CheckVersion" ))
  VVTikG.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVTikG.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVTikG.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFh3ra(self, boundFunction(self.VVM0S3, package), VVTikG=VVTikG)
 def VVM0S3(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVgO7i
   elif item == "install_ForceReinstall" : cmdOpt = VVyAfl
   elif item == "install_ForceDowngrade" : cmdOpt = VV1VTr
   elif item == "install_IgnoreDepends" : cmdOpt = VVvJGF
   FFAuNs(self, boundFunction(self.VVDJd1, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVDJd1(self, package, cmdOpt):
  cmd = FFl4YE(cmdOpt, package)
  if cmd : FFH6Oq(self, cmd, VV3dyz=FF776W, checkNetAccess=True, enableSaveRes=True)
  else : FFYXW3(self)
 def VVLLYZ(self, VVTGDg, title, txt, colList):
  package  = colList[1]
  FFAuNs(self, boundFunction(self.VV7IH0, package), "Download Package ?\n\n%s" % package)
 def VV7IH0(self, package):
  if FFhnij():
   cmd = FFl4YE(VVmp1e, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFXkoO(success, VVHsWS))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFXkoO(fail, VVao2g))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFH6Oq(self, cmd, VVCdBh=[VVao2g, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFYXW3(self)
  else:
   FF3mKe(self, "No internet connection !")
 def VVxpDa(self, package):
  infoCmd  = FFl4YE(VVg4aK, package)
  filesCmd = FFl4YE(VVdmfG, package)
  listInstCmd = FFLJQQ(VVabbE, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFtgPs(VVL19M)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFXkoO(notInst, VVix4Z))
   cmd += "else "
   cmd +=   FFC4in("System Info", VVL19M)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFC4in("Related Files", VVL19M)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF0iLg(self, cmd)
  else:
   FFYXW3(self)
class CCdz2s(Screen):
 VVSeLC  = 0
 VVR8Yd = 1
 VVCMqz  = 2
 VVli6I  = 3
 VVHbv4 = 4
 VV2Z8v = 5
 VVYZ7T = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVT9XC = None
  self.lastfilterUsed  = None
  VVTikG = self.VVVrHo()
  FFxmEB(self, VVTikG=VVTikG, title="Services/Channels")
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self["myMenu"].setList(self.VVVrHo())
  FFWhRj(self["myMenu"])
  FFtLnH(self)
 def VVVrHo(self):
  VVTikG = []
  VVTikG.append(("Current Service (Signal Monitor)"   , "currentServiceSignal"    ))
  VVTikG.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVTikG.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVTikG.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVTikG.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVTikG.append(("Services with PIcons for the System"  , "VVCzrq"     ))
  VVTikG.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVTikG.append(VVK4l8)
  lamedbFile, disabledFile = CCdz2s.VVPPCo()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVTikG.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVTikG.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVTikG.append(("Reset Parental Control Settings"   , "VVjdzw"    ))
  VVTikG.append(("Delete Channels with no names"   , "VVZe26"    ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Reload Channels and Bouquets"    , "VVsBUg"      ))
  return VVTikG
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFYt0A(self)
   elif item == "currentServiceInfo"     : FFWqlt(self, fncMode=CCw0CQ.VVYtHE)
   elif item == "TranspondersStats"     : FFapsE(self, self.VV5Q94     )
   elif item == "lameDB_allChannels_with_refCode"  : FFapsE(self, self.VVa5r2 )
   elif item == "lameDB_allChannels_with_tranaponder" : FFapsE(self, self.VV3Sy9)
   elif item == "lameDB_allChannels_with_details"  : FFapsE(self, self.VV7L2a )
   elif item == "parentalControlChannels"    : FFapsE(self, self.VVgUEy   )
   elif item == "showHiddenChannels"     : FFapsE(self, self.VVWHNj     )
   elif item == "VVCzrq"     : FFapsE(self, self.VVRuzT     )
   elif item == "servicesWithMissingPIcons"   : FFapsE(self, self.VV7jC6   )
   elif item == "enableHiddenChannels"     : self.VVtlLb(True)
   elif item == "disableHiddenChannels"    : self.VVtlLb(False)
   elif item == "VVjdzw"    : FFAuNs(self, self.VVjdzw, "Reset and Restart ?" )
   elif item == "VVZe26"    : FFapsE(self, self.VVZe26)
   elif item == "VVsBUg"      : FFapsE(self, boundFunction(CCdz2s.VVsBUg, self))
   else            : self.close()
 @staticmethod
 def VVsBUg(SELF):
  FFWzzi()
  FFX4bs(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVa5r2(self):
  self.VVT9XC = None
  self.lastfilterUsed  = None
  self.filterObj   = CC1HZL(self)
  VVOZgd = CCdz2s.VVc6H0(self, self.VVSeLC)
  if VVOZgd:
   VVOZgd.sort(key=lambda x: x[0].lower())
   VVXJOe  = ("Zap"   , self.VVQGUK     , [])
   VVcsOf = (""    , self.VVstfL   , [])
   VVtuOR = ("Options"  , self.VVfW8G , [])
   VVpp6N = ("Current Service", self.VVP2kh , [])
   VVwxMC = ("Filter"   , self.VVxNx0  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVfMBx  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFw32s(self, None, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVwxMC=VVwxMC)
 def VV3Sy9(self):
  self.VVT9XC = None
  self.lastfilterUsed  = None
  self.filterObj   = CC1HZL(self)
  VVOZgd = CCdz2s.VVc6H0(self, self.VVR8Yd)
  if VVOZgd:
   VVOZgd.sort(key=lambda x: x[0].lower())
   VVXJOe  = ("Zap"   , self.VVQGUK      , [])
   VVcsOf = (""    , self.VVstfL    , [])
   VVpp6N = ("Current Service", self.VVP2kh  , [])
   VVtuOR = ("Options"  , self.VV897U , [])
   VVwxMC = ("Filter"   , self.VVOF9y  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVfMBx  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFw32s(self, None, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVwxMC=VVwxMC)
 def VVfW8G(self, VVTGDg, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CC8ndA(self, VVTGDg, 3)
  mSel.VVaQlH(servName, refCode, pcState, hidState)
 def VV897U(self, VVTGDg, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CC8ndA(self, VVTGDg, 3)
  mSel.VVMS4z(servName, refCode)
 def VVZF7q(self, VVTGDg, refCode, isAddToBlackList):
  self.VVT9XC = None
  self.lastfilterUsed  = None
  VVTGDg.VVWdWk("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFapsE(self, boundFunction(self.VVTzUd, VVTGDg, refCode))
  else:
   FFhkqx(self, path)
 def VVKiQr(self, VVTGDg, refCode, isHide):
  self.VVT9XC = None
  self.lastfilterUsed  = None
  VVTGDg.VVWdWk("Changing state ...")
  if FFvfLn(refCode):
   ret = FFPEzU(refCode, isHide)
   if ret : FFapsE(self, boundFunction(self.VVTzUd, VVTGDg, refCode))
   else : FF3mKe(self, "Cannot Hide/Unhide this channel.")
  else:
   FF3mKe(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVTzUd(self, VVTGDg, refCode):
  VVOZgd = CCdz2s.VVc6H0(self, self.VVSeLC, VVSSBT=[3, [refCode], False])
  done = False
  if VVOZgd:
   data = VVOZgd[0]
   if data[3] == refCode:
    done = VVTGDg.VViRsV(data)
  if not done:
   self.VVLKjo(VVTGDg, VVTGDg.VVEebE(), self.VVSeLC)
  VVTGDg.VVqfpI()
 def VVxNx0(self, VVTGDg, title, txt, colList):
  self.filterObj.VV5npx(1, VVTGDg, 2, boundFunction(self.VVYys1, VVTGDg))
 def VVYys1(self, VVTGDg, item):
  self.VVSPgB(VVTGDg, item, 2, self.VVSeLC)
 def VVOF9y(self, VVTGDg, title, txt, colList):
  self.filterObj.VV5npx(2, VVTGDg, 4, boundFunction(self.VVrqvg, VVTGDg))
 def VVrqvg(self, VVTGDg, item):
  self.VVSPgB(VVTGDg, item, 4, self.VVR8Yd)
 def VV8Oot(self, VVTGDg, title, txt, colList):
  self.filterObj.VV5npx(0, VVTGDg, 4, boundFunction(self.VVPjTJ, VVTGDg))
 def VVPjTJ(self, VVTGDg, item):
  self.VVSPgB(VVTGDg, item, 4, self.VVCMqz)
 def VVSPgB(self, VVTGDg, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVTGDg.VV7rv1(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVT9XC = None
  else:
   words, asPrefix = CC1HZL.VVxEg1(words)
   self.VVT9XC = [col, words, asPrefix]
  if not words:
   FFK43o(VVTGDg, "Incorrect filter", 2000)
  else:
   VVTGDg.VVWdWk("Reading Services ...")
   FFapsE(self, boundFunction(self.VVLKjo, VVTGDg, title, mode))
 def VVLKjo(self, VVTGDg, title, mode):
  VVOZgd = CCdz2s.VVc6H0(self, mode, VVSSBT=self.VVT9XC, VVpQw7=False)
  if VVOZgd:
   VVOZgd.sort(key=lambda x: x[0].lower())
   VVTGDg.VV8OPy(VVOZgd, title)
  else:
   VVTGDg.VVqfpI()
   FFK43o(VVTGDg, "Not found!", 1500)
 def VVCYpV(self, VV26yB, VVXJOe=None, VVcsOf=None, VVgrOj=None, VVpp6N=None, VVtuOR=None, VVwxMC=None):
  VVpp6N = ("Current Service", self.VVP2kh, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVfMBx = (LEFT  , LEFT  , CENTER, LEFT    )
  FFw32s(self, None, header=header, VV26yB=VV26yB, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=24, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVwxMC=VVwxMC)
 def VVP2kh(self, VVTGDg, title, txt, colList):
  self.VVsc7Q(VVTGDg)
 def VV6o1M(self, VVTGDg, title, txt, colList):
  self.VVsc7Q(VVTGDg, True)
 def VVsc7Q(self, VVTGDg, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVTGDg.VV4w3d(colDict, VVU7ut=True)
   else:
    VVTGDg.VVf6dd(3, refCode, True)
   return
  FF3mKe(self, "Colud not read current Reference Code !")
 def VV7L2a(self):
  self.VVT9XC = None
  self.lastfilterUsed  = None
  self.filterObj   = CC1HZL(self)
  VVOZgd = CCdz2s.VVc6H0(self, self.VVCMqz)
  if VVOZgd:
   VVOZgd.sort(key=lambda x: x[0].lower())
   VVcsOf = (""    , self.VVcPOf , []      )
   VVpp6N = ("Current Service", self.VV6o1M  , []      )
   VVwxMC = ("Filter"   , self.VV8Oot   , [], "Loading Filters ..." )
   VVXJOe  = ("Zap"   , self.VVnDfk      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVfMBx  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFw32s(self, None, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=24, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVpp6N=VVpp6N, VVwxMC=VVwxMC)
 def VVcPOf(self, VVTGDg, title, txt, colList):
  refCode  = self.VV85kW(colList)
  chName  = colList[0]
  txt   += "Reference\t: %s" % refCode
  FFWqlt(self, fncMode=CCw0CQ.VVyjm7, refCode=refCode, chName=chName, text=txt)
 def VVnDfk(self, VVTGDg, title, txt, colList):
  refCode = self.VV85kW(colList)
  FFHTCm(self, refCode)
 def VVQGUK(self, VVTGDg, title, txt, colList):
  FFHTCm(self, colList[3])
 def VV85kW(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVc6H0(SELF, mode, VVSSBT=None, VVpQw7=True, VVF6KR=True):
  lamedbFile, disabledFile = CCdz2s.VVPPCo()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVSSBT:
    filterCol = VVSSBT[0]
    filterWords = VVSSBT[1]
    asPrefix = VVSSBT[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCdz2s.VVSeLC:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFVFca(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCdz2s.VVR8Yd:
    tp = CCVmtR()
   VV6JRk, VVHm2S = FFPeve()
   tagFound  = False
   if mode in (CCdz2s.VV2Z8v, CCdz2s.VVYZ7T):
    VVOZgd = {}
   else:
    VVOZgd = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFJJe1(SELF):
      return None
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
        sTypeInt = int(STYPE)
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFZIIQ(val)
       servTypeHex = (hex(sTypeInt))[2:].upper()
       if mode == CCdz2s.VVCMqz:
        if sTypeInt in VV6JRk:
         STYPE = VVHm2S[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVOZgd.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVOZgd.append(tRow)
        else:
         VVOZgd.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCdz2s.VV2Z8v:
         VVOZgd[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCdz2s.VVYZ7T:
         VVOZgd[chName] = refCode
        elif mode == CCdz2s.VVSeLC:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVOZgd.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVOZgd.append(tRow)
         else:
          VVOZgd.append(tRow)
        elif mode == CCdz2s.VVR8Yd:
         if sTypeInt in VV6JRk:
          STYPE = VVHm2S[sTypeInt]
         freq, pol, fec, sr, syst = tp.VV38cC(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVOZgd.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVOZgd.append(tRow)
         else:
          VVOZgd.append(tRow)
        elif mode == CCdz2s.VVli6I:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVOZgd.append((chName, chProv, sat, refCode))
        elif mode == CCdz2s.VVHbv4:
         VVOZgd.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVOZgd and VVpQw7:
    FF3mKe(SELF, "No services found!")
   return VVOZgd
  else:
   if VVF6KR:
    FFhkqx(SELF, lamedbFile)
   return None
 def VVgUEy(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFVFca(path)
   if lines:
    newRows  = []
    VVOZgd = CCdz2s.VVc6H0(self, self.VVHbv4)
    if VVOZgd:
     lines = set(lines)
     for item in VVOZgd:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVOZgd = newRows
      VVOZgd.sort(key=lambda x: x[0].lower())
      VVcsOf = ("", self.VVstfL, [])
      VVXJOe = ("Zap", self.VVQGUK, [])
      self.VVCYpV(VV26yB=VVOZgd, VVXJOe=VVXJOe, VVcsOf=VVcsOf)
     else:
      FFxYUM(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVOZgd)))
   else:
    FFX4bs(self, "No hidden services.", FFXHTP())
  else:
   FFhkqx(self, path)
 def VVWHNj(self):
  VVOZgd = CCdz2s.VVc6H0(self, self.VVli6I)
  if VVOZgd:
   if VVOZgd:
    VVOZgd.sort(key=lambda x: x[0].lower())
    VVcsOf = ("" , self.VVstfL, [])
    VVXJOe  = ("Zap", self.VVQGUK, [])
    self.VVCYpV(VV26yB=VVOZgd, VVXJOe=VVXJOe, VVcsOf=VVcsOf)
   else:
    FFxYUM(self, "Lines\t: %d\nFound\t: %d\nLameDB\t: %d" % (len(lines), txt.count("\n"), len(VVOZgd)))
 def VV5Q94(self):
  totT, totC, totA, totS, totS2, satList = self.VV2b9B()
  txt = FFNe7q("Total Transponders:\n\n", VV1Zj2)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFNe7q("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV1Zj2)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFp151(item), satList.count(item))
  FFxYUM(self, txt)
 def VV2b9B(self):
  lamedbFile, disabledFile = CCdz2s.VVPPCo()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFJJe1(self):
      return 0, 0, 0, 0, 0, None
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFhkqx(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVRuzT(self):
  self.VVCzrq(True)
 def VV7jC6(self):
  self.VVCzrq(False)
 def VVCzrq(self, isWithPIcons):
  piconsPath = CCffqz.VV9UQ6()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCffqz.VVCu9O(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVOZgd = CCdz2s.VVc6H0(self, self.VVHbv4)
    if VVOZgd:
     channels = []
     for (chName, chProv, sat, refCode) in VVOZgd:
      if not FFJJe1(self):
       return
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFNqua(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVOZgd)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVuxnk(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVuxnk("PIcons Path"  , piconsPath)
     txt += VVuxnk("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVuxnk("Total services" , totalServices)
     txt += VVuxnk("With PIcons"  , totalWithPIcons)
     txt += VVuxnk("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFxYUM(self, txt)
     else:
      VVcsOf     = (""      , self.VVstfL , [])
      if isWithPIcons : VVwxMC = ("Export Current PIcon", self.VVo8nP  , [])
      else   : VVwxMC = None
      VVtuOR     = ("Statistics", FFxYUM, [txt])
      VVXJOe      = ("Zap", self.VVQGUK, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVCYpV(VV26yB=channels, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVtuOR=VVtuOR, VVwxMC=VVwxMC)
   else:
    FF3mKe(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF3mKe(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVstfL(self, VVTGDg, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFWqlt(self, fncMode=CCw0CQ.VVyjm7, refCode=refCode, chName=chName, text=txt)
 def VVo8nP(self, VVTGDg, title, txt, colList):
  png, path = CCffqz.VVJhKA(colList[3], colList[0])
  if path:
   CCffqz.VVn75S(self, png, path)
 @staticmethod
 def VVPPCo():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVr3TB():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVtlLb(self, isEnable):
  lamedbFile, disabledFile = CCdz2s.VVPPCo()
  if isEnable and not fileExists(disabledFile):
   FFX4bs(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF3mKe(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFAuNs(self, boundFunction(self.VVC1uY, isEnable), "%s Hidden Channels ?" % word)
 def VVC1uY(self, isEnable):
  lamedbFile , disabledFile = CCdz2s.VVPPCo()
  lamedb5File, diabled5File = CCdz2s.VVr3TB()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFWzzi()
  if res == 0 : FFX4bs(self, "Hidden List %s" % word)
  else  : FF3mKe(self, "Error while restoring:\n\n%s" % fileName)
 def VVjdzw(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFbCeq(self, cmd)
 def VVZe26(self):
  lamedbFile, disabledFile = CCdz2s.VVPPCo()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFOaw3("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFVFca(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFOaw3("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFWzzi()
   FFxYUM(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFhkqx(self, lamedbFile)
class CCw0CQ(Screen):
 VVYtHE  = 0
 VVQbms   = 1
 VVV9n9   = 2
 VVyjm7    = 3
 VVkKHz    = 4
 VVj5qP   = 5
 VVnWEm   = 6
 VV3vSH    = 7
 VVYO8w   = 8
 VVhGMO   = 9
 VVkDB4   = 10
 VV9PA0   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFOSVY(VVnnJQ, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVYtHE)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFNe7q("%s\n", VVleFh) % VVGWwg
  FFxmEB(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self["myLabel"].VVqvJx(enableSave=True)
  if   self.fncMode == self.VVYtHE : fnc = self.VVa6iV_VVYtHE
  elif self.fncMode == self.VVQbms  : fnc = self.VVa6iV_VVYtHE
  elif self.fncMode == self.VVV9n9  : fnc = self.VVa6iV_VVYtHE
  elif self.fncMode == self.VVyjm7  : fnc = self.VVa6iV_VVyjm7
  elif self.fncMode == self.VVkKHz  : fnc = self.VVa6iV_VVkKHz
  elif self.fncMode == self.VVj5qP  : fnc = self.VVa6iV_VVj5qP
  elif self.fncMode == self.VVnWEm  : fnc = self.VVa6iV_VVnWEm
  elif self.fncMode == self.VV3vSH  : fnc = self.VVa6iV_VV3vSH
  elif self.fncMode == self.VVYO8w  : fnc = self.VVa6iV_VVYO8w
  elif self.fncMode == self.VVhGMO : fnc = self.VVa6iV_VVhGMO
  elif self.fncMode == self.VVkDB4  : fnc = self.VVa6iV_VVkDB4
  elif self.fncMode == self.VV9PA0 : fnc = self.VVa6iV_VV9PA0
  self["myLabel"].setText("Reading Info ...")
  FFk91F(fnc)
 def VVT4BQ(self, txt):
  self["myLabel"].setText(txt, VVLxmM=VVJGAZ)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVWwRD(minHeight=minH)
 def VV6xBD(self, err):
  self["myLabel"].setText(err)
  FFGQmF(self["myTitle"], "#22200000")
  FFGQmF(self["myBody"], "#22200000")
  self["myLabel"].FFGQmFColor("#22200000")
  self["myLabel"].VVWwRD()
 def VVa6iV_VVYtHE(self):
  info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
  try:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  except:
   return
  if not info:
   self.VV6xBD("No data from system !")
   return
  self.text  = self.VV0FBL(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
  self.info  = info
  self.refCode = refCode
  self.decodedUrl = decodedUrl
  self.origUrl = origUrl
  self.iptvRef = iptvRef
  self.chName  = chName
  self.prov  = prov
  self.state  = state
  self.isIptv  = len(iptvRef) > 0
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVyjm7(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVkKHz(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVj5qP(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVnWEm(self):
  self.VVa6iV_basic("Picon Info")
 def VVa6iV_VV3vSH(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVYO8w(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVhGMO(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VVkDB4(self):
  self.chUrl = self.refCode + self.callingSELF.VVAmTJ(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVa6iV_basic(self.chName)
 def VVa6iV_VV9PA0(self):
  self.VVa6iV_basic(self.chName)
 def VVa6iV_basic(self, title):
  self.VVnWub(title)
  if not self.epg:
   epg = self.VVfG9L(self.info, self.refCode)
   if epg:
    self.epg = epg
  self.text += epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVI2An(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCffqz.VVJhKA(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVI2An(path)
  self.VVSi2E()
  self.VVT4BQ(self.text)
  self.VVbCuE()
 def VVSi2E(self):
  if not self.piconShown and self.picUrl:
   path, err = FFUSMT(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VVI2An(path)
    if self.piconShown and self.refCode:
     self.VVLKdU(path, self.refCode)
 def VVLKdU(self, path, refCode):
  if path and fileExists(path) and os.system(FFOaw3("which ffmpeg")) == 0:
   pPath = CCffqz.VV9UQ6()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFOaw3("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVI2An(self, path):
  if path and fileExists(path):
   err, w, h = self.VV17eU(path)
   if not err:
    if h > w:
     self.VVuOOi(self["myPicF"], w, h, True)
     self.VVuOOi(self["myPic"] , w, h, False)
   allOK = FFjIiX(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVuOOi(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV17eU(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFVfkZ(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVnWub(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VV0FBL(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFNe7q(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVuxnk(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFNe7q(state, VVix4Z)
   txt += "State\t: %s\n" % state
  w = FFc4jf(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFc4jf(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = FFc4jf(info      , iServiceInformation.sAspect)
  if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : aspect = "4:3"
  else           : aspect = "16:9"
  txt += "Video Format\t: %s\n" % aspect
  txt += self.VVuxnk(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVuxnk(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVuxnk(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFNe7q("IPTV", VV1Zj2)
   txt += self.VV1k0O(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVlR1h(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCVmtR()
    tpTxt, namespace = tp.VVnmOb(refCode)
    del tp
    if tpTxt:
     txt += FFNe7q("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFNe7q("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVuxnk(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVuxnk(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVuxnk(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVuxnk(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVuxnk(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVuxnk(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVuxnk(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVuxnk(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVuxnk(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 def VVuxnk(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFc4jf(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVRPaY(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVRPaY(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVlR1h(self, refCode, iptvRef, chName):
  refCode = FFrgTu(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFjNcO(VVGXYV + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFjNcO(VVGXYV + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV26yB = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVGXYV + item
   if fileExists(path):
    txt = FFjNcO(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV26yB.append(bName)
  txt = self.Sep
  if VV26yB:
   if len(VV26yB) == 1:
    txt += "%s\t: %s\n" % (FFNe7q("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV26yB[0])
   else:
    txt += FFNe7q("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV26yB):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVfG9L(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVxAAI(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVxAAI(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVxAAI(event, 0)
     except:
      pass
  return epg
 def VVxAAI(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FFNe7q(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FF2W46(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF2W46(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFwz6F(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFwz6F(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFwz6F(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FFNe7q(evShort, VVPZsu)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFNe7q(evDesc , VVPZsu)
    if txt:
     txt = FFNe7q("\n%s\n%s Event:\n%s\n" % (VVGWwg, ("Current", "Next")[evNum], VVGWwg), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VV1k0O(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFXGZ9(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   txt += "\n"
   txt += FFNe7q("URL:", VV1Zj2) + "\n%s\n" % decodedUrl
  else:
   txt = "\n"
   txt += FFNe7q("Reference:", VV1Zj2) + "\n%s\n" % refCode
  return txt
 def VVbCuE(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFZjOO(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  picUrl, epg, err = self.VVoZ5c(FFl9uW(url))
  if epg:
   self.text += "\n" + FFQpa3("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
   self.VVT4BQ(self.text)
  if picUrl:
   self.picUrl = picUrl
   self.VVSi2E()
 def VVoZ5c(self, decodedUrl):
  if not FFhnij():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCn3vN.VVM1D4(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCn3vN.VVwyBK(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if uType == "live":
    epg, lang = self.VVXI7H(tDict)
    if epg:
     epg = "Language\t: %s\n\n%s" % (lang, epg)
   elif uType == "movie":
    epg, picUrl = self.VVi1ID(tDict)
  if epg : return picUrl, epg, ""
  else : return picUrl, "" ,  "No EPG from server !"
 def VVXI7H(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCn3vN.VVTHaX(item, "title"    , is_base64=True )
     lang    = CCn3vN.VVTHaX(item, "lang"         ).upper()
     description   = CCn3vN.VVTHaX(item, "description"  , is_base64=True )
     start_timestamp  = CCn3vN.VVTHaX(item, "start_timestamp" , isDate=True  )
     stop_timestamp  = CCn3vN.VVTHaX(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCn3vN.VVTHaX(item, "stop_timestamp"       )
     now_playing   = CCn3vN.VVTHaX(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVhsuV, ""
      else     : color, txt = VVix4Z , "    (CURRENT EVENT)"
      epg += FFNe7q("_" * 32 + "\n", VVleFh)
      epg += FFNe7q("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FFNe7q(description, VVPZsu)
      evNum += 1
   except:
    pass
  return epg, lang
 def VVi1ID(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item =tDict["info"]
    movie_image   = CCn3vN.VVTHaX(item, "movie_image" )
    genre    = CCn3vN.VVTHaX(item, "genre"   ) or "-"
    plot    = CCn3vN.VVTHaX(item, "plot"   ) or "-"
    cast    = CCn3vN.VVTHaX(item, "cast"   ) or "-"
    rating    = CCn3vN.VVTHaX(item, "rating"   ) or "-"
    director   = CCn3vN.VVTHaX(item, "director"  ) or "-"
    releasedate   = CCn3vN.VVTHaX(item, "releasedate" ) or "-"
    duration   = CCn3vN.VVTHaX(item, "duration"  ) or "-"
    epg += "Genre\t: %s\n"  % genre
    epg += "Released\t: %s\n" % releasedate
    epg += "Duration\t: %s\n" % duration
    epg += "Director\t: %s\n" % director
    epg += "Rating\t: %s\n\n" % rating
    epg += "Cast:\n%s\n\n"  % FFNe7q(cast, VVPZsu)
    epg += "Plot:\n%s"   % FFNe7q(plot, VVPZsu)
   except:
    pass
  return epg, movie_image
class CCbodp():
 def __init__(self):
  self.VVZvGq  = ""
  self.VVocsj   = ""
  self.VVtoBT  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVmRFF(self, url, mac, VVU7ut=True):
  self.VVZvGq = ""
  self.VVocsj  = ""
  self.VVtoBT = ""
  host = self.VVJUke(url)
  if not host:
   if VVU7ut:
    self.VVU7utor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVZ7h3(mac)
  if not host:
   if VVU7ut:
    self.VVU7utor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVZvGq = host
  self.VVocsj  = mac
  self.VVtoBT = ""
  return True
 def VV0Bti(self):
  res, err = self.VV6Fr5(self.VVZvGq, useCookies=False)
  if err:
   self.VVU7utor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VV6Fr5(newUrl, res.cookies)
   if err:
    self.VVU7utor(err, "URL Redirection")
    return False
   else:
    host = self.VVJUke(newUrl)
    if not host:
     self.VVU7utor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVZvGq = host
  token, profile = self.VVZY1C()
  if not token:
   return False
  return True
 def VVJUke(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VVZ7h3(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVZY1C(self, VVU7ut=True):
  try:
   token = self.VVRv4G()
   if token:
    self.VVtoBT = token
   else:
    if VVU7ut:
     self.VVU7utor("Could not get Token from server !")
    return "", ""
   return token, self.VVqXVN()
  except:
   return "", ""
 def VVRv4G(self):
  token  = ""
  res, err = self.VV6Fr5(self.VVIIty())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCn3vN.VVTHaX(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVqXVN(self):
  res, err = self.VV6Fr5(self.VVpIGf())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVL9zI(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV9HFk()
  if len(rows) < 10:
   rows = self.VVKYR8()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVZvGq ))
   rows.append(("MAC (from URL)" , self.VVocsj ))
   rows.append(("Token"   , self.VVtoBT ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVocsj ))
   rows.append(("2", self.colored_server, "Host" , self.VVZvGq ))
   rows.append(("2", self.colored_server, "Token" , self.VVtoBT ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVwB0J(self):
  token, profile = self.VVZY1C()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VV8n7m()
  res, err = self.VV6Fr5(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCn3vN.VVTHaX(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VV9HFk(self):
  m3u_Url = self.VVwB0J()
  rows = []
  if m3u_Url:
   res, err = self.VV6Fr5(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF2W46(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF2W46(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVKYR8(self):
  tDict = self.VVqXVN()
  try:
   item = tDict["js"]
  except:
   return []
  if not isinstance(tDict, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFJHxZ(val): val = FFjf4U(val.decode("UTF-8"))
     else     : val = self.VVocsj
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF2W46(int(parts[1]))
      if parts[2] : ends = FF2W46(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF2W46(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVAmTJ(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVtuwu(mode, chCm, epNum, epId)
  token, profile = self.VVZY1C(VVU7ut=False)
  if not token:
   return ""
  res, err = self.VV6Fr5(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCn3vN.VVTHaX(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVIIty(self):
  return self.VVZvGq + "/server/load.php?type=stb&action=handshake&token=&mac=%s" % self.VVocsj
 def VVpIGf(self):
  return self.VVZvGq + "/server/load.php?type=stb&action=get_profile"
 def VVrw20(self, mode):
  url = self.VVZvGq + "/server/load.php?type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVDnVS(self, catID):
  return self.VVZvGq + "/server/load.php?type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVqfw4(self, mode, catID, page):
  url = self.VVZvGq + "/server/load.php?type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVA2Yh(self, mode, catID):
  return self.VVZvGq + "/server/load.php?type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVtuwu(self, mode, chCm, serCode, serId):
  url = self.VVZvGq + "/server/load.php?action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV8n7m(self):
  return self.VVZvGq + "/server/load.php?type=itv&action=create_link"
 def VV1rej(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV7cO2(catID, stID, chNum)
  query = self.VVPMNt(mode, FFIfm6(host), FFIfm6(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVPMNt(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVfnDB(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVPMNt(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFjf4U(host)
  mac   = FFjf4U(mac)
  valid = False
  if self.VVJUke(playHost) and self.VVJUke(host) and self.VVJUke(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV6Fr5(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVocsj, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVtoBT:
    headers["Authorization"] = "Bearer %s" % self.VVtoBT
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVwRTq(host, mac, tType, action, keysList=[]):
  myPortal = CCbodp()
  ok = myPortal.VVmRFF(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VVZY1C()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VV6Fr5(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVg5Z4(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVg5Z4(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVU7utor(self, err, title="Portal Browser"):
  FF3mKe(self, str(err), title=title)
class CCRrkz():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex" , "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
 def VVyPV7(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(r"(b[-]*e[-]*I[-]*N)", r"beIN", name, flags=IGNORECASE).strip()
  if CCn3vN.VVwt9Y(name):
   return CCn3vN.VVeOsu(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVh48F(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVy8h1(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
class CCciTg(CCbodp):
 def __init__(self):
  CCbodp.__init__(self)
 def VVbxcn(self):
  try:
   import requests
   FFapsE(self, self.VVZyaE, title="Searching ...")
  except:
   FFAuNs(self, self.VVWdhK, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVox6b(self, winSession, url, mac):
  if self.VVmRFF(url, mac):
   FFapsE(winSession, self.VV1V1Q, title="Checking Server ...")
  else:
   FF3mKe(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVWdhK(self):
  from sys import version_info
  cmdUpd = FFLJQQ(VVQIHG, "")
  if cmdUpd:
   cmdInst = FFl4YE(VVgO7i, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFH6Oq(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFYXW3(self)
 def VVZyaE(self):
  lines = FFwzkK('find / %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % FFBQjd(1))
  if lines:
   lines.sort()
   VVTikG = []
   for line in lines:
    VVTikG.append((line, line))
   OKBtnFnc = self.VVaEs6
   FFh3ra(self, None, title="Select Portals File", VVTikG=VVTikG, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FF3mKe(self, "No portal files found\n\nFile example : portalxx.txt \n(separate URL and MAC with space/tab/comma)")
 def VVaEs6(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CCgXI4, barTheme=CCgXI4.VV2nUu
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVIbtb, path)
       , VV6kEn = boundFunction(self.VVxQft, menuInstance, path))
 def VVIbtb(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  lines  = FFVFca(path)
  progBarObj.VVbJ1q(len(lines))
  progBarObj.VVcLSJ = []
  import time
  for lineNum, line in enumerate(lines, start=1):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV72tV(1)
   iSleep(0.0001)
   line = line.strip()
   if not line or "password" in line:
    continue
   span = iSearch(urlMacPatt, line, IGNORECASE)
   if span:
    c  += 1
    subj = span.group(1).strip() or "-"
    url  = span.group(2).strip()
    mac  = span.group(3).strip().replace(" ", "").upper()
    info = span.group(4).strip() or "-"
    host = self.VVJUke(url)
    mac  = self.VVZ7h3(mac)
    if host and mac and progBarObj:
     progBarObj.VVcLSJ.append((str(c), str(lineNum), subj, host, mac, info))
    url  = ""
    continue
   if not url:
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if not span:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
   else:
    span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     mac  = span.group(2).strip().replace(" ", "").upper()
     info = span.group(3).strip() or "-"
     host = self.VVJUke(url)
     mac  = self.VVZ7h3(mac)
     if host and mac and not mac.startswith("AC") and progBarObj:
      progBarObj.VVcLSJ.append((str(c), str(lineNum), "-", host, mac, info))
    else:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
 def VVxQft(self, menuInstance, path, VVzE4w, VVcLSJ, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVcLSJ:
   VVgrOj  = ("Home Menu", FFHFZT, [])
   VVwxMC  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVtuOR = ("Edit File" , boundFunction(self.VVtRi6, path) , [])
   VVXJOe  = ("Select"  , self.VVox6b_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVfMBx  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVTGDg = FFw32s(self, None, title=title, header=header, VV26yB=VVcLSJ, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22, VVXJOe=VVXJOe, VVgrOj=VVgrOj, VVtuOR=VVtuOR, VVwxMC=VVwxMC, VVICrB="#0a001111", VVMl7F="#0a001122", VV7My0="#0a001122", VV0ai5="#00000000", VVRCjQ=True, searchCol=1)
   if not VVzE4w:
    FFK43o(VVTGDg, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVzE4w:
    FF3mKe(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVox6b_fromMacFiles(self, VVTGDg, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVox6b(VVTGDg, url, mac)
 def VVtRi6(self, path, VVTGDg, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCrET4(self, path, VV6kEn=boundFunction(self.VVjXRR, VVTGDg), curRowNum=rowNum)
  else    : FFhkqx(self, path)
 def VVjXRR(self, VVTGDg, fileChanged):
  if fileChanged:
   VVTGDg.cancel()
 def VVSPw6(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFjf4U(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VV1V1Q(self):
  if self.VV0Bti():
   VVTikG = []
   VVTikG.append(("Live"     , "stbLive"  ))
   VVTikG.append(("VOD"     , "stbVod"  ))
   VVTikG.append(("Series (Seasons)"  , "stbSeries" ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("Portal Account Info." , "accountInfo" ))
   OKBtnFnc  = self.VVQjuz
   VVr7QF  = ("Home Menu", FFHFZT)
   FFh3ra(self, None, title="Portal Resources (MAC=%s)" % self.VVocsj, VVTikG=VVTikG, OKBtnFnc=OKBtnFnc, VVr7QF=VVr7QF)
 def VVQjuz(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "stbLive"  : mode = "itv"
   elif ref == "stbVod"  : mode = "vod"
   elif ref == "stbSeries"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFapsE(menuInstance, boundFunction(self.VVH5wq, mode), title="Reading Categories ...")
   else : FFapsE(menuInstance, boundFunction(self.VVh1TN, menuInstance, title), title="Reading Account ...")
 def VVh1TN(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVL9zI(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVocsj)
  VVgrOj  = ("Home Menu" , FFHFZT, [])
  if totCols == 2:
   VVwxMC = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVwxMC = ("Other Info." , boundFunction(self.VVYjsT, menuInstance) , [])
  FFw32s(self, None, title=title, header=header, VV26yB=rows, VVX78s=widths, VV3p9i=26, VVgrOj=VVgrOj, VVwxMC=VVwxMC, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000", searchCol=searchCol)
 def VVYjsT(self, menuInstance, VVTGDg, title, txt, colList):
  VVTGDg.cancel()
  FFapsE(menuInstance, boundFunction(self.VVh1TN, menuInstance, title, forceMoreInfo=True), title="Reading Account ...")
 def VVH5wq(self, mode):
  token, profile = self.VVZY1C()
  if not token:
   return
  res, err = self.VV6Fr5(self.VVrw20(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCRrkz()
     chList = tDict["js"]
     for item in chList:
      Id   = CCn3vN.VVTHaX(item, "id"       )
      Title  = CCn3vN.VVTHaX(item, "title"      )
      censored = CCn3vN.VVTHaX(item, "censored"     )
      Title = processChanName.VVh48F(Title)
      if Title and not Title.strip().lower() == "all":
       list.append((Title.strip(), Id))
   except:
    pass
  if mode == "series" : title = mode.capitalize()
  else    : title = mode.upper()
  title += " Categories"
  if list:
   VVtuOR = None #("Find %s Name" % fName, boundFunction(self.VVk9wb, fMode), [])
   VVXJOe  = ("Show Channels" , boundFunction(self.VV9eIQ, mode) , [])
   VVgrOj = ("Home Menu"  , FFHFZT         , [])
   header   = ("Category", "catID" )
   widths   = (100   , 0  )
   FFw32s(self, None, title=title, header=header, VV26yB=list, VVX78s=widths, VV3p9i=30, VVgrOj=VVgrOj, VVtuOR=VVtuOR, VVXJOe=VVXJOe, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000")
  else:
   FF3mKe(self, "Could not get Categories from server!", title=title)
 def VVWoRi(self, mode, VVTGDg, title, txt, colList):
  FFapsE(VVTGDg, boundFunction(self.VVcZGt, mode, VVTGDg, title, txt, colList), title="Downloading ...")
 def VVcZGt(self, mode, VVTGDg, title, txt, colList):
  token, profile = self.VVZY1C()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV6Fr5(self.VVDnVS(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCn3vN.VVTHaX(item, "id"    )
      actors   = CCn3vN.VVTHaX(item, "actors"   )
      added   = CCn3vN.VVTHaX(item, "added"   )
      age    = CCn3vN.VVTHaX(item, "age"   )
      category_id  = CCn3vN.VVTHaX(item, "category_id" )
      description  = CCn3vN.VVTHaX(item, "description" )
      director  = CCn3vN.VVTHaX(item, "director"  )
      genres_str  = CCn3vN.VVTHaX(item, "genres_str"  )
      name   = CCn3vN.VVTHaX(item, "name"   )
      path   = CCn3vN.VVTHaX(item, "path"   )
      screenshot_uri = CCn3vN.VVTHaX(item, "screenshot_uri" )
      series   = CCn3vN.VVTHaX(item, "series"   )
      cmd    = CCn3vN.VVTHaX(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVXJOe  = ("Play"  , boundFunction(self.VV5Mws, mode)        , [])
   VVcsOf = (""   , boundFunction(self.VVmafe, mode)      , [])
   VVgrOj = ("Home Menu" , FFHFZT                , [])
   VVpp6N = ("Download PIcons" , boundFunction(self.VVxeEM, mode)      , [])
   VVtuOR = ("Add ALL to Bouquet" , boundFunction(self.VVZOzY, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVfMBx  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFw32s(self, None, title=seriesName, header=header, VV26yB=list, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=26, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000")
  else:
   FF3mKe(self, "Could not get Episodes from server!", title=seriesName)
 def VV9eIQ(self, mode, VVTGDg, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.session.open(CCgXI4, barTheme=CCgXI4.VVhtfw
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVOq3u, mode, bName, catID)
      , VV6kEn = boundFunction(self.VV2rjg, mode, bName, catID))
 def VV2rjg(self, mode, bName, catID, VVzE4w, VVcLSJ, threadCounter, threadTotal, threadErr):
  if VVcLSJ:
   if mode == "series":
    VVXJOe  = ("Episodes", boundFunction(self.VVWoRi, mode) , [])
    VVpp6N = None
    VVtuOR = None
   else:
    VVXJOe  = ("Play"    , boundFunction(self.VV5Mws, mode)     , [])
    VVpp6N = ("Download PIcons" , boundFunction(self.VVxeEM, mode)     , [])
    VVtuOR = ("Add ALL to Bouquet" , boundFunction(self.VVZOzY, mode, bName) , [])
   VVcsOf = (""      , boundFunction(self.VV6lqZ, mode)    , [])
   VVgrOj = ("Home Menu"    , FFHFZT             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVfMBx  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVTGDg = FFw32s(self, None, title=bName, header=header, VV26yB=VVcLSJ, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=26, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000", VVRCjQ=True, searchCol=1)
   if not VVzE4w:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVTGDg.VVeD6r(VVTGDg.VVEebE() + tot)
    if threadErr: FFK43o(VVTGDg, "Error while reading !", 2000)
    else  : FFK43o(VVTGDg, "Stopped at channel %s" % threadCounter, 1000)
  else:
   FF3mKe(self, "Could not get list from server !", title=bName)
 def VV6lqZ(self, mode, VVTGDg, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   FFWqlt(self, fncMode=CCw0CQ.VV9PA0, portalHost=self.VVZvGq, portalMac=self.VVocsj, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVBpWA(mode, VVTGDg, title, txt, colList)
 def VVmafe(self, mode, VVTGDg, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFNe7q(colList[10], VVPZsu)
  txt += "Description:\n%s" % FFNe7q(colList[11], VVPZsu)
  self.VVBpWA(mode, VVTGDg, title, txt, colList)
 def VVBpWA(self, mode, VVTGDg, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVQzeG(mode, colList)
  refCode, chUrl = self.VV1rej(self.VVZvGq, self.VVocsj, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  FFWqlt(self, fncMode=CCw0CQ.VVkDB4, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVOq3u(self, mode, bName, catID, progBarObj):
  try:
   token, profile = self.VVZY1C()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVcLSJ, total_items, max_page_items, err = self.VVi6di(mode, catID, 1, 1)
   progBarObj.VV72tV(max_page_items)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVcLSJ and total_items > -1 and max_page_items > -1:
    progBarObj.VVbJ1q(total_items)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVi6di(mode, catID, page, counter)
     if err:
      progBarObj.VV3pTu()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVcLSJ += list
      progBarObj.VV72tV(len(list))
  except:
   pass
 def VVi6di(self, mode, catID, page, counter):
  list  = []
  total_items = max_page_items = -1
  res, err = self.VV6Fr5(self.VVqfw4(mode, catID, page))
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVTWj7(CCn3vN.VVTHaX(item, "total_items" ))
     max_page_items = self.VVTWj7(CCn3vN.VVTHaX(item, "max_page_items" ))
     processChanName = CCRrkz()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCn3vN.VVTHaX(item, "id"    )
      name   = CCn3vN.VVTHaX(item, "name"   )
      tv_genre_id  = CCn3vN.VVTHaX(item, "tv_genre_id" )
      number   = CCn3vN.VVTHaX(item, "number"   ) or str(counter)
      logo   = CCn3vN.VVTHaX(item, "logo"   )
      screenshot_uri = CCn3vN.VVTHaX(item, "screenshot_uri" )
      cmd    = CCn3vN.VVTHaX(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVyPV7(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVZOzY(self, mode, bName, VVTGDg, title, txt, colList):
  FFapsE(VVTGDg, boundFunction(self.VVoylz, mode, bName, VVTGDg, title, txt, colList), title="Adding Channels ...")
 def VVoylz(self, mode, bName, VVTGDg, title, txt, colList):
  bNameFile = CCn3vN.VVUE1j(bName)
  num  = 0
  path = VVGXYV + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVGXYV + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVTGDg.VVaz4B():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVQzeG(mode, row)
    refCode, chUrl = self.VV1rej(self.VVZvGq, self.VVocsj, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFPDjv(os.path.basename(path))
  self.VVYSxf(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVTWj7(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV5Mws(self, mode, VVTGDg, title, txt, colList, forceZap=False):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVQzeG(mode, colList)
  refCode, chUrl = self.VV1rej(self.VVZvGq, self.VVocsj, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if not forceZap and self.VVwt9Y(chName):
   FFK43o(VVTGDg, "This is a marker!", 300)
  else:
   FFHTCm(self, chUrl, VVqXf4=False)
   self.session.open(CCEwTV, portalTableParam=(self, VVTGDg, mode))
 def VVQzeG(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCn3vN(Screen, CCciTg):
 VVhyTG = 0
 VVh6WJ = 1
 VVjcyr = 2
 VVRqDt = 3
 VV8roK  = 4
 VVqcBO  = 5
 VVwJWX  = 6
 VVf8FW  = 7
 VVwyVS   = 8
 VVjnrm  = 9
 VVlNqd  = 10
 VV0pf5  = 11
 VVB3t0  = 12
 VVxSy5   = 13
 VVcvIm   = 14
 VVr7Xf   = 15
 VVUU7L   = 16
 VVdIMY   = 17
 VVqKJS    = 0
 VV4r1C   = 1
 VVjM2y   = 2
 VVedmu   = 3
 VVUacs  = 4
 VVE9Bj   = 5
 VVrgSU   = 6
 VVVRAk  = 7
 VVqC3Z  = 8
 VVwuoh   = 9
 VViM51 = 10
 VVj8kD   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 1100, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVTGDg  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVW5jGData  = {}
  self.lastFindIptvName = ""
  CCciTg.__init__(self)
  VVTikG= self.VVS1Ey()
  FFxmEB(self, VVTikG=VVTikG)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
  FFHvL6(self)
 def VVS1Ey(self):
  files = self.VVnKeU()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVW5jG_fromPlayList" ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVW5jG_fromM3u"  ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVW5jG_fromMac"  ))
  qUrl, iptvRef = self.VVYYLH()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVW5jG_fromCurrChan" ))
  VVTikG = []
  if files:
   if self.VVTGDg:
    VVTikG.append(("Add Current List to a New Bouquet"      , "VVrwxL"  ))
    VVTikG.append(VVK4l8)
    VVTikG.append(("Change Current List References to Unique Codes"   , "VVu3fI"))
    VVTikG.append(("Change Current List References to Identical Codes"  , "VVezoy_rows" ))
    VVTikG.append(VVK4l8)
    VVTikG.append(("Share Reference with Satellite/C/T Channel"    , "VVhenB" ))
   else:
    VVTikG += tList
    VVTikG.append(VVK4l8)
    VVTikG.append(("Local IPTV Channels (All)"        , "iptvTable_all"   ))
    VVTikG.append(VVK4l8)
    VVTikG.append(("Count Available IPTV Channels"       , "VVdDbU"    ))
    VVTikG.append(("Check Reference Codes Format"        , "VVD7TW"   ))
    VVTikG.append(("Check System Acceptable Reference Types"     , "VVDRDY"   ))
    VVTikG.append(VVK4l8)
    VVTikG.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVPEjm"  ))
    VVTikG.append(("Change ALL References to Matching Sat/C/T Channels"  , "VVI6i1" ))
    VVTikG.append(("Change ALL References to Unique Codes"     , "VVZnE8" ))
    VVTikG.append(("Change ALL References to Identical Codes"     , "VVezoy_all" ))
  if not self.VVTGDg:
   if not files:
    VVTikG += tList
   VVTikG.append(VVK4l8)
   VVTikG.append(("Analyse m3u File"            , "VVOlVe"   ))
   VVTikG.append(("Convert m3u File to Bouquet (from File Manager)"    , "VV0SCr" ))
   VVTikG.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VV0rvI" ))
   VVTikG.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVfq8S" ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("Reload Channels and Bouquets"         , "VVsBUg"   ))
  return VVTikG
 def VVElZw(self, item):
  if item is not None:
   if   item == "VVrwxL"   : FFCkFz(self, self.VVrwxL, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVu3fI" : FFAuNs(self, boundFunction(FFapsE, self.VVTGDg, self.VVu3fI ), "Change Current List References to Unique Codes ?")
   elif item == "VVezoy_rows" : FFAuNs(self, boundFunction(FFapsE, self.VVTGDg, self.VVezoy   ), "Change Current List References to Identical Codes ?")
   elif item == "VVhenB" : FFapsE(self.VVTGDg, self.VVhenB, title="Searching ...")
   elif item == "VVW5jG_fromPlayList" : FFapsE(self, boundFunction(self.VVPCEM, True), title="Searching ...")
   elif item == "VVW5jG_fromM3u"  : FFapsE(self, boundFunction(self.VVhnRw, 0), title="Searching ...")
   elif item == "VVW5jG_fromMac"  : self.VVbxcn()
   elif item == "VVW5jG_fromCurrChan" : self.VVox6b_fromCurrChan()
   elif item == "iptvTable_live"   : FFapsE(self, boundFunction(self.VV1zqc, self.VVf8FW ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFapsE(self, boundFunction(self.VV1zqc, self.VVhyTG) , title="Loading Channels ...")
   elif item == "VVdDbU"    : FFapsE(self, self.VVdDbU)
   elif item == "VVD7TW"    : FFapsE(self, self.VVD7TW)
   elif item == "VVDRDY"   : FFapsE(self, self.VVDRDY)
   elif item == "VVPEjm"  : self.VVPEjm()
   elif item == "VVI6i1"  : FFAuNs(self, boundFunction(FFapsE, self, self.VVI6i1 ), "Copy from existing Sat. Channel" )
   elif item == "VVZnE8" : FFAuNs(self, boundFunction(FFapsE, self, self.VVZnE8 ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVezoy_all" : FFAuNs(self, boundFunction(FFapsE, self, self.VVezoy  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVOlVe"   : FFapsE(self, boundFunction(self.VVhnRw, 1), title="Searching ...")
   elif item == "VV0SCr" : self.VV0SCr()
   elif item == "VV0rvI" : FFapsE(self, boundFunction(self.VVhnRw, 2), title="Searching ...")
   elif item == "VVfq8S" : FFapsE(self, boundFunction(self.VVPCEM, False), title="Searching ...")
   elif item == "VVsBUg"   : FFapsE(self, boundFunction(CCdz2s.VVsBUg, self))
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVElZw(item)
 def VV1zqc(self, mode):
  VVOZgd = self.VV4bhE(mode)
  if VVOZgd:
   VVpp6N = ("Current Service", self.VVFHve , [])
   VVtuOR = ("Options"  , self.VV57yD   , [])
   VVwxMC = ("Filter"   , self.VViDJl    , [])
   VVXJOe  = ("Zap"   , self.VVHBZg   , [])
   VVcsOf = (""    , self.VVGdku    , [])
   VVPfEQ = (""    , self.VVZzDR     , [])
   VVCWuB = (""    , self.VVRdlT    , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVfMBx  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFw32s(self, None, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22
     , VVXJOe=VVXJOe, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVwxMC=VVwxMC, VVcsOf=VVcsOf, VVPfEQ=VVPfEQ
     , VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000", VVRCjQ=True, searchCol=1)
  else:
   if mode == self.VVf8FW: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF3mKe(self, err)
 def VVZzDR(self, VVTGDg, title, txt, colList):
  self.VVTGDg = VVTGDg
 def VVRdlT(self, VVTGDg):
  self.VVTGDg = None
 def VV57yD(self, VVTGDg, title, txt, colList):
  VVTikG= self.VVS1Ey()
  FFh3ra(self, self.VVElZw, title="IPTV Tools", VVTikG=VVTikG)
 def VViDJl(self, VVTGDg, title, txt, colList):
  VVTikG = []
  VVTikG.append(("All"         , "all"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Prefix of Selected Channel"   , "sameName" ))
  VVTikG.append(("Suggest Words from Selected Channel" , "partName" ))
  VVTikG.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Live TV"        , "live"  ))
  VVTikG.append(("VOD"         , "vod"   ))
  VVTikG.append(("Series"        , "series"  ))
  VVTikG.append(("Uncategorised"      , "uncat"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Video"        , "video"  ))
  VVTikG.append(("Audio"        , "audio"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("MKV"         , "MKV"   ))
  VVTikG.append(("MP4"         , "MP4"   ))
  VVTikG.append(("MP3"         , "MP3"   ))
  VVTikG.append(("AVI"         , "AVI"   ))
  VVTikG.append(("FLV"         , "FLV"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVJH9g()
  if bNames:
   bNames.sort()
   VVTikG.append(VVK4l8)
   for item in bNames:
    VVTikG.append((item, "__b__" + item))
  filterObj = CC1HZL(self)
  filterObj.VVwutn(VVTikG, VVTikG, boundFunction(self.VVnOYS, VVTGDg))
 def VVnOYS(self, VVTGDg, item=None):
  prefix = VVTGDg.VV7rv1(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVhyTG, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVh6WJ , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVjcyr , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVRqDt , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVf8FW  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVwyVS   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVjnrm  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVlNqd  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VV0pf5  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVB3t0  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVxSy5   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVcvIm   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVr7Xf   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVUU7L   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVdIMY   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVwJWX  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VV8roK  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVqcBO  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVjcyr:
   VVTikG = []
   chName = VVTGDg.VV7rv1(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVTikG.append((item, item))
    if not VVTikG and chName:
     VVTikG.append((chName, chName))
    FFh3ra(self, boundFunction(self.VVZHzJ_partOfName, title), title="Words from Current Selection", VVTikG=VVTikG)
   else:
    VVTGDg.VVstuD("Invalid Channel Name")
  else:
   words, asPrefix = CC1HZL.VVxEg1(words)
   if not words and mode in (self.VV8roK, self.VVqcBO):
    FFK43o(self.VVTGDg, "Incorrect filter", 2000)
   else:
    FFapsE(self.VVTGDg, boundFunction(self.VV3Evu, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVZHzJ_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFapsE(self.VVTGDg, boundFunction(self.VV3Evu, self.VVjcyr, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVeOsu(txt):
  return "#f#11ffff00#" + txt
 def VV3Evu(self, mode, words, asPrefix, title):
  VVOZgd = self.VV4bhE(mode=mode, words=words, asPrefix=asPrefix)
  if VVOZgd : self.VVTGDg.VV8OPy(VVOZgd, title)
  else  : self.VVTGDg.VVstuD("Not found")
 def VV4bhE(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVOZgd = []
  files  = self.VVnKeU()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFjNcO(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV8SWr = span.group(1)
    else : VV8SWr = ""
    VV8SWr_lCase = VV8SWr.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVwt9Y(chName): chNameMod = self.VVeOsu(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV8SWr, chType, refCode, url)
     ok = False
     tUrl = FFl9uW(url).lower()
     if mode == self.VVhyTG       : ok = True
     elif mode == self.VVwJWX       : ok = True
     elif mode == self.VV0pf5:
      if CCn3vN.VVM1D4(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVB3t0:
      if CCn3vN.VVM1D4(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVf8FW:
      if CCn3vN.VVM1D4(tUrl, compareType="live")  : ok = True
     elif mode == self.VVwyVS:
      if CCn3vN.VVM1D4(tUrl, compareType="movie") : ok = True
     elif mode == self.VVjnrm:
      if CCn3vN.VVM1D4(tUrl, compareType="series") : ok = True
     elif mode == self.VVlNqd:
      if CCn3vN.VVM1D4(tUrl, compareType="")   : ok = True
     elif mode == self.VVxSy5:
      if CCn3vN.VVM1D4(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVcvIm:
      if CCn3vN.VVM1D4(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVr7Xf:
      if CCn3vN.VVM1D4(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVUU7L:
      if CCn3vN.VVM1D4(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVdIMY:
      if CCn3vN.VVM1D4(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVh6WJ:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVjcyr:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVRqDt:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VV8roK:
      if words[0] == VV8SWr_lCase:
       ok = True
     elif mode == self.VVqcBO:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVOZgd.append(row)
      chNum += 1
  if VVOZgd and mode == self.VVwJWX:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVOZgd)
   for item in VVOZgd:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVOZgd = newRows
  return VVOZgd
 def VVrwxL(self, bName):
  if bName:
   FFapsE(self.VVTGDg, boundFunction(self.VV0pXM, bName), title="Adding Channels ...")
 def VV0pXM(self, bName):
  num = 0
  path = VVGXYV + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVGXYV + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVTGDg.VVaz4B():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFIQzg(row[1]))
    totChange += 1
  FFPDjv(os.path.basename(path))
  self.VVYSxf(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVPEjm(self):
  txt = "Stream Type "
  VVTikG = []
  VVTikG.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVTikG.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVTikG.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVTikG.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVTikG.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVTikG.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFh3ra(self, self.VVw7IU, title="Change Reference Types to:", VVTikG=VVTikG)
 def VVw7IU(self, item=None):
  if item:
   if   item == "RT_1"  : self.VV2HIm("1"   )
   elif item == "RT_4097" : self.VV2HIm("4097")
   elif item == "RT_5001" : self.VV2HIm("5001")
   elif item == "RT_5002" : self.VV2HIm("5002")
   elif item == "RT_8192" : self.VV2HIm("8192")
   elif item == "RT_8193" : self.VV2HIm("8193")
 def VV2HIm(self, rType):
  FFAuNs(self, boundFunction(FFapsE, self, boundFunction(self.VV5Q5Z, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VV5Q5Z(self, refType):
  totChange = 0
  files  = self.VVnKeU()
  if files:
   for path in files:
    txt = FFjNcO(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFPDjv(os.path.basename(path))
  self.VVYSxf(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVdDbU(self):
  totFiles = 0
  files  = self.VVnKeU()
  if files:
   totFiles = len(files)
  totChans = 0
  VVOZgd = self.VV4bhE()
  if VVOZgd:
   totChans = len(VVOZgd)
  FFxYUM(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVD7TW(self):
  files  = self.VVnKeU()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFjNcO(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVHsWS
   else    : color = VVix4Z
   totInvalid = FFNe7q(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFNe7q("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFxYUM(self, txt, title="Check IPTV References")
 def VVDRDY(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVGXYV + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFPDjv(os.path.basename(path))
  FFWzzi()
  acceptedList = []
  VVQOTK = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVQOTK:
   VVYcTd = FF0qTN(VVQOTK)
   if VVYcTd:
    for service in VVYcTd:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVGXYV + userBName
  bFile = VVGXYV + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFOaw3("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFOaw3("rm -f '%s'" % path)
  os.system(cmd)
  FFWzzi()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVHsWS
    else     : res, color = "No" , VVix4Z
    txt += "    %s\t: %s\n" % (item, FFNe7q(res, color))
   FFxYUM(self, txt, title=title)
  else:
   txt = FF3mKe(self, "Could not complete the test on your system!", title=title)
 def VVI6i1(self):
  lameDbChans = CCdz2s.VVc6H0(self, CCdz2s.VVYZ7T)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVnKeU():
    toSave = False
    txt = FFjNcO(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVYSxf(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF3mKe(self, 'No channels in "lamedb" !')
 def VVZnE8(self):
  files  = self.VVnKeU()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFVFca(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVWoAp(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVYSxf(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVu3fI(self):
  iptvRefList = []
  files  = self.VVnKeU()
  if files:
   for path in files:
    txt = FFjNcO(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVTGDg.VVKseX(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVWoAp(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVnKeU()
  if files:
   for path in files:
    lines = FFVFca(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVYSxf(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVWoAp(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVezoy(self):
  list = None
  if self.VVTGDg:
   list = []
   for row in self.VVTGDg.VVaz4B():
    list.append(row[4] + row[5])
  files  = self.VVnKeU()
  totChange = 0
  if files:
   for path in files:
    lines = FFVFca(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVYSxf(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVYSxf(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFWzzi()
   if refreshTable and self.VVTGDg:
    VVOZgd = self.VV4bhE()
    if VVOZgd and self.VVTGDg:
     self.VVTGDg.VV8OPy(VVOZgd, self.tableTitle)
     self.VVTGDg.VVstuD(txt)
   FFxYUM(self, txt, title=title)
  else:
   FFX4bs(self, "No changes.")
 def VVJH9g(self):
  files = self.VVnKeU()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVKPBD = FFZh4R()
    if VVKPBD:
     for b in VVKPBD:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVnKeU(self):
  return CCn3vN.VVGyWB(self)
 @staticmethod
 def VVGyWB(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVGXYV + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFjNcO(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVGdku(self, VVTGDg, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFl9uW(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url  + ":" + chName
  ndx = txt.find("Ref.")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "Row Number\t: %d of %d\n\n%s" % (VVTGDg.VVu2q3() + 1, VVTGDg.VVOSYq(), txt)
  FFWqlt(self, fncMode=CCw0CQ.VV3vSH, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVHBZg(self, VVTGDg, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVoCCH(VVTGDg, chName, chUrl, "localIptv")
 def VVX5Go(self, mode, VVTGDg, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVeGN8(mode, colList)
  self.VVoCCH(VVTGDg, chName, chUrl, mode)
 def VVoCCH(self, VVTGDg, chName, chUrl, playerFlag):
  chName = FFIQzg(chName)
  if not self.VVwt9Y(chName):
   FFHTCm(self, chUrl, VVqXf4=False)
   self.session.open(CCEwTV, portalTableParam=(self, VVTGDg, playerFlag))
  else:
   FFK43o(VVTGDg, "This is a marker!", 300)
 @staticmethod
 def VVwt9Y(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVFHve(self, VVTGDg, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  if refCode:
   bName = FFY8A8()
   if any(x in origUrl for x in ("mode=", "&end=")):
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFrgTu(refCode, origUrl, chName) }
   VVTGDg.VV4w3d_partial(colDict, VVU7ut=True)
 def VV0SCr(self):
  self.session.open(CCXbmU)
  self.close()
 def VVhnRw(self, m3uMode):
  lines = FFwzkK("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFBQjd(1))
  if lines:
   lines.sort()
   VVTikG = []
   for line in lines:
    VVTikG.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File:"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VViuu9 = ("All to Playlist", self.VV9ybb)
   else    : VViuu9 = None
   OKBtnFnc = boundFunction(self.VV4l4D, m3uMode, title)
   VVmqZr = ("Show Full Path", self.VV8Lpc)
   FFh3ra(self, None, title=title, VVTikG=VVTikG, OKBtnFnc=OKBtnFnc, VVmqZr=VVmqZr, VViuu9=VViuu9)
  else:
   FF3mKe(self, 'No "m3u" files found.')
 def VV8Lpc(self, VVEOjrObj, url):
  FFxYUM(self, url, title="Full Path")
 def VV4l4D(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFapsE(menuInstance, boundFunction(self.VVw4yq, title, path))
   elif m3uMode == 1 : FFapsE(menuInstance, boundFunction(self.VVOlVe, title, path))
   else    : self.VVJA57(menuInstance, path)
 def VV9ybb(self, VVEOjrObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVEOjrObj.VVTikG):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVZumQ(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    pListF = "%sPlaylist_%s.txt" % (FFgLfR(CFG.exportedTablesPath.getValue()), FFJ142())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVEOjrObj.VVTikG)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFxYUM(self, txt, title=title)
   else:
    FF3mKe(self, "Could not obtain URLs from this file list !", title=title)
 def VVOlVe(self, title, path):
  if fileExists(path):
   txt = FFjNcO(path)
   totChan   = 0
   totLive   = 0
   totVod   = 0
   totSeries  = 0
   totUncat  = 0
   totVideo  = 0
   totAudio  = 0
   for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE):
    totChan += 1
    chName  = match.group(1).strip()
    fullUrl  = match.group(2).strip()
    urlPart1 = match.group(3)
    if urlPart1 : tUrl = urlPart1
    else  : tUrl = fullUrl
    tUrl = FFl9uW(tUrl).lower()
    chType, host, username, password, streamId, chName = CCn3vN.VVM1D4(tUrl)
    if   chType == "live" : totLive += 1
    elif chType == "movie" : totVod += 1
    elif chType == "series" : totSeries += 1
    else     : totUncat += 1
    aud_vid = CCn3vN.VVM1D4(tUrl, getAudVid=True)
    if   aud_vid == "vid" : totVideo += 1
    elif aud_vid == "aud" : totAudio += 1
   txt = ""
   txt += FFNe7q("File:\n", VV1Zj2)
   txt += "    %s\n"    % path
   txt += "\n"
   txt += FFNe7q("Channels:\n", VV1Zj2)
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFNe7q("Category:\n", VV1Zj2)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFNe7q("Content:\n", VV1Zj2)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
   FFxYUM(self, txt, title="M3U File Analysis")
  else:
   FF3mKe(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
 def VVPCEM(self, isBrowseServer):
  lines = FFwzkK('find / %s -iname "*playlist*" | grep -i ".txt"' % FFBQjd(1))
  if lines:
   lines.sort()
   VVTikG = []
   for line in lines:
    VVTikG.append((line, line))
   OKBtnFnc = boundFunction(self.VVKcwW, isBrowseServer)
   FFh3ra(self, None, title="Select Playlist File", VVTikG=VVTikG, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFhkqx(self, "( playlist.txt  or  playlists.txt )")
 def VVKcwW(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFapsE(menuInstance, boundFunction(self.VVVUGl, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVVUGl(self, fileMenuInstance, path, isBrowseServer):
  VVTikG = []
  lines = FFVFca(path)
  for line in lines:
   line = line.strip()
   span = iSearch(r"(http.+php.+username=.+password=.+)(?:[&]+)*", line, IGNORECASE)
   if span:
    VVTikG.append((span.group(1), span.group(1)))
   else:
    span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
    if span:
     host = FFgLfR(span.group(1).strip())
     user1 = span.group(2).strip()
     pass1 = span.group(3).strip()
     line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
     VVTikG.append((line, line))
  if VVTikG:
   if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVTikG)
   else    : title = "Convert to Bouquet"
   OKBtnFnc  = boundFunction(self.VVNNVP, isBrowseServer, title)
   VVr7QF  = ("Home Menu"  , FFHFZT)
   VVmqZr  = ("Show URL"  , self.VV9S6X)
   VViuu9   = ("Check & Filter" , boundFunction(self.VVzJM6, fileMenuInstance, path, isBrowseServer))
   FFh3ra(self, None, title=title, VVTikG=VVTikG, width=1200, OKBtnFnc=OKBtnFnc, VVr7QF=VVr7QF, VVmqZr=VVmqZr, VViuu9=VViuu9)
  else:
   FF3mKe(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV9S6X(self, VVEOjrObj, url):
  FFxYUM(self, url, title="URL")
 def VVNNVP(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFapsE(menuInstance, boundFunction(self.VVyXOb, title, url), title="Checking Server ...")
   else:
    FFAuNs(self, boundFunction(FFapsE, menuInstance, boundFunction(self.VVT6Qc, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVT6Qc(self, menuInstance, url):
  path, err = FFUSMT(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FF3mKe(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFjNcO(path)
    if '{"user_info":{"auth":0}}' in txt:
     FF3mKe(self, "Unauthorized", title=title)
     os.system(FFOaw3("rm -f '%s'" % path))
     return
   self.VVJA57(menuInstance, path)
 def VVhenB(self):
  curChName = self.VVTGDg.VV7rv1(1)
  curRefCode = self.VVTGDg.VV7rv1(4)
  curUrl  = self.VVTGDg.VV7rv1(5)
  FFK43o(self, "Loading Channels ...")
  tableRows = []
  lameDbChans = CCdz2s.VVc6H0(self, CCdz2s.VV2Z8v, VVpQw7=False, VVF6KR=False)
  if lameDbChans:
   curCh = curChName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCffqz.VVixJc(chName.lower(), curCh)
    if ratio > 50:
     tableRows.append((chName, FF0G5Z(sat), refCode.replace("_", ":")))
  FFK43o(self)
  title = "Share Reference with Satellite/C/T Channel"
  if tableRows:
   tableRows.sort(key=lambda x: x[0].lower())
   VVXJOe  = ("Share Sat/C/T Ref.", boundFunction(self.VVSsOf, title, curChName, curRefCode, curUrl) , [])
   header   = ("Name" , "Sat"  , "Reference" )
   widths   = (34  , 33  , 33   )
   FFw32s(self, None, title=title, header=header, VV26yB=tableRows, VVX78s=widths, VV3p9i=24, VVXJOe=VVXJOe, VVICrB="#0a00112B", VVMl7F="#0a001126", VV7My0="#0a001126", VV0ai5="#00000000")
  else:
   FF3mKe(self, "No similar names found !", title)
 def VVSsOf(self, newtitle, curChName, curRefCode, curUrl, VVTGDg, title, txt, colList):
  VVTGDg.cancel()
  newChName = colList[0]
  newRefCode = colList[2]
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  FFapsE(self.VVTGDg, boundFunction(self.VVNp1v, data, ques, newtitle))
 def VVNp1v(self, data, ques, title):
  FFAuNs(self.VVTGDg, boundFunction(FFapsE, self.VVTGDg, boundFunction(self.VV3XgL, data)), ques, title=title, VVSmS1=True)
 def VV3XgL(self, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVnKeU():
    txt = FFjNcO(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFWzzi()
    newRow = []
    for i in range(6):
     newRow.append(self.VVTGDg.VV7rv1(i))
    newRow[4] = newRefCode
    done = self.VVTGDg.VViRsV(newRow)
    FFX4bs(self, "Done", title=title)
   else:
    FF3mKe(self, "Not found in IPTV files !", title=title)
  else:
   FF3mKe(self, "Could not read channel info !", title=title)
 def VVzJM6(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, item):
  self.session.open(CCgXI4, barTheme=CCgXI4.VV2nUu
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVzSBn, urlMenuInstance)
      , VV6kEn = boundFunction(self.VVwh75, fileMenuInstance, path, isBrowseServer, urlMenuInstance))
 def VVzSBn(self, urlMenuInstance, progBarObj):
  progBarObj.VVbJ1q(len(urlMenuInstance.VVTikG))
  progBarObj.VVcLSJ = []
  for ndx, item in enumerate(urlMenuInstance.VVTikG):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV72tV(1)
   qUrl = self.VVNmFi(self.VVqKJS, item[0])
   txt, err = self.VVwyBK(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVTHaX(item, "auth") == "0":
       progBarObj.VVcLSJ.append(qUrl)
    except:
     pass
 def VVwh75(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, VVzE4w, VVcLSJ, threadCounter, threadTotal, threadErr):
  if VVzE4w:
   list = VVcLSJ
   title = "Authorized Servers"
   if list:
    totChk = len(urlMenuInstance.VVTikG)
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFJ142()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVPCEM(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFNe7q(str(totAuth), VVHsWS)
     txt += "%s\n\n%s"     %  (FFNe7q("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFxYUM(self, txt, title=title)
     urlMenuInstance.close()
     fileMenuInstance.close()
    else:
     FFX4bs(self, "All URLs are authorized.", title=title)
   else:
    FF3mKe(self, "No authorized URL found !", title=title)
 def VVJA57(self, parentInstant, path):
  files = CCn3vN.VVGyWB(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCn3vN.VV4Xe0(parentInstant, path, exitCurWin)
 @staticmethod
 def VV4Xe0(SELF, path, exitCurWin):
  FFAuNs(SELF, boundFunction(FFapsE, SELF, boundFunction(CCn3vN.VVHeze, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVHeze(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FF3mKe(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCn3vN.VVUE1j(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVGXYV + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVGXYV + bFileName):
     bName = tmpBName
     break
  txt = FFjNcO(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVGXYV + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FF28bV(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFPDjv(bFileName)
   FFWzzi()
   FFX4bs(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FF3mKe(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVwyBK(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVgi1R(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVM1D4(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVNmFi(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVgi1R(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVqKJS   : return "%s"            % url
  elif mode == self.VV4r1C   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVjM2y   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVedmu  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVUacs : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVE9Bj   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVrgSU    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVVRAk  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVqC3Z  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVwuoh  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VViM51 : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVj8kD   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVTHaX(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF2W46(int(val))
    elif is_base64 : val = FFjf4U(val)
    elif isToHHMMSS : val = FFwz6F(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVw4yq(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVZumQ(line)
     if qUrl:
      break
   if qUrl : self.VVyXOb(title, qUrl)
   else : FF3mKe(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF3mKe(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVox6b_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVYYLH()
  if qUrl:
   host, mac, isPortalUrl = self.VVSPw6(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVox6b(self, host, mac)
    else   : FF3mKe(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFapsE(self, boundFunction(self.VVyXOb, title, qUrl), title="Checking Server ...")
  else:
   FF3mKe(self, "Error in current channel URL !", title=title)
 def VVYYLH(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  qUrl = self.VVZumQ(decodedUrl)
  return qUrl, iptvRef
 def VVZumQ(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVyXOb(self, title, url):
  self.VVW5jGData = {}
  qUrl = self.VVNmFi(self.VVqKJS, url)
  txt, err = self.VVwyBK(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVW5jGData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVW5jGData["username"    ] = self.VVTHaX(item, "username"        )
    self.VVW5jGData["password"    ] = self.VVTHaX(item, "password"        )
    self.VVW5jGData["message"    ] = self.VVTHaX(item, "message"        )
    self.VVW5jGData["auth"     ] = self.VVTHaX(item, "auth"         )
    self.VVW5jGData["status"    ] = self.VVTHaX(item, "status"        )
    self.VVW5jGData["exp_date"    ] = self.VVTHaX(item, "exp_date"    , isDate=True )
    self.VVW5jGData["is_trial"    ] = self.VVTHaX(item, "is_trial"        )
    self.VVW5jGData["active_cons"   ] = self.VVTHaX(item, "active_cons"       )
    self.VVW5jGData["created_at"   ] = self.VVTHaX(item, "created_at"   , isDate=True )
    self.VVW5jGData["max_connections"  ] = self.VVTHaX(item, "max_connections"      )
    self.VVW5jGData["allowed_output_formats"] = self.VVTHaX(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVW5jGData[key] = lst
    item = tDict["server_info"]
    self.VVW5jGData["url"    ] = self.VVTHaX(item, "url"        )
    self.VVW5jGData["port"    ] = self.VVTHaX(item, "port"        )
    self.VVW5jGData["https_port"  ] = self.VVTHaX(item, "https_port"      )
    self.VVW5jGData["server_protocol" ] = self.VVTHaX(item, "server_protocol"     )
    self.VVW5jGData["rtmp_port"   ] = self.VVTHaX(item, "rtmp_port"       )
    self.VVW5jGData["timezone"   ] = self.VVTHaX(item, "timezone"       )
    self.VVW5jGData["timestamp_now"  ] = self.VVTHaX(item, "timestamp_now"  , isDate=True )
    self.VVW5jGData["time_now"   ] = self.VVTHaX(item, "time_now"       )
    VVTikG = []
    VVTikG.append(("Live"     , "serverLive"  ))
    VVTikG.append(("VOD"     , "serverVod"  ))
    VVTikG.append(("Series (Seasons)"  , "serverSeries" ))
    VVTikG.append(VVK4l8)
    VVTikG.append(("User/Server Info." , "serverInfo"  ))
    OKBtnFnc  = self.VVW5jGOptions
    VVr7QF  = ("Home Menu", FFHFZT)
    FFh3ra(self, None, title="IPTV Server Resources", VVTikG=VVTikG, OKBtnFnc=OKBtnFnc, VVr7QF=VVr7QF)
   else:
    err = "Could not get data from server !"
  if err:
   FF3mKe(self, err, title=title)
  FFK43o(self)
 def VVW5jGOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "serverLive" : FFapsE(menuInstance, boundFunction(self.VV2ifD, self.VV4r1C , title=title), title=wTxt)
   elif ref == "serverVod"  : FFapsE(menuInstance, boundFunction(self.VV2ifD, self.VVjM2y , title=title), title=wTxt)
   elif ref == "serverSeries" : FFapsE(menuInstance, boundFunction(self.VV2ifD, self.VVedmu, title=title), title=wTxt)
   elif ref == "serverInfo" : FFapsE(menuInstance, boundFunction(self.VVlaIE          , title=title), title=wTxt)
 def VVlaIE(self, title):
  rows = []
  for key, val in self.VVW5jGData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVgrOj = ("Home Menu", FFHFZT, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFw32s(self, None, title=title, header=header, VV26yB=rows, VVX78s=widths, VV3p9i=26, VVgrOj=VVgrOj, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000", searchCol=2)
 def VVqMMA(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCRrkz()
    if mode == self.VVE9Bj:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVTHaX(item, "num"         )
      name     = self.VVTHaX(item, "name"        )
      stream_id    = self.VVTHaX(item, "stream_id"       )
      stream_icon    = self.VVTHaX(item, "stream_icon"       )
      epg_channel_id   = self.VVTHaX(item, "epg_channel_id"      )
      added     = self.VVTHaX(item, "added"    , isDate=True )
      is_adult    = self.VVTHaX(item, "is_adult"       )
      category_id    = self.VVTHaX(item, "category_id"       )
      name = processChanName.VVyPV7(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVrgSU:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVTHaX(item, "num"         )
      name    = self.VVTHaX(item, "name"        )
      stream_id   = self.VVTHaX(item, "stream_id"       )
      stream_icon   = self.VVTHaX(item, "stream_icon"       )
      added    = self.VVTHaX(item, "added"    , isDate=True )
      is_adult   = self.VVTHaX(item, "is_adult"       )
      category_id   = self.VVTHaX(item, "category_id"       )
      container_extension = self.VVTHaX(item, "container_extension"     ) or "mp4"
      name = processChanName.VVyPV7(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVVRAk:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVTHaX(item, "num"        )
      name    = self.VVTHaX(item, "name"       )
      series_id   = self.VVTHaX(item, "series_id"      )
      cover    = self.VVTHaX(item, "cover"       )
      genre    = self.VVTHaX(item, "genre"       )
      episode_run_time = self.VVTHaX(item, "episode_run_time"    )
      category_id   = self.VVTHaX(item, "category_id"      )
      container_extension = self.VVTHaX(item, "container_extension"    ) or "mp4"
      name = processChanName.VVyPV7(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VV2ifD(self, mode, title):
  qUrl = self.VVNmFi(mode, self.VVW5jGData["playListURL"])
  txt, err = self.VVwyBK(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    hideAdult = CFG.hideIptvServerAdultWords.getValue()
    tDict = jLoads(txt)
    if tDict:
     processChanName = CCRrkz()
     for item in tDict:
      category_id  = self.VVTHaX(item, "category_id"  )
      category_name = self.VVTHaX(item, "category_name" )
      parent_id  = self.VVTHaX(item, "parent_id"  )
      category_name = processChanName.VVh48F(category_name)
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   FF3mKe(self, err, title=title)
  if err:
   FF3mKe(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   if   mode == self.VV4r1C  : okTitle, fName, fMode = "Show Channels", "Live" , self.VVE9Bj
   elif mode == self.VVjM2y  : okTitle, fName, fMode = "Show Channels", "VOD" , self.VVrgSU
   elif mode == self.VVedmu : okTitle, fName, fMode = "Show List"  , "Series" , self.VVVRAk
   VVtuOR = ("Find %s Name" % fName , boundFunction(self.VVk9wb, fMode) , [])
   VVXJOe  = (okTitle     , boundFunction(self.VV4HJ7, mode) , [])
   VVgrOj = ("Home Menu"    , FFHFZT          , [])
   header   = ("Category", "catID" , "ParentID" )
   widths   = (100   , 0  , 0    )
   FFw32s(self, None, title=title, header=header, VV26yB=list, VVX78s=widths, VV3p9i=30, VVgrOj=VVgrOj, VVtuOR=VVtuOR, VVXJOe=VVXJOe, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000")
  else:
   FF3mKe(self, "No list from server !", title=title)
  FFK43o(self)
 def VV4HJ7(self, mode, VVTGDg, title, txt, colList):
  title = colList[1]
  FFapsE(VVTGDg, boundFunction(self.VVQ9DW, mode, VVTGDg, title, txt, colList), title="Downloading ...")
 def VVQ9DW(self, mode, VVTGDg, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title  = bName
  if   mode == self.VV4r1C  : mode, title = self.VVE9Bj  , "Live = %s" % title
  elif mode == self.VVjM2y  : mode, title = self.VVrgSU  , "VOD = %s" % title
  elif mode == self.VVedmu : mode, title = self.VVVRAk , "Series = %s" % title
  qUrl  = self.VVNmFi(mode, self.VVW5jGData["playListURL"], catID)
  txt, err = self.VVwyBK(qUrl)
  list  = []
  if not err and mode in (self.VVE9Bj, self.VVrgSU, self.VVVRAk):
   list, err = self.VVqMMA(mode, txt)
  if err:
   FF3mKe(self, err, title=title)
  elif list:
   VVgrOj  = ("Home Menu"   , FFHFZT            , [])
   if mode == self.VVE9Bj:
    VVXJOe  = ("Play"    , boundFunction(self.VVX5Go, mode)    , [])
    VVcsOf = (""     , boundFunction(self.VVUYyg, mode)    , [])
    VVpp6N = ("Download PIcons" , boundFunction(self.VVxeEM, mode)    , [])
    VVtuOR = ("Add ALL to Bouquet" , boundFunction(self.VVS1Wk, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVfMBx  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVrgSU:
    VVXJOe  = ("Play"    , boundFunction(self.VVX5Go, mode)    , [])
    VVcsOf = (""     , boundFunction(self.VVUYyg, mode)    , [])
    VVpp6N = ("Download PIcons" , boundFunction(self.VVxeEM, mode)    , [])
    VVtuOR = ("Add ALL to Bouquet" , boundFunction(self.VVS1Wk, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVfMBx  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVVRAk:
    VVXJOe  = ("Show Seasons", boundFunction(self.VVbCQl, mode) , [])
    VVcsOf = ("", boundFunction(self.VVcyxr, mode)  , [])
    VVpp6N = None
    VVtuOR = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVfMBx  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFw32s(self, None, title=title, header=header, VV26yB=list, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=26, VVXJOe=VVXJOe, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVcsOf=VVcsOf, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000", VVRCjQ=True, searchCol=1)
  else:
   FF3mKe(self, "No Channels found !", title=title)
  FFK43o(self)
 def VVbCQl(self, mode, VVTGDg, title, txt, colList):
  title = colList[1]
  FFapsE(VVTGDg, boundFunction(self.VVX4ar, mode, VVTGDg, title, txt, colList), title="Downloading ...")
 def VVX4ar(self, mode, VVTGDg, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVNmFi(self.VVUacs, self.VVW5jGData["playListURL"], series_id)
  txt, err = self.VVwyBK(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVTHaX(tDict["info"], "name"   )
      category_id = self.VVTHaX(tDict["info"], "category_id" )
      icon  = self.VVTHaX(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVTHaX(EP, "id"     )
        episode_num   = self.VVTHaX(EP, "episode_num"   )
        epTitle    = self.VVTHaX(EP, "title"     )
        container_extension = self.VVTHaX(EP, "container_extension" )
        seasonNum   = self.VVTHaX(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF3mKe(self, err, title=title)
  elif list:
   VVgrOj = ("Home Menu"   , FFHFZT            , [])
   VVpp6N = ("Download PIcons" , boundFunction(self.VVxeEM , mode)   , [])
   VVtuOR = ("Add ALL to Bouquet" , boundFunction(self.VVS1Wk, mode, title) , [])
   VVcsOf = (""     , boundFunction(self.VVUYyg, mode)    , [])
   VVXJOe  = ("Play"    , boundFunction(self.VVX5Go, mode)    , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVfMBx  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFw32s(self, None, title=title, header=header, VV26yB=list, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=26, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVXJOe=VVXJOe, VVcsOf=VVcsOf, VVtuOR=VVtuOR, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000")
  else:
   FF3mKe(self, "No Channels found !", title=title)
  FFK43o(self)
 def VVk9wb(self, mode, VVTGDg, title, txt, colList):
  VVTikG = []
  VVTikG.append(("Keyboard" , "manualEntry"))
  VVTikG.append(("From Filter" , "fromFilter"))
  FFh3ra(self, boundFunction(self.VVQleH, VVTGDg, mode), title="Input Type", VVTikG=VVTikG, width=400)
 def VVQleH(self, VVTGDg, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFCkFz(self, boundFunction(self.VVSE7h, VVTGDg, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC1HZL(self)
    filterObj.VVgngQ(boundFunction(self.VVSE7h, VVTGDg, mode))
 def VVSE7h(self, VVTGDg, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCRrkz()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVy8h1(words):
     FF3mKe(self, 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.', title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCgXI4, barTheme=CCgXI4.VV2nUu
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVkxUu, VVTGDg, mode, title, words, toFind, asPrefix, processChanName)
         , VV6kEn = boundFunction(self.VVHTvu, mode, toFind, title))
   else:
    FF3mKe(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVkxUu(self, VVTGDg, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVbJ1q(VVTGDg.VVOSYq())
  progBarObj.VVcLSJ = []
  for row in VVTGDg.VVaz4B():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV72tV(1)
   progBarObj.VVHhjE("Found %d ... %s" % (len(progBarObj.VVcLSJ), catName))
   qUrl  = self.VVNmFi(mode, self.VVW5jGData["playListURL"], catID)
   txt, err = self.VVwyBK(qUrl)
   if not err:
    tList, err = self.VVqMMA(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVyPV7(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVE9Bj:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVcLSJ.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVrgSU:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVcLSJ.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVVRAk:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVcLSJ.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVHTvu(self, mode, toFind, title, VVzE4w, VVcLSJ, threadCounter, threadTotal, threadErr):
  if VVcLSJ:
   if mode == self.VVE9Bj or mode == self.VVrgSU:
    bName   = CCn3vN.VVUE1j(toFind)
    VVXJOe  = ("Play"   , boundFunction(self.VVX5Go, mode), [])
    VVtuOR = ("Add ALL to Bouquet" , boundFunction(self.VVS1Wk, mode, bName) , [])
    VVpp6N = ("Download PIcons" , boundFunction(self.VVxeEM, mode)    , [])
   elif mode == self.VVVRAk:
    VVXJOe  = ("Show Seasons", boundFunction(self.VVbCQl, mode), [])
    VVtuOR = None
    VVpp6N = None
   VVcsOf = (""     , boundFunction(self.VVUYyg, mode)    , [])
   VVgrOj = ("Home Menu"   , FFHFZT            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVfMBx  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVTGDg = FFw32s(self, None, title="Find (%s)" % toFind, header=header, VV26yB=VVcLSJ, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=26, VVXJOe=VVXJOe, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVcsOf=VVcsOf, VVICrB="#0a00292B", VVMl7F="#0a002126", VV7My0="#0a002126", VV0ai5="#00000000", VVRCjQ=True, searchCol=1)
   if not VVzE4w:
    FFK43o(VVTGDg, "Stopped" , 1000)
  else:
   if VVzE4w:
    FF3mKe(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVeGN8(self, mode, colList):
  if mode == self.VVE9Bj:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVrgSU:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFIQzg(chName)
  url = self.VVW5jGData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVgi1R(url)
  refCode = self.VV7cO2(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVUYyg(self, mode, VVTGDg, title, txt, colList):
  FFapsE(VVTGDg, boundFunction(self.VVGP1I, mode, VVTGDg, title, txt, colList))
 def VVGP1I(self, mode, VVTGDg, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVeGN8(mode, colList)
  FFWqlt(self, fncMode=CCw0CQ.VVYO8w, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVcyxr(self, mode, VVTGDg, title, txt, colList):
  FFapsE(VVTGDg, boundFunction(self.VVVxck, mode, VVTGDg, title, txt, colList))
 def VVVxck(self, mode, VVTGDg, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  += "Duration\t: %s" % Dur
  FFWqlt(self, fncMode=CCw0CQ.VVhGMO, chName=name, text=txt, picUrl=Cover)
 def VVS1Wk(self, mode, bName, VVTGDg, title, txt, colList):
  FFapsE(VVTGDg, boundFunction(self.VVsNxP, mode, bName, VVTGDg, title, txt, colList), title="Adding Channels ...")
 def VVsNxP(self, mode, bName, VVTGDg, title, txt, colList):
  url = self.VVW5jGData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVgi1R(url)
  bNameFile = CCn3vN.VVUE1j(bName)
  num  = 0
  path = VVGXYV + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVGXYV + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVTGDg.VVaz4B():
    chName, chUrl, picUrl, refCode = self.VVeGN8(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFPDjv(os.path.basename(path))
  self.VVYSxf(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVxeEM(self, mode, VVTGDg, title, txt, colList):
  if os.system(FFOaw3("which ffmpeg")) == 0:
   self.session.open(CCgXI4, barTheme=CCgXI4.VVBdj0
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVpzrm, VVTGDg, mode)
       , VV6kEn = self.VVHP3x)
  else:
   FFAuNs(self, self.VVZ5J8, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVHP3x(self, VVzE4w, VVcLSJ, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVcLSJ["proces"], VVcLSJ["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVcLSJ["ok"], VVcLSJ["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVcLSJ["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVcLSJ["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVcLSJ["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVcLSJ["path"]
  if not VVzE4w  : color = "#11402000"
  elif VVcLSJ["err"]: color = "#11201000"
  else     : color = None
  if VVcLSJ["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVcLSJ["err"], txt)
  title = "PIcons Download Result"
  if not VVzE4w:
   title += "  (cancelled)"
  FFxYUM(self, txt, title=title, VV7My0=color)
 def VVpzrm(self, VVTGDg, mode, progBarObj):
  totRows = VVTGDg.VVOSYq()
  progBarObj.VVbJ1q(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCffqz.VV9UQ6()
  progBarObj.VVcLSJ = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVTGDg.VVaz4B():
    if progBarObj.isCancelled:
     break
    progBarObj.VVcLSJ["proces"] += 1
    progBarObj.VV72tV(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVQzeG(mode, row)
     refCode = CCn3vN.VV7cO2(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVeGN8(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVcLSJ["attempt"] += 1
      path, err = FFUSMT(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVcLSJ["ok"] += 1
       if FFVDP7(path) > 0:
        cmd = ""
        if not mode == CCn3vN.VVE9Bj:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFOaw3("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVcLSJ["size0"] += 1
        os.system(FFOaw3("rm -f '%s'" % path))
      elif err:
       progBarObj.VVcLSJ["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVcLSJ["err"] = err.title()
        break
     else:
      progBarObj.VVcLSJ["exist"] += 1
    else:
     progBarObj.VVcLSJ["badURL"] += 1
  except:
   pass
 def VVZ5J8(self):
  cmd = FFl4YE(VVgO7i, "ffmpeg")
  if cmd : FFH6Oq(self, cmd, title="Installing FFmpeg")
  else : FFYXW3(self)
 @staticmethod
 def VV7cO2(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCn3vN.VVrP6l(catID, MAX_4b)
  TSID = CCn3vN.VVrP6l(chNum, MAX_4b)
  ONID = CCn3vN.VVrP6l(chNum, MAX_4b)
  NS  = CCn3vN.VVrP6l(stID, MAX_8b)
  int(catID) if catID.isdigit() else ""
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVrP6l(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVUE1j(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CCAExk(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVNI96  = 0
  self.VVdWh0 = 1
  self.VVYBHh  = 2
  VVTikG = []
  VVTikG.append(("Find All (from filter)"    , "VVpy5c" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Find All"        , "VVGzbj"    ))
  VVTikG.append(("Find TV"        , "VVQTpj"    ))
  VVTikG.append(("Find Radio"       , "VVTzLu"   ))
  if self.VVUrKz():
   VVTikG.append(VVK4l8)
   VVTikG.append(("Hide Channel: %s" % self.servName , "VVi9C3"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Zap History"       , "VVwy0j"    ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("PIcons Tools"       , "PIconsTools"     ))
  VVTikG.append(("Channels Tools"      , "ChannelsTools"    ))
  FFxmEB(self, VVTikG=VVTikG, title=title)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
  if self.isFindMode:
   self.VVvTMm(self.VVvvtX())
 def VV0W2R(self):
  global VVajY4
  VVajY4 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVGzbj"    : self.VVGzbj()
   elif item == "VVpy5c" : self.VVpy5c()
   elif item == "VVQTpj"    : self.VVQTpj()
   elif item == "VVTzLu"   : self.VVTzLu()
   elif item == "VVi9C3"   : self.VVi9C3()
   elif item == "VVwy0j"    : self.VVwy0j()
   elif item == "PIconsTools"     : self.session.open(CCffqz)
   elif item == "ChannelsTools"    : self.session.open(CCdz2s)
 def VVQTpj(self) : self.VVvTMm(self.VVNI96)
 def VVTzLu(self) : self.VVvTMm(self.VVdWh0)
 def VVGzbj(self) : self.VVvTMm(self.VVYBHh)
 def VVvTMm(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFCkFz(self, boundFunction(self.VVuUHi, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVpy5c(self):
  filterObj = CC1HZL(self)
  filterObj.VVgngQ(self.VVNbEO)
 def VVNbEO(self, item):
  self.VVuUHi(self.VVYBHh, item)
 def VVUrKz(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFZjOO(self.refCode)        : return False
  return True
 def VVuUHi(self, mode, VV64Gu):
  FFapsE(self, boundFunction(self.VVXAj3, mode, VV64Gu), title="Searching ...")
 def VVXAj3(self, mode, VV64Gu):
  if VV64Gu:
   self.findTxt = VV64Gu
   if   mode == self.VVNI96  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVdWh0 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV64Gu)
   if len(title) > 55:
    title = title[:55] + ".."
   VVOZgd = self.VVb90L(VV64Gu, servTypes)
   if self.isFindMode or mode == self.VVYBHh:
    VVOZgd += self.VVCSqv(VV64Gu)
   if VVOZgd:
    VVOZgd.sort(key=lambda x: x[0].lower())
    VVCWuB = self.VVocB0
    VVXJOe  = ("Zap"   , self.VVW3Gx    , [])
    VVpp6N = ("Current Service", self.VV0b8P , [])
    VVtuOR = ("Options"  , self.VVk4vk , [])
    VVcsOf = (""    , self.VVrTSG , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVfMBx  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFw32s(self, None, title=title, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=25, VVXJOe=VVXJOe, VVCWuB=VVCWuB, VVpp6N=VVpp6N, VVtuOR=VVtuOR, VVcsOf=VVcsOf)
   else:
    self.VVvTMm(self.VVvvtX())
    FFX4bs(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVb90L(self, VV64Gu, servTypes):
  VVg2N7  = eServiceCenter.getInstance()
  VVfYIV   = '%s ORDER BY name' % servTypes
  VVNFQc   = eServiceReference(VVfYIV)
  VVJ4FZ = VVg2N7.list(VVNFQc)
  if VVJ4FZ: VV26yB = VVJ4FZ.getContent("CN", False)
  else     : VV26yB = None
  VVOZgd = []
  if VV26yB:
   VV6JRk, VVHm2S = FFPeve()
   tp   = CCVmtR()
   words, asPrefix = CC1HZL.VVxEg1(VV64Gu)
   colorYellow  = CCBNh7.VV9kke(VVL19M)
   colorWhite  = CCBNh7.VV9kke(VVhsuV)
   for s in VV26yB:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFALDD(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV6JRk:
        STYPE = VVHm2S[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV38cC(refCode)
       if not "-S" in syst:
        sat = syst
       VVOZgd.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVOZgd
 def VVCSqv(self, VV64Gu):
  VV64Gu = VV64Gu.lower()
  VVKPBD = FFZh4R()
  VVOZgd = []
  colorYellow  = CCBNh7.VV9kke(VVL19M)
  colorWhite  = CCBNh7.VV9kke(VVhsuV)
  if VVKPBD:
   for b in VVKPBD:
    VV8SWr  = b[0]
    VVOKX1  = b[1].toString()
    VVQOTK = eServiceReference(VVOKX1)
    VVYcTd = FF0qTN(VVQOTK)
    for service in VVYcTd:
     refCode  = service[0]
     if FFZjOO(refCode):
      servName = service[1]
      if VV64Gu in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV64Gu), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVOZgd.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVOZgd
 def VVvvtX(self):
  VVUF3D = InfoBar.instance
  if VVUF3D:
   VVzpXX = VVUF3D.servicelist
   if VVzpXX:
    return VVzpXX.mode == 1
  return self.VVYBHh
 def VVocB0(self, VVTGDg):
  self.close()
  VVTGDg.cancel()
 def VVW3Gx(self, VVTGDg, title, txt, colList):
  FFHTCm(VVTGDg, colList[2], VVqXf4=False, checkParentalControl=True)
 def VV0b8P(self, VVTGDg, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(VVTGDg)
  if refCode:
   VVTGDg.VVf6dd(2, FFrgTu(refCode, iptvRef, chName), True)
 def VVk4vk(self, VVTGDg, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CC8ndA(self, VVTGDg, 2)
  mSel.VVMS4z(servName, refCode)
 def VVrTSG(self, VVTGDg, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFWqlt(self, fncMode=CCw0CQ.VVkKHz, refCode=refCode, chName=chName, text=txt)
 def VVi9C3(self):
  FFAuNs(self, self.VVFFJI, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVFFJI(self):
  ret = FFPEzU(self.refCode, True)
  if ret:
   self.VVmcQS()
   self.close()
  else:
   FFK43o(self, "Cannot change state" , 1000)
 def VVmcQS(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVSO90()
  except:
   self.VVS9BU()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      self.session.nav.playService(serviceRef)
 def VVIJ6T(self):
  VVUF3D = InfoBar.instance
  if VVUF3D:
   VVzpXX = VVUF3D.servicelist
   if VVzpXX:
    VVzpXX.setMode()
 def VVSO90(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVUF3D = InfoBar.instance
   if VVUF3D:
    VVzpXX = VVUF3D.servicelist
    if VVzpXX:
     hList = VVzpXX.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVzpXX.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVzpXX.history  = newList
       VVzpXX.history_pos = pos
 def VVS9BU(self):
  VVUF3D = InfoBar.instance
  if VVUF3D:
   VVzpXX = VVUF3D.servicelist
   if VVzpXX:
    VVzpXX.history  = []
    VVzpXX.history_pos = 0
 def VVwy0j(self):
  VVUF3D = InfoBar.instance
  VVOZgd = []
  if VVUF3D:
   VVzpXX = VVUF3D.servicelist
   if VVzpXX:
    VV6JRk, VVHm2S = FFPeve()
    for chParams in VVzpXX.history:
     refCode = chParams[-1].toString()
     chName = FFpRQc(refCode)
     isIptv = FFZjOO(refCode)
     if isIptv: sat = "-"
     else  : sat = FFALDD(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV6JRk:
       STYPE = VVHm2S[sTypeInt]
     VVOZgd.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVOZgd:
   VVXJOe  = ("Zap"   , self.VVBPe6   , [])
   VVtuOR = ("Clear History" , self.VVMRmI   , [])
   VVcsOf = (""    , self.VVa6iVFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVfMBx  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFw32s(self, None, title=title, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=23, VVXJOe=VVXJOe, VVtuOR=VVtuOR, VVcsOf=VVcsOf)
  else:
   FFX4bs(self, "Not found", title=title)
 def VVBPe6(self, VVTGDg, title, txt, colList):
  FFHTCm(VVTGDg, colList[3], VVqXf4=False, checkParentalControl=True)
 def VVMRmI(self, VVTGDg, title, txt, colList):
  FFAuNs(self, boundFunction(self.VVZNSM, VVTGDg), "Clear Zap History ?")
 def VVZNSM(self, VVTGDg):
  self.VVS9BU()
  VVTGDg.cancel()
 def VVa6iVFromZapHistory(self, VVTGDg, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFWqlt(self, fncMode=CCw0CQ.VVj5qP, refCode=refCode, chName=chName, text=txt)
class CCffqz(Screen):
 VVYOzw   = 0
 VVnX1G  = 1
 VVzIFc  = 2
 VV36Td  = 3
 VVmJcu  = 4
 VV7kSA  = 5
 VVOQTF  = 6
 VVnur6  = 7
 VVN8yP = 8
 VVapc4 = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFOSVY(VVXRTM, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFxmEB(self, self.Title)
  FFHCfw(self["keyRed"] , "OK = Zap")
  FFHCfw(self["keyGreen"] , "Current Service")
  FFHCfw(self["keyYellow"], "Page Options")
  FFHCfw(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCffqz.VV9UQ6()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV26yB    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV1mVZ        ,
   "green"   : self.VVWD9W       ,
   "yellow"  : self.VV9oEf        ,
   "blue"   : self.VVpvZb        ,
   "menu"   : self.VVSctb        ,
   "info"   : self.VVa6iV         ,
   "up"   : self.VVJMNA          ,
   "down"   : self.VVXMes         ,
   "left"   : self.VVQsXz         ,
   "right"   : self.VVPA2J         ,
   "pageUp"  : boundFunction(self.VVNCHI, True) ,
   "chanUp"  : boundFunction(self.VVNCHI, True) ,
   "pageDown"  : boundFunction(self.VVNCHI, False) ,
   "chanDown"  : boundFunction(self.VVNCHI, False) ,
   "next"   : self.VVqPMs        ,
   "last"   : self.VVbcnF         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFZ8sT(self)
  FFGQmF(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFapsE(self, boundFunction(self.VVRmZT, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVSctb(self):
  if not self.isBusy:
   VVTikG = []
   VVTikG.append(("Statistics"           , "VVXxGO"    ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("Suggest PIcons for Current Channel"     , "VVhyoy"   ))
   VVTikG.append(("Set to Current Channel (copy file)"     , "VV2PbC_file"  ))
   VVTikG.append(("Set to Current Channel (as SymLink)"     , "VV2PbC_link"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append(CCffqz.VVIoqV())
   VVTikG.append(VVK4l8)
   VVTikG.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVYbqs"  ))
   VVTikG.append(VVK4l8)
   VVTikG += CCffqz.VViQ1L()
   VVTikG.append(VVK4l8)
   VVTikG.append(("RCU Keys Help"          , "VVGk8L"    ))
   FFh3ra(self, self.VVElZw, title=self.Title, VVTikG=VVTikG)
 def VVElZw(self, item=None):
  if item is not None:
   if   item == "VVXxGO"     : self.VVXxGO()
   elif item == "VVhyoy"    : FFapsE(self, self.VVhyoy, clearMsg=False)
   elif item == "VV2PbC_file"   : self.VV2PbC(0)
   elif item == "VV2PbC_link"   : self.VV2PbC(1)
   elif item == "VVLUXb_file"  : self.VVLUXb(0)
   elif item == "VVLUXb_link"  : self.VVLUXb(1)
   elif item == "VVAIkq"   : self.VVAIkq()
   elif item == "VVYXTt"  : self.VVYXTt()
   elif item == "VVF9Hd"   : self.VVF9Hd()
   elif item == "VVYbqs"   : self.VVYbqs()
   elif item == "VVIv8F"   : CCffqz.VVIv8F(self)
   elif item == "VVj9Ch"   : CCffqz.VVj9Ch(self)
   elif item == "findPiconBrokenSymLinks"  : CCffqz.VVLaoE(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCffqz.VVLaoE(self, False)
   elif item == "VVGk8L"      : self.VVGk8L()
 def VV9oEf(self):
  if not self.isBusy:
   VVTikG = []
   VVTikG.append(("Go to First PIcon"  , "VVt61K"  ))
   VVTikG.append(("Go to Last PIcon"   , "VVLUGq"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("Sort by Channel Name"     , "sortByChan" ))
   VVTikG.append(("Sort by File Name"  , "sortByFile" ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("Find from File List .." , "VVLv31" ))
   FFh3ra(self, self.VV57m0, title=self.Title, VVTikG=VVTikG)
 def VV57m0(self, item=None):
  if item is not None:
   if   item == "VVt61K"   : self.VVt61K()
   elif item == "VVLUGq"   : self.VVLUGq()
   elif item == "sortByChan"  : self.VVheW8(2)
   elif item == "sortByFile"  : self.VVheW8(0)
   elif item == "VVLv31"  : self.VVLv31()
 def VVGk8L(self):
  FF0qcI(self, VVuSNJ + "_help_picons", "PIcons Manager (Keys Help)")
 def VVJMNA(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVLUGq()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV1y0r()
 def VVXMes(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVt61K()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV1y0r()
 def VVQsXz(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVLUGq()
  else:
   self.curCol -= 1
   self.VV1y0r()
 def VVPA2J(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVt61K()
  else:
   self.curCol += 1
   self.VV1y0r()
 def VVbcnF(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV1y0r(True)
 def VVqPMs(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV1y0r(True)
 def VVt61K(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV1y0r(True)
 def VVLUGq(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV1y0r(True)
 def VVLv31(self):
  VVTikG = []
  for item in self.VV26yB:
   VVTikG.append((item[0], item[0]))
  FFh3ra(self, self.VVnhls, title='PIcons ".png" Files', VVTikG=VVTikG, VVxlCv=True)
 def VVnhls(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVL1r2(ndx)
 def VV1mVZ(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVReX6()
   if refCode:
    FFHTCm(self, refCode)
    self.VV6Y9R()
    self.VVbmbU()
 def VVNCHI(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VV6Y9R()
   self.VVbmbU()
  except:
   pass
 def VVWD9W(self):
  if self["keyGreen"].getVisible():
   self.VVL1r2(self.curChanIndex)
 def VVL1r2(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV1y0r(True)
  else:
   FFK43o(self, "Not found", 1000)
 def VVheW8(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFapsE(self, boundFunction(self.VVRmZT, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV2PbC(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVReX6()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVTikG = []
     VVTikG.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVTikG.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFh3ra(self, boundFunction(self.VVCgMU, mode, curChF, selPiconF), VVTikG=VVTikG, title="Current Channel PIcon (already exists)")
    else:
     self.VVCgMU(mode, curChF, selPiconF, "overwrite")
   else:
    FF3mKe(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF3mKe(self, "Could not read current channel info. !", title=title)
 def VVCgMU(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFapsE(self, boundFunction(self.VVRmZT, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVLUXb(self, mode):
  pass
 def VVAIkq(self):
  pass
 def VVYXTt(self):
  pass
 def VVF9Hd(self):
  pass
 def VVYbqs(self):
  lines = FFwzkK("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFAuNs(self, boundFunction(self.VVMOT0, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVSmS1=True)
  else:
   FFX4bs(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVMOT0(self, fList):
  os.system(FFOaw3("find -L '%s' -type l -delete" % self.pPath))
  FFX4bs(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVa6iV(self):
  FFapsE(self, self.VVGdhL)
 def VVGdhL(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVReX6()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFNe7q("PIcon Directory:\n", VV1Zj2)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFxCl6(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFxCl6(path)
   txt += FFNe7q("PIcon File:\n", VV1Zj2)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFwzkK(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFNe7q("Found %d SymLink%s to this file from:\n" % (tot, s), VV1Zj2)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFpRQc(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFNe7q(tChName, VVHsWS)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFNe7q(line, VVPZsu), tChName)
    txt += "\n"
   if chName:
    txt += FFNe7q("Channel:\n", VV1Zj2)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFNe7q(chName, VVHsWS)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFNe7q("Remarks:\n", VV1Zj2)
    txt += "  %s\n" % FFNe7q("Unused", VVix4Z)
  else:
   txt = "No info found"
  FFWqlt(self, fncMode=CCw0CQ.VVnWEm, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVReX6(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV26yB[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF0G5Z(sat)
  return fName, refCode, chName, sat, inDB
 def VV6Y9R(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV26yB):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVbmbU(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVReX6()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFNe7q("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV1Zj2))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVReX6()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFNe7q(self.curChanName, VVL19M)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVXxGO(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV26yB:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFVfkZ("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFxYUM(self, txt, title=self.Title)
 def VVpvZb(self):
  if not self.isBusy:
   VVTikG = []
   VVTikG.append(("All"         , "all"   ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("Used by Channels"      , "used"  ))
   VVTikG.append(("Unused PIcons"      , "unused"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("PIcons Files"       , "pFiles"  ))
   VVTikG.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVTikG.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVTikG.append(VVK4l8)
   VVTikG.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVTikG.append(VVK4l8)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFZIIQ(val)
      VVTikG.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC1HZL(self)
   filterObj.VVPwlG(VVTikG, self.nsList, self.VVeDG0)
 def VVeDG0(self, item=None):
  if item is not None:
   self.VVZHzJ(item)
 def VVZHzJ(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVYOzw   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVnX1G   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVzIFc  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VV36Td  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVmJcu  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV7kSA  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVOQTF   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVnur6   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVN8yP , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV7kSA:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFwzkK("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFK43o(self, "Not found", 1000)
     return
   elif mode == self.VVapc4:
    return
   else:
    words, asPrefix = CC1HZL.VVxEg1(words)
   if not words and mode in (self.VVnur6, self.VVN8yP):
    FFK43o(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFapsE(self, boundFunction(self.VVRmZT, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVhyoy(self):
  FFK43o(self, "Loading Channels ...")
  lameDbChans = CCdz2s.VVc6H0(self, CCdz2s.VV2Z8v, VVpQw7=False, VVF6KR=False)
  files = []
  words = []
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCffqz.VVixJc(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCffqz.VV6Qio(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       words.append(f.replace(".png", ""))
  if words:
   FFapsE(self, boundFunction(self.VVRmZT, mode=self.VVapc4, words=words), title="Filtering ...", clearMsg=False)
  else:
   FFK43o(self, "Not found", 1000)
 def VVRmZT(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVLxDG(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCdz2s.VVc6H0(self, CCdz2s.VV2Z8v, VVpQw7=False, VVF6KR=False)
  iptvRefList = self.VVuD2Y()
  tList = []
  for fName, fType in CCffqz.VVCu9O(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVYOzw:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVnX1G  and chName         : isAdd = True
   elif mode == self.VVzIFc and not chName        : isAdd = True
   elif mode == self.VV36Td  and fType == 0        : isAdd = True
   elif mode == self.VVmJcu  and fType == 1        : isAdd = True
   elif mode == self.VV7kSA  and fName in words       : isAdd = True
   elif mode == self.VVapc4 and fName in words       : isAdd = True
   elif mode == self.VVOQTF  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVnur6  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVN8yP:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV26yB   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFK43o(self)
  else:
   self.isBusy = False
   FFK43o(self, "Not found", 1000)
   return
  self.VV26yB.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV6Y9R()
  self.totalPIcons = len(self.VV26yB)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV1y0r(True)
 def VVLxDG(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCffqz.VVCu9O(self.pPath):
    if fName:
     return True
   if isFirstTime : FF3mKe(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFK43o(self, "Not found", 1000)
  else:
   FF3mKe(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVuD2Y(self):
  VVOZgd = {}
  files  = CCn3vN.VVGyWB(self)
  if files:
   for path in files:
    txt = FFjNcO(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVOZgd[refCode] = item[1]
  return VVOZgd
 def VV1y0r(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV5bNr = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV5bNr: self.curPage = VV5bNr
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVJnBG()
  if self.curPage == VV5bNr:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVbmbU()
  filName, refCode, chName, sat, inDB = self.VVReX6()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVJnBG(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV26yB[ndx]
   fName = self.VV26yB[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFNe7q(chName, VVHsWS))
    else : lbl.setText("-")
   except:
    lbl.setText(FFNe7q(chName, VVa59G))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVixJc(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVIoqV():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVIv8F"   )
 @staticmethod
 def VViQ1L():
  VVTikG = []
  VVTikG.append(("Find SymLinks (to PIcon Directory)"   , "VVj9Ch"   ))
  VVTikG.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVTikG.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVTikG
 @staticmethod
 def VVIv8F(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(SELF)
  png, path = CCffqz.VVJhKA(refCode)
  if path : CCffqz.VVn75S(SELF, png, path)
  else : FF3mKe(SELF, "No PIcon found for current channel in:\n\n%s" % CCffqz.VV9UQ6())
 @staticmethod
 def VVj9Ch(SELF):
  if VVL19M:
   sed1 = FFXkoO("->", VVL19M)
   sed2 = FFXkoO("picon", VVix4Z)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVa59G, VVhsuV)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF0iLg(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFBQjd(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVLaoE(SELF, isPIcon):
  sed1 = FFXkoO("->", VVa59G)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFXkoO("picon", VVix4Z)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF0iLg(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFBQjd(), grep, sed1, sed2))
 @staticmethod
 def VVCu9O(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV9UQ6():
  path = CFG.PIconsPath.getValue()
  return FFgLfR(path)
 @staticmethod
 def VVJhKA(refCode, chName=None):
  if FFZjOO(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFXGZ9(refCode)
  allPath, fName, refCodeFile, pList = CCffqz.VV6Qio(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVn75S(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFXkoO("%s%s" % (dest, png), VVHsWS))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFXkoO(errTxt, VVao2g))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFOfw9(SELF, cmd)
 @staticmethod
 def VV6Qio(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCffqz.VV9UQ6()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFIQzg(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCtdm8():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVWUE6  = None
  self.VVMJpn = ""
  self.VVH0W0  = noService
  self.VVeeXU = 0
  self.VVovyH  = noService
  self.VVBqJ0 = 0
  self.VVzUgw  = "-"
  self.VVrUoC = 0
  self.VVNpR5  = ""
  self.serviceName = ""
 def VVV9k3(self, service):
  if service:
   feinfo = service.frontendInfo()
   if feinfo:
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVWUE6 = frontEndStatus
     self.VVNoVl()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVNoVl(self):
  if self.VVWUE6:
   val = self.VVWUE6.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVMJpn = "%3.02f dB" % (val / 100.0)
   else         : self.VVMJpn = ""
   val = self.VVWUE6.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVeeXU = int(val)
   self.VVH0W0  = "%d%%" % val
   val = self.VVWUE6.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVBqJ0 = int(val)
   self.VVovyH  = "%d%%" % val
   val = self.VVWUE6.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVzUgw  = "%d" % val
   val = int(val * 100 / 500)
   self.VVrUoC = min(500, val)
   val = self.VVWUE6.get("tuner_locked", 0)
   if val == 1 : self.VVNpR5 = "Locked"
   else  : self.VVNpR5 = "Not locked"
 def VVgVPl(self)   : return self.VVMJpn
 def VVwLmu(self)   : return self.VVH0W0
 def VVpxYb(self)  : return self.VVeeXU
 def VVLind(self)   : return self.VVovyH
 def VV2Fbv(self)  : return self.VVBqJ0
 def VVVwOZ(self)   : return self.VVzUgw
 def VVTEaq(self)  : return self.VVrUoC
 def VV0pM4(self)   : return self.VVNpR5
 def VV9Aom(self) : return self.serviceName
class CCVmtR():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVWI96(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFBWm8(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV0Yz3(self.ORPOS  , mod=1   )
      self.sat2  = self.VV0Yz3(self.ORPOS  , mod=2   )
      self.freq  = self.VV0Yz3(self.FREQ  , mod=3   )
      self.sr   = self.VV0Yz3(self.SR   , mod=4   )
      self.inv  = self.VV0Yz3(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV0Yz3(self.POL  , self.D_POL )
      self.fec  = self.VV0Yz3(self.FEC  , self.D_FEC )
      self.syst  = self.VV0Yz3(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV0Yz3("modulation" , self.D_MOD )
       self.rolof = self.VV0Yz3("rolloff"  , self.D_ROLOF )
       self.pil = self.VV0Yz3("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV0Yz3("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV0Yz3("pls_code"  )
       self.iStId = self.VV0Yz3("is_id"   )
       self.t2PlId = self.VV0Yz3("t2mi_plp_id" )
       self.t2PId = self.VV0Yz3("t2mi_pid"  )
 def VV0Yz3(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFZIIQ(val)
  elif mod == 2   : return FFCltT(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVnmOb(self, refCode):
  txt = ""
  self.VVWI96(refCode)
  if self.data:
   def VVuxnk(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVuxnk("System"   , self.syst)
    txt += VVuxnk("Satellite"  , self.sat2)
    txt += VVuxnk("Frequency"  , self.freq)
    txt += VVuxnk("Inversion"  , self.inv)
    txt += VVuxnk("Symbol Rate"  , self.sr)
    txt += VVuxnk("Polarization" , self.pol)
    txt += VVuxnk("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVuxnk("Modulation" , self.mod)
     txt += VVuxnk("Roll-Off" , self.rolof)
     txt += VVuxnk("Pilot"  , self.pil)
     txt += VVuxnk("Input Stream", self.iStId)
     txt += VVuxnk("T2MI PLP ID" , self.t2PlId)
     txt += VVuxnk("T2MI PID" , self.t2PId)
     txt += VVuxnk("PLS Mode" , self.plsMod)
     txt += VVuxnk("PLS Code" , self.plsCod)
   else:
    txt += VVuxnk("System"   , self.txMedia)
    txt += VVuxnk("Frequency"  , self.freq)
  return txt, self.namespace
 def VV1r4N(self, refCode):
  txt = "Transpoder : ?"
  self.VVWI96(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV1Zj2 + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VV38cC(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFBWm8(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV0Yz3(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV0Yz3(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV0Yz3(self.SYST, self.D_SYS_S)
     freq = self.VV0Yz3(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV0Yz3(self.POL , self.D_POL)
      fec = self.VV0Yz3(self.FEC , self.D_FEC)
      sr = self.VV0Yz3(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVTv7n(self, refCode):
  self.data = None
  self.VVWI96(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCrET4():
 def __init__(self, VVOlM8, path, VV6kEn=None, curRowNum=-1):
  self.VVOlM8  = VVOlM8
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VV6kEn  = VV6kEn
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFOaw3("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVrHnB(curRowNum)
  else:
   FF3mKe(self.VVOlM8, "Error while preparing edit!")
 def VVrHnB(self, curRowNum):
  VVOZgd = self.VVbe17()
  VVgrOj = None #("Delete Line" , self.deleteLine  , [])
  VVpp6N = ("Save Changes" , self.VVcc4V   , [])
  VVXJOe  = ("Edit Line"  , self.VVRwBZ    , [])
  VVwxMC = ("Line Options" , self.VVMdXC   , [])
  VVPfEQ = (""    , self.VVzcdA , [])
  VVCWuB = self.VVbud1
  VVvEKu  = self.VVPWhI
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVfMBx  = (CENTER  , LEFT  )
  VVTGDg = FFw32s(self.VVOlM8, None, title=self.Title, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=24, VVgrOj=VVgrOj, VVpp6N=VVpp6N, VVXJOe=VVXJOe, VVwxMC=VVwxMC, VVCWuB=VVCWuB, VVvEKu=VVvEKu, VVPfEQ=VVPfEQ, VVRCjQ=True
    , VVICrB   = "#11001111"
    , VVMl7F   = "#11001111"
    , VV7My0   = "#11001111"
    , VV0ai5  = "#05333333"
    , VVovon  = "#00222222"
    , VVZHY2  = "#11331133"
    )
  VVTGDg.VVy0NS(curRowNum)
 def VVMdXC(self, VVTGDg, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVTGDg.VVpsIe()
  VVTikG = []
  VVTikG.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVTikG.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VV3WDb"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVKt69:
   VVTikG.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(  ("Delete Line"         , "deleteLine"   ))
  FFh3ra(self.VVOlM8, boundFunction(self.VVSRRI, VVTGDg, lineNum), VVTikG=VVTikG, title="Line Options")
 def VVSRRI(self, VVTGDg, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVnRRU("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVTGDg)
   elif item == "VV3WDb"  : self.VV3WDb(VVTGDg, lineNum)
   elif item == "copyToClipboard"  : self.VVzNJ8(VVTGDg, lineNum)
   elif item == "pasteFromClipboard" : self.VVsApk(VVTGDg, lineNum)
   elif item == "deleteLine"   : self.VVnRRU("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVTGDg)
 def VVPWhI(self, VVTGDg):
  VVTGDg.VVcIAU()
 def VVzcdA(self, VVTGDg, title, txt, colList):
  if   self.insertMode == 1: VVTGDg.VVDd5Q()
  elif self.insertMode == 2: VVTGDg.VVu6Hb()
  self.insertMode = 0
 def VV3WDb(self, VVTGDg, lineNum):
  if lineNum == VVTGDg.VVpsIe():
   self.insertMode = 1
   self.VVnRRU("echo '' >> '%s'" % self.tmpFile, VVTGDg)
  else:
   self.insertMode = 2
   self.VVnRRU("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVTGDg)
 def VVzNJ8(self, VVTGDg, lineNum):
  global VVKt69
  VVKt69 = FFVfkZ("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVTGDg.VVstuD("Copied to clipboard")
 def VVcc4V(self, VVTGDg, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFOaw3("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFOaw3("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVTGDg.VVstuD("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVTGDg.VVcIAU()
    else:
     FF3mKe(self.VVOlM8, "Cannot save file!")
   else:
    FF3mKe(self.VVOlM8, "Cannot create backup copy of original file!")
 def VVbud1(self, VVTGDg):
  if self.fileChanged:
   FFAuNs(self.VVOlM8, boundFunction(self.VV5jng, VVTGDg), "Cancel changes ?")
  else:
   finalOK = os.system(FFOaw3("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VV5jng(VVTGDg)
 def VV5jng(self, VVTGDg):
  VVTGDg.cancel()
  os.system(FFOaw3("rm -f '%s'" % self.tmpFile))
  if self.VV6kEn:
   self.VV6kEn(self.fileSaved)
 def VVRwBZ(self, VVTGDg, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVhsuV + "ORIGINAL TEXT:\n" + VVPZsu + lineTxt
  FFCkFz(self.VVOlM8, boundFunction(self.VVhTwI, lineNum, VVTGDg), title="File Line", defaultText=lineTxt, message=message)
 def VVhTwI(self, lineNum, VVTGDg, VVD55x):
  if not VVD55x is None:
   if VVTGDg.VVpsIe() <= 1:
    self.VVnRRU("echo %s > '%s'" % (VVD55x, self.tmpFile), VVTGDg)
   else:
    self.VVKHrC(VVTGDg, lineNum, VVD55x)
 def VVsApk(self, VVTGDg, lineNum):
  if lineNum == VVTGDg.VVpsIe() and VVTGDg.VVpsIe() == 1:
   self.VVnRRU("echo %s >> '%s'" % (VVKt69, self.tmpFile), VVTGDg)
  else:
   self.VVKHrC(VVTGDg, lineNum, VVKt69)
 def VVKHrC(self, VVTGDg, lineNum, newTxt):
  VVTGDg.VVWdWk("Saving ...")
  lines = FFVFca(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVTGDg.VVH12h()
  VVOZgd = self.VVbe17()
  VVTGDg.VV8OPy(VVOZgd)
 def VVnRRU(self, cmd, VVTGDg):
  tCons = CCtZBs()
  tCons.ePopen(cmd, boundFunction(self.VVZ3w7, VVTGDg))
  self.fileChanged = True
  VVTGDg.VVH12h()
 def VVZ3w7(self, VVTGDg, result, retval):
  VVOZgd = self.VVbe17()
  VVTGDg.VV8OPy(VVOZgd)
 def VVbe17(self):
  if fileExists(self.tmpFile):
   lines = FFVFca(self.tmpFile)
   VVOZgd = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVOZgd.append((str(ndx), line.strip()))
   if not VVOZgd:
    VVOZgd.append((str(1), ""))
   return VVOZgd
  else:
   FFhkqx(self.VVOlM8, self.tmpFile)
class CC1HZL():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVTikG   = []
  self.satList   = []
 def VVgngQ(self, VV6kEn):
  self.VVTikG = []
  VVTikG, VVkria = self.VV11xh(False, True)
  if VVTikG:
   self.VVTikG += VVTikG
   self.VVQdap(VV6kEn, VVkria)
 def VV5npx(self, mode, VVTGDg, satCol, VV6kEn):
  VVTGDg.VVWdWk("Loading Filters ...")
  self.VVTikG = []
  self.VVTikG.append(("All Services" , "all"))
  if mode == 1:
   self.VVTikG.append(VVK4l8)
   self.VVTikG.append(("Parental Control", "parentalControl"))
   self.VVTikG.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVTikG.append(VVK4l8)
   self.VVTikG.append(("Selected Transponder"   , "selectedTP" ))
   self.VVTikG.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVIpbg(VVTGDg, satCol)
  VVTikG, VVkria = self.VV11xh(True, False)
  if VVTikG:
   VVTikG.insert(0, VVK4l8)
   self.VVTikG += VVTikG
  VVTGDg.VVqfpI()
  self.VVQdap(VV6kEn, VVkria)
 def VVPwlG(self, VVTikG, sats, VV6kEn):
  self.VVTikG = VVTikG
  VVTikG, VVkria = self.VV11xh(True, False)
  if VVTikG:
   self.VVTikG.append(VVK4l8)
   self.VVTikG += VVTikG
  self.VVQdap(VV6kEn, VVkria)
 def VVwutn(self, VVTikG, sats, VV6kEn):
  self.VVTikG = VVTikG
  VVTikG, VVkria = self.VV11xh(True, False)
  if VVTikG:
   self.VVTikG.append(VVK4l8)
   self.VVTikG += VVTikG
  self.VVQdap(VV6kEn, VVkria)
 def VVQdap(self, VV6kEn, VVkria):
  VVmqZr = ("Edit Filter", boundFunction(self.VVRni3, VVkria))
  VViuu9  = ("Filter Help", boundFunction(self.VVwiRA, VVkria))
  FFh3ra(self.callingSELF, boundFunction(self.VV7gz5, VV6kEn), VVTikG=self.VVTikG, title="Select Filter", VVmqZr=VVmqZr, VViuu9=VViuu9)
 def VV7gz5(self, VV6kEn, item):
  if item:
   VV6kEn(item)
 def VVRni3(self, VVkria, VVEOjrObj, sel):
  if fileExists(VVkria) : CCrET4(self.callingSELF, VVkria, VV6kEn=None)
  else       : FFhkqx(self.callingSELF, VVkria)
  VVEOjrObj.cancel()
 def VVwiRA(self, VVkria, VVEOjrObj, sel):
  FF0qcI(self.callingSELF, VVuSNJ + "_help_service_filter", "Service Filter")
 def VVIpbg(self, VVTGDg, satColNum):
  if not self.satList:
   satList = VVTGDg.VVKseX(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF0G5Z(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVK4l8)
  if self.VVTikG:
   self.VVTikG += self.satList
 def VV11xh(self, addTag, VVU7ut):
  FFoKMu()
  fileName  = "ajpanel_services_filter"
  VVkria = VVCWNQ + fileName
  VVTikG  = []
  if not fileExists(VVkria):
   os.system(FFOaw3("cp -f '%s' '%s'" % (VVuSNJ + fileName, VVkria)))
  fileFound = False
  if fileExists(VVkria):
   fileFound = True
   lines = FFVFca(VVkria)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVTikG.append((line, "__w__" + line))
       else  : VVTikG.append((line, line))
  if VVU7ut:
   if   not fileFound : FFhkqx(self.callingSELF , VVkria)
   elif not VVTikG : FFYdcr(self.callingSELF , VVkria)
  return VVTikG, VVkria
 @staticmethod
 def VVxEg1(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CC8ndA():
 def __init__(self, callingSELF, VVTGDg, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVTGDg = VVTGDg
  self.refCodeColNum = refCodeColNum
  self.VVTikG = []
  iMulSel = self.VVTGDg.VVSHYA()
  if iMulSel : self.VVTikG.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVTikG.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVTGDg.VVZtAS()
  self.VVTikG.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVTikG.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVTikG.append(VVK4l8)
 def VVMS4z(self, servName, refCode):
  tot = self.VVTGDg.VVZtAS()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVTikG.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVc5aI_multi" ))
  else    : self.VVTikG.append( ("Add to Bouquet : %s"      % servName , "VVc5aI_one" ))
  self.VV9d7V(servName, refCode)
 def VVaQlH(self, servName, refCode, pcState, hidState):
  self.VVTikG = []
  if pcState == "No" : self.VVTikG.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVTikG.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVTikG.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVTikG.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VV9d7V(servName, refCode)
 def VV9d7V(self, servName, refCode):
  FFh3ra(self.callingSELF, boundFunction(self.VVKjy5, servName, refCode), title="Options", VVTikG=self.VVTikG)
 def VVKjy5(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVTGDg.VVpGmr(True)
   elif item == "MultSelDisab"    : self.VVTGDg.VVpGmr(False)
   elif item == "selectAll"    : self.VVTGDg.VVOztk()
   elif item == "unselectAll"    : self.VVTGDg.VVd1k8()
   elif item == "parentalControl_add"  : self.callingSELF.VVZF7q(self.VVTGDg, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVZF7q(self.VVTGDg, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVKiQr(self.VVTGDg, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVKiQr(self.VVTGDg, refCode, False)
   elif item == "VVc5aI_multi" : self.VVc5aI(refCode, True)
   elif item == "VVc5aI_one" : self.VVc5aI(refCode, False)
 def VVc5aI(self, refCode, isMulti):
  bouquets = FFZh4R()
  if bouquets:
   VVTikG = []
   for item in bouquets:
    VVTikG.append((item[0], item[1].toString()))
   VVmqZr = ("Create New", boundFunction(self.VV9rtt, refCode, isMulti))
   FFh3ra(self.callingSELF, boundFunction(self.VVNA2r, refCode, isMulti), VVTikG=VVTikG, title="Add to Bouquet", VVmqZr=VVmqZr, VVxlCv=True, VV5vXM=True)
  else:
   FFAuNs(self.callingSELF, boundFunction(self.VVDVij, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVNA2r(self, refCode, isMulti, bName=None):
  if bName:
   FFapsE(self.VVTGDg, boundFunction(self.VVKwyA, refCode, isMulti, bName), title="Adding Channels ...")
 def VVKwyA(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VV8McB(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVUF3D = InfoBar.instance
    if VVUF3D:
     VVzpXX = VVUF3D.servicelist
     if VVzpXX:
      mutableList = VVzpXX.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVTGDg.VVqfpI()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFX4bs(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF3mKe(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VV8McB(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVTGDg.VV47o3(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VV9rtt(self, refCode, isMulti, VVEOjrObj, path):
  self.VVDVij(refCode, isMulti)
 def VVDVij(self, refCode, isMulti):
  FFCkFz(self.callingSELF, boundFunction(self.VVwkkc, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVwkkc(self, refCode, isMulti, name):
  if name:
   FFapsE(self.VVTGDg, boundFunction(self.VV18mF, refCode, isMulti, name), title="Adding Channels ...")
 def VV18mF(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VV8McB(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVUF3D = InfoBar.instance
    if VVUF3D:
     VVzpXX = VVUF3D.servicelist
     if VVzpXX:
      try:
       VVzpXX.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVzpXX.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVTGDg.VVqfpI()
   title = "Add to Bouquet"
   if allOK: FFX4bs(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF3mKe(self.callingSELF, "Nothing added!", title=title)
class CCjNtp(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVhKBL, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFxmEB(self)
  FFHCfw(self["keyRed"]  , "Exit")
  FFHCfw(self["keyGreen"]  , "Save")
  FFHCfw(self["keyYellow"] , "Refresh")
  FFHCfw(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVSH7n  ,
   "green"   : self.VV5Qm0 ,
   "yellow"  : self.VVMZL8  ,
   "blue"   : self.VVLa0o   ,
   "up"   : self.VVJMNA    ,
   "down"   : self.VVXMes   ,
   "left"   : self.VVQsXz   ,
   "right"   : self.VVPA2J   ,
   "cancel"  : self.VVSH7n
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVMZL8()
  self.VVwPOA()
  FFZ8sT(self)
 def VVSH7n(self) : self.close(True)
 def VVomM5(self) : self.close(False)
 def VVLa0o(self):
  self.session.openWithCallback(self.VVmGmF, boundFunction(CCYdhj))
 def VVmGmF(self, closeAll):
  if closeAll:
   self.close()
 def VVJMNA(self):
  self.VV64tj(1)
 def VVXMes(self):
  self.VV64tj(-1)
 def VVQsXz(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVwPOA()
 def VVPA2J(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVwPOA()
 def VV64tj(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVQBBY(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVQBBY(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVQBBY(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV2uqc(year)):
   days += 1 #29 days in a leap year February
  return days
 def VV2uqc(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVwPOA(self):
  for obj in self.list:
   FFGQmF(obj, "#11404040")
  FFGQmF(self.list[self.index], "#11ff8000")
 def VVMZL8(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VV5Qm0(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCtZBs()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVGUKe)
 def VVGUKe(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFX4bs(self, "Nothing returned from the system!")
  else:
   FFX4bs(self, str(result))
class CCYdhj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVbrPw, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFxmEB(self, addLabel=True)
  FFHCfw(self["keyRed"]  , "Exit")
  FFHCfw(self["keyGreen"]  , "Sync")
  FFHCfw(self["keyYellow"] , "Refresh")
  FFHCfw(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVSH7n   ,
   "green"   : self.VVvNkS  ,
   "yellow"  : self.VVm01K ,
   "blue"   : self.VVWgRG  ,
   "cancel"  : self.VVSH7n
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVXwXd()
  self.onShow.append(self.start)
 def start(self):
  FFk91F(self.refresh)
  FFZ8sT(self)
 def refresh(self):
  self.VVxuZb()
  self.VVfEPM(False)
 def VVSH7n(self)  : self.close(True)
 def VVWgRG(self) : self.close(False)
 def VVXwXd(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVxuZb(self):
  self.VVY9Qk()
  self.VVyKAX()
  self.VVglFQ()
  self.VV7ySU()
 def VVm01K(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVXwXd()
   self.VVxuZb()
   FFk91F(self.refresh)
 def VVvNkS(self):
  if len(self["keyGreen"].getText()) > 0:
   FFAuNs(self, self.VVSfUT, "Synchronize with Internet Date/Time ?")
 def VVSfUT(self):
  self.VVxuZb()
  FFk91F(boundFunction(self.VVfEPM, True))
 def VVY9Qk(self)  : self["keyRed"].show()
 def VVbcOC(self)  : self["keyGreen"].show()
 def VVHDet(self) : self["keyYellow"].show()
 def VV7wXk(self)  : self["keyBlue"].show()
 def VVyKAX(self)  : self["keyGreen"].hide()
 def VVglFQ(self) : self["keyYellow"].hide()
 def VV7ySU(self)  : self["keyBlue"].hide()
 def VVfEPM(self, sync):
  localTime = FFr8kC()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVfOWv(server)
   if epoch_time is not None:
    ntpTime = FF2W46(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCtZBs()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVGUKe, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVHDet()
  self.VV7wXk()
  if ok:
   self.VVbcOC()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVGUKe(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVfEPM(False)
  except:
   pass
 def VVfOWv(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFhnij():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCLehz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFOSVY(VVTTXm, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFxmEB(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFk91F(self.VVaEd5)
 def VVaEd5(self):
  if FFhnij(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFGQmF(self["myBody"], color)
   FFGQmF(self["myLabel"], color)
  except:
   pass
class CCtjVn(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFCHYw()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFOSVY(VVLk86, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCpj3Q(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCpj3Q(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCpj3Q(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCtdm8()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFxmEB(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVJMNA          ,
   "down"  : self.VVXMes         ,
   "left"  : self.VVQsXz         ,
   "right"  : self.VVPA2J         ,
   "info"  : self.VVmAEN        ,
   "epg"  : self.VVmAEN        ,
   "menu"  : self.VVGk8L         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVSiht, -1)  ,
   "next"  : boundFunction(self.VVSiht, 1)  ,
   "pageUp" : boundFunction(self.VVlMg3, True) ,
   "chanUp" : boundFunction(self.VVlMg3, True) ,
   "pageDown" : boundFunction(self.VVlMg3, False) ,
   "chanDown" : boundFunction(self.VVlMg3, False) ,
   "0"   : boundFunction(self.VVSiht, 0)  ,
   "1"   : boundFunction(self.VVVObi, pos=1) ,
   "2"   : boundFunction(self.VVVObi, pos=2) ,
   "3"   : boundFunction(self.VVVObi, pos=3) ,
   "4"   : boundFunction(self.VVVObi, pos=4) ,
   "5"   : boundFunction(self.VVVObi, pos=5) ,
   "6"   : boundFunction(self.VVVObi, pos=6) ,
   "7"   : boundFunction(self.VVVObi, pos=7) ,
   "8"   : boundFunction(self.VVVObi, pos=8) ,
   "9"   : boundFunction(self.VVVObi, pos=9) ,
  }, -1)
  self.onShown.append(self.VV6NQt)
  self.onClose.append(self.onExit)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self.sliderSNR.VVFnlg()
  self.sliderAGC.VVFnlg()
  self.sliderBER.VVFnlg(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVVObi()
  self.VV9krJInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9krJ)
  except:
   self.timer.callback.append(self.VV9krJ)
  self.timer.start(500, False)
 def VV9krJInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVV9k3(service)
  serviceName = self.tunerInfo.VV9Aom()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  tp = CCVmtR()
  txt = tp.VV1r4N(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VV9krJ(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVV9k3(service)
  self["mySNRdB"].setText(self.tunerInfo.VVgVPl())
  self["mySNR"].setText(self.tunerInfo.VVwLmu())
  self["myAGC"].setText(self.tunerInfo.VVLind())
  self["myBER"].setText(self.tunerInfo.VVVwOZ())
  self.sliderSNR.VVU1IO(self.tunerInfo.VVpxYb())
  self.sliderAGC.VVU1IO(self.tunerInfo.VV2Fbv())
  self.sliderBER.VVU1IO(self.tunerInfo.VVTEaq())
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
    if state and not state == "Tuned":
     FFK43o(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVmAEN(self):
  FFWqlt(self, fncMode=CCw0CQ.VVQbms)
 def VVGk8L(self):
  FF0qcI(self, VVuSNJ + "_help_signal", "Signal Monitor (Keys)")
 def VVJMNA(self)  : self.VVVObi(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVXMes(self) : self.VVVObi(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVQsXz(self) : self.VVVObi(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVPA2J(self) : self.VVVObi(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVVObi(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVSiht(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFFGcp(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVlMg3(self, isUp):
  FFK43o(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VV9krJInfo()
  except:
   pass
class CCpj3Q(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVFnlg(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFGQmF(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVuSNJ +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFGQmF(self.covObj, self.covColor)
   else:
    FFGQmF(self.covObj, "#00006688")
    self.isColormode = True
  self.VVU1IO(0)
 def VVU1IO(self, val):
  val  = FFFGcp(val, self.minN, self.maxN)
  width = int(FFfeLG(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFFGcp(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCgXI4(Screen):
 VV2nUu    = 0
 VVBdj0 = 1
 VVhtfw = 2
 def __init__(self, session, titlePrefix="Processing", fncToRun=None, VV6kEn=None, barTheme=VV2nUu):
  ratio = self.VVodbF(barTheme)
  self.skin, self.skinParam = FFOSVY(VVRMqr, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.fncToRun  = fncToRun
  self.VV6kEn = VV6kEn
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 1
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVcLSJ = None
  self.isUpdTitle  = False
  self.timer   = eTimer()
  self.myThread  = None
  FFxmEB(self, title="Processing ...")
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV6NQt)
  self.onClose.append(self.onExit)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self.VVxMXh()
  FFGQmF(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVXskX()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVXskX)
  except:
   self.timer.callback.append(self.VVXskX)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="download_PIcons", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVbJ1q(self, val):
  self.maxValue = val
  self.isUpdTitle = True
 def VVHhjE(self, title):
  self.isUpdTitle = False
  self["myTitle"].setText("  " + title + "  ")
 def VV72tV(self, addVal):
  self.counter += addVal
 def VV3pTu(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFK43o(self, "Cancelling ...")
  self.isCancelled = True
  if self.VV6kEn:
   self.VV6kEn(False, self.VVcLSJ, self.counter, self.maxValue, self.isError)
  self.close()
 def VVXskX(self):
  val  = self.counter
  val  = FFFGcp(self.counter, 0, self.maxValue)
  width = int(FFfeLG(val, 0, self.maxValue, 0, self.barWidth))
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
  if self.isUpdTitle:
   self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, val, self.maxValue))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VV6kEn and not self.isCancelled:
    self.VV6kEn(True, self.VVcLSJ, self.counter, self.maxValue, self.isError)
   self.close()
 def VVxMXh(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme == self.VVBdj0:
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVhtfw:
   pass
 def VVodbF(self, barTheme):
  if   barTheme == self.VVBdj0 : return 0.8
  elif barTheme == self.VVhtfw : return 1
  else              : return 1
class CCtZBs(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VV6kEn = {}
  self.commandRunning = False
  self.VV6C6C  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VV6kEn, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VV6kEn[name] = VV6kEn
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV6C6C:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VV4tTy, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVxMx9 , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VV4tTy, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVxMx9 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVxMx9(name, retval)
  return True
 def VV4tTy(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVxMx9(self, name, retval):
  if not self.VV6C6C:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VV6kEn[name]:
   self.VV6kEn[name](self.appResults[name], retval)
  del self.VV6kEn[name]
 def VVkbU7(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCE2bf(Screen):
 def __init__(self, session, title="", VVzSps=None, VVNbOh=False, VVaApu=False, VVzoe2=False, VVvHfg=False, VVtAKF=False, VVrzXH=False, VVLxmM=VVsweO, VV3dyz=None, VV5j3B=False, VVCdBh=None, VV0k69="", checkNetAccess=False, enableSaveRes=False):
  self.skin, self.skinParam = FFOSVY(VVnnJQ, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFxmEB(self, addScrollLabel=True)
  if not VV0k69:
   VV0k69 = "Processing ..."
  self["myLabel"].setText("   %s" % VV0k69)
  self.VVNbOh   = VVNbOh
  self.VVaApu   = VVaApu
  self.VVzoe2   = VVzoe2
  self.VVvHfg  = VVvHfg
  self.VVtAKF = VVtAKF
  self.VVrzXH = VVrzXH
  self.VVLxmM   = VVLxmM
  self.VV3dyz = VV3dyz
  self.VV5j3B  = VV5j3B
  self.VVCdBh  = VVCdBh
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCtZBs()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFXHTP()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVzSps, str):
   self.VVzSps = [VVzSps]
  else:
   self.VVzSps = VVzSps
  if self.VVzoe2 or self.VVvHfg:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVGWwg, VVGWwg)
   self.VVzSps.append("echo -e '\n%s\n' %s" % (restartNote, FFXkoO(restartNote, VVL19M)))
   if self.VVzoe2:
    self.VVzSps.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVzSps.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVtAKF:
   FFK43o(self, "Processing ...")
  self.onLayoutFinish.append(self.VVeYCl)
  self.onClose.append(self.VVfyEB)
 def VVeYCl(self):
  self["myLabel"].VVqvJx(enableSave=self.enableSaveRes)
  if self.VVNbOh:
   self["myLabel"].VVWwRD()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV2knT()
  else:
   self.VVOu5n()
 def VV2knT(self):
  if FFhnij():
   self["myLabel"].setText("Processing ...")
   self.VVOu5n()
  else:
   self["myLabel"].setText(FFNe7q("\n   No connection to internet!", VVix4Z))
 def VVOu5n(self):
  allOK = self.container.ePopen(self.VVzSps[0], self.VV332Q, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV332Q("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVrzXH or self.VVzoe2 or self.VVvHfg:
    self["myLabel"].setText(FFQpa3("STARTED", VVL19M) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVCdBh:
   colorWhite = CCBNh7.VV9kke(VVhsuV)
   color  = CCBNh7.VV9kke(self.VVCdBh[0])
   words  = self.VVCdBh[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVLxmM=self.VVLxmM)
 def VV332Q(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVzSps):
   allOK = self.container.ePopen(self.VVzSps[self.cmdNum], self.VV332Q, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV332Q("Cannot connect to Console!", -1)
  else:
   if self.VVtAKF and FFJJe1(self):
    FFK43o(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVrzXH:
    self["myLabel"].appendText("\n" + FFQpa3("FINISHED", VVL19M), self.VVLxmM)
   if self.VVNbOh or self.VVaApu:
    self["myLabel"].VVWwRD()
   if self.VV3dyz is not None:
    self.VV3dyz()
   if not retval and self.VV5j3B:
    self.VVfyEB()
 def VVfyEB(self):
  if self.container.VVkbU7():
   self.container.killAll()
class CCbDx6(Screen):
 def __init__(self, session, VVzSps=None, VVtAKF=False):
  self.skin, self.skinParam = FFOSVY(VVnnJQ, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVCWNQ + "ajpanel_terminal.history"
  self.customCommandsFile = VVCWNQ + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFVfkZ("pwd") or "/home/root"
  self.container   = CCtZBs()
  FFxmEB(self, addScrollLabel=True)
  FFHCfw(self["keyRed"] , "Stop Command")
  FFHCfw(self["keyGreen"] , "OK = History")
  FFHCfw(self["keyYellow"], "Menu = Custom Cmds")
  FFHCfw(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVKarp ,
   "red"  : self.VVmH3o   ,
   "cancel" : self.VVGi9M   ,
   "menu"  : self.VVdArA ,
   "last"  : self.VVqsDe  ,
   "next"  : self.VVqsDe  ,
   "1"   : self.VVqsDe  ,
   "2"   : self.VVqsDe  ,
   "3"   : self.VVqsDe  ,
   "4"   : self.VVqsDe  ,
   "5"   : self.VVqsDe  ,
   "6"   : self.VVqsDe  ,
   "7"   : self.VVqsDe  ,
   "8"   : self.VVqsDe  ,
   "9"   : self.VVqsDe  ,
   "0"   : self.VVqsDe
  })
  self.onLayoutFinish.append(self.VV6NQt)
  self.onClose.append(self.VVmH3o)
 def VV6NQt(self):
  self["myLabel"].VVqvJx(isResizable=False)
  FFGQmF(self["keyGreen"]  , self.skinParam["titleColor"])
  FFGQmF(self["keyYellow"] , self.skinParam["titleColor"])
  FFGQmF(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVPsGf(FFVfkZ("date"), 5)
  result = FFVfkZ("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVff1J()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVuSNJ + "LinuxCommands.lst"
   newTemplate = VVuSNJ + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFOaw3("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFOaw3("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVmH3o(self):
  if self.container.VVkbU7():
   self.container.killAll()
   self.VVPsGf("Process killed\n", 4)
   self.VVff1J()
 def VVGi9M(self):
  if self.container.VVkbU7():
   FFAuNs(self, self.close, "Terminate command and exit ?")
  else:
   self.close()
 def VVff1J(self):
  self.VVPsGf(self.prompt, 1)
  self["keyRed"].hide()
 def VVPsGf(self, txt, mode):
  if   mode == 1 : color = VVL19M
  elif mode == 2 : color = VV1Zj2
  elif mode == 3 : color = VVhsuV
  elif mode == 4 : color = VVix4Z
  elif mode == 5 : color = VVPZsu
  elif mode == 6 : color = VVleFh
  else   : color = VVhsuV
  try:
   self["myLabel"].appendText(FFNe7q(txt, color))
  except:
   pass
 def VVU7KA(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFNe7q(parts[0].strip(), VV1Zj2)
   right = FFNe7q("#" + parts[1].strip(), VVleFh)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVPsGf(txt, 2)
  lastLine = self.VV9T4e()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VViV6I(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VV332Q, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FF3mKe(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVPsGf(data, 3)
 def VV332Q(self, data, retval):
  if not retval == 0:
   self.VVPsGf("Exit Code : %d\n" % retval, 4)
  self.VVff1J()
 def VVKarp(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV9T4e() == "":
   self.VViV6I("cd /tmp")
   self.VViV6I("ls")
  VVOZgd = []
  if fileExists(self.commandHistoryFile):
   lines  = FFVFca(self.commandHistoryFile)
   c = 0
   for line in reversed(lines):
    line = line.strip()
    if line and not line.startswith("#"):
     c += 1
     VVOZgd.append((str(c), line))
   self.VV0GK7(VVOZgd, title, self.commandHistoryFile, isHistory=True)
  else:
   FFhkqx(self, self.commandHistoryFile, title=title)
 def VV9T4e(self):
  lastLine = FFVfkZ("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VViV6I(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVdArA(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFVFca(self.customCommandsFile)
   lastLineIsSep = False
   VVOZgd = []
   c = 0
   for line in lines:
    line = line.strip()
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVOZgd.append((str(c), line))
   self.VV0GK7(VVOZgd, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFhkqx(self, self.customCommandsFile, title=title)
 def VV0GK7(self, VVOZgd, title, filePath=None, isHistory=False):
  if VVOZgd:
   VV0ai5 = "#05333333"
   if isHistory: VVICrB = VVMl7F = VV7My0 = "#11000020"
   else  : VVICrB = VVMl7F = VV7My0 = "#06002020"
   VVXJOe     = ("Send"   , self.VVc3ms  , [])
   VVtuOR    = ("Modify & Send" , self.VVwxic  , [])
   if filePath : VVwxMC = ("Edit File"  , self.VVnZYp , [filePath])
   else  : VVwxMC = None
   header      = ("No."  , "Commands")
   widths      = (7   , 93   )
   VVfMBx     = (CENTER  , LEFT   )
   FFw32s(self, None, title=title, header=header, VV26yB=VVOZgd, VVfMBx=VVfMBx, VVX78s=widths, VV3p9i=22, VVXJOe=VVXJOe, VVtuOR=VVtuOR, VVwxMC=VVwxMC, VVRCjQ=True
     , VVICrB   = VVICrB
     , VVMl7F   = VVMl7F
     , VV7My0   = VV7My0
     , VVf7yk  = "#05ffff00"
     , VV0ai5  = VV0ai5
    )
  else:
   FFYdcr(self, filePath, title=title)
 def VVc3ms(self, VVTGDg, title, txt, colList):
  cmd = colList[1].strip()
  VVTGDg.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVPsGf("\n%s\n" % cmd, 6)
   self.VVPsGf(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVPsGf(cmd, 2)
    self.VVPsGf("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVPsGf(ch, 0)
    self.VVPsGf("\nor\n", 4)
    self.VVPsGf("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVff1J()
   else:
    self.VVU7KA(cmd)
 def VVwxic(self, VVTGDg, title, txt, colList):
  cmd = colList[1]
  self.VVVLkm(VVTGDg, cmd)
 def VVnZYp(self, VVTGDg, filePath):
  if fileExists(filePath):
   CCrET4(self, filePath, VV6kEn=boundFunction(self.VVjRUq))
   VVTGDg.cancel()
  else:
   FFhkqx(self, filePath)
 def VVjRUq(self, fileChanged):
  FFk91F(self.VVdArA)
 def VVqsDe(self):
  self.VVVLkm(None, self.lastCommand)
 def VVVLkm(self, VVTGDg, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFCkFz(self, boundFunction(self.VVPWaL, VVTGDg), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVPWaL(self, VVTGDg, cmd):
  if cmd and len(cmd) > 0:
   self.VVU7KA(cmd)
   if VVTGDg:
    VVTGDg.cancel()
class CCghfF(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVD55x="", VVKTjd=False, VVYhlR=False, isTrimEnds=True):
  self.skin, self.skinParam = FFOSVY(VVEbX0, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFxmEB(self, title, addLabel=True)
  FFHCfw(self["keyRed"] , "Up/Down = Change")
  FFHCfw(self["keyGreen"] , "Overwrite")
  FFHCfw(self["keyYellow"], "Pick Key Map")
  FFHCfw(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVYhlR   = VVYhlR
  self.VVKTjd  = VVKTjd
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVD55x, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVtUwI      ,
   "green"    : self.VVjHcF    ,
   "yellow"   : self.VVcfdc      ,
   "blue"    : self.VVpcOT     ,
   "menu"    : self.VVvPYP     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VV9aQD, True) ,
   "down"    : boundFunction(self.VV9aQD, False) ,
   "left"    : self.VVcMsP       ,
   "right"    : self.VVIC92       ,
   "home"    : self.VVpsXx       ,
   "end"    : self.VVZkGQ       ,
   "next"    : self.VVTcYY      ,
   "last"    : self.VVPbgm      ,
   "deleteForward"  : self.VVTcYY      ,
   "deleteBackward" : self.VVPbgm      ,
   "tab"    : self.VVkQWH       ,
   "toggleOverwrite" : self.VVjHcF    ,
   "0"     : self.VV2zE2     ,
   "1"     : self.VV2zE2     ,
   "2"     : self.VV2zE2     ,
   "3"     : self.VV2zE2     ,
   "4"     : self.VV2zE2     ,
   "5"     : self.VV2zE2     ,
   "6"     : self.VV2zE2     ,
   "7"     : self.VV2zE2     ,
   "8"     : self.VV2zE2     ,
   "9"     : self.VV2zE2
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVXCVk()
  self.onShown.append(self.VV6NQt)
  self.onClose.append(self.onExit)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self["myLabel"].setText(self.message)
  self.VV6PYJ()
  if self.VVKTjd : self.VVjHcF()
  else    : self.VVwxjm()
  FFZ8sT(self)
  FFGQmF(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVja5N)
  except:
   self.timer.callback.append(self.VVja5N)
 def onExit(self):
  self.timer.stop()
 def VVtUwI(self):
  self.VVG9ga()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVG9ga()
  self.close(None)
 def VVvPYP(self):
  VVTikG = []
  VVTikG.append(("Home"         , "home"    ))
  VVTikG.append(("End"         , "end"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Clear All"       , "clearAll"   ))
  VVTikG.append(("Clear To Home"      , "clearToHome"   ))
  VVTikG.append(("Clear To End"       , "clearToEnd"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVKt69:
   VVTikG.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("To Capital Letters"     , "toCapital"   ))
  VVTikG.append(("To Small Letters"      , "toSmall"    ))
  FFh3ra(self, self.VVGkh7, title="Edit Options", VVTikG=VVTikG)
 def VVGkh7(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVpsXx()
   elif item == "end"     : self.VVZkGQ()
   elif item == "clearAll"    : self.VVX78d()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVpsXx()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVKt69
    VVKt69 = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVKt69)
    self.VVpsXx()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVja5N(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVjHcF(self):
  self["myInput"].toggleOverwrite()
  self.VVwxjm()
 def VVcfdc(self):
  self.session.openWithCallback(self.VVJHdT, boundFunction(CCnM9r, mode=self.charMode, VVYhlR=self.VVYhlR))
 def VVJHdT(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VV6PYJ()
 def VVwxjm(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVXCVk(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVG9ga(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVApdB(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVcMsP(self)     : self.VVAy69(self["myInput"].left)
 def VVIC92(self)     : self.VVAy69(self["myInput"].right)
 def VVTcYY(self)     : self.VVAy69(self["myInput"].delete)
 def VVpsXx(self)     : self.VVAy69(self["myInput"].home)
 def VVZkGQ(self)     : self.VVAy69(self["myInput"].end)
 def VVPbgm(self)    : self.VVAy69(self["myInput"].deleteBackward)
 def VVkQWH(self)     : self.VVAy69(self["myInput"].tab)
 def VVX78d(self)     : self["myInput"].setText("")
 def VVAy69(self, fnc):
  fnc()
  self.VVja5N()
 def VV2zE2(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVApdB(newChar, overwrite)
   self.VVGlgW(newChar, self["myInput"].mapping[number])
 def VV9aQD(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCnM9r.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCnM9r.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVApdB(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVGlgW(newChar, group)
     break
 def VVGlgW(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVhsuV:
    group = VVPZsu + group.replace(newChar, FFNe7q(newChar, VVhsuV, VVPZsu))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVpcOT(self):
  if self.VVYhlR : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VV6PYJ()
 def VV6PYJ(self):
  self["myInput"].mapping = CCnM9r.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCnM9r.RCU_MAP_TITLES[self.charMode])
class CCnM9r(Screen):
 VVvgNW  = 0
 VVLYJ5  = 1
 VVI0j4  = 2
 VVKKp8  = 3
 VVEWzy = 4
 VVc4cD = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVvgNW, VVYhlR=False):
  self.skin, self.skinParam = FFOSVY(VVSc7g, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVYhlR  = VVYhlR
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFxmEB(self, title=self.Title)
  FFHCfw(self["keyRed"] ,"OK = Select")
  FFHCfw(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVYHoH     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVv5un, -1) ,
   "next"  : boundFunction(self.VVv5un, +1) ,
   "left"  : boundFunction(self.VVv5un, -1) ,
   "right"  : boundFunction(self.VVv5un, +1) ,
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFGQmF(self["keyRed"], "#11222222")
  FFGQmF(self["keyGreen"], "#11222222")
  self.VVpHBp()
 def VVpHBp(self):
  self.VVZV49()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVZV49(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVv5un(self, direction):
  if self.VVYhlR : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVpHBp()
 def VVYHoH(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCVQoF(Screen):
 def __init__(self, session, title="", message="", VVLxmM=VVsweO, VVcEvx=False, VV7My0=None, VV3p9i=30):
  self.skin, self.skinParam = FFOSVY(VVnnJQ, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VV3p9i)
  self.session   = session
  FFxmEB(self, title, addScrollLabel=True)
  self.VVLxmM   = VVLxmM
  self.VVcEvx   = VVcEvx
  self.VV7My0   = VV7My0
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self["myLabel"].VVqvJx(VVcEvx=self.VVcEvx)
  self["myLabel"].setText(self.message, self.VVLxmM)
  if self.VV7My0:
   FFGQmF(self["myBody"], self.VV7My0)
   FFGQmF(self["myLabel"], self.VV7My0)
   FFA2A6(self["myLabel"], self.VV7My0)
  self["myLabel"].VVWwRD()
class CC7mIK(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFOSVY(VVrDJT, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFxmEB(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  path = VVuSNJ + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCEwTV(Screen, CCbodp):
 def __init__(self, session, enableZapping=True, portalTableParam=None):
  self.skin, self.skinParam = FFOSVY(VVhFmC, 800, 170, 25, 10, 6, "#1100202a", "#1100202a", 20)
  CCbodp.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.winHeight    = 0
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.cutListCounter   = 0
  self.isCutListFound   = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFxmEB(self, "", addLabel=True)
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayBarM"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayJmp"] = Label("Jump: %d m" % self.jumpMinutes)
  self["myPlaySkp"] = Label()
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayInf"] = Label("Info")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0W2R         ,
   "info"  : self.VVmAEN        ,
   "epg"  : self.VVmAEN        ,
   "menu"  : self.VVGk8L         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVy36b        ,
   "green"  : boundFunction(self.VVif0l, True) ,
   "play"  : self.VVMzen        ,
   "pause"  : self.VVMzen        ,
   "stop"  : self.VVMzen        ,
   "left"  : boundFunction(self.VV4Ok0, -1)   ,
   "right"  : boundFunction(self.VV4Ok0,  1)   ,
   "rewind" : self.VVwJOb        ,
   "forward" : self.VV3xb0        ,
   "last"  : boundFunction(self.VVOAn6, 0)    ,
   "next"  : self.VVcLci        ,
   "pageUp" : boundFunction(self.VV43pE, True) ,
   "chanUp" : boundFunction(self.VV43pE, True) ,
   "pageDown" : boundFunction(self.VV43pE, False) ,
   "chanDown" : boundFunction(self.VV43pE, False) ,
   "0"   : boundFunction(self.VVP4Rw , 10)  ,
   "1"   : boundFunction(self.VVP4Rw , 1)  ,
   "2"   : boundFunction(self.VVP4Rw , 2)  ,
   "3"   : boundFunction(self.VVP4Rw , 3)  ,
   "4"   : boundFunction(self.VVP4Rw , 4)  ,
   "5"   : boundFunction(self.VVP4Rw , 5)  ,
   "6"   : boundFunction(self.VVP4Rw , 6)  ,
   "7"   : boundFunction(self.VVP4Rw , 7)  ,
   "8"   : boundFunction(self.VVP4Rw , 8)  ,
   "9"   : boundFunction(self.VVP4Rw , 9)
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self.VVS94Y()
  self.instance.move(ePoint(40, 40))
  size = self.instance.size()
  self.VVIuAo = int(size.width())
  self.winHeight1 = int(size.height())
  self.winHeight2 = int(self["myPlaySep"].getPosition()[1])
  FF5xSe(self["myPlayJmp"], "#0a666666")
  FF5xSe(self["myPlaySkp"], "#0affff00")
  FFGQmF(self["myPlayBlu"], "#1118188b")
  FFGQmF(self["myPlayInf"], "#11444444")
  self["myPlayBarM"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvFtQ)
  except:
   self.timer.callback.append(self.VVvFtQ)
  self.timer.start(1000, False)
  self.VVvFtQ("Checking ...")
  self.VVif0l()
 def onExit(self):
  self.timer.stop()
 def VVS94Y(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
 def VVGk8L(self):
  FF0qcI(self, VVuSNJ + "_help_player", "Player Controller (Keys)")
 def VV0W2R(self):
  if self.isManualSeek:
   self.VViKh0()
   self.VVOAn6(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VViKh0()
  else:
   self.close()
 def VVmAEN(self):
  FFWqlt(self, fncMode=CCw0CQ.VVV9n9)
 def VVMzen(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVvFtQ("Toggling Play/Pause ...")
 def VViKh0(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayBarM"].hide()
   self["myPlaySkp"].hide()
 def VV4Ok0(self, direc):
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVj8Hb()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayBarM"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFFGcp(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayBarM"].instance.size().width() + 1
   left = int(FFfeLG(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayBarM"].instance.move(ePoint(left, int(self["myPlayBarM"].getPosition()[1])))
   self["myPlaySkp"].setText(FFwz6F(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVP4Rw(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFHCfw(self["myPlayJmp"], "Jump: %d m" % self.jumpMinutes)
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVvFtQ("Changed Jump Minutes to : %d" % val)
 def VVvFtQ(self, title=""):
  if title:
   self.timer.stop()
  txt = self.Title
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVj8Hb()
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(str(posTxt))
    self["myPlayVal"].setText(percTxt)
    val  = FFFGcp(percVal, 0, 100)
    width = int(FFfeLG(val, 0, 100, 0, self.barWidth))
    self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
   if durTxt:
    self["myPlayDur"].setText(str(durTxt))
  if not self.isCutListFound and self.cutListCounter < 5:
   self.cutListCounter += 1
   if self.VVJTZG():
    self["myPlayBlu"].show()
    self.isCutListFound
  winH = self.instance.size().height()
  if durTxt:
   if winH < self.winHeight1:
    self.instance.resize(eSize(*(self.VVIuAo, self.winHeight1)))
  else:
   self["myPlayVal"].setText("0 %")
   if winH > self.winHeight2:
    self.instance.resize(eSize(*(self.VVIuAo, self.winHeight2)))
  if title:
   stateTxt = title
   FF5xSe(self["myPlayMsg"], "#00ff8000")
   self.timer.start(1000, False)
  else:
   stateTxt = ""
   if not posTxt and not durTxt:
    stateTxt = "Not playing yet ..."
   state = self.VVEKzN()
   if state:
    if state == "Playing" and not posTxt: stateTxt = "Unknown state"
    elif percVal == 100     : stateTxt = "End"
    else        : stateTxt = state
    if state == "Playing" and posTxt:
     if self.restoreLastPlayPos:
      self.restoreLastPlayPos = False
      if self.lastPlayPos > 0:
       stateTxt = "Restoring Pos. ..."
       self.VVOAn6(self.lastPlayPos * 90000.0)
     else:
      self.lastPlayPos = posVal
   state = self.VV1TtB()
   if state:
    stateTxt = state
   if stateTxt == "Playing": FF5xSe(self["myPlayMsg"], "#0000ff00")
   else     : FF5xSe(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVj8Hb(self):
  percVal = durVal = posVal = seekable = 0
  percTxt = durTxt = posTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFwz6F(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFwz6F(posVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt
 def VVy36b(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVJTZG()
   if cList:
    VVTikG = []
    for pts, what in cList:
     txt = FFwz6F(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVTikG.append((txt, pts))
    FFh3ra(self, self.VVkv9k, VVTikG=VVTikG, title="Cut List")
   else:
    self.VVvFtQ("No Cut-List for this channel !")
 def VVkv9k(self, item=None):
  if item:
   self.VVOAn6(item)
 def VVJTZG(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV3xb0(self) : self.VV8tI7(self.jumpMinutes)
 def VVwJOb(self) : self.VV8tI7(-self.jumpMinutes)
 def VV8tI7(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVvFtQ("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVvFtQ("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVvFtQ("Cannot jump")
 def VVjNVZ(self):
  InfoBar.instance.VVjNVZ()
 def VVOAn6(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVvFtQ("Changing Time ...")
 def VVcLci(self):
  try:
   seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVj8Hb()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVvFtQ("Jumping to end ...")
  except:
   pass
 def VVEKzN(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV1TtB(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV43pE(self, isUp):
  if self.enableZapping:
   if self.portalTableParam:
    self.VVrUE6(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
     ok = True
    except:
     pass
    self.VVS94Y()
    self.VVif0l()
 def VVrUE6(self, isUp):
  CCn3vN_inatance, VVTGDg, mode = self.portalTableParam
  totRows = VVTGDg.VVOSYq()
  curRow = VVTGDg.VVu2q3()
  if totRows > 1:
   if isUp:
    nextRow = curRow + 1
    if nextRow > totRows - 1:
     nextRow = 0
   else:
    nextRow = curRow - 1
    if nextRow < 0:
     nextRow = totRows - 1
  VVTGDg.VVy0NS(nextRow)
  FFapsE(VVTGDg, boundFunction(self.VV35Ee, mode, VVTGDg, CCn3vN_inatance), title="Playing ...")
 def VV35Ee(self, mode, VVTGDg, CCn3vN_inatance):
  colList = VVTGDg.VVtyqv()
  if mode == "localIptv":
   CCn3vN_inatance.VVHBZg(VVTGDg, "", "", colList)
  elif isinstance(mode, int):
   CCn3vN_inatance.VVX5Go(mode, VVTGDg, "", "", colList)
  else:
   CCn3vN_inatance.VV5Mws(mode, VVTGDg, "", "", colList, forceZap=True)
  self.close()
 def VVif0l(self, refresh=False):
  try:
   if not refresh:
    seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVj8Hb()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF3CkY(self)
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVfnDB(decodedUrl)
   if not valid:
    return
   if not self.VVmRFF(host, mac, VVU7ut=False):
    return
   self.VVvFtQ("Refreshing Portal")
   FFk91F(boundFunction(self.VVPb6J, mode, refCode, chName, iptvRef, chCm, epNum, epId, query))
  except:
   pass
 def VVPb6J(self, mode, refCode, chName, iptvRef, chCm, epNum, epId, query):
  chUrl = self.VVAmTJ(mode, chCm, epNum, epId)
  if not chUrl:
   return
  if not refCode.endswith(":"):
   refCode += ":"
  chUrl = refCode + chUrl.strip() + ":" + chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + query + right
  if newIptvRef:
   success = self.VVdbuO(iptvRef, newIptvRef)
   self.restoreLastPlayPos = True
   FFHTCm(self, newIptvRef, VVqXf4=False)
 def VVdbuO(self, oldCode, newCode):
  bPath = FFzE8V()
  if bPath:
   txt = FFjNcO(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFWzzi()
    return True
  return False
class CC16dg(Screen):
 def __init__(self, session, title="", VVN4XI="Continue?", VV5OMH=True, VVSmS1=False):
  self.skin, self.skinParam = FFOSVY(VVHmfh, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVN4XI = VVN4XI
  self.VVSmS1 = VVSmS1
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV5OMH : VVTikG = [no , yes]
  else   : VVTikG = [yes, no ]
  FFxmEB(self, title, VVTikG=VVTikG, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0W2R ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVN4XI)
  if self.VVSmS1:
   self["myLabel"].instance.setHAlign(0)
  self.VVH544()
  FFWhRj(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFSQc5(self["myMenu"])
  FFGCsy(self, self["myMenu"])
 def VV0W2R(self):
  item = FF49MM(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVH544(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCM32K(Screen):
 def __init__(self, session, title="", VVTikG=None, width=1000, OKBtnFnc=None, VVr7QF=None, VVemQY=None, VVmqZr=None, VViuu9=None, VVxlCv=False, VV5vXM=False):
  self.skin, self.skinParam = FFOSVY(VVyfFI, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVTikG   = VVTikG
  self.OKBtnFnc   = OKBtnFnc
  self.VVr7QF   = VVr7QF
  self.VVemQY  = VVemQY
  self.VVmqZr  = VVmqZr
  self.VViuu9   = VViuu9
  self.VVxlCv  = VVxlCv
  self.VV5vXM  = VV5vXM
  FFxmEB(self, title, VVTikG=VVTikG)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0W2R          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVE7CC         ,
   "green"  : self.VVY3M3         ,
   "yellow" : self.VVUBbh         ,
   "blue"  : self.VVY7o2         ,
   "pageUp" : self.VV05hz       ,
   "chanUp" : self.VV05hz       ,
   "pageDown" : self.VVgdhP        ,
   "chanDown" : self.VVgdhP
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["myMenu"])
  FFtLnH(self)
  self.VV0NgF(self["keyRed"]  , self.VVr7QF )
  self.VV0NgF(self["keyGreen"] , self.VVemQY )
  self.VV0NgF(self["keyYellow"] , self.VVmqZr )
  self.VV0NgF(self["keyBlue"]  , self.VViuu9 )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFZ8sT(self)
 def VV0NgF(self, btnObj, btnFnc):
  if btnFnc:
   FFHCfw(btnObj, btnFnc[0])
 def VV0W2R(self):
  item = FF49MM(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVxlCv: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVE7CC(self)  : self.VVAy69(self.VVr7QF)
 def VVY3M3(self) : self.VVAy69(self.VVemQY)
 def VVUBbh(self) : self.VVAy69(self.VVmqZr)
 def VVY7o2(self) : self.VVAy69(self.VViuu9)
 def VVAy69(self, btnFnc):
  if btnFnc:
   item = FF49MM(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV5vXM:
    self.cancel()
 def VVlVEa(self, VVTikG):
  if len(VVTikG) > 0:
   newList = []
   for item in VVTikG:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVK0dL(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV05hz(self):
  self["myMenu"].moveToIndex(0)
 def VVgdhP(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCZM1I(Screen):
 def __init__(self, session, title="", header=None, VV26yB=None, VVfMBx=None, VVX78s=None, VV3p9i=24, VVRCjQ=False, VVXJOe=None, VVcsOf=None, VVgrOj=None, VVpp6N=None, VVtuOR=None, VVwxMC=None, VVvEKu=None, VVPfEQ=None, VVCWuB=None, VV2PiX=-1, VVZfHP=False, searchCol=0, VVICrB=None, VVMl7F=None, VViX1b="#00dddddd", VV7My0="#11002233", VVf7yk="#00ff8833", VV0ai5="#11111111", VVovon="#0a555555", VVWDiQ="#0affffff", VVZHY2="#11552200", VVvceo="#0055ff55"):
  self.skin, self.skinParam = FFOSVY(VV0K2n, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFxmEB(self, title)
  self.header     = header
  self.VV26yB     = VV26yB
  self.totalCols    = len(VV26yB[0])
  self.VV4S25   = 0
  self.lastSortModeIsReverese = False
  self.VVRCjQ   = VVRCjQ
  self.VV17DK   = 0.01
  self.VV3ksZ   = 0.02
  self.VVaevT  = 1
  self.VVX78s = VVX78s
  self.colWidthPixels   = []
  self.VVXJOe   = VVXJOe
  self.OKButtonObj   = None
  self.VVcsOf   = VVcsOf
  self.VVgrOj   = VVgrOj
  self.VVpp6N   = VVpp6N
  self.VVtuOR  = VVtuOR
  self.VVwxMC   = VVwxMC
  self.VVvEKu    = VVvEKu
  self.VVPfEQ   = VVPfEQ
  self.VVCWuB  = VVCWuB
  self.VV2PiX    = VV2PiX
  self.VVZfHP   = VVZfHP
  self.searchCol    = searchCol
  self.VVfMBx    = VVfMBx
  self.keyPressed    = -1
  self.VV3p9i    = FF0hZe(VV3p9i)
  self.VV6w1K    = FFhoJ7(self.VV3p9i, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVICrB    = VVICrB
  self.VVMl7F      = VVMl7F
  self.VViX1b    = FFzmVi(VViX1b)
  self.VV7My0    = FFzmVi(VV7My0)
  self.VVf7yk    = FFzmVi(VVf7yk)
  self.VV0ai5    = FFzmVi(VV0ai5)
  self.VVovon   = FFzmVi(VVovon)
  self.VVWDiQ    = FFzmVi(VVWDiQ)
  self.VVZHY2    = FFzmVi(VVZHY2)
  self.VVvceo   = FFzmVi(VVvceo)
  self.VV3JmO  = False
  self.selectedItems   = 0
  self.VVISfD   = FFzmVi("#01fefe01")
  self.VVAhcu   = FFzmVi("#11400040")
  self.VVcPpI  = self.VVISfD
  self.VVsTOM  = self.VV0ai5
  if self.VVZfHP:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV6J6U  ,
   "red"   : self.VVfnuy  ,
   "green"   : self.VVXo8U ,
   "yellow"  : self.VVEHxN ,
   "blue"   : self.VVVmcw  ,
   "menu"   : self.VVdCqV ,
   "info"   : self.VVAfVM  ,
   "cancel"  : self.VV5Nmf  ,
   "up"   : self.VVOqXM    ,
   "down"   : self.VV4Xdr  ,
   "left"   : self.VVbcnF   ,
   "right"   : self.VVqPMs  ,
   "pageUp"  : self.VVilN3  ,
   "chanUp"  : self.VVilN3  ,
   "pageDown"  : self.VVu6Hb  ,
   "chanDown"  : self.VVu6Hb
  }, -1)
  FF1t9f(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  try:
   self.VVUpgA()
  except Exception as err:
   FF3mKe(self, str(err))
   self.close(None)
 def VVUpgA(self):
  FFZ8sT(self)
  if self.VVICrB:
   FFGQmF(self["myTitle"], self.VVICrB)
  if self.VVMl7F:
   FFGQmF(self["myBody"] , self.VVMl7F)
   FFGQmF(self["myTableH"] , self.VVMl7F)
   FFGQmF(self["myTable"] , self.VVMl7F)
   FFGQmF(self["myBar"]  , self.VVMl7F)
  self.VV0NgF(self.VVgrOj  , self["keyRed"])
  self.VV0NgF(self.VVpp6N  , self["keyGreen"])
  self.VV0NgF(self.VVtuOR , self["keyYellow"])
  self.VV0NgF(self.VVwxMC  , self["keyBlue"])
  if self.VVXJOe:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVXJOe[0])
    FFGQmF(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV6w1K)
  self["myTableH"].l.setFont(0, gFont(VViB9W, self.VV3p9i))
  self["myTable"].l.setItemHeight(self.VV6w1K)
  self["myTable"].l.setFont(0, gFont(VViB9W, self.VV3p9i))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV6w1K)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV6w1K))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV6w1K)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV6w1K
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV6w1K * len(self.VV26yB) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVX78s:
   self.VVX78s = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVX78s)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVfMBx:
   self.VVfMBx = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVfMBx
   self.VVfMBx = []
   for item in tmpList:
    self.VVfMBx.append(item | RT_VALIGN_CENTER)
  self.VVgDF4()
  if self.VVvEKu:
   self.VVvEKu(self)
 def VV0NgF(self, btnFnc, btn):
  if btnFnc : FFHCfw(btn, btnFnc[0])
  else  : FFHCfw(btn, "")
 def VVsxnf(self, waitTxt):
  FFapsE(self, self.VVgDF4, title=waitTxt)
 def VVgDF4(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVzu2t(0, self.header, self.VVWDiQ, self.VVZHY2, self.VVWDiQ, self.VVZHY2, self.VVvceo)])
   rows = []
   for c, row in enumerate(self.VV26yB):
    rows.append(self.VVzu2t(c, row, self.VViX1b, self.VV7My0, self.VVf7yk, self.VV0ai5, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VV2PiX > -1:
    self["myTable"].moveToIndex(self.VV2PiX )
   self.VVLFfv()
   if self.VVZfHP:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV6w1K * len(self.VV26yB)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVPfEQ:
    self.VVAy69(self.VVPfEQ, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF3mKe(self, str(err))
    self.close()
   except:
    pass
 def VVzu2t(self, keyIndex, columns, VViX1b, VV7My0, VVf7yk, VV0ai5, VVvceo):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVvceo and ndx == self.VV4S25 : textColor = VVvceo
   else           : textColor = VViX1b
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.+)", entry, IGNORECASE)
   if span:
    c = FFzmVi(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VV7My0 = c
    entry = span.group(3)
   if self.VVfMBx[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV6w1K)
           , font   = 0
           , flags   = self.VVfMBx[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VV7My0
           , color_sel  = VVf7yk
           , backcolor_sel = VV0ai5
           , border_width = 1
           , border_color = self.VVovon
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVAfVM(self):
  rowData = self.VVlE72()
  if rowData:
   title, txt, colList = rowData
   if self.VVcsOf:
    fnc  = self.VVcsOf[1]
    params = self.VVcsOf[2]
    fnc(self, title, txt, colList)
   else:
    FFxYUM(self, txt, title)
 def VV6J6U(self):
  if   self.VV3JmO : self.VV6SL0(self.VVu2q3(), mode=2)
  elif self.VVXJOe  : self.VVAy69(self.VVXJOe, None)
  else      : self.VVAfVM()
 def VVfnuy(self) : self.VVAy69(self.VVgrOj , self["keyRed"])
 def VVXo8U(self) : self.VVAy69(self.VVpp6N , self["keyGreen"])
 def VVEHxN(self): self.VVAy69(self.VVtuOR , self["keyYellow"])
 def VVVmcw(self) : self.VVAy69(self.VVwxMC , self["keyBlue"])
 def VVAy69(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFK43o(self, buttonFnc[3])
    FFk91F(boundFunction(self.VVSeHO, buttonFnc))
   else:
    self.VVSeHO(buttonFnc)
 def VVSeHO(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVlE72()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV6SL0(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV26yB[ndx]
   isSelected = row[1][9] == self.VVISfD
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVzu2t(ndx, item, self.VViX1b, self.VV7My0, self.VVf7yk, self.VV0ai5, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVzu2t(ndx, item, self.VVISfD, self.VVAhcu, self.VVcPpI, self.VVsTOM, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVLFfv()
 def VVOztk(self):
  FFapsE(self, self.VVH1GZ, title="Selecting all ...")
 def VVH1GZ(self):
  self.VVpGmr(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVISfD
   if not isSelected:
    item = self.VV26yB[ndx]
    newRow = self.VVzu2t(ndx, item, self.VVISfD, self.VVAhcu, self.VVcPpI, self.VVsTOM, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVLFfv()
  self.VVLHLa()
 def VVd1k8(self):
  FFapsE(self, self.VVa3Xx, title="Unselecting all ...")
 def VVa3Xx(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVISfD:
    item = self.VV26yB[ndx]
    newRow = self.VVzu2t(ndx, item, self.VViX1b, self.VV7My0, self.VVf7yk, self.VV0ai5, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVLFfv()
  self.VVLHLa()
 def VVlE72(self):
  item = self["myTable"].getCurrent()
  if item:
   rowNum = item[0] + 1
   txt  = ""
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    if self.VVX78s[i - 1] > 1 or self.VVX78s[i - 1] == self.VV17DK:
     if self.header : txt += "%s\t: %s\n" % (self.header[i - 1], colTxt)
     else   : txt += "Col-%d\t: %s\n" % (i, colTxt)
    colList.append(colTxt)
   return "Row Number : %d of %d\n\n" % (rowNum, len(self.VV26yB)), txt, colList
  else:
   return None
 def VV5Nmf(self):
  if self.VVCWuB : self.VVCWuB(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVEebE(self):
  return self["myTitle"].getText().strip()
 def VVeD6r(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVWdWk(self, txt):
  FFK43o(self, txt)
 def VVstuD(self, txt):
  FFK43o(self, txt, 1000)
 def VVqfpI(self):
  FFK43o(self)
 def VVpsIe(self):
  return len(self.VV26yB)
 def VVH12h(self): self["keyGreen"].show()
 def VVcIAU(self): self["keyGreen"].hide()
 def VVu2q3(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVOSYq(self):
  return len(self["myTable"].list)
 def VVpGmr(self, isOn):
  self.VV3JmO = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVwxMC: self["keyBlue"].hide()
   if self.VVXJOe and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVwxMC: self["keyBlue"].show()
   if self.VVXJOe and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVXJOe[0])
   self.VVd1k8()
  FFGQmF(self["myTitle"], color)
  FFGQmF(self["myBar"]  , color)
 def VVSHYA(self):
  return self.VV3JmO
 def VVZtAS(self):
  return self.selectedItems
 def VVLHLa(self):
  self.hide()
  self.show()
 def VVy0NS(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVLFfv()
 def VVDd5Q(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVLFfv()
 def VVORyJ(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV26yB:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVNpvK(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVpsIe()
  txt += FFQpa3("Total Unique Items", VVix4Z)
  for i in range(self.totalCols):
   if self.VVX78s[i - 1] > 1 or self.VVX78s[i - 1] == self.VV17DK:
    name, tot = self.VVORyJ(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFxYUM(self, txt)
 def VV7rv1(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVtyqv(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV8OPy(self, newList, newTitle=""):
  if newList:
   self.VV26yB = newList
   if self.VVRCjQ and self.VV4S25 == 0:
    self.VV26yB = sorted(self.VV26yB, key=lambda x: int(x[self.VV4S25])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV26yB = sorted(self.VV26yB, key=lambda x: x[self.VV4S25].lower(), reverse=self.lastSortModeIsReverese)
   self.VVsxnf("Refreshing ...")
   if newTitle:
    self.VVeD6r(newTitle)
  else:
   FF3mKe(self, "Cannot refresh list")
   self.cancel()
 def VViRsV(self, data):
  ndx = self.VVu2q3()
  newRow = self.VVzu2t(ndx, data, self.VViX1b, self.VV7My0, self.VVf7yk, self.VV0ai5, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVLHLa()
   return True
  else:
   return False
 def VVf6dd(self, colNum, textToFind, VVU7ut=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVLFfv()
    break
  else:
   if VVU7ut:
    FFK43o(self, "Not found", 1000)
 def VV4w3d(self, colDict, VVU7ut=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVLFfv()
    return
  if VVU7ut:
   FFK43o(self, "Not found", 1000)
 def VV4w3d_partial(self, colDict, VVU7ut=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVLFfv()
    return
  if VVU7ut:
   FFK43o(self, "Not found", 1000)
 def VVKseX(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV47o3(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVISfD:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVaz4B(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVdCqV(self):
  if not self["keyMenu2F"].getVisible():
   return
  if not self.VVZfHP:
   VVTikG = []
   VVTikG.append(("Table Statistcis"             , "tableStat"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append((FFNe7q("Export Table to .html"     , VVix4Z) , "VVlwhY" ))
   VVTikG.append((FFNe7q("Export Table to .csv"     , VVix4Z) , "VV1GWu" ))
   VVTikG.append((FFNe7q("Export Table to .txt (Tab Separated)", VVix4Z) , "VVQvJV" ))
   VVTikG.append(VVK4l8)
   for i in range(self.totalCols):
    if self.header : name = self.header[i]
    else   : name = "Col-%d" % i
    if self.VVX78s[i] > 1 or self.VVX78s[i] == self.VV3ksZ:
     VVTikG.append(("Sort by : %s" % name, i))
   if VVTikG:
    FFh3ra(self, self.VVG3Iz, VVTikG=VVTikG, title=self.VVEebE())
 def VVG3Iz(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVNpvK()
   elif item == "VVlwhY": FFapsE(self, self.VVlwhY, title=title)
   elif item == "VV1GWu" : FFapsE(self, self.VV1GWu , title=title)
   elif item == "VVQvJV" : FFapsE(self, self.VVQvJV , title=title)
   else:
    isReversed = False
    if self.VV4S25 == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVRCjQ and item == 0:
     self.VV26yB = sorted(self.VV26yB, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV26yB = sorted(self.VV26yB, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VV4S25 = item
    self.VVsxnf("Sorting ...")
 def VVOqXM(self):
  self["myTable"].up()
  self.VVLFfv()
 def VV4Xdr(self):
  self["myTable"].down()
  self.VVLFfv()
 def VVbcnF(self):
  self["myTable"].pageUp()
  self.VVLFfv()
 def VVqPMs(self):
  self["myTable"].pageDown()
  self.VVLFfv()
 def VVilN3(self):
  self["myTable"].moveToIndex(0)
  self.VVLFfv()
 def VVu6Hb(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVLFfv()
 def VVQvJV(self):
  expFile = self.VVW8me() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVWzd3()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV26yB:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVX78s[ndx] > self.VVaevT:
      col = self.VVUXVz(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVBCFq(expFile)
 def VV1GWu(self):
  expFile = self.VVW8me() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVWzd3()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV26yB:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVX78s[ndx] > self.VVaevT:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVUXVz(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVBCFq(expFile)
 def VVlwhY(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVEebE(), PLUGIN_NAME, VViRxJ)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVEebE()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVWzd3()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVX78s:
   colgroup += '   <colgroup>'
   for w in self.VVX78s:
    if w > self.VVaevT:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVW8me() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV26yB:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVX78s[ndx] > self.VVaevT:
      col = self.VVUXVz(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVBCFq(expFile)
 def VVWzd3(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVX78s[ndx] > self.VVaevT:
     newRow.append(col.strip())
  return newRow
 def VVUXVz(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFIQzg(col)
 def VVW8me(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVEebE())
  fileName = fileName.replace("__", "_")
  path  = FFgLfR(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFJ142()
  return expFile
 def VVBCFq(self, expFile):
  FFX4bs(self, "File exported to:\n\n%s" % expFile, title=self.VVEebE())
 def VVLFfv(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCDWEy(Screen):
 def __init__(self, session, Title="", VVZrCB=None):
  self.skin, self.skinParam = FFOSVY(VVwJIf, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFxmEB(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVZrCB = VVZrCB
  if len(Title) == 0 : Title = FFXHTP()
  else    : Title = "File : %s" % VVZrCB
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  allOK = FFjIiX(self["myLabel"], self.VVZrCB)
  if not allOK:
   FF3mKe(self, "Could not view this picture file")
   self.close()
class CCVRQj(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFOSVY(VVQXyC, 1400, 950, 50, 40, 40, "#11201010", "#11101010", 30, barHeight=40, topRightBtns=1)
  self.session  = session
  FFxmEB(self)
  FFHCfw(self["keyGreen"], "Save")
  self.VV26yB = []
  self.VV26yB.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VV26yB.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VV26yB.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VV26yB.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VV26yB.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  self.VV26yB.append(getConfigListEntry(VVGWwg *2            ,         ))
  self.VV26yB.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VV26yB.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VV26yB.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VV26yB.append(getConfigListEntry(VVGWwg *2            ,         ))
  self.VV26yB.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VV26yB.append(getConfigListEntry(VVGWwg *2            ,         ))
  self.VV26yB.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VV26yB.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VV26yB.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VV26yB.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VV26yB.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VV26yB, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VV0W2R   ,
   "OK"  : self.VV0W2R   ,
   "green"  : self.VVX4pY  ,
   "menu"  : self.VVx8Eu ,
   "cancel" : self.VVC2uE
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFWhRj(self["config"])
  FFtLnH(self,  self["config"])
  FFZ8sT(self)
 def VV0W2R(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VVaAs3(item)
   elif item == CFG.backupPath    : self.VVaAs3(item)
   elif item == CFG.packageOutputPath  : self.VVaAs3(item)
   elif item == CFG.downloadedPackagesPath : self.VVaAs3(item)
   elif item == CFG.exportedTablesPath  : self.VVaAs3(item)
   elif item == CFG.exportedPIconsPath  : self.VVaAs3(item)
 def VVaAs3(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VVkD0W, configObj)
         , boundFunction(CCXbmU, mode=CCXbmU.VVoyZj, VVg2QG=sDir))
 def VVkD0W(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVC2uE(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFAuNs(self, self.VVX4pY, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVX4pY(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVFXNI()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVx8Eu(self):
  VVTikG = []
  VVTikG.append(("Use Backup directory in all other paths"      , "VVvXTd"   ))
  VVTikG.append(("Reset all to default (including File Manager bookmarks)"  , "VVrMlH"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Backup %s Settings" % PLUGIN_NAME        , "VVWODd"  ))
  VVTikG.append(("Restore %s Settings" % PLUGIN_NAME       , "VV1vV9"  ))
  if fileExists(VVCWNQ + VViooG):
   VVTikG.append(VVK4l8)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVTikG.append(('%s Checking for Update' % txt1       , txt2     ))
   VVTikG.append(("Reinstall %s" % PLUGIN_NAME        , "VV2hYN"  ))
   VVTikG.append(("Update %s" % PLUGIN_NAME        , "VV4HEe"   ))
  FFh3ra(self, self.VVeZza, VVTikG=VVTikG, title="Config. Options")
 def VVeZza(self, item=None):
  if item:
   if   item == "VVvXTd"  : FFAuNs(self, self.VVvXTd , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVrMlH"  : FFAuNs(self, self.VVrMlH, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCBNh7)
   elif item == "VVWODd" : self.VVWODd()
   elif item == "VV1vV9" : FFapsE(self, self.VV1vV9, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVL5Ky(True)
   elif item == "disableChkUpdate" : self.VVL5Ky(False)
   elif item == "VV2hYN" : FFapsE(self, self.VV2hYN , "Checking Server ...")
   elif item == "VV4HEe"  : FFapsE(self, self.VV4HEe  , "Checking Server ...")
 def VVWODd(self):
  path = "%sajpanel_settings_%s" % (VVCWNQ, FFJ142())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFX4bs(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV1vV9(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFwzkK("find / %s -iname '%s*' | grep %s" % (FFBQjd(1), name, name))
  if lines:
   lines.sort()
   VVTikG = []
   for line in lines:
    VVTikG.append((line, line))
   FFh3ra(self, boundFunction(self.VVUMVf, title), title=title, VVTikG=VVTikG, width=1200)
  else:
   FF3mKe(self, "No settings files found !", title=title)
 def VVUMVf(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFVFca(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVFXNI()
    FFoKMu()
   else:
    FFhkqx(SELF, path, title=title)
 def VVL5Ky(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVvXTd(self):
  newPath = FFgLfR(VVCWNQ)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVFXNI()
 @staticmethod
 def VV4ZnL():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVrMlH(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.PIconsPath.setValue(VVdxwL)
  CFG.backupPath.setValue(CCVRQj.VV4ZnL())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVFXNI()
  self.close()
 def VVFXNI(self):
  configfile.save()
  global VVCWNQ
  VVCWNQ = CFG.backupPath.getValue()
  FFKQ3v()
 def VV4HEe(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVFjzf(title)
  if webVer:
   FFAuNs(self, boundFunction(FFapsE, self, boundFunction(self.VVj8Z8, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VV2hYN(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVFjzf(title, True)
  if webVer:
   FFAuNs(self, boundFunction(FFapsE, self, boundFunction(self.VVj8Z8, webVer, title)), "Install and Restart ?", title=title)
 def VVj8Z8(self, webVer, title):
  url = self.VVZ9Ni(self, title)
  if url:
   VV6C6C = FFOVMy() == "dpkg"
   if VV6C6C == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VV6C6C else "ipk")
   path, err = FFUSMT(url + fName, fName, timeout=2)
   if path:
    cmd = FFl4YE(VVyAfl, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFH6Oq(self, cmd)
    else:
     FFYXW3(self, title=title)
   else:
    FF3mKe(self, err, title=title)
 def VVFjzf(self, title, anyVer=False):
  url = self.VVZ9Ni(self, title)
  if not url:
   return ""
  path, err = FFUSMT(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF3mKe(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFjNcO(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF3mKe(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VViRxJ.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFwzkK(cmd)
   if list and curVer == list[0]:
    return webVer
  FFX4bs(self, FFNe7q("No update required.", VVHsWS) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVZ9Ni(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVCWNQ + VViooG
  if fileExists(path):
   span = iSearch(r"(http.+)", FFjNcO(path), IGNORECASE)
   if span : url = FFgLfR(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF3mKe(SELF, err, title)
  return url
 @staticmethod
 def VVrGA8(url):
  path, err = FFUSMT(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFjNcO(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VViRxJ.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFwzkK(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCBNh7(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFOSVY(VV1Uct, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVYaet
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFxmEB(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVGGR8("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVGGR8("\c00888888", i) + sp + "GREY\n"
   txt += self.VVGGR8("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVGGR8("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVGGR8("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVGGR8("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVGGR8("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVGGR8("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVGGR8("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVGGR8("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVGGR8("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVGGR8("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV0W2R ,
   "green"   : self.VV0W2R ,
   "left"   : self.VVQsXz ,
   "right"   : self.VVPA2J ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  self.VVqxqp()
 def VV0W2R(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFAuNs(self, self.VVETIq, "Change to : %s" % txt, title=self.Title)
 def VVETIq(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVYaet
  VVYaet = self.cursorPos
  self.VVqfIh()
  self.close()
 def VVQsXz(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVqxqp()
 def VVPA2J(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVqxqp()
 def VVqxqp(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVGGR8(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV9kke(color):
  if VVL19M: return "\\" + color
  else    : return ""
 @staticmethod
 def VVqfIh():
  global VVleFh, VVPZsu, VVao2g, VVix4Z, VVcYGL, VV9G5r, VVHsWS, VVL19M, COLOR_CONS_BRIGHT_YELLOW, VV1Zj2, VVa59G, VVhsuV
  VVhsuV   = CCBNh7.VVGGR8("\c00FFFFFF", VVYaet)
  VVPZsu    = CCBNh7.VVGGR8("\c00888888", VVYaet)
  VVleFh  = CCBNh7.VVGGR8("\c005A5A5A", VVYaet)
  VV9G5r    = CCBNh7.VVGGR8("\c00FF0000", VVYaet)
  VVao2g   = CCBNh7.VVGGR8("\c00FF5000", VVYaet)
  VVL19M   = CCBNh7.VVGGR8("\c00FFFF00", VVYaet)
  COLOR_CONS_BRIGHT_YELLOW = CCBNh7.VVGGR8("\c00FFFFAA", VVYaet)
  VVHsWS   = CCBNh7.VVGGR8("\c0000FF00", VVYaet)
  VVcYGL    = CCBNh7.VVGGR8("\c000066FF", VVYaet)
  VV1Zj2    = CCBNh7.VVGGR8("\c0000FFFF", VVYaet)
  VVa59G   = CCBNh7.VVGGR8("\c00FA55E7", VVYaet)
  VVix4Z    = CCBNh7.VVGGR8("\c00FF8F5F", VVYaet)
CCBNh7.VVqfIh()
class CCfmbm(Screen):
 def __init__(self, session, path, VV6C6C):
  self.skin, self.skinParam = FFOSVY(VVbrPw, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVmIB3   = path
  self.VVdLgj   = ""
  self.VVJGgR   = ""
  self.VV6C6C    = VV6C6C
  self.VVSb5j    = ""
  self.VV1vPT  = ""
  self.VVCyJF    = False
  self.VV6XU9  = False
  self.postInstAcion   = 0
  self.VV8NMY  = "enigma2-plugin-extensions"
  self.VVGPvO  = "enigma2-plugin-systemplugins"
  self.VVaUEM = "enigma2"
  self.VVA8Sm  = 0
  self.VVPuqu  = 1
  self.VVwiUu  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVCq6B = "DEBIAN"
  else        : self.VVCq6B = "CONTROL"
  self.controlPath = self.Path + self.VVCq6B
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV6C6C:
   self.packageExt  = ".deb"
   self.VV7My0  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VV7My0  = "#11001020"
  FFxmEB(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFHCfw(self["keyRed"] , "Create")
  FFHCfw(self["keyGreen"] , "Post Install")
  FFHCfw(self["keyYellow"], "Installation Path")
  FFHCfw(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVn49G  ,
   "green"   : self.VVb2je ,
   "yellow"  : self.VVnu44  ,
   "blue"   : self.VVBWpP  ,
   "cancel"  : self.VVSH7n
  }, -1)
  self.onShown.append(self.VV6NQt)
 def VV6NQt(self):
  self.onShown.remove(self.VV6NQt)
  FFZ8sT(self)
  if self.VV7My0:
   FFGQmF(self["myBody"], self.VV7My0)
   FFGQmF(self["myLabel"], self.VV7My0)
  self.VVimwP(True)
  self.VVa6iV(True)
 def VVa6iV(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV7YNW()
  if isFirstTime:
   if   package.startswith(self.VV8NMY) : self.VVmIB3 = VVXkvT + self.VVSb5j + "/"
   elif package.startswith(self.VVGPvO) : self.VVmIB3 = VVb5jS + self.VVSb5j + "/"
   else            : self.VVmIB3 = self.Path
  if self.VVCyJF : myColor = VVix4Z
  else    : myColor = VVhsuV
  txt  = ""
  txt += "Source Path\t: %s\n" % FFNe7q(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFNe7q(self.VVmIB3, VVL19M)
  if self.VVJGgR : txt += "Package File\t: %s\n" % FFNe7q(self.VVJGgR, VVPZsu)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFNe7q("Check Control File fields : %s" % errTxt, VVao2g)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFNe7q("Restart GUI", VVix4Z)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFNe7q("Reboot Device", VVix4Z)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFNe7q("Post Install", VVHsWS), act)
  if not errTxt and VVao2g in controlInfo:
   txt += "Warning\t: %s\n" % FFNe7q("Errors in control file may affect the result package.", VVao2g)
  txt += "\nControl File\t: %s\n" % FFNe7q(self.controlFile, VVPZsu)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVb2je(self):
  VVTikG = []
  VVTikG.append(("No Action"    , "noAction"  ))
  VVTikG.append(("Restart GUI"    , "VVzoe2"  ))
  VVTikG.append(("Reboot Device"   , "rebootDev"  ))
  FFh3ra(self, self.VVQrlB, title="Package Installation Option (after completing installation)", VVTikG=VVTikG)
 def VVQrlB(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVzoe2"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVimwP(False)
   self.VVa6iV()
 def VVnu44(self):
  rootPath = FFNe7q("/%s/" % self.VVSb5j, VVleFh)
  VVTikG = []
  VVTikG.append(("Current Path"        , "toCurrent"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Extension Path"       , "toExtensions" ))
  VVTikG.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVTikG.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFh3ra(self, self.VVRgxl, title="Installation Path", VVTikG=VVTikG)
 def VVRgxl(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVjXf3(FFLTn7(self.Path, True))
   elif item == "toExtensions"  : self.VVjXf3(VVXkvT)
   elif item == "toSystemPlugins" : self.VVjXf3(VVb5jS)
   elif item == "toRootPath"  : self.VVjXf3("/")
   elif item == "toRoot"   : self.VVjXf3("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV3Cb2, boundFunction(CCXbmU, mode=CCXbmU.VVoyZj, VVg2QG=VVCWNQ))
 def VV3Cb2(self, path):
  if len(path) > 0:
   self.VVjXf3(path)
 def VVjXf3(self, parent, withPackageName=True):
  if withPackageName : self.VVmIB3 = parent + self.VVSb5j + "/"
  else    : self.VVmIB3 = "/"
  mode = self.VVjyyr()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVi4zs(mode), self.controlFile))
  self.VVa6iV()
 def VVBWpP(self):
  if fileExists(self.controlFile):
   lines = FFVFca(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFCkFz(self, self.VVeYk0, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF3mKe(self, "Version not found or incorrectly set !")
  else:
   FFhkqx(self, self.controlFile)
 def VVeYk0(self, VVD55x):
  if VVD55x:
   version, color = self.VVBc8z(VVD55x, False)
   if color == VV1Zj2:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVD55x, self.controlFile))
    self.VVa6iV()
   else:
    FF3mKe(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVSH7n(self):
  if self.newControlPath:
   if self.VVCyJF:
    self.VV4lEp()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFNe7q(self.newControlPath, VVPZsu)
    txt += FFNe7q("Do you want to keep these files ?", VVL19M)
    FFAuNs(self, self.close, txt, callBack_No=self.VV4lEp, title="Create Package", VVSmS1=True)
  else:
   self.close()
 def VV4lEp(self):
  os.system(FFOaw3("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVi4zs(self, mode):
  if   mode == self.VVPuqu : prefix = self.VV8NMY
  elif mode == self.VVwiUu : prefix = self.VVGPvO
  else        : prefix = self.VVaUEM
  return prefix + "-" + self.VV1vPT
 def VVjyyr(self):
  if   self.VVmIB3.startswith(VVXkvT) : return self.VVPuqu
  elif self.VVmIB3.startswith(VVb5jS) : return self.VVwiUu
  else            : return self.VVA8Sm
 def VVimwP(self, isFirstTime):
  self.VVSb5j   = os.path.basename(os.path.normpath(self.Path))
  self.VVSb5j   = "_".join(self.VVSb5j.split())
  self.VV1vPT = self.VVSb5j.lower()
  self.VVCyJF = self.VV1vPT == VVQbK6.lower()
  if self.VVCyJF and self.VV1vPT.endswith("ajpan"):
   self.VV1vPT += "el"
  if self.VVCyJF : self.VVdLgj = VVCWNQ
  else    : self.VVdLgj = CFG.packageOutputPath.getValue()
  self.VVdLgj = FFgLfR(self.VVdLgj)
  if not pathExists(self.controlPath):
   os.system(FFOaw3("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVCyJF : t = PLUGIN_NAME
  else    : t = self.VVSb5j
  self.VV8mG7(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVY7i7.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVCyJF : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VV8mG7(self.postrmFile, txt)
  if self.VVCyJF:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VViRxJ)
   self.VV8mG7(self.preinstFile, txt)
  else:
   self.VV8mG7(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVSb5j)
  mode = self.VVjyyr()
  if isFirstTime and not mode == self.VVA8Sm:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVGWwg
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VV8mG7(self.postinstFile, txt, VVKTjd=True)
  os.system(FFOaw3("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVCyJF : version, descripton, maintainer = VViRxJ , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVSb5j , self.VVSb5j
   txt = ""
   txt += "Package: %s\n"  % self.VVi4zs(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VV8mG7(self, path, lines, VVKTjd=False):
  if not fileExists(path) or VVKTjd:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV7YNW(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFVFca(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFNe7q(line, VVao2g)
     elif not line.startswith(" ")    : line = FFNe7q(line, VVao2g)
     else          : line = FFNe7q(line, VV1Zj2)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV1Zj2
   else   : color = VVao2g
   descr = FFNe7q(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVao2g
     elif line.startswith((" ", "\t")) : color = VVao2g
     elif line.startswith("#")   : color = VVPZsu
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVBc8z(val, True)
      elif key == "Version"  : version, color = self.VVBc8z(val, False)
      elif key == "Maintainer" : maint  , color = val, VV1Zj2
      elif key == "Architecture" : arch  , color = val, VV1Zj2
      else:
       color = VV1Zj2
      if not key == "OE" and not key.istitle():
       color = VVao2g
     else:
      color = VVix4Z
     txt += FFNe7q(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVJGgR = self.VVdLgj + packageName
   self.VV6XU9 = True
   errTxt = ""
  else:
   self.VVJGgR  = ""
   self.VV6XU9 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVBc8z(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV1Zj2
  else          : return val, VVao2g
 def VVn49G(self):
  if not self.VV6XU9:
   FF3mKe(self, "Please fix Control File errors first.")
   return
  if self.VV6C6C: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFLTn7(self.VVmIB3, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVSb5j
  symlinkTo  = FFgg7n(self.Path)
  dataDir   = self.VVmIB3.rstrip("/")
  removePorjDir = FFOaw3("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFOaw3("rm -f '%s'" % self.VVJGgR) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFx0RW()
  if self.VV6C6C:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFvwoj("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVCyJF:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVmIB3 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVCq6B)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVJGgR, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVJGgR
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVJGgR, FFXkoO(result  , VVHsWS))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVmIB3, FFXkoO(instPath, VV1Zj2))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFXkoO(failed, VVao2g))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFH6Oq(self, cmd)
class CCXbmU(Screen):
 VVM2wS   = 0
 VVoyZj  = 1
 VVzsqz = 20
 def __init__(self, session, VVg2QG="/", mode=VVM2wS, VV8bKI="Select", VV3p9i=30):
  self.skin, self.skinParam = FFOSVY(VVyfFI, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFxmEB(self)
  FFHCfw(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV8bKI = VV8bKI
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVM2wS  : VVNaNP, self.VVg2QG = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVoyZj : VVNaNP, self.VVg2QG = False, VVg2QG
  else           : VVNaNP, self.VVg2QG = True , VVg2QG
  VVg2QG = FFgLfR(VVg2QG)
  self["myMenu"] = CCPfds(  directory   = "/"
         , VVNaNP   = VVNaNP
         , VVeDZj = True
         , VVIuAo   = self.skinParam["width"]
         , VV3p9i   = self.skinParam["bodyFontSize"]
         , VV6w1K  = self.skinParam["bodyLineH"]
         , VV6hwG  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV0W2R      ,
   "cancel"   : self.cancel      ,
   "green"    : self.VVYgaC    ,
   "yellow"   : self.VV4oIN   ,
   "blue"    : self.VVcpYW   ,
   "menu"    : self.VVDFz9    ,
   "info"    : self.VVD55S    ,
   "pageUp"   : self.VVVv9x     ,
   "chanUp"   : self.VVVv9x
  }, -1)
  FF1t9f(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVwPOA)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVwPOA)
  FFWhRj(self["myMenu"], bg="#06003333")
  FFZ8sT(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VVoyZj:
   FFHCfw(self["keyGreen"], self.VV8bKI)
   color = "#22000022"
   FFGQmF(self["myBody"], color)
   FFGQmF(self["myMenu"], color)
   color = "#22220000"
   FFGQmF(self["myTitle"], color)
   FFGQmF(self["myBar"], color)
  self.VVwPOA()
  if self.VVDGmD(self.VVg2QG) > self.bigDirSize:
   FFK43o(self, "Changing directory...")
   FFk91F(self.VVxbVH)
  else:
   self.VVxbVH()
 def VVxbVH(self):
  self["myMenu"].VVKgSC(self.VVg2QG)
 def VVUG0y(self):
  self["myMenu"].refresh()
  FF776W()
 def VVDGmD(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VV0W2R(self):
  if self["myMenu"].VVvVwX():
   path = self.VVUPRN(self.VVEOjr())
   if self.VVDGmD(path) > self.bigDirSize:
    FFK43o(self, "Changing directory...")
    FFk91F(self.VVDeIP)
   else:
    self.VVDeIP()
  else:
   self.VVZCLv()
 def VVDeIP(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVwPOA()
 def VVVv9x(self):
  if self["myMenu"].VVNmdA():
   self["myMenu"].moveToIndex(0)
   self.VVDeIP()
 def cancel(self):
  if not FFJJe1(self):
   self.close("")
 def VVYgaC(self):
  if self.mode == self.VVoyZj:
   path = self.VVUPRN(self.VVEOjr())
   self.close(path)
 def VVD55S(self):
  FFapsE(self, self.VVstxi, title="Calculating size ...")
 def VVstxi(self):
  path = self.VVUPRN(self.VVEOjr())
  param = self.VVI7T2(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFVfkZ("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFVfkZ("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVkamb(size), format(size, ',d'))
   else   : size = "%s" % self.VVkamb(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFNe7q(pathTxt, VVix4Z) + "\n"
   if slBroken : fileTime = self.VVGelW(path)
   else  : fileTime = self.VVH3Mj(path)
   def VVpVKy(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVpVKy("Path"    , pathTxt)
   txt += VVpVKy("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVpVKy("Target"   , slTarget)
   txt += VVpVKy("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVpVKy("Owner"    , owner)
   txt += VVpVKy("Group"    , group)
   txt += VVpVKy("Perm. (User)"  , permUser)
   txt += VVpVKy("Perm. (Group)"  , permGroup)
   txt += VVpVKy("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVpVKy("Perm. (Ext.)" , permExtra)
   txt += VVpVKy("iNode"    , iNode)
   txt += VVpVKy("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVGWwg, VVGWwg)
    txt += hLinkedFiles
  else:
   FF3mKe(self, "Cannot access information !")
  if len(txt) > 0:
   FFxYUM(self, txt)
 def VVI7T2(self, path):
  path = path.strip()
  path = FFgg7n(path)
  result = FFVfkZ("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVsxRR(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVsxRR(perm, 1, 4)
   permGroup = VVsxRR(perm, 4, 7)
   permOther = VVsxRR(perm, 7, 10)
   permExtra = VVsxRR(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFoQiW("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVH3Mj(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF2W46(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF2W46(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF2W46(os.path.getctime(path))
  return txt
 def VVGelW(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFVfkZ("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFVfkZ("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFVfkZ("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVkamb(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVUPRN(self, currentSel):
  currentDir  = self["myMenu"].VVNmdA()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVvVwX():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVEOjr(self):
  return self["myMenu"].getSelection()[0]
 def VVwPOA(self):
  FFK43o(self)
  path = self.VVUPRN(self.VVEOjr())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV26yB = self.VVzSMt()
  if VV26yB and len(VV26yB) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVuOft(path)
  if self.mode == self.VVM2wS and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVuOft(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VV5pCT(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVDFz9(self):
  if self.mode == self.VVM2wS:
   path  = self.VVUPRN(self.VVEOjr())
   isDir  = os.path.isdir(path)
   VVTikG = []
   VVTikG.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVgNok(path):
     sepShown = True
     VVTikG.append(VVK4l8)
     VVTikG.append( (VVix4Z + "Archiving / Packaging"      , "VVqVdR"  ))
    if self.VVyRiR(path):
     if not sepShown:
      VVTikG.append(VVK4l8)
     VVTikG.append( (VVix4Z + "Read Backup information"     , "VVG15c"  ))
     VVTikG.append( (VVix4Z + "Compress Octagon Image (to zip File)"  , "VVbONR" ))
   elif os.path.isfile(path):
    selFile = self.VVEOjr()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVTikG.extend(self.VVEXrX(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVTikG.extend(self.VVo4If(True))
    elif selFile.endswith(".m3u")              : VVTikG.extend(self.VVUffE(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFhl50(path):
     VVTikG.append(VVK4l8)
     VVTikG.append((VVix4Z + "View" , "text_View" ))
     VVTikG.append((VVix4Z + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVTikG.append(VVK4l8)
     VVTikG.append(   (VVix4Z + txt      , "VVZCLv"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append(     ("Create SymLink"       , "VVMVRY" ))
   if not self.VVgNok(path):
    VVTikG.append(   ("Rename"          , "VVFrPx" ))
    VVTikG.append(   ("Copy"           , "copyFileOrDir" ))
    VVTikG.append(   ("Move"           , "moveFileOrDir" ))
    VVTikG.append(   ("DELETE"          , "VVLJLt" ))
    if fileExists(path):
     VVTikG.append(VVK4l8)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVTikG.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVTikG.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVTikG.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVTikG.append(VVK4l8)
   VVTikG.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVTikG.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVTikG.append(VVK4l8)
   VVTikG.append(    ("Set current directory as \"Startup Path\"" , "VVSjDI" ))
   FFh3ra(self, self.VVY7ff, title="Options", VVTikG=VVTikG)
 def VVY7ff(self, item=None):
  if self.mode == self.VVM2wS:
   if item is not None:
    path = self.VVUPRN(self.VVEOjr())
    selFile = self.VVEOjr()
    if   item == "properties"    : self.VVD55S()
    elif item == "VVqVdR"  : self.VVqVdR(path)
    elif item == "VVG15c"  : self.VVG15c(path)
    elif item == "VVbONR" : self.VVbONR(path)
    elif item.startswith("extract_")  : self.VVAdmB(path, selFile, item)
    elif item.startswith("script_")   : self.VV7wSN(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVElZwItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FF9reT(self, path)
    elif item.startswith("text_Edit")  : CCrET4(self, path)
    elif item == "chmod644"     : self.VVmVCR(path, selFile, "644")
    elif item == "chmod755"     : self.VVmVCR(path, selFile, "755")
    elif item == "chmod777"     : self.VVmVCR(path, selFile, "777")
    elif item == "VVMVRY"   : self.VVMVRY(path, selFile)
    elif item == "VVFrPx"   : self.VVFrPx(path, selFile)
    elif item == "copyFileOrDir"   : self.VVuA4B(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVuA4B(path, selFile, True)
    elif item == "VVLJLt"   : self.VVLJLt(path, selFile)
    elif item == "createNewFile"   : self.VVYWU3(path, True)
    elif item == "createNewDir"    : self.VVYWU3(path, False)
    elif item == "VVSjDI"   : self.VVSjDI(path)
    elif item == "VVZCLv"    : self.VVZCLv()
    else         : self.close()
 def VVZCLv(self):
  selFile = self.VVEOjr()
  path  = self.VVUPRN(selFile)
  if os.path.isfile(path):
   VVzSps = []
   category = self["myMenu"].VVjioU(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVOHwN(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFqol5(self, selFile, path)
   elif category == "txt"         : FF9reT(self, path)
   elif category in ("tar", "zip")       : self.VVtLNJ(path, selFile)
   elif category == "scr"         : self.VVcg5v(path, selFile)
   elif category == "m3u"         : self.VVuSGl(path, selFile)
   elif category in ("ipk", "deb")       : self.VVWNk3(path, selFile)
   elif category == "mus"         : self.VVhoR5(path)
   elif category == "mov"         : self.VVhoR5(path)
   elif not FFhl50(path)        : FF9reT(self, path)
 def VVhoR5(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFHTCm(self, refCode)
  except:
   pass
 def VV4oIN(self):
  path = self.VVUPRN(self.VVEOjr())
  action = self.VVuOft(path)
  if action == 1:
   self.VV2ak0(path)
   FFK43o(self, "Added", 500)
  elif action == -1:
   self.VVXeyf(path)
   FFK43o(self, "Removed", 500)
  self.VVuOft(path)
 def VV2ak0(self, path):
  VV26yB = self.VVzSMt()
  if not VV26yB:
   VV26yB = []
  if len(VV26yB) >= self.VVzsqz:
   FF3mKe(SELF, "Max bookmarks reached (max=%d)." % self.VVzsqz)
  elif not path in VV26yB:
   VV26yB = [path] + VV26yB
   self.VV2QW7(VV26yB)
 def VVcpYW(self):
  VV26yB = self.VVzSMt()
  if VV26yB:
   newList = []
   for line in VV26yB:
    newList.append((line, line))
   VVr7QF  = ("Delete"  , self.VVH5P2 )
   VVmqZr = ("Move Up"   , self.VV5kId )
   VViuu9  = ("Move Down" , self.VVQy7b )
   self.bookmarkMenu = FFh3ra(self, self.VVYEBF, title="Bookmarks", VVTikG=newList, VVr7QF=VVr7QF, VVmqZr=VVmqZr, VViuu9=VViuu9)
 def VVH5P2(self, VVEOjrObj, path):
  if self.bookmarkMenu:
   VV26yB = self.VVXeyf(path)
   self.bookmarkMenu.VVlVEa(VV26yB)
 def VV5kId(self, VVEOjrObj, path):
  if self.bookmarkMenu:
   VV26yB = self.bookmarkMenu.VVK0dL(True)
   if VV26yB:
    self.VV2QW7(VV26yB)
 def VVQy7b(self, VVEOjrObj, path):
  if self.bookmarkMenu:
   VV26yB = self.bookmarkMenu.VVK0dL(False)
   if VV26yB:
    self.VV2QW7(VV26yB)
 def VVYEBF(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVKgSC(folder)
   self["myMenu"].moveToIndex(0)
  self.VVwPOA()
 def VVzSMt(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VV5pCT(self, path):
  VV26yB = self.VVzSMt()
  if VV26yB and path in VV26yB:
   return True
  else:
   return False
 def VVzfwe(self):
  if VVzSMt():
   return True
  else:
   return False
 def VV2QW7(self, VV26yB):
  line = ",".join(VV26yB)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVXeyf(self, path):
  VV26yB = self.VVzSMt()
  if VV26yB:
   while path in VV26yB:
    VV26yB.remove(path)
   self.VV2QW7(VV26yB)
   return VV26yB
 def VVSjDI(self, path):
  if not os.path.isdir(path):
   path = FFLTn7(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVOHwN(self, selFile, VVN4XI, command):
  FFAuNs(self, boundFunction(FFH6Oq, self, command, VV3dyz=self.VVUG0y), "%s\n\n%s" % (VVN4XI, selFile))
 def VVEXrX(self, path, calledFromMenu):
  destPath = self.VVbBia(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVTikG = []
  if calledFromMenu:
   VVTikG.append(VVK4l8)
   color = VVix4Z
  else:
   color = ""
  VVTikG.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVTikG.append(VVK4l8)
  VVTikG.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVTikG.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVTikG.append((color + "Extract Here"            , "extract_here"  ))
  if VVn7sl and path.endswith(".tar.gz"):
   VVTikG.append(VVK4l8)
   VVTikG.append((color + 'Convert to ".ipk" Package' , "VVFBFE"  ))
   VVTikG.append((color + 'Convert to ".deb" Package' , "VVuPBh"  ))
  return VVTikG
 def VVtLNJ(self, path, selFile):
  FFh3ra(self, boundFunction(self.VVAdmB, path, selFile), title="Tar File Options", VVTikG=self.VVEXrX(path, False))
 def VVAdmB(self, path, selFile, item=None):
  if item is not None:
   parent  = FFLTn7(path, False)
   destPath = self.VVbBia(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVGWwg
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVGWwg, VVGWwg)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FF0iLg(self, cmd)
   elif path.endswith(".zip"):
    self.VV8dMO(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFOaw3("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVOHwN(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVOHwN(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFLTn7(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVOHwN(selFile, "Extract Here ?"      , cmd)
   elif item == "VVFBFE" : self.VVFBFE(path)
   elif item == "VVuPBh" : self.VVuPBh(path)
 def VVbBia(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VV8dMO(self, item, path, parent, destPath, VVN4XI):
  FFAuNs(self, boundFunction(self.VVFCmJ, item, path, parent, destPath), VVN4XI)
 def VVFCmJ(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVGWwg
  cmd  = FFvwoj("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFXkoO(destPath, VVHsWS))
  cmd +=   sep
  cmd += "fi;"
  FFW0Tm(self, cmd, VV3dyz=self.VVUG0y)
 def VVo4If(self, addSep=False):
  VVTikG = []
  if addSep:
   VVTikG.append(VVK4l8)
  VVTikG.append((VVix4Z + "View Script File"  , "script_View"  ))
  VVTikG.append((VVix4Z + "Execute Script File" , "script_Execute" ))
  VVTikG.append((VVix4Z + "Edit"     , "script_Edit" ))
  return VVTikG
 def VVcg5v(self, path, selFile):
  FFh3ra(self, boundFunction(self.VV7wSN, path, selFile), title="Script File Options", VVTikG=self.VVo4If())
 def VV7wSN(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF9reT(self, path)
   elif item == "script_Execute" : self.VVOHwN(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCrET4(self, path)
 def VVUffE(self, addSep=False):
  VVTikG = []
  if addSep:
   VVTikG.append(VVK4l8)
  VVTikG.append((VVix4Z + "View"      , "m3u_View" ))
  VVTikG.append((VVix4Z + "Edit"      , "m3u_Edit" ))
  VVTikG.append((VVix4Z + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVTikG
 def VVuSGl(self, path, selFile):
  FFh3ra(self, boundFunction(self.VVElZwItem_m3u, path, selFile), title="M3U File Options", VVTikG=self.VVUffE())
 def VVElZwItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FF9reT(self, path)
   elif item == "m3u_Edit"  : CCrET4(self, path)
   elif item == "m3u_Convert" : CCn3vN.VV4Xe0(self, path, False)
 def VVmVCR(self, path, selFile, newChmod):
  FFAuNs(self, boundFunction(self.VV33TL, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV33TL(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVX9mL)
  result = FFVfkZ(cmd)
  if result == "Successful" : FFX4bs(self, result)
  else      : FF3mKe(self, result)
 def VVMVRY(self, path, selFile):
  parent = FFLTn7(path, False)
  self.session.openWithCallback(self.VVuKol, boundFunction(CCXbmU, mode=CCXbmU.VVoyZj, VVg2QG=parent, VV8bKI="Create Symlink here"))
 def VVuKol(self, newPath):
  if len(newPath) > 0:
   target = self.VVUPRN(self.VVEOjr())
   target = FFgg7n(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFgLfR(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF3mKe(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFAuNs(self, boundFunction(self.VVgkek, target, link), "Create Soft Link ?\n\n%s" % txt, VVSmS1=True)
 def VVgkek(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVX9mL)
  result = FFVfkZ(cmd)
  if result == "Successful" : FFX4bs(self, result)
  else      : FF3mKe(self, result)
 def VVFrPx(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFCkFz(self, boundFunction(self.VVNEhC, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVNEhC(self, path, selFile, VVD55x):
  if VVD55x:
   parent = FFLTn7(path, True)
   if os.path.isdir(path):
    path = FFgg7n(path)
   newName = parent + VVD55x
   cmd = "mv '%s' '%s' %s" % (path, newName, VVX9mL)
   if VVD55x:
    if selFile != VVD55x:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFAuNs(self, boundFunction(self.VV0Pcj, cmd), message, title="Rename file?")
    else:
     FF3mKe(self, "Cannot use same name!", title="Rename")
 def VV0Pcj(self, cmd):
  result = FFVfkZ(cmd)
  if "Fail" in result:
   FF3mKe(self, result)
  self.VVUG0y()
 def VVuA4B(self, path, selFile, isMove):
  if isMove : VV8bKI = "Move to here"
  else  : VV8bKI = "Copy to here"
  parent = FFLTn7(path, False)
  self.session.openWithCallback(boundFunction(self.VVBV76, isMove, path, selFile)
         , boundFunction(CCXbmU, mode=CCXbmU.VVoyZj, VVg2QG=parent, VV8bKI=VV8bKI))
 def VVBV76(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFgg7n(path)
   newPath = FFgLfR(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFAuNs(self, boundFunction(FFOfw9, self, cmd, VV3dyz=self.VVUG0y), txt, VVSmS1=True)
   else:
    FF3mKe(self, "Cannot %s to same directory !" % action.lower())
 def VVLJLt(self, path, fileName):
  path = FFgg7n(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFAuNs(self, boundFunction(self.VVXZTM, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVXZTM(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVUG0y()
 def VVgNok(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVElr3 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVYWU3(self, path, isFile):
  dirName = FFgLfR(os.path.dirname(path))
  if isFile : objName, VVD55x = "File"  , self.edited_newFile
  else  : objName, VVD55x = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFCkFz(self, boundFunction(self.VVCYHv, dirName, isFile, title), title=title, defaultText=VVD55x, message="Enter %s Name:" % objName)
 def VVCYHv(self, dirName, isFile, title, VVD55x):
  if VVD55x:
   if isFile : self.edited_newFile = VVD55x
   else  : self.edited_newDir  = VVD55x
   path = dirName + VVD55x
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVX9mL)
    else  : cmd = "mkdir '%s' %s" % (path, VVX9mL)
    result = FFVfkZ(cmd)
    if "Fail" in result:
     FF3mKe(self, result)
    self.VVUG0y()
   else:
    FF3mKe(self, "Name already exists !\n\n%s" % path, title)
 def VVWNk3(self, path, selFile):
  VVTikG = []
  VVTikG.append(("List Package Files"          , "VV0rmB"     ))
  VVTikG.append(("Package Information"          , "VVkLqm"     ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Install Package"           , "VVvLIC_CheckVersion" ))
  VVTikG.append(("Install Package (force reinstall)"      , "VVvLIC_ForceReinstall" ))
  VVTikG.append(("Install Package (force downgrade)"      , "VVvLIC_ForceDowngrade" ))
  VVTikG.append(("Install Package (ignore failed dependencies)"    , "VVvLIC_IgnoreDepends" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Remove Related Package"         , "VVMLBT_ExistingPackage" ))
  VVTikG.append(("Remove Related Package (force remove)"     , "VVMLBT_ForceRemove"  ))
  VVTikG.append(("Remove Related Package (ignore failed dependencies)"  , "VVMLBT_IgnoreDepends" ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("Extract Files"           , "VVoHyH"     ))
  VVTikG.append(("Unbuild Package"           , "VVxycL"     ))
  FFh3ra(self, boundFunction(self.VVP1nF, path, selFile), VVTikG=VVTikG)
 def VVP1nF(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV0rmB"      : self.VV0rmB(path, selFile)
   elif item == "VVkLqm"      : self.VVkLqm(path)
   elif item == "VVvLIC_CheckVersion"  : self.VVvLIC(path, selFile, VVgO7i     )
   elif item == "VVvLIC_ForceReinstall" : self.VVvLIC(path, selFile, VVyAfl )
   elif item == "VVvLIC_ForceDowngrade" : self.VVvLIC(path, selFile, VV1VTr )
   elif item == "VVvLIC_IgnoreDepends" : self.VVvLIC(path, selFile, VVvJGF )
   elif item == "VVMLBT_ExistingPackage" : self.VVMLBT(path, selFile, VVE0pE     )
   elif item == "VVMLBT_ForceRemove"  : self.VVMLBT(path, selFile, VV4TK6  )
   elif item == "VVMLBT_IgnoreDepends"  : self.VVMLBT(path, selFile, VVE1tM )
   elif item == "VVoHyH"     : self.VVoHyH(path, selFile)
   elif item == "VVxycL"     : self.VVxycL(path, selFile)
   else           : self.close()
 def VV0rmB(self, path, selFile):
  if FFZA91("ar") : cmd = "allOK='1';"
  else    : cmd  = FFx0RW()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVGWwg, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVGWwg, VVGWwg)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFoqGf(self, cmd, VV3dyz=self.VVUG0y)
 def VVoHyH(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFLTn7(path, True) + selFile[:-4]
  cmd  =  FFx0RW()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFOaw3("mkdir '%s'" % dest) + ";"
  cmd +=    FFOaw3("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFXkoO(dest, VVHsWS))
  cmd += "fi;"
  FFH6Oq(self, cmd, VV3dyz=self.VVUG0y)
 def VVxycL(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV6h9V = os.path.splitext(path)[0]
  else        : VV6h9V = path + "_"
  if path.endswith(".deb")   : VVCq6B = "DEBIAN"
  else        : VVCq6B = "CONTROL"
  cmd  = FFx0RW()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV6h9V, FF2m4A())
  cmd += "  mkdir '%s';"    % VV6h9V
  cmd += "  CONTPATH='%s/%s';"  % (VV6h9V, VVCq6B)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV6h9V
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV6h9V, VV6h9V)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV6h9V
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV6h9V, VV6h9V)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV6h9V
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV6h9V
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV6h9V, FFXkoO(VV6h9V, VVHsWS))
  cmd += "fi;"
  FFH6Oq(self, cmd, VV3dyz=self.VVUG0y)
 def VVkLqm(self, path):
  listCmd  = FFLJQQ(VVabbE, "")
  infoCmd  = FFl4YE(VVg4aK , "")
  filesCmd = FFl4YE(VVdmfG, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFtgPs(VVL19M)
   notInst = "Package not installed."
   cmd  = FFC4in("File Info", VVL19M)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFC4in("System Info", VVL19M)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFXkoO(notInst, VVix4Z))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFC4in("Related Files", VVL19M)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF0iLg(self, cmd)
  else:
   FFYXW3(self)
 def VVvLIC(self, path, selFile, cmdOpt):
  cmd = FFl4YE(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFAuNs(self, boundFunction(FFH6Oq, self, cmd, VV3dyz=FF776W), "Install Package ?\n\n%s" % selFile)
  else:
   FFYXW3(self)
 def VVMLBT(self, path, selFile, cmdOpt):
  listCmd  = FFLJQQ(VVabbE, "")
  infoCmd  = FFl4YE(VVg4aK, "")
  instRemCmd = FFl4YE(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFXkoO(errTxt, VVix4Z))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFXkoO(cannotTxt, VVix4Z))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFXkoO(tryTxt, VVix4Z))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFAuNs(self, boundFunction(FFH6Oq, self, cmd, VV3dyz=FF776W), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFYXW3(self)
 def VVgTDJ(self, path):
  hostName = FFVfkZ("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVyRiR(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVgTDJ(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVqVdR(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVTikG = []
  VVTikG.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVTikG.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVTikG.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVTikG.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVTikG.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVTikG.append(VVK4l8)
  VVTikG.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVTikG.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVTikG.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVTikG.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVTikG.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVTikG.append(VVK4l8)
  VVTikG.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVTikG.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFh3ra(self, boundFunction(self.VVZctG, path), VVTikG=VVTikG)
 def VVZctG(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVMjj0(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVMjj0(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVMjj0(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVMjj0(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVMjj0(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVMjj0(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVMjj0(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVMjj0(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVMjj0(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVMjj0(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVnL8d(path, False)
   elif item == "convertDirToDeb"   : self.VVnL8d(path, True)
   else         : self.close()
 def VVnL8d(self, path, VV6C6C):
  self.session.openWithCallback(self.VVUG0y, boundFunction(CCfmbm, path=path, VV6C6C=VV6C6C))
 def VVMjj0(self, path, fileExt, preserveDirStruct):
  parent  = FFLTn7(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFvwoj("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFvwoj("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFvwoj("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVGWwg
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFOaw3("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFXkoO(resultFile, VVHsWS))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFXkoO(failed, VVao2g))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFoqGf(self, cmd, VV3dyz=self.VVUG0y)
 def VVG15c(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FF9reT(self, versionFile)
 def VVbONR(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVgTDJ(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF3mKe(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFVFca(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFLTn7(path, False)
  VV6h9V = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFXkoO(errCmd, VVao2g))
  installCmd = FFl4YE(VVgO7i , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV6h9V, VV6h9V)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV6h9V
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV6h9V
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV6h9V, VV6h9V)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFH6Oq(self, cmd, VV3dyz=self.VVUG0y)
 def VVFBFE(self, path):
  FF3mKe(self, "Under Construction.")
 def VVuPBh(self, path):
  FF3mKe(self, "Under Construction.")
class CCPfds(MenuList):
 def __init__(self, VVeDZj=False, directory="/", VVGSlW=True, VVNaNP=True, VVLVcl=True, VVgOFP=None, VVWJqb=False, VVpVdU=False, VV8ptM=False, isTop=False, VVRET2=None, VVIuAo=1000, VV3p9i=30, VV6w1K=30, VV6hwG="#00000000"):
  MenuList.__init__(self, list, VVeDZj, eListboxPythonMultiContent)
  self.VVGSlW  = VVGSlW
  self.VVNaNP    = VVNaNP
  self.VVLVcl  = VVLVcl
  self.VVgOFP  = VVgOFP
  self.VVWJqb   = VVWJqb
  self.VVpVdU   = VVpVdU or []
  self.VV8ptM   = VV8ptM or []
  self.isTop     = isTop
  self.additional_extensions = VVRET2
  self.VVIuAo    = VVIuAo
  self.VV3p9i    = VV3p9i
  self.VV6w1K    = VV6w1K
  self.pngBGColor    = FFzmVi(VV6hwG)
  self.EXTENSIONS    = self.VV3H6f()
  self.VVg2N7   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VViB9W, self.VV3p9i))
  self.l.setItemHeight(self.VV6w1K)
  self.png_mem   = self.VVSq5V("mem")
  self.png_usb   = self.VVSq5V("usb")
  self.png_fil   = self.VVSq5V("fil")
  self.png_dir   = self.VVSq5V("dir")
  self.png_dirup   = self.VVSq5V("dirup")
  self.png_srv   = self.VVSq5V("srv")
  self.png_slwfil   = self.VVSq5V("slwfil")
  self.png_slbfil   = self.VVSq5V("slbfil")
  self.png_slwdir   = self.VVSq5V("slwdir")
  self.VVBNMW()
  self.VVKgSC(directory)
 def VVSq5V(self, category):
  return LoadPixmap("%s%s.png" % (VVuSNJ, category), getDesktop(0))
 def VV3H6f(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVTLZQ(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFgg7n(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFNe7q(" -> " , VVL19M) + FFNe7q(os.readlink(path), VVHsWS)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV6w1K + 10, 0, self.VVIuAo, self.VV6w1K, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVrXo2: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV6w1K-4, self.VV6w1K-4, png, self.pngBGColor, self.pngBGColor, VVrXo2))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV6w1K-4, self.VV6w1K-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVjioU(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVBNMW(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVINQP(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVMT9y(self, file):
  if os.path.realpath(file) == file:
   return self.VVINQP(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVINQP(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVINQP(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVcKcZ(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVg2N7.info(l[0][0]).getEvent(l[0][0])
 def VVcDzs(self):
  return self.list
 def VVL9C4(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVKgSC(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVLVcl:
    self.current_mountpoint = self.VVMT9y(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVLVcl:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VV8ptM and not self.VVL9C4(path, self.VVpVdU):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVTLZQ(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVWJqb:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVg2N7 = eServiceCenter.getInstance()
   list = VVg2N7.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVGSlW and not self.isTop:
   if directory == self.current_mountpoint and self.VVLVcl:
    self.list.append(self.VVTLZQ(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VV8ptM and self.VVINQP(directory) in self.VV8ptM):
    self.list.append(self.VVTLZQ(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVGSlW:
   for x in directories:
    if not (self.VV8ptM and self.VVINQP(x) in self.VV8ptM) and not self.VVL9C4(x, self.VVpVdU):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVTLZQ(name = name, absolute = x, isDir = True, png = png))
  if self.VVNaNP:
   for x in files:
    if self.VVWJqb:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFNe7q(" -> " , VVL19M) + FFNe7q(target, VVHsWS)
       else:
        png = self.png_slbfil
        name += FFNe7q(" -> " , VVL19M) + FFNe7q(target, VVao2g)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVjioU(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVuSNJ, category))
    if (self.VVgOFP is None) or iCompile(self.VVgOFP).search(path):
     self.list.append(self.VVTLZQ(name = name, absolute = x , isDir = False, png = png))
  if self.VVLVcl and len(self.list) == 0:
   self.list.append(self.VVTLZQ(name = FFNe7q("No USB connected", VVPZsu), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVNmdA(self):
  return self.current_directory
 def VVvVwX(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVKgSC(self.getSelection()[0], select = self.current_directory)
 def VVeNCD(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVJ2E4(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVoEtr)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVoEtr)
 def refresh(self):
  self.VVKgSC(self.current_directory, self.VVeNCD())
 def VVoEtr(self, action, device):
  self.VVBNMW()
  if self.current_directory is None:
   self.refresh()
class CCePyp(ScrollLabel):
 def __init__(self, parentSELF, text="", VVz958=True):
  ScrollLabel.__init__(self, text)
  self.VVz958=VVz958
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVTiYq  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VV3p9i    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVq2Hh   ,
   "green"   : self.VV0yGI  ,
   "yellow"  : self.VVIeHn  ,
   "blue"   : self.VVGh0m  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVKBTA    ,
   "chanUp"  : self.VVKBTA    ,
   "pageDown"  : self.VV5bNr    ,
   "chanDown"  : self.VV5bNr
  }, -1)
 def VVqvJx(self, isResizable=True, VVcEvx=False, enableSave=False):
  if enableSave:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFZ8sT(self.parentSELF, True)
  self.isResizable = isResizable
  if VVcEvx:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VV3p9i  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFGQmF(self, color)
 def FFGQmFColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVTiYq - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVLYoP()
 def pageUp(self):
  if self.VVTiYq > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVTiYq > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVKBTA(self):
  self.setPos(0)
 def VV5bNr(self):
  self.setPos(self.VVTiYq-self.pageHeight)
 def VVn5Vz(self):
  return self.VVTiYq <= self.pageHeight or self.curPos == self.VVTiYq - self.pageHeight
 def VVLYoP(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVTiYq, 3))
   start = int((100 - vis) * self.curPos / (self.VVTiYq - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVLxmM=VVsweO):
  old_VVn5Vz = self.VVn5Vz()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVTiYq = self.long_text.calculateSize().height()
   if self.VVz958 and self.VVTiYq > self.pageHeight:
    self.scrollbar.show()
    self.VVLYoP()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVTiYq))
   if   VVLxmM == VVJGAZ: self.setPos(0)
   elif VVLxmM == VVafWR : self.VV5bNr()
   elif old_VVn5Vz    : self.VV5bNr()
 def appendText(self, text, VVLxmM=VVafWR):
  self.setText(self.message + str(text), VVLxmM)
 def VVIeHn(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV88X7(size)
 def VVGh0m(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV88X7(size)
 def VV0yGI(self):
  self.VV88X7(self.VV3p9i)
 def VV88X7(self, VV3p9i):
  self.long_text.setFont(gFont(self.fontFamily, VV3p9i))
  self.setText(self.message, VVLxmM=VVsweO)
  self.VVWwRD(calledFromFontSizer=True)
 def VVq2Hh(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "Save to File"
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_Info_%s.txt" % (FFgLfR(expPath), FFJ142())
    with open(outF, "w") as f:
     f.write(FFIQzg(self.message))
    FFX4bs(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF3mKe(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVWwRD(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVTiYq > 0 and self.pageHeight > 0:
   if self.VVTiYq < self.pageHeight * 0.8:
    self.setText("\n" + self.message.strip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVTiYq
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
