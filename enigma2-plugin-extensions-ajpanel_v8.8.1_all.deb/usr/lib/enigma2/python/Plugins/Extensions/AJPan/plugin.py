import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVFo84   = "v8.8.1"
VVDVa8    = "16-03-2023"
EASY_MODE    = 0
VVfRPv   = 0
TEST_FUNCTION   = 0
VVzry0  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVATu0  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVUQHY    = "/media/usb/"
VVgtjL    = "/usr/share/enigma2/picon/"
VV05KA = "/etc/enigma2/blacklist"
VVGMYl   = "/etc/enigma2/"
VVsYl4   = "AJPan"
VVpkJd  = "AUTO FIND"
VV9ZmY  = "Custom"
VVlCmV  = None
VVtufY    = ""
VVgWB4 = "Regular"
VV2B3N = "Fixed"
VVWiAM  = "AJP_Main"
VVz0ti = "AJP_Terminal"
VVVf82 = "AJP_System"
VVczsY  = VVgWB4
VVU0bd    = ""
VVYXrW   = " && echo 'Successful' || echo 'Failed!'"
VVLdCF  = "Cannot continue (No Enough Memory) !"
VVVNZR  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVyU28    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVjOGl  = "utf8"
VVJKCZ    = ("-" * 100, )
SEP      = "-" * 80
VVS9jK  = False
VVWEgS  = False
VVzryP     = 0
VVJOxT    = 1
VVbHtF    = 2
VVtyom   = 3
VVJsvf    = 4
VV4GaE    = 5
VVJPgr = 6
VVDjOq = 7
VVDaED  = 8
VVR8Wn   = 9
VV9TYj  = 10
VVwLpo  = 11
VV8zMg = 12
VVwv41 = 13
VV3yNV = 14
VV1wqm  = 15
VVtlKb    = 16
VVHtTB   = 17
VVsFyt   = 18
VVCTW9    = 19
VVjGxK    = 20
VVQVkn  = 21
VVS1Zw    = 22
VVb3Z6   = 0
VVy5UE   = 1
VVlBOt   = 2
def FFZ5LC():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVczsY
  if VVWiAM in lst and CFG.fontPathMain.getValue(): VVczsY = VVWiAM
  else               : VVczsY = VVgWB4
  return lst
 else:
  return [VVgWB4]
def FFkKOE(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVjOGl)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVpkJd, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVgtjL, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVUQHY, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVczsY, choices=[(x,  x) for x in FFZ5LC()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFqzWR():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV1ZPW  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVcSqv = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV1ZPW  : return 0
  elif VVcSqv : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVowRJ = FFqzWR()
VVwos9 = VVBhz1 = VV8a8m = VVO7vL = VVUS1a = VVQrak = VV0HZq = VVHovR = VVRTFm = VVFWDt = VVRkew = VVPr8g = VVJTsP = VVqWCE = VV7CTN = VV15Fs = ""
def FFnOLe()  : FFVjH2(FFxtyD())
def FFnwKS()  : FFVjH2(FFulxf())
def FFAops(tDict): FFVjH2(iDumps(tDict, indent=4, sort_keys=True))
def FF4LpY(*args): FFPMT5(True, True, *args)
def FFVjH2(*args) : FFPMT5(True , False , *args)
def FFyNME(*args): FFPMT5(False, False, *args)
def FFPMT5(addSep=True, isArray=True, *args):
 if VVfRPv:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFG5r9(fnc):
 def VVrahD(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFVjH2(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVrahD
def FFIQaG(*args):
 if VVfRPv:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFyNME("Added to : %s" % path)
def FFjTvT(txt, isAppend=True, ignoreErr=False):
 if VVfRPv:
  tm = FF84Fc()
  err = ""
  if not ignoreErr:
   err = FFulxf()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFVjH2(err)
  FFVjH2("Output Log File : %s" % fileName)
def FFulxf():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF84Fc()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFxtyD():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVFlS7 = 0
def FF82UA():
 global VVFlS7
 VVFlS7 = iTime()
def FFJS0C(txt=""):
 FFVjH2(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVFlS7)).rstrip("0"), txt))
VV1FRX = []
def FF1Sqn(win):
 global VV1FRX
 if not win in VV1FRX:
  VV1FRX.append(win)
def FF9KFt(*args):
 global VV1FRX
 for win in VV1FRX:
  try:
   win.close()
  except:
   pass
 VV1FRX = []
def FFoVhu(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFT9Kj():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVzxT6 = FFT9Kj()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFQOR3()    : return PluginDescriptor(fnc=FFMV3Q, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFZMtn()      : return getDescriptor(FFZGk7 , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFuRcE()     : return getDescriptor(FFnFh1  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFOkt8()  : return getDescriptor(FFjdrd, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF6diQ() : return getDescriptor(FFesi7 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFakr7()  : return getDescriptor(FFqNts , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFcahA()  : return getDescriptor(FFvkyG  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFIWpg() : return getDescriptor(FFdjj0 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FFGZOS()      : return getDescriptor(FFQ6zb, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFuRcE() , FFZMtn() , FFQOR3() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFOkt8())
  result.append(FF6diQ())
  result.append(FFakr7())
  result.append(FFcahA())
  result.append(FFIWpg())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFGZOS())
 return result
def FFMV3Q(reason, **kwargs):
 if reason == 0:
  CC7rkQ.VVGg8g()
  if "session" in kwargs:
   session = kwargs["session"]
   FFMQ2t(session)
   CCjnCh(session)
def FFZGk7(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFnFh1, PLUGIN_NAME, 45)]
 else:
  return []
def FFnFh1(session, **kwargs):
 session.open(Main_Menu)
def FFjdrd(session, **kwargs): session.open(CCLSXF)
def FFesi7(session, **kwargs) : session.open(CC3ZOl)
def FFqNts(session, **kwargs) : CCGzpp.VVfWLm(session)
def FFvkyG(session, **kwargs)  : FFR4Pq(session, reopen=True)
def FFdjj0(session, **kwargs) : session.open(CCwp6k)
def FFQ6zb(session, **kwargs):
 session.open(CCY1HC, fncMode=CCY1HC.VVbVB0)
def FFs1eH():
 FFHUEO(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFOkt8(), FF6diQ(), FFakr7(), FFcahA(), FFIWpg()])
 FFHUEO(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFGZOS() ])
def FFHUEO(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFMQ2t(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFYETT, session, "lok")
 hk.actions["longCancel"]= BF(FFYETT, session, "lesc")
 hk.actions["longRed"] = BF(FFYETT, session, "lred")
 for k in (CC4Zpg.VVcAua, CC4Zpg.VVDQvM, CC4Zpg.VV9to0):
  hk.actions[k] = BF(CC4Zpg.VVAvuS, session, k)
def FFYETT(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCI10Q.VVnf3Q:
    CCI10Q.VVnf3Q.close()
   if not CCGzpp.VVRINw:
    CCGzpp.VVfWLm(session)
  except:
   pass
def FF3Ual(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFk1xo(SELF, title="", addLabel=False, addScrollLabel=False, VVutlQ=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFfwaK()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVHXst = eTimer()
 try: SELF.VV4XRa = SELF.VVHXst.timeout.connect(BF(FFri7G, SELF))
 except: SELF.VVHXst.callback.append(BF(FFri7G, SELF))
 SELF.onClose.append(SELF.VVHXst.stop)
 FFri7G(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCbd2t(SELF)
 if VVutlQ:
  SELF["myMenu"] = MenuList(VVutlQ)
  SELF["myActionMap"] = ActionMap(VVyU28,
  {
   "ok" : SELF.VVQHyQ ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VVyU28,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFCRhg(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFE1ST, SELF, "0"),
  "1" : BF(FFE1ST, SELF, "1"),
  "2" : BF(FFE1ST, SELF, "2"),
  "3" : BF(FFE1ST, SELF, "3"),
  "4" : BF(FFE1ST, SELF, "4"),
  "5" : BF(FFE1ST, SELF, "5"),
  "6" : BF(FFE1ST, SELF, "6"),
  "7" : BF(FFE1ST, SELF, "7"),
  "8" : BF(FFE1ST, SELF, "8"),
  "9" : BF(FFE1ST, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFSYA1, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFE1ST(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV15Fs:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV15Fs + SELF.keyPressed + VVBhz1)
    txt = VVBhz1 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFhSFw(SELF, txt)
def FFSYA1(SELF, tableObj, colNum, isMenu):
 FFhSFw(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFLAHl(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VV75it(i)
     else  : SELF.VVfMAJ(i)
     break
 except:
  pass
def FFfwaK():
 return ("  %s" % VVU0bd)
def FFWr7z(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFLAHl(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFkpAV(color):
 return parseColor(color).argb()
def FFBD6G(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFiva8(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFfsD7(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFLPjB(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV15Fs)
 else:
  return ""
def FFm5eu(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VV15Fs)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FF0D7j(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV15Fs
def FFGl7m(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFLPjB(SEP, VVRkew))
 else : return "echo -e '%s';" % SEP
def FFl9yk(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FF0D7j(title, color)
def FFRLsp(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF7qfI(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFciRl(fncCB):
 tCons = CC4u2A()
 tCons.ePopen(":", BF(FFCLjR, fncCB))
def FFCLjR(fncCB, result, retval):
 fncCB()
def FFVvl9(SELF, fnc, title="Processing ...", clearMsg=True):
 FFhSFw(SELF, title)
 tCons = CC4u2A()
 tCons.ePopen(":", BF(FFnSBg, SELF, fnc, clearMsg))
def FFnSBg(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFhSFw(SELF)
def FFt7KC(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVLdCF
  else       : return ""
def FFlfx8(cmd):
 txt = FFt7KC(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FF7jZM(cmd):
 lines = FFlfx8(cmd)
 if lines: return lines[0]
 else : return ""
def FFKENU(SELF, cmd):
 lines = FFlfx8(cmd)
 VV796F = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV796F.append((key, val))
  elif line:
   VV796F.append((line, ""))
 if VV796F:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFvfpt(SELF, None, header=header, VVUel6=VV796F, VVFNzW=widths, VVH0vt=28)
 else:
  FFrGZ9(SELF, cmd)
def FF2ufE(cmd):
 return os.system(FFYhY6(cmd)) == 0
def FFIapl(cmd):
 return os.system(FF2F4M(cmd)) == 0
def FFYhY6(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FF2F4M(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFrGZ9(    SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, VV5TVy=True, VVognF=VVy5UE, **kwargs)
def FFPlAt(  SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, **kwargs)
def FFmUBH(   SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, VVjC3w=True, VVjMdX=True, VVognF=VVy5UE, **kwargs)
def FF6W91(  SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, VVjC3w=True, VVjMdX=True, VVognF=VVlBOt, **kwargs)
def FF9pl1(  SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, VVKCNR=True , **kwargs)
def FFareT(  session, cmd, **kwargs):      session.open(CCIEmq, VVNDa4=cmd, VVKCNR=True , **kwargs)
def FFoYdL( SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, VVhnmM=True   , **kwargs)
def FFbwen( SELF, cmd, **kwargs): SELF.session.open(CCIEmq, VVNDa4=cmd, VV89vt=True  , **kwargs)
def FFVjaP(cmd):
 return FF2ufE("which %s" % cmd)
def FF3UQa():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FF7jZM(cmd)
def FFNOMj(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVy8pU     = 0
VVUphI      = 1
VVf00o   = 2
VVadqV   = 3
VV7ZXX      = 4
VV3lW5      = 5
VVI3NW     = 6
VVQqp7     = 7
VVtZiS     = 8
VVpQG6 = 9
VVaEyM = 10
VVobz0 = 11
VVbZpU  = 12
VVRTxu     = 13
VVHJv5  = 14
VV472U  = 15
def FFwyvS(parmNum, grepTxt):
 if   parmNum == VVy8pU  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVUphI   : param = ["list"   , "apt list"    ]
 elif parmNum == VVf00o: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVadqV: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FF3UQa()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFciUY(parmNum, package):
 if   parmNum == VV7ZXX      : param = ["info"      , "apt show"         ]
 elif parmNum == VV3lW5      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVI3NW     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVQqp7     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVtZiS     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVpQG6 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVaEyM : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVobz0 : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVbZpU  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVRTxu     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVHJv5  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV472U  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF3UQa()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF8IJx():
 result = FF7jZM("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFciUY(VVtZiS, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFYhY6("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFYhY6("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFLPjB(failed1, VVRkew))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFLPjB(failed2, VVRkew))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFLPjB(failed3, VV8a8m))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFaZl2(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFciUY(VVtZiS , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFYhY6("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFLPjB(failed1, VVRkew))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFLPjB(failed2, VV8a8m))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFXk75(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCDQtT.VVZrBR()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF6UEw(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFXk75(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFc1hL(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFrMJ0(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFXk75(path, maxSize=maxSize, encLst=encLst)
  if lines: FFEso0(SELF, lines, title=title, VVognF=VVy5UE, width=1600, height=1000, titleFontSize=30)
  else : FFBhlv(SELF, path, title=title)
 else:
  FFvsvw(SELF, path, title)
def FF1D9G(SELF, fName, title):
 path = VV8pP1 + fName
 if fileExists(path):
  txt = FFXk75(path)
  txt = txt.replace("#W#", VV15Fs)
  txt = txt.replace("#Y#", VVPr8g)
  txt = txt.replace("#G#", VVBhz1)
  txt = txt.replace("#C#", VVJTsP)
  txt = txt.replace("#P#", VVUS1a)
  FFEso0(SELF, txt, title=title)
 else:
  FFvsvw(SELF, path, title)
def FFeMpE(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFiGD2(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFqvjY(parent)
 else    : return FFHx8R(parent)
def FFY1Mj(path):
 return os.path.basename(os.path.normpath(path))
def FFiHF8(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFrMJ0(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFAjaE(path):
 path = FFHx8R(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFRJjL(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFldVs(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFEUy9(path):
 try: os.remove(path)
 except: pass
def FFViMr(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFEYIA(path):
 return FF2ufE("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FF7q9A(path):
 return FF2ufE("cp -f '%s' '%s.bak'" % (path, path))
def FFqvjY(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFHx8R(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFqUbU():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVzry0)
 paths.append(VVzry0.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFeMpE(ba)
 for p in list:
  p = ba + p + VVzry0
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVsYl4, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVzry0, VVsYl4 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV5jqn, VV8pP1 = FFqUbU()
def FFlcwU():
 def VVCuy5(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVKhOZ   = VVCuy5(CFG.backupPath, CCpO9T.VVQhPB())
 VVcxZ1   = VVCuy5(CFG.downloadedPackagesPath, t)
 VVUBM8  = VVCuy5(CFG.exportedTablesPath, t)
 VVkgxO  = VVCuy5(CFG.exportedPIconsPath, t)
 VVBnUq   = VVCuy5(CFG.packageOutputPath, t)
 global VVUQHY
 VVUQHY = FFqvjY(CFG.backupPath.getValue())
 if VVKhOZ or VVBnUq or VVcxZ1 or VVUBM8 or VVkgxO or oldMovieDownloadPath:
  configfile.save()
 return VVKhOZ, VVBnUq, VVcxZ1, VVUBM8, VVkgxO, oldMovieDownloadPath
def FF6tJG(path):
 path = FFHx8R(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFe2gd(SELF, pathList, tarFileName, addTimeStamp=True):
 VVUel6 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVUel6.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVUel6.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVUel6.append(path)
 if not VVUel6:
  FF9Njt(SELF, "Files not found!")
 elif not pathExists(VVUQHY):
  FF9Njt(SELF, "Path not found!\n\n%s" % VVUQHY)
 else:
  VVdjLk = FFqvjY(VVUQHY)
  tarFileName = "%s%s" % (VVdjLk, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFKX94())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVUel6:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFLPjB(tarFileName, VVRTFm))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFLPjB(failed, VVRTFm))
  cmd += "fi;"
  cmd +=  sep
  FFPlAt(SELF, cmd)
def FFqFdY(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFHeVW(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFHeVW(SELF["keyInfo"], "info")
def FFHeVW(barObj, fName):
 path = "%s%s%s" % (VV8pP1, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFh9n9(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FF1Q1b(satNum)
  return satName
def FF1Q1b(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFjfzk(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFh9n9(val)
  else  : sat = FF1Q1b(val)
 return sat
def FFv6HB(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFh9n9(num)
 except:
  pass
 return sat
def FFRZJT(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFi1IN(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF78Jk(info, iServiceInformation.sServiceref)
   prov = FF78Jk(info, iServiceInformation.sProvider)
   state = str(FF78Jk(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF4MQW(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFYUp6(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF78Jk(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFFMIK(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FF8eVo(refCode):
 info = FFla35(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFkXXp(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFzUm6(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFla35(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV0WM0 = eServiceCenter.getInstance()
  if VV0WM0:
   info = VV0WM0.info(service)
 return info
def FFlpKW(SELF, refCode, VVeuyP=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFYUp6(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CC4cFe()
  if pr.VVfbLd(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVsAcI(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFDSaZ(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVeuyP:
   FFPQza(SELF, isFromSession)
 try:
  VV7fnz = InfoBar.instance
  if VV7fnz:
   VVObn7 = VV7fnz.servicelist
   if VVObn7:
    servRef = eServiceReference(refCode)
    VVObn7.saveChannel(servRef)
 except:
  pass
def FFDSaZ(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CC4cFe()
    if pr.VVfbLd(refCode, chName, decodedUrl, iptvRef):
     pr.VVsAcI(SELF, isFromSession)
def FF4MQW(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFcIP1(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFfoad(url): return FFeDHc(url) or FFlS6F(url)
def FFeDHc(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFlS6F(url): return any(x in url for x in ("/series/", "mode=series"))
def FFYUp6(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FF2zGt(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF2zGt(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFROgB(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFuZgB(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFRlnq(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFqDto(txt):
 try:
  return FFuZgB(FFRlnq(txt)) == txt
 except:
  return False
def FFJwmB(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFqvjY(newPath), patt))
def FFPQza(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCGzpp.VVfWLm(session)
 else      : FFR4Pq(session, reopen=True)
def FFR4Pq(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFR4Pq, session), CCI10Q)
  except:
   try:
    FFnco7(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFTYUK(refCode):
 tp = CCSt6f()
 if tp.VVrcxQ(refCode) : return True
 else        : return False
def FFNQSk(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFURke(True)
     return True
 return False
def FFURke(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFRNW3()
def FFRNW3():
 VV7fnz = InfoBar.instance
 if VV7fnz:
  VVObn7 = VV7fnz.servicelist
  if VVObn7:
   VVObn7.setMode()
def FFmpJ8(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV0WM0 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VV0WM0.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFhx3o():
 VV0f8b = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVceEt = list(VV0f8b)
 return VVceEt, VV0f8b
def FFT3Ui():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFLHvJ(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFaLO4(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFExv2():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFKX94():
 return FFExv2().replace(" ", "_").replace("-", "").replace(":", "")
def FFnZVI(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF84Fc():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFAqj4(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC3ZOl.VVakT8(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC3ZOl.VVBr0k(fName)
     phpFile = tmpDir + fName + ext
     FF2ufE("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FF5YNj(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFCMcT(num):
 return "s" if num > 1 else ""
def FFl54W(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFTJBw(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFe0ql(a, b):
 return (a > b) - (a < b)
def FFhvfk(a, b):
 def VVSTNc(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVSTNc(a)
 b = VVSTNc(b)
 return (a > b) - (a < b)
def FF2BO2(mycmp):
 class CC3TlY(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CC3TlY
def FFmMPS(SELF, message, title="", VVFqvg=None):
 SELF.session.openWithCallback(VVFqvg, CCJXhR, title=title, message=message, VVz31H=True)
def FFEso0(SELF, message, title="", VVognF=VVy5UE, VVFqvg=None, **kwargs):
 SELF.session.openWithCallback(VVFqvg, CCJXhR, title=title, message=message, VVognF=VVognF, **kwargs)
def FFKsbm(SELF, txt):
 SELF.session.open(CCq1i7, txt)
def FF9Njt(SELF, message, title="")  : FFnco7(SELF.session, message, title)
def FFvsvw(SELF, path, title="") : FFnco7(SELF.session, "File not found !\n\n%s" % path, title)
def FFBhlv(SELF, path, title="") : FFnco7(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFdRu7(SELF, title="")  : FFnco7(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFnco7(session, message, title="") : session.open(BF(CCigZo, title=title, message=message))
def FFuRfO(SELF, VVFqvg, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVFqvg, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVFqvg, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF9Njt(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFfbEx(SELF, callBack_Yes, VVumEG, callBack_No=None, title="", VVAbek=False, VVNwKe=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFFb7T, callBack_Yes, callBack_No)
         , BF(CCk8OT, title=title, VVumEG=VVumEG, VVNwKe=VVNwKe, VVAbek=VVAbek))
def FFFb7T(callBack_Yes, callBack_No, FFfbExed):
 if FFfbExed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFhSFw(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFiva8(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVHXst.start(timeout, True)
  except: pass
 else: FFri7G(SELF)
def FFGp67(*kargs, **kwargs):
 FFciRl(BF(FFhSFw, *kargs, **kwargs))
def FFri7G(SELF):
 try:
  SELF.VVHXst.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFSHcW(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFvfpt(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CClArU, **kwargs))
  else   : win = SELF.session.open(BF(CClArU, **kwargs))
  FF1Sqn(win)
  return win
 except:
  return None
def FFre61(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCMtdd, **kwargs))
 FF1Sqn(win)
 return win
def FFODSa(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FF47SM(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FF0gQ0(SELF, **kwargs):
 SELF.session.open(CCY1HC, **kwargs)
def FFlx3W(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFlK3z(SELF[name], "#000000", 3)
  except:
   pass
def FFlK3z(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFVHEz(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVczsY, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFkPKs(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFVHEz(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFDNFi(SELF, winSize.width(), winSize.height())
def FFDNFi(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFUXKU():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFBCoV(VVH0vt):
 screenSize  = FFUXKU()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVH0vt)
 return bodyFontSize
def FFFt0C(VVH0vt, extraSpace):
 font = gFont(VVczsY, VVH0vt)
 VVDng6 = fontRenderClass.getInstance().getLineHeight(font) or (VVH0vt * 1.25)
 return int(VVDng6 + VVDng6 * extraSpace)
def FFzoo9(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFUXKU()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVczsY, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFFt0C(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVczsY, titleFontSize, alignLeftCenter)
 if winType == VVS1Zw:
  pass
 elif winType in (VVzryP, VVJOxT):
  if winType == VVJOxT : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVQVkn:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVjGxK:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVczsY, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVtlKb:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFmMPSL = b2Left2 + timeW + marginLeft
  FFmMPSW = b2Left3 - marginLeft - FFmMPSL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFmMPSL , b2Top, FFmMPSW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVHtTB:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVJsvf:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVbHtF:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVtyom:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVczsY, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVczsY, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV9TYj:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVczsY, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVsFyt:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVczsY, fontH, alignCenter)
 elif winType in (VVwLpo, VV8zMg, VVwv41, VV3yNV, VV1wqm):
  if   winType == VVwLpo  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VV8zMg : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVwv41 : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VV3yNV : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVwLpo:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVczsY, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVczsY, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVczsY, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVczsY, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVczsY, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVczsY, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVczsY, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVCTW9:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV4GaE:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVDjOq : align = alignLeftCenter
  elif winType == VVJPgr : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVR8Wn:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVczsY
  if usefixedFont and winType == VVJPgr:
   fLst = FFZ5LC()
   if   VVz0ti in fLst and CFG.fontPathTerm.getValue(): fontName = VVz0ti
   elif VV2B3N in fLst         : fontName = VV2B3N
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVH0vt = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVczsY, VVH0vt, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVczsY, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVVNZR[i], VVczsY, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVJPgr:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVVNZR[i], VVczsY, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVqzoF = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVFo84)
  VVutlQ = []
  if TEST_FUNCTION:
   VVutlQ.append(("-- MY TEST --", "myTest" ))
  VVutlQ.append(("File Manager"  , "fMan" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("IPTV"    , "iptv" ))
  VVutlQ.append(("Movies Browser" , "movie" ))
  VVutlQ.append(("Services/Channels", "chan" ))
  VVutlQ.append(("Bouquet Editor" , "bouq" ))
  VVutlQ.append(("PIcons"   , "picon" ))
  VVutlQ.append(("EPG"    , "epg"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Terminal"   , "term" ))
  VVutlQ.append(("SoftCam"   , "soft" ))
  VVutlQ.append(("Plugins"   , "plug" ))
  VVutlQ.append(("Backup & Restore" , "bakup" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Date/Time"  , "date" ))
  VVutlQ.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVutlQ):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVutlQ[ndx] = tuple(item)
  FFk1xo(self, title=self.Title, VVutlQ=VVutlQ)
  FFWr7z(self["keyRed"] , "Exit")
  FFWr7z(self["keyGreen"] , "Settings")
  FFWr7z(self["keyYellow"], "Dev. Info.")
  FFWr7z(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VV2VKn      ,
   "yellow": self.VVzWXh      ,
   "blue" : self.VVD3tj     ,
   "info" : BF(FFVvl9, self, self.VV7x9k) ,
   "text" : self.VVEJlp      ,
   "menu" : self.VVKrtC    ,
   "0"  : BF(self.VVPnfM, 0)   ,
   "1"  : BF(self.VVC0O7, "fMan")   ,
   "2"  : BF(self.VVC0O7, "iptv")   ,
   "3"  : BF(self.VVC0O7, "movie")   ,
   "4"  : BF(self.VVC0O7, "chan")   ,
   "5"  : BF(self.VVC0O7, "bouq")   ,
   "6"  : BF(self.VVC0O7, "picon")   ,
   "7"  : BF(self.VVC0O7, "epg")   ,
   "8"  : BF(self.VVC0O7, "term")   ,
   "9"  : BF(self.VVC0O7, "soft")   ,
   "last" : BF(self.VVC0O7, "plug")   ,
   "next" : BF(self.VVC0O7, "bakup")
  })
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
  global VVS9jK, VVWEgS, VVwta1
  VVS9jK = VVWEgS = False
  VVwta1 = True
 def VVQHyQ(self):
  self.VVC0O7(self["myMenu"].l.getCurrentSelection()[1])
 def VVC0O7(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVU0bd
   VVU0bd = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVyIhI()
   elif item == "fMan"  : self.session.open(CCLSXF)
   elif item == "iptv"  : self.session.open(CC3ZOl)
   elif item == "movie" : FFVvl9(self, BF(CC1FQa.VVrxDE, self))
   elif item == "chan"  : self.session.open(CCIdtv)
   elif item == "bouq"  : self.session.open(CCDaBC)
   elif item == "picon" : self.VVPyop()
   elif item == "epg"  : self.session.open(CCvK6a)
   elif item == "term"  : self.session.open(CCwp6k)
   elif item == "soft"  : self.session.open(CCkTjP)
   elif item == "plug"  : self.session.open(CCunAJ)
   elif item == "bakup" : self.session.open(CC8rLK)
   elif item == "date"  : self.session.open(CCv63H)
   elif item == "net"  : self.session.open(CCJft9)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
  FFlx3W(self)
  FFqFdY(self)
  VVKhOZ, VVBnUq, VVcxZ1, VVUBM8, VVkgxO, oldMovieDownloadPath = FFlcwU()
  if VVKhOZ or VVBnUq or VVcxZ1 or VVUBM8 or VVkgxO or oldMovieDownloadPath:
   VVy75x = lambda path, subj: "%s:\n%s\n\n" % (subj, FF0D7j(path, VVO7vL)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVy75x(VVKhOZ   , "Backup/Restore Path"    )
   txt += VVy75x(VVBnUq  , "Created Package Files (IPK/DEB)" )
   txt += VVy75x(VVcxZ1  , "Download Packages (from feeds)" )
   txt += VVy75x(VVUBM8 , "Exported Tables"     )
   txt += VVy75x(VVkgxO , "Exported PIcons"     )
   txt += VVy75x(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFEso0(self, txt, title="Settings Paths")
  self.VVmqZB()
  if (EASY_MODE or VVfRPv or TEST_FUNCTION):
   FFiva8(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFhSFw(self, "Welcome", 300)
  FFciRl(self.VVUwBo)
 def VVUwBo(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCpO9T.VVjU4M()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FF2ufE("rm -f /tmp/ajp_*")
  global VVS9jK, VVWEgS
  VVS9jK = VVWEgS = False
  FFoVhu("VVwta1")
 def VVPnfM(self, digit):
  self.VVqzoF += str(digit)
  ln = len(self.VVqzoF)
  global VVS9jK
  if ln == 4:
   if self.VVqzoF == "0" * ln:
    VVS9jK = True
    FFiva8(self["myTitle"], "#11805040")
   else:
    self.VVqzoF = "x"
 def VVEJlp(self):
  self.VVqzoF += "t"
  if self.VVqzoF == "0" * 4 + "t" * 2:
   global VVWEgS
   VVWEgS = True
   FFiva8(self["myTitle"], "#dd5588")
 def VVPyop(self):
  found = False
  pPath = CC3hRa.VV3CCT()
  if pathExists(pPath):
   for fName, fType in CC3hRa.VVwLN3(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC3hRa)
  else:
   VVutlQ = []
   VVutlQ.append(("PIcons Tools" , "CC3hRa" ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(CC3hRa.VVkFrl())
   VVutlQ.append(VVJKCZ)
   VVutlQ += CC3hRa.VVXoaY()
   FFre61(self, self.VVZ4IO, VVutlQ=VVutlQ)
 def VVZ4IO(self, item=None):
  if item:
   if   item == "CC3hRa"   : self.session.open(CC3hRa)
   elif item == "VV76vU"  : CC3hRa.VV76vU(self)
   elif item == "VV1oIx"  : CC3hRa.VV1oIx(self)
   elif item == "findPiconBrokenSymLinks" : CC3hRa.VVxzcD(self, True)
   elif item == "FindAllBrokenSymLinks" : CC3hRa.VVxzcD(self, False)
 def VV7x9k(self):
  changeLogFile = VV8pP1 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF6UEw(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF0D7j("\n%s\n%s\n%s" % (SEP, line, SEP), VVRkew, VV15Fs)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF0D7j(line, VVBhz1, VV15Fs)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFEso0(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVFo84, PLUGIN_DESCRIPTION), VVH0vt=28, width=1600, height=1000, VVTJDG="#11000011")
 def VVKrtC(self):
  VVutlQ = []
  VVutlQ.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Keys Help"     , "hlp" ))
  FFre61(self, self.VVcXNX, VVutlQ=VVutlQ, width=650, title="Options")
 def VVcXNX(self, item=None):
  if item:
   if   item == "libr" : FFVvl9(self, BF(self.VVKD2j))
   elif item == "hlp" : FF1D9G(self, "_help_main", "Main Page (Keys Help)")
 def VV2VKn(self) : self.session.open(CCpO9T)
 def VVzWXh(self) : self.session.open(CCFZiz)
 def VVD3tj(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVFWDt, VVO7vL, VVPr8g, VVQrak
  VVutlQ = []
  VVutlQ.append((c1 + "Change Title Colors"   , "title"  ))
  VVutlQ.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVutlQ.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVutlQ.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVutlQ.append((c2 + "Reset Colors"    , "resetColor" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVutlQ.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c4 + "Change System Font"    , "sysFont"  ))
  FFre61(self, BF(self.VVkrI8, title), VVutlQ=VVutlQ, width=600, title=title)
 def VVkrI8(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVIoga()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVBnTj, tDict, item), CCTwdG, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFfbEx(self, self.VV7mGg, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVAWcR(VVWiAM  )
   elif item == "termFont"  : self.VVAWcR(VVz0ti)
   elif item == "sysFont"  : self.VVAWcR(VVVf82  )
 def VVKD2j(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VV796F, pkgs = self.VVUQAS()
  VVDle6 = ("Install", BF(self.VV3x1O, title, pkgs)  , [])
  VVUum8  = ("Update Sys. Packages", self.VVnopp , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVxWCE = (LEFT  , CENTER , LEFT  )
  VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, width=1350, VVDle6=VVDle6, VVUum8=VVUum8, VVVcQT="#00ffffaa", VV6Uvt=1)
 def VV3x1O(self, Title, pkgs, VVhkUd, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVzl1c, VVhkUd)
   item = colList[0]
   if   item == "requests" : CCJ0a3.VVSfC2(self, cbFnc=cbFnc)
   elif item == "Imaging" : CC4Zpg.VVafHZ(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FF9pl1(self, FF8IJx(), VVsWF3=cbFnc)
   elif item in pkgs  : FF9pl1(self, FFaZl2(item, item, item.capitalize()), VVsWF3=cbFnc)
  else:
   FFhSFw(VVhkUd, "Already installed.", 700, isGrn=True)
 def VVnopp(self, VVhkUd, title, txt, colList):
  CCunAJ.VVVmz0(self)
 def VVzl1c(self, VVhkUd):
  VV796F, pkgs = self.VVUQAS()
  VVhkUd.VVTXUN(VV796F[VVhkUd.VVSWzf()])
 def VVUQAS(self):
  tDict = {}
  path = VV8pP1 + "_sup_lib"
  if fileExists(path):
   for line in FF6UEw(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVy75x(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FF0D7j("Installed", VVRTFm), txt)
   else : return (lib, FF0D7j("Not installed", VV8a8m), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VV796F = []
  VV796F.append(VVy75x("requests", CCJ0a3.VVSfC2(self, install=False)))
  VV796F.append(VVy75x("Imaging" , CC4Zpg.VVafHZ(self, "", False, install=False)))
  VV796F.append(VVy75x("ar"   , FF2ufE("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VV796F.append(VVy75x(item, FFVjaP(item)))
  VV796F.sort(key=lambda x: x[0].lower())
  return VV796F, pkgs
 def VVKlSD(self):
  return VVUQHY + "ajpanel_colors"
 def VVIoga(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVKlSD()
  if fileExists(p):
   txt = FFXk75(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVBnTj(self, tDict, item, fg, bg):
  if fg:
   self.VVwyUA(item, fg)
   self.VV8RBz(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVrUp1(tDict)
 def VVrUp1(self, tDict):
   p = self.VVKlSD()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVwyUA(self, item, fg):
  if   item == "title" : FFBD6G(self["myTitle"], fg)
  elif item == "body"  :
   FFBD6G(self["myMenu"], fg)
   FFBD6G(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFBD6G(self[item], fg)
 def VV8RBz(self, item, bg):
  if   item == "title" : FFiva8(self["myTitle"], bg)
  elif item == "body"  :
   FFiva8(self["myMenu"], bg)
   FFiva8(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFiva8(self["myBar"], bg)
 def VV7mGg(self):
  FF2ufE("rm '%s'" % self.VVKlSD())
  self.close()
 def VVmqZB(self):
  tDict = self.VVIoga()
  for item in ("title", "body", "cursor", "bar"):
   self.VVTgNJ(tDict, item)
 def VVTgNJ(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVwyUA(name, fg)
  if bg: self.VV8RBz(name, bg)
 def VVAWcR(self, which):
  if   which == VVWiAM  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVz0ti : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVVf82  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCdMC7.VVAEOw(self, "Change %s Font" % title, defFnt, rest, BF(self.VVFzho, which))
 def VVFzho(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVWiAM  : FF3Ual(CFG.fontPathMain, path)
   elif which == VVz0ti: FF3Ual(CFG.fontPathTerm, path)
   elif which == VVVf82  : FF3Ual(CFG.fontPathSys , path)
   err = Main_Menu.VVqnxf(which)
   if err          : FF9Njt(self, err, title=title)
   elif which == VVWiAM   : self.close()
   elif which == VVz0ti  : FFhSFw(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVVf82 and path: FFhSFw(self, "System font applied", 1500, isGrn=True)
   elif which == VVVf82   : FFfbEx(self, BF(Main_Menu.VVhnmM, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVhnmM(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVqnxf(name):
  if   name == VVWiAM : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVz0ti: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVVf82 : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFZ5LC()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVVf82:
   nameLst = []
   for nm in FFZ5LC():
    if not nm in (VVWiAM, VVz0ti):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFkKOE(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFZ5LC()
  else    : return "Could not add font"
 def VVyIhI(self):
  self.session.open(CCDaBC)
class CCJft9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVUQHY, "ajpanel_network")
  c1, c2 = VVPr8g, VVFWDt
  VVutlQ = []
  VVutlQ.append((c1 + "Network Devices"     , "dev" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Network Scanner (ping)"    , "ping"))
  VVutlQ.append(("Port Scanner (scan for famous ports)" , "port"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Check Internet Connection"  , "intr"))
  FFk1xo(self, title="Network Tools", VVutlQ=VVutlQ)
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFVvl9(self, self.VV8NDp, title="REading Devices ...")
  elif item == "ping" : FFVvl9(self, self.VVTq5S, title="Scanning ...")
  elif item == "port" : CCYYaf.VVmstV(self, self.VV7VW0, title="Select host to scan")
  elif item == "intr" : self.session.open(CCTbQH)
 def VV8NDp(self, canCencel=False):
  title = "Network Devices"
  VV796F = self.VVqN3o()
  if VV796F:
   bg = "#0a223333"
   VV796F.sort(key=lambda x: x[0].lower())
   VVfT1c = BF(self.VVJuPr, canCencel)
   VVOPmD  = ("Start FTP"   , self.VVOoJp    , [])
   VVPOPD = ("Entry Options"  , self.VVcUBH  , [])
   VVUum8 = ("Scan for Devices" , self.VVvMef , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVxWCE = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, width=1500, height=900, VVFNzW=widths, VVH0vt=28, VVOPmD=VVOPmD, VVfT1c=VVfT1c, VVPOPD=VVPOPD, VVUum8=VVUum8
       , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVVcQT="#11ffff00", VVChAx="#11220000", VVDQNf="#00333333", VV4UX1="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVhkUd.VVfMAJ(ndx)
  else:
   FFfbEx(self, BF(FFVvl9, self, BF(self.VVkLuf, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVJuPr, canCencel), title=title)
 def VVcUBH(self, VVhkUd, title, txt, colList):
  VVutlQ = []
  VVutlQ.append(("Change Username"   , "user"))
  VVutlQ.append(("Change Password"   , "pass"))
  VVutlQ.append(("Change Remarks"   , "rem"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Remove Selected Server" , "del"))
  FFre61(self, BF(self.VV7xN9, VVhkUd), VVutlQ=VVutlQ, title="Entry Options")
 def VV7xN9(self, VVhkUd, item=None):
  if item:
   if   item == "user" : self.VVlPMH("u", VVhkUd)
   elif item == "pass" : self.VVlPMH("p", VVhkUd)
   elif item == "rem" : self.VVlPMH("r", VVhkUd)
   elif item == "del" : FFfbEx(self, BF(FFVvl9, self, BF(self.VV7yNh, VVhkUd), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVJuPr(self, canCencel, VVhkUd=None):
  if VVhkUd: VVhkUd.cancel()
  if canCencel : self.close()
 def VVOoJp(self, VVhkUd, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FF3Ual(CFG.lastNetworkDevice, VVhkUd.VVSWzf())
  self.session.openWithCallback(BF(self.VVEJ6M, entry, VVhkUd), CCwmaF, entry)
 def VVEJ6M(self, entry, VVhkUd, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVKMeX("d", newPath, ip, u, p, path, rem)
    self.VV3FfS(VVhkUd)
 def VVvMef(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVkLuf, mainTableInst=VVhkUd), title="Scanning Network ...")
 def VVkLuf(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCYYaf.VVWl7A(CCYYaf.VVpK6P)
  if err:
   FF9Njt(self, err, title=title)
   return
  telLst, err = CCYYaf.VVWl7A(CCYYaf.VVV7pG)
  if err:
   FF9Njt(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVyrwi(p1, p2): return FFhvfk(p1[0], p2[0])
   lst.sort(key=FF2BO2(VVyrwi))
   bg = "#0a202020"
   VVfT1c = BF(self.VVJuPr, canCencel)
   VVOPmD  = ("Add to Devices" , BF(self.VVdPBP, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVxWCE = (LEFT   , CENTER  , CENTER  )
   FFvfpt(self, None, title=title, header=header, VVUel6=lst, VVxWCE=VVxWCE, VVFNzW=widths, width=1200, VVH0vt=30, VVOPmD=VVOPmD, VVfT1c=VVfT1c, VV6Uvt=2
     , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVChAx="#0a225555", VV4UX1="#11403040")
  else:
   FF9Njt(self, "No devices found !", title=title)
 def VVTq5S(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCYYaf.VVWl7A(-1)
  if err:
   FF9Njt(self, err, title=title)
  elif lst:
   def VVyrwi(p1, p2): return FFhvfk(p1[0], p2[0])
   lst.sort(key=FF2BO2(VVyrwi))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVxWCE = (LEFT   , LEFT   )
   FFvfpt(self, None, title=title, header=header, VVUel6=lst, VVxWCE=VVxWCE, VVFNzW=widths, width=1000, height=700, VVH0vt=30
     , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVChAx="#0a225555", VV4UX1="#11403040")
  else:
   FF9Njt(self, "Network scanning failed !", title=title)
 def VV7VW0(self, ip=None):
  if ip:
   FFVvl9(self, BF(self.VVZndR, ip), title="Scanning %s" % ip)
 def VVZndR(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCYYaf.VVqJ08(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCYYaf.VVTJSi(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFEso0(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVqN3o(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFXk75(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVyrwi(p1, p2): return FFhvfk(p1[0], p2[0])
  tLst.sort(key=FF2BO2(VVyrwi))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVqN3o(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFXk75(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVyrwi(p1, p2): return FFhvfk(p1[0], p2[0])
  tLst.sort(key=FF2BO2(VVyrwi))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVdPBP(self, mainTableInst, canCencel, VVhkUd, title, txt, colList):
  ip, mac, typ = VVhkUd.VVbWAe(VVhkUd.VVSWzf())
  if "Own" in ip:
   FFhSFw(VVhkUd, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVqN3o():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFViMr(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVpwNH(ip, u, p, path, rem))
   if mainTableInst: self.VV3FfS(mainTableInst, [ip, u, p, path, rem])
   else   : self.VV8NDp(canCencel)
   VVhkUd.cancel()
 def VVpwNH(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VV7yNh(self, VVhkUd):
  num, ip, u, p, path, rem = VVhkUd.VVbWAe(VVhkUd.VVSWzf())
  lst = self.VVqN3o()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVpwNH(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VV3FfS(VVhkUd)
  else:
   VVhkUd.cancel()
 def VVlPMH(self, col, VVhkUd):
  num, ip, u, p, path, rem = VVhkUd.VVbWAe(VVhkUd.VVSWzf())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFuRfO(self, BF(self.VVLOZS, col, orig, VVhkUd, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVLOZS(self, col, orig, VVhkUd, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFhSFw(VVhkUd, "No change", 1500)
   elif not newTxt and col == "u":
    FFhSFw(VVhkUd, "No user !", 2000)
   else:
    self.VVKMeX(col, newTxt, ip, u, p, path, rem)
    self.VV3FfS(VVhkUd)
 def VVKMeX(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVqN3o()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVpwNH(ip1, u1, p1, path1, rem1))
 def VV3FfS(self, VVhkUd, newEntry=None):
  VV796F = self.VVqN3o()
  if VV796F : VVhkUd.VVoiHv(VV796F, tableRefreshCB=BF(self.VVE0z5, newEntry))
  else  : VVhkUd.cancel()
 def VVE0z5(self, newEntry, VVhkUd, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVhkUd.VVNCJx()):
    if row[1:] == newEntry:
     VVhkUd.VVfMAJ(ndx)
 def VVJuPr(self, canCencel, VVhkUd=None):
  if VVhkUd: VVhkUd.cancel()
  if canCencel : self.close()
class CCYYaf():
 VVpK6P = 21
 VVV7pG = 23
 def __init__(self):
  self.VVUkqE()
 def VVUkqE(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVEL0U(self, ip, User, Pass, timeout=5):
  myIp = CCYYaf.VVf4jn()
  if ip != myIp:
   if CCYYaf.VVTJSi(ip, CCYYaf.VVpK6P):
    self.VVUkqE()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVIIIN(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVONgy(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVtl40(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVONgy()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVGPml(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VV5J2T(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVeero(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVaDn7(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVohO2(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVaDn7()
   if self.VVeero(path) : typ = "d"
   else      : typ = "b"
   self.VVeero(curDir)
   return typ
 def VVavoG(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVeero(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVYCnn(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVQ0oj(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVMqYD(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVEeGj(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVavoG(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFEUy9(locFile)
   return "", sz, str(e)
 def VVq7U8(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVUkqE()
 @staticmethod
 def VVcCnK():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVf4jn():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVDQWe():
  myIp = CCYYaf.VVf4jn()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VV2Sl5():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FF7jZM("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVlvJ7(port=-1):
  lst = []
  def VVOv31(ip):
   if port > -1: ok = CCYYaf.VVTJSi(ip, port)
   else  : ok = CCYYaf.VVqJ08(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCYYaf.VVDQWe()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVOv31, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVWl7A(port):
  myIp = CCYYaf.VVf4jn()
  myGw = CCYYaf.VV2Sl5()
  tDict = { myIp: CCYYaf.VVcCnK() }
  devLst, err = CCYYaf.VVlvJ7(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFt7KC("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVPr8g
    elif key == myGw: txt = " %s Gateway" % VVPr8g
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVqJ08(ip):
  return FF2ufE("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVTJSi(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVmh4s(ip="1.1.1.1", timeout=1):
  if CCYYaf.VVTJSi(ip, 53, timeout):
   return True
  if CCYYaf.VVqJ08(ip):
   return True
  return FF2ufE("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVmstV(SELF, okFnc, title):
  baseIp = CCYYaf.VVDQWe()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFre61(SELF, okFnc, VVutlQ=lst, width=600, title=title, VVRdqN="#222222", VVkSGg="#222222")
class CCwmaF(Screen, CCYYaf):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFzoo9(VVzryP, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVH0vt  = self.skinParam["bodyFontSize"]
  self.VVDng6  = self.skinParam["bodyLineH"]
  self.VVRiUz  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCr5ME.VVQDUE("fil")
  self.png_dir  = CCr5ME.VVQDUE("dir")
  self.png_dirup  = CCr5ME.VVQDUE("dirup")
  self.png_slwfil  = CCr5ME.VVQDUE("slwfil")
  self.png_slbfil  = CCr5ME.VVQDUE("slbfil")
  self.png_slwdir  = CCr5ME.VVQDUE("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCYYaf.__init__(self)
  VVutlQ = [("Item-%d" % x,) for x in range(50)]
  FFk1xo(self, title=self.Title, VVutlQ=VVutlQ)
  FFWr7z(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVutlQ, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVczsY, self.VVH0vt))
  self["myMenu"].l.setItemHeight(self.VVDng6)
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "red" : BF(self.VVgUEA, True) ,
   "ok" : self.VVQHyQ    ,
   "cancel": self.VVgUEA    ,
   "menu" : self.VVW1oN   ,
   "info" : self.VVLZuO  ,
   "pageUp": self.VVV9fF    ,
   "chanUp": self.VVV9fF
  })
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVyxgL)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
  FFlx3W(self)
  FFqFdY(self)
  FFiva8(self["keyBlue"], "#11333333")
  FFVvl9(self, self.VV2bUX, title="Connecting ...")
 def VV2bUX(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVEL0U(ip, u, p)
  if err:
   FF9Njt(self, err, title=self.Title)
   FFWr7z(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFWr7z(self["keyBlue"], self.ftpIp)
   if not self.VVeero(path):
    path = "/"
   self.VV8N1T(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVONgy():
   self.VVq7U8()
 def VVQHyQ(self):
  if self.VV6f0b():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VV8N1T(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVV9fF()
    else         : self.VVIuy1(os.path.join(self.curDir, name))
 def VVgUEA(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVV9fF()
 def VV6f0b(self):
  if self.VVONgy():
   return True
  else:
   FF9Njt(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVIuy1(self, path):
  cat = self.VVDtpZ(path)
  if cat in ("pic"):
   FFVvl9(self, BF(self.VVcxSx, path))
  elif cat in ("mov", "mus"):
   if CC3ZOl.VV1BDv("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFVvl9(self, BF(CCLSXF.VVPDp5, self, url, rType=rType), title="Playing Media ...")
 def VVcxSx(self, path):
  locFile, size, err = self.VVEeGj(path)
  if err: FF9Njt(self, err, title="View Picture File")
  else  : CCMQgO.VVR5E7(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFEUy9))
 def VVyxgL(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCr5ME.VVHgCU else sel[0][0])
  else  : title=  VV8a8m + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVV9fF(self):
  if self.VV6f0b():
   lastPart = FFY1Mj(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VV8N1T(parentDir, lastPart, "d")
 def VV8N1T(self, Dir, moveTo="", moveToType=""):
  FFVvl9(self, BF(self.VV9x2f, Dir, moveTo, moveToType))
 def VV9x2f(self, Dir, moveTo, moveToType):
  files, err = self.VV5J2T(Dir, isLong=True)
  self.curDir = self.VVaDn7() or "/"
  self.VVwvvO(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVwvvO(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVoVE1(CCr5ME.VVHgCU, CCr5ME.VVHgCU, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVohO2(target)
    color = VV8a8m if targetState == "b" else VVRTFm
    origName = name + VVRkew + linkSep + color + " "+ target
   self.list.append(self.VVoVE1(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVoVE1(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVDtpZ(name)
    if cat: png = LoadPixmap("%s%s.png" % (VV8pP1, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCr5ME.VVHgCU: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVDng6 + 10, 0, self.VVRiUz, self.VVDng6, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CClArU.VVAekn(0, 2, self.VVDng6-4, self.VVDng6-4, png))
  return tableRow
 def VVDtpZ(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCr5ME.VVbcLX().items():
    if ext in lst:
     return cat
  return ""
 def VVW1oN(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCr5ME.VVHgCU
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VV12qh(titl, ref, chk, color=""):
   if chk: return VVutlQ.append((color + titl, ref))
   else  : return VVutlQ.append((titl, ))
  VVutlQ = []
  VV12qh("Properties", "VVLZuO", not isTop)
  c = VVPr8g
  VVutlQ.append(VVJKCZ)
  VV12qh("Download Selected File ..."    , "FFAqj4FromServer", isFile, c)
  VV12qh("Upload a Local File to Remote Server ...", "VVIGTi" , True  , c)
  VVutlQ.append(VVJKCZ)
  VV12qh("Create new directory", "VVqvmR", True)
  VV12qh("Rename", "VV4OIH", not isTop)
  VV12qh("DELETE", "VVXcdk", not isTop, VVUS1a)
  VVutlQ.append(VVJKCZ)
  VV12qh("FTP Server Information", "VVasPa", True)
  VVutlQ.append(VVJKCZ)
  VV12qh("Refresh File List", "refresh", True)
  FFre61(self, self.VVwpMj, VVutlQ=VVutlQ, title="Options")
 def VVwpMj(self, item=None):
  if item:
   if   item == "VVLZuO"     : self.VVLZuO()
   elif item == "FFAqj4FromServer"   : self.FFAqj4FromServer()
   elif item == "VVIGTi"   : self.VVIGTi()
   elif item == "VVqvmR"   : self.VVqvmR()
   elif item == "VV4OIH"   : self.VV4OIH()
   elif item == "VVXcdk"   : self.VVXcdk()
   elif item == "VVasPa"    : self.VVasPa()
   elif item == "refresh"and self.VV6f0b() : self.VV8N1T(self.curDir)
 def VVLZuO(self):
  if self.VV6f0b():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FF0D7j("Path", VVPr8g), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVavoG(path)
    if sz > -1: txt += "Size\t: %s" % CCLSXF.VVtnwF(sz)
   else:
    txt = "Nothing selected"
   FFEso0(self, txt, title="Properties")
 def VVasPa(self):
  if self.VV6f0b():
   Sys  = self.VVIIIN() or " -"
   txt = "%s\n  %s\n\n" % (FF0D7j("System:", VVPr8g), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVGPml() or " -"
   txt += "%s\n" % (FF0D7j("Status:", VVPr8g))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFEso0(self, txt, title="FTP Server Information")
 def VVqvmR(self, name=""):
  if self.VV6f0b():
   title = "Add New Directory"
   FFuRfO(self, BF(self.VVBIar, title), defaultText=name, title=title, message="Enter Directory name")
 def VVBIar(self, title, name):
  if name and name.strip():
   if self.VVYCnn(name) : self.VV8N1T(self.curDir, name, "d")
   else     : FF9Njt(self, "Failed to create : %s" % name, title)
 def VV4OIH(self):
  if self.VV6f0b():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFuRfO(self, BF(self.VVqC5d, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVqC5d(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVMqYD(name, newName.strip()) : self.VV8N1T(self.curDir, newName, flag)
   else          : FF9Njt(self, "Failed to rename to : %s" % newName, title)
 def VVXcdk(self):
  if self.VV6f0b():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFfbEx(self, BF(FFVvl9, self, BF(self.VVUDJX, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVUDJX(self, name, flag):
  if self.VVQ0oj(name, flag) : self.VV8N1T(self.curDir)
  else         : FF9Njt(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFAqj4FromServer(self):
  if self.VV6f0b():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVavoG(remFile)
    if size == -1:
     FF9Njt(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVUQHY
     self.session.openWithCallback(BF(self.VVOeHA, title, remFile, name, size), BF(CCLSXF, mode=CCLSXF.VVL22N, VVkeEZ="Download here", VVXhi5=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVOeHA(self, title, remFile, name, size, locPath):
  if locPath:
   FF3Ual(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVFqE7, remFile, size, locFile)
       , VVFqvg = BF(self.VVDY5J, remFile, size, locFile))
 def VVFqE7(self, remFile, size, locFile, VVdu90):
  VVdu90.VV7hIf(size)
  VVdu90.VVeIVc = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVIy5e(data):
     if not VVdu90 or VVdu90.isCancelled:
      return
     locFileObj.write(data)
     VVdu90.VVRbmv(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVIy5e)
   except Exception as e:
    VVdu90.VVeIVc = str(e)
 def VVDY5J(self, remFile, size, locFile, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVeIVc:
   FF9Njt(self, "%s\n\nftp:/%s" % (VVeIVc, remFile), title="Download Error")
   delF = True
  elif not VVegYv:
   FF9Njt(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFrMJ0(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFmMPS(self, txt, title=title)
   else:
    FF9Njt(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFEUy9(locFile)
 def VVIGTi(self):
  if self.VV6f0b():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVUQHY
   self.session.openWithCallback(self.VVVDPJ, BF(CCLSXF, VVkeEZ="Upload selected file", VVXhi5=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVVDPJ(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FF3Ual(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFrMJ0(locFile)
   if size == -1:
    FF9Njt(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VV5HAV, locFile, size, remFile)
        , VVFqvg = BF(self.VVig7h, locFile, size, remFile))
 def VV5HAV(self, locFile, size, remFile, VVdu90):
  VVdu90.VV7hIf(size)
  VVdu90.VVeIVc = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVb1YP(data):
     if not VVdu90 or VVdu90.isCancelled:
      VVdu90.VVeIVc = "Upload cancelled"
      locFileObj.close()
      return
     VVdu90.VVRbmv(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVb1YP)
   except Exception as e:
    VVdu90.VVeIVc = VVdu90.VVeIVc or str(e)
 def VVig7h(self, locFile, size, remFile, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVegYv:
   if size == FFrMJ0(locFile) : FFmMPS(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVeIVc : err = "%s\n\n%s" % (VVeIVc, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FF9Njt(self, err, title=title)
   self.VVtl40()
   self.VVQ0oj(remFile, "")
  self.VV8N1T(self.curDir)
class CC4Zpg():
 VVcAua  = "all"
 VVDQvM = "vid"
 VV9to0  = "osd"
 @staticmethod
 def VVAvuS(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFVjaP("grab"):
    winShown = session.current_dialog.shown
    if k == CC4Zpg.VVDQvM and winShown: session.current_dialog.hide()
    FFciRl(BF(CC4Zpg.VVMYCg, title, session, k, winShown))
   else:
    FFnco7(session, "No Grab command !", title=title)
 @staticmethod
 def VVMYCg(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CC4Zpg.VV9to0:
   if not winShown:
    FFnco7(session, "No Window to capture !", title=title)
    return
   if not CC4Zpg.VVafHZ(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CC4Zpg.VV7adx(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFnco7(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFqvjY(CFG.exportedPIconsPath.getValue()), fTitle, FFKX94(), ext)
  ok = FFIapl("grab -q -s %s > '%s'" % (typ, path))
  if k == CC4Zpg.VVDQvM and winShown:
   session.current_dialog.show()
  elif k == CC4Zpg.VV9to0:
   ok = CC4Zpg.VVc457(path, x, y, w, h)
   if not ok:
    FFEUy9(path)
    FFnco7(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCMQgO, title=path, VVQVlp=path))
  else      : FFnco7(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVafHZ(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFfbEx(SELF, BF(CC4Zpg.VVDjd4, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVDjd4(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFareT, VVsWF3=cbFnc)
  else    : fnc = BF(FF9pl1 , VVsWF3=cbFnc)
  fnc(SELF, FFciUY(VVtZiS, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VV7adx(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVc457(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFUXKU()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFTJBw(x , 0, scrW, 0, w)
     y  = FFTJBw(y , 0, scrH, 0, h)
     x1 = FFTJBw(x1, 0, scrW, 0, w)
     y1 = FFTJBw(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVW0tv(path):
  size = FFrMJ0(path)
  sizeTxt = CCLSXF.VVtnwF(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCdMC7(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFzoo9(VVzryP, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FF0D7j(" (Requires GUI Restart)", VVQrak) if withRestart else ""
  VVutlQ = []
  for path in self.fontsList:
   VVutlQ.append((os.path.splitext(os.path.basename(path))[0], path))
  VVutlQ.sort(key=lambda x: x[0].lower())
  VVutlQ.insert(0, VVJKCZ)
  VVutlQ.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVutlQ):
    if len(item) == 2 and item[1] == self.defFnt:
     VVutlQ[ndx] = (VVRTFm + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVutlQ[curIndex] = (VVRTFm + VVutlQ[curIndex][0], VVutlQ[curIndex][1])
  FFk1xo(self, VVutlQ=VVutlQ, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
  self["myBar"].setText(self.VVJdoD())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VVpSyH)
  self.VVpSyH()
 def VVQHyQ(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVpSyH(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFkKOE(path, fnt, isRepl=1)
  else:
   fnt = VVgWB4
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVJdoD(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVAEOw(SELF, title, defFnt, rest, VVFqvg):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFJwmB(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVFqvg, CCdMC7, title, fontsList, defFnt, rest)
  else  : FF9Njt(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCdSB3(Screen):
 def __init__(self, session, path, VVutlQ, title):
  self.skin, self.skinParam = FFzoo9(VVzryP, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFk1xo(self, VVutlQ=VVutlQ, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok"  : self.VVQHyQ   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VV1l5A,
   "chanUp" : self.VV1l5A,
   "pageDown" : self.VVTs3T ,
   "chanDown" : self.VVTs3T ,
  }, -1)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
  FFiva8(self["myLabelFrm"], "#11110000")
  FFiva8(self["myLabelTit"], "#11663322")
  FFiva8(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVfFyc)
  self.VVfFyc()
 def VVfFyc(self):
  if fileExists(self.path): txt = FFXk75(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVQHyQ(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV1l5A(self) : self["myMenu"].moveToIndex(0)
 def VVTs3T(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCDQtT():
 @staticmethod
 def VVZrBR():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV4TfD(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFvfpt(SELF, None, VVUel6=lst, VVH0vt=30, VV6Uvt=1)
 @staticmethod
 def VVvetn(path, SELF=None):
  for enc in CCDQtT.VVZrBR():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF9Njt(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VV9DXi(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVuKpV(SELF, path, cbFnc, curEnc=VVjOGl, title="Select Encoding"):
  lst = CCDQtT.VVExAe(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCdSB3, path, lst, title)
 @staticmethod
 def VVB9XY(SELF, cbFnc, curEnc=VVjOGl, title="Select Encoding"):
  lst = CCDQtT.VVExAe(SELF, "", "")
  if lst:
   FFre61(SELF, cbFnc, title=title, VVutlQ=lst, width=1000, height=1000, VVRdqN="#22220000", VVkSGg="#22220000", VVNxG7=True)
 @staticmethod
 def VVExAe(SELF, path, curEnc):
  lst = CCDQtT.VVa5EN(path)
  if lst:
   VVutlQ = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVRTFm
    elif enc == VVjOGl: c = VVRkew
    else      : c = ""
    VVutlQ.append((c + txt, enc))
   return VVutlQ
  else:
   FFGp67(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVa5EN(path=""):
  encLst = []
  cPath = VV8pP1 + "_sup_codecs"
  if fileExists(cPath):
   lines = FF6UEw(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCDQtT.VVZrBR())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCFZiz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVutlQ = []
  VVutlQ.append(("Settings File"   , "SettingsFile"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Box Info"     , "VVEJ9T"   ))
  VVutlQ.append(("Tuners Info"    , "VVhqAV"  ))
  VVutlQ.append(("Python Version"   , "VVnPaC"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Screen Size"    , "ScreenSize"   ))
  VVutlQ.append(("Language/Locale"   , "Locale"    ))
  VVutlQ.append(("Processor"    , "Processor"   ))
  VVutlQ.append(("Operating System"   , "OperatingSystem"  ))
  VVutlQ.append(("Drivers"     , "drivers"    ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("System Users"    , "SystemUsers"   ))
  VVutlQ.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVutlQ.append(("Uptime"     , "Uptime"    ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Host Name"    , "HostName"   ))
  VVutlQ.append(("MAC Address"    , "MACAddress"   ))
  VVutlQ.append(("Network Configuration" , "NetworkConfiguration"))
  VVutlQ.append(("Network Status"   , "NetworkStatus"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Disk Usage"    , "VVEwc5"   ))
  VVutlQ.append(("Mount Points"    , "MountPoints"   ))
  VVutlQ.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVutlQ.append(("USB Devices"    , "USB_Devices"   ))
  VVutlQ.append(("List Block-Devices"  , "listBlockDevices" ))
  VVutlQ.append(("Directory Size"   , "DirectorySize"  ))
  VVutlQ.append(("Memory"     , "Memory"    ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVutlQ.append(("Running Processes"  , "RunningProcesses" ))
  VVutlQ.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFk1xo(self, VVutlQ=VVutlQ, title="Device Information")
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCh51w)
   elif item == "VVEJ9T"   : self.VVEJ9T()
   elif item == "VVhqAV"  : self.VVhqAV()
   elif item == "VVnPaC"  : self.VVnPaC()
   elif item == "ScreenSize"   : FFEso0(self, "Width\t: %s\nHeight\t: %s" % (FFUXKU()[0], FFUXKU()[1]))
   elif item == "Locale"    : CCDQtT.VV4TfD(self)
   elif item == "Processor"   : self.VVqQxr()
   elif item == "OperatingSystem"  : FFrGZ9(self, "uname -a")
   elif item == "drivers"    : self.VVrtxf()
   elif item == "SystemUsers"   : FFrGZ9(self, "id")
   elif item == "LoggedInUsers"  : FFrGZ9(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFrGZ9(self, "uptime")
   elif item == "HostName"    : FFrGZ9(self, "hostname")
   elif item == "MACAddress"   : self.VV7RlN()
   elif item == "NetworkConfiguration" : FFrGZ9(self, "ifconfig %s %s" % (FFLPjB("HWaddr", VV7CTN), FFLPjB("addr:", VVRkew)))
   elif item == "NetworkStatus"  : FFrGZ9(self, "netstat -tulpn", VVH0vt=24, consFont=True)
   elif item == "VVEwc5"   : self.VVEwc5()
   elif item == "MountPoints"   : FFrGZ9(self, "mount %s" % (FFLPjB(" on ", VVRkew)))
   elif item == "FileSystemTable"  : FFrGZ9(self, "cat /etc/fstab", VVH0vt=24, consFont=True)
   elif item == "USB_Devices"   : FFrGZ9(self, "lsusb")
   elif item == "listBlockDevices"  : FFrGZ9(self, "blkid")
   elif item == "DirectorySize"  : FFrGZ9(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVxGOu="Reading size ...")
   elif item == "Memory"    : FFrGZ9(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVOYok()
   elif item == "RunningProcesses"  : FFrGZ9(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFrGZ9(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVNyMg()
   else        : self.close()
 def VV7RlN(self):
  res = FFt7KC("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFEso0(self, txt)
  else:
   FFrGZ9(self, "ip link")
 def VV68fL(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFlfx8(cmd)
  return lines
 def VVzzfH(self, lines, headerRepl, widths, VVxWCE):
  VV796F = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV796F.append(parts)
  if VV796F and len(header) == len(widths):
   VV796F.sort(key=lambda x: x[0].lower())
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, VV6Uvt=1)
   return True
  else:
   return False
 def VVEwc5(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFt7KC(cmd)
  if not "invalid option" in txt:
   lines  = self.VV68fL(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVxWCE = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVzzfH(lines, headerRepl, widths, VVxWCE)
  else:
   cmd = "df -h"
   lines  = self.VV68fL(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVxWCE = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVzzfH(lines, headerRepl, widths, VVxWCE)
  if not allOK:
   lines = FFlfx8(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFHx8R(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVRTFm:
     note = "\n%s" % FF0D7j("Green = Mounted Partitions", VVRTFm)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVRkew
     elif line.endswith(mountList) : color = VVRTFm
     else       : color = VVBhz1
     txt += FF0D7j(line, color) + "\n"
    FFEso0(self, txt + note)
   else:
    FF9Njt(self, "Not data from system !")
 def VVOYok(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV68fL(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVxWCE = (LEFT , CENTER, LEFT )
  allOK = self.VVzzfH(lines, headerRepl, widths, VVxWCE)
  if not allOK:
   FFrGZ9(self, cmd)
 def VVrtxf(self):
  cmd = FFwyvS(VVf00o, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFrGZ9(self, cmd)
  else : FFdRu7(self)
 def VVqQxr(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFrGZ9(self, cmd)
 def VVNyMg(self):
  cmd = FFwyvS(VVUphI, "| grep secondstage")
  if cmd : FFrGZ9(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFdRu7(self)
 def VVEJ9T(self):
  c = VVRTFm
  VVUel6 = []
  VVUel6.append((FF0D7j("Box Type"  , c), FF0D7j(self.VVJYSf("boxtype").upper(), c)))
  VVUel6.append((FF0D7j("Board Version", c), FF0D7j(self.VVJYSf("board_revision") , c)))
  VVUel6.append((FF0D7j("Chipset"  , c), FF0D7j(self.VVJYSf("chipset")  , c)))
  VVUel6.append((FF0D7j("S/N"   , c), FF0D7j(self.VVJYSf("sn")    , c)))
  VVUel6.append((FF0D7j("Version"  , c), FF0D7j(self.VVJYSf("version")  , c)))
  VV0mgu   = []
  VVfLEC = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVfLEC = SystemInfo[key]
     else:
      VV0mgu.append((FF0D7j(str(key), VVJTsP), FF0D7j(str(SystemInfo[key]), VVJTsP)))
  except:
   pass
  if VVfLEC:
   VVpr46 = self.VVMPvV(VVfLEC)
   if VVpr46:
    VVpr46.sort(key=lambda x: x[0].lower())
    VVUel6 += VVpr46
  if VV0mgu:
   VV0mgu.sort(key=lambda x: x[0].lower())
   VVUel6 += VV0mgu
  if VVUel6:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFvfpt(self, None, header=header, VVUel6=VVUel6, VVFNzW=widths, VVH0vt=28, VV6Uvt=1)
  else:
   FFEso0(self, "Could not read info!")
 def VVJYSf(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF6UEw(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVMPvV(self, mbDict):
  try:
   mbList = list(mbDict)
   VVUel6 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVUel6.append((FF0D7j(subject, VVRkew), FF0D7j(value, VVRkew)))
  except:
   pass
  return VVUel6
 def VVhqAV(self):
  txt = self.VVVjKY("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVVjKY("/proc/bus/nim_sockets")
  if not txt: txt = self.VVPYMo()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFEso0(self, txt)
 def VVPYMo(self):
  txt = ""
  VVy75x = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVy75x("Slot Name" , slot.getSlotName())
     txt += FF0D7j(slotName, VVRkew)
     txt += VVy75x("Description"  , slot.getFullDescription())
     txt += VVy75x("Frontend ID"  , slot.frontend_id)
     txt += VVy75x("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVVjKY(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF6UEw(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF0D7j(line, VVRkew)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVnPaC(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFEso0(self, txt)
 @staticmethod
 def VVkAa1():
  def VVy75x(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVy75x(v,0), "/etc/issue.net": VVy75x(v,1), "/etc/image-version": VVy75x(v,2)}
  for p1, d in v.items():
   img = CCFZiz.VV8iM5(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVy75x(v,0), p + "Plugins/": VVy75x(v,1), VVATu0: VVy75x(v,2), VVzry0: VVy75x(v,3)}
  for p1, d in v.items():
   img = CCFZiz.VVzdyg(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VV8iM5(path, d):
  if fileExists(path):
   txt = FFXk75(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVzdyg(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCh51w(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVutlQ = []
  VVutlQ.append(("Settings (All)"   , "Settings_All"   ))
  VVutlQ.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVutlQ.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVutlQ.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVutlQ.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVutlQ.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVutlQ.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVWEgS:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVutlQ.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVGMYl
   grep = " | grep "
   if   item == "Settings_All"   : FFrGZ9(self, cmd)
   elif item == "Settings_HotKeys"  : FFrGZ9(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFrGZ9(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFrGZ9(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFrGZ9(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFrGZ9(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFrGZ9(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFrGZ9(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFrGZ9(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCkTjP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVkZng, VVSTng, VVKmPG, camCommand = CCkTjP.VVjF3p()
  self.VVSTng = VVSTng
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVSTng:
   c = VVFWDt if VVKmPG else VVqWCE
   if   "oscam" in VVSTng : camName, oC = "OSCam", c
   elif "ncam"  in VVSTng : camName, nC = "NCam" , c
  VVutlQ = []
  VVutlQ.append(("OSCam Files" , "OSCamFiles" ))
  VVutlQ.append(("NCam Files" , "NCamFiles" ))
  VVutlQ.append(("CCcam Files" , "CCcamFiles" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((VVPr8g + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVWOy4" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVutlQ.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVutlQ.append(VVJKCZ)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVutlQ.append(FF47SM(txt, "camInfo", VVSTng, c))
  VVutlQ.append(VVJKCZ)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVSTng:
   for item in camLst: VVutlQ.append(item)
  else:
   for item in camLst: VVutlQ.append((item[0], ))
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CC3XgP, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CC3XgP, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CC3XgP, "cccam"))
   elif item == "VVWOy4" : self.VVWOy4()
   elif item == "OSCamReaders"  : self.VVfsRf("os")
   elif item == "NSCamReaders"  : self.VVfsRf("n")
   elif item == "camInfo"   : FFKENU(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCkTjP.VVRxri(self.session, CChQO0.VVQVbH)
   elif item == "camLiveReaders" : CCkTjP.VVRxri(self.session, CChQO0.VVWJyP)
   elif item == "camLiveLog"  : CCkTjP.VVRxri(self.session, CChQO0.VVdAKf)
   else       : self.close()
 def VVWOy4(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVUQHY, FFKX94())
  if fileExists(path):
   lines = FF6UEw("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVy75x = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVy75x("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVy75x("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVy75x("protocol"   , "cccam"))
      f.write(VVy75x("device"    , "%s,%s" % (host, port)))
      f.write(VVy75x("user"    , User))
      f.write(VVy75x("password"   , Pass))
      f.write(VVy75x("fallback"   , "1"))
      f.write(VVy75x("group"    , "64"))
      f.write(VVy75x("cccversion"   , "2.3.2"))
      f.write(VVy75x("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFmMPS(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFCMcT(tot), outFile))
   else:
    FFhSFw(self, "No valid CCcam lines", 1500)
  else:
   FFhSFw(self, "%s not found" % path, 1500)
 def VVfsRf(self, camPrefix):
  VV796F = self.VVykRD(camPrefix)
  if VV796F:
   VV796F.sort(key=lambda x: int(x[0]))
   if self.VVSTng and self.VVSTng.startswith(camPrefix):
    VVDle6 = ("Toggle State", self.VVCI6U, [camPrefix], "Changing State ...")
   else:
    VVDle6 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVxWCE  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVDle6=VVDle6, VVNWl5=True)
 def VVykRD(self, camPrefix):
  readersFile = self.VVkZng + camPrefix + "cam.server"
  VV796F = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF6UEw(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV796F.append((str(len(VV796F) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV796F:
    FF9Njt(self, "No readers found !")
  else:
   FFvsvw(self, readersFile)
  return VV796F
 def VVCI6U(self, VVhkUd, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVkZng, camPrefix)
  readerState  = VVhkUd.VVxwcf(1)
  readerLabel  = VVhkUd.VVxwcf(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCkTjP.VV4sfi(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVhkUd.VVmw4V()
    FF9Njt(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV796F = self.VVykRD(camPrefix)
   if VV796F:
    VVhkUd.VVoiHv(VV796F)
  else:
   VVhkUd.VVmw4V()
 @staticmethod
 def VV4sfi(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF6UEw(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF9Njt(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF9Njt(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFvsvw(SELF, confFile)
   return None
  if not iRequest:
   FF9Njt(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCkTjP.VVWuZE(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FF9Njt(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVWuZE(SELF):
  if iElem:
   return True
  else:
   FF9Njt(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVRxri(session, VVAH7D):
  VVkZng, VVSTng, VVKmPG, camCommand = CCkTjP.VVjF3p()
  if VVSTng:
   runLog = False
   if   VVAH7D == CChQO0.VVQVbH : runLog = True
   elif VVAH7D == CChQO0.VVWJyP : runLog = True
   elif not VVKmPG          : FFnco7(session, message="SoftCam not started yet!")
   elif fileExists(VVKmPG)        : runLog = True
   else             : FFnco7(session, message="File not found !\n\n%s" % VVKmPG)
   if runLog:
    session.open(BF(CChQO0, VVkZng=VVkZng, VVSTng=VVSTng, VVKmPG=VVKmPG, VVAH7D=VVAH7D))
  else:
   FFnco7(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVjF3p():
  VVkZng = "/etc/tuxbox/config/"
  VVSTng = None
  VVKmPG  = None
  camCommand = FF7jZM("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVSTng = "oscam"
   elif camCmd.startswith("ncam") : VVSTng = "ncam"
  if VVSTng:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFXk75(path), IGNORECASE)
     if span:
      VVkZng = FFqvjY(span.group(1))
      break
   else:
    path = FF7jZM(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFqvjY(path)
    if pathExists(path):
     VVkZng = path
   tFile = FFqvjY(VVkZng) + VVSTng + ".conf"
   tFile = FF7jZM("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVKmPG = tFile
  return VVkZng, VVSTng, VVKmPG, camCommand
class CC3XgP(Screen):
 def __init__(self, VVqpgy, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVkZng, VVSTng, VVKmPG, camCommand = CCkTjP.VVjF3p()
  if   VVqpgy == "ncam" : self.prefix = "n"
  elif VVqpgy == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVutlQ = []
  if self.prefix == "":
   VVutlQ.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVutlQ.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVutlQ.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVutlQ.append(("constant.cw"         , "x_constant_cw" ))
   VVutlQ.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVutlQ.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVutlQ.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVutlQ.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVutlQ.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVutlQ.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVutlQ.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVutlQ.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVutlQ.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVutlQ.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVutlQ.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFc1hL(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFc1hL(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFc1hL(self, self.VVkZng + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFc1hL(self, self.VVkZng + "constant.cw")
   elif item == "x_cam_ccache"  : self.VV6A72("cam.ccache")
   elif item == "x_cam_conf"  : self.VV6A72("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VV6A72("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VV6A72("cam.provid")
   elif item == "x_cam_server"  : self.VV6A72("cam.server")
   elif item == "x_cam_services" : self.VV6A72("cam.services")
   elif item == "x_cam_srvid2"  : self.VV6A72("cam.srvid2")
   elif item == "x_cam_user"  : self.VV6A72("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVpx4R()
   elif item == "x_CCcam_cfg"  : FFc1hL(self, self.VVkZng + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFc1hL(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFc1hL(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFc1hL(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VV6A72(self, fileName):
  FFc1hL(self, self.VVkZng + self.prefix + fileName)
 def VVpx4R(self):
  path = self.VVkZng + "SoftCam.Key"
  if fileExists(path) : FFc1hL(self, path)
  else    : FFc1hL(self, path.replace(".Key", ".key"))
class CChQO0(Screen):
 VVQVbH  = 0
 VVWJyP = 1
 VVdAKf = 2
 def __init__(self, session, VVkZng="", VVSTng="", VVKmPG="", VVAH7D=VVQVbH):
  self.skin, self.skinParam = FFzoo9(VVJPgr, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVKmPG   = VVKmPG
  self.VVAH7D  = VVAH7D
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVkZng + VVSTng + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVSTng : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVkZng, self.camPrefix)
  if self.VVAH7D == self.VVQVbH:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVAH7D == self.VVWJyP:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFk1xo(self, self.Title, addScrollLabel=True)
  FFWr7z(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVqA14
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self["myLabel"].VVABQW(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFlx3W(self)
  self.VVqA14()
 def onExit(self):
  self.timer.stop()
 def VVcCTC(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVRRHM)
  except:
   self.timer.callback.append(self.VVRRHM)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFhSFw(self, "Started", 1000)
 def VVhzql(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVRRHM)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFhSFw(self, "Stopped", 1000)
 def VVqA14(self):
  if self.timerRunning:
   self.VVhzql()
  else:
   self.VVcCTC()
   if self.VVAH7D == self.VVQVbH or self.VVAH7D == self.VVWJyP:
    if self.VVAH7D == self.VVQVbH : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCkTjP.VV4sfi(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFciRl(self.VVWDuh)
    else:
     self.close()
   else:
    self.VVPSnn()
 def VVRRHM(self):
  if self.timerRunning:
   if   self.VVAH7D == self.VVQVbH : self.VV2yfj()
   elif self.VVAH7D == self.VVWJyP : self.VV2yfj()
   else            : self.VVPSnn()
 def VVPSnn(self):
  if fileExists(self.VVKmPG):
   fTime = FFaLO4(os.path.getmtime(self.VVKmPG))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVVNFB(), VVognF=VVlBOt)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVKmPG)
 def VVWDuh(self):
  self.VV2yfj()
 def VV2yfj(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF0D7j("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVUS1a))
   self.camWebIfErrorFound = True
   self.VVhzql()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVAH7D == self.VVQVbH : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF0D7j("Error while parsing data elements !\n\nError = %s" % str(e), VV8a8m)
   self.camWebIfErrorFound = True
   self.VVhzql()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVvsiB(root)
  self["myLabel"].setText(txt, VVognF=VVlBOt)
  self["myBar"].setText("Last Update : %s" % FFExv2())
 def VVvsiB(self, rootElement):
  def VVy75x(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVAH7D == self.VVQVbH:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF0D7j(status, VVRTFm)
    else          : status = FF0D7j(status, VV8a8m)
    txt += SEP + "\n"
    txt += VVy75x("Name"  , name)
    txt += VVy75x("Description" , desc)
    txt += VVy75x("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVy75x("Protocol" , protocol)
    txt += VVy75x("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF0D7j("Yes", VVRTFm)
    else    : enabTxt = FF0D7j("No", VV8a8m)
    txt += SEP + "\n"
    txt += VVy75x("Label"  , label)
    txt += VVy75x("Protocol" , protocol)
    txt += VVy75x("Enabled" , enabTxt)
  return txt
 def VVVNFB(self):
  lines = FFlfx8("tail -n %d %s" % (100, self.VVKmPG))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVQrak + line[:19] + VVBhz1 + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VV0HZq + "WebIf" + VVBhz1)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVJTsP + h1 + h2 + VVBhz1 + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVRTFm + span.group(2) + VVPr8g + span.group(3) + VVBhz1 + span.group(4)
    line = self.VVrSxG(line, VVPr8g, ("(webif)", ))
    line = self.VVrSxG(line, VVPr8g, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVrSxG(line, VVRTFm, ("OSCam", "NCam", "log switched"))
    line = self.VVrSxG(line, VVO7vL, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVRkew + line[ndx + 3:] + VVBhz1
   elif line.startswith("----") or ">>" in line:
    line = FF0D7j(line, VV15Fs)
   txt += line + "\n"
  return txt
 def VVrSxG(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVBhz1 + t3
  return line
class CC8rLK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVutlQ = []
  VVutlQ.append(("Backup Channels"    , "VVC8sT"   ))
  VVutlQ.append(("Restore Channels"    , "Restore_Channels"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Backup SoftCAM Files"   , "VVq44T" ))
  VVutlQ.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVutlQ.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVutlQ.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Backup Network Settings"  , "VVTrrC"   ))
  VVutlQ.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVWEgS:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((VVUS1a + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VV8aYO"   ))
   VVutlQ.append((VVRTFm + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVDVa8), "createMyIpk"   ))
   VVutlQ.append((VVRTFm + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVDVa8), "createMyDeb"   ))
   VVutlQ.append((VVJTsP + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVutlQ.append((VVJTsP + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVIeh1" ))
   VVutlQ.append((VVJTsP + "Show Windows Stats"           , "VVuYT9" ))
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVC8sT"    : self.VVC8sT()
   elif item == "Restore_Channels"    : self.VVxU73("channels_backup*.tar.gz", self.VVi9Mv, isChan=True)
   elif item == "VVq44T"   : self.VVq44T()
   elif item == "Restore_SoftCAM_Files"  : self.VVxU73("softcam_backup*.tar.gz", self.VVkWiI)
   elif item == "Backup_TunerDiSEqC"   : self.VVg2cx("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVxU73("tuner_backup*.backup", BF(self.VVClOI, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVg2cx("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVxU73("hotkey_*backup*.backup", BF(self.VVClOI, "misc"))
   elif item == "VVTrrC"    : self.VVTrrC()
   elif item == "Restore_Network"    : self.VVxU73("network_backup*.tar.gz", self.VVGjtk)
   elif item == "VV8aYO"     : FFfbEx(self, BF(FFVvl9, self, BF(CC8rLK.VV8aYO, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVHDIv(False)
   elif item == "createMyDeb"     : self.VVHDIv(True)
   elif item == "createMyTar"     : self.VV3y59()
   elif item == "VVIeh1"   : self.VVIeh1()
   elif item == "VVuYT9"    : CC8rLK.VVuYT9(self)
 @staticmethod
 def VVVWun(SELF):
  OBF_Path = VV5jqn + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFvsvw(SELF, OBF_Path)
   return None
 @staticmethod
 def VVuYT9(SELF):
  obf = CC8rLK.VVVWun(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFEso0(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VV8aYO(SELF):
  obf = CC8rLK.VVVWun(SELF)
  if obf:
   txt, err = obf.fixCode(VV5jqn, VVFo84, VVDVa8)
   if err : FF9Njt(SELF, err)
   else : FFEso0(SELF, txt)
 def VVHDIv(self, VVb8Ad):
  OBF_Path = VV5jqn + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF9Njt(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FF2ufE("rm -f %s__pycache__/" % VV5jqn)
  FF2ufE("mv -f '%smain.py' '%s'" % (VV5jqn, OBF_Path))
  FF2ufE("mv -f '%splugin.py' '%s'" % (VV5jqn, OBF_Path))
  FF2ufE("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VV5jqn))
  self.session.openWithCallback(self.VV0dW3, BF(CCRQQt, path=VV5jqn, VVb8Ad=VVb8Ad))
 def VV0dW3(self):
  FF2ufE("mv -f %s %s" % (VV5jqn + "OBF/main.py" , VV5jqn))
  FF2ufE("mv -f %s %s" % (VV5jqn + "OBF/plugin.py", VV5jqn))
 def VVIeh1(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF9Njt(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF9Njt(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVr8Vm("%s*.list" % path)
  if err:
   FFvsvw(self, path + "*.list")
   return
  srcF, err = self.VVr8Vm("%s*main_final.py" % path)
  if err:
   FFvsvw(self, path + "*.final.py")
   return
  VVUel6 = []
  for f in files:
   f = os.path.basename(f)
   VVUel6.append((f, f))
  FFre61(self, BF(self.VVkYlE, path, codF, srcF), VVutlQ=VVUel6)
 def VVkYlE(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFvsvw(self, logF)
   else     : FFVvl9(self, BF(self.VVstw9, logF, codF, srcF))
 def VVstw9(self, logF, codF, srcF):
  lst  = []
  lines = FF6UEw(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF9Njt(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVrUdF(lst, logF, newLogF)
  totSrc  = self.VVrUdF(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFEso0(self, txt)
 def VVr8Vm(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVrUdF(self, lst, f1, f2):
  txt = FFXk75(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VV3y59(self):
  VVUel6 = []
  VVUel6.append("%s%s" % (VV5jqn, "*.py"))
  VVUel6.append("%s%s" % (VV5jqn, "*.png"))
  VVUel6.append("%s%s" % (VV5jqn, "*.xml"))
  VVUel6.append("%s"  % (VV8pP1))
  FFe2gd(self, VVUel6, "%s_%s" % (PLUGIN_NAME, VVFo84), addTimeStamp=False)
 def VVC8sT(self):
  path1 = VVGMYl
  path2 = "/etc/tuxbox/"
  VVUel6 = []
  VVUel6.append("%s%s" % (path1, "*.tv"))
  VVUel6.append("%s%s" % (path1, "*.radio"))
  VVUel6.append("%s%s" % (path1, "*list"))
  VVUel6.append("%s%s" % (path1, "lamedb*"))
  VVUel6.append("%s%s" % (path2, "*.xml"))
  FFe2gd(self, VVUel6, self.VV4b21("channels_backup"), addTimeStamp=True)
 def VVq44T(self):
  VVUel6 = []
  VVUel6.append("/etc/tuxbox/config/")
  VVUel6.append("/usr/keys/")
  VVUel6.append("/usr/scam/")
  VVUel6.append("/etc/CCcam.cfg")
  FFe2gd(self, VVUel6, self.VV4b21("softcam_backup"), addTimeStamp=True)
 def VVTrrC(self):
  VVUel6 = []
  VVUel6.append("/etc/hostname")
  VVUel6.append("/etc/default_gw")
  VVUel6.append("/etc/resolv.conf")
  VVUel6.append("/etc/wpa_supplicant*.conf")
  VVUel6.append("/etc/network/interfaces")
  VVUel6.append("%snameserversdns.conf" % VVGMYl)
  FFe2gd(self, VVUel6, self.VV4b21("network_backup"), addTimeStamp=True)
 def VV4b21(self, fName):
  img = CCFZiz.VVkAa1()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVi9Mv(self, fileName=None):
  if fileName:
   FFfbEx(self, BF(FFVvl9, self, BF(self.VVeKGl, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVeKGl(self, fileName):
  path = "%s%s" % (VVUQHY, fileName)
  if fileExists(path):
   if CCLSXF.VVGkwN(path):
    VVcP6r , VVjbHq = CCIdtv.VVMsCA()
    VVlL8F, VVKGHq = CCIdtv.VVVjAF()
    cmd  = FFYhY6("cd %s" % VVGMYl)
    cmd += FFYhY6("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVjbHq, VVKGHq))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FF2ufE(cmd)
    FFURke()
    if ok: FFmMPS(self, "Channels Restored.")
    else : FF9Njt(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FF9Njt(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFvsvw(self, path)
 def VVkWiI(self, fileName=None):
  if fileName:
   FFfbEx(self, BF(self.VVgxtA, fileName), "Overwrite SoftCAM files ?")
 def VVgxtA(self, fileName):
  fileName = "%s%s" % (VVUQHY, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF6W91(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFLPjB(note, VVRkew), sep))
  else:
   FFvsvw(self, fileName)
 def VVGjtk(self, fileName=None):
  if fileName:
   FFfbEx(self, BF(self.VVFQ3a, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVFQ3a(self, fileName):
  fileName = "%s%s" % (VVUQHY, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF9pl1(self,  cmd)
  else:
   FFvsvw(self, fileName)
 def VVxU73(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFfwaK()
  if pathExists(VVUQHY):
   myFiles = FFJwmB(VVUQHY, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVUel6 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVUel6.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVzsZa = ("Sat. List", self.VVLBmb)
    elif isChan and iTar: VVzsZa = ("Bouquets Importer", CC8h2J.VValYu)
    else    : VVzsZa = None
    FFre61(self, callBackFunction, title=title, width=1200, VVutlQ=VVUel6, VVzsZa=VVzsZa, VVBWci=VVUQHY)
   else:
    FF9Njt(self, "No files found in:\n\n%s" % VVUQHY, title)
  else:
   FF9Njt(self, "Path not found:\n\n%s" % VVUQHY, title)
 def VVg2cx(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVGMYl
  tCons = CC4u2A()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVjrbO, filePrefix))
 def VVjrbO(self, filePrefix, result, retval):
  title = FFfwaK()
  if pathExists(VVUQHY):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF9Njt(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVUQHY, filePrefix, self.VV4b21(""), FFKX94())
    try:
     VVUel6 = str(result.strip()).split()
     if VVUel6:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVUel6:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FF0D7j(fName, VVRkew), SEP)
       FFEso0(self, txt, title=title, VVognF=VVlBOt)
      else:
       FF9Njt(self, "File creation failed!", title)
     else:
      FF9Njt(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FF2ufE("rm %s" % fName)
     FF9Njt(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FF2ufE("rm %s" % fName)
     FF9Njt(self, "Error while writing file.")
  else:
   FF9Njt(self, "Path not found:\n\n%s" % VVUQHY, title)
 def VVClOI(self, mode, path=None):
  if path:
   path = "%s%s" % (VVUQHY, path)
   if fileExists(path):
    lines = FF6UEw(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFfbEx(self, BF(self.VVFqVE, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFBhlv(self, path, title=FFfwaK())
   else:
    FFvsvw(self, path)
 def VVFqVE(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVNDa4 = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVNDa4.append("echo -e 'Reading current settings ...'")
  VVNDa4.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVNDa4.append("echo -e 'Preparing new settings ...'")
  VVNDa4.append(settingsLines)
  VVNDa4.append("echo -e 'Applying new settings ...'")
  VVNDa4.append("mv -f %s %s" % (tFile, sFile))
  FFbwen(self, VVNDa4)
 def VVLBmb(self, selectionObj, path):
  if not path:
   return
  path = VVUQHY + path
  if not fileExists(path):
   FFvsvw(self, path)
   return
  txt = FFXk75(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFh9n9(item[1]))
   FFEso0(self, txt, title="Satellites List")
  else:
   FF9Njt(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC8h2J():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VValYu(SELF, fName):
  bi = CC8h2J(SELF)
  bi.instance = bi
  bi.VV5pUj(SELF, fName)
 @staticmethod
 def VVL0PP(SELF):
  bi = CC8h2J(SELF)
  bi.instance = bi
  bi.VV1frO()
 def VV5pUj(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVUQHY + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFVvl9(waitObg, self.VVHMXg, title="Reading bouquets ...")
  else      : self.VVG5Bk(self.filePath)
 def VVBTBJ(self, txt) : FF9Njt(self.SELF, txt, title=self.Title)
 def VVJLdL(self, txt)  : FFhSFw(self, txt, 1500)
 def VVG5Bk(self, path) : FFvsvw(self.SELF, path, title=self.Title)
 def VV1frO(self):
  if pathExists(VVUQHY):
   lst = FFJwmB(VVUQHY, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVTBfR())
   if len(lst) > 0:
    VVutlQ = []
    for item in lst:
     item = os.path.basename(item)
     txt = FF0D7j(item, VVPr8g) if item.endswith(".zip") else item
     VVutlQ.append((txt, item))
    VVutlQ.sort(key=lambda x: x[1].lower())
    VVnFDy = self.VVIV1d
    FFre61(self.SELF, self.VVqhA5, minRows=3, title=self.Title, width=1200, VVutlQ=VVutlQ, VVnFDy=VVnFDy, VVBWci=VVUQHY, VVRdqN="#22111111", VVkSGg="#22111111")
   else:
    self.VVBTBJ("No valid backup files found in:\n\n%s" % VVUQHY)
  else:
   self.VVBTBJ("Backup Directory not found:\n\n%s" % VVUQHY)
 def VVIV1d(self, item=None):
  if item:
   VVG7pv, txt, fName, ndx = item
   self.VV5pUj(VVG7pv, fName)
 def VVqhA5(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVTBfR(self):
  files = FFJwmB(VVUQHY, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVHMXg(self):
  lines, err = CC8h2J.VVH5WB(self.filePath, "bouquets.tv")
  if err:
   self.VVBTBJ(err)
   return
  bTvSortLst  = self.VVQUw2(lines)
  lines, err = CC8h2J.VVH5WB(self.filePath, "bouquets.radio")
  if err:
   self.VVBTBJ(err)
   return
  bRadSortLst = self.VVQUw2(lines)
  VV796F = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVQzrt(f, mode, len(VV796F), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VV796F.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVQzrt(f, mode, len(VV796F), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVQzrt(f, mode, len(VV796F), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VV796F.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVQzrt(f, mode, len(VV796F), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VV796F:
   VV796F.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VV796F): VV796F[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VV796F):
     if key == os.path.basename(row[9]):
      VV796F = VV796F[:ndx+1] + lst + VV796F[ndx+1:]
      break
   for ndx, item in enumerate(VV796F): VV796F[ndx][0] = str(ndx + 1)
   VVTJDG = "#11000600"
   VVOPmD  = ("Show Services" , self.VV9YEJ  , [], "Reading ..." )
   VV5qt4 = (""    , self.VV0jGQ, [])
   VVPOPD = ("Options"  , self.VVHd0Y, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVxWCE  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFvfpt(self.SELF, None, title=self.Title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=24, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVPOPD=VVPOPD, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVRdqN=VVTJDG, VVkSGg=VVTJDG, VVTJDG=VVTJDG, VVChAx="#00004455", VVDQNf="#0a282828")
  else:
   self.VVBTBJ("No valid bouquets in:\n\n%s" % self.filePath)
 def VVQUw2(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VV0jGQ(self, VVhkUd, title, txt, colList):
  FFEso0(self.SELF, FFLAHl(txt), title=title)
 def VVHd0Y(self, VVhkUd, title, txt, colList):
  mSel = CCoGI2(self.SELF, VVhkUd)
  if VVhkUd.VVs7XH:
   totSel = VVhkUd.VVznW9()
   if totSel: VVutlQ = [("Import %s Bouquet%s" % (FF0D7j(str(totSel), VVRTFm), FFCMcT(totSel)), "imp")]
   else  : VVutlQ = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FF0D7j(bName, VVRTFm)
   VVutlQ = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFVvl9, VVhkUd, BF(CC8h2J.VVkAjd, self.SELF, VVhkUd, self.filePath))}
  mSel.VVZZ7l(VVutlQ, cbFncDict)
 def VV9YEJ(self, VVhkUd, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CC8h2J.VVH5WB(self.filePath, "lamedb")
   if err:
    self.VVBTBJ(err)
    return
   dbServLst = CCIdtv.VV9UuU(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVhkUd.VVZqZI()
   lines, err = CC8h2J.VVH5WB(self.filePath, os.path.basename(fName))
   if err:
    self.VVBTBJ(err)
    return
   VV796F = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VV796F.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VV796F.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VV796F.append((span.group(1).strip() or "-", "Stream Relay" if FFcIP1(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VV796F.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VV796F.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCIdtv.VVO8MG(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VV796F.append((name.strip() or "-", FFjfzk(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VV796F):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CC8h2J.VVH5WB(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VV796F[ndx] = (bName, descr)
   if VV796F:
    VVTJDG = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVxWCE = (LEFT  , CENTER)
    FFvfpt(self.SELF, None, title="Services in : %s" % bName, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, VVRdqN=VVTJDG, VVkSGg=VVTJDG, VVTJDG=VVTJDG, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFhSFw(VVhkUd, err, 1500)
  else : VVhkUd.VVmw4V()
 def VVQzrt(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVBTBJ("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFcIP1(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVGQB8(var):
   return str(var) if var else VVwos9 + str(var)
  totItem = VVRkew + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVUS1a   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVPr8g, "Sub-B."
  else  : bColor, totBnb = ""      , VVGQB8(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVGQB8(totDVB), VVGQB8(totIptv), VVGQB8(totSRelay), VVGQB8(totLoc), VVGQB8(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVkAjd(SELF, VVhkUd, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVGMYl + "bouquets.tv"
  radBouquetFile = VVGMYl + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFvsvw(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFvsvw(SELF, radBouquetFile, title=title)
   return
  isMulti = VVhkUd.VVs7XH
  if isMulti : rows = VVhkUd.VVEDPQ()
  else  : rows = [VVhkUd.VVZqZI()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FF9Njt(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFLAHl(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFLAHl(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVGMYl + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVGMYl + newFile
    CC8h2J.VVNPWD(archPath, fName, VVGMYl, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFViMr(tvBouquetFile)
   FFViMr(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CC8h2J.VVLPdz(SELF, archPath, bList)
   FFURke()
  txt  = FF0D7j("Added:\n", VVPr8g)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FF0D7j("Imported to lamedab:\n", VVPr8g)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FF0D7j("Missing from archived lamedb:\n", VVUS1a)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFEso0(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVLPdz(SELF, archPath, bList):
  VVcP6r, err = CCIdtv.VVT54D(SELF, VVWj86=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCIdtv.VVbaZi(VVcP6r, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF6UEw(VVGMYl + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCIdtv.VVO8MG(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCIdtv.VVwroE(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CC8h2J.VV6iwp(archPath, dbName)
   CC8h2J.VVNPWD(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCIdtv.VVbaZi(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCIdtv.VVbaZi(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCIdtv.VVbaZi(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCIdtv.VVbaZi(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFEUy9(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVcP6r + ".tmp"
   lines   = FF6UEw(VVcP6r)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FF2ufE("mv -f '%s' '%s'" % (tmpDbFile, VVcP6r))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVIWrX(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VV6iwp(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVNPWD(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVH5WB(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCNfYP():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVPdWZ()
 def VVPdWZ(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVU6oe(self):
  FFVvl9(self, self.VVOP4W)
 def VVOP4W(self):
  if pathExists(self.projMainPath):
   lst = FFeMpE(self.projMainPath)
   VVutlQ = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVutlQ.append((prName, prName))
   if VVutlQ:
    VVutlQ.sort(key=lambda x: x[1].lower())
    VVnFDy = self.VV2HVY
    VVzsZa = ("Add new project", self.VVzysu)
    VVMTOL= ("Delete Project" , self.VVSpO1)
    self.projMenu = FFre61(self, None, VVutlQ=VVutlQ, width=1100, VVnFDy=VVnFDy, VVzsZa=VVzsZa, VVMTOL=VVMTOL, minRows=5, VVRdqN="#22111133", VVkSGg="#22111133")
   else:
    FFfbEx(self, self.VVbYD1, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVhktn("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVbYD1(self)    : FFVvl9(self, BF(self.VVFspG))
 def VVzysu(self, VVG7pv, item) : FFVvl9(self.projMenu, BF(self.VVFspG))
 def VVFspG(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVt1dQ(name)
 def VVt1dQ(self, name, cbFnc=None):
  FFuRfO(self, cbFnc or self.VVGSBy, defaultText=name, title="New Project Name", message="Enter project name")
 def VVGSBy(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFfbEx(self, BF(self.VVt1dQ, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFiHF8(path)
    if err:
     self.VVhktn("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVWImw((item, item), isSort=True)
     else   : self.VVU6oe()
 def VVSpO1(self, VVG7pv, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFldVs(path)
    FFfbEx(self, BF(self.VV4ABk, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VV4ABk(self, path):
  if FF2ufE("rm -rf '%s'" % path):
   self.projMenu.VV2aSr()
 def VV2HVY(self, item=None):
  if item:
   VVG7pv, txt, Dir, ndx = item
   self.VVPdWZ()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VV8pP1
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FF6UEw(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFExv2()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVCE7W()
   else      : self.VVhktn("Cannot create project file:\n\n%s" % self.projFile)
 def VVCE7W(self, VVG7pv=None, jmpDict=None):
  FFVvl9(VVG7pv or self.projTable or self, BF(self.VV82qu, jmpDict))
 def VV82qu(self, jmpDict):
  self.VVPdWZ()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FF6UEw(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVYgo6(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVhktn('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFrMJ0(path)
    if sz > -1: size = CCLSXF.VVtnwF(sz, mode=4)
    else   : size = FF0D7j("Size error", VVUS1a)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FF6UEw(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVHIA8(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVwBJw(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FF0D7j("Unknown value", VVUS1a), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FF0D7j(rem, VVUS1a), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VV796F = pkgRows
  VV796F.extend(actnRows)
  VV796F.extend(ctrlRows)
  VV796F.extend(fileRows)
  VV796F.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VV796F):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FF0D7j("Valid", VVRTFm), " ... " + Remarks if Remarks else "")
    VV796F[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVoiHv(VV796F, tableRefreshCB=BF(self.VVgolC, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VV5qt4 = (""     , self.VV6wWH   , [])
   menuButtonFnc = (""     , self.VVbFFO   , [])
   VVRsW0 = ("Create Package"  , self.VVmDVE , [])
   VVPOPD = ("Post Install Action", self.VVm0Nw, [])
   VVUum8 = ("Edit File"   , self.VVWtyR  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVxWCE = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, width=1850, height=1040, VVH0vt=26, VV5qt4=VV5qt4, menuButtonFnc=menuButtonFnc, VVRsW0=VVRsW0, VVPOPD=VVPOPD, VVUum8=VVUum8, searchCol=2
         , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVChAx="#00664411", VVDQNf="#00444444", VV4UX1="#08442211")
   self.projTable.VVHrXj(self.VV9if8, True)
 def VVgolC(self, jmpDict, VVhkUd, title, txt, colList):
  self.projTable.VV9SZy(jmpDict)
 def VV9if8(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVZqZI()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVYgo6(self, line):
  def VVOv31(patt, val, Len):
   if len(val) < Len   : return FF0D7j("Length error" , VVUS1a)
   elif not iMatch(patt, val) : return FF0D7j("Invalid format" , VVUS1a)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVOv31(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVOv31(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVHIA8(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFAjaE(path)
  path = FFHx8R(path)
  c = VVUS1a
  if   typ == "Mount" : rem = FF0D7j("Not allowed", c)
  elif not typ  : rem = FF0D7j("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FF0D7j("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFRJjL(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFAjaE(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FF0D7j("Not allowed", c)
     elif targetType == "Directory" : sz = FFRJjL(targetPath)
     elif targetType == "File"  : sz = FFrMJ0(targetPath)
     else       : sz, rem = FFrMJ0(path), FF0D7j("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFrMJ0(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCLSXF.VVtnwF(sz, mode=4)
     else:
      size = FF0D7j("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVwBJw(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVWtyR(self, VVhkUd, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCc3G0(self, path, VVFqvg=self.VVs7Si, curRowNum=lineNdx)
  else    : FFvsvw(self, path)
 def VVs7Si(self, fileChanged):
  if fileChanged:
   self.VVCE7W()
 def VVhktn(self, txt):
  FF9Njt(self, txt, title=self.projTitle)
 def VV6wWH(self, VVhkUd, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVPr8g
  s  = FFl9yk("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFl9yk("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCLSXF.VVtnwF(self.projFilesSize))
  FFEso0(self, s, title="Project Info", width=1600)
 def VVbFFO(self, VVhkUd, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVFWDt, VVqWCE, VVPr8g
  VVutlQ = []
  VVutlQ.append((c1 + "Add Resource File"  , "addFile" ))
  VVutlQ.append((c1 + "Add Resource Directory" , "addDir" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change Package Name"   , "pkgNam" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Add Dependency"   , "addDep" ))
  VVutlQ.append((c2 + "Remove Dependency"  , "delDep" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVutlQ.append(FF47SM('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(FF47SM("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVUS1a))
  FFre61(self, self.VVqIaF, VVutlQ=VVutlQ, width=1050, title="Options", VVRdqN="#11001122", VVkSGg="#11001122")
 def VVqIaF(self, item=None):
  if item:
   if   item == "addFile" : self.VVzWhs(False)
   elif item == "addDir" : self.VVzWhs(True)
   elif item == "pkgNam" : self.VV2FiX()
   elif item == "addDep" : FFVvl9(self.projTable, self.VVxMy2)
   elif item == "delDep" : self.VV6C05()
   elif item == "ctrlFMan" : self.VV2Dgc()
   elif item == "ctrlImprt": FFVvl9(self.projTable, self.VVixAr)
   elif item == "ctrlUndo" : self.VVoF34()
   elif item == "delRow" : self.VV5oYe()
 def VVzWhs(self, isDir):
  Dir = FFiGD2(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVdJil, BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=Dir))
  else : self.session.openWithCallback(self.VVdJil, BF(CCLSXF, patternMode="all", VVXhi5=Dir))
 def VVdJil(self, path):
  if path:
   FF3Ual(CFG.lastPkgProjDir, path)
   self.VVfff6(path, 2)
 def VV2Dgc(self):
  Dir = FFiGD2(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVvOFn, BF(CCLSXF, patternMode="pkgCtrl", VVXhi5=Dir))
 def VVvOFn(self, path):
  if path:
   FF3Ual(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FF2ufE("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVCE7W()
    self.projTable.VV9SZy({1:"Script", 2:fName})
 def VVixAr(self):
  cmd = FFwyvS(VVf00o, "")
  if not cmd:
   FFdRu7(self)
   return
  lst = FFlfx8(cmd)
  if lst:
   err = CCLSXF.VVTvbh(lst, fromFind=False)
   if err:
    self.VVhktn(err)
    return
   lst.sort()
   VV796F = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VV796F.append(("", span.group(1), span.group(2)))
   if VV796F:
    VVDle6 = ("Import 'control' data", self.VVzwcB, [])
    VVPOPD = ("Package Info.", self.VV4HV1     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFvfpt(self, None, header=header, VVUel6=VV796F, VVFNzW=widths, VVH0vt=30, VVDle6=VVDle6, VVPOPD=VVPOPD, VVuFV9=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVRdqN="#22110011", VVkSGg="#22191111", VVTJDG="#22191111", VVChAx="#00003030", VVDQNf="#00333333")
   else:
    self.VVhktn("Cannot process installed packages !")
  else:
   self.VVhktn("Cannot read installed packages !")
 def VVoF34(self):
  if FF2ufE("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVCE7W(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVhktn("Process Failed !")
 def VVzwcB(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVkbYQ, VVhkUd, colList[1]))
 def VVkbYQ(self, VVhkUd, pkg):
  lines = []
  for line in FFlfx8(FFciUY(VV7ZXX, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFfbEx(self, BF(self.VVWYbr, VVhkUd, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVhktn("Cannot import from this package:\n\n%s" % pkg)
 def VVWYbr(self, VVhkUd, lines):
  VVhkUd.cancel()
  FF7q9A(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVCE7W(jmpDict={1:"Control", 2:"Package"})
 def VV5oYe(self):
  lineNum = int(self.projTable.VVZqZI()[0]) + 1
  FF2ufE("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVCE7W()
 def VVfff6(self, line, jmp):
  if fileExists(self.projFile):
   FF7q9A(self.projFile)
   FFViMr(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVCE7W(jmpDict=jmpDict)
  else:
   FFvsvw(self, self.projFile, title=self.projTitle)
 def VVm0Nw(self, VVhkUd, title, txt, colList):
  VVutlQ = []
  VVutlQ.append(FF47SM("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVutlQ.append(FF47SM("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVutlQ.append(FF47SM("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(FF47SM("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVutlQ.append(FF47SM("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVutlQ.append(FF47SM("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFre61(self, self.VVJQK2, VVutlQ=VVutlQ, title="Action (after the package is installed/removed)")
 def VVJQK2(self, item=None):
  if item:
   if   item == "instNon" : self.VVvhAi("postinst", 0)
   elif item == "instRes" : self.VVvhAi("postinst", 1)
   elif item == "instReb" : self.VVvhAi("postinst", 2)
   elif item == "rmNon" : self.VVvhAi("postrm", 0)
   elif item == "rmRes" : self.VVvhAi("postrm", 1)
   elif item == "rmReb" : self.VVvhAi("postrm", 2)
 def VVvhAi(self, subj, val):
  if fileExists(self.projFile):
   lines = FF6UEw(self.projFile)
   FF7q9A(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVfff6("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVCE7W()
 def VV2FiX(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVutlQ = []
  VVutlQ.append((pkg, pkg))
  VVutlQ.append(VVJKCZ)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVPr8g if name == self.projPkg else ""
    VVutlQ.append((c + name, name))
   else:
    VVutlQ.append(VVJKCZ)
  FFre61(self, self.VVAYWX, VVutlQ=VVutlQ, title="Package Name")
 def VVAYWX(self, item=None):
  if item:
   self.VVZdXv("Package", item)
 def VVxMy2(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVutlQ = []
   for item in lst: VVutlQ.append((item, item))
   VVutlQ.sort(key=lambda x: x[0].lower())
   VVG7pv = FFre61(self, self.VVK4Fq, VVutlQ=VVutlQ, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVG7pv.VVU16Q(self.projLastDepends)
  else:
   self.VVhktn("Cannot read dependencies list !")
 def VVK4Fq(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FF6UEw(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVZdXv("Depends", ", ".join(lst))
   else:
    FFhSFw(self.projTable, "Already added", 1500)
    self.projTable.VV9SZy({1:"Control", 2:"Depends"})
 def VV6C05(self):
  lst = []
  for row in self.projTable.VVNCJx():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVutlQ = []
   for item in lst: VVutlQ.append((item, item))
   FFre61(self, BF(self.VVd1z8, lst), VVutlQ=VVutlQ, title="Remove Dependency")
  else:
   self.VVhktn("No dependencies to remove !")
 def VVd1z8(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVZdXv("Depends", ", ".join(lst))
   else:
    FF2ufE("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVCE7W()
 def VVZdXv(self, subj, val):
  lines = FF6UEw(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVCE7W(jmpDict={1:"Control", 2:subj})
 def VVmDVE(self, VVhkUd, title, txt, colList):
  VVutlQ = []
  VVutlQ.append(("Create .ipk"  , "ipk"))
  VVutlQ.append(("Create .deb"  , "deb"))
  VVutlQ.append(("Create .tar.gz" , "tar"))
  FFre61(self, self.VVd2EX, VVutlQ=VVutlQ, width=500, title=self.projTitle)
 def VVd2EX(self, item=None):
  if item:
   FFVvl9(self.projTable, BF(self.VVATYs, item))
 def VVATYs(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVhktn("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVb8Ad, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVb8Ad, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVhktn(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFYhY6("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFLPjB(result  , VVRTFm))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFLPjB(failed, VV8a8m))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFYhY6("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVNCJx()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FF9pl1(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FF2ufE(cmd) or not pathExists(ctrlDir):
   VVhktn(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVOv31(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FF2ufE("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVOv31(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFViMr(dstF)
   FF2ufE("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FF8IJx()
  if VVb8Ad:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFaZl2("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FF9pl1(self, cmd)
class CCunAJ(Screen, CCNfYP):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVzryP, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCNfYP.__init__(self)
  c1, c2, c3, c4 = VVFWDt, VVqWCE, VVQrak, VVPr8g
  VVutlQ = []
  VVutlQ.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c3 + "Remove Packages (show all)"     , "VVcLn9sAll"  ))
  VVutlQ.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Update Packages List from Feed"    , "VVVmz0"  ))
  VVutlQ.append((c2 + "Upgradable Packages"       , "VVRjOR" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Packaging Tool"         , "VV5c0p"   ))
  VVutlQ.append(("Active Feeds"          , "VVkaQI"   ))
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CC13qe.VVdwGB(self)
   elif item == "downloadInstallPackages"  : FFVvl9(self, BF(self.VVkxIy, 0, ""))
   elif item == "VVcLn9sAll"   : FFVvl9(self, BF(self.VVkxIy, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFVvl9(self, BF(self.VVkxIy, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVVmz0"   : CCunAJ.VVVmz0(self)
   elif item == "VVRjOR"  : FFVvl9(self, self.VVRjOR)
   elif item == "packageCreator"    : self.VVU6oe()
   elif item == "VV5c0p"    : self.VV5c0p()
   elif item == "VVkaQI"    : FFVvl9(self, self.VVkaQI)
   else          : self.close()
 def VVkaQI(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VV796F = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VV796F.append((os.path.basename(path), str(tot)))
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVxWCE = (LEFT  , CENTER )
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, width=1000, VVH0vt=26, VV6Uvt=2)
  else:
   self.VVhktn("Cannot read packages list !")
 def VVRjOR(self, VVhkUd=None):
  lst = FFlfx8(FFwyvS(VVadqV, ""))
  VV796F = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VV796F.append((str(len(VV796F) + 1), pkg, curV, newVer))
   if VV796F:
    if VVhkUd:
     VVhkUd.VVoiHv(VV796F, VVanXbMsg=True)
    else:
     bg = "#00221111"
     VVDle6 = ("Upgrade", self.VVchAE   , [])
     VVPOPD = ("Package Info.", self.VV4HV1 , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVxWCE = (CENTER , LEFT  , LEFT  , LEFT   )
     FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, width=1700, VVH0vt=26, VVDle6=VVDle6, VVPOPD=VVPOPD, VVNWl5=True, VVdQKE=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVVcQT="#00ffff55", VVChAx="#00003040")
  if not VV796F:
   FFGp67(self, "Nothing to upgrade", 1500)
   if VVhkUd: VVhkUd.cancel()
 def VVchAE(self, VVhkUd, title, txt, colList):
  pkg = colList[1]
  cmd = FFciUY(VVtZiS, pkg)
  if cmd : FF9pl1(self, cmd, title="Installing : %s" % pkg, VVsWF3=BF(self.VVRjOR, VVhkUd))
  else : FFdRu7(SELF)
 def VV5c0p(self):
  pkg = FF3UQa()
  aptT = "apt - Advanced Package Tool" if FFVjaP("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFmMPS(self, txt or "No packaging tools found!")
 def VVkxIy(self, mode, grep, VVhkUd=None, title=""):
  if   mode == 0: cmd = FFwyvS(VVUphI    , grep)
  elif mode == 1: cmd = FFwyvS(VVf00o , grep)
  elif mode == 2: cmd = FFwyvS(VVf00o , grep)
  if not cmd:
   FFdRu7(self)
   return
  VV796F = FFlfx8(cmd)
  if VV796F:
   err = CCLSXF.VVTvbh(VV796F, fromFind=False)
   if err:
    FF9Njt(self, err)
    return
  else:
   if VVhkUd: VVhkUd.VVmw4V()
   FF9Njt(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVUel6  = []
  for item in VV796F:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVUel6.append((name, package, version))
  if mode > 0:
   extensions = FFlfx8("ls %s -l | grep '^d' | awk '{print $9}'" % VVzry0)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVUel6:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVsYl4: name += "el"
      VVUel6.append((name, VVzry0 + item, "-"))
   systemPlugins = FFlfx8("ls %s -l | grep '^d' | awk '{print $9}'" % VVATu0)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVUel6:
      if item.lower() == row[0].lower():
       break
     else:
      VVUel6.append((item, VVATu0 + item, "-"))
  if not VVUel6:
   FF9Njt(self, "No packages found!")
   return
  if VVhkUd:
   VVUel6.sort(key=lambda x: x[0].lower())
   VVhkUd.VVoiHv(VVUel6, title)
  else:
   widths = (20, 50, 30)
   VVDle6 = None
   VVUum8 = None
   if mode == 0:
    VVRsW0 = ("Install" , self.VVklBn   , [])
    VVDle6 = ("Download" , self.VVIpyV   , [])
    VVUum8 = ("Filter"  , self.VV5fIE , [])
   elif mode == 1:
    VVRsW0 = ("Uninstall", self.VVcLn9, [])
   elif mode == 2:
    VVRsW0 = ("Uninstall", self.VVcLn9, [])
    widths= (18, 57, 25)
   VVUel6.sort(key=lambda x: x[0].lower())
   VVPOPD = ("Package Info.", self.VV4HV1, [])
   header   = ("Name" ,"Package" , "Version" )
   FFvfpt(self, None, header=header, VVUel6=VVUel6, VVFNzW=widths, VVH0vt=28, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, VVuFV9=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVRdqN="#22110011", VVkSGg="#22191111", VVTJDG="#22191111", VVChAx="#00003030", VVDQNf="#00333333")
 def VV4HV1(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVdhMt, VVhkUd, colList[1]))
 def VVdhMt(self, VVhkUd, pkg):
  if pathExists(pkg):
   pkg, err = CCunAJ.VVwB2b(pkg)
   if err:
    FFGp67(VVhkUd, err, 1000)
    return
  CCunAJ.VVQnRR(self, pkg)
 def VV5fIE(self, VVhkUd, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVutlQ = []
  VVutlQ.append(("All Packages", "all"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVutlQ.append(VVJKCZ)
  for word in words:
   VVutlQ.append((word, word))
  FFre61(self, BF(self.VVSpkw, VVhkUd), VVutlQ=VVutlQ, title="Select Filter")
 def VVSpkw(self, VVhkUd, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFVvl9(VVhkUd, BF(self.VVkxIy, 0, grep, VVhkUd, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVcLn9(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVoGQq, VVhkUd, colList[1]))
 def VVoGQq(self, VVhkUd, package):
  if pathExists(package):
   pkg, err = CCunAJ.VVwB2b(package)
   if pkg:
    package = pkg
  if package.startswith((VVzry0, VVATu0)):
   FFfbEx(self, BF(self.VVEB19, VVhkUd, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVutlQ = []
   VVutlQ.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVutlQ.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVutlQ.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFre61(self, BF(self.VV3iVt, VVhkUd, package), VVutlQ=VVutlQ)
 def VVEB19(self, VVhkUd, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVYXrW)
  FF9pl1(self, cmd, VVsWF3=BF(self.VV4cyk, VVhkUd))
 def VV3iVt(self, VVhkUd, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVRTxu
   elif item == "remove_ForceRemove"  : cmdOpt = VVHJv5
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV472U
   FFfbEx(self, BF(self.VVZKoa, VVhkUd, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVZKoa(self, VVhkUd, package, cmdOpt):
  self.lastSelectedRow = VVhkUd.VVSWzf()
  cmd = FFciUY(cmdOpt, package)
  if cmd : FF9pl1(self, cmd, VVsWF3=BF(self.VV4cyk, VVhkUd))
  else : FFdRu7(self)
 def VV4cyk(self, VVhkUd):
  VVhkUd.cancel()
  FFT3Ui()
 def VVklBn(self, VVhkUd, title, txt, colList):
  package  = colList[1]
  VVutlQ = []
  VVutlQ.append(("Install Package"        , "install_CheckVersion" ))
  VVutlQ.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVutlQ.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVutlQ.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVutlQ.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFre61(self, BF(self.VVotWQ, package), VVutlQ=VVutlQ)
 def VVotWQ(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVtZiS
   elif item == "install_ForceReinstall" : cmdOpt = VVpQG6
   elif item == "install_ForceOverwrite" : cmdOpt = VVaEyM
   elif item == "install_ForceDowngrade" : cmdOpt = VVobz0
   elif item == "install_IgnoreDepends" : cmdOpt = VVbZpU
   FFfbEx(self, BF(self.VVbgBW, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVbgBW(self, package, cmdOpt):
  cmd = FFciUY(cmdOpt, package)
  if cmd : FF9pl1(self, cmd, VVsWF3=FFT3Ui, checkNetAccess=True)
  else : FFdRu7(self)
 def VVIpyV(self, VVhkUd, title, txt, colList):
  package  = colList[1]
  FFfbEx(self, BF(self.VVLm2n, package), "Download Package ?\n\n%s" % package)
 def VVLm2n(self, package):
  if CCYYaf.VVmh4s():
   cmd = FFciUY(VVQqp7, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFLPjB(success, VVRTFm))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFLPjB(fail, VV8a8m))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF9pl1(self, cmd, VVivQn=[VV8a8m, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFdRu7(self)
  else:
   FF9Njt(self, "No internet connection !")
 @staticmethod
 def VVVmz0(SELF):
  cmd = FFwyvS(VVy8pU, "")
  if cmd : FF9pl1(SELF, cmd, checkNetAccess=True)
  else : FFdRu7(SELF)
 @staticmethod
 def VVwB2b(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFlfx8(FFciUY(VVI3NW, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVQnRR(SELF, package, title=""):
  title = title or package
  infoCmd  = FFciUY(VV7ZXX, package)
  filesCmd = FFciUY(VV3lW5, package)
  listInstCmd = FFwyvS(VVf00o, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFGl7m(VVRkew)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFLPjB(notInst, VVUS1a))
   cmd += "else "
   cmd +=   FFm5eu("System Info", VVRkew)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFm5eu("Related Files", VVRkew)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFmUBH(SELF, cmd, title=title)
  else:
   FFdRu7(SELF, title=title)
class CC7DUr():
 def VVE73I(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVftdc()
 def VVftdc(self):
  files = FFJwmB(VVUQHY, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVutlQ = []
   for fil in files:
    VVutlQ.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVRdqN, VVkSGg = "#22221133", "#22221133"
   else    : VVRdqN, VVkSGg = "#22003344", "#22002233"
   VVzsZa  = ("Add new File", self.VVqSRi)
   FFre61(self, self.VVKsZp, VVutlQ=VVutlQ, width=1100, VVzsZa=VVzsZa, VVBWci="", minRows=4, VVRdqN=VVRdqN, VVkSGg=VVkSGg)
  else:
   FFfbEx(self, self.VVGpBk, "No files found.\n\nCreate a new file ?")
 def VVGpBk(self):
  path = self.VVJXPI()
  if fileExists(path) : self.VVftdc()
  else    : FFhSFw(self, "Cannot create file", 1500)
 def VVqSRi(self, VVG7pv, path):
  path = self.VVJXPI()
  VVG7pv.VVWImw((os.path.basename(path), path), isSort=True)
 def VVJXPI(self):
  path = "%s%s%s.xml" % (VVUQHY, self.shareFilePrefix, FFKX94())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVKsZp(self, path=None):
  if path:
   FFVvl9(self, BF(self.VV15Ny, path))
 def VV15Ny(self, path):
  if not fileExists(path):
   FFvsvw(self, path)
   return
  elif not CCLSXF.VVpzqc(self, path, FFfwaK()):
   return
  else:
   self.shareFilePath = path
  if not CCkTjP.VVWuZE(self):
   return
  tree = CCIdtv.VVkEFl(self, self.shareFilePath)
  if not tree:
   return
  refLst = CC0axI.VV9HVA()
  def VVy75x(refCode):
   if   FFTYUK(refCode): return FF0D7j("DVB", VVFWDt)
   elif refCode in refLst     : return FF0D7j("IPTV", VVFWDt)
   else         : return ""
  VV796F= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVZIWd(ch)
   if ok:
    srcTxt = VVy75x(srcRef)
    dstTxt = VVy75x(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VV796F:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VV796F.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VV796F:
   if self.shareIsRef : VVRdqN, VVkSGg, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVRdqN, VVkSGg, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVAWwW = (""    , BF(self.VVyvv4, dupl), [])
   VV5qt4 = (""    , self.VVf1a3    , [])
   VVRsW0 = ("Delete Entry" , self.VVDxlI   , [])
   VVDle6 = ("Add Entry"  , self.VVkbRr   , [])
   VVPOPD = (optTxt   , self.VVW5TA  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVxWCE = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVhkUd = FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=24, VVAWwW=VVAWwW, VV5qt4=VV5qt4, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVNWl5=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVkSGg, VVChAx="#0a000000")
  else:
   FF9Njt(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVyvv4(self, dupl, VVhkUd, title, txt, colList):
  if dupl:
   VVhkUd.VVRR2a("Skipped %d duplicate%s" % (dupl, FFCMcT(dupl)), 2000)
 def VVf1a3(self, VVhkUd, title, txt, colList):
  def VVy75x(key, val): return "%s\t: %s\n" % (key, val or FF0D7j("?", VVO7vL))
  Keys = VVhkUd.VVIvJH()
  Vals = VVhkUd.VVZqZI()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVy75x(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVRTFm, VVO7vL
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFEso0(self, txt + txt1, title=title)
 def VVZIWd(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVDxlI(self, VVhkUd, title, txt, colList):
  if VVhkUd.VVSWzf() == 0 and VVhkUd.VVc8ws() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFfbEx(self, BF(self.VVfbXt, isLast, VVhkUd), ques)
 def VVfbXt(self, isLast, VVhkUd):
  if isLast:
   FFEUy9(self.shareFilePath)
   VVhkUd.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVhkUd.VVZqZI()
   if self.VVspAG(srcName, srcRef, dstName, dstRef):
    VVhkUd.VVfA76()
    VVhkUd.VV3qTB()
    FFhSFw(VVhkUd, "Deleted", 500, isGrn=True)
   else:
    FFhSFw(VVhkUd, "Cannot delete from file", 2000)
 def VVkbRr(self, VVhkUd, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVqctm(VVhkUd, isDvb=True)
  else    : self.VVmZmt(VVhkUd, "Source Channel", "#22003344", "#22002233")
 def VVmZmt(self, mainTableInst, title, VVRdqN, VVkSGg):
  FFre61(self, BF(self.VVO7sm, mainTableInst, title), VVutlQ=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVRdqN=VVRdqN, VVkSGg=VVkSGg)
 def VVO7sm(self, mainTableInst, title, item=None):
  if item:
   FFVvl9(mainTableInst, BF(self.VVIRch, mainTableInst, title, item), clearMsg=False)
 def VVIRch(self, mainTableInst, title, item):
  FFhSFw(mainTableInst)
  if item == "DVB": self.VVqctm(mainTableInst, isDvb=True)
  else   : self.VVqctm(mainTableInst, isDvb=False)
 def VVVbZU(self, mainTableInst, chType, VVhkUd, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVhkUd.VVSWzf()
  if   chType == "DVB" : FF3Ual(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FF3Ual(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVNCJx()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FF9Njt(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVSDLU(srcName, srcRef, dstName, dstRef):
      mainTableInst.VV6y5N((str(mainTableInst.VVc8ws() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFhSFw(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFhSFw(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFhSFw(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVqctm(mainTableInst, isDvb=False)
   else    : FFciRl(BF(self.VVmZmt, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVhkUd.cancel()
 def VVJSpX(self, item, VVhkUd, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVhkUd.VVfMAJ(ndx)
 def VVqctm(self, VVhkUd, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVVbZU, VVhkUd, typ)
  doneFnc = BF(self.VVJSpX, typ)
  if isDvb: CC7DUr.VV25Kf(VVhkUd , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CC7DUr.VVIyLT(VVhkUd, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VV25Kf(SELF, title, okFnc, doneFnc=None):
  FFVvl9(SELF, BF(CC7DUr.VVgspM, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVgspM(SELF, title, okFnc, doneFnc=None):
  VV796F, err = CCIdtv.VVu18q(SELF, CCIdtv.VVIF6H)
  if VV796F:
   color = "#0a000022"
   VV796F.sort(key=lambda x: x[0].lower())
   VVOPmD = ("Select" , okFnc, [])
   VVAWwW= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVxWCE = (LEFT  , LEFT  , CENTER, LEFT    )
   FFvfpt(SELF, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVRdqN=color, VVkSGg=color, VVTJDG=color, VVOPmD=VVOPmD, VVAWwW=VVAWwW, lastFindConfigObj=CFG.lastFindServices)
  else:
   FF9Njt(SELF, "No DVB Services !")
 @staticmethod
 def VVIyLT(SELF, title, okFnc, doneFnc=None):
  FFVvl9(SELF, BF(CC7DUr.VV5v8C, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VV5v8C(SELF, title, okFnc, doneFnc=None):
  VV796F = CC7DUr.VV6rNr()
  if VV796F:
   color = "#0a112211"
   VV796F.sort(key=lambda x: x[0].lower())
   VVOPmD = ("Select" , okFnc, [])
   VVAWwW= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFvfpt(SELF, None, title=title, header=header, VVUel6=VV796F, VVFNzW=widths, VVH0vt=26, VVRdqN=color, VVkSGg=color, VVTJDG=color, VVOPmD=VVOPmD, VVAWwW=VVAWwW, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF9Njt(SELF, "No IPTV Services !")
 @staticmethod
 def VV6rNr():
  VV796F = []
  files  = CC3ZOl.VVYQhO()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFXk75(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVHrCe = span.group(1)
    else : VVHrCe = ""
    VVHrCe_lCase = VVHrCe.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VV796F.append((chName, VVHrCe, url, refCode))
  return VV796F
 def VVSDLU(self, srcName, srcRef, dstName, dstRef):
  tree = CCIdtv.VVkEFl(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVNDf5(tree, root)
  return True
 def VVspAG(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCIdtv.VVkEFl(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVZIWd(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVNDf5(tree, root)
  return found
 def VVNDf5(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCIdtv.VV4GYC(xmlTxt)
  parser = CCIdtv.CC0Fvg()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVW5TA(self, VVhkUd, title, txt, colList):
  if self.onlyEpg:
   self.VVuhmV(VVhkUd, "epg")
  else:
   if self.shareIsRef:
    FFfbEx(self, BF(FFVvl9, VVhkUd, BF(self.VV3NQg, VVhkUd)), "Copy all References from Source to Destination ?")
   else:
    VVutlQ = []
    VVutlQ.append(("Copy EPG\t (All List)" , "epg"  ))
    VVutlQ.append(("Copy Picons\t (All List)" , "picon" ))
    FFre61(self, BF(self.VVuhmV, VVhkUd), VVutlQ=VVutlQ, width=1000)
 def VVuhmV(self, VVhkUd, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVu7et  , "EPG"
   elif item == "picon": fnc, txt = self.VVuWJZ , "PIcons"
   title = "Copy %s" % txt
   tot   = VVhkUd.VVc8ws()
   FFfbEx(self, BF(FFVvl9, VVhkUd, BF(fnc, VVhkUd, title)), "Overwrite %s for %d Service%s ?" % (FF0D7j(txt, VVRkew), tot, FFCMcT(tot)), title=title)
 def VV3NQg(self, VVhkUd):
  files = CC3ZOl.VVYQhO()
  totChange = 0
  if files:
   for path in files:
    txt = FFXk75(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVhkUd.VVNCJx():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFURke()
  tot = VVhkUd.VVc8ws()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFEso0(self, txt)
 def VVuWJZ(self, VVhkUd, title):
  if not iCopyfile:
   FF9Njt(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CC3hRa.VV3CCT()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVhkUd.VVNCJx():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVhkUd.VVc8ws()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFEso0(self, txt, title=title)
 def VVu7et(self, VVhkUd, title):
  txt, err = CCvK6a.VVtBgm(VVhkUd, title)
  if err : FF9Njt(self, err, title=title)
  else : FFEso0(self, txt, title=title)
 class CC0Fvg(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVkEFl(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCIdtv.CC0Fvg())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FF0D7j("XML Parse Error in:", VVO7vL), path)
   txt += "%s\n%s\n\n" % (FF0D7j("Error:", VVO7vL), str(e))
   FFEso0(SELF, txt, VVTJDG="#11220000", title=title)
   return None
 @staticmethod
 def VV4GYC(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCvK6a(Screen, CC7DUr):
 VVBXR0  = "BDTSE"
 VVpJfy   = "save"
 VVl7jR   = "load"
 VVndUs  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVzryP, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCvK6a.VVaVOy()
  qUrl, iptvRef = CC3ZOl.VVkdjp(self)
  VVutlQ = []
  VVutlQ.append((VVFWDt + "Cache File Info." , "inf"))
  VVutlQ.append(VVJKCZ)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVutlQ.append(FF47SM("Save EPG to File%s" % fTxt , self.VVpJfy, valid))
  VVutlQ.append(FF47SM("Load EPG from File%s" % fTxt , self.VVl7jR, valid))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((VVUS1a + "Delete EPG (from RAM only)", self.VVndUs))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(FF47SM("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVutlQ.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Translate Current Channel EPG %s(Experimental)" % VVUS1a, "VVKOHq"))
  FFk1xo(self, VVutlQ=VVutlQ)
  self.onShown.append(self.VVywsT)
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVDltj()
   elif item in (self.VVpJfy, self.VVl7jR, self.VVndUs):
    reset = item == self.VVl7jR
    FFfbEx(self, BF(FFVvl9, self, BF(self.VV1rO2, item, reset)), VVumEG="Continue ?")
   elif item == "refreshIptvEPG"  : CC3ZOl.VVHFOc(self)
   elif item == "VVKOHq" : self.VVKOHq()
   elif item == "copyEpg"    : self.VVE73I(False, onlyEpg=True)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VV1rO2(self, act, reset=False):
  ok = CCvK6a.VVEb6V(act)
  if ok:
   if reset:
    CCvK6a.VV4wVo(self)
   FFmMPS(self, "Done")
  else:
   FFmMPS(self, "Failed!")
 def VVDltj(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCvK6a.VVaVOy()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FF0D7j("File not found (check System EPG settings).", VVUS1a))
   FFEso0(self, txt, title=title)
  else:
   FF9Njt(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VV0D2W():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVKOHq(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVOPmD  = (""  , BF(self.VVODrh, title, True) , [])
  VVDle6 = ("Start" , BF(self.VVODrh, title, False), [])
  VVUum8 = ("Change Language", self.VVi2Y5      , [])
  widths  = (70 , 30)
  VVxWCE = (LEFT , CENTER)
  FFvfpt(self, None, title=title, VVUel6=self.VVff7L(), VVxWCE=VVxWCE, VVFNzW=widths, width=1200, vMargin=20, VVH0vt=30, VVOPmD=VVOPmD, VVDle6=VVDle6, VVUum8=VVUum8, VV6Uvt=2
    , VVRdqN="#11201010", VVkSGg=bg, VVTJDG=bg, VVChAx="#00004455", VVDQNf=bg)
 def VVff7L(self):
  Def, ch = "DISABLED", dict(CCvK6a.VV0D2W())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVUel6 = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVUel6
 def VVi2Y5(self, VVhkUd, title, txt, colList):
  ndx = VVhkUd.VVSWzf()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCpO9T.VVsCHV(self, confItem, title, lst=CCvK6a.VV0D2W(), cbFnc=BF(self.VVY4Sm, VVhkUd), isSave=True)
 def VVY4Sm(self, VVhkUd):
  for ndx, row in enumerate(self.VVff7L()):
   VVhkUd.VVmJSt(ndx, row)
 def VVODrh(self, Title, isAsk, VVhkUd, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFhSFw(VVhkUd, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
   refCode, evList, err = CCvK6a.VVSFa8(refCode)
   fnc = BF(self.VVYGC2, Title, refCode, evList, VVhkUd)
   if   err : FF9Njt(self, err, title=Title)
   elif isAsk : FFfbEx(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVYGC2(self, title, refCode, evList, VVhkUd):
  self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVRBgw, evList)
      , VVFqvg = BF(self.VVRoEI, title, refCode))
  VVhkUd.cancel()
 def VVRBgw(self, evList, VVdu90):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVdu90.VV7hIf(totEv)
  VVdu90.VVeIVc = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCvK6a.VVzu7Q(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVRbmv(1)
   VVdu90.VVThQs(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVdu90.VVeIVc = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVRoEI(self, title, refCode, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVeIVc
  if newLst: totEv, totOK = CCvK6a.VVKaCW(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCvK6a.VVyfRr()
   CCvK6a.VV4wVo(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFEso0(self, txt, title=title)
 @staticmethod
 def VVzu7Q(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVy75x(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCvK6a.VVZTbf(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVy75x, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVZTbf(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFROgB(txt))
   txt, err = CC3ZOl.VVxuE9(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FF2zGt(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCvK6a.VVP7Et(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVaVOy():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFrMJ0(path)
   szTxt = CCLSXF.VVtnwF(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VV0H7j():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVyfRr(): CCvK6a.VVEb6V(CCvK6a.VVpJfy)
 @staticmethod
 def VVEb6V(act):
  ec, inst = CCvK6a.VV0H7j()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VV4wVo(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVSFa8(refCode):
  ec, inst = CCvK6a.VV0H7j()
  if inst:
   try:
    evList = inst.lookupEvent([CCvK6a.VVBXR0, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVKaCW(refCode, events, longDescDays=0):
  ec, inst = CCvK6a.VV0H7j()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVseo6(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCvK6a.VV0H7j()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCvK6a.VVRhNI(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCY1HC.CCvK6a(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVRhNI(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCvK6a.VVc0NP(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVsrtb(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCvK6a.VV0H7j()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCvK6a.VVRhNI(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFaLO4(evTime)
       evEndTxt  = FFaLO4(evEnd)
       evDurTxt  = FFnZVI(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFnZVI(evPos)
        evRem = evEnd - now
        evRemTxt = FFnZVI(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFnZVI(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVc0NP(event):
  genre = PR = ""
  try:
   genre  = CCvK6a.VVZwTi(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCvK6a.VVvUjo(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVvUjo(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVZwTi(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCvK6a.VVUqKC()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVUqKC():
  path = VV8pP1 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFXk75(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFXk75(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVtBgm(VVhkUd, title):
  ec, inst = CCvK6a.VV0H7j()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVhkUd.VVNCJx():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCvK6a.VVBXR0, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCvK6a.VVKaCW(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCvK6a.VVyfRr()
  txt  = "Services\t: %d\n"  % VVhkUd.VVc8ws()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVtNy0(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCvK6a.VVFKOY(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCvK6a.VVFKOY(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCvK6a.VVFKOY(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVFKOY(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvK6a.VVRhNI(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCvK6a.VVzu7Q(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FF0D7j(evName, VVPr8g)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FF0D7j(evNameTransl, VVPr8g))
    if evTime           : txt += "Start Time\t: %s\n" % FFaLO4(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFaLO4(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFnZVI(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFnZVI(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFnZVI(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF0D7j(evShort, VVqWCE)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF0D7j(evDesc , VVqWCE)
    if txt:
     txt = FF0D7j("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVPr8g) + txt
  return txt
 @staticmethod
 def VVP7Et(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCIdtv(Screen, CC7DUr):
 VVhiz0  = 0
 VVecz5 = 1
 VVDRdY  = 2
 VVcYvk  = 3
 VV17og = 4
 VVbDDC = 5
 VV2yf4 = 6
 VVIF6H   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVzryP, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVEwkw = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVutlQ = self.VVJ8vv()
  FFk1xo(self, VVutlQ=VVutlQ, title="Services/Channels")
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self["myMenu"].setList(self.VVJ8vv())
  FFRLsp(self["myMenu"])
  FFkPKs(self)
 def VVJ8vv(self):
  VVutlQ = []
  c = VVFWDt
  VVutlQ.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVutlQ.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVutlQ.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVutlQ.append(VVJKCZ)
  c = VVPr8g
  VVutlQ.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVutlQ.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVutlQ.append((VVO7vL + "More tables ..."     , "VVglWp"    ))
  c = VVqWCE
  VVutlQ.append(VVJKCZ)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVutlQ.append((c + txt          , "VVL0PP"  ))
  else : VVutlQ.append((txt           ,          ))
  VVutlQ.append((c + 'Export Services to "channels.xml"'    , "VVI0cP"      ))
  VVutlQ.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVQrak
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVutlQ.append((c + "Invalid Services Cleaner"       , "VVE0fg"    ))
  c = VVQrak
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c + "Delete Channels with no names"     , "VVgBYN"    ))
  VVutlQ.append((c + "Delete Empty Bouquets"       , "VVGJ5N"     ))
  VVutlQ.append(VVJKCZ)
  VVcP6r, VVjbHq = CCIdtv.VVMsCA()
  if fileExists(VVcP6r):
   enab = fileExists(VVjbHq)
   if enab: VVutlQ.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVutlQ.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVutlQ.append(("Reset Parental Control Settings"      , "VVHcUr"    ))
  VVutlQ.append(("Reload Channels and Bouquets"       , "VVpE62"      ))
  return VVutlQ
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCGzpp.VVfWLm(self.session)
   elif item == "openSignal"       : FFR4Pq(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FF0gQ0(self, fncMode=CCY1HC.VVbVB0)
   elif item == "lameDB_allChannels_with_refCode"  : FFVvl9(self, self.VVmpzs)
   elif item == "lameDB_allChannels_with_tranaponder" : FFVvl9(self, self.VVP8sD)
   elif item == "VVglWp"     : self.VVglWp()
   elif item == "VVL0PP"  : CC8h2J.VVL0PP(self)
   elif item == "VVI0cP"      : self.VVI0cP()
   elif item == "copyEpgPicons"      : self.VVE73I(False)
   elif item == "SatellitesCleaner"     : FFVvl9(self, self.FFVvl9_SatellitesCleaner)
   elif item == "VVE0fg"    : FFVvl9(self, BF(self.VVE0fg))
   elif item == "VVgBYN"    : FFVvl9(self, self.VVgBYN)
   elif item == "VVGJ5N"     : self.VVGJ5N(self)
   elif item == "enableHiddenChannels"     : self.VVeqD3(True)
   elif item == "disableHiddenChannels"    : self.VVeqD3(False)
   elif item == "VVHcUr"    : FFfbEx(self, self.VVHcUr, "Reset and Restart ?")
   elif item == "VVpE62"      : FFVvl9(self, BF(CCIdtv.VVpE62, self))
 def VVglWp(self):
  VVutlQ = []
  VVutlQ.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVutlQ.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVutlQ.append(("Services with PIcons for the System"  , "VVwKA2"    ))
  VVutlQ.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVutlQ.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFre61(self, self.VVF4yI, VVutlQ=VVutlQ, title="Service Information", VVNxG7=True)
 def VVF4yI(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFVvl9(self, BF(self.VVy1i9, title))
   elif ref == "parentalControlChannels"   : FFVvl9(self, BF(self.VVqLhy, title))
   elif ref == "showHiddenChannels"    : FFVvl9(self, BF(self.VVs7rz, title))
   elif ref == "VVwKA2"    : FFVvl9(self, BF(self.VVZX3S, title))
   elif ref == "servicesWithMissingPIcons"   : FFVvl9(self, BF(self.VVEH6M, title))
   elif ref == "TranspondersStats"     : FFVvl9(self, BF(self.VVePxK, title))
   elif ref == "SatellitesXmlStats"    : FFVvl9(self, BF(self.VVCfB2, title))
 def VVI0cP(self):
  VVutlQ = []
  VVutlQ.append(("All DVB-S/C/T Services", "all"))
  VVutlQ.extend(CC0axI.VVt3TU())
  FFre61(self, self.VV8uLl, VVutlQ=VVutlQ, title="", VVNxG7=True)
 def VV8uLl(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCIdtv.VV6cZh("1:7:")
   else   : lst = FFmpJ8(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFjfzk(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFcIP1(r)  : sat = "Stream Relay"
       elif FF4MQW(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFqvjY(CFG.exportedTablesPath.getValue()), FFKX94())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFmMPS(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFhSFw(self, "No Services found !", 1500)
 @staticmethod
 def VVpE62(SELF):
  FFURke()
  FFmMPS(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVmpzs(self):
  self.VVEwkw = None
  self.lastfilterUsed  = None
  self.filterObj   = CCtamE(self)
  VV796F, err = CCIdtv.VVu18q(self, self.VVhiz0)
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   VVOPmD  = ("Zap"   , self.VVK0S4     , [])
   VV5qt4 = (""    , self.VVhJEt   , [])
   VVPOPD = ("Options"  , self.VVmemx , [])
   VVDle6 = ("Current Service", self.VV13EK , [])
   VVUum8 = ("Filter"   , self.VVqKmy  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVxWCE  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindServices)
 def VVP8sD(self):
  self.VVEwkw = None
  self.lastfilterUsed  = None
  self.filterObj   = CCtamE(self)
  VV796F, err = CCIdtv.VVu18q(self, self.VVecz5)
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   VVOPmD  = ("Zap"   , self.VVK0S4      , [])
   VV5qt4 = (""    , self.VVhJEt    , [])
   VVDle6 = ("Current Service", self.VV13EK  , [])
   VVPOPD = ("Options"  , self.VVFk2t , [])
   VVUum8 = ("Filter"   , self.VVaEZa  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVxWCE  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindServices)
 def VVmemx(self, VVhkUd, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCoGI2(self, VVhkUd)
  VVutlQ = []
  isMulti = VVhkUd.VVs7XH
  if isMulti:
   refCodeList = VVhkUd.VVd77Z(3)
   if refCodeList:
    VVutlQ.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVutlQ.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVutlQ.append(VVJKCZ)
    VVutlQ.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVutlQ.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVutlQ.append(VVJKCZ)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVutlQ.append((txt1, "parentalControl_add" ))
    VVutlQ.append((txt2,        ))
   else:
    VVutlQ.append((txt1,       ))
    VVutlQ.append((txt2, "parentalControl_remove" ))
   VVutlQ.append(VVJKCZ)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVutlQ.append((txt1, "hiddenServices_add"  ))
    VVutlQ.append((txt2,       ))
   else:
    VVutlQ.append((txt1,        ))
    VVutlQ.append((txt2, "hiddenServices_remove" ))
   VVutlQ.append(VVJKCZ)
  cbFncDict = { "parentalControl_add"   : BF(self.VV6voh, VVhkUd, refCode, True)
     , "parentalControl_remove"  : BF(self.VV6voh, VVhkUd, refCode, False)
     , "hiddenServices_add"   : BF(self.VVrcaK, VVhkUd, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVrcaK, VVhkUd, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVxaGT, VVhkUd, True)
     , "parentalControl_sel_remove" : BF(self.VVxaGT, VVhkUd, False)
     , "hiddenServices_sel_add"  : BF(self.VVB3aw, VVhkUd, True)
     , "hiddenServices_sel_remove" : BF(self.VVB3aw, VVhkUd, False)
     }
  VVutlQ1, cbFncDict1 = CCIdtv.VVd4gP(self, VVhkUd, servName, 3)
  VVutlQ.extend(VVutlQ1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVZZ7l(VVutlQ, cbFncDict)
 def VVFk2t(self, VVhkUd, title, txt, colList):
  servName = colList[0]
  mSel = CCoGI2(self, VVhkUd)
  VVutlQ, cbFncDict = CCIdtv.VVd4gP(self, VVhkUd, servName, 3)
  mSel.VVZZ7l(VVutlQ, cbFncDict)
 @staticmethod
 def VVd4gP(SELF, VVhkUd, servName, refCodeCol):
  tot = VVhkUd.VVznW9()
  if tot > 0:
   sTxt = FF0D7j("%d Service%s" % (tot, FFCMcT(tot)), VVPr8g)
   VVutlQ = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFLAHl(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FF0D7j(servName, VVPr8g)
   VVutlQ = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCIdtv.VV7ENT, SELF, VVhkUd, refCodeCol, True)
     , "addToBouquet_one" : BF(CCIdtv.VV7ENT, SELF, VVhkUd, refCodeCol, False)
     }
  return VVutlQ, cbFncDict
 @staticmethod
 def VV7ENT(SELF, VVhkUd, refCodeCol, isMulti):
  picker = CC0axI(SELF, VVhkUd, "Add to Bouquet", BF(CCIdtv.VVTSF6, VVhkUd, refCodeCol, isMulti))
 @staticmethod
 def VVTSF6(VVhkUd, refCodeCol, isMulti):
  if isMulti : refCodeList = VVhkUd.VVd77Z(refCodeCol)
  else  : refCodeList = [VVhkUd.VVZqZI()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VV6voh(self, VVhkUd, refCode, isAddToBlackList):
  VVhkUd.VVsbUP("Processing ...")
  FFciRl(BF(self.VVdyXf, VVhkUd, [refCode], isAddToBlackList))
 def VVxaGT(self, VVhkUd, isAddToBlackList):
  refCodeList = VVhkUd.VVd77Z(3)
  if not refCodeList:
   FF9Njt(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVhkUd.VVsbUP("Processing ...")
  FFciRl(BF(self.VVdyXf, VVhkUd, refCodeList, isAddToBlackList))
 def VVdyXf(self, VVhkUd, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV05KA, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV05KA):
   lines = FF6UEw(VV05KA)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV05KA, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVhkUd.VVs7XH
   if isMulti:
    self.VVW3tq(VVhkUd, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVDGLL(VVhkUd, refCode)
    VVhkUd.VVmw4V()
  else:
   VVhkUd.VVRR2a("No changes")
 def VVrcaK(self, VVhkUd, refCode, isHide):
  title = "Change Hidden State"
  if FFTYUK(refCode):
   VVhkUd.VVsbUP("Processing ...")
   ret = FFNQSk(refCode, isHide)
   if ret : FFVvl9(self, BF(self.VVDGLL, VVhkUd, refCode))
   else : FF9Njt(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF9Njt(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVDGLL(self, VVhkUd, refCode):
  VV796F, err = CCIdtv.VVu18q(self, self.VVhiz0, VVQF3m=[3, [refCode], False])
  done = False
  if VV796F:
   data = VV796F[0]
   if data[3] == refCode:
    done = VVhkUd.VVTXUN(data)
  if not done:
   self.VV4jaV(VVhkUd, VVhkUd.VV5xTc(), self.VVhiz0)
  VVhkUd.VVmw4V()
 def VVW3tq(self, VVhkUd, totRefCodes):
  VV796F, err = CCIdtv.VVu18q(self, self.VVhiz0, VVQF3m=self.VVEwkw)
  VVhkUd.VVoiHv(VV796F)
  VVhkUd.VVGaoF(False)
  VVhkUd.VVRR2a("%d Processed" % totRefCodes)
 def VVB3aw(self, VVhkUd, isHide):
  refCodeList = VVhkUd.VVd77Z(3)
  if not refCodeList:
   FF9Njt(self, "Nothing selected", title="Change Hidden State")
   return
  VVhkUd.VVsbUP("Processing ...")
  FFciRl(BF(self.VV0Y32, VVhkUd, refCodeList, isHide))
 def VV0Y32(self, VVhkUd, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFNQSk(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFURke(True)
   self.VVW3tq(VVhkUd, len(refCodeList))
  else:
   VVhkUd.VVRR2a("No changes")
 def VVqKmy(self, VVhkUd, title, txt, colList):
  inFilterFnc = BF(self.VVlpGc, VVhkUd) if self.VVEwkw else None
  self.filterObj.VVIvwl(1, VVhkUd, 2, BF(self.VVybk8, VVhkUd), inFilterFnc=inFilterFnc)
 def VVybk8(self, VVhkUd, item):
  self.VVQNdi(VVhkUd, False, item, 2, self.VVhiz0)
 def VVlpGc(self, VVhkUd, VVG7pv, item):
  self.VVQNdi(VVhkUd, True, item, 2, self.VVhiz0)
 def VVaEZa(self, VVhkUd, title, txt, colList):
  inFilterFnc = BF(self.VVNS87, VVhkUd) if self.VVEwkw else None
  self.filterObj.VVIvwl(2, VVhkUd, 4, BF(self.VVu2GY, VVhkUd), inFilterFnc=inFilterFnc)
 def VVu2GY(self, VVhkUd, item):
  self.VVQNdi(VVhkUd, False, item, 4, self.VVecz5)
 def VVNS87(self, VVhkUd, VVG7pv, item):
  self.VVQNdi(VVhkUd, True, item, 4, self.VVecz5)
 def VVHpdl(self, VVhkUd, title, txt, colList):
  inFilterFnc = BF(self.VVXcRn, VVhkUd) if self.VVEwkw else None
  self.filterObj.VVIvwl(0, VVhkUd, 4, BF(self.VVSDqe, VVhkUd), inFilterFnc=inFilterFnc)
 def VVSDqe(self, VVhkUd, item):
  self.VVQNdi(VVhkUd, False, item, 4, self.VVDRdY)
 def VVXcRn(self, VVhkUd, VVG7pv, item):
  self.VVQNdi(VVhkUd, True, item, 4, self.VVDRdY)
 def VVQNdi(self, VVhkUd, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVhkUd.VVxwcf(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVEwkw = None
  else:
   words, asPrefix = CCtamE.VVy75H(words)
   self.VVEwkw = [col, words, asPrefix]
  if words: FFVvl9(VVhkUd, BF(self.VV4jaV, VVhkUd, title, mode), clearMsg=False)
  else : FFhSFw(VVhkUd, "Incorrect filter", 2000)
 def VV4jaV(self, VVhkUd, title, mode):
  VV796F, err = CCIdtv.VVu18q(self, mode, VVQF3m=self.VVEwkw, VVadNQ=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVhkUd.VVNCJx():
    try:
     ndx = VV796F.index(tuple(list(map(str.strip, row))))
     lst.append(VV796F[ndx])
    except:
     pass
   VV796F = lst
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   VVhkUd.VVoiHv(VV796F, title, VVanXbMsg=True)
  else:
   FFhSFw(VVhkUd, "Not found!", 1500)
 def VVAK0L(self, title, VVUel6, VVOPmD=None, VV5qt4=None, VVRsW0=None, VVDle6=None, VVPOPD=None, VVUum8=None):
  VVDle6 = ("Current Service", self.VV13EK, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVxWCE = (LEFT  , LEFT  , CENTER, LEFT    )
  FFvfpt(self, None, title=title, header=header, VVUel6=VVUel6, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindServices)
 def VV13EK(self, VVhkUd, title, txt, colList):
  self.VVlo1H(VVhkUd)
 def VVAU3T(self, VVhkUd, title, txt, colList):
  self.VVlo1H(VVhkUd, True)
 def VVlo1H(self, VVhkUd, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVhkUd.VV9SZy(colDict, VVJLdL=True)
   else:
    VVhkUd.VVrxBR(3, refCode, True)
   return
  FF9Njt(self, "Cannot read current Reference Code !")
 def VVy1i9(self, title):
  self.VVEwkw = None
  self.lastfilterUsed  = None
  self.filterObj   = CCtamE(self)
  VV796F, err = CCIdtv.VVu18q(self, self.VVDRdY)
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   VV5qt4 = (""    , self.VV3y5P , []      )
   VVDle6 = ("Current Service", self.VVAU3T  , []      )
   VVUum8 = ("Filter"   , self.VVHpdl   , [], "Loading Filters ..." )
   VVOPmD  = ("Zap"   , self.VVp1O4      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVxWCE  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVDle6=VVDle6, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindServices)
 def VV3y5P(self, VVhkUd, title, txt, colList):
  refCode  = self.VVMOON(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FF0gQ0(self, fncMode=CCY1HC.VVEbBC, refCode=refCode, chName=chName, text=txt)
 def VVp1O4(self, VVhkUd, title, txt, colList):
  refCode = self.VVMOON(colList)
  FFlpKW(self, refCode)
 def VVK0S4(self, VVhkUd, title, txt, colList):
  FFlpKW(self, colList[3])
 def VVMOON(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVbaZi(VVcP6r, mode=0):
  lines = FF6UEw(VVcP6r, encLst=["UTF-8"])
  return CCIdtv.VV9UuU(lines, mode)
 @staticmethod
 def VV9UuU(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVu18q(SELF, mode, VVQF3m=None, VVadNQ=True, VVWj86=True):
  VVcP6r, err = CCIdtv.VVT54D(SELF, VVWj86)
  if err:
   return None, err
  asPrefix = False
  if VVQF3m:
   filterCol = VVQF3m[0]
   filterWords = VVQF3m[1]
   asPrefix = VVQF3m[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCIdtv.VVhiz0:
   blackList = None
   if fileExists(VV05KA):
    blackList = FF6UEw(VV05KA)
    if blackList:
     blackList = set(blackList)
  elif mode == CCIdtv.VVecz5:
   tp = CCSt6f()
  VVceEt, VV0f8b = FFhx3o()
  if mode in (CCIdtv.VVbDDC, CCIdtv.VV2yf4):
   VV796F = {}
  else:
   VV796F = []
  tagFound = False
  with ioOpen(VVcP6r, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FF1Q1b(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCIdtv.VVDRdY:
       if sTypeInt in VVceEt:
        STYPE = VV0f8b[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VV796F.append(tRow)
        elif any(x in tmp for x in filterWords)    : VV796F.append(tRow)
       else:
        VV796F.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCIdtv.VVIF6H:
        VV796F.append((chName, chProv, sat, refCode))
       elif mode == CCIdtv.VVbDDC:
        VV796F[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCIdtv.VV2yf4:
        VV796F[chName] = refCode
       elif mode == CCIdtv.VVhiz0:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV796F.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV796F.append(tRow)
        else:
         VV796F.append(tRow)
       elif mode == CCIdtv.VVecz5:
        if sTypeInt in VVceEt:
         STYPE = VV0f8b[sTypeInt]
        freq, pol, fec, sr, syst = tp.VV4HYJ(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV796F.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV796F.append(tRow)
        else:
         VV796F.append(tRow)
       elif mode == CCIdtv.VVcYvk:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VV796F.append((chName, chProv, sat, refCode))
       elif mode == CCIdtv.VV17og:
        VV796F.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VV796F and VVadNQ:
   FF9Njt(SELF, "No services found!")
  return VV796F, ""
 def VVqLhy(self, title):
  if fileExists(VV05KA):
   lines = FF6UEw(VV05KA)
   if lines:
    newRows = []
    VV796F, err = CCIdtv.VVu18q(self, self.VV17og)
    if VV796F:
     lines = set(lines)
     for item in VV796F:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV796F = newRows
      VV796F.sort(key=lambda x: x[0].lower())
      VV5qt4 = ("", self.VVhJEt, [])
      VVOPmD = ("Zap", self.VVK0S4, [])
      self.VVAK0L(title, VV796F, VVOPmD=VVOPmD, VV5qt4=VV5qt4)
     else:
      FFEso0(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV796F)))
   else:
    FFmMPS(self, "No active Parental Control services.", FFfwaK())
  else:
   FFvsvw(self, VV05KA)
 def VVs7rz(self, title):
  VV796F, err = CCIdtv.VVu18q(self, self.VVcYvk)
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   VV5qt4 = ("" , self.VVhJEt, [])
   VVOPmD  = ("Zap", self.VVK0S4, [])
   self.VVAK0L(title, VV796F, VVOPmD=VVOPmD, VV5qt4=VV5qt4)
  elif err:
   pass
  else:
   FFmMPS(self, "No hidden services.", FFfwaK())
 def VVE0fg(self):
  title = "Services unused in Tuner Configuration"
  VVcP6r, err = CCIdtv.VVT54D(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCIdtv.VVfFqT()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVXTnl(str(item[0]))
    nsLst.add(ns)
  sysLst = CCIdtv.VV6cZh("1:7:")
  tpLst  = CCIdtv.VVbaZi(VVcP6r, mode=1)
  VV796F = []
  for refCode, chName in sysLst:
   servID = CCIdtv.VVO8MG(refCode)
   tpID = CCIdtv.VVwroE(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VV796F.append((chName, FFjfzk(refCode, False), refCode, servID))
  if VV796F:
   VV796F.sort(key=lambda x: x[0].lower())
   VVPOPD = ("Options"   , BF(self.VViYyK, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVxWCE  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVPOPD=VVPOPD, VVRdqN="#0a001122", VVkSGg="#0a001122", VVTJDG="#0a001122", VVChAx="#00004455", VVDQNf="#0a333333", VV4UX1="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFmMPS(self, "No invalid service found !", title=title)
 def VViYyK(self, Title, VVhkUd, title, txt, colList):
  mSel = CCoGI2(self, VVhkUd)
  isMulti = VVhkUd.VVs7XH
  if isMulti : txt = "Remove %s Services" % FF0D7j(str(VVhkUd.VVznW9()), VVO7vL)
  else  : txt = "Remove : %s" % FF0D7j(VVhkUd.VVZqZI()[0], VVO7vL)
  VVutlQ = [(txt, "del")]
  cbFncDict = {"del": BF(FFVvl9, VVhkUd, BF(self.VVLasS, VVhkUd, Title))}
  mSel.VVZZ7l(VVutlQ, cbFncDict)
 def VVLasS(self, VVhkUd, title):
  VVcP6r, err = CCIdtv.VVT54D(self, title=title)
  if err:
   return
  isMulti = VVhkUd.VVs7XH
  skipLst = []
  if isMulti : skipLst = VVhkUd.VVd77Z(3)
  else  : skipLst = [VVhkUd.VVZqZI()[3]]
  tpLst = CCIdtv.VVbaZi(VVcP6r, mode=0)
  servLst = CCIdtv.VVbaZi(VVcP6r, mode=10)
  tmpDbFile = VVcP6r + ".tmp"
  lines   = FF6UEw(VVcP6r)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FF2ufE("mv -f '%s' '%s'" % (tmpDbFile, VVcP6r))
  VV796F = []
  for row in VVhkUd.VVNCJx():
   if not row[3] in skipLst:
    VV796F.append(row)
  FFURke()
  FFEso0(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VV796F:
   VVhkUd.VVoiHv(VV796F, title)
   VVhkUd.VVGaoF(False)
  else:
   VVhkUd.cancel()
 def VVePxK(self, title):
  VVcP6r, err = CCIdtv.VVT54D(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVivws(VVcP6r)
  txt = FF0D7j("Total Transponders:\n\n", VVJTsP)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF0D7j("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVJTsP)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFRZJT(item), satList.count(item))
  FFEso0(self, txt, title)
 def VVivws(self, VVcP6r):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVcP6r, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVCfB2(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFvsvw(self, path, title=title)
   return
  elif not CCLSXF.VVpzqc(self, path, title):
   return
  if not CCkTjP.VVWuZE(self):
   return
  tree = CCIdtv.VVkEFl(self, path, title=title)
  if not tree:
   return
  VV796F = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FF1Q1b(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VV796F.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VV796F:
   VV796F.sort(key=lambda x: int(x[1]))
   VVDle6 = ("Current Satellite", BF(self.VVH8Hc, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVxWCE  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=25, VVdQKE=1, VVDle6=VVDle6, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF9Njt(self, "No data found !", title=title)
 def VVH8Hc(self, satCol, VVhkUd, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  sat = FFjfzk(refCode, False)
  for ndx, row in enumerate(VVhkUd.VVNCJx()):
   if sat == row[satCol].strip():
    VVhkUd.VVfMAJ(ndx)
    break
  else:
   FFhSFw(VVhkUd, "No listed !", 1500)
 def FFVvl9_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FF9Njt(self, "No Satellites found !")
   return
  usedSats = CCIdtv.VVfFqT()
  VV796F = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VV796F.append((sat[1], posTxt, FF1Q1b(sat[0]), tuners, str(posVal)))
  if VV796F:
   VVTJDG = "#11222222"
   VV796F.sort(key=lambda x: int(x[1]))
   VVDle6 = ("Current Satellite" , BF(self.VVH8Hc, 2) , [])
   VVPOPD = ("Options"   , self.VVkplh  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVxWCE  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, VVDle6=VVDle6, VVPOPD=VVPOPD, VVRdqN=VVTJDG, VVkSGg=VVTJDG, VVTJDG=VVTJDG, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF9Njt(self, "No data found !")
 def VVkplh(self, VVhkUd, title, txt, colList):
  mSel = CCoGI2(self, VVhkUd)
  isMulti = VVhkUd.VVs7XH
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FF0D7j(str(VVhkUd.VVznW9()), VVO7vL)
  else  : txt = "Remove ALL Services on : %s" % FF0D7j(VVhkUd.VVZqZI()[0], VVO7vL)
  VVutlQ = []
  VVutlQ.append((txt, "deleteSat"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Delete Empty Bouquets", "VVGJ5N"))
  cbFncDict = { "deleteSat"   : BF(FFVvl9, VVhkUd, BF(self.VVmydO, VVhkUd))
     , "VVGJ5N" : BF(self.VVGJ5N, VVhkUd)
     }
  mSel.VVZZ7l(VVutlQ, cbFncDict)
 def VVmydO(self, VVhkUd):
  posLst = []
  isMulti = VVhkUd.VVs7XH
  posLst = []
  if isMulti : posLst = VVhkUd.VVd77Z(4)
  else  : posLst = [VVhkUd.VVZqZI()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVXTnl(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVdpmW(nsLst)
  FFURke(True)
  FFEso0(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVGJ5N(self, winObj):
  title = "Delete Empty Bouquets"
  FFfbEx(self, BF(FFVvl9, winObj, BF(self.VV18wc, title)), "Delete bouquets with no services ?", title=title)
 def VV18wc(self, title):
  bList = CC0axI.VVYvqm()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CC0axI.VVAClG(bRef)
    bPath = VVGMYl + bFile
    FFEUy9(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVGMYl + fil
     if fileExists(path):
      lines = FF6UEw(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFURke(True)
  if bNames: txt = "%s\n\n%s" % (FF0D7j("Deleted Bouquets:", VVPr8g), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFEso0(self, txt, title=title)
 def VVXTnl(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVdpmW(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVGMYl)
  for srcF in files:
   if fileExists(srcF):
    lines = FF6UEw(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFkXXp(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVZX3S(self, title)   : self.VVwKA2(title, True)
 def VVEH6M(self, title) : self.VVwKA2(title, False)
 def VVwKA2(self, title, isWithPIcons):
  piconsPath = CC3hRa.VV3CCT()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC3hRa.VVwLN3(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV796F, err = CCIdtv.VVu18q(self, self.VV17og)
    if VV796F:
     channels = []
     for (chName, chProv, sat, refCode) in VV796F:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFzUm6(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV796F)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVy75x(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVy75x("PIcons Path"  , piconsPath)
     txt += VVy75x("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVy75x("Total services" , totalServices)
     txt += VVy75x("With PIcons"  , totalWithPIcons)
     txt += VVy75x("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFEso0(self, txt)
     else:
      VV5qt4     = (""      , self.VVhJEt , [])
      if isWithPIcons : VVUum8 = ("Export Current PIcon", self.VV5LL0  , [])
      else   : VVUum8 = None
      VVPOPD     = ("Statistics", FFEso0, [txt])
      VVOPmD      = ("Zap", self.VVK0S4, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVAK0L(title, channels, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVPOPD=VVPOPD, VVUum8=VVUum8)
   else:
    FF9Njt(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF9Njt(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVhJEt(self, VVhkUd, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FF0gQ0(self, fncMode=CCY1HC.VVEbBC, refCode=refCode, chName=chName, text=txt)
 def VV5LL0(self, VVhkUd, title, txt, colList):
  png, path = CC3hRa.VVenVx(colList[3], colList[0])
  if path:
   CC3hRa.VVrraB(self, png, path)
 @staticmethod
 def VVMsCA():
  VVcP6r  = "%slamedb" % VVGMYl
  VVjbHq = "%slamedb.disabled" % VVGMYl
  return VVcP6r, VVjbHq
 @staticmethod
 def VVVjAF():
  VVlL8F  = "%slamedb5" % VVGMYl
  VVKGHq = "%slamedb5.disabled" % VVGMYl
  return VVlL8F, VVKGHq
 def VVeqD3(self, isEnable):
  VVcP6r, VVjbHq = CCIdtv.VVMsCA()
  if isEnable and not fileExists(VVjbHq):
   FFmMPS(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVcP6r):
   FF9Njt(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFfbEx(self, BF(self.VVKXZr, isEnable), "%s Hidden Channels ?" % word)
 def VVKXZr(self, isEnable):
  VVcP6r , VVjbHq = CCIdtv.VVMsCA()
  VVlL8F, VVKGHq = CCIdtv.VVVjAF()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVjbHq, VVjbHq, VVcP6r)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVKGHq, VVKGHq, VVlL8F)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVcP6r  , VVcP6r , VVjbHq)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVlL8F , VVlL8F, VVKGHq)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVjbHq, VVcP6r )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVKGHq, VVlL8F)
  ok = FF2ufE(cmd)
  FFURke()
  if ok: FFmMPS(self, "Hidden List %s" % word)
  else : FF9Njt(self, "Error while restoring:\n\n%s" % fileName)
 def VVHcUr(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVGMYl
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVGMYl
  FFbwen(self, cmd)
 def VVgBYN(self):
  VVcP6r, err = CCIdtv.VVT54D(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFEUy9(tmpFile)
  totChan = totRemoved = 0
  lines = FF6UEw(VVcP6r, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFfbEx(self, BF(FFVvl9, self, BF(self.VVKyBZ, tmpFile, VVcP6r, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFCMcT(totRemoved), totChan, FFCMcT(totChan))
      , callBack_No=BF(self.VVUavi, tmpFile))
  else:
   FFEso0(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVKyBZ(self, tmpFile, VVcP6r, totRemoved, totChan):
  FF2ufE("mv -f '%s' '%s'" % (tmpFile, VVcP6r))
  FFURke()
  FFEso0(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVUavi(self, tmpFile):
  FFEUy9(tmpFile)
 @staticmethod
 def VVT54D(SELF, VVWj86=True, title=""):
  VVcP6r, VVjbHq = CCIdtv.VVMsCA()
  if   not fileExists(VVcP6r)       : err = "File not found !\n\n%s" % VVcP6r
  elif not CCLSXF.VVpzqc(SELF, VVcP6r) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVWj86:
   FF9Njt(SELF, err, title=title)
  return VVcP6r, err
 @staticmethod
 def VVwroE(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVO8MG(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VV6cZh(servTypes):
  VV0WM0  = eServiceCenter.getInstance()
  VVzi19   = '%s ORDER BY name' % servTypes
  VVv1zC   = eServiceReference(VVzi19)
  VVbyaY = VV0WM0.list(VVv1zC)
  if VVbyaY: return VVbyaY.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVfFqT():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCY1HC(Screen):
 VVbVB0  = 0
 VVkglL   = 1
 VVfuV4   = 2
 VVEbBC    = 3
 VVI7L5    = 4
 VVZspE   = 5
 VVDgRc   = 6
 VVJUjV    = 7
 VVG9Cu   = 8
 VVQQZu   = 9
 VVZ5aH   = 10
 VV9bkk   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFzoo9(VVJPgr, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVbVB0)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FF0D7j("%s\n", VVwos9) % SEP
  self.picViewer  = None
  FFk1xo(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVYkWQ })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self["myLabel"].VVABQW(outputFileToSave="chann_info")
  if   self.fncMode == self.VVbVB0 : fnc = self.VVJAHs
  elif self.fncMode == self.VVkglL  : fnc = self.VVJAHs
  elif self.fncMode == self.VVfuV4  : fnc = self.VVJAHs
  elif self.fncMode == self.VVEbBC  : fnc = self.VVhUTV
  elif self.fncMode == self.VVI7L5  : fnc = self.VV852Z
  elif self.fncMode == self.VVZspE  : fnc = self.VVmttl
  elif self.fncMode == self.VVDgRc  : fnc = self.VVjRic
  elif self.fncMode == self.VVJUjV  : fnc = self.VVB5ZU
  elif self.fncMode == self.VVG9Cu  : fnc = self.VVvBOR
  elif self.fncMode == self.VVQQZu : fnc = self.VVAZ3L
  elif self.fncMode == self.VVZ5aH  : fnc = self.VVuTTt
  elif self.fncMode == self.VV9bkk : fnc = self.VVSEjN
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VVHEZv
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVydFj()
  FFciRl(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVWobb()
 def VV8KG2(self, err):
  self["myLabel"].setText(err)
  FFiva8(self["myTitle"], "#22200000")
  FFiva8(self["myBody"], "#22200000")
  self["myLabel"].VVdd1T("#22200000")
  self["myLabel"].VVydFj()
 def VVJAHs(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  self.refCode = refCode
  self.VVF3YA(chName)
 def VVhUTV(self):
  self.VVF3YA(self.chName)
 def VV852Z(self):
  self.VVF3YA(self.chName)
 def VVmttl(self):
  self.VVF3YA(self.chName)
 def VVjRic(self):
  self.VVF3YA("Picon Info")
 def VVB5ZU(self):
  self.VVF3YA(self.chName)
 def VVvBOR(self):
  self.VVF3YA(self.chName)
 def VVAZ3L(self):
  self.VVF3YA(self.chName)
 def VVuTTt(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFRlnq(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVrd5B(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVF3YA(self.chName)
 def VVSEjN(self):
  self.VVF3YA(self.chName)
 def VVHEZv(self):
  self.VV0CYj(self.picPath)
  self.VVTm8l()
 def VVF3YA(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFi1IN(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVFADs(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FF0D7j(self.VVnxvc(tUrl), VVBhz1)
  if not self.epg:
   epg = CCvK6a.VVtNy0(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV0CYj(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC3hRa.VVenVx(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV0CYj(path)
  self.VV4tSv()
  self.VV77SW(decodedUrl)
  self.VVTm8l()
 def VVTm8l(self):
  self["myLabel"].setText(self.text or "   No active service", VVognF=VVy5UE)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVydFj(minHeight=minH)
 def VV77SW(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FF4MQW(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVnRvY(FF2zGt(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCLRZv.VVOHBD(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCLRZv.VVOHBD(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFl9yk("EPG:", VVPr8g) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV4tSv()
 def VV4tSv(self):
  if not self.piconShown and self.picUrl:
   path, err = FFAqj4(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV0CYj(path)
    if self.piconShown and self.refCode:
     self.VVWZ4C(path, self.refCode)
 def VVWZ4C(self, path, refCode):
  if path and fileExists(path) and FFVjaP("ffmpeg"):
   pPath = CC3hRa.VV3CCT()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCY1HC.VVlIL4(path)
    cmd += FFYhY6("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FF2ufE(cmd)
 def VV0CYj(self, path):
  if path and fileExists(path):
   err, w, h = self.VVK89w(path)
   if not err:
    if h > w:
     self.VVe3Q1(self["myPicF"], w, h, True)
     self.VVe3Q1(self["myPicB"], w, h, False)
     self.VVe3Q1(self["myPic"] , w, h, False)
   self.picViewer = CCl6im.VVMews(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVe3Q1(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVK89w(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF7jZM(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVFADs(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF0D7j(chName, VVPr8g)
  txt += self.VVy75x(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF0D7j(state, VVUS1a)
   txt += "State\t: %s\n" % state
  w = FF78Jk(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF78Jk(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVe28b(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVy75x(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVy75x(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVy75x(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVACq6()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV27dA()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCY1HC.VVMVwo(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF0D7j("Stream-Relay" if FFcIP1(decodedUrl) else "IPTV", VVJTsP)
   txt += self.VV966t(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVnbLm(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCSt6f()
    tpTxt, namespace = tp.VVxC4S(refCode)
    if tpTxt:
     txt += FF0D7j("Tuner:\n", VVPr8g)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF0D7j("Codes:\n", VVPr8g)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVy75x(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVy75x(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVy75x(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVy75x(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVy75x(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVy75x(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVy75x(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVy75x(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVy75x(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVe28b(info):
  if info:
   aspect = FF78Jk(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVy75x(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF78Jk(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV9OWG(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV9OWG(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVACq6(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VV27dA(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVnbLm(self, refCode, iptvRef, chName):
  refCode = FFFMIK(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFXk75(VVGMYl + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFXk75(VVGMYl + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVUel6 = []
  tmpRefCode = FF2zGt(refCode)
  for item in fList:
   path = VVGMYl + item
   if fileExists(path):
    txt = FFXk75(path)
    if tmpRefCode in FF2zGt(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVUel6.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVUel6:
   if len(VVUel6) == 1:
    txt += "%s\t: %s%s\n" % (FF0D7j("Bouquet", VVPr8g), VVUel6[0][0], " (%s)" % VVUel6[0][1] if VVS9jK else "")
   else:
    txt += FF0D7j("Bouquets:\n", VVPr8g)
    for ndx, item in enumerate(VVUel6):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVS9jK else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV966t(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFYUp6(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCLRZv()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF0D7j("URL:", VVJTsP) + "\n%s\n" % self.VVnxvc(decodedUrl)
  else:
   txt = "\n"
   txt += FF0D7j("Reference:", VVJTsP) + "\n%s\n" % refCode
  return txt
 def VVnxvc(self, url):
  if not FFcIP1(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVWEgS:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FF2zGt(url)
 def VVnRvY(self, decodedUrl):
  if not CCYYaf.VVmh4s():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC3ZOl.VVakT8(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC3ZOl.VVxuE9(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVL1Xq(tDict)
   elif uType == "movie" : epg, picUrl = CCY1HC.VVT3u9(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVL1Xq(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC3ZOl.VVq4yM(item, "title"    , is_base64=True )
     lang    = CC3ZOl.VVq4yM(item, "lang"         ).upper()
     description   = CC3ZOl.VVq4yM(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC3ZOl.VVq4yM(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC3ZOl.VVq4yM(item, "start_timestamp"      )
     stop_timestamp  = CC3ZOl.VVq4yM(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC3ZOl.VVq4yM(item, "stop_timestamp"       )
     now_playing   = CC3ZOl.VVq4yM(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV15Fs, ""
      else     : color, txt = VVUS1a , "    (CURRENT EVENT)"
      epg += FF0D7j("_" * 32 + "\n", VVwos9)
      epg += FF0D7j("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF0D7j(description, VVBhz1)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCvK6a.VVKaCW(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVT3u9(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC3ZOl.VVq4yM(item, "movie_image" )
    genre  = CC3ZOl.VVq4yM(item, "genre"   ) or "-"
    plot  = CC3ZOl.VVq4yM(item, "plot"   ) or "-"
    country  = CC3ZOl.VVq4yM(item, "country"  ) or "-"
    actors  = CC3ZOl.VVq4yM(item, "actors"   ) or "-"
    cast  = CC3ZOl.VVq4yM(item, "cast"   ) or "-"
    rating  = CC3ZOl.VVq4yM(item, "rating"   ) or "-"
    director = CC3ZOl.VVq4yM(item, "director"  ) or "-"
    releasedate = CC3ZOl.VVq4yM(item, "releasedate" ) or "-"
    duration = CC3ZOl.VVq4yM(item, "duration"  ) or "-"
    try:
     lang = CC3ZOl.VVq4yM(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF0D7j(cast if cast != "-" else actors, VVBhz1)
    epg += "Plot:\n%s"    % FF0D7j(plot, VVBhz1)
   except:
    pass
  return epg, movie_image
 def VVYkWQ(self):
  if VVWEgS:
   def VVy75x(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVy75x(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCLRZv()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVy75x(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFhSFw(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVq78j(SELF):
  if not CCJ0a3.VVSfC2(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF)
  err = url =  fSize = resumable = ""
  if FFfoad(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCLRZv.VVJYyo(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCLRZv.VV8fYq(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FF9Njt(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCLSXF.VVtnwF(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF0D7j(" (M3U/M3U8 File)", VVBhz1)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCkpqq.VVfs86(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVGQB8(subj, val):
   return "%s\n%s\n\n" % (FF0D7j("%s:" % subj, VVPr8g), val)
  title = "File Size"
  txt  = VVGQB8(title , fSize or "?")
  txt += VVGQB8("Name" , chName)
  txt += VVGQB8("URL" , url)
  if resumable: txt += VVGQB8("Supports Download-Resume", resumable)
  if err  : txt += FF0D7j("Error:\n", VVUS1a) + err
  FFEso0(SELF, txt, title=title)
 @staticmethod
 def VVMVwo(SELF):
  fPath, fDir, fName = CCLSXF.VVtloK(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVlIL4(path):
  return FFYhY6("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVinHk(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CC3hRa.VV3CCT() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VV30cN(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FF4MQW(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFkXXp(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCLRZv():
 def __init__(self):
  self.VVKclO()
  self.VVRqws    = ""
  self.VVeTsN   = "#f#11ffffaa#User"
  self.VVhbEj   = "#f#11aaffff#Server"
 def VVKclO(self):
  self.VVQ4dj   = ""
  self.VV6daG    = ""
  self.VVUQEE   = ""
  self.VVFzlX = ""
  self.VVtYKA  = ""
  self.VVKPs9 = 0
 def VVS6va(self, url, mac, ph1="", VVJLdL=True):
  self.VVKclO()
  self.VVRqws = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVWVvF(url)
  if not host:
   if VVJLdL:
    self.VVBTBJ("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVwviR(mac)
  if not host:
   if VVJLdL:
    self.VVBTBJ("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVQ4dj = host
  self.VV6daG  = mac
  return True
 def VV566v(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVRqws, "")
 def VVWVvF(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVwviR(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVhUe5(self):
  res, err = self.VVb4hn(self.VVOMau())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVQ4dj.endswith("/c"):
    self.VVQ4dj = self.VVQ4dj[:-2]
    res, err = self.VVb4hn(self.VVOMau())
   elif self.VVQ4dj.endswith("/stalker_portal"):
    self.VVQ4dj = self.VVQ4dj[:-15]
    res, err = self.VVb4hn(self.VVOMau())
   else:
    self.VVQ4dj += "/c"
    res, err = self.VVb4hn(self.VVOMau())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC3ZOl.VVq4yM(tDict["js"], "token")
    rand  = CC3ZOl.VVq4yM(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVTLtK(self, VVJLdL=True):
  if not self.VVRqws:
   self.VVL4GY()
  err = blkMsg = FFmMPSTxt = ""
  try:
   token, rand, err = self.VVhUe5()
   if token:
    self.VVUQEE = token
    self.VVFzlX = rand
    if rand:
     self.VVKPs9 = 2
    prof, retTxt = self.VV3A2N(True)
    if prof:
     self.VVtYKA = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVKPs9 = 3
      prof, retTxt = self.VV3A2N(False)
      if retTxt:
       self.VVtYKA = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFmMPSTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFmMPSTxt: tErr += "\n%s" % FFmMPSTxt
  if VVJLdL:
   self.VVBTBJ(tErr)
  return "", "", tErr
 def VVL4GY(self):
  try:
   import requests
   url = self.VV93yC()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCLRZv.VV8fYq(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCLRZv.VV8fYq(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVQ4dj = url
       self.VVRqws = span.group(1)
       return
  except:
   pass
  self.VVRqws = "/server/load.php"
 def VV93yC(self):
  url = self.VVQ4dj.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVMRrM(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVb4hn("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVb4hn("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VV3A2N(self, capMac):
  res, err = self.VVb4hn(self.VVDEB1(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC3ZOl.VVq4yM(tDict["js"], "block_%s" % word)
    FFmMPSTxt = CC3ZOl.VVq4yM(tDict["js"], word)
    return tDict, FFmMPSTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVDEB1(self, capMac):
  param = ""
  if self.VVtYKA or self.VVFzlX:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VV6daG.upper() if capMac else self.VV6daG.lower(), self.VVFzlX))
  return self.VVpfth() + "type=stb&action=get_profile" + param
 exec(FFRlnq("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVG2GI(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVtqQ2()
  if len(rows) < 10:
   rows = self.VVJ0S3()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVQ4dj ))
   rows.append(("MAC (from URL)" , self.VV6daG ))
   rows.append(("Token"   , self.VVUQEE ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVeTsN  , "MAC" , self.VV6daG ))
   rows.append(("2", self.VVhbEj, "Host" , self.VVQ4dj ))
   rows.append(("2", self.VVhbEj, "Token" , self.VVUQEE ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV7Uqz(self, isPhp=True, VVJLdL=False):
  token, profile, tErr = self.VVTLtK(VVJLdL)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VV92Xm()
  res, err = self.VVb4hn(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC3ZOl.VVq4yM(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFROgB(span.group(2))
     pass1 = FFROgB(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVtqQ2(self):
  m3u_Url, host, user1, pass1, err = self.VV7Uqz()
  rows = []
  if m3u_Url:
   res, err = self.VVb4hn(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFaLO4(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVeTsN, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFaLO4(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVhbEj, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVJ0S3(self):
  token, profile, tErr = self.VVTLtK()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFqDto(val): val = FFRlnq(val.decode("UTF-8"))
     else     : val = self.VV6daG
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFaLO4(int(parts[1]))
      if parts[2] : ends = FFaLO4(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFaLO4(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVrd5B(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVTLtK(VVJLdL=False)
  if not token:
   return ""
  crLinkUrl = self.VVqLZS(mode, chCm, epNum, epId)
  res, err = self.VVb4hn(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC3ZOl.VVq4yM(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVpfth(self):
  return self.VVQ4dj + self.VVRqws + "?"
 def VVOMau(self):
  return self.VVpfth() + "type=stb&action=handshake&token=&mac=%s" % self.VV6daG
 def VVWj9o(self, mode):
  url = self.VVpfth() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVZeTe(self, catID):
  return self.VVpfth() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVMM1B(self, mode, catID, page):
  url = self.VVpfth() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VV7Gpi(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVpfth() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VV5wvX(self, stID):
  return self.VVpfth() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVqLZS(self, mode, chCm, serCode, serId):
  url = self.VVpfth() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV92Xm(self):
  return self.VVpfth() + "type=itv&action=create_link"
 def VV3HXs(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV2ZyA(catID, stID, chNum)
  query = self.VVDPph(mode, self.VV566v(), FFuZgB(host), FFuZgB(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVDPph(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVN0zr(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVDPph(mode, ph1, host, mac, epNum, epId, FFROgB(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFRlnq(host)
  mac   = FFRlnq(mac)
  valid = False
  if self.VVWVvF(playHost) and self.VVWVvF(host) and self.VVWVvF(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVb4hn(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCLRZv.VV8fYq()
   if self.VVUQEE:
    headers["Authorization"] = "Bearer %s" % self.VVUQEE
   if useCookies : cookies = {"mac": self.VV6daG, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVbnHU(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCLRZv.VV8fYq(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VV8fYq():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVBTBJ(self, err, title="Portal Browser"):
  FF9Njt(self, str(err), title=title)
 def VVnULp(self, mode):
  if   mode in ("itv"  , CC3ZOl.VVjzKg , CC3ZOl.VV7Kdc)  : return "Live"
  elif mode in ("vod"  , CC3ZOl.VVOLum , CC3ZOl.VVIgU3)  : return "VOD"
  elif mode in ("series" , CC3ZOl.VV70Qz , CC3ZOl.VVD8FZ) : return "Series"
  else                          : return "IPTV"
 def VVl0du(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVnULp(mode), FF0D7j(searchName, VVBhz1))
 def VVmCIy(self, catchup=False):
  VVutlQ = []
  VVutlQ.append(("Live"    , "live"  ))
  VVutlQ.append(("VOD"    , "vod"   ))
  VVutlQ.append(("Series"   , "series"  ))
  if catchup:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Catch-up TV" , "catchup"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Account Info." , "accountInfo" ))
  return VVutlQ
 @staticmethod
 def VVMalC(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCLRZv()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(decodedUrl)
  if valid:
   ok = p.VVS6va(host, mac, ph1, VVJLdL=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VV7Uqz(isPhp=False, VVJLdL=False)
    streamId = CCLRZv.VVBtza(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVBtza(decodedUrl):
  p = CCLRZv()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFRlnq(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVJYyo(decodedUrl):
  p = CCLRZv()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(decodedUrl)
  if valid:
   if CCLRZv.VV0jTr(chCm):
    return FF2zGt(chCm)
   else:
    ok = p.VVS6va(host, mac, ph1, VVJLdL=False)
    if ok:
     try:
      chUrl = p.VVrd5B(mode, chCm, epNum, epId)
      return FF2zGt(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VV0jTr(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVOHBD(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCLRZv()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(decodedUrl)
   if valid:
    if not stID:
     stID = CCLRZv.VVBtza(decodedUrl)
    if stID:
     if p.VVS6va(host, mac, ph1, VVJLdL=False):
      token, profile, tErr = p.VVTLtK(VVJLdL=False)
      if token:
       res, err = p.VVb4hn(p.VV5wvX(stID))
       if res:
        epg, err = CCLRZv.VVg67W(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCLRZv.VVg67W(res.text, retLst=True)
         if pList:
          totEv, totOK = CCvK6a.VVKaCW(refCode, pList)
  return epg, err
 @staticmethod
 def VVg67W(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CC3ZOl.VVq4yM(item, "actor"       )
    category   = CC3ZOl.VVq4yM(item, "category"      )
    descr    = CC3ZOl.VVq4yM(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CC3ZOl.VVq4yM(item, "director"      )
    name    = CC3ZOl.VVq4yM(item, "name"   , is_base64=True)
    start_timestamp  = CC3ZOl.VVq4yM(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CC3ZOl.VVq4yM(item, "start_timestamp"    )
    stop_timestamp  = CC3ZOl.VVq4yM(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CC3ZOl.VVq4yM(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FF0D7j("    (CURRENT EVENT)", VVFWDt)
     except:
      pass
     if not skip:
      epg += FF0D7j("_" * 32 + "\n", VVwos9)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FF0D7j(name, VVPr8g)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FF0D7j(descr , VVBhz1) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FF0D7j(category, VVBhz1) if category else ""
      epg += "Actors:\n%s\n"  % FF0D7j(actor , VVBhz1) if actor else ""
      epg += "Director:\n%s\n" % FF0D7j(director, VVBhz1) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CC4cFe(CCLRZv):
 def __init__(self):
  CCLRZv.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVfbLd(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVN0zr(decodedUrl)
  if valid:
   if self.VVS6va(host, mac, ph1, VVJLdL=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVsAcI(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFRlnq(self.chCm[3:])
  else:
   try:
    chUrl = self.VVrd5B(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCLRZv.VV0jTr(self.chCm):
   chUrl = FF2zGt(self.chCm)
   chUrl = FFROgB(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVQ3O1(chUrl)
  bPath = CC0axI.VVUNhc()
  if newIptvRef:
   if passedSELF:
    FFlpKW(passedSELF, newIptvRef, VVeuyP=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFlpKW(self, newIptvRef, VVeuyP=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVGp2Q(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVQ3O1(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVGp2Q(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FF6UEw(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFURke()
class CCjnCh(CC4cFe):
 def __init__(self, passedSession):
  CC4cFe.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVqnxf(VVWiAM  )
  Main_Menu.VVqnxf(VVz0ti)
  Main_Menu.VVqnxf(VVVf82  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVmHao, iPlayableService.evEOF: self.VVK6i6, iPlayableService.evEnd: self.VVX4Kz})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVCTyQ)
  except:
   self.timer2.callback.append(self.VVCTyQ)
  self.timer2.start(3000, False)
  self.VVCTyQ()
 def VVCTyQ(self):
  if not CFG.downloadMonitor.getValue():
   self.VVRZvw()
   return
  lst = CCkpqq.VVmSW2()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFrMJ0(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCkpqq.VVYoWe(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCfirR.VV6zn8(self.passedSession, txt, 30)
   else    : CCfirR.VVQPUc(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVRZvw()
 def VVRZvw(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVmHao(self):
  self.startTime = iTime()
 def VVK6i6(self):
  global VV0P9w
  VV0P9w = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFfoad(decodedUrl):
     self.isFromEOF = True
     CCfirR(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVX4Kz(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV3Md2)
  except:
   self.timer1.callback.append(self.VV3Md2)
  self.timer1.start(100, True)
 def VV3Md2(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVfbLd(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCGzpp.VVRINw:
       self.isFromEOF = False
       self.VVsAcI(self.passedSession, isFromSession=True)
class CC26Ue():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVOrqy(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVOrqy(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVOrqy(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VV8pP1, VVUQHY):
    path += fName
    if fileExists(path):
     for line in FF6UEw(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVVZZx(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC3ZOl.VVMYA2(name):
   return CC3ZOl.VVWS6n(name)
  return self.VVnHRt(name)
 def VVnHRt(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VV51yv(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVnHRt(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVAW8u(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVecfR(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVL5YU(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCJ0a3(CCLRZv):
 def __init__(self):
  self.curPortalCatId = ""
  CCLRZv.__init__(self)
 def VV3sJO(self):
  if CCJ0a3.VVSfC2(self):
   FFVvl9(self, BF(self.VVaEsz, 2), title="Searching ...")
 def VVwI9O(self, winSession, url, mac):
  self.curUrl = url
  if CCJ0a3.VVSfC2(self):
   if self.VVS6va(url, mac):
    FFVvl9(winSession, self.VVzo67, title="Checking Server ...")
   else:
    FF9Njt(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVJqUd(self, item=None):
  if item:
   VVG7pv, txt, path, ndx = item
   enc = CCDQtT.VVvetn(path, self)
   if enc == -1:
    return
   self.session.open(CC1jbq, barTheme=CC1jbq.VVlB2I
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVmrcY, path, enc)
       , VVFqvg = BF(self.VVtroP, VVG7pv, path))
 def VVmrcY(self, path, enc, VVdu90):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVdu90.VV7hIf(totLines)
  VVdu90.VVeIVc = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVdu90 or VVdu90.isCancelled:
     return
    VVdu90.VVRbmv(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVWVvF(url)
     mac  = self.VVwviR(mac)
     if host and mac and VVdu90:
      VVdu90.VVeIVc.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVWVvF(url)
      mac  = self.VVwviR(mac)
      if host and mac and not mac.startswith("AC") and VVdu90:
       VVdu90.VVeIVc.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVtroP(self, VVG7pv, path, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVeIVc:
   VVRsW0  = ("Home Menu"  , FF9KFt            , [])
   VVPOPD = ("Edit File"  , BF(self.VVNl5X, path)       , [])
   VVDle6 = ("M3U Options" , self.VVrDGg         , [])
   VVUum8 = ("Check & Filter" , BF(self.VVqgNC, VVG7pv, path), [])
   VVOPmD  = ("Select"   , self.VVrP1R      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVxWCE  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VVeIVc, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, VVRdqN="#0a001122", VVkSGg="#0a001122", VVTJDG="#0a001122", VVChAx="#00004455", VVDQNf="#0a333333", VV4UX1="#11331100", VVNWl5=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVegYv:
    FFhSFw(VVhkUd, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVegYv:
    FF9Njt(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVrDGg(self, VVhkUd, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVutlQ = []
  VVutlQ.append(("Browse as M3U"  , "browse"))
  VVutlQ.append(("Download M3U File" , "downld"))
  FFre61(self, BF(self.VV3hFR, VVhkUd, host, mac), title=title, VVutlQ=VVutlQ, width=600, VVNxG7=True)
 def VV3hFR(self, VVhkUd, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFVvl9(VVhkUd, BF(self.VVr6ra, VVhkUd, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFfbEx(self, BF(FFVvl9, VVhkUd, BF(self.VVr6ra, VVhkUd, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVr6ra(self, VVhkUd, title, host, mac, item):
  p = CCLRZv()
  m3u_Url = ""
  ok = p.VVS6va(host, mac, VVJLdL=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV7Uqz(VVJLdL=False)
  if m3u_Url:
   if   item == "browse": self.VViicr(title, m3u_Url)
   elif item == "downld": self.VVHujd(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FF9Njt(self, err or "No response from Server !", title=title)
 def VVrP1R(self, VVhkUd, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVwI9O(VVhkUd, url, mac)
 def VVNl5X(self, path, VVhkUd, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCc3G0(self, path, VVFqvg=BF(self.VVdamT, VVhkUd), curRowNum=rowNum)
  else    : FFvsvw(self, path)
 def VVqgNC(self, VVG7pv, path, VVhkUd, title, txt, colList):
  self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVG0AF, VVhkUd)
      , VVFqvg = BF(self.VVqQzZ, VVG7pv, VVhkUd, path))
 def VVG0AF(self, VVhkUd, VVdu90):
  VVdu90.VVeIVc = []
  VVdu90.VV7hIf(VVhkUd.VVc8ws())
  for row in VVhkUd.VVNCJx():
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVRbmv(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVS6va(host, mac, VVJLdL=False):
    token, profile, tErr = self.VVTLtK(VVJLdL=False)
    if token and VVdu90 and not VVdu90.isCancelled:
     res, err = self.VVb4hn(self.VVWj9o("itv"))
     if res and VVdu90 and not VVdu90.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVdu90.VVRbmv(0, showFound=True)
       VVdu90.VVeIVc.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVdu90:
    return
 def VVqQzZ(self, VVG7pv, VVhkUd, path, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if VVeIVc:
   VVhkUd.close()
   VVG7pv.close()
   newPath = "%s_OK_%s.txt" % (path, FFKX94())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVeIVc:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF0D7j(str(threadCounter), VVUS1a)
    skipped = FF0D7j(str(threadTotal - threadCounter), VVUS1a)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVeIVc)
   txt += "%s\n\n%s"    %  (FF0D7j("Result File:", VVPr8g), newPath)
   FFEso0(self, txt, title="Accessible Portals")
  elif VVegYv:
   FF9Njt(self, "No portal access found !", title="Accessible Portals")
 def VVK6zd(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFRlnq(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVzo67(self):
  token, profile, tErr = self.VVTLtK()
  if token:
   dots = "." * self.VVKPs9
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VV566v(), "")
   dots += "*" if not self.VVQ4dj == self.curUrl else ""
   VVutlQ  = self.VVmCIy()
   VVnFDy = self.VVBJhX
   VVRIxl = self.VVZfjY
   VVuLNH = ("Home Menu", FF9KFt)
   VVMTOL= ("Add to Menu", BF(CC3ZOl.VVJyHj, self, True, self.VVQ4dj + "\t" + self.VV6daG))
   VVmhL9 = ("Bookmark Server", BF(CC3ZOl.VVD91C, self, True, self.VVQ4dj + "\t" + self.VV6daG))
   VVG7pv = FFre61(self, None, title="Portal Resources (MAC=%s) %s" % (self.VV6daG, dots), VVutlQ=VVutlQ, VVnFDy=VVnFDy, VVRIxl=VVRIxl, VVuLNH=VVuLNH, VVMTOL=VVMTOL, VVmhL9=VVmhL9)
   self.VV8hzO(VVG7pv)
 def VVBJhX(self, item=None):
  if item:
   VVG7pv, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFVvl9(VVG7pv, BF(self.VVl1Tx, mode), title="Reading Categories ...")
   else : FFVvl9(VVG7pv, BF(self.VVZzJM, VVG7pv, title), title="Reading Account ...")
 def VVZzJM(self, VVG7pv, title, forceMoreInfo=False):
  rows, totCols = self.VVG2GI(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV6daG)
  VVRsW0  = ("Home Menu" , FF9KFt           , [])
  VVDle6  = None
  if VVWEgS:
   VVDle6 = ("Get JS"  , BF(self.VVZK6v, self.VV93yC()) , [])
  if totCols == 2:
   VVUum8 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVUum8 = ("More Info.", BF(self.VVZz0t, VVG7pv)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFvfpt(self, None, title=title, width=1200, header=header, VVUel6=rows, VVFNzW=widths, VVH0vt=26, VVRsW0=VVRsW0, VVDle6=VVDle6, VVUum8=VVUum8, VVRdqN="#0a00292B", VVkSGg="#0a002126", VVTJDG="#0a002126", VVChAx="#00000000", searchCol=searchCol)
 def VVZK6v(self, url, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVlvF1, url), title="Getting JS ...")
 def VVlvF1(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VV6daG)
  ver, err = self.VVMRrM(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVMRrM(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFEso0(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVZz0t(self, VVG7pv, VVhkUd, title, txt, colList):
  VVhkUd.cancel()
  FFVvl9(VVG7pv, BF(self.VVZzJM, VVG7pv, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVl1Tx(self, mode):
  token, profile, tErr = self.VVTLtK()
  if not token:
   return
  res, err = self.VVb4hn(self.VVWj9o(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CC3ZOl.VVq4yM(item, "id"       )
      Title  = CC3ZOl.VVq4yM(item, "title"      )
      censored = CC3ZOl.VVq4yM(item, "censored"     )
      Title = self.VVAW8u(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVS9jK:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVnULp(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo(mode)
   mName = self.VVnULp(mode)
   VVAWwW  = (""     , BF(self.VVC65U, mode), [])
   VVOPmD   = ("Show List"   , BF(self.VViBT1, mode)   , [])
   VVRsW0  = ("Home Menu"   , FF9KFt        , [])
   if mode in ("vod", "series"):
    VVPOPD = ("Find in %s" % mName , BF(self.VV1ILc, mode, False), [])
    VVUum8 = ("Find in Selected" , BF(self.VV1ILc, mode, True) , [])
   else:
    VVPOPD = None
    VVUum8 = None
   header   = None
   widths   = (100   , 0  )
   FFvfpt(self, None, title=title, width=1200, header=header, VVUel6=list, VVFNzW=widths, VVH0vt=30, VVRsW0=VVRsW0, VVPOPD=VVPOPD, VVUum8=VVUum8, VVAWwW=VVAWwW, VVOPmD=VVOPmD, VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVTJDG, VVChAx=VVChAx, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVtYKA:
     txt += "\n\n( %s )" % self.VVtYKA
   else:
    txt = "Could not get Categories from server!"
   FF9Njt(self, txt, title=title)
 def VVpYSW(self, mode, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVCcDl, mode, VVhkUd, title, txt, colList), title="Downloading ...")
 def VVCcDl(self, mode, VVhkUd, title, txt, colList):
  token, profile, tErr = self.VVTLtK()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVb4hn(self.VVZeTe(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CC3ZOl.VVq4yM(item, "id"    )
      actors   = CC3ZOl.VVq4yM(item, "actors"   )
      added   = CC3ZOl.VVq4yM(item, "added"   )
      age    = CC3ZOl.VVq4yM(item, "age"   )
      category_id  = CC3ZOl.VVq4yM(item, "category_id" )
      description  = CC3ZOl.VVq4yM(item, "description" )
      director  = CC3ZOl.VVq4yM(item, "director"  )
      genres_str  = CC3ZOl.VVq4yM(item, "genres_str"  )
      name   = CC3ZOl.VVq4yM(item, "name"   )
      path   = CC3ZOl.VVq4yM(item, "path"   )
      screenshot_uri = CC3ZOl.VVq4yM(item, "screenshot_uri" )
      series   = CC3ZOl.VVq4yM(item, "series"   )
      cmd    = CC3ZOl.VVq4yM(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVAWwW = (""     , BF(self.VVb1bN, mode, True)  , [])
   VVOPmD  = ("Play"    , BF(self.VVbXz0, mode)       , [])
   VV5qt4 = (""     , BF(self.VVVAlb, mode)     , [])
   VVRsW0 = ("Home Menu"   , FF9KFt            , [])
   VVDle6 = ("Download Options" , BF(self.VVTa6H, mode, "sp", seriesName) , [])
   VVPOPD = ("Options"   , BF(self.VVFB4x, "pEp", mode, seriesName) , [])
   VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVxWCE  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFvfpt(self, None, title=seriesName, width=1200, header=header, VVUel6=list, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVAWwW=VVAWwW, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindIptv, VVRdqN="#0a00292B", VVkSGg="#0a002126", VVTJDG="#0a002126", VVChAx="#00000000")
  else:
   FF9Njt(self, "Could not get Episodes from server!", title=seriesName)
 def VV1ILc(self, mode, searchInCat, VVhkUd, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVutlQ = []
  VVutlQ.append(("Keyboard"  , "manualEntry"))
  VVutlQ.append(("From Filter" , "fromFilter"))
  FFre61(self, BF(self.VV4kPL, VVhkUd, mode, searchCatId), title="Input Type", VVutlQ=VVutlQ, width=400)
 def VV4kPL(self, VVhkUd, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFuRfO(self, BF(self.VVm8eW, VVhkUd, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCtamE(self)
    filterObj.VVKEz5(BF(self.VVm8eW, VVhkUd, mode, searchCatId))
 def VVm8eW(self, VVhkUd, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FF3Ual(CFG.lastFindIptv, searchName)
   title = self.VVl0du(mode, searchName)
   if "," in searchName : FF9Njt(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FF9Njt(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVecfR([searchName]):
     FF9Njt(self, self.VVL5YU(), title=title)
    else:
     self.VVb2E1(mode, searchName, "", searchName, searchCatId)
 def VViBT1(self, mode, VVhkUd, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVb2E1(mode, bName, catID, "", "")
 def VVb2E1(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CC1jbq, barTheme=CC1jbq.VVlB2I
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVFuzf, mode, bName, catID, searchName, searchCatId)
      , VVFqvg = BF(self.VVuhwg, mode, bName, catID, searchName, searchCatId))
 def VVuhwg(self, mode, bName, catID, searchName, searchCatId, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVl0du(mode, searchName)
  else   : title = "%s : %s" % (self.VVnULp(mode), bName)
  if VVeIVc:
   VVDle6 = None
   VVPOPD = None
   if mode == "series":
    VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo("series2")
    VVOPmD  = ("Episodes"   , BF(self.VVpYSW, mode)           , [])
   else:
    VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo("")
    VVOPmD  = ("Play"    , BF(self.VVbXz0, mode)           , [])
    VVDle6 = ("Download Options" , BF(self.VVTa6H, mode, "vp" if mode == "vod" else "", "") , [])
    VVPOPD = ("Options"   , BF(self.VVFB4x, "pCh", mode, bName)      , [])
   VVAWwW = (""      , BF(self.VVb1bN, mode, False)      , [])
   VV5qt4 = (""      , BF(self.VVvl1H, mode)         , [])
   VVRsW0 = ("Home Menu"    , FF9KFt                , [])
   VVUum8 = ("Posters Mode"   , BF(self.VVAeQV, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVxWCE  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VVeIVc, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindIptv, VVOPmD=VVOPmD, VVAWwW=VVAWwW, VV5qt4=VV5qt4, VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVTJDG, VVChAx=VVChAx, VVNWl5=True, searchCol=1)
   if not VVegYv:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVhkUd.VV5ujT(VVhkUd.VV5xTc() + tot)
    if threadErr: FFhSFw(VVhkUd, "Error while reading !", 2000)
    else  : FFhSFw(VVhkUd, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF9Njt(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF9Njt(self, "Could not get list from server !", title=title)
 def VVvl1H(self, mode, VVhkUd, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF0D7j(x, VVPr8g), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FF0gQ0(self, fncMode=CCY1HC.VV9bkk, portalHost=self.VVQ4dj, portalMac=self.VV6daG, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV42bc(mode, VVhkUd, title, txt, colList)
 def VVVAlb(self, mode, VVhkUd, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF0D7j(colList[10], VVBhz1)
  txt += "Description:\n%s" % FF0D7j(colList[11], VVBhz1)
  self.VV42bc(mode, VVhkUd, title, txt, colList)
 def VV42bc(self, mode, VVhkUd, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWdYd(mode, colList)
  refCode, chUrl = self.VV3HXs(self.VVQ4dj, self.VV6daG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FF0gQ0(self, fncMode=CCY1HC.VVZ5aH, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVFuzf(self, mode, bName, catID, searchName, searchCatId, VVdu90):
  try:
   token, profile, tErr = self.VVTLtK()
   if not token:
    return
   if VVdu90.isCancelled:
    return
   VVdu90.VVeIVc, total_items, max_page_items, err = self.VVVFFb(mode, catID, 1, 1, searchName, searchCatId)
   if VVdu90.isCancelled:
    return
   if VVdu90.VVeIVc and total_items > -1 and max_page_items > -1:
    VVdu90.VV7hIf(total_items)
    VVdu90.VVRbmv(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVdu90.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVVFFb(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVdu90.VV2m3h()
     if VVdu90.isCancelled:
      return
     if list:
      VVdu90.VVeIVc += list
      VVdu90.VVRbmv(len(list), True)
  except:
   pass
 def VVVFFb(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VV7Gpi(mode, searchName, searchCatId, page)
  else   : url = self.VVMM1B(mode, catID, page)
  res, err = self.VVb4hn(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVuwV8(CC3ZOl.VVq4yM(item, "total_items" ))
     max_page_items = self.VVuwV8(CC3ZOl.VVq4yM(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC3ZOl.VVq4yM(item, "id"    )
      name   = CC3ZOl.VVq4yM(item, "name"   )
      o_name   = CC3ZOl.VVq4yM(item, "o_name"   )
      category_id  = CC3ZOl.VVq4yM(item, "category_id" )
      tv_genre_id  = CC3ZOl.VVq4yM(item, "tv_genre_id" )
      number   = CC3ZOl.VVq4yM(item, "number"   ) or str(counter)
      logo   = CC3ZOl.VVq4yM(item, "logo"   )
      screenshot_uri = CC3ZOl.VVq4yM(item, "screenshot_uri" )
      pic    = CC3ZOl.VVq4yM(item, "pic"   )
      cmd    = CC3ZOl.VVq4yM(item, "cmd"   )
      censored  = CC3ZOl.VVq4yM(item, "censored"  )
      genres_str  = CC3ZOl.VVq4yM(item, "genres_str"  )
      curPlay   = CC3ZOl.VVq4yM(item, "cur_playing" )
      actors   = CC3ZOl.VVq4yM(item, "actors"   )
      descr   = CC3ZOl.VVq4yM(item, "description" )
      director  = CC3ZOl.VVq4yM(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFuZgB(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVQ4dj + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVVZZx(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVuwV8(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVbXz0(self, mode, VVhkUd, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWdYd(mode, colList)
  refCode, chUrl = self.VV3HXs(self.VVQ4dj, self.VV6daG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVMYA2(chName):
   FFhSFw(VVhkUd, "This is a marker!", 300)
  else:
   FFVvl9(VVhkUd, BF(self.VVBKjm, mode, VVhkUd, chUrl), title="Playing ...")
 def VVBKjm(self, mode, VVhkUd, chUrl):
  FFlpKW(self, chUrl, VVeuyP=False)
  CCGzpp.VVfWLm(self.session, iptvTableParams=(self, VVhkUd, mode))
 def VVx9wg(self, mode, VVhkUd, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWdYd(mode, colList)
  refCode, chUrl = self.VV3HXs(self.VVQ4dj, self.VV6daG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVWdYd(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVSfC2(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVutlQ = []
    VVutlQ.append((title        , "inst" ))
    VVutlQ.append(("Update Packages then %s" % title , "updInst" ))
    FFre61(SELF, BF(CCJ0a3.VVPqsF, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVutlQ=VVutlQ)
   return False
 @staticmethod
 def VVPqsF(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFwyvS(VVy8pU, "")
   if cmdUpd:
    cmdInst = FFciUY(VVtZiS, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF9pl1(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVsWF3=cbFnc)
   else:
    FFdRu7(SELF)
 def VVCxdV(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVN0zr(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VV8hzO(self, VVG7pv):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVCxdV()
  if all((curMode, curHost, curCat)) and curHost == self.VVQ4dj:
   VVG7pv.VV75it({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVC65U(self, mode, VVhkUd, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVCxdV()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVQ4dj:
   VVhkUd.VV9SZy({1:curCat})
 def VVb1bN(self, mode, isEp, VVhkUd, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVCxdV()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVQ4dj:
   if mode in ("itv", "vod"):
    VVhkUd.VV9SZy({2:curStID})
   else: #series
    if isEp:
     VVhkUd.VV9SZy({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVhkUd.VV9SZy({2:ser2})
     if not ok: VVhkUd.VV9SZy({2:ser1})
class CC3ZOl(Screen, CCJ0a3, CC26Ue, CC7DUr):
 VVOipX    = 0
 VVdXNZ    = 1
 VV4gf8    = 2
 VVzspM    = 3
 VVrtzq     = 4
 VVtpKK     = 5
 VVDZgJ     = 6
 VV4L7X     = 7
 VVJhyY     = 8
 VVysoN     = 9
 VVkC8M      = 10
 VVEyBg     = 11
 VVAeLO     = 12
 VVZoSN     = 13
 VV3mGm     = 14
 VV5IZf      = 15
 VVSweN      = 16
 VV5oZz      = 17
 VVU1Js      = 18
 VVOfCD      = 19
 VVaRCh    = 0
 VVjzKg   = 1
 VVOLum   = 2
 VV70Qz   = 3
 VVHp0c  = 4
 VVt4kd  = 5
 VV7Kdc   = 6
 VVIgU3   = 7
 VVD8FZ  = 8
 VVyfRH  = 9
 VVr81F  = 10
 VVPUv3 = 0
 VVJDQf = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFzoo9(VVzryP, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVhkUd    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVZ5pQData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CC3ZOl.VVYQhO(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCJ0a3.__init__(self)
  CC26Ue.__init__(self)
  VVutlQ = self.VVJ8vv()
  FFk1xo(self, title="IPTV", VVutlQ=VVutlQ)
  self["myActionMap"].actions.update({
   "menu" : self.VVwFVP
  })
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVseS9)
  global VVLdrz
  VVLdrz = True
 def VVywsT(self):
  self["myMenu"].setList(self.VVJ8vv())
  FFkPKs(self)
  FFqFdY(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFRLsp(self["myMenu"])
   FF1Sqn(self)
   if self.m3uOrM3u8File:
    self.VVjVk2(self.m3uOrM3u8File)
   else:
    self.VVPqBm()
 def VVPqBm(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFoVhu("VVLdrz")
 def VVseS9(self):
  if self["myMenu"].getCurrent()[1] in ("VVY6E9", "VVontBPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVwFVP(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VVontBPortal" : confItem = CFG.favServerPortal
   elif item == "VVY6E9" : confItem = CFG.favServerPlaylist
   else         : return
   FFfbEx(self, BF(self.VVsvqs, confItem), 'Remove from menu ?', title=title)
 def VVsvqs(self, confItem):
  FF3Ual(confItem, "")
  self.VVywsT()
 def VVJ8vv(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVQrak
  VVutlQ = []
  if isFav1: VVutlQ.append((c +  "Favourite Playlist Server"   , "VVY6E9" ))
  if isFav2: VVutlQ.append((c +  "Favourite Portal Server"    , "VVontBPortal" ))
  VVutlQ.append(("IPTV Server Browser (from Playlists)"     , "VVZ5pQ_fromPlayList" ))
  VVutlQ.append(("IPTV Server Browser (from Portal List)"    , "VVZ5pQ_fromMac"  ))
  VVutlQ.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVZ5pQ_fromM3u"  ))
  qUrl, iptvRef = CC3ZOl.VVkdjp(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVutlQ.append(FF47SM("IPTV Server Browser (from Current Channel)", "VVZ5pQ_fromCurrChan", fromCurCond))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("M3U/M3U8 File Browser"        , "VV12HS"   ))
  if self.iptvFileAvailable:
   VVutlQ.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(FF47SM("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVutlQ.append(FF47SM("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVutlQ.append(VVJKCZ)
   c1, c2 = VVqWCE, VVPr8g
   t1 = FF0D7j("auto-match names", VVQrak)
   t2 = FF0D7j("from xml file"  , VVQrak)
   VVutlQ.append((c1 + "Count Available IPTV Channels"    , "VV2zAc"    ))
   VVutlQ.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVutlQ.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVnaIr" ))
   VVutlQ.append((VVO7vL + "More Reference Tools ..."  , "VVbZuW"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Reload Channels and Bouquets"       , "VVpE62"   ))
  VVutlQ.append(VVJKCZ)
  if not CCkpqq.VVkLR8():
   VVutlQ.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVutlQ.append(("Download Manager ... No downloads"    ,       ))
  return VVutlQ
 def VVC0O7(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVkJtB"   : self.VVkJtB()
   elif item == "VV76UC" : FFfbEx(self, self.VV76UC, "Change Current List References to Unique Codes ?")
   elif item == "VV7TDp_rows" : FFfbEx(self, BF(FFVvl9, self.VVhkUd, self.VV7TDp), "Change Current List References to Identical Codes ?")
   elif item == "VVUUVH"   : self.VVUUVH(tTitle)
   elif item == "VVioKu"   : self.VVioKu(tTitle)
   elif item == "VVY6E9" : self.VVontB(False)
   elif item == "VVontBPortal" : self.VVontB(True)
   elif item == "VVZ5pQ_fromPlayList" : FFVvl9(self, BF(self.VVaEsz, 1), title=title)
   elif item == "VVZ5pQ_fromM3u"  : FFVvl9(self, BF(self.VVJfnd, CC3ZOl.VVPUv3), title=title)
   elif item == "VVZ5pQ_fromMac"  : self.VV3sJO()
   elif item == "VVZ5pQ_fromCurrChan" : self.VVuFVT()
   elif item == "VV12HS"   : self.VV12HS()
   elif item == "iptvTable_all"   : FFVvl9(self, BF(self.VVBSBf, self.VVOipX), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CC3ZOl.VVHFOc(self)
   elif item == "refreshIptvPicons"  : self.VVqdKP()
   elif item == "VV2zAc"    : FFVvl9(self, self.VV2zAc)
   elif item == "copyEpgPicons"   : self.VVE73I(False)
   elif item == "renumIptvRef_fromFile" : self.VVE73I(True)
   elif item == "VVnaIr" : FFfbEx(self, BF(FFVvl9, self, self.VVnaIr), VVumEG="Continue ?")
   elif item == "VVbZuW"    : self.VVbZuW()
   elif item == "VVpE62"   : FFVvl9(self, BF(CCIdtv.VVpE62, self))
   elif item == "dload_stat"    : CCkpqq.VV4eHX(self)
 def VV12HS(self):
  if CCJ0a3.VVSfC2(self):
   FFVvl9(self, BF(self.VVJfnd, CC3ZOl.VVJDQf), title="Searching ...")
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVC0O7(item)
 def VVBSBf(self, mode):
  VV796F = self.VVqx8g(mode)
  if VV796F:
   VVDle6 = ("Current Service", self.VVJvUE , [])
   VVPOPD = ("Options"  , self.VV9tvn   , [])
   VVUum8 = ("Filter"   , self.VVh7Or   , [])
   VVOPmD  = ("Play"   , BF(self.VV15Yq)  , [])
   VV5qt4 = (""    , self.VV2PTS    , [])
   VVAWwW = (""    , self.VVUb5p     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVxWCE  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFvfpt(self, None, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26
     , VVOPmD=VVOPmD, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, VV5qt4=VV5qt4, VVAWwW=VVAWwW
     , VVRdqN="#0a00292B", VVkSGg="#0a002126", VVTJDG="#0a002126", VVChAx="#00000000", VVNWl5=True, searchCol=1)
  else:
   if mode == self.VVysoN: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF9Njt(self, err)
 def VVUb5p(self, VVhkUd, title, txt, colList):
  self.VVhkUd = VVhkUd
 def VV9tvn(self, VVhkUd, title, txt, colList):
  VVutlQ = []
  VVutlQ.append(("Add Current List to a New Bouquet"    , "VVkJtB"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change Current List References to Unique Codes" , "VV76UC"))
  VVutlQ.append(("Change Current List References to Identical Codes", "VV7TDp_rows" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Share Reference with DVB Service (manual entry)" , "VVUUVH"   ))
  VVutlQ.append(("Share Reference with DVB Service (auto-find)"  , "VVioKu"   ))
  FFre61(self, self.VVC0O7, title="IPTV Tools", VVutlQ=VVutlQ)
 def VVh7Or(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVwejA, VVhkUd))
 def VVwejA(self, VVhkUd):
  VVutlQ = []
  VVutlQ.append(("All"         , "all"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Prefix of Selected Channel"   , "sameName" ))
  VVutlQ.append(("Suggest Words from Selected Channel" , "partName" ))
  VVutlQ.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVutlQ.append(("Duplicate References"     , "depRef"  ))
  VVutlQ.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVutlQ.append(("Stream Relay"       , "SRelay"  ))
  VVutlQ.append(FFODSa("Category"))
  VVutlQ.append(("Live TV"        , "live"  ))
  VVutlQ.append(("VOD"         , "vod"   ))
  VVutlQ.append(("Series"        , "series"  ))
  VVutlQ.append(("Uncategorised"      , "uncat"  ))
  VVutlQ.append(FFODSa("Media"))
  VVutlQ.append(("Video"        , "video"  ))
  VVutlQ.append(("Audio"        , "audio"  ))
  VVutlQ.append(FFODSa("File Type"))
  VVutlQ.append(("MKV"         , "MKV"   ))
  VVutlQ.append(("MP4"         , "MP4"   ))
  VVutlQ.append(("MP3"         , "MP3"   ))
  VVutlQ.append(("AVI"         , "AVI"   ))
  VVutlQ.append(("FLV"         , "FLV"   ))
  VVutlQ.extend(CC0axI.VVt3TU(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVYA2D, VVhkUd) if VVhkUd.VV5xTc().startswith("IPTV Filter ") else None
  filterObj = CCtamE(self)
  filterObj.VVo6vS(VVutlQ, VVutlQ, BF(self.VVdqVE, VVhkUd, False), inFilterFnc=inFilterFnc)
 def VVYA2D(self, VVhkUd, VVG7pv, item):
  self.VVdqVE(VVhkUd, True, item)
 def VVdqVE(self, VVhkUd, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVhkUd.VVxwcf(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVOipX , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVdXNZ , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV4gf8 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVzspM , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVDZgJ  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV4L7X  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVJhyY  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVysoN  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVkC8M   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVEyBg  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVAeLO  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVZoSN  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV3mGm  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV5IZf   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVSweN   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV5oZz   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVU1Js   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVOfCD   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVrtzq  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVtpKK  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV4gf8:
   VVutlQ = []
   chName = VVhkUd.VVxwcf(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVutlQ.append((item, item))
    if not VVutlQ and chName:
     VVutlQ.append((chName, chName))
    FFre61(self, BF(self.VVfqJP, title), title="Words from Current Selection", VVutlQ=VVutlQ)
   else:
    VVhkUd.VVRR2a("Invalid Channel Name")
  else:
   words, asPrefix = CCtamE.VVy75H(words)
   if not words and mode in (self.VVrtzq, self.VVtpKK):
    FFhSFw(self.VVhkUd, "Incorrect filter", 2000)
   else:
    FFVvl9(self.VVhkUd, BF(self.VVzq4P, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVfqJP(self, title, word=None):
  if word:
   words = [word.lower()]
   FFVvl9(self.VVhkUd, BF(self.VVzq4P, self.VV4gf8, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVWS6n(txt):
  return "#f#11ffff00#" + txt
 def VVzq4P(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VV796F = self.VVW1Oy(mode=mode, words=words, asPrefix=asPrefix)
  else       : VV796F = self.VVqx8g(mode=mode, words=words, asPrefix=asPrefix)
  if VV796F : self.VVhkUd.VVoiHv(VV796F, title)
  else  : self.VVhkUd.VVRR2a("Not found")
 def VVW1Oy(self, mode=0, words=None, asPrefix=False):
  VV796F = []
  for row in self.VVhkUd.VVNCJx():
   row = list(map(str.strip, row))
   chNum, chName, VVHrCe, chType, refCode, url = row
   if self.VV1z3k(mode, refCode, FF2zGt(url).lower(), chName, words, VVHrCe.lower(), asPrefix):
    VV796F.append(row)
  VV796F = self.VVP62Q(mode, VV796F)
  return VV796F
 def VVqx8g(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VV796F = []
  files = CC3ZOl.VVYQhO()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFXk75(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVHrCe = span.group(1)
    else : VVHrCe = ""
    VVHrCe_lCase = VVHrCe.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVMYA2(chName): chNameMod = self.VVWS6n(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVHrCe, chType + (" SRel" if FFcIP1(url) else ""), refCode, url)
     if self.VV1z3k(mode, refCode, FF2zGt(url).lower(), chName, words, VVHrCe_lCase, asPrefix):
      VV796F.append(row)
      chNum += 1
  VV796F = self.VVP62Q(mode, VV796F)
  return VV796F
 def VVP62Q(self, mode, VV796F):
  newRows = []
  if VV796F and mode == self.VVDZgJ:
   counted  = iCounter(elem[4] for elem in VV796F)
   for item in VV796F:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VV796F
 def VV1z3k(self, mode, refCode, tUrl, chName, words, VVHrCe_lCase, asPrefix):
  if   mode == self.VVOipX : return True
  elif mode == self.VVDZgJ : return True
  elif mode == self.VV4L7X  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVJhyY : return FFcIP1(tUrl)
  elif mode == self.VVZoSN  : return CC3ZOl.VVakT8(tUrl, getAudVid=True) == "vid"
  elif mode == self.VV3mGm  : return CC3ZOl.VVakT8(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVysoN  : return CC3ZOl.VVakT8(tUrl, compareType="live")
  elif mode == self.VVkC8M  : return CC3ZOl.VVakT8(tUrl, compareType="movie")
  elif mode == self.VVEyBg : return CC3ZOl.VVakT8(tUrl, compareType="series")
  elif mode == self.VVAeLO  : return CC3ZOl.VVakT8(tUrl, compareType="")
  elif mode == self.VV5IZf  : return CC3ZOl.VVakT8(tUrl, compareExt="mkv")
  elif mode == self.VVSweN  : return CC3ZOl.VVakT8(tUrl, compareExt="mp4")
  elif mode == self.VV5oZz  : return CC3ZOl.VVakT8(tUrl, compareExt="mp3")
  elif mode == self.VVU1Js  : return CC3ZOl.VVakT8(tUrl, compareExt="avi")
  elif mode == self.VVOfCD  : return CC3ZOl.VVakT8(tUrl, compareExt="flv")
  elif mode == self.VVdXNZ: return chName.lower().startswith(words[0])
  elif mode == self.VV4gf8: return words[0] in chName.lower()
  elif mode == self.VVzspM: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVrtzq : return words[0] == VVHrCe_lCase
  elif mode == self.VVtpKK :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVkJtB(self):
  picker = CC0axI(self, self.VVhkUd, "Add to Bouquet", self.VV7fhn)
 def VV7fhn(self):
  chUrlLst = []
  for row in self.VVhkUd.VVNCJx():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVbZuW(self):
  t1 = FF0D7j("Bouquet" , VVPr8g)
  t2 = FF0D7j("ALL"  , VVO7vL)
  t3 = FF0D7j("Unique"  , VVqWCE)
  t4 = FF0D7j("Identical" , VVQrak)
  VVutlQ = []
  VVutlQ.append((VVFWDt + "Check System Acceptable Reference Types", "VVwFEo"))
  VVutlQ.append(FF47SM("Check Reference Codes Format", "VVPLYc", self.iptvFileAvailable, VVFWDt))
  VVutlQ.append(VVJKCZ)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVutlQ.append((txt % t1, "VVVjxf" ))
  VVutlQ.append((txt % t2, "VVbavo_all"  ))
  VVutlQ.append(VVJKCZ)
  txt = "Change %s References to %s Codes .."
  VVutlQ.append((txt % (t1, t3), "VVx3QE" ))
  VVutlQ.append((txt % (t2, t3), "VVpoWU"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change %s References to %s Codes" % (t2, t4) , "VV7TDp_all"))
  VVnFDy = self.VV5hPi
  FFre61(self, None, width=1150, title="IPTV Reference Tools", VVutlQ=VVutlQ, VVnFDy=VVnFDy, VVRdqN="#22002233", VVkSGg="#22001122")
 def VV5hPi(self, item=None):
  if item:
   ques = "Continue ?"
   VVG7pv, txt, item, ndx = item
   if   item == "VVwFEo"    : FFVvl9(VVG7pv, self.VVwFEo)
   elif item == "VVPLYc"     : FFVvl9(VVG7pv, self.VVPLYc)
   elif item == "VVVjxf" : self.VVdDHy(VVG7pv, self.VVlvon)
   elif item == "VVbavo_all"  : self.VVlvon(VVG7pv, None, None)
   elif item == "VVx3QE" : self.VVx3QE(VVG7pv, txt)
   elif item == "VVpoWU"  : FFfbEx(self, BF(self.VVpoWU , VVG7pv, txt), title=txt, VVumEG=ques)
   elif item == "VV7TDp_all"  : FFfbEx(self, BF(FFVvl9, VVG7pv, self.VV7TDp), title=txt, VVumEG=ques)
 def VVlvon(self, VVG7pv, bName, bPath):
  VVutlQ = []
  for rt in CC3ZOl.VVXLzV():
   VVutlQ.append(("%s\t ... %s" % (rt, CC3ZOl.VVEEig(rt)), rt))
  FFre61(self, BF(self.VVp4iq, VVG7pv, bName, bPath), VVutlQ=VVutlQ, width=800, title="Change Reference Types to:")
 def VVp4iq(self, VVG7pv, bName, bPath, rType=None):
  if rType:
   self.VVa3EB(VVG7pv, bName, bPath, rType)
 def VVdDHy(self, VVG7pv, fnc):
  VVutlQ = CC0axI.VVt3TU()
  if VVutlQ:
   FFre61(self, BF(self.VV6nlC, VVG7pv, fnc), VVutlQ=VVutlQ, title="IPTV Bouquets", VVNxG7=True)
  else:
   FFhSFw(VVG7pv, "No bouquets Found !", 1500)
 def VV6nlC(self, VVG7pv, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVGMYl + span.group(1)
    if fileExists(bPath): fnc(VVG7pv, bName, bPath)
    else    : FFhSFw(VVG7pv, "Bouquet file not found!", 2000)
   else:
    FFhSFw(VVG7pv, "Cannot process bouquet !", 2000)
 def VVa3EB(self, VVG7pv, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FF0D7j(bName, VVRkew)
  else : title = "Change for %s" % FF0D7j("All IPTV Services", VVRkew)
  FFfbEx(self, BF(FFVvl9, VVG7pv, BF(self.VVk8Qg, VVG7pv, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FF0D7j(rType, VVRkew), title=title)
 def VVk8Qg(self, VVG7pv, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CC3ZOl.VVYQhO()
  if files:
   newRType = rType + ":"
   piconPath = CC3hRa.VV3CCT()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCLSXF.VVpzqc(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FF9Njt(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FF2ufE("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FF2ufE(cmd)
  self.VV5TH7(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VV2zAc(self):
  totFiles = 0
  files  = CC3ZOl.VVYQhO()
  if files:
   totFiles = len(files)
  totChans = 0
  VV796F = self.VVqx8g()
  if VV796F:
   totChans = len(VV796F)
  FFEso0(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVPLYc(self):
  files = CC3ZOl.VVYQhO()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFXk75(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVRTFm
   else    : color = VVUS1a
   totInvalid = FF0D7j(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF0D7j("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFEso0(self, txt, title="Check IPTV References")
 def VVwFEo(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CC3ZOl.VVXLzV()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CC0axI.VVbZpk(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVY0hj = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVY0hj:
   VVwJ4u = FFmpJ8(VVY0hj)
   if VVwJ4u:
    for service in VVwJ4u:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVGMYl + userBName
  bFile = VVGMYl + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFYhY6("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFYhY6("rm -f '%s'" % path)
  FF2ufE(cmd)
  FFURke()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVRTFm
    else     : res, color = "No" , VVUS1a
    pl = CC3ZOl.VVEEig(item)
    txt += "    %s\t: %s%s\n" % (item, FF0D7j(res, color), FF0D7j("\t... %s" % pl, VVBhz1) if pl else "")
   FFEso0(self, txt, title=title)
  else:
   txt = FF9Njt(self, "Could not complete the test on your system!", title=title)
 def VVnaIr(self):
  VVy2ge, err = CCIdtv.VVu18q(self, CCIdtv.VV2yf4)
  if VVy2ge:
   totChannels = 0
   totChange = 0
   for path in CC3ZOl.VVYQhO():
    toSave = False
    txt = FFXk75(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVy2ge.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV5TH7(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF9Njt(self, 'No channels in "lamedb" !')
 def VVpoWU(self, VVG7pv, title):
  bFiles = CC3ZOl.VVYQhO()
  if bFiles: self.VVhtdr(bFiles, title)
  else  : FFhSFw(VVG7pv, "No bouquets files !", 1500)
 def VVx3QE(self, VVG7pv, title):
  self.VVdDHy(VVG7pv, BF(self.VVulvO, title))
 def VVulvO(self, title, VVG7pv, bName, bPath):
  self.VVhtdr([bPath], title)
 def VVhtdr(self, bFiles, title):
  self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VV9oN8, bFiles)
      , VVFqvg = BF(self.VVVlYy, title))
 def VV9oN8(self, bFiles, VVdu90):
  VVdu90.VVeIVc = ""
  VVdu90.VVnUuP("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF6UEw(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVdu90 or VVdu90.isCancelled:
   return
  elif not totLines:
   VVdu90.VVeIVc = "No IPTV Services !"
   return
  else:
   VVdu90.VV7hIf(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVdu90 or VVdu90.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF6UEw(path)
    for ndx, line in enumerate(lines):
     if not VVdu90 or VVdu90.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVdu90:
       VVdu90.VVnUuP("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVdu90:
       VVdu90.VVRbmv(1)
      refCode, startId, startNS = CC0axI.VVByyr(rType, CC0axI.VVq9R3, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVdu90:
        VVdu90.VVeIVc = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVVlYy(self, title, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVeIVc:
   txt += "\n\n%s\n%s" % (FF0D7j("Ended with Error:", VVUS1a), VVeIVc)
  self.VV5TH7(True, title, txt)
 def VV76UC(self):
  bFiles = CC3ZOl.VVYQhO()
  if not bFiles:
   FFhSFw(self.VVhkUd, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVhkUd.VVNCJx():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFhSFw(self.VVhkUd, "Cannot read list", 1500)
   return
  self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVUyP3, bFiles, tableRefList)
      , VVFqvg = BF(self.VVVlYy, "Change Current List References to Unique Codes"))
 def VVUyP3(self, bFiles, tableRefList, VVdu90):
  VVdu90.VVeIVc = ""
  VVdu90.VVnUuP("Reading System References ...")
  refLst = CC0axI.VVQLYv(CC0axI.VVq9R3, stripRType=True)
  if not VVdu90 or VVdu90.isCancelled:
   return
  VVdu90.VV7hIf(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVdu90 or VVdu90.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFXk75(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVdu90 or VVdu90.isCancelled:
     return
    VVdu90.VVnUuP("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVdu90 or VVdu90.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVdu90.VVRbmv(1)
      refCode, startId, startNS = CC0axI.VVByyr(rType, CC0axI.VVq9R3, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVdu90:
        VVdu90.VVeIVc = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VV7TDp(self):
  list = None
  if self.VVhkUd:
   list = []
   for row in self.VVhkUd.VVNCJx():
    list.append(row[4] + row[5])
  files = CC3ZOl.VVYQhO()
  totChange = 0
  if files:
   for path in files:
    lines = FF6UEw(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VV5TH7(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV5TH7(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFURke()
   if refreshTable and self.VVhkUd:
    VV796F = self.VVqx8g()
    if VV796F and self.VVhkUd:
     self.VVhkUd.VVoiHv(VV796F, self.tableTitle)
     self.VVhkUd.VVRR2a(txt)
   FFEso0(self, txt, title=title)
  else:
   FFmMPS(self, "No changes.")
 @staticmethod
 def VVYQhO(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVGMYl + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFXk75(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV2PTS(self, VVhkUd, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FF2zGt(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FF0gQ0(self, fncMode=CCY1HC.VVJUjV, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVGtsd(self, VVhkUd, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VV15Yq(self, VVhkUd, title, txt, colList):
  chName, chUrl = self.VVGtsd(VVhkUd, colList)
  self.VVA7bD(VVhkUd, chName, chUrl, "localIptv")
 def VVs3yZ(self, mode, VVhkUd, colList):
  chName, chUrl, picUrl, refCode = self.VV56wc(mode, colList)
  return chName, chUrl
 def VVfNY1(self, mode, VVhkUd, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV56wc(mode, colList)
  self.VVA7bD(VVhkUd, chName, chUrl, mode)
 def VVA7bD(self, VVhkUd, chName, chUrl, playerFlag):
  chName = FFLAHl(chName)
  if self.VVMYA2(chName):
   FFhSFw(VVhkUd, "This is a marker!", 300)
  else:
   FFVvl9(VVhkUd, BF(self.VVykTL, VVhkUd, chUrl, playerFlag), title="Playing ...")
 def VVykTL(self, VVhkUd, chUrl, playerFlag):
  FFlpKW(self, chUrl, VVeuyP=False)
  CCGzpp.VVfWLm(self.session, iptvTableParams=(self, VVhkUd, playerFlag))
 @staticmethod
 def VVMYA2(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVJvUE(self, VVhkUd, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  if refCode:
   url1 = FF2zGt(origUrl.strip())
   for ndx, row in enumerate(VVhkUd.VVNCJx()):
    if refCode in row[4]:
     tableRow = FF2zGt(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVhkUd.VVfMAJ(ndx)
      break
   else:
    FFhSFw(VVhkUd, "No found", 1000)
 def VVJfnd(self, m3uMode):
  lines = self.VVC6IY(3)
  if lines:
   lines.sort()
   VVutlQ = []
   for line in lines:
    VVutlQ.append((line, line))
   if m3uMode == CC3ZOl.VVPUv3:
    title = "Browse Server from M3U URLs"
    VVmhL9 = ("All to Playlist", self.VVWNHi)
   else:
    title = "M3U/M3U8 File Browser"
    VVmhL9 = None
   VVnFDy = BF(self.VVYb1r, m3uMode, title)
   VVRIxl = self.VVCBcv
   FFre61(self, None, title=title, VVutlQ=VVutlQ, width=1200, VVnFDy=VVnFDy, VVRIxl=VVRIxl, VVBWci="", VVmhL9=VVmhL9, VVRdqN="#11221122", VVkSGg="#11221122")
 def VVYb1r(self, m3uMode, title, item=None):
  if item:
   VVG7pv, txt, path, ndx = item
   if m3uMode == CC3ZOl.VVPUv3:
    FFVvl9(VVG7pv, BF(self.VVUuyf, title, path))
   else:
    FFVvl9(VVG7pv, BF(self.VVjVk2, path))
 def VVjVk2(self, path, m3uFilterParam=None, VVhkUd=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFXk75(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVO5lS(propLine, "group-title") or "-"
   if not group == "-" and self.VVAW8u(group):
    if not chName or self.VVVZZx(chName):
     if self.VV1z3k(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VV796F = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VV796F.append((name, str(tot), name))
    totAll += tot
   VV796F.sort(key=lambda x: x[0].lower())
   VV796F.insert(0, ("ALL", str(totAll), ""))
  if VV796F:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVhkUd:
    VVhkUd.VVoiHv(VV796F, newTitle=title, VVanXbMsg=True)
   else:
    VVfT1c = self.VV0EVM
    VVOPmD  = ("Select" , BF(self.VVINuT, path, m3uFilterParam)  , [])
    VVUum8 = ("Filter" , BF(self.VVutUA, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVxWCE  = (LEFT  , CENTER , LEFT )
    FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, width= 1400, height= 1000, VVH0vt=28, VVOPmD=VVOPmD, VVUum8=VVUum8, VVfT1c=VVfT1c, lastFindConfigObj=CFG.lastFindIptv
      , VVRdqN="#11110022", VVkSGg="#11110022", VVTJDG="#11110022", VVChAx="#00444400")
  elif VVhkUd:
   FFGp67(VVhkUd, "Not found !", 1500)
  else:
   self.VVeQY8(FFXk75(path), "", m3uFilterParam)
 def VVINuT(self, path, m3uFilterParam, VVhkUd, title, txt, colList):
  self.VVeQY8(FFXk75(path), colList[2], m3uFilterParam)
 def VVutUA(self, path, m3uFilterParam, VVhkUd, title, txt, colList):
  VVutlQ = []
  VVutlQ.append(("All"      , "all"  ))
  VVutlQ.append(FFODSa("Category"))
  VVutlQ.append(("Live TV"     , "live" ))
  VVutlQ.append(("VOD"      , "vod"  ))
  VVutlQ.append(("Series"     , "series" ))
  VVutlQ.append(("Uncategorised"   , "uncat" ))
  VVutlQ.append(FFODSa("Media"))
  VVutlQ.append(("Video"     , "video" ))
  VVutlQ.append(("Audio"     , "audio" ))
  VVutlQ.append(FFODSa("File Type"))
  VVutlQ.append(("MKV"      , "MKV"  ))
  VVutlQ.append(("MP4"      , "MP4"  ))
  VVutlQ.append(("MP3"      , "MP3"  ))
  VVutlQ.append(("AVI"      , "AVI"  ))
  VVutlQ.append(("FLV"      , "FLV"  ))
  filterObj = CCtamE(self, VVRdqN="#11332244", VVkSGg="#11222244")
  filterObj.VVo6vS(VVutlQ, [], BF(self.VVq6us, VVhkUd, path), inFilterFnc=None)
 def VVq6us(self, VVhkUd, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVOipX , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVysoN  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVkC8M  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVEyBg  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVAeLO  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVZoSN  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VV3mGm  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VV5IZf  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVSweN  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VV5oZz  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVU1Js  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVOfCD  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVtpKK  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCtamE.VVy75H(words)
   if not mode == self.VVOipX:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FF0D7j(fTitle, VVBhz1)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFVvl9(VVhkUd, BF(self.VVjVk2, path, m3uFilterParam, VVhkUd), title="Filtering ...")
 def VVeQY8(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CC1jbq, barTheme=CC1jbq.VVlB2I
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVDbjH, lst, filterGroup, m3uFilterParam)
       , VVFqvg = BF(self.VVJlsC, title, bName))
  else:
   self.VVvrFl("No valid lines found !", title)
 def VVDbjH(self, lst, filterGroup, m3uFilterParam, VVdu90):
  VVdu90.VVeIVc = []
  VVdu90.VV7hIf(len(lst))
  num = 0
  for cols in lst:
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVRbmv(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVO5lS(propLine, "group-title") or "-"
   picon = self.VVO5lS(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVAW8u(group) : skip = True
    elif chName and not self.VVVZZx(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VV1z3k(mode, "", FF2zGt(url).lower(), chName, words, "", asPrefix)
    if not skip and VVdu90:
     num += 1
     VVdu90.VVeIVc.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVJlsC(self, title, bName, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if VVeIVc:
   VVfT1c = self.VV0EVM
   VVOPmD  = ("Select"   , BF(self.VVwVUL, title)   , [])
   VV5qt4 = (""    , self.VVQuYn        , [])
   VVDle6 = ("Download PIcons", self.VVPQBN       , [])
   VVPOPD = ("Options"  , BF(self.VVFB4x, "m3Ch", "", bName) , [])
   VVUum8 = ("Posters Mode" , BF(self.VVAeQV, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVxWCE  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFvfpt(self, None, title=title, header=header, VVUel6=VVeIVc, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, VVOPmD=VVOPmD, VVfT1c=VVfT1c, VV5qt4=VV5qt4, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindIptv, VVNWl5=True, searchCol=1
     , VVRdqN="#0a00192B", VVkSGg="#0a00192B", VVTJDG="#0a00192B", VVChAx="#00000000")
  else:
   self.VVvrFl("Not found !", title)
 def VVPQBN(self, VVhkUd, title, txt, colList):
  self.VV5eg8(VVhkUd, "m3u/m3u8")
 def VV27tl(self, rowNum, url, chName):
  refCode = self.VVd1kS(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFROgB(url), chName)
  return chUrl
 def VVd1kS(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VV2ZyA(catID, stID, chNum)
  return refCode
 def VVO5lS(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVwVUL(self, Title, VVhkUd, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFVvl9(VVhkUd, BF(self.VVn0Hg, Title, VVhkUd, colList), title="Checking Server ...")
  else:
   self.VVT8vq(VVhkUd, url, chName)
 def VVn0Hg(self, title, VVhkUd, colList):
  if not CCJ0a3.VVSfC2(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCLRZv.VVbnHU(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVutlQ = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC3ZOl.VVqtvl(url, fPath)
     VVutlQ.append((resol, fullUrl))
    if VVutlQ:
     if len(VVutlQ) > 1:
      FFre61(self, BF(self.VVEMpA, VVhkUd, chName), VVutlQ=VVutlQ, title="Resolution", VVNxG7=True, VVLIB1=True)
     else:
      self.VVT8vq(VVhkUd, VVutlQ[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVT8vq(VVhkUd, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CC3ZOl.VVqtvl(url, span.group(1))
       self.VVT8vq(VVhkUd, fullUrl, chName)
      else:
       self.VVBTBJ("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVeQY8(txt, filterGroup="")
      return
    self.VVT8vq(VVhkUd, url, chName)
   else:
    self.VVvrFl("Cannot process this channel !", title)
  else:
   self.VVvrFl(err, title)
 def VVEMpA(self, VVhkUd, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVT8vq(VVhkUd, resolUrl, chName)
 def VVT8vq(self, VVhkUd, url, chName):
  FFVvl9(VVhkUd, BF(self.VVPS3a, VVhkUd, url, chName), title="Playing ...")
 def VVPS3a(self, VVhkUd, url, chName):
  chUrl = self.VV27tl(VVhkUd.VVSWzf(), url, chName)
  FFlpKW(self, chUrl, VVeuyP=False)
  CCGzpp.VVfWLm(self.session, iptvTableParams=(self, VVhkUd, "m3u/m3u8"))
 def VVTvfW(self, VVhkUd, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV27tl(VVhkUd.VVSWzf(), url, chName)
  return chName, chUrl
 def VVQuYn(self, VVhkUd, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FF0gQ0(self, fncMode=CCY1HC.VVJUjV, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVvrFl(self, err, title):
  FF9Njt(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VV0EVM(self, VVhkUd):
  if self.m3uOrM3u8File:
   self.close()
  VVhkUd.cancel()
 def VVWNHi(self, selectionObj, item=None):
  FFVvl9(selectionObj, BF(self.VV0aCc, selectionObj, item))
 def VV0aCc(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVutlQ):
    path = item[1]
    if fileExists(path):
     enc = CCDQtT.VVvetn(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CC3ZOl.VVnr6E(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC3ZOl.VVWZc1()
    pListF = "%sPlaylist_%s.txt" % (path, FFKX94())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVutlQ)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFEso0(self, txt, title=title)
   else:
    FF9Njt(self, "Could not obtain URLs from this file list !", title=title)
 def VVaEsz(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVe6rc
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVJqUd
  lines = self.VVC6IY(mode)
  if lines:
   lines.sort()
   VVutlQ = []
   for line in lines:
    VVutlQ.append((FF0D7j(line, VVPr8g) if "Bookmarks" in line else line, line))
   VVRIxl = self.VVCBcv
   FFre61(self, None, title=title, VVutlQ=VVutlQ, width=1200, VVnFDy=okFnc, VVRIxl=VVRIxl, VVBWci="")
 def VVCBcv(self, VVG7pv, txt, ref, ndx):
  txt = ref
  sz = FFrMJ0(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCLSXF.VVtnwF(sz)
  FFEso0(self, txt, title="File Path")
 def VVe6rc(self, item=None):
  if item:
   VVG7pv, txt, path, ndx = item
   FFVvl9(VVG7pv, BF(self.VV89PM, VVG7pv, path), title="Processing File ...")
 def VV89PM(self, VVmNef, path):
  enc = CCDQtT.VVvetn(path, self)
  if enc == -1:
   return
  VV796F = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFqvjY(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC3ZOl.VVpXry(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV796F:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VV796F.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV796F:
   title = "Playlist File : %s" % os.path.basename(path)
   VVOPmD  = ("Start"    , BF(self.VVp1JW, "Playlist File")      , [])
   VVRsW0 = ("Home Menu"   , FF9KFt             , [])
   VVDle6 = ("Download M3U File" , self.VVXlVG         , [])
   VVPOPD = ("Edit File"   , BF(self.VVCx6l, path)        , [])
   VVUum8 = ("Check & Filter"  , BF(self.VVyO5V, VVmNef, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVxWCE  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVRsW0=VVRsW0, VVUum8=VVUum8, VVDle6=VVDle6, VVPOPD=VVPOPD, VVRdqN="#11001116", VVkSGg="#11001116", VVTJDG="#11001116", VVChAx="#00003635", VVDQNf="#0a333333", VV4UX1="#11331100", VVNWl5=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FF9Njt(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVXlVG(self, VVhkUd, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFfbEx(self, BF(FFVvl9, VVhkUd, BF(self.VVHujd, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVHujd(self, title, url):
  path, err = FFAqj4(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF9Njt(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFXk75(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFEUy9(path)
    FF9Njt(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFEUy9(path)
    FF9Njt(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC3ZOl.VVWZc1() + fName
    FF2ufE("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFmMPS(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF9Njt(self, "Could not download the M3U file!", title=errTitle)
 def VVp1JW(self, Title, VVhkUd, title, txt, colList):
  url = colList[6]
  FFVvl9(VVhkUd, BF(self.VViicr, Title, url), title="Checking Server ...")
 def VVCx6l(self, path, VVhkUd, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCc3G0(self, path, VVFqvg=BF(self.VVdamT, VVhkUd), curRowNum=rowNum)
  else    : FFvsvw(self, path)
 def VVdamT(self, VVhkUd, fileChanged):
  if fileChanged:
   VVhkUd.cancel()
 def VVUUVH(self, title):
  curChName = self.VVhkUd.VVxwcf(1)
  FFuRfO(self, BF(self.VVYQZk, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVYQZk(self, title, name):
  if name:
   VVy2ge, err = CCIdtv.VVu18q(self, CCIdtv.VV17og, VVadNQ=False, VVWj86=False)
   list = []
   if VVy2ge:
    name = self.VV51yv(name)
    ratio = "1"
    for item in VVy2ge:
     if name in item[0].lower():
      list.append((item[0], FFv6HB(item[2]), item[3], ratio))
   if list : self.VVRnfP(list, title)
   else : FF9Njt(self, "Not found:\n\n%s" % name, title=title)
 def VVioKu(self, title):
  curChName = self.VVhkUd.VVxwcf(1)
  self.session.open(CC1jbq, barTheme=CC1jbq.VVlB2I
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVeOHw
      , VVFqvg = BF(self.VV7iJ7, title, curChName))
 def VVeOHw(self, VVdu90):
  curChName = self.VVhkUd.VVxwcf(1)
  VVy2ge, err = CCIdtv.VVu18q(self, CCIdtv.VVbDDC, VVadNQ=False, VVWj86=False)
  if not VVy2ge or not VVdu90 or VVdu90.isCancelled:
   return
  VVdu90.VVeIVc = []
  VVdu90.VV7hIf(len(VVy2ge))
  curCh = self.VV51yv(curChName)
  for refCode in VVy2ge:
   chName, sat, inDB = VVy2ge.get(refCode, ("", "", 0))
   ratio = CC3hRa.VVydpe(chName.lower(), curCh)
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVRbmv(1, True)
   if VVdu90 and ratio > 50:
    VVdu90.VVeIVc.append((chName, FFv6HB(sat), refCode.replace("_", ":"), str(ratio)))
 def VV7iJ7(self, title, curChName, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if VVeIVc: self.VVRnfP(VVeIVc, title)
  elif VVegYv: FF9Njt(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVRnfP(self, VV796F, title):
  curChName = self.VVhkUd.VVxwcf(1)
  VVLpZE = self.VVhkUd.VVxwcf(4)
  curUrl  = self.VVhkUd.VVxwcf(5)
  VV796F.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVOPmD  = ("Share Sat/C/T Ref.", BF(self.VVswEe, title, curChName, VVLpZE, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVRdqN="#0a00112B", VVkSGg="#0a001126", VVTJDG="#0a001126", VVChAx="#00000000")
 def VVswEe(self, newtitle, curChName, VVLpZE, curUrl, VVhkUd, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVLpZE, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFfbEx(self.VVhkUd, BF(FFVvl9, self.VVhkUd, BF(self.VV89n6, VVhkUd, data)), ques, title=newtitle, VVAbek=True)
 def VV89n6(self, VVhkUd, data):
  VVhkUd.cancel()
  title, curChName, VVLpZE, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVLpZE = VVLpZE.strip()
  newRefCode = newRefCode.strip()
  if not VVLpZE.endswith(":") : VVLpZE += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVLpZE, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVLpZE + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CC3ZOl.VVYQhO():
    txt = FFXk75(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFURke()
    newRow = []
    for i in range(6):
     newRow.append(self.VVhkUd.VVxwcf(i))
    newRow[4] = newRefCode
    done = self.VVhkUd.VVTXUN(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFciRl(BF(FFmMPS , self, resTxt, title=title))
  elif resErr: FFciRl(BF(FF9Njt, self, resErr, title=title))
 def VVyO5V(self, VVmNef, path, VVhkUd, title, txt, colList):
  self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VV6w4v, VVhkUd)
      , VVFqvg = BF(self.VVOkle, VVmNef, path, VVhkUd))
 def VV6w4v(self, VVhkUd, VVdu90):
  VVdu90.VV7hIf(VVhkUd.VVA2PV())
  VVdu90.VVeIVc = []
  for row in VVhkUd.VVNCJx():
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVRbmv(1, True)
   qUrl = self.VV0KOI(self.VVaRCh, row[6])
   txt, err = self.VVxuE9(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVq4yM(item, "auth") == "0":
       VVdu90.VVeIVc.append(qUrl)
    except:
     pass
 def VVOkle(self, VVmNef, path, VVhkUd, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if VVegYv:
   list = VVeIVc
   title = "Authorized Servers"
   if list:
    totChk = VVhkUd.VVA2PV()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFKX94()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVaEsz(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF0D7j(str(totAuth), VVRTFm)
     txt += "%s\n\n%s"    %  (FF0D7j("Result File:", VVPr8g), newPath)
     FFEso0(self, txt, title=title)
     VVhkUd.close()
     VVmNef.close()
    else:
     FFmMPS(self, "All URLs are authorized.", title=title)
   else:
    FF9Njt(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVxuE9(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVpXry(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVakT8(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCr5ME.VVbcLX()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VV3v12(decodedUrl):
  return CC3ZOl.VVakT8(decodedUrl, justRetDotExt=True)
 def VV0KOI(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVpXry(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVaRCh   : return "%s"            % url
  elif mode == self.VVjzKg   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVOLum   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV70Qz  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVHp0c  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVt4kd : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV7Kdc   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVIgU3    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVD8FZ  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVr81F : return "%s&action=get_live_streams"      % url
  elif mode == self.VVyfRH  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVq4yM(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFaLO4(int(val))
    elif is_base64 : val = FFRlnq(val)
    elif isToHHMMSS : val = FFnZVI(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVUuyf(self, title, path):
  if fileExists(path):
   enc = CCDQtT.VVvetn(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CC3ZOl.VVnr6E(line)
     if qUrl:
      break
   if qUrl : self.VViicr(title, qUrl)
   else : FF9Njt(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF9Njt(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVuFVT(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CC3ZOl.VVkdjp(self)
  if qUrl or "chCode" in iptvRef:
   p = CCLRZv()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVN0zr(iptvRef)
   if valid:
    self.VVwI9O(self, host, mac)
    return
   elif qUrl:
    FFVvl9(self, BF(self.VViicr, title, qUrl), title="Checking Server ...")
    return
  FF9Njt(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVkdjp(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF)
  qUrl = CC3ZOl.VVnr6E(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVnr6E(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VViicr(self, title, url):
  self.curUrl = url
  self.VVZ5pQData = {}
  qUrl = self.VV0KOI(self.VVaRCh, url)
  txt, err = self.VVxuE9(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVZ5pQData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVZ5pQData["username"    ] = self.VVq4yM(item, "username"        )
    self.VVZ5pQData["password"    ] = self.VVq4yM(item, "password"        )
    self.VVZ5pQData["message"    ] = self.VVq4yM(item, "message"        )
    self.VVZ5pQData["auth"     ] = self.VVq4yM(item, "auth"         )
    self.VVZ5pQData["status"    ] = self.VVq4yM(item, "status"        )
    self.VVZ5pQData["exp_date"    ] = self.VVq4yM(item, "exp_date"    , isDate=True )
    self.VVZ5pQData["is_trial"    ] = self.VVq4yM(item, "is_trial"        )
    self.VVZ5pQData["active_cons"   ] = self.VVq4yM(item, "active_cons"       )
    self.VVZ5pQData["created_at"   ] = self.VVq4yM(item, "created_at"   , isDate=True )
    self.VVZ5pQData["max_connections"  ] = self.VVq4yM(item, "max_connections"      )
    self.VVZ5pQData["allowed_output_formats"] = self.VVq4yM(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVZ5pQData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVZ5pQData["url"    ] = self.VVq4yM(item, "url"        )
    self.VVZ5pQData["port"    ] = self.VVq4yM(item, "port"        )
    self.VVZ5pQData["https_port"  ] = self.VVq4yM(item, "https_port"      )
    self.VVZ5pQData["server_protocol" ] = self.VVq4yM(item, "server_protocol"     )
    self.VVZ5pQData["rtmp_port"   ] = self.VVq4yM(item, "rtmp_port"       )
    self.VVZ5pQData["timezone"   ] = self.VVq4yM(item, "timezone"       )
    self.VVZ5pQData["timestamp_now"  ] = self.VVq4yM(item, "timestamp_now"  , isDate=True )
    self.VVZ5pQData["time_now"   ] = self.VVq4yM(item, "time_now"       )
    VVutlQ  = self.VVmCIy(True)
    VVnFDy = self.VVyHYe
    VVRIxl = self.VVZfjY
    VVuLNH = ("Home Menu", FF9KFt)
    VVMTOL= ("Add to Menu", BF(CC3ZOl.VVJyHj, self, False, self.VVZ5pQData["playListURL"]))
    VVmhL9 = ("Bookmark Server", BF(CC3ZOl.VVD91C, self, False, self.VVZ5pQData["playListURL"]))
    FFre61(self, None, title="IPTV Server Resources", VVutlQ=VVutlQ, VVnFDy=VVnFDy, VVRIxl=VVRIxl, VVuLNH=VVuLNH, VVMTOL=VVMTOL, VVmhL9=VVmhL9)
   else:
    err = "Could not get data from server !"
  if err:
   FF9Njt(self, err, title=title)
  FFhSFw(self)
 def VVyHYe(self, item=None):
  if item:
   VVG7pv, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFVvl9(VVG7pv, BF(self.VVfHkT, self.VVjzKg  , title=title), title=wTxt)
   elif ref == "vod"   : FFVvl9(VVG7pv, BF(self.VVfHkT, self.VVOLum  , title=title), title=wTxt)
   elif ref == "series"  : FFVvl9(VVG7pv, BF(self.VVfHkT, self.VV70Qz , title=title), title=wTxt)
   elif ref == "catchup"  : FFVvl9(VVG7pv, BF(self.VVfHkT, self.VVHp0c , title=title), title=wTxt)
   elif ref == "accountInfo" : FFVvl9(VVG7pv, BF(self.VVWiwu           , title=title), title=wTxt)
 def VVZfjY(self, VVG7pv, txt, ref, ndx):
  FFVvl9(VVG7pv, self.VVZQM0)
 def VVZQM0(self):
  txt = self.curUrl
  if VVWEgS:
   ver, err = self.VVMRrM(self.VV93yC())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVQ4dj
   txt += "PHP\t: %s\n"  % self.VVRqws
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVKPs9, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFEso0(self, txt, title="Current Server URL")
 def VVWiwu(self, title):
  rows = []
  for key, val in self.VVZ5pQData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVhbEj
   else:
    num, part = "1", self.VVeTsN
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVRsW0  = ("Home Menu", FF9KFt, [])
  VVDle6  = None
  if VVWEgS:
   VVDle6 = ("Get JS" , BF(self.VVZK6v, "/".join(self.VVZ5pQData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFvfpt(self, None, title=title, width=1200, header=header, VVUel6=rows, VVFNzW=widths, VVH0vt=26, VVRsW0=VVRsW0, VVDle6=VVDle6, VVRdqN="#0a00292B", VVkSGg="#0a002126", VVTJDG="#0a002126", VVChAx="#00000000", searchCol=2)
 def VV4ImK(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VV7Kdc, self.VVyfRH):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVq4yM(item, "num"         )
      name     = self.VVq4yM(item, "name"        )
      stream_id    = self.VVq4yM(item, "stream_id"       )
      stream_icon    = self.VVq4yM(item, "stream_icon"       )
      epg_channel_id   = self.VVq4yM(item, "epg_channel_id"      )
      added     = self.VVq4yM(item, "added"    , isDate=True )
      is_adult    = self.VVq4yM(item, "is_adult"       )
      category_id    = self.VVq4yM(item, "category_id"       )
      tv_archive    = self.VVq4yM(item, "tv_archive"       )
      direct_source   = self.VVq4yM(item, "direct_source"      )
      tv_archive_duration  = self.VVq4yM(item, "tv_archive_duration"     )
      name = self.VVVZZx(name, is_adult)
      if name:
       if mode == self.VV7Kdc or mode == self.VVyfRH and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVIgU3:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVq4yM(item, "num"         )
      name    = self.VVq4yM(item, "name"        )
      stream_id   = self.VVq4yM(item, "stream_id"       )
      stream_icon   = self.VVq4yM(item, "stream_icon"       )
      added    = self.VVq4yM(item, "added"    , isDate=True )
      is_adult   = self.VVq4yM(item, "is_adult"       )
      category_id   = self.VVq4yM(item, "category_id"       )
      container_extension = self.VVq4yM(item, "container_extension"     ) or "mp4"
      name = self.VVVZZx(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVD8FZ:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVq4yM(item, "num"        )
      name    = self.VVq4yM(item, "name"       )
      series_id   = self.VVq4yM(item, "series_id"      )
      cover    = self.VVq4yM(item, "cover"       )
      genre    = self.VVq4yM(item, "genre"       )
      episode_run_time = self.VVq4yM(item, "episode_run_time"    )
      category_id   = self.VVq4yM(item, "category_id"      )
      container_extension = self.VVq4yM(item, "container_extension"    ) or "mp4"
      name = self.VVVZZx(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVfHkT(self, mode, title):
  cList, err = self.VVSEee(mode)
  if cList and mode == self.VVHp0c:
   cList = self.VVKp4J(cList)
  if err:
   FF9Njt(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo(mode)
   mName = self.VVnULp(mode)
   if   mode == self.VVjzKg  : fMode = self.VV7Kdc
   elif mode == self.VVOLum  : fMode = self.VVIgU3
   elif mode == self.VV70Qz : fMode = self.VVD8FZ
   elif mode == self.VVHp0c : fMode = self.VVyfRH
   if mode == self.VVHp0c:
    VVPOPD = None
    VVUum8 = None
   else:
    VVPOPD = ("Find in %s" % mName , BF(self.VVUz9a, fMode, True) , [])
    VVUum8 = ("Find in Selected" , BF(self.VVUz9a, fMode, False) , [])
   VVOPmD   = ("Show List"   , BF(self.VVaqCQ, mode)  , [])
   VVRsW0  = ("Home Menu"   , FF9KFt         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFvfpt(self, None, title=title, width=1200, header=header, VVUel6=cList, VVFNzW=widths, VVH0vt=30, VVRsW0=VVRsW0, VVPOPD=VVPOPD, VVUum8=VVUum8, VVOPmD=VVOPmD, VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVTJDG, VVChAx=VVChAx, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF9Njt(self, "No list from server !", title=title)
  FFhSFw(self)
 def VVSEee(self, mode):
  qUrl  = self.VV0KOI(mode, self.VVZ5pQData["playListURL"])
  txt, err = self.VVxuE9(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVq4yM(item, "category_id"  )
     category_name = self.VVq4yM(item, "category_name" )
     parent_id  = self.VVq4yM(item, "parent_id"  )
     category_name = self.VVAW8u(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVKp4J(self, catList):
  mode  = self.VVyfRH
  qUrl  = self.VV0KOI(mode, self.VVZ5pQData["playListURL"])
  txt, err = self.VVxuE9(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV4ImK(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVaqCQ(self, mode, VVhkUd, title, txt, colList):
  title = colList[1]
  FFVvl9(VVhkUd, BF(self.VV2fFi, mode, VVhkUd, title, txt, colList), title="Downloading ...")
 def VV2fFi(self, mode, VVhkUd, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVnULp(mode) + " : "+ bName
  if   mode == self.VVjzKg  : mode = self.VV7Kdc
  elif mode == self.VVOLum  : mode = self.VVIgU3
  elif mode == self.VV70Qz : mode = self.VVD8FZ
  elif mode == self.VVHp0c : mode = self.VVyfRH
  qUrl  = self.VV0KOI(mode, self.VVZ5pQData["playListURL"], catID)
  txt, err = self.VVxuE9(qUrl)
  list  = []
  if not err and mode in (self.VV7Kdc, self.VVIgU3, self.VVD8FZ, self.VVyfRH):
   list, err = self.VV4ImK(mode, txt)
  if err:
   FF9Njt(self, err, title=title)
  elif list:
   VVRsW0  = ("Home Menu"   , FF9KFt            , [])
   if mode in (self.VV7Kdc, self.VVyfRH):
    VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo(mode)
    VV5qt4 = (""     , BF(self.VVVYbS, mode)      , [])
    VVDle6 = ("Download Options" , BF(self.VVTa6H, mode, "", "")   , [])
    VVPOPD = ("Options"   , BF(self.VVFB4x, "lv", mode, bName)   , [])
    VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, False)     , [])
    if mode == self.VV7Kdc:
     VVOPmD = ("Play"    , BF(self.VVfNY1, mode)       , [])
    else:
     VVOPmD = ("Programs"   , BF(self.VVcbn9, mode, bName) , [])
   elif mode == self.VVIgU3:
    VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo(mode)
    VVOPmD  = ("Play"    , BF(self.VVfNY1, mode)       , [])
    VV5qt4 = (""     , BF(self.VVVYbS, mode)      , [])
    VVDle6 = ("Download Options" , BF(self.VVTa6H, mode, "v", "")   , [])
    VVPOPD = ("Options"   , BF(self.VVFB4x, "v", mode, bName)   , [])
    VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, False)     , [])
   elif mode == self.VVD8FZ:
    VVRdqN, VVkSGg, VVTJDG, VVChAx = self.VVyrBo("series2")
    VVOPmD  = ("Show Seasons"  , BF(self.VVPXQg, mode)       , [])
    VV5qt4 = (""     , BF(self.VV0UFZ, mode)     , [])
    VVDle6 = None
    VVPOPD = None
    VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, True)      , [])
   header, widths, VVxWCE = self.VVKK9f(mode)
   FFvfpt(self, None, title=title, header=header, VVUel6=list, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindIptv, VV5qt4=VV5qt4, VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVTJDG, VVChAx=VVChAx, VVNWl5=True, searchCol=1)
  else:
   FF9Njt(self, "No Channels found !", title=title)
  FFhSFw(self)
 def VVKK9f(self, mode):
  if mode in (self.VV7Kdc, self.VVyfRH):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVxWCE  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVIgU3:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVxWCE  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVD8FZ:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVxWCE  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVxWCE
 def VVcbn9(self, mode, bName, VVhkUd, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVZ5pQData["playListURL"]
  ok_fnc  = BF(self.VV86sb, hostUrl, chName, catId, streamId)
  FFVvl9(VVhkUd, BF(CC3ZOl.VVVk7T, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV86sb(self, chUrl, chName, catId, streamId, VVhkUd, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC3ZOl.VVpXry(chUrl)
   chNum = "333"
   refCode = CC3ZOl.VV2ZyA(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFlpKW(self, chUrl, VVeuyP=False)
   CCGzpp.VVfWLm(self.session)
  else:
   FF9Njt(self, "Incorrect Timestamp", pTitle)
 def VVPXQg(self, mode, VVhkUd, title, txt, colList):
  title = colList[1]
  FFVvl9(VVhkUd, BF(self.VVczzT, mode, VVhkUd, title, txt, colList), title="Downloading ...")
 def VVczzT(self, mode, VVhkUd, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV0KOI(self.VVt4kd, self.VVZ5pQData["playListURL"], series_id)
  txt, err = self.VVxuE9(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVq4yM(tDict["info"], "name"   )
      category_id = self.VVq4yM(tDict["info"], "category_id" )
      icon  = self.VVq4yM(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVq4yM(EP, "id"     )
        episode_num   = self.VVq4yM(EP, "episode_num"   )
        epTitle    = self.VVq4yM(EP, "title"     )
        container_extension = self.VVq4yM(EP, "container_extension" )
        seasonNum   = self.VVq4yM(EP, "season"    )
        epTitle = self.VVVZZx(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF9Njt(self, err, title=title)
  elif list:
   VVRsW0 = ("Home Menu"   , FF9KFt          , [])
   VVDle6 = ("Download Options" , BF(self.VVTa6H, mode, "s", title), [])
   VVPOPD = ("Options"   , BF(self.VVFB4x, "s", mode, title) , [])
   VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, False)   , [])
   VV5qt4 = (""     , BF(self.VVVYbS, mode)    , [])
   VVOPmD  = ("Play"    , BF(self.VVfNY1, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVxWCE  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFvfpt(self, None, title=title, header=header, VVUel6=list, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVRsW0=VVRsW0, VVDle6=VVDle6, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVPOPD=VVPOPD, VVUum8=VVUum8, lastFindConfigObj=CFG.lastFindIptv, VVRdqN="#0a00292B", VVkSGg="#0a002126", VVTJDG="#0a002126", VVChAx="#00000000")
  else:
   FF9Njt(self, "No Channels found !", title=title)
  FFhSFw(self)
 def VVUz9a(self, mode, isAll, VVhkUd, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVutlQ = []
  VVutlQ.append(("Keyboard"  , "manualEntry"))
  VVutlQ.append(("From Filter" , "fromFilter"))
  FFre61(self, BF(self.VVOJys, VVhkUd, mode, onlyCatID), title="Input Type", VVutlQ=VVutlQ, width=400)
 def VVOJys(self, VVhkUd, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFuRfO(self, BF(self.VV9KGz, VVhkUd, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCtamE(self)
    filterObj.VVKEz5(BF(self.VV9KGz, VVhkUd, mode, onlyCatID))
 def VV9KGz(self, VVhkUd, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FF3Ual(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCtamE.VVy75H(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FF9Njt(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FF9Njt(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVecfR(words):
      FF9Njt(self, self.VVL5YU(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CC1jbq, barTheme=CC1jbq.VVlB2I
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVO9aF, VVhkUd, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVFqvg = BF(self.VVOvl4, mode, toFind, title))
   if not words:
    FFhSFw(VVhkUd, "Nothing to find !", 1500)
 def VVO9aF(self, VVhkUd, mode, onlyCatID, title, words, toFind, asPrefix, VVdu90):
  VVdu90.VV7hIf(VVhkUd.VVc8ws() if onlyCatID is None else 1)
  VVdu90.VVeIVc = []
  for row in VVhkUd.VVNCJx():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVRbmv(1)
   VVdu90.VVvM6s(catName)
   qUrl  = self.VV0KOI(mode, self.VVZ5pQData["playListURL"], catID)
   txt, err = self.VVxuE9(qUrl)
   if not err:
    tList, err = self.VV4ImK(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVVZZx(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVdu90 or VVdu90.isCancelled:
        return
       VVdu90.VVeIVc.append(item)
       VVdu90.VVvM6s(catName)
 def VVOvl4(self, mode, toFind, title, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if VVeIVc:
   title = self.VVl0du(mode, toFind)
   if mode == self.VV7Kdc or mode == self.VVIgU3:
    if mode == self.VVIgU3 : typ = "v"
    else          : typ = ""
    bName   = CC3ZOl.VVBr0k(toFind)
    VVOPmD  = ("Play"     , BF(self.VVfNY1, mode)     , [])
    VVDle6 = ("Download Options" , BF(self.VVTa6H, mode, typ, "") , [])
    VVPOPD = ("Options"   , BF(self.VVFB4x, "fnd", mode, bName), [])
    VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, False)   , [])
    VV5qt4 = (""     , BF(self.VVVYbS, mode)    , [])
   elif mode == self.VVD8FZ:
    VVOPmD  = ("Show Seasons"  , BF(self.VVPXQg, mode)     , [])
    VVPOPD = None
    VVDle6 = None
    VVUum8 = ("Posters Mode"  , BF(self.VVAeQV, mode, True)    , [])
    VV5qt4 = (""     , BF(self.VV0UFZ, mode)   , [])
   VVRsW0  = ("Home Menu"   , FF9KFt          , [])
   header, widths, VVxWCE = self.VVKK9f(mode)
   VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VVeIVc, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, VV5qt4=VV5qt4, VVRdqN="#0a00292B", VVkSGg="#0a002126", VVTJDG="#0a002126", VVChAx="#00000000", VVNWl5=True, searchCol=1)
   if not VVegYv:
    FFhSFw(VVhkUd, "Stopped" , 1000)
  else:
   if VVegYv:
    FF9Njt(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VV56wc(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VV7Kdc, self.VVyfRH):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVIgU3:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFLAHl(chName)
  url = self.VVZ5pQData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVpXry(url)
  refCode = self.VV2ZyA(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVVYbS(self, mode, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVZ9Qy, mode, VVhkUd, title, txt, colList))
 def VVZ9Qy(self, mode, VVhkUd, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV56wc(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FF0gQ0(self, fncMode=CCY1HC.VVG9Cu, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VV0UFZ(self, mode, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VV5C4s, mode, VVhkUd, title, txt, colList))
 def VV5C4s(self, mode, VVhkUd, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FF0gQ0(self, fncMode=CCY1HC.VVQQZu, chName=name, text=txt, picUrl=Cover)
 def VVAeQV(self, mode, isSerNames, VVhkUd, title, txt, colList):
  if   mode in ("itv"  , CC3ZOl.VV7Kdc, CC3ZOl.VVyfRH): category = "live"
  elif mode in ("vod"  , CC3ZOl.VVIgU3 )          : category = "vod"
  elif mode in ("series" , CC3ZOl.VVD8FZ)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VV7Kdc : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVyfRH : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVIgU3  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVD8FZ : picCol, descCol, descTxt = 5, 0, "Season"
  FFVvl9(VVhkUd, BF(self.session.open, CCZQEI, VVhkUd, category, nameCol, picCol, descCol, descTxt))
 def VVTa6H(self, mode, typ, seriesName, VVhkUd, title, txt, colList):
  VVutlQ = []
  isMulti = VVhkUd.VVs7XH
  tot  = VVhkUd.VVznW9()
  if isMulti:
   if tot < 1:
    FFhSFw(VVhkUd, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVutlQ.append(("Download %s PIcon%s" % (name, FFCMcT(tot)), "dnldPicons" ))
  if typ:
   VVutlQ.append(VVJKCZ)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVutlQ.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVutlQ.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVutlQ.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCkpqq.VVkLR8():
    VVutlQ.append(VVJKCZ)
    VVutlQ.append(("Download Manager"      , "dload_stat" ))
  FFre61(self, BF(self.VVJ5Do, VVhkUd, mode, typ, seriesName, colList), title="Download Options", VVutlQ=VVutlQ)
 def VVJ5Do(self, VVhkUd, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV5eg8(VVhkUd, mode)
   elif item == "dnldSel"  : self.VVJqrX(VVhkUd, mode, typ, colList, True)
   elif item == "addSel"  : self.VVJqrX(VVhkUd, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV35Mb(VVhkUd, mode, typ, seriesName)
   elif item == "dload_stat" : CCkpqq.VV4eHX(self, VVhkUd)
 def VVJqrX(self, VVhkUd, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVeg3j(mode, typ, colList)
  if startDnld:
   CCkpqq.VVriiW(self, decodedUrl)
  else:
   self.VVgIQ0(VVhkUd, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV35Mb(self, VVhkUd, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVhkUd.VVNCJx():
   chName, decodedUrl = self.VVeg3j(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVgIQ0(VVhkUd, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVgIQ0(self, VVhkUd, title, chName, decodedUrl_list, startDnld):
  FFfbEx(self, BF(self.VViLA1, VVhkUd, decodedUrl_list, startDnld), chName, title=title)
 def VViLA1(self, VVhkUd, decodedUrl_list, startDnld):
  added, skipped = CCkpqq.VVMyZ8(decodedUrl_list)
  FFhSFw(VVhkUd, "Added", 1000)
 def VVeg3j(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VV56wc(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWdYd(mode, colList)
   refCode, chUrl = self.VV3HXs(self.VVQ4dj, self.VV6daG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFYUp6(chUrl)
  return chName, decodedUrl
 def VV5eg8(self, VVhkUd, mode):
  if FFVjaP("ffmpeg"):
   self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVbCKw, VVhkUd, mode)
       , VVFqvg = self.VVzz7H)
  else:
   FFfbEx(self, BF(CC3ZOl.VVHnAe, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVzz7H(self, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVeIVc["proces"], VVeIVc["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVeIVc["ok"], VVeIVc["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVeIVc["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVeIVc["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVeIVc["badURL"]
  txt += "Download Failure\t: %d\n"   % VVeIVc["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVeIVc["path"]
  if not VVegYv  : color = "#11402000"
  elif VVeIVc["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVeIVc["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVeIVc["err"], txt)
  title = "PIcons Download Result"
  if not VVegYv:
   title += "  (cancelled)"
  FFEso0(self, txt, title=title, VVTJDG=color)
 def VVbCKw(self, VVhkUd, mode, VVdu90):
  isMulti = VVhkUd.VVs7XH
  if isMulti : totRows = VVhkUd.VVznW9()
  else  : totRows = VVhkUd.VVc8ws()
  VVdu90.VV7hIf(totRows)
  VVdu90.VV1eIu(0)
  counter     = VVdu90.counter
  maxValue    = VVdu90.maxValue
  pPath     = CC3hRa.VV3CCT()
  VVdu90.VVeIVc = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVhkUd.VVNCJx()):
    if VVdu90.isCancelled:
     break
    if not isMulti or VVhkUd.VVrdPF(rowNum):
     VVdu90.VVeIVc["proces"] += 1
     VVdu90.VVRbmv(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWdYd(mode, row)
      refCode = CC3ZOl.VV2ZyA(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVd1kS(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VV56wc(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVdu90.VVeIVc["attempt"] += 1
       path, err = FFAqj4(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVdu90:
         VVdu90.VVeIVc["ok"] += 1
         VVdu90.VV1eIu(VVdu90.VVeIVc["ok"])
        if FFrMJ0(path) > 0:
         cmd = CCY1HC.VVlIL4(path)
         cmd += FFYhY6("mv -f '%s' '%s'" % (path, pPath))
         FF2ufE(cmd)
        else:
         if VVdu90:
          VVdu90.VVeIVc["size0"] += 1
         FFEUy9(path)
       elif err:
        if VVdu90:
         VVdu90.VVeIVc["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVdu90:
          VVdu90.VVeIVc["err"] = err.title()
         break
      else:
       if VVdu90:
        VVdu90.VVeIVc["exist"] += 1
     else:
      if VVdu90:
       VVdu90.VVeIVc["badURL"] += 1
  except:
   pass
 def VVqdKP(self):
  title = "Download PIcons for Current Bouquet"
  if FFVjaP("ffmpeg"):
   self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
       , titlePrefix = ""
       , fncToRun  = self.VVNOPE
       , VVFqvg = BF(self.VVgQ15, title))
  else:
   FFfbEx(self, BF(CC3ZOl.VVHnAe, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVNOPE(self, VVdu90):
  bName = CC0axI.VVdPHV()
  pPath = CC3hRa.VV3CCT()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVdu90.VVeIVc = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CC0axI.VVttck()
  if not VVdu90 or VVdu90.isCancelled:
   return
  if not services or len(services) == 0:
   VVdu90.VVeIVc = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVdu90.VV7hIf(totCh)
  VVdu90.VV1eIu(0)
  for serv in services:
   if not VVdu90 or VVdu90.isCancelled:
    return
   VVdu90.VVeIVc = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVdu90.VVRbmv(1)
   VVdu90.VV1eIu(totPic)
   fullRef  = serv[0]
   if FF4MQW(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFYUp6(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCLRZv.VVMalC(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CC3ZOl.VVakT8(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC3ZOl.VVxuE9(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCY1HC.VVT3u9(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFAqj4(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVdu90:
     VVdu90.VV1eIu(totPic)
    if FFrMJ0(path) > 0:
     cmd = CCY1HC.VVlIL4(path)
     cmd += FFYhY6("mv -f '%s' '%s'" % (path, pPath))
     FF2ufE(cmd)
     totPicOK += 1
    else:
     totSize0
     FFEUy9(path)
  if VVdu90:
   VVdu90.VVeIVc = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVgQ15(self, title, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVeIVc
  if err:
   FF9Njt(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FF0D7j(str(totExist)  , VVUS1a)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF0D7j(str(totNotIptv)  , VVUS1a)
    if totServErr : txt += "Server Errors\t: %s\n" % FF0D7j(str(totServErr) + t1, VVUS1a)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FF0D7j(str(totParseErr) , VVUS1a)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FF0D7j(str(totInvServ)  , VVUS1a)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FF0D7j(str(totInvPicUrl) , VVUS1a)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FF0D7j(str(totSize0)  , VVUS1a)
   if not VVegYv:
    title += "  (stopped)"
   FFEso0(self, txt, title=title)
 @staticmethod
 def VVHnAe(SELF):
  cmd = FFciUY(VVtZiS, "ffmpeg")
  if cmd : FF9pl1(SELF, cmd, title="Installing FFmpeg")
  else : FFdRu7(SELF)
 @staticmethod
 def VVHFOc(SELF):
  SELF.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa
      , titlePrefix = ""
      , fncToRun  = CC3ZOl.VVfLC3
      , VVFqvg = BF(CC3ZOl.VVGui8, SELF))
 @staticmethod
 def VVfLC3(VVdu90):
  bName = CC0axI.VVdPHV()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVdu90.VVeIVc = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CC0axI.VVttck()
  if not VVdu90 or VVdu90.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVdu90.VV7hIf(totCh)
   for serv in services:
    if not VVdu90 or VVdu90.isCancelled:
     return
    VVdu90.VVRbmv(1)
    fullRef = serv[0]
    if FF4MQW(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFYUp6(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCLRZv.VVOHBD(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CC3ZOl.VVakT8(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CC3ZOl.VVRPis(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVdu90:
      VVdu90.VVxpa1(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCvK6a.VVKaCW(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVdu90:
     VVdu90.VVeIVc = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVdu90.VVeIVc = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVGui8(SELF, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVeIVc
  title = "IPTV EPG Import"
  if err:
   FF9Njt(SELF, err, title=title)
  else:
   if VVegYv and totEpgOK > 0:
    CCvK6a.VVyfRr()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF0D7j(str(totNotIptv), VVUS1a)
    if totServErr : txt += "Server Errors\t: %s\n" % FF0D7j(str(totServErr) + t1, VVUS1a)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF0D7j(str(totInv), VVUS1a)
   if not VVegYv:
    title += "  (stopped)"
   FFEso0(SELF, txt, title=title)
 @staticmethod
 def VVRPis(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC3ZOl.VVpXry(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC3ZOl.VVxuE9(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC3ZOl.VVq4yM(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CC3ZOl.VVq4yM(item, "lang"        ).upper()
    now_playing   = CC3ZOl.VVq4yM(item, "now_playing"      )
    start    = CC3ZOl.VVq4yM(item, "start"        )
    start_timestamp  = CC3ZOl.VVq4yM(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC3ZOl.VVq4yM(item, "start_timestamp"     )
    stop_timestamp  = CC3ZOl.VVq4yM(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC3ZOl.VVq4yM(item, "stop_timestamp"      )
    tTitle    = CC3ZOl.VVq4yM(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV2ZyA(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC3ZOl.VVelLA(catID, MAX_4b)
  TSID = CC3ZOl.VVelLA(chNum, MAX_4b)
  ONID = CC3ZOl.VVelLA(chNum, MAX_4b)
  NS  = CC3ZOl.VVelLA(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVelLA(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVBr0k(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVyrBo(mode):
  if   mode in ("itv"  , CC3ZOl.VVjzKg)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC3ZOl.VVOLum)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC3ZOl.VV70Qz) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC3ZOl.VVHp0c) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC3ZOl.VVyfRH    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVC6IY(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVpkJd:
   excl = FFNOMj(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FF9Njt(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFlfx8('find %s %s %s' % (path, excl, par))
  if files:
   err = CCLSXF.VVTvbh(files)
   if err : FF9Njt(self, err + FF0D7j('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVPr8g))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FF9Njt(self, err)
  return []
 @staticmethod
 def VVWZc1():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFqvjY(path)
  return "/"
 @staticmethod
 def VVVk7T(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CC3ZOl.VVRPis(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FF9Njt(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVRdqN, VVkSGg, VVTJDG, VVChAx = CC3ZOl.VVyrBo("")
   VVRsW0 = ("Home Menu" , FF9KFt, [])
   VVOPmD  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVxWCE  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFvfpt(SELF, None, title="Programs for : " + chName, header=header, VVUel6=pList, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=24, VVOPmD=VVOPmD, VVRsW0=VVRsW0, VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVTJDG, VVChAx=VVChAx)
  else:
   FF9Njt(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVqtvl(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVJyHj(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFfbEx(self, BF(self.VVThom, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FF3Ual(confItem, line)
   FFmMPS(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVThom(self, title, confItem):
  FF3Ual(confItem, "")
  FFmMPS(self, "Removed from IPTV Menu.", title=title)
 def VVontB(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVwI9O(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFVvl9(self, BF(self.VViicr, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FF9Njt(self, "Incorrect server data !")
 @staticmethod
 def VVD91C(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC3ZOl.VVWZc1()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF9Njt(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFmMPS(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF9Njt(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVFB4x(self, source, mode, curBName, VVhkUd, title, txt, colList):
  isMulti = VVhkUd.VVs7XH
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVhkUd.VVznW9()
   totTxt = "%d Service%s" % (tot, FFCMcT(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FF0D7j(totTxt, VVPr8g)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCoGI2(self, VVhkUd, addSep=False)
  thTxt = "Adding Services ..."
  VVutlQ, cbFncDict = [], None
  VVutlQ.append(VVJKCZ)
  if itemsOK:
   VVutlQ.append(("Add %s to New Bouquet : %s"    % (totTxt, FF0D7j(curBName , VVRTFm)), "addToCur1"))
   if curBName2: VVutlQ.append(("Add %s to New Bouquet : %s" % (totTxt, FF0D7j(curBName2, VVJTsP)) , "addToCur2"))
   VVutlQ.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFVvl9, mSel.VVhkUd, BF(self.VV93y7,source, mode, curBName , VVhkUd, title), title=thTxt)
      , "addToCur2": BF(FFVvl9, mSel.VVhkUd, BF(self.VV93y7,source, mode, curBName2, VVhkUd, title), title=thTxt)
      , "addToNew" : BF(self.VVMCwr, source, mode, curBName, VVhkUd, title)
      }
  else:
   VVutlQ.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVZZ7l(VVutlQ, cbFncDict, width=1400)
 def VV93y7(self, source, mode, curBName, VVhkUd, Title):
  chUrlLst = self.VVVJSG(source, mode, VVhkUd)
  CC0axI.VVbZpk(self, Title, curBName, "", chUrlLst)
 def VVMCwr(self, source, mode, curBName, VVhkUd, Title):
  picker = CC0axI(self, VVhkUd, Title, BF(self.VVVJSG, source, mode, VVhkUd), defBName=curBName)
 def VVVJSG(self, source, mode, VVhkUd):
  totChange = 0
  isMulti = VVhkUd.VVs7XH
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVhkUd.VVNCJx()):
   if not isMulti or VVhkUd.VVrdPF(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWdYd(mode, row)
     refCode, chUrl = self.VV3HXs(self.VVQ4dj, self.VV6daG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VV27tl(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VV56wc(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VV2oZz():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVXLzV():
  return sorted(tuple(CC3ZOl.VV2oZz()))
 @staticmethod
 def VVEEig(rt):
  return CC3ZOl.VV2oZz().get(str(rt), "")
 @staticmethod
 def VVFHkL(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CC3ZOl.VVEEig(span.group(1)) if span else ""
 @staticmethod
 def VV1BDv(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVq62G():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVutlQ = []
  for ndx, rt in enumerate(CC3ZOl.VVXLzV()):
   VVutlQ.append(FF47SM("%s\t... %s" % (CC3ZOl.VVEEig(rt), rt), rt, CC3ZOl.VV1BDv(rt), VVFWDt if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVutlQ.append(VVJKCZ)
  return VVutlQ
class CCvR68(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VV9fM0(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFiva8(self.frm, frmColor)
  FFiva8(self.bak, bakColor)
  FFiva8(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVhpZk(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFTJBw(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CChBHx(CCvR68):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCvR68.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VV5w00()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VVyU28,
  {
   "up" : self.VVDWrv   ,
   "down" : self.VV2Slw  ,
   "left" : self.VVY4Ig  ,
   "right" : self.VV85da  ,
   "next" : self.VV5D8z ,
   "last" : self.VVwMUP
  }, -1)
 def VV60nP(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VV9fM0(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VV2sSm()
  self["myPiconPtr"].hide()
 def VV0cPZ(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVDWrv(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVXm2i()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVbPsM()
 def VV2Slw(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVLD85()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVbPsM()
 def VVY4Ig(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVXm2i()
  else:
   self.curCol -= 1
   self.VVbPsM()
 def VV85da(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVLD85()
  else:
   self.curCol += 1
   self.VVbPsM()
 def VVwMUP(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVbPsM(oldPage != self.curPage)
 def VV5D8z(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVbPsM(oldPage != self.curPage)
 def VVLD85(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVbPsM(force)
 def VVXm2i(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVbPsM(force)
 def VVbPsM(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVRYcR = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVRYcR: self.curPage = VVRYcR
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVsaq1()
  self["myPiconPtr"].hide()
  self.VVhpZk(self.curPage + 1, self.totalPages)
  FFciRl(BF(self.VVDHOT, force or not oldPage == self.curPage, VVRYcR))
 def VVDHOT(self, force, VVRYcR):
  try:
   if force:
    self.VVIfwu()
   if self.curPage == VVRYcR:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVsaq1()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VV7wRM(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVbPsM(False if oldPage == self.curPage else True)
  else:
   FFhSFw(self, "Not found", 1000)
 def VV4PiE(self):
  self.VV7wRM(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VV5w00(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VV9c5O(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VV7oVJ, CCTwdG, defFG=fg, defBG=bg, onlyBG=True)
 def VV7oVJ(self, fg, bg):
  if self.colorCfg and bg:
   FF3Ual(self.colorCfg, bg)
   self.VV2sSm()
 def VV2sSm(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFiva8(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVICXO(self, lbl, txt, color=""):
  CChBHx.VVM70z(lbl, txt, color)
 @staticmethod
 def VVM70z(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVtlBV(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCZQEI(Screen, CChBHx):
 def __init__(self, session, VVhkUd, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFzoo9(VV8zMg, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVhkUd  = VVhkUd
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVUel6    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFk1xo(self, self.Title)
  CChBHx.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVUQHY, subPath)
  if not pathExists(self.pPath):
   FF2ufE("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVQHyQ    ,
   "cancel": self.close    ,
   "menu" : self.VVJnxe ,
   "info" : self.VVTuY7  ,
   "0"  : self.VV4PiE
  })
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  FFlx3W(self)
  self.VV60nP()
  self.VVupob()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVJnxe(self):
  chName, subj, desc, fName, picUrl = self.VVUel6[self.curIndex]
  VVutlQ = []
  VVutlQ.append(FF47SM("Show Selected Picture"        , "VV7H3I"  , fName))
  VVutlQ.append(FF47SM("Copy Selected Picture to Export-Directory"   , "VVOsv3" , fName))
  VVutlQ.append(FF47SM("Set Selected Picture as a Poster for a Local Media" , "VVfxRI", fName))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Cache details"       , "VVFwpy"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change Poster/Picon Transparency Color" , "VV9c5O" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Help (Keys)"        , "help"     ))
  FFre61(self, self.VVF8Ic, title=self.Title, VVutlQ=VVutlQ)
 def VVF8Ic(self, item=None):
  if item is not None:
   if   item == "VV7H3I"   : self.VV7H3I()
   elif item == "VVOsv3"   : self.VVOsv3()
   elif item == "VVfxRI"  : self.VVfxRI()
   elif item == "VVFwpy"  : FFVvl9(self, self.VVFwpy, title="Calculating ...")
   elif item == "VV9c5O": self.VV9c5O()
   elif item == "help"     : FF1D9G(self, "_help_servBr", "Server Browser (Keys)")
 def VVQHyQ(self):
  self.VVhkUd.VVfMAJ(self.curIndex)
  self.VVhkUd.VVbNjW()
 def VVTuY7(self):
  self.VVhkUd.VVfMAJ(self.curIndex)
  self.VVhkUd.VVUt6l()
 def VVupob(self):
  for colList in self.VVhkUd.VVNCJx():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVUel6.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVUel6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVhkUd.VVSWzf()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVbPsM(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1Gbt)
  except:
   self.timer.callback.append(self.VV1Gbt)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV2Hhw)
  self.myThread.start()
 def VV2Hhw(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVUel6):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFAqj4(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FF2ufE("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVUel6[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VV1Gbt(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VV8a8m + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVUel6[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVUel6[ndx] = (chName, subj, desc, fName, "")
     CChBHx.VVtlBV(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVIfwu(self):
  self.VV5w00()
  f1, f2 = self.VV0cPZ()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVUel6[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVICXO(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VV8pP1 + "iptv.png"
   CChBHx.VVtlBV(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVsaq1(self):
  chName, subj, desc, fName, picUrl = self.VVUel6[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV7H3I(self):
  chName, subj, desc, fName, picUrl = self.VVUel6[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCMQgO.VVR5E7(self, self.pPath + fName)
  else          : FFhSFw(self, "File not found", 1500)
 def VVOsv3(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVUel6[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FF2ufE("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFmMPS(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FF9Njt(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FF9Njt(self, "No Poster/PIcon found", title=title)
 def VVfxRI(self):
  self.session.openWithCallback(self.VVgrfJ, BF(CCLSXF, patternMode="movies", VVXhi5=CFG.MovieDownloadPath.getValue()))
 def VVgrfJ(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVUel6[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FF2ufE("cp -f '%s' '%s'" % (srcF, dstF)):
     FFmMPS(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FF9Njt(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CC1FQa.VVbwlq(dstF)
   else:
    FF9Njt(self, "No Poster/PIcon found", title=title)
 def VVFwpy(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVUQHY, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FF7jZM("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCLSXF.VVtnwF(size)
   txt += "%s\n    %s\n\n" % (FF0D7j(path, VVPr8g), size)
  mainPath = "%sPosters" % VVUQHY
  totFiles = FF7jZM("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFCMcT(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FF0D7j("Total space used by Posters/PIcons%s:" % totFTxt, VVRkew), CCLSXF.VVtnwF(totSize))
  mountPath = CCLSXF.VVzPhC(mainPath)
  if pathExists(mountPath):
   totSize  = CCLSXF.VVCzeu(mountPath)
   freeSize = CCLSXF.VVf7tK(mountPath)
   usedSize = CCLSXF.VVtnwF(totSize - freeSize)
   totSize  = CCLSXF.VVtnwF(totSize)
   freeSize = CCLSXF.VVtnwF(freeSize)
   txt += "%s\n" % SEP
   txt += FF0D7j("Media Space:\n", VVQrak)
   txt += "    Media Path\t: %s\n" % FF0D7j(mountPath, VVqWCE)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFEso0(self, txt, title="Cache Used Size", height=1000)
class CC1FQa(Screen, CChBHx):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFzoo9(VVwv41, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVUel6    = lst
  FFk1xo(self, self.Title)
  CChBHx.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVQHyQ    ,
   "cancel": self.close    ,
   "menu" : self.VVLRgg ,
   "info" : self.VVVldf  ,
   "0"  : self.VV4PiE
  })
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  FFlx3W(self)
  self.VV60nP()
  self.totalItems = len(self.VVUel6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVbPsM(True)
 def VVIfwu(self):
  self.VV5w00()
  f1, f2 = self.VV0cPZ()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVUel6[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VV8pP1 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVICXO(lbl, os.path.splitext(os.path.basename(path))[0])
   CChBHx.VVtlBV(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVDDkO(self):
  path, movie, poster = self.VVUel6[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVsaq1(self):
  path, poster = self.VVDDkO()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVLRgg(self):
  path, poster = self.VVDDkO()
  VVutlQ = []
  VVutlQ.append(("Go to movie ...", "VVtGEL"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(FF47SM("Show Poster"      , "VV7H3I" , poster))
  VVutlQ.append(FF47SM("Copy Poster to Export-Directory" , "VVOsv3", poster))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change Poster/Picon Transparency Color"  , "VV9c5O" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change Poster (from current movie path) ..." , "VVEYW61"  ))
  VVutlQ.append(("Change Poster (locate manually) ..."   , "VVEYW62"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Help (Keys)"         , "help"     ))
  FFre61(self, self.VVfYIz, title=self.Title, VVutlQ=VVutlQ)
 def VVfYIz(self, item=None):
  if item is not None:
   if   item == "VVtGEL"    : self.VVtGEL()
   elif item == "VVOsv3"    : self.VVOsv3()
   elif item == "VV7H3I"    : self.VV7H3I()
   elif item == "VV9c5O" : self.VV9c5O()
   elif item == "VVEYW61"  : self.VVEYW6()
   elif item == "VVEYW62"  : self.VVEYW6(True)
   elif item == "help"      : FF1D9G(self, "_help_movBr", "Movies Browser (Keys)")
 def VVtGEL(self):
  VV796F = []
  for ndx, item in enumerate(self.VVUel6):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VV796F.append((os.path.splitext(movie)[0], path, str(ndx)))
  VV796F.sort(key=lambda x: x[0].lower())
  VVOPmD = ("Select" , self.VVKnva, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFvfpt(self, None, title="Select Movie", width=1800, height=1000, header=header, VVUel6=VV796F, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, lastFindConfigObj=CFG.lastFindMovie)
 def VVKnva(self, VVhkUd, title, txt, colList):
  self.VV7wRM(int(colList[2].strip()))
  VVhkUd.cancel()
 def VVQHyQ(self):
  path, poster = self.VVDDkO()
  FFVvl9(self, BF(CCLSXF.VVPDp5, self, path), title="Playing Media ...")
 def VVVldf(self):
  path, poster = self.VVDDkO()
  txt = "%s:\n%s\n\n" % (FF0D7j("Path", VVPr8g), path)
  size = FFrMJ0(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FF0D7j("File Size", VVPr8g), CCLSXF.VVtnwF(size))
  if poster:
   txt += "%s:\n%s" % (FF0D7j("Poster", VVPr8g), poster)
  FFEso0(self, txt, title="Media File Information")
 def VV7H3I(self):
  path, poster = self.VVDDkO()
  if fileExists(poster): CCMQgO.VVR5E7(self, poster)
  else     : FFhSFw(self, "No Poster", 1500)
 def VVOsv3(self):
  title = "Copy Poster"
  path, poster = self.VVDDkO()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FF2ufE("cp -f '%s' '%s'" % (poster, dstF)):
    FFmMPS(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FF9Njt(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFhSFw(self, "No Poster", 1500)
 def VVEYW6(self, isManual=False):
  path, poster = self.VVDDkO()
  sDir = FFqvjY(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVbN08, sDir, path), BF(CCLSXF, patternMode="poster", VVXhi5=sDir))
  else:
   VVutlQ = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVutlQ.append((os.path.basename(item), sDir + item))
   if VVutlQ:
    VVutlQ.sort(key=lambda x: x[0].lower())
    VVRIxl = self.VVQN1n
    FFre61(self, BF(self.VVbN08, sDir, path), VVutlQ=VVutlQ, title="Posters", VVRIxl=VVRIxl, VVBWci=sDir)
   else:
    FFhSFw(self, "No jpg/png in current dir", 1500)
 def VVQN1n(self, VVG7pv, txt, ref, ndx):
  CCMQgO.VVR5E7(self, VVQVlp=ref)
 def VVbN08(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FF2ufE("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVUel6[self.curIndex] = (self.VVUel6[self.curIndex][0], self.VVUel6[self.curIndex][1], os.path.basename(newPath))
    FFVvl9(self, self.VVIfwu)
    CC1FQa.VVbwlq(newPath)
   else:
    FFhSFw(self, "Cannot copy file", 1000)
 @staticmethod
 def VVbwlq(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FF2ufE("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVrxDE(SELF):
  eLst = CCr5ME.VVbcLX()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CC1FQa, title, lst)
  else  : FF9Njt(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCLIum(Screen, CChBHx):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFzoo9(VV3yNV, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVUel6    = lst
  self.pPath    = CC3hRa.VV3CCT()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFk1xo(self, self.Title)
  FFWr7z(self["keyRed"] , "OK = Zap (Review)")
  FFWr7z(self["keyGreen"] , "Zap & Exit")
  FFWr7z(self["keyYellow"], "Find Current Service")
  CChBHx.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVJSzK, False),
   "cancel" : self.VVgUEA      ,
   "menu"  : self.VVjVBT   ,
   "red"  : self.VVgUEA      ,
   "green"  : BF(self.VVJSzK, True) ,
   "yellow" : BF(self.VVqoZo, True)  ,
   "0"   : self.VV4PiE
  })
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFqFdY(self)
   FFlx3W(self)
   FFiva8(self["keyRed"], "#0a333333")
   self.VV60nP()
  else:
   pName, srvLst = CCLIum.VVZe8f()
   if srvLst and not srvLst == self.VVUel6:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVUel6 = srvLst
   else:
    force = False
  self.totalItems = len(self.VVUel6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVbPsM(force)
  self.VVqoZo()
 def VVjVBT(self):
  VVutlQ = []
  VVutlQ.append(("Find Name (sorted list)" , "findSrt"  ))
  VVutlQ.append(("Find Name (as listed)" , "findNoSrt"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Change Background Color" , "VV9c5O"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Help (Keys)", "help"))
  FFre61(self, self.VVuAVZ, title="Options", VVutlQ=VVutlQ)
 def VVuAVZ(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVD0jy(True)
   elif item == "findNoSrt"   : self.VVD0jy(False)
   elif item == "VV9c5O": self.VV9c5O()
   elif item == "help"     : FF1D9G(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVD0jy(self, isSort):
  VVutlQ = []
  for ndx, item in enumerate(self.VVUel6):
   VVutlQ.append((item[1], ndx))
  if isSort:
   VVutlQ.sort(key=lambda x: x[0].lower())
  FFre61(self, self.VVUxhi, title="Find Name", VVutlQ=VVutlQ, width=1300)
 def VVUxhi(self, ndx=None):
  if ndx is not None:
   self.VV7wRM(ndx)
 def VVgUEA(self):
  if self.shown: self.close()
  else   : self.show()
 def VVJSzK(self, isExit):
  FFVvl9(self, BF(self.VV9XVO, isExit), title="Starting ...")
 def VV9XVO(self, isExit):
  try:
   if self.shown:
    FFlpKW(self, self.VVUel6[self.curIndex][0], VVeuyP=False)
    if isExit: self.close()
    else  : CCGzpp.VVfWLm(self.session)
   else:
    self.show()
  except:
   pass
 def VVqoZo(self, VVJLdL=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVUel6):
    if curRef == item[0]:
     self.VV7wRM(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVJLdL and err:
   FFhSFw(self, err, 500)
  return -1
 def VVIfwu(self):
  self.VV5w00()
  f1, f2 = self.VV0cPZ()
  row = col = 0
  noPos = VV8pP1 + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVUel6[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVICXO(lbl, name)
   path = CC3hRa.VVCaDz(self.pPath, ref, name) or noPos
   CChBHx.VVtlBV(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVsaq1(self):
  ref, name = self.VVUel6[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVbDTP():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VV7fnz = InfoBar.instance
  if VV7fnz:
   csel = VV7fnz.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FF8eVo(rootRef)
    refName  = FF8eVo(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVZe8f(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCLIum.VVbDTP()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFmpJ8(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CC0axI.VVttck()
   pName  = CC0axI.VVdPHV() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVqeQM(SELF):
  pName, srvLst = CCLIum.VVZe8f()
  if srvLst: SELF.session.open(CCLIum, pName, srvLst)
  else  : FF9Njt(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CC13qe(Screen, CChBHx):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFzoo9(VV1wqm, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVUel6    = CC13qe.VVhHtp(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFk1xo(self, self.Title)
  FFWr7z(self["keyRed"] , "OK = Start Plugin")
  FFWr7z(self["keyYellow"], "Package Info.")
  FFWr7z(self["keyBlue"] , "Plugins Group")
  CChBHx.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV6SSL   ,
   "cancel" : self.VVgUEA    ,
   "menu"  : self.VVniNI ,
   "info"  : self.VVbbFs  ,
   "red"  : self.VVgUEA    ,
   "yellow" : BF(FFVvl9, self, self.VVNkwU),
   "blue"  : self.VV1oiK  ,
   "0"   : self.VV4PiE
  })
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  FFlx3W(self)
  FFiva8(self["keyRed"], "#0a333333")
  self.VV60nP()
  self.totalItems = len(self.VVUel6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVbPsM(True)
 def VVgUEA(self):
  self.close()
 def VV6SSL(self):
  name, desc = self.VV2yx2(self.curIndex)
  if name == PLUGIN_NAME:
   FFhSFw(self, "Already running.", 500)
  else:
   try:
    p = self.VVUel6[self.curIndex]
    p(session=self.session)
   except:
    FF9Njt(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVbbFs(self):
  def VVy75x(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVUel6[self.curIndex]
  txt = ""
  try:
   txt += VVy75x("Path"  , p.path  )
   txt += VVy75x("Description" , p.description )
   txt += VVy75x("Icon"  , p.iconstr  )
   txt += VVy75x("Wakeup Fnc" , p.wakeupfnc )
   txt += VVy75x("NeedsRestart", p.needsRestart)
   txt += VVy75x("Internal" , p.internal )
   txt += VVy75x("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VV2yx2(self.curIndex)
  if txt : FFEso0(self, txt, title=name)
  else : FF9Njt(self, "Could not read plugin info.", title=name)
 def VVNkwU(self):
  p = self.VVUel6[self.curIndex]
  name, desc = self.VV2yx2(self.curIndex)
  path = p.path
  pkg, err = CCunAJ.VVwB2b(path)
  if pkg : CCunAJ.VVQnRR(self, pkg, name)
  else : FFGp67(self, err, 1000)
 def VVniNI(self):
  path = self.VVUel6[self.curIndex].path
  VVutlQ = []
  txt = "Open Plugin Path in File Manager"
  VVutlQ.append(FF47SM("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Use Original Icon Size", "setOrigSize"))
  FFre61(self, self.VV2k6P, title="Plugins Group", VVutlQ=VVutlQ)
 def VV2k6P(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCLSXF, mode=CCLSXF.VVXivG, VVXhi5=self.VVUel6[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVbPsM(True)
 def VV1oiK(self):
  FFre61(self, self.VVD2iv, title="Plugins Group", VVutlQ=CC13qe.VVwmoP(True, True), width=700, VVNxG7=True)
 def VVD2iv(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CC13qe.VVUOOO(where)
   if lst:
    self.VVUel6 = CC13qe.VVhHtp(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVUel6)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVbPsM(True)
   else:
    FF9Njt(self, "Not found !", title=self.Title)
 def VVIfwu(self):
  self.VV5w00()
  f1, f2 = self.VV0cPZ()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VV2yx2(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVICXO(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVUel6[ndx].icon:
    try:
     pngSz = self.VVUel6[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVUel6[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVUel6[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VV8pP1 + "plugin.png")
    for path in icons:
     pixMap = CChBHx.VVtlBV(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV2yx2(self, ndx):
  name = str(self.VVUel6[ndx].name).strip()
  desc = str(self.VVUel6[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFY1Mj(self.VVUel6[ndx].path)
  return name, desc
 def VVsaq1(self):
  name, desc = self.VV2yx2(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVwmoP(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CC13qe.VVUOOO(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVBhz1, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVJKCZ)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVUOOO(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVhHtp(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFY1Mj(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVdwGB(SELF):
  title = "Plugins Browser"
  lst = CC13qe.VVUOOO(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CC13qe, title, lst)
  else : FF9Njt(SELF, "No plugins found !", title=title)
class CC7rkQ(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFzoo9(VVzryP, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVAevT  = 0
  self.VVGzYL = 1
  self.VVc3Lh  = 2
  VVutlQ = []
  VVutlQ.append(("Find in All Service (from filter)" , "VVG3DP" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Find in All (Manual Entry)"   , "VV2ybG"    ))
  VVutlQ.append(("Find in TV"       , "VV8ekX"    ))
  VVutlQ.append(("Find in Radio"      , "VViuBI"   ))
  if self.VVxPAw():
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Hide Channel: %s" % self.servName , "VVbuXv"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Zap History"       , "VVlYgF"    ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("IPTV Tools"       , "iptv"      ))
  VVutlQ.append(("PIcons Tools"       , "PIconsTools"     ))
  VVutlQ.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVutlQ.append(("EPG Tools"       , "epgTools"     ))
  FFk1xo(self, VVutlQ=VVutlQ, title=title)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self)
  if self.isFindMode:
   self.VVTHXT(self.VVjcdX())
 def VVQHyQ(self):
  global VVU0bd
  VVU0bd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV2ybG"    : self.VV2ybG()
   elif item == "VVG3DP" : self.VVG3DP()
   elif item == "VV8ekX"    : self.VV8ekX()
   elif item == "VViuBI"   : self.VViuBI()
   elif item == "VVbuXv"   : self.VVbuXv()
   elif item == "VVlYgF"    : self.VVlYgF()
   elif item == "iptv"       : self.session.open(CC3ZOl)
   elif item == "PIconsTools"     : self.session.open(CC3hRa)
   elif item == "ChannelsTools"    : self.session.open(CCIdtv)
   elif item == "epgTools"      : self.session.open(CCvK6a)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV8ekX(self) : self.VVTHXT(self.VVAevT)
 def VViuBI(self) : self.VVTHXT(self.VVGzYL)
 def VV2ybG(self) : self.VVTHXT(self.VVc3Lh)
 def VVTHXT(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFuRfO(self, BF(self.VVSgms, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVG3DP(self):
  filterObj = CCtamE(self)
  filterObj.VVKEz5(self.VVOtKx)
 def VVOtKx(self, item):
  self.VVSgms(self.VVc3Lh, item)
 def VVxPAw(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF4MQW(self.refCode)        : return False
  return True
 def VVSgms(self, mode, VV7Bxs):
  FFVvl9(self, BF(self.VVvvP3, mode, VV7Bxs), title="Searching ...")
 def VVvvP3(self, mode, VV7Bxs):
  if VV7Bxs:
   VV7Bxs = VV7Bxs.strip()
  if VV7Bxs:
   self.findTxt = VV7Bxs
   CFG.lastFindContextFind.setValue(VV7Bxs)
   if   mode == self.VVAevT  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVGzYL : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV7Bxs)
   if len(title) > 55:
    title = title[:55] + ".."
   VV796F = self.VVw894(VV7Bxs, servTypes)
   if self.isFindMode or mode == self.VVc3Lh:
    VV796F += self.VVBBa0(VV7Bxs)
   if VV796F:
    VV796F.sort(key=lambda x: x[0].lower())
    VVfT1c = self.VVsNMk
    VVOPmD  = ("Zap"   , self.VV5m8k    , [])
    VVDle6 = ("Current Service", self.VVy3Jf , [])
    VVPOPD = ("Options"  , self.VVs04S , [])
    VV5qt4 = (""    , self.VVCIgU , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVxWCE  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVfT1c=VVfT1c, VVDle6=VVDle6, VVPOPD=VVPOPD, VV5qt4=VV5qt4, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVTHXT(self.VVjcdX())
    FFmMPS(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVw894(self, VV7Bxs, servTypes):
  VVUel6 = CCIdtv.VV6cZh(servTypes)
  VV796F = []
  if VVUel6:
   VVceEt, VV0f8b = FFhx3o()
   tp = CCSt6f()
   words, asPrefix = CCtamE.VVy75H(VV7Bxs)
   colorYellow  = CCcW2f.VVNgBs(VVRkew)
   colorWhite  = CCcW2f.VVNgBs(VV15Fs)
   for s in VVUel6:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFjfzk(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVceEt:
        STYPE = VV0f8b[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV4HYJ(refCode)
       if not "-S" in syst:
        sat = syst
       VV796F.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV796F
 def VVBBa0(self, VV7Bxs):
  VV7Bxs = VV7Bxs.lower()
  VV796F = []
  colorYellow  = CCcW2f.VVNgBs(VVRkew)
  colorWhite  = CCcW2f.VVNgBs(VV15Fs)
  for b in CC0axI.VVJHB3():
   VVHrCe  = b[0]
   VVmCqQ  = b[1].toString()
   VVY0hj = eServiceReference(VVmCqQ)
   VVwJ4u = FFmpJ8(VVY0hj)
   for service in VVwJ4u:
    refCode  = service[0]
    if FF4MQW(refCode):
     servName = service[1]
     if VV7Bxs in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VV7Bxs), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VV796F.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV796F
 def VVjcdX(self):
  mode = CCDaBC.VVG9ZK(default=-1)
  return self.VVc3Lh if mode == -1 else mode
 def VVsNMk(self, VVhkUd):
  self.close()
  VVhkUd.cancel()
 def VV5m8k(self, VVhkUd, title, txt, colList):
  FFlpKW(VVhkUd, colList[2], VVeuyP=False, checkParentalControl=True)
 def VVy3Jf(self, VVhkUd, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(VVhkUd)
  if refCode:
   VVhkUd.VVrxBR(2, FFFMIK(refCode, iptvRef, chName), True)
 def VVs04S(self, VVhkUd, title, txt, colList):
  servName = colList[0]
  mSel = CCoGI2(self, VVhkUd)
  VVutlQ, cbFncDict = CCIdtv.VVd4gP(self, VVhkUd, servName, 2)
  mSel.VVZZ7l(VVutlQ, cbFncDict)
 def VVCIgU(self, VVhkUd, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FF0gQ0(self, fncMode=CCY1HC.VVI7L5, refCode=refCode, chName=chName, text=txt)
 def VVbuXv(self):
  FFfbEx(self, self.VV5lrn, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV5lrn(self):
  ret = FFNQSk(self.refCode, True)
  if ret:
   self.VVcj21()
   self.close()
  else:
   FFhSFw(self, "Cannot change state" , 1000)
 def VVcj21(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVEm4k()
  except:
   self.VVsIDj()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFDSaZ(self, serviceRef)
 def VVEm4k(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV7fnz = InfoBar.instance
   if VV7fnz:
    VVObn7 = VV7fnz.servicelist
    if VVObn7:
     hList = VVObn7.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVObn7.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVObn7.history  = newList
       VVObn7.history_pos = pos
 def VVsIDj(self):
  VV7fnz = InfoBar.instance
  if VV7fnz:
   VVObn7 = VV7fnz.servicelist
   if VVObn7:
    VVObn7.history  = []
    VVObn7.history_pos = 0
 def VVlYgF(self):
  VV7fnz = InfoBar.instance
  VV796F = []
  if VV7fnz:
   VVObn7 = VV7fnz.servicelist
   if VVObn7:
    VVceEt, VV0f8b = FFhx3o()
    for serv in VVObn7.history:
     refCode = serv[-1].toString()
     chName = FF8eVo(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FF4MQW(refCode)
     isSRel = FFcIP1(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFjfzk(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVceEt:
       STYPE = VV0f8b[sTypeInt]
     VV796F.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV796F:
   VVOPmD  = ("Zap"   , self.VVzzhD   , [])
   VVPOPD = ("Clear History" , self.VVEmVw   , [])
   VV5qt4 = (""    , self.VVvK4f , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVxWCE  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, VVOPmD=VVOPmD, VVPOPD=VVPOPD, VV5qt4=VV5qt4)
  else:
   FFmMPS(self, "History is empty.", title=title)
 def VVzzhD(self, VVhkUd, title, txt, colList):
  FFlpKW(VVhkUd, colList[3], VVeuyP=False, checkParentalControl=True)
 def VVEmVw(self, VVhkUd, title, txt, colList):
  FFfbEx(self, BF(self.VVrc0Y, VVhkUd), "Clear Zap History ?")
 def VVrc0Y(self, VVhkUd):
  self.VVsIDj()
  VVhkUd.cancel()
 def VVvK4f(self, VVhkUd, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FF0gQ0(self, fncMode=CCY1HC.VVZspE, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVGg8g():
  try:
   global VVlCmV
   if VVlCmV is None:
    VVlCmV    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CC7rkQ.VVqZVp
   ChannelContextMenu.VVpKAU = CC7rkQ.VVpKAU
  except:
   pass
 @staticmethod
 def VVqZVp(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVlCmV(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVpKAU, csel, ndx, title))))
 @staticmethod
 def VVpKAU(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FF8eVo(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCLIum.VVqeQM(SELF)
  elif mode == 2: SELF.session.open(CCDaBC)
  else    : SELF.session.open(CC7rkQ, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CCDaBC(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FFzoo9(VVS1Zw, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CC3hRa.VV3CCT()
  self.bTables = []
  FFk1xo(self)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self.VVkImI()
 def VV6iG6(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VVkImI(self):
  rootStr = CCDaBC.VVUyOs()
  rows = self.VV3JSX(rootStr)
  if rows :
   self.VV5Raw(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCLIum.VVbDTP()
   if not self.bTables[-1].VV9SZy({3:refCode}):
    self.bTables[-1].VV9SZy({3:rootRef})
  else:
   FF9Njt(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVrchs(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VV3JSX(self, bRef=None):
  blkLst = CCDaBC.VVtiri()
  rows = []
  for ndx, row in enumerate(FFmpJ8(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CCDaBC.VV7OlH(flags)
   lck = "1" if CCDaBC.VVITtC(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VV5Raw(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FF0D7j("Fav: ", VVBhz1), bName), 2:"%s %s" % (FF0D7j("Sub: ", VVBhz1), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVfT1c = self.VV6Ywm
  VV5qt4 = (""    , self.VVTfSi  , [])
  VVOPmD  = ("Enter Bouquet" , self.VVLIts , [])
  VVRsW0 = ("Delete"   , self.VVmAEW , [])
  VVPOPD = ("Options"  , self.VVr0B2 , [])
  VVUum8 = ("Move Here"  , self.VV0FAD , [])
  picParams  = (1, self.VVpDyr, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VVxWCE = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFvfpt(self, None, title=title, VVUel6=rows, VVxWCE=VVxWCE, width=1500, height=1000, VVFNzW=widths, VVH0vt=28, addSort=False, VV5qt4=VV5qt4, VVOPmD=VVOPmD, VVfT1c=VVfT1c, VVRsW0=VVRsW0, VVPOPD=VVPOPD, VVUum8=VVUum8, VVNWl5=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVChAx="#0a442200", borderWidth=0, VV4UX1="#11330000")
  tbl.VVHrXj(BF(self.VVfttq, tbl), True)
  self.VV6iG6(tbl, bName, bRef)
 def VVgu2r(self, VVhkUd, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFURke()
   rows = self.VV3JSX(VVhkUd.bouqRef)
   if rows:
    VVhkUd.VVGaoF(False)
    VVhkUd.VVoiHv(rows, VVanXbMsg=True, isSort=False, tableRefreshCB=BF(self.VVVzvQ, jumpDict))
   else:
    self.VVrchs()
    totTbl = len(self.bTables)
    FFhSFw(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFGp67(VVhkUd, "No change !", 1500)
 def VVVzvQ(self, jumpDict, VVhkUd, title, txt, colList):
  if jumpDict:
   VVhkUd.VV9SZy(jumpDict)
 def VVfttq(self, VVhkUd):
  VVhkUd["keyRed"].hide()
  VVhkUd["keyBlue"].hide()
  if VVhkUd.VVs7XH:
   if VVhkUd.VVznW9() > 0:
    VVhkUd["keyRed"].show()
    VVhkUd["keyBlue"].show()
  else:
   VVhkUd["keyRed"].show()
 def VVTfSi(self, VVhkUd, title, txt, colList):
  c1, c2, c3 = VVRkew, VVJTsP, VVUS1a
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FF0D7j(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CCDaBC.VVSOQP(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVhkUd.bouqName, c2)
  txt += ttl("Parent Bouquet File", CCDaBC.VVSOQP(VVhkUd.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVWEgS else ""
  txt += ttl("Remarks"   , rem, c3) if VVWEgS else ""
  path = CC3hRa.VVCaDz(self.pPath, ref, name)
  FF0gQ0(self, fncMode=CCY1HC.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVLIts(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVmlYF, VVhkUd, colList) )
 def VVmlYF(self, VVhkUd, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if "FROM BOUQUET " in ref:
   if len(self.bTables) <= maxLev:
    rows = self.VV3JSX(ref)
    if rows : self.VV5Raw(VVhkUd, name, ref, rows)
    else : FFGp67(VVhkUd, "Empty list !", 1500)
   else:
    FF9Njt(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CCDaBC.VVecsE(ref) == 0:
   FFlpKW(self, ref, VVeuyP=False)
   FFKsbm(self, "Cancel to go back to table")
  else:
   FFhSFw(VVhkUd, "No action", 300)
 def VV6Ywm(self, VVhkUd):
  if VVhkUd.VVs7XH:
   VVhkUd.VVGaoF(False)
   self.VVfttq(VVhkUd)
  else:
   self.VVrchs()
 def VVr0B2(self, VVhkUd, title, txt, colList):
  VVutlQ = []
  iMulSel = VVhkUd.VVsOQV()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVhkUd.VVznW9()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFCMcT(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  VVutlQ.append(FF47SM("Rename"   , "renm" , not iMulSel))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(FF47SM("Add Marker"  , "mrkr" , not iMulSel))
  VVutlQ.append(FF47SM("Add Empty Bouquet", "addBouq" , not iMulSel and inMain))
  if inMain:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(FF47SM("Hide %s" % bTxt , "hidOn" , isSel))
   VVutlQ.append(FF47SM("Unhide %s" % bTxt , "hidOff" , isSel))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(FF47SM("Protect %s" % bTxt , "lckOn" , isSel))
   VVutlQ.append(FF47SM("Unprotect %s" % bTxt , "lckOff" , isSel))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(sortItem)
  VVutlQ.append(FF47SM("Copy to Bouquet" , "toBouq" , isSel))
  cbFncDict = { "renm" : BF(self.VV5ndp  , VVhkUd)
     , "mrkr" : BF(self.VVvb8A , VVhkUd)
     , "addBouq" : BF(self.VV3eqV, VVhkUd)
     , "hidOn" : BF(self.VVvwqX  , VVhkUd, True)
     , "hidOff" : BF(self.VVvwqX  , VVhkUd, False)
     , "lckOn" : BF(self.VVOjdP  , VVhkUd, True)
     , "lckOff" : BF(self.VVOjdP  , VVhkUd, False)
     , "sort" : BF(self.VVWMlT  , VVhkUd)
     , "toBouq" : BF(self.VV7DLB , VVhkUd) }
  fnc = BF(self.VVfttq, VVhkUd)
  mSel = CCoGI2(self, VVhkUd)
  mSel.VVZZ7l(VVutlQ, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc)
 def VVmAEW(self, VVhkUd, title, txt, colList):
  txt, totSel = "", 0
  if VVhkUd.VVsOQV():
   totSel = VVhkUd.VVznW9()
   if totSel:
    txt = "Delete %s item%s" % (FF0D7j(str(totSel), VVRkew), FFCMcT(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FF0D7j(name, VVRkew)
  if txt:
   FFfbEx(self, BF(self.VVKX23, VVhkUd), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVKX23(self, VVhkUd):
  FFVvl9(VVhkUd, BF(self.VVNyHC, VVhkUd))
 def VVNyHC(self, VVhkUd):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CC0axI.VVAClG(ref)
     if "userSubBouquet" in bFile:
      bFile = VVGMYl + bFile
      FF2ufE("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VVgu2r(VVhkUd, mutableList, tot)
 def VV0FAD(self, VVhkUd, title, txt, colList):
  FFVvl9(VVhkUd, BF(self.VVZEey, VVhkUd))
 def VVZEey(self, VVhkUd):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  if mutableList is not None:
   curNdx = VVhkUd.VVSWzf()
   if curNdx <= VVhkUd.VVQijQ(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVgu2r(VVhkUd, mutableList, tot)
 def VVWMlT(self, VVhkUd):
  FFVvl9(VVhkUd, BF(self.VVMrB8, VVhkUd))
 def VVMrB8(self, VVhkUd):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  if mutableList is not None:
   nmlst = VVhkUd.VVd77Z(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVhkUd.VVQijQ()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVgu2r(VVhkUd, mutableList, tot)
 def VV5ndp(self, VVhkUd, item=None):
  name = VVhkUd.VVZqZI()[2]
  FFuRfO(self, BF(self.VVk7Xk, VVhkUd), defaultText=name, title="Rename", message="Enter new name")
 def VVk7Xk(self, VVhkUd, name):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVhkUd.VVZqZI()[3]
    if "FROM BOUQUET " in ref:
     CC0axI.VVxrmW(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVhkUd.VVSWzf())
    self.VVgu2r(VVhkUd, mutableList, 1)
 def VVvb8A(self, VVhkUd):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFVvl9(VVhkUd, BF(self.VVup8v, VVhkUd, name))
 def VVup8v(self, VVhkUd, name):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  if mutableList is not None:
   curServ = eServiceReference(VVhkUd.VVZqZI()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VVgu2r(VVhkUd, mutableList, tot)
 def VV3eqV(self, VVhkUd):
  names = VVhkUd.VVT6PQ(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FFuRfO(self, BF(self.VV8TIN, VVhkUd), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VV8TIN(self, VVhkUd, name=None):
  if name and name.strip():
   FFVvl9(VVhkUd, BF(self.VVOFwm, VVhkUd, name.strip()))
 def VVOFwm(self, VVhkUd, bName):
  CC0axI.VVcKKE(bName)
  self.VVgu2r(VVhkUd, None, 1, jumpDict={2:bName})
 def VV7DLB(self, VVhkUd):
  bRows = CC0axI.VVnqVH()
  if VVhkUd.VVs7XH : lst = VVhkUd.VVd77Z(3)
  else        : lst = [VVhkUd.VVZqZI()[3]]
  VVutlQ = []
  for name, ref in bRows:
   if not ref in lst:
    VVutlQ.append((name, ref))
  if VVutlQ : FFre61(self,  BF(self.VV2ObT, VVhkUd), VVutlQ=VVutlQ, width=1100, height=900, VVRdqN="#22220000", VVkSGg="#22110000", title="Destination Bouquet", VVNxG7=True)
  else  : FFhSFw(VVhkUd, "No bouquets left !", 1000)
 def VV2ObT(self, VVhkUd, item=None):
  if item:
   bName, bRef, ndx = item
   FFVvl9(VVhkUd, BF(self.VVP9fe, VVhkUd, bName, bRef))
 def VVP9fe(self, VVhkUd, bName, bRef):
  if VVhkUd.VVs7XH : lst = VVhkUd.VVd77Z(3)
  else        : lst = [VVhkUd.VVZqZI()[3]]
  dstFile = CC0axI.VVAClG(bRef)
  tot = 0
  for ref in lst:
   ok = CC0axI.VVXPeY(ref, dstFile)
   if ok:
    tot += 1
  self.VVgu2r(VVhkUd, None, tot)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FF0D7j(x, VVPr8g), y)
  txt  = ttl("Source Bouquet"  , VVhkUd.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FFEso0(VVhkUd, txt, title="Copy Services")
 def VVvwqX(self, VVhkUd, isHide):
  FFVvl9(VVhkUd, BF(self.VVYZvh, VVhkUd, isHide))
 def VVYZvh(self, VVhkUd, isHide):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  mode = CCDaBC.VVG9ZK()
  path = VVGMYl + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FF6UEw(path)))
   for ref in lst:
    if "FROM BOUQUET " in ref:
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VVgu2r(VVhkUd, None, tot)
 def VVOjdP(self, VVhkUd, isLck):
  FFVvl9(VVhkUd, BF(self.VVzWZ7, VVhkUd, isLck))
 def VVzWZ7(self, VVhkUd, isLck):
  lst, mutableList, csel, bServ = self.VVjMt9(VVhkUd)
  blkLst = CCDaBC.VVtiri()
  tot = 0
  for ref in lst:
   if "FROM BOUQUET " in ref:
    ndx = CCDaBC.VVITtC(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VV05KA, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VVgu2r(VVhkUd, None, tot)
 def VVjMt9(self, VVhkUd, bServ=None):
  if VVhkUd.VVs7XH : lst = VVhkUd.VVd77Z(3)
  else        : lst = [VVhkUd.VVZqZI()[3]]
  mutableList = csel = None
  VV7fnz = InfoBar.instance
  if VV7fnz:
   csel = VV7fnz.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVhkUd.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VVpDyr(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VV8pP1, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif "FROM BOUQUET " in ref:
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CC3hRa.VVCaDz(self.pPath, ref, name)
 @staticmethod
 def VV7OlH(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.FF5YNjedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVSOQP(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVWEgS:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVGMYl + span.group(1)
  return path
 @staticmethod
 def VVecsE(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVG9ZK(default=0):
  VV7fnz = InfoBar.instance
  if VV7fnz:
   csel = VV7fnz.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVUyOs():
  VV7fnz = InfoBar.instance
  if VV7fnz:
   csel = VV7fnz.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVtiri():
  return FF6UEw(VV05KA) if fileExists(VV05KA) else []
 @staticmethod
 def VVITtC(ref, lst=None):
  if not lst:
   lst = CCDaBC.VVtiri()
  if "FROM BOUQUET " in ref:
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CC3hRa(Screen, CChBHx, CC26Ue):
 VVW2ry   = 0
 VVrfAU  = 1
 VVqwEt  = 2
 VVm80K  = 3
 VVHfuo  = 4
 VVer3o  = 5
 VVPTBE  = 6
 VVJqzi  = 7
 VVi6Zz = 8
 VVoZof = 9
 VVt1Y1 = 10
 VVecA7 = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVwLpo, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CC3hRa.VV3CCT()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVUel6    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFk1xo(self, self.Title)
  FFWr7z(self["keyRed"] , "OK = Zap")
  FFWr7z(self["keyGreen"] , "Current Service")
  FFWr7z(self["keyYellow"], "Page Options")
  FFWr7z(self["keyBlue"] , "Filter")
  CChBHx.__init__(self, 5, 7, CFG.transpColorPicons)
  CC26Ue.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVorO8     ,
   "green"  : self.VVGDe2    ,
   "yellow" : self.VVwiJI     ,
   "blue"  : self.VVuPO9     ,
   "menu"  : self.VVVXli     ,
   "info"  : self.VVUcbQ    ,
   "pageUp" : BF(self.VVW8zV, True) ,
   "chanUp" : BF(self.VVW8zV, True) ,
   "pageDown" : BF(self.VVW8zV, False) ,
   "chanDown" : BF(self.VVW8zV, False) ,
   "0"   : self.VV4PiE  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  FFlx3W(self)
  FFiva8(self["keyRed"], "#0a333333")
  self.VV60nP()
  FFVvl9(self, BF(self.VV41BP, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVVXli(self):
  if not self.isBusy:
   VVutlQ = []
   VVutlQ.append(("Statistics"           , "VV0Cyf"    ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Suggest PIcons for Current Channel"     , "VVgjnG"   ))
   VVutlQ.append(("Set to Current Channel (copy file)"     , "VVNmhq_file"  ))
   VVutlQ.append(("Set to Current Channel (as SymLink)"     , "VVNmhq_link"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Export Current File Names List"      , "VVuETW" ))
   VVutlQ.append(CC3hRa.VVkFrl())
   VVutlQ.append(VVJKCZ)
   c, cond = VVO7vL, self.filterTitle == "PIcons without Channels"
   VVutlQ.append(FF47SM("Move Unused PIcons to a Directory", "VVXcOY" , cond, c))
   VVutlQ.append(FF47SM("DELETE Unused PIcons"    , "VVeMfs" , cond, c))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVVIc9"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ += CC3hRa.VVXoaY()
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Change Poster/Picon Transparency Color"    , "VV9c5O" ))
   VVutlQ.append(("Keys Help"           , "VVgovm"    ))
   FFre61(self, self.VVC0O7, width=1100, height=1050, title=self.Title, VVutlQ=VVutlQ)
 def VVC0O7(self, item=None):
  if item is not None:
   if   item == "VV0Cyf"    : self.VV0Cyf()
   elif item == "VVgjnG"   : self.VVgjnG()
   elif item == "VVNmhq_file"  : self.VVNmhq(0)
   elif item == "VVNmhq_link"  : self.VVNmhq(1)
   elif item == "VVuETW"  : self.VVuETW()
   elif item == "VV76vU"  : CC3hRa.VV76vU(self)
   elif item == "VVXcOY"   : self.VVXcOY()
   elif item == "VVeMfs"  : self.VVeMfs()
   elif item == "VVVIc9"  : self.VVVIc9()
   elif item == "VV1oIx"  : CC3hRa.VV1oIx(self)
   elif item == "findPiconBrokenSymLinks" : CC3hRa.VVxzcD(self, True)
   elif item == "FindAllBrokenSymLinks" : CC3hRa.VVxzcD(self, False)
   elif item == "VV9c5O" : self.VV9c5O()
   elif item == "VVgovm"     : FF1D9G(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVwiJI(self):
  if not self.isBusy:
   VVutlQ = []
   VVutlQ.append(("Go to First PIcon"  , "VVLD85"  ))
   VVutlQ.append(("Go to Last PIcon"   , "VVXm2i"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Sort by Channel Name"     , "sortByChan" ))
   VVutlQ.append(("Sort by File Name"  , "sortByFile" ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Find from File List .." , "VVPcmz" ))
   FFre61(self, self.VVZRSi, title=self.Title, VVutlQ=VVutlQ)
 def VVZRSi(self, item=None):
  if item is not None:
   if   item == "VVLD85"   : self.VVLD85()
   elif item == "VVXm2i"   : self.VVXm2i()
   elif item == "sortByChan"  : self.VV2xNa(2)
   elif item == "sortByFile"  : self.VV2xNa(0)
   elif item == "VVPcmz"  : self.VVPcmz()
 def VVPcmz(self):
  VVutlQ = []
  for item in self.VVUel6:
   VVutlQ.append((item[0], item[0]))
  FFre61(self, self.VVG4lb, title='PIcons ".png" Files', VVutlQ=VVutlQ, VVNxG7=True)
 def VVG4lb(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV7wRM(ndx)
 def VVorO8(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVozEX()
   if refCode:
    FFlpKW(self, refCode)
    self.VVZjCX()
    self.VVsaq1()
 def VVW8zV(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVZjCX()
   self.VVsaq1()
  except:
   pass
 def VVGDe2(self):
  if self["keyGreen"].getVisible():
   self.VV7wRM(self.curChanIndex)
 def VV2xNa(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFVvl9(self, BF(self.VV41BP, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVNmhq(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVozEX()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVutlQ = []
     VVutlQ.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVutlQ.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFre61(self, BF(self.VVijVN, mode, curChF, selPiconF), VVutlQ=VVutlQ, title="Current Channel PIcon (already exists)")
    else:
     self.VVijVN(mode, curChF, selPiconF, "overwrite")
   else:
    FF9Njt(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF9Njt(self, "Could not read current channel info. !", title=title)
 def VVijVN(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FF2ufE(cmd)
   FFVvl9(self, BF(self.VV41BP, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVXcOY(self):
  defDir = FFqvjY(CC3hRa.VV3CCT() + "picons_backup")
  FF2ufE("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVO9ED, defDir), BF(CCLSXF
         , mode=CCLSXF.VVL22N, VVXhi5=CC3hRa.VV3CCT()))
 def VVO9ED(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC3hRa.VV3CCT():
    FF9Njt(self, "Cannot move to same directory !", title=title)
   else:
    if not FFqvjY(path) == FFqvjY(defDir):
     self.VV7JC2(defDir)
    FFfbEx(self, BF(FFVvl9, self, BF(self.VVDGLA, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVUel6), path), title=title)
  else:
   self.VV7JC2(defDir)
 def VVDGLA(self, title, defDir, toPath):
  if not iMove:
   self.VV7JC2(defDir)
   FF9Njt(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFqvjY(toPath)
  pPath = CC3hRa.VV3CCT()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVUel6:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVUel6)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFEso0(self, txt, title=title, VVTJDG="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVvL7R("all")
 def VV7JC2(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVeMfs(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVUel6)
  FFfbEx(self, BF(FFVvl9, self, BF(self.VVkesN, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFCMcT(tot)), title=title)
 def VVkesN(self, title):
  pPath = CC3hRa.VV3CCT()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVUel6:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVUel6)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF0D7j(str(totErr), VVUS1a)
  FFEso0(self, txt, title=title)
 def VVVIc9(self):
  lines = FFlfx8("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFfbEx(self, BF(self.VVbfeR, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFCMcT(tot)), VVAbek=True)
  else:
   FFmMPS(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVbfeR(self, fList):
  FF2ufE("find -L '%s' -type l -delete" % self.pPath)
  FFmMPS(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVUcbQ(self):
  FFVvl9(self, self.VVPGS5)
 def VVPGS5(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVozEX()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF0D7j("PIcon Directory:\n", VVJTsP)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF6tJG(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF6tJG(path)
   txt += FF0D7j("PIcon File:\n", VVJTsP)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FF0D7j("Found %d SymLink%s to this file from:\n" % (tot, FFCMcT(tot)), VVJTsP)
     for fPath in slLst:
      txt += "  %s\n" % FF0D7j(fPath, VVBhz1)
     txt += "\n"
   if chName:
    txt += FF0D7j("Channel:\n", VVJTsP)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF0D7j(chName, VVRTFm)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FF0D7j("Remarks:\n", VVJTsP)
    txt += "  %s\n" % FF0D7j("Unused", VVUS1a)
  else:
   txt = "No info found"
  FF0gQ0(self, fncMode=CCY1HC.VVDgRc, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVozEX(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVUel6[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFv6HB(sat)
  return fName, refCode, chName, sat, inDB
 def VVZjCX(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVUel6):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVsaq1(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVozEX()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF0D7j("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVJTsP))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVozEX()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFcIP1(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF0D7j(self.curChanName, VVRkew)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVozEX()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV0Cyf(self):
  VVceEt, VV0f8b = FFhx3o()
  sTypeNameDict = {}
  for key, val in VV0f8b.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVUel6:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VV0f8b: sTypeDict[VV0f8b[stNum]] = sTypeDict.get(VV0f8b[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FF7jZM("find -L '%s' -type l -print | wc -l" % self.pPath)
  VV796F = []
  c = "#b#11003333#"
  VV796F.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VV796F.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VV796F.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VV796F.append((c + "In Database (lamedb)"  , str(totInDB)))
  VV796F.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VV796F.append((c + "Satellites"    , str(len(self.nsList))))
  VV796F.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VV796F.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VV796F.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VV796F.extend(sTypeRows)
  FFvfpt(self, None, title=self.Title, VVUel6=VV796F, VVH0vt=28, VVChAx="#00003333", VVDQNf="#00222222")
 def VVuETW(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFqvjY(CFG.exportedTablesPath.getValue()), txt, FFKX94())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVUel6:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFmMPS(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVuPO9(self):
  if not self.isBusy:
   VVutlQ = []
   VVutlQ.append(("All"        , "all"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Used by Channels"     , "used" ))
   VVutlQ.append(("Unused PIcons"     , "unused" ))
   VVutlQ.append(("IPTV PIcons"      , "iptv" ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("PIcons Files"      , "pFiles" ))
   VVutlQ.append(("SymLinks to PIcons"    , "pLinks" ))
   VVutlQ.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVutlQ.append(("By Files Date ..."    , "pDate" ))
   VVutlQ.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVutlQ.append(FFODSa("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FF1Q1b(val)
      VVutlQ.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCtamE(self)
   filterObj.VVo6vS(VVutlQ, self.nsList, self.VVfj1k)
 def VVfj1k(self, item=None):
  if item is not None:
   self.VVvL7R(item)
 def VVvL7R(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVW2ry   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVrfAU   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVqwEt  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVPTBE   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVm80K  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVHfuo  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVer3o  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVt1Y1 , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVecA7 , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVJqzi   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVi6Zz , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVer3o:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFlfx8("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFY1Mj(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFhSFw(self, "Not found", 1000)
     return
   elif mode == self.VVt1Y1:
    self.VVnNsb(mode)
    return
   elif mode == self.VVecA7:
    self.VVn0sS(mode)
    return
   elif mode == self.VVoZof:
    return
   else:
    words, asPrefix = CCtamE.VVy75H(words)
   if not words and mode in (self.VVJqzi, self.VVi6Zz):
    FFhSFw(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFVvl9(self, BF(self.VV41BP, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVnNsb(self, mode):
  VVutlQ = []
  VVutlQ.append(("Today"   , "today" ))
  VVutlQ.append(("Since Yesterday" , "yest" ))
  VVutlQ.append(("Since 7 days"  , "week" ))
  FFre61(self, BF(self.VVVeIy, mode), VVutlQ=VVutlQ, title="Filter by Added/Modified Date")
 def VVVeIy(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFLHvJ(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFLHvJ(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFLHvJ(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFVvl9(self, BF(self.VV41BP, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVn0sS(self, mode):
  VVceEt, VV0f8b = FFhx3o()
  lst = set()
  for key, val in VV0f8b.items():
   lst.add(val)
  VVutlQ = []
  for item in lst:
   VVutlQ.append((item, item))
  VVutlQ.sort(key=lambda x: x[0])
  FFre61(self, BF(self.VVBVU7, mode), VVutlQ=VVutlQ, title="Filter by Service Type")
 def VVBVU7(self, mode, item=None):
  if item:
   VVceEt, VV0f8b = FFhx3o()
   sTypeList = []
   for key, val in VV0f8b.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFVvl9(self, BF(self.VV41BP, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVgjnG(self):
  self.session.open(CC1jbq, barTheme=CC1jbq.VVlB2I
      , titlePrefix = ""
      , fncToRun  = self.VVJpNl
      , VVFqvg = self.VVrezf)
 def VVJpNl(self, VVdu90):
  VVy2ge, err = CCIdtv.VVu18q(self, CCIdtv.VVbDDC, VVadNQ=False, VVWj86=False)
  files = []
  words = []
  if not VVdu90 or VVdu90.isCancelled:
   return
  VVdu90.VVeIVc = []
  VVdu90.VV7hIf(len(VVy2ge))
  if VVy2ge:
   curCh = self.VV51yv(self.curChanName)
   for refCode in VVy2ge:
    if not VVdu90 or VVdu90.isCancelled:
     return
    VVdu90.VVRbmv(1, True)
    chName, sat, inDB = VVy2ge.get(refCode, ("", "", 0))
    ratio = CC3hRa.VVydpe(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC3hRa.VVku5e(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFY1Mj(f)
       fil = f.replace(".png", "")
       if not fil in VVdu90.VVeIVc:
        VVdu90.VVeIVc.append(fil)
 def VVrezf(self, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  if VVeIVc : FFVvl9(self, BF(self.VV41BP, mode=self.VVoZof, words=VVeIVc), title="Loading ...")
  else   : FFhSFw(self, "Not found", 2000)
 def VV41BP(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVCajv(isFirstTime):
   return
  self.isBusy = True
  VVWj86 = True if isFirstTime else False
  VVy2ge, err = CCIdtv.VVu18q(self, CCIdtv.VVbDDC, VVadNQ=False, VVWj86=VVWj86)
  if err:
   self.close()
  iptvRefList = self.VV2J9E()
  tList = []
  for fName, fType in CC3hRa.VVwLN3(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVy2ge:
    if fName in VVy2ge:
     chName, sat, inDB = VVy2ge.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVW2ry:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVrfAU  and chName         : isAdd = True
   elif mode == self.VVqwEt and not chName        : isAdd = True
   elif mode == self.VVm80K  and fType == 0        : isAdd = True
   elif mode == self.VVHfuo  and fType == 1        : isAdd = True
   elif mode == self.VVer3o  and fName in words       : isAdd = True
   elif mode == self.VVoZof and fName in words       : isAdd = True
   elif mode == self.VVPTBE  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVJqzi  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVi6Zz:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVt1Y1:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVecA7:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVUel6   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFhSFw(self)
  else:
   self.isBusy = False
   FFhSFw(self, "Not found", 1000)
   return
  self.VVUel6.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVZjCX()
  self.totalItems = len(self.VVUel6)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVbPsM(True)
 def VVCajv(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC3hRa.VVwLN3(self.pPath):
    if fName:
     return True
   if isFirstTime : FF9Njt(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFhSFw(self, "Not found", 1000)
  else:
   FF9Njt(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV2J9E(self):
  VV796F = {}
  files  = CC3ZOl.VVYQhO()
  if files:
   for path in files:
    txt = FFXk75(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV796F[refCode] = item[1]
  return VV796F
 def VVIfwu(self):
  self.VV5w00()
  f1, f2 = self.VV0cPZ()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVUel6[ndx]
   fName = self.VVUel6[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CChBHx.VVtlBV(pic, path) : color = VVRTFm if inDB else ""
   elif not chName           : color = ""
   else             : color = VV7CTN
   self.VVICXO(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVydpe(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVkFrl():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VV76vU")
 @staticmethod
 def VVXoaY():
  VVutlQ = []
  VVutlQ.append(("Find SymLinks (to PIcon Directory)"   , "VV1oIx"  ))
  VVutlQ.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVutlQ.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVutlQ
 @staticmethod
 def VV76vU(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF)
  png, path = CC3hRa.VVenVx(refCode)
  if path : CC3hRa.VVrraB(SELF, png, path)
  else : FF9Njt(SELF, "No PIcon found for current channel in:\n\n%s" % CC3hRa.VV3CCT())
 @staticmethod
 def VV1oIx(SELF):
  if VVRkew:
   sed1 = FFLPjB("->", VVRkew)
   sed2 = FFLPjB("picon", VVUS1a)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV7CTN, VV15Fs)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFmUBH(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFNOMj(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVxzcD(SELF, isPIcon):
  sed1 = FFLPjB("->", VV7CTN)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFLPjB("picon", VVUS1a)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFmUBH(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFNOMj(), grep, sed1, sed2))
 @staticmethod
 def VVrraB(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFLPjB("%s%s" % (dest, png), VVRTFm))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFLPjB(errTxt, VV8a8m))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFrGZ9(SELF, cmd)
 @staticmethod
 def VVwLN3(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV3CCT():
  path = CFG.PIconsPath.getValue()
  return FFqvjY(path)
 @staticmethod
 def VVenVx(refCode, chName=None):
  if FF4MQW(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFYUp6(refCode)
  allPath, fName, refCodeFile, pList = CC3hRa.VVku5e(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVCaDz(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CC3ZOl.VVXLzV():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFLAHl(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVku5e(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC3hRa.VV3CCT()
   pList = []
   lst = FFJwmB(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFLAHl(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFY1Mj(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCfiOU():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVz9iu  = None
  self.VVC9p8 = ""
  self.VVksni  = noService
  self.VVKVDK = 0
  self.VVndf4  = noService
  self.VVCVLd = 0
  self.VV32KL  = "-"
  self.VVtc4j = 0
  self.VVHM47  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVO2ia(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVz9iu = frontEndStatus
     self.VVNALu()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVNALu(self):
  if self.VVz9iu:
   val = self.VVz9iu.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVC9p8 = "%3.02f dB" % (val / 100.0)
   else         : self.VVC9p8 = ""
   val = self.VVz9iu.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVKVDK = int(val)
   self.VVksni  = "%d%%" % val
   val = self.VVz9iu.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVCVLd = int(val)
   self.VVndf4  = "%d%%" % val
   val = self.VVz9iu.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV32KL  = "%d" % val
   val = int(val * 100 / 500)
   self.VVtc4j = min(500, val)
   val = self.VVz9iu.get("tuner_locked", 0)
   if val == 1 : self.VVHM47 = "Locked"
   else  : self.VVHM47 = "Not locked"
 def VVmPBC(self)   : return self.VVC9p8
 def VVU8lF(self)   : return self.VVksni
 def VVMWuT(self)  : return self.VVKVDK
 def VVNFED(self)   : return self.VVndf4
 def VVZ4ih(self)  : return self.VVCVLd
 def VVxFKM(self)   : return self.VV32KL
 def VVfb5N(self)  : return self.VVtc4j
 def VVWlfK(self)   : return self.VVHM47
 def VVGBfG(self) : return self.serviceName
class CCSt6f():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVg8UX(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFkXXp(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVNtDZ(self.ORPOS  , mod=1   )
      self.sat2  = self.VVNtDZ(self.ORPOS  , mod=2   )
      self.freq  = self.VVNtDZ(self.FREQ  , mod=3   )
      self.sr   = self.VVNtDZ(self.SR   , mod=4   )
      self.inv  = self.VVNtDZ(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVNtDZ(self.POL  , self.D_POL )
      self.fec  = self.VVNtDZ(self.FEC  , self.D_FEC )
      self.syst  = self.VVNtDZ(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVNtDZ("modulation" , self.D_MOD )
       self.rolof = self.VVNtDZ("rolloff"  , self.D_ROLOF )
       self.pil = self.VVNtDZ("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVNtDZ("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVNtDZ("pls_code"  )
       self.iStId = self.VVNtDZ("is_id"   )
       self.t2PlId = self.VVNtDZ("t2mi_plp_id" )
       self.t2PId = self.VVNtDZ("t2mi_pid"  )
 def VVNtDZ(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FF1Q1b(val)
  elif mod == 2   : return FFh9n9(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVxC4S(self, refCode):
  txt = ""
  self.VVg8UX(refCode)
  if self.data:
   def VVy75x(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVy75x("System"   , self.syst)
    txt += VVy75x("Satellite"  , self.sat2)
    txt += VVy75x("Frequency"  , self.freq)
    txt += VVy75x("Inversion"  , self.inv)
    txt += VVy75x("Symbol Rate"  , self.sr)
    txt += VVy75x("Polarization" , self.pol)
    txt += VVy75x("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVy75x("Modulation" , self.mod)
     txt += VVy75x("Roll-Off" , self.rolof)
     txt += VVy75x("Pilot"  , self.pil)
     txt += VVy75x("Input Stream", self.iStId)
     txt += VVy75x("T2MI PLP ID" , self.t2PlId)
     txt += VVy75x("T2MI PID" , self.t2PId)
     txt += VVy75x("PLS Mode" , self.plsMod)
     txt += VVy75x("PLS Code" , self.plsCod)
   else:
    txt += VVy75x("System"   , self.txMedia)
    txt += VVy75x("Frequency"  , self.freq)
  return txt, self.namespace
 def VVM9Ow(self, refCode):
  txt = "Transpoder : ?"
  self.VVg8UX(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VV4HYJ(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFkXXp(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVNtDZ(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVNtDZ(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVNtDZ(self.SYST, self.D_SYS_S)
     freq = self.VVNtDZ(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVNtDZ(self.POL , self.D_POL)
      fec = self.VVNtDZ(self.FEC , self.D_FEC)
      sr = self.VVNtDZ(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVrcxQ(self, refCode):
  self.data = None
  self.VVg8UX(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCc3G0():
 def __init__(self, VVgabR, path, VVFqvg=None, curRowNum=-1):
  self.VVgabR  = VVgabR
  self.origFile   = path
  self.Title    = "File Editor: " + FFY1Mj(path)
  self.VVFqvg  = VVFqvg
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FF2ufE("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFVvl9(self.VVgabR, BF(self.VVnXBE, curRowNum), title="Loading file ...")
  else:
   FF9Njt(self.VVgabR, "Error while preparing edit!")
 def VVnXBE(self, curRowNum):
  VV796F = self.VVO9k9()
  VVDle6 = ("Save Changes" , self.VVyin2   , [])
  VVOPmD  = ("Edit Line"  , self.VVp4cJ    , [])
  VVPOPD = ("Options"  , self.VVzGuI  , [])
  VVUum8 = ("Line Options" , self.VVYZAy   , [])
  VVAWwW = (""    , self.VVR4Ia , [])
  VVfT1c = self.VVKoH0
  VVj6l9  = self.VVPteL
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVxWCE  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFvfpt(self.VVgabR, None, title=self.Title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, width=1600, height=1000, VVH0vt=26, isEditor=True, VVDle6=VVDle6, VVOPmD=VVOPmD, VVPOPD=VVPOPD, VVUum8=VVUum8, VVfT1c=VVfT1c, VVj6l9=VVj6l9, VVAWwW=VVAWwW, VVNWl5=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVChAx="#05333333", VVDQNf="#00303030", VV4UX1="#11331133")
  self.editorTable.VVfMAJ(curRowNum)
 def VVPteL(self, VVhkUd):
  VVhkUd.VVSegU()
 def VVzGuI(self, VVhkUd, title, txt, colList):
  VVutlQ = []
  VVutlQ.append(("Go to Line Num" , "toLine"))
  VVutlQ.append(("Find & Replace" , "repl"))
  FFre61(self.VVgabR, self.VVmO4y, VVutlQ=VVutlQ, width=500, title="Options", VVNxG7=True)
 def VVmO4y(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVjD4H()
   elif ref == "repl"  : self.VVfnDc(title)
 def VVfnDc(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVOPmD  = ("Change" , BF(self.VVQZQA, title, lst) , [])
  VVDle6 = ("Start" , BF(self.VVWU37, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VVxWCE = (LEFT   , LEFT  , CENTER)
  FFvfpt(self.VVgabR, None, title=title, VVUel6=lst, header=header, VVxWCE=VVxWCE, VVFNzW=widths, width=1200, VVH0vt=30, isEditor=True, VVOPmD=VVOPmD, VVDle6=VVDle6, VV6Uvt=2
    , VVRdqN=bg, VVkSGg=bg, VVTJDG=bg, VVChAx="#06224455", VVDQNf="#0a303030")
 def VVQZQA(self, Title, lst, VVhkUd, title, txt, colList):
  title = VVhkUd.VVxwcf(0)
  ndx = VVhkUd.VVSWzf()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FFuRfO(self.VVgabR, BF(self.VVTjlq, VVhkUd, ndx), title=title, defaultText=txt, message="New entry")
 def VVTjlq(self, VVhkUd, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FF3Ual(CFG.lastFindRepl_fnd, newTxt)
   else  : FF3Ual(CFG.lastFindRepl_rpl, newTxt)
   VVhkUd.VVtaQs({1:newTxt, 2:len(newTxt)})
 def VVWU37(self, Title, VVhkUd, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFXk75(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFfbEx(self.VVgabR, BF(FFVvl9, VVhkUd, BF(self.VVUvlu, VVhkUd, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFhSFw(VVhkUd, "Not found in file !", 1000)
    VVhkUd.VVfMAJ(0)
  else:
   FFhSFw(VVhkUd, "Nothing to find", 1000)
 def VVUvlu(self, VVhkUd, fnd, rpl):
  txt = FFXk75(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVhkUd.cancel()
  self.fileChanged = True
  self.editorTable.VVOPTG()
  VV796F = self.VVO9k9()
  self.editorTable.VVoiHv(VV796F)
 def VVjD4H(self):
  totRows = self.editorTable.VVc8ws()
  lineNum = self.editorTable.VVSWzf() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFuRfO(self.VVgabR, BF(self.VVYA4A, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVYA4A(self, lineNum, totRows, VVF3qs):
  if VVF3qs:
   VVF3qs = VVF3qs.strip()
   if VVF3qs.isdigit():
    num = FFl54W(int(VVF3qs) - 1, 0, totRows)
    self.editorTable.VVfMAJ(num)
    self.lastLineNum = num + 1
   else:
    FFhSFw(self.editorTable, "Incorrect number", 1500)
 def VVYZAy(self, VVhkUd, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVhkUd.VVA2PV()
  VVutlQ = []
  VVutlQ.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVutlQ.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VV7fGr"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVtufY:
   VVutlQ.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(  ("Delete Line"         , "deleteLine"   ))
  FFre61(self.VVgabR, BF(self.VVciRy, lineNum), VVutlQ=VVutlQ, title="Line Options")
 def VVciRy(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVmssA("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VV7fGr"  : self.VV7fGr(lineNum)
   elif item == "copyToClipboard"  : self.VV9hzf(lineNum)
   elif item == "pasteFromClipboard" : self.VViZM2(lineNum)
   elif item == "deleteLine"   : self.VVmssA("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VVR4Ia(self, VVhkUd, title, txt, colList):
  if   self.insertMode == 1: VVhkUd.VVmBIp()
  elif self.insertMode == 2: VVhkUd.VVXXgH()
  self.insertMode = 0
 def VV7fGr(self, lineNum):
  if lineNum == self.editorTable.VVA2PV():
   self.insertMode = 1
   self.VVmssA("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VVmssA("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VV9hzf(self, lineNum):
  global VVtufY
  VVtufY = FF7jZM("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVRR2a("Copied to clipboard")
 def VVyin2(self, VVhkUd, title, txt, colList):
  if self.fileChanged:
   if FF7q9A(self.origFile):
    if FF2ufE("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVhkUd.VVRR2a("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVhkUd.VVSegU()
    else:
     FF9Njt(self.VVgabR, "Cannot save file!")
   else:
    FF9Njt(self.VVgabR, "Cannot create backup copy of original file!")
 def VVKoH0(self, VVhkUd):
  if self.fileChanged:
   FFfbEx(self.VVgabR, BF(self.VVNsD9, VVhkUd), "Cancel changes ?")
  else:
   FF2ufE("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVNsD9(VVhkUd)
 def VVNsD9(self, VVhkUd):
  VVhkUd.cancel()
  FFEUy9(self.tmpFile)
  if self.VVFqvg:
   self.VVFqvg(self.fileSaved)
 def VVp4cJ(self, VVhkUd, title, txt, colList):
  lineNum = int(VVhkUd.VVxwcf(0))
  lineTxt = VVhkUd.VVxwcf(1, isStrip=False)
  message = VV15Fs + "ORIGINAL TEXT:\n" + VVBhz1 + lineTxt
  FFuRfO(self.VVgabR, BF(self.VVhAXB, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVhAXB(self, lineNum, VVF3qs):
  if not VVF3qs is None:
   if self.editorTable.VVA2PV() <= 1:
    self.VVmssA("echo %s > '%s'" % (VVF3qs, self.tmpFile))
   else:
    self.VVUwi8(lineNum, VVF3qs)
 def VViZM2(self, lineNum):
  if lineNum == self.editorTable.VVA2PV() and self.editorTable.VVA2PV() == 1:
   self.VVmssA("echo %s >> '%s'" % (VVtufY, self.tmpFile))
  else:
   self.VVUwi8(lineNum, VVtufY)
 def VVUwi8(self, lineNum, newTxt):
  self.editorTable.VVsbUP("Saving ...")
  lines = FF6UEw(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVOPTG()
  VV796F = self.VVO9k9()
  self.editorTable.VVoiHv(VV796F)
 def VVmssA(self, cmd):
  tCons = CC4u2A()
  tCons.ePopen(cmd, self.VVIklb)
  self.fileChanged = True
  self.editorTable.VVOPTG()
 def VVIklb(self, result, retval):
  VV796F = self.VVO9k9()
  self.editorTable.VVoiHv(VV796F)
 def VVO9k9(self):
  if fileExists(self.tmpFile):
   lines = FF6UEw(self.tmpFile)
   VV796F = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV796F.append((str(ndx), line))
   if not VV796F:
    VV796F.append((str(1), ""))
   return VV796F
  else:
   FFvsvw(self.VVgabR, self.tmpFile)
class CCtamE():
 def __init__(self, callingSELF, VVRdqN="#22003344", VVkSGg="#22002233"):
  self.callingSELF = callingSELF
  self.VVutlQ  = []
  self.satList  = []
  self.VVRdqN  = VVRdqN
  self.VVkSGg   = VVkSGg
 def VVKEz5(self, VVFqvg):
  self.VVutlQ = []
  VVutlQ, VVZLh1 = CCtamE.VVrIwr(self.callingSELF, False, True)
  if VVutlQ:
   self.VVutlQ += VVutlQ
   self.VVjEqY(VVFqvg, VVZLh1)
 def VVIvwl(self, mode, VVhkUd, satCol, VVFqvg, inFilterFnc=None):
  VVhkUd.VVsbUP("Loading Filters ...")
  self.VVutlQ = []
  self.VVutlQ.append(("All Services" , "all"))
  if mode == 1:
   self.VVutlQ.append(VVJKCZ)
   self.VVutlQ.append(("Parental Control", "parentalControl" ))
   self.VVutlQ.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVutlQ.append(VVJKCZ)
   self.VVutlQ.append(("Selected Transponder"   , "selectedTP" ))
   self.VVutlQ.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VViMY3(VVhkUd, satCol)
  VVutlQ, VVZLh1 = CCtamE.VVrIwr(self.callingSELF, True, False)
  if VVutlQ:
   VVutlQ.insert(0, FFODSa("Custom Words"))
   self.VVutlQ += VVutlQ
  VVhkUd.VVmw4V()
  self.VVjEqY(VVFqvg, VVZLh1, inFilterFnc)
 def VVo6vS(self, VVutlQ, sats, VVFqvg, inFilterFnc=None):
  self.VVutlQ = VVutlQ
  VVutlQ, VVZLh1 = CCtamE.VVrIwr(self.callingSELF, True, False)
  if VVutlQ:
   self.VVutlQ.append(FFODSa("Custom Words"))
   self.VVutlQ += VVutlQ
  self.VVjEqY(VVFqvg, VVZLh1, inFilterFnc)
 def VVjEqY(self, VVFqvg, VVZLh1, inFilterFnc=None):
  VVzsZa  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVMTOL = ("Edit Filter"  , BF(self.VVPN4T, VVZLh1))
  VVmhL9  = ("Filter Help"  , BF(self.VVzjX1, VVZLh1))
  FFre61(self.callingSELF, BF(self.VVeZLi, VVFqvg), VVutlQ=self.VVutlQ, title="Select Filter", VVzsZa=VVzsZa, VVMTOL=VVMTOL, VVmhL9=VVmhL9, VVLIB1=True, VVRdqN=self.VVRdqN, VVkSGg=self.VVkSGg)
 def VVeZLi(self, VVFqvg, item):
  if item:
   VVFqvg(item)
 def VVPN4T(self, VVZLh1, selectionObj, sel):
  if fileExists(VVZLh1) : CCc3G0(self.callingSELF, VVZLh1, VVFqvg=None)
  else       : FFvsvw(self.callingSELF, VVZLh1)
  selectionObj.cancel()
 def VVzjX1(self, VVZLh1, selectionObj, sel):
  FF1D9G(self.callingSELF, "_help_service_filter", "Service Filter")
 def VViMY3(self, VVhkUd, satColNum):
  if not self.satList:
   satList = VVhkUd.VVT6PQ(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFv6HB(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFODSa("Satellites"))
  if self.VVutlQ:
   self.VVutlQ += self.satList
 @staticmethod
 def VVrIwr(SELF, addTag, VVJLdL):
  FFlcwU()
  fileName  = "ajpanel_services_filter"
  VVZLh1 = VVUQHY + fileName
  VVutlQ  = []
  if not fileExists(VVZLh1):
   FF2ufE("cp -f '%s' '%s'" % (VV8pP1 + fileName, VVZLh1))
  fileFound = False
  if fileExists(VVZLh1):
   fileFound = True
   lines = FF6UEw(VVZLh1)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVutlQ.append((line, "__w__" + line))
       else  : VVutlQ.append((line, line))
  if VVJLdL:
   if   not fileFound : FFvsvw(SELF, VVZLh1)
   elif not VVutlQ : FFBhlv(SELF, VVZLh1)
  return VVutlQ, VVZLh1
 @staticmethod
 def VVy75H(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCoGI2():
 def __init__(self, callingSELF, VVhkUd, addSep=True):
  self.callingSELF = callingSELF
  self.VVhkUd = VVhkUd
  self.VVutlQ = []
  iMulSel = self.VVhkUd.VVsOQV()
  if iMulSel : self.VVutlQ.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVutlQ.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVhkUd.VVznW9()
  self.VVutlQ.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVutlQ.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVutlQ.append(VVJKCZ)
 def VVZZ7l(self, extraMenu, cbFncDict, width=1000, okFnc=None, onMultiSelFnc=None):
  self.VVhkUd.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVutlQ.extend(extraMenu)
  FFre61(self.callingSELF, BF(self.VVw15t, cbFncDict, okFnc), width=width, title="Options", VVutlQ=self.VVutlQ)
 def VVw15t(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVhkUd.VVGaoF(True)
   elif item == "MultSelDisab" : self.VVhkUd.VVGaoF(False)
   elif item == "selectAll" : self.VVhkUd.VV4ooJ()
   elif item == "unselectAll" : self.VVhkUd.VVaYvW()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCv63H(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVtyom, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFk1xo(self)
  FFWr7z(self["keyRed"]  , "Exit")
  FFWr7z(self["keyGreen"]  , "Save")
  FFWr7z(self["keyYellow"] , "Refresh")
  FFWr7z(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VVyU28,
  {
   "red" : self.VVTVMW  ,
   "green" : self.VVzUZV ,
   "yellow": self.VVpbzX  ,
   "blue" : self.VVf6NO   ,
   "up" : self.VVDWrv    ,
   "down" : self.VV2Slw   ,
   "left" : self.VVY4Ig   ,
   "right" : self.VV85da   ,
   "cancel": self.VVTVMW
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self.VVpbzX()
  self.VVuv4N()
  FFlx3W(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVbHzR)
  except:
   self.timer.callback.append(self.VVbHzR)
  self.timer.start(1000, False)
  self.VVbHzR()
 def onExit(self):
  self.timer.stop()
 def VVTVMW(self) : self.close(True)
 def VVmUDq(self) : self.close(False)
 def VVf6NO(self):
  self.session.openWithCallback(self.VVsyCn, BF(CCdLJv))
 def VVsyCn(self, closeAll):
  if closeAll:
   self.close()
 def VVbHzR(self):
  self["curTime"].setText(str(FFaLO4(iTime())))
 def VVDWrv(self):
  self.VV2L3M(1)
 def VV2Slw(self):
  self.VV2L3M(-1)
 def VVY4Ig(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVuv4N()
 def VV85da(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVuv4N()
 def VV2L3M(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVf8V7(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVf8V7(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVf8V7(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVn0Z6(year)):
   days += 1
  return days
 def VVn0Z6(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVuv4N(self):
  for obj in self.list:
   FFiva8(obj, "#11404040")
  FFiva8(self.list[self.index], "#11ff8000")
 def VVpbzX(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVzUZV(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC4u2A()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVm2Bq)
 def VVm2Bq(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFmMPS(self, "Nothing returned from the system!")
  else    : FFmMPS(self, str(result))
class CCdLJv(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVDjOq, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFk1xo(self, addLabel=True)
  FFWr7z(self["keyRed"]  , "Exit")
  FFWr7z(self["keyGreen"]  , "Sync")
  FFWr7z(self["keyYellow"] , "Refresh")
  FFWr7z(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VVyU28,
  {
   "red" : self.VVTVMW   ,
   "green" : self.VV7noj  ,
   "yellow": self.VVMhye ,
   "blue" : self.VVTNcV  ,
   "cancel": self.VVTVMW
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVanXb()
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  FFlx3W(self)
  FFciRl(self.VVz7Lg)
 def VVz7Lg(self):
  self.VVKfWO()
  self.VVF4qp(False)
 def VVTVMW(self)  : self.close(True)
 def VVTNcV(self) : self.close(False)
 def VVanXb(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVKfWO(self):
  self.VVigT1()
  self.VVpFDO()
  self.VViKJE()
  self.VVLKvl()
 def VVMhye(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVanXb()
   self.VVKfWO()
   FFciRl(self.VVz7Lg)
 def VV7noj(self):
  if len(self["keyGreen"].getText()) > 0:
   FFfbEx(self, self.VVitPd, "Synchronize with Internet Date/Time ?")
 def VVitPd(self):
  self.VVKfWO()
  FFciRl(BF(self.VVF4qp, True))
 def VVigT1(self)  : self["keyRed"].show()
 def VVdtfh(self)  : self["keyGreen"].show()
 def VVnv54(self) : self["keyYellow"].show()
 def VVnlmc(self)  : self["keyBlue"].show()
 def VVpFDO(self)  : self["keyGreen"].hide()
 def VViKJE(self) : self["keyYellow"].hide()
 def VVLKvl(self)  : self["keyBlue"].hide()
 def VVF4qp(self, sync):
  localTime = FFExv2()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVqJ7t(server)
   if epoch_time is not None:
    ntpTime = FFaLO4(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC4u2A()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVm2Bq, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVnv54()
  self.VVnlmc()
  if ok:
   self.VVdtfh()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVm2Bq(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVF4qp(False)
  except:
   pass
 def VVqJ7t(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCYYaf.VVmh4s():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCTbQH(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFzoo9(VVDaED, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFk1xo(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFciRl(self.VVWXpt)
 def VVWXpt(self):
  if CCYYaf.VVmh4s() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFiva8(self["myBody"], color)
   FFiva8(self["myLabel"], color)
  except:
   pass
class CCI10Q(Screen):
 VVnf3Q = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFUXKU()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFzoo9(VV9TYj, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CClbQu(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CClbQu(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CClbQu(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCfiOU()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFk1xo(self, title="Signal")
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok"  : self.close      ,
   "up"  : self.VVDWrv       ,
   "down"  : self.VV2Slw      ,
   "left"  : self.VVY4Ig      ,
   "right"  : self.VV85da      ,
   "info"  : self.VVXhax     ,
   "epg"  : self.VVXhax     ,
   "menu"  : self.VVgovm      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VV6Pk5, -1)  ,
   "next"  : BF(self.VV6Pk5, 1)  ,
   "pageUp" : BF(self.VVXLVk, True) ,
   "chanUp" : BF(self.VVXLVk, True) ,
   "pageDown" : BF(self.VVXLVk, False) ,
   "chanDown" : BF(self.VVXLVk, False) ,
   "0"   : BF(self.VV6Pk5, 0)  ,
   "1"   : BF(self.VVJn2r, pos=1) ,
   "2"   : BF(self.VVJn2r, pos=2) ,
   "3"   : BF(self.VVJn2r, pos=3) ,
   "4"   : BF(self.VVJn2r, pos=4) ,
   "5"   : BF(self.VVJn2r, pos=5) ,
   "6"   : BF(self.VVJn2r, pos=6) ,
   "7"   : BF(self.VVJn2r, pos=7) ,
   "8"   : BF(self.VVJn2r, pos=8) ,
   "9"   : BF(self.VVJn2r, pos=9) ,
  }, -1)
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  if not CCI10Q.VVnf3Q:
   CCI10Q.VVnf3Q = self
  self.sliderSNR.VVB3bk()
  self.sliderAGC.VVB3bk()
  self.sliderBER.VVB3bk(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVJn2r()
  self.VVTMFV()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVJ1Vs)
  except:
   self.timer.callback.append(self.VVJ1Vs)
  self.timer.start(500, False)
 def VVTMFV(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVO2ia(service)
  serviceName = self.tunerInfo.VVGBfG()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  tp = CCSt6f()
  tpTxt, satTxt = tp.VVM9Ow(refCode)
  if tpTxt == "?" :
   tpTxt = FF0D7j("NO SIGNAL", VVO7vL)
  self["myTPInfo"].setText(tpTxt + "  " + FF0D7j(satTxt, VVPr8g))
 def VVJ1Vs(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVO2ia(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVmPBC())
   self["mySNR"].setText(self.tunerInfo.VVU8lF())
   self["myAGC"].setText(self.tunerInfo.VVNFED())
   self["myBER"].setText(self.tunerInfo.VVxFKM())
   self.sliderSNR.VVc3EZ(self.tunerInfo.VVMWuT())
   self.sliderAGC.VVc3EZ(self.tunerInfo.VVZ4ih())
   self.sliderBER.VVc3EZ(self.tunerInfo.VVfb5N())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVc3EZ(0)
   self.sliderAGC.VVc3EZ(0)
   self.sliderBER.VVc3EZ(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
    if state and not state == "Tuned":
     FFhSFw(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVXhax(self):
  FF0gQ0(self, fncMode=CCY1HC.VVkglL)
 def VVgovm(self):
  FF1D9G(self, "_help_signal", "Signal Monitor (Keys)")
 def VVDWrv(self)  : self.VVJn2r(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV2Slw(self) : self.VVJn2r(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVY4Ig(self) : self.VVJn2r(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV85da(self) : self.VVJn2r(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVJn2r(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FF3Ual(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV6Pk5(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFl54W(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FF3Ual(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCI10Q.VVnf3Q = None
 def VVXLVk(self, isUp):
  FFhSFw(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVTMFV()
  except:
   pass
class CClbQu(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVB3bk(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFiva8(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV8pP1 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFiva8(self.covObj, self.covColor)
   else:
    FFiva8(self.covObj, "#00006688")
    self.isColormode = True
  self.VVc3EZ(0)
 def VVc3EZ(self, val):
  val  = FFl54W(val, self.minN, self.maxN)
  width = int(FFTJBw(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFl54W(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC1jbq(Screen):
 VVlB2I    = 0
 VVsWWa = 1
 VVNthX = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVFqvg=None, barTheme=VVlB2I, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVirKx(barTheme)
  self.skin, self.skinParam = FFzoo9(VVsFyt, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVFqvg = VVFqvg
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVeIVc = None
  self.timer   = eTimer()
  self.myThread  = None
  FFk1xo(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VVyU28, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self.VVj3Lg()
  self["myProgBarVal"].setText("0%")
  FFiva8(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVlsbu()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVlsbu)
  except:
   self.timer.callback.append(self.VVlsbu)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VV7hIf(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVvM6s(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVeIVc), self.counter, self.maxValue, catName)
 def VVxpa1(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV1eIu(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVThQs(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVgJEk(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVxRn8(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVnUuP(self, txt):
  self.newTitle = txt
 def VVRbmv(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVeIVc), self.counter, self.maxValue)
  except:
   pass
 def VVyAiu(self, val):
  try:
   self.counter = val
  except:
   pass
 def VV1CUf(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV2m3h(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFhSFw(self, "Cancelling ...")
  self.isCancelled = True
  self.VVbhC0(False)
 def VVbhC0(self, isDone):
  FFciRl(BF(self.VVW6Qh, isDone))
 def VVW6Qh(self, isDone):
  if self.VVFqvg:
   self.VVFqvg(isDone, self.VVeIVc, self.counter, self.maxValue, self.isError)
  self.close()
 def VVlsbu(self):
  val = FFl54W(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFTJBw(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVbhC0(True)
 def VVj3Lg(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVsWWa, self.VVNthX):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVirKx(self, barTheme):
  if   barTheme == self.VVsWWa : return 0.7
  if   barTheme == self.VVNthX : return 0.5
  else             : return 1
class CC4u2A(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVFqvg = {}
  self.commandRunning = False
  self.VVb8Ad  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVFqvg, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVFqvg[name] = VVFqvg
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVb8Ad:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVOd7E, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVMshO , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVOd7E, name))
    self.appContainers[name].appClosed.append(BF(self.VVMshO , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVMshO(name, retval)
  return True
 def VVOd7E(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FF0D7j("[UN-DECODED STRING]", VVO7vL))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVMshO(self, name, retval):
  if not self.VVb8Ad:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVFqvg[name]:
   self.VVFqvg[name](self.appResults[name], retval)
  del self.VVFqvg[name]
 def VVF2Ix(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCIEmq(Screen):
 def __init__(self, session, title="", VVNDa4=None, VV5TVy=False, VVjMdX=False, VVhnmM=False, VV89vt=False, VVjC3w=False, VVKCNR=False, VVognF=VVb3Z6, VVsWF3=None, VVyuRo=False, VVivQn=None, VVxGOu="", checkNetAccess=False, VVH0vt=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFzoo9(VVJPgr, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVH0vt, usefixedFont=consFont)
  self.session   = session
  self.VVxGOu = VVxGOu
  FFk1xo(self, addScrollLabel=True)
  self.VV5TVy   = VV5TVy
  self.VVjMdX   = VVjMdX
  self.VVhnmM   = VVhnmM
  self.VV89vt  = VV89vt
  self.VVjC3w = VVjC3w
  self.VVKCNR = VVKCNR
  self.VVognF   = VVognF
  self.VVsWF3 = VVsWF3
  self.VVyuRo  = VVyuRo
  self.VVivQn  = VVivQn
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC4u2A()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFfwaK()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVNDa4, str):
   self.VVNDa4 = [VVNDa4]
  else:
   self.VVNDa4 = VVNDa4
  if self.VVhnmM or self.VV89vt:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVNDa4.append("echo -e '\n%s\n' %s" % (restartNote, FFLPjB(restartNote, VVRkew)))
   if self.VVhnmM:
    self.VVNDa4.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVNDa4.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVjC3w:
   FFhSFw(self, "Processing ...")
  self.onLayoutFinish.append(self.VVzbkI)
  self.onClose.append(self.VVZIIt)
 def VVzbkI(self):
  self["myLabel"].VVABQW(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVxGOu or "Processing ..."))
  if self.VV5TVy:
   self["myLabel"].VVydFj()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVGxh5()
  else:
   self.VV9mGc()
 def VVGxh5(self):
  if CCYYaf.VVmh4s():
   self["myLabel"].setText("Processing ...")
   self.VV9mGc()
  else:
   self["myLabel"].setText(FF0D7j("\n   No connection to internet!", VVUS1a))
 def VV9mGc(self):
  allOK = self.container.ePopen(self.VVNDa4[0], self.VVxoIY, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVxoIY("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVKCNR or self.VVhnmM or self.VV89vt:
    self["myLabel"].setText(FFl9yk("STARTED", VVRkew) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVivQn:
   colorWhite = CCcW2f.VVNgBs(VV15Fs)
   color  = CCcW2f.VVNgBs(self.VVivQn[0])
   words  = self.VVivQn[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVognF=self.VVognF)
 def VVxoIY(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVNDa4):
   allOK = self.container.ePopen(self.VVNDa4[self.cmdNum], self.VVxoIY, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVxoIY("Cannot connect to Console!", -1)
  else:
   if self.VVjC3w and FFSHcW(self):
    FFhSFw(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVKCNR:
    self["myLabel"].appendText("\n" + FFl9yk("FINISHED", VVRkew), self.VVognF)
   if self.VV5TVy or self.VVjMdX:
    self["myLabel"].VVydFj()
   if self.VVsWF3 is not None:
    self.VVsWF3()
   if not retval and self.VVyuRo:
    self.VVZIIt()
 def VVZIIt(self):
  if self.container.VVF2Ix():
   self.container.killAll()
class CCwp6k(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVJPgr, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVUQHY + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF7jZM("pwd") or "/home/root"
  self.container   = CC4u2A()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFk1xo(self, title="Terminal", addScrollLabel=True)
  FFWr7z(self["keyRed"] , self.exitBtnText)
  FFWr7z(self["keyGreen"] , "OK = History")
  FFWr7z(self["keyYellow"], "Menu = Custom Cmds")
  FFWr7z(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVNmU0 ,
   "cancel": self.VVkCrD  ,
   "menu" : self.VVL2HX ,
   "last" : self.VV8OOx  ,
   "next" : self.VV8OOx  ,
   "1"  : self.VV8OOx  ,
   "2"  : self.VV8OOx  ,
   "3"  : self.VV8OOx  ,
   "4"  : self.VV8OOx  ,
   "5"  : self.VV8OOx  ,
   "6"  : self.VV8OOx  ,
   "7"  : self.VV8OOx  ,
   "8"  : self.VV8OOx  ,
   "9"  : self.VV8OOx  ,
   "0"  : self.VV8OOx
  })
  self.onLayoutFinish.append(self.VVywsT)
  self.onClose.append(self.VV8t8F)
 def VVywsT(self):
  self["myLabel"].VVABQW(isResizable=False, outputFileToSave="terminal")
  FFBD6G(self["keyRed"]  , "#00ff8000")
  FFiva8(self["keyRed"]  , self.skinParam["titleColor"])
  FFiva8(self["keyGreen"]  , self.skinParam["titleColor"])
  FFiva8(self["keyYellow"] , self.skinParam["titleColor"])
  FFiva8(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV81uC(FF7jZM("date"), 5)
  result = FF7jZM("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVDcNh()
  self.VVfOzX()
 def VVfOzX(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVUQHY + "LinuxCommands.lst"
  templPath = VV8pP1 + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FF2ufE("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFIapl("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VV8t8F(self):
  if self.container.VVF2Ix():
   self.container.killAll()
   self.VV81uC("Process killed\n", 4)
   self.VVDcNh()
 def VVkCrD(self):
  if self.container.VVF2Ix():
   self.VV8t8F()
  else:
   FFfbEx(self, self.close, "Exit ?", VVNwKe=False)
 def VVDcNh(self):
  self.VV81uC(self.prompt, 1)
  self["keyRed"].hide()
 def VV81uC(self, txt, mode):
  if   mode == 1 : color = VVRkew
  elif mode == 2 : color = VVJTsP
  elif mode == 3 : color = VV15Fs
  elif mode == 4 : color = VVUS1a
  elif mode == 5 : color = VVBhz1
  elif mode == 6 : color = VVwos9
  else   : color = VV15Fs
  try:
   self["myLabel"].appendText(FF0D7j(txt, color))
  except:
   pass
 def VVNmU0(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVVyoh() == "":
   self.VVsl4q("cd /tmp")
   self.VVsl4q("ls")
  VV796F = []
  if fileExists(self.commandHistoryFile):
   lines  = FF6UEw(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV796F.append((str(c), line, str(lNum)))
   self.VVFavi(VV796F, title, self.commandHistoryFile, isHistory=True)
  else:
   FFvsvw(self, self.commandHistoryFile, title=title)
 def VVVyoh(self):
  lastLine = FF7jZM("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVsl4q(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVL2HX(self, VVhkUd=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FF6UEw(self.customCommandsFile)
   VV796F = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV796F.append((str(c), line, str(lNum)))
   if VVhkUd:
    VVhkUd.VVoiHv(VV796F)
    VVhkUd.VVfMAJ(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVFavi(VV796F, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFvsvw(self, self.customCommandsFile, title=title)
 def VVFavi(self, VV796F, title, filePath=None, isHistory=False):
  if VV796F:
   VVChAx = "#05333333"
   if isHistory: VVRdqN = VVkSGg = VVTJDG = "#11000020"
   else  : VVRdqN = VVkSGg = VVTJDG = "#06002020"
   VVOPmD   = ("Send"   , BF(self.VVupsP, isHistory)  , [])
   VVDle6  = ("Modify & Send" , self.VVmzdA     , [])
   if isHistory:
    VVPOPD = ("Clear History" , self.VVJqk9     , [])
    VVUum8 = None
    VV5qt4 = None
   elif filePath:
    VVPOPD = ("Options"  , self.VVLs38      , [])
    VVUum8 = ("Edit File"  , BF(self.VV15Q9, filePath) , [])
    VV5qt4 = (""    , self.VVUZ1d     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVxWCE = (CENTER , LEFT   , CENTER )
   VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8, VV5qt4=VV5qt4, lastFindConfigObj=CFG.lastFindTerminal, VVNWl5=True, searchCol=1
         , VVRdqN=VVRdqN, VVkSGg=VVkSGg, VVTJDG=VVTJDG, VVChAx=VVChAx)
   if not isHistory:
    VVhkUd.VVfMAJ(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFfbEx(self, BF(self.VVI1xd, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVUZ1d(self, VVhkUd, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FF0D7j("Command:", VVPr8g), colList[1])
  txt += "%s\n%s\n\n" % (FF0D7j("Line %s in File:" % colList[2], VVPr8g), self.customCommandsFile)
  FFEso0(self, txt, title=title)
 def VVLs38(self, VVhkUd, title, txt, colList):
  mSel = CCoGI2(self, VVhkUd)
  VVutlQ = []
  txt1 = "Change Custom Commands File"
  if VVhkUd.VVs7XH:
   VVutlQ.append((txt1, ))
   VVutlQ.append(VVJKCZ)
   totSel = VVhkUd.VVznW9()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FF0D7j(totTxt, VVRkew) if totSel else totTxt, FFCMcT(totSel))
   VVutlQ.append((txt2, "send") if totSel else (txt2,))
  else:
   VVutlQ.append((txt1, "newFile"))
   VVutlQ.append(VVJKCZ)
   txt2 = "Send current line"
   VVutlQ.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVI1xd, VVhkUd, txt1)
     , "send" : BF(self.VVupsP, False, VVhkUd, title, txt2, colList) }
  mSel.VVZZ7l(VVutlQ, cbFncDict, okFnc=BF(self.VVY4PR, VVhkUd))
 def VVI1xd(self, VVhkUd, title):
  VVutlQ = []
  for fName in os.listdir(VVUQHY):
   path = os.path.join(VVUQHY, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVutlQ.append((fName, path))
  VVutlQ.sort(key=lambda x: x[0].lower())
  if VVutlQ : FFre61(self, BF(self.VVzIWy, VVhkUd, title), VVutlQ=VVutlQ, title=title, minRows=3, VVRdqN="#11220000", VVkSGg="#11220000")
  else  : FF9Njt(self, "No valid files found in:\n\n%s" % VVUQHY, title=title)
 def VVzIWy(self, VVhkUd, title, path=None):
  if path:
   if CCLSXF.VV0Q6W(path):
    FF9Njt(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FF6UEw(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FF3Ual(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FF3Ual(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVL2HX(VVhkUd)
      break
    else:
     FF9Njt(self, "File is empty:\n\n%s" % path, title=title)
 def VVY4PR(self, VVhkUd):
  if VVhkUd.VVs7XH : VVhkUd.VVSegU()
  else        : VVhkUd.VVOPTG()
 def VVupsP(self, isHistory, VVhkUd, title, txt, colList):
  if VVhkUd.VVs7XH:
   lst = VVhkUd.VVd77Z(1)
   curNdx = VVhkUd.VVQijQ()
  else:
   lst = [colList[1]]
   curNdx = VVhkUd.VVSWzf()
  if not isHistory:
   FF3Ual(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVhkUd.cancel()
  FFciRl(self.VVPTd9)
 def VVPTd9(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VV81uC("\n%s\n" % cmd, 6)
    self.VV81uC(self.prompt, 1)
    self.VVPTd9()
   else:
    self.VVRlW6(cmd)
 def VVRlW6(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV81uC(cmd, 2)
   self.VV81uC("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV81uC(ch, 0)
   self.VV81uC("\nor\n", 4)
   self.VV81uC("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVDcNh()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF0D7j(parts[0].strip(), VVJTsP)
    right = FF0D7j("#" + parts[1].strip(), VVwos9)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV81uC(txt, 2)
   lastLine = self.VVVyoh()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVsl4q(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVxoIY, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF9Njt(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV81uC(data, 3)
 def VVxoIY(self, data, retval):
  if not retval == 0:
   self.VV81uC("Exit Code : %d\n" % retval, 4)
  self.VVDcNh()
  if self.commandsList:
   self.VVPTd9()
 def VVmzdA(self, VVhkUd, title, txt, colList):
  if VVhkUd.VVpsVv():
   cmd = colList[1]
   self.VVHMDD(VVhkUd, cmd)
 def VVJqk9(self, VVhkUd, title, txt, colList):
  FFfbEx(self, BF(self.VVJWvX, VVhkUd), "Reset History File ?", title="Command History")
 def VVJWvX(self, VVhkUd):
  FFIapl("> '%s'" % self.commandHistoryFile)
  VVhkUd.cancel()
 def VV15Q9(self, filePath, VVhkUd, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCc3G0(self, filePath, VVFqvg=BF(self.VVyc4r, VVhkUd), curRowNum=rowNum)
  else     : FFvsvw(self, filePath)
 def VVyc4r(self, VVhkUd, fileChanged):
  if fileChanged:
   VVhkUd.cancel()
   FFciRl(self.VVL2HX)
 def VV8OOx(self):
  self.VVHMDD(None, self.lastCommand)
 def VVHMDD(self, VVhkUd, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFuRfO(self, BF(self.VVKOiB, VVhkUd), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVKOiB(self, VVhkUd, cmd):
  if cmd and len(cmd) > 0:
   self.VVRlW6(cmd)
   if VVhkUd:
    VVhkUd.cancel()
class CCJXhR(Screen):
 def __init__(self, session, title="", message="", VVognF=VVb3Z6, width=1400, height=900, VVz31H=False, titleBg="#22002020", VVTJDG="#22001122", VVH0vt=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFzoo9(VVJPgr, width, height, titleFontSize, 30, 20, titleBg, VVTJDG, VVH0vt)
  self.session   = session
  FFk1xo(self, title, addScrollLabel=True)
  self.VVognF   = VVognF
  self.VVz31H   = VVz31H
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self["myLabel"].VVABQW(VVz31H=self.VVz31H, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVognF)
  self["myLabel"].VVydFj()
class CCq1i7(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFzoo9(VVQVkn, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFk1xo(self, " ", addCloser=True)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  CCfirR.VVQPUc(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCigZo(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFzoo9(VVR8Wn, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFk1xo(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFHeVW(self["errPic"], "err")
class CCtfd1(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFzoo9(VVQVkn, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFk1xo(self, " ", addCloser=True)
class CCfirR():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCfirR.VV6zn8(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVXgkU)
  except: self.timer.callback.append(self.VVXgkU)
  self.timer.start(timeout, True)
 def VVXgkU(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VV6zn8(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCtfd1, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFlK3z(win["myWinTitle"], shadColor, shadW)
  CCfirR.VVQPUc(win, txt)
  return win
 @staticmethod
 def VVQPUc(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCkpqq():
 VVdPrY    = 0
 VVgcMu  = 1
 VVm3nI   = ""
 VV4LFd    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVhkUd   = None
  self.timer     = eTimer()
  self.VVEoIT   = 0
  self.VVhm2z  = 1
  self.VVZcIl  = 2
  self.VVDn2h   = 3
  self.VVmdgo   = 4
  VV796F = self.VV06Ne()
  if VV796F:
   self.VVhkUd = self.VVwkbC(VV796F)
  if not VV796F and mode == self.VVdPrY:
   self.VVBTBJ("Download list is empty !")
   self.cancel()
  if mode == self.VVgcMu:
   FFVvl9(self.VVhkUd or self.SELF, BF(self.VVUduK, startDnld, decodedUrl), title="Checking Server ...")
  self.VVHpXa(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVHpXa)
  except:
   self.timer.callback.append(self.VVHpXa)
  self.timer.start(1000, False)
 def VVwkbC(self, VV796F):
  VV796F.sort(key=lambda x: int(x[0]))
  VVfT1c = self.VV3UxT
  VVOPmD  = ("Play"  , self.VVxwuQ , [])
  VV5qt4 = (""   , self.VVg2jP  , [])
  VVRsW0 = ("Stop"  , self.VVbpVs  , [])
  VVDle6 = ("Resume"  , self.VVypkc , [])
  VVPOPD = ("Options" , self.VVVXli  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVxWCE  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFvfpt(self.SELF, None, title=self.Title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVOPmD=VVOPmD, VV5qt4=VV5qt4, VVfT1c=VVfT1c, VVRsW0=VVRsW0, VVDle6=VVDle6, VVPOPD=VVPOPD, lastFindConfigObj=CFG.lastFindIptv, VVRdqN="#11220022", VVkSGg="#11110011", VVTJDG="#11110011", VVChAx="#00223025", VVDQNf="#0a333333", VV4UX1="#0a400040", VVNWl5=True, searchCol=1)
 def VV06Ne(self):
  lines = CCkpqq.VVZjDr()
  VV796F = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVkeoa(decodedUrl)
      if fName:
       if   FFeDHc(decodedUrl) : sType = "Movie"
       elif FFlS6F(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVWHgu(decodedUrl, fName)
       if size > -1: sizeTxt = CCLSXF.VVtnwF(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV796F.append((str(len(VV796F) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV796F
 def VVsy8X(self):
  VV796F = self.VV06Ne()
  if VV796F:
   if self.VVhkUd : self.VVhkUd.VVoiHv(VV796F, VVanXbMsg=False)
   else     : self.VVhkUd = self.VVwkbC(VV796F)
  else:
   self.cancel()
 def VVHpXa(self, force=False):
  if self.VVhkUd:
   thrListUrls = self.VVch07()
   VV796F = []
   changed = False
   for ndx, row in enumerate(self.VVhkUd.VVNCJx()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVEoIT
    if m3u8Log:
     percent = CCkpqq.VVYoWe(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVDn2h , "%.2f %%" % percent
      else   : flag, progr = self.VVmdgo , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFrMJ0(mPath)
     if curSize > -1:
      fSize = CCLSXF.VVtnwF(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCLSXF.VVtnwF(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFrMJ0(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVDn2h , "%.2f %%" % percent
       else   : flag, progr = self.VVmdgo , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCLSXF.VVtnwF(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVZcIl
     if m3u8Log :
      if not speed and not force : flag = self.VVhm2z
      elif curSize == -1   : self.VVfrwj(False)
    elif flag == self.VVEoIT  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVEoIT  : color2 = "#f#00555555#"
    elif flag == self.VVhm2z : color2 = "#f#0000FFFF#"
    elif flag == self.VVZcIl : color2 = "#f#0000FFFF#"
    elif flag == self.VVDn2h  : color2 = "#f#00FF8000#"
    elif flag == self.VVmdgo  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVsp6Q(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV796F.append(row)
   if changed or force:
    self.VVhkUd.VVoiHv(VV796F, VVanXbMsg=False)
 def VVsp6Q(self, flag):
  tDict = self.VVGukF()
  return tDict.get(flag, "?")
 def VVXfEH(self, state):
  for flag, txt in self.VVGukF().items():
   if txt == state:
    return flag
  return -1
 def VVGukF(self):
  return { self.VVEoIT: "Not started", self.VVhm2z: "Connecting", self.VVZcIl: "Downloading", self.VVDn2h: "Stopped", self.VVmdgo: "Completed" }
 def VVyYwr(self, title):
  colList = self.VVhkUd.VVZqZI()
  path = colList[6]
  url  = colList[8]
  if self.VVoP8l() : self.VVBTBJ("Cannot delete !\n\nFile is downloading.")
  else      : FFfbEx(self.SELF, BF(self.VVg4co, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVg4co(self, path, url):
  m3u8Log = self.VVhkUd.VVZqZI()[12]
  if m3u8Log : FF2ufE("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FF2ufE("rm -rf '%s'" % path)
  self.VVVKDe(False)
  self.VVsy8X()
 def VVVKDe(self, VVJLdL=True):
  if self.VVoP8l():
   FFhSFw(self.VVhkUd, self.VVsp6Q(self.VVZcIl), 500)
  else:
   colList  = self.VVhkUd.VVZqZI()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVXfEH(state) in (self.VVEoIT, self.VVmdgo, self.VVDn2h):
    lines = CCkpqq.VVZjDr()
    newLines = []
    found = False
    for line in lines:
     if CCkpqq.VVEnR3(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVtPE1(newLines)
     self.VVsy8X()
     FFhSFw(self.VVhkUd, "Removed.", 1000)
    else:
     FFhSFw(self.VVhkUd, "Not found.", 1000)
   elif VVJLdL:
    self.VVBTBJ("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVPgOi(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFfbEx(self.SELF, BF(self.VVW6g7, flag), ques, title=title)
 def VVW6g7(self, flag):
  list = []
  for ndx, row in enumerate(self.VVhkUd.VVNCJx()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVXfEH(state)
   if   flag == flagVal == self.VVmdgo: list.append(decodedUrl)
   elif flag == flagVal == self.VVEoIT : list.append(decodedUrl)
  lines = CCkpqq.VVZjDr()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVtPE1(newLines)
   self.VVsy8X()
   FFhSFw(self.VVhkUd, "%d removed." % totRem, 1000)
  else:
   FFhSFw(self.VVhkUd, "Not found.", 1000)
 def VVC8vy(self):
  colList  = self.VVhkUd.VVZqZI()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFhSFw(self.VVhkUd, "Poster exists", 1500)
  else    : FFVvl9(self.VVhkUd, BF(self.VVL3NM, decodedUrl, path, png), title="Checking Server ...")
 def VVL3NM(self, decodedUrl, path, png):
  err = self.VVGhg1(decodedUrl, path, png)
  if err:
   FF9Njt(self.SELF, err, title="Poster Download")
 def VVGhg1(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCLRZv.VVJYyo(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC3ZOl.VVakT8(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC3ZOl.VVxuE9(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC3ZOl.VVq4yM(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFAqj4(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FF2ufE("mv -f '%s' '%s'" % (tPath, png))
   CCMQgO.VVR5E7(self.SELF, VVQVlp=png, showGrnMsg="Downloaded")
   return ""
 def VVg2jP(self, VVhkUd, title, txt, colList):
  def VVGQB8(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVy75x(key, val) : return "\n%s:\n%s\n" % (FF0D7j(key, VVPr8g), val.strip())
  heads  = self.VVhkUd.VVIvJH()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVGQB8(heads[i]  , CCLSXF.VVtnwF(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVGQB8("Downloaded" , CCLSXF.VVtnwF(int(curSize), mode=0))
   else:
    txt += VVGQB8(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVy75x(heads[i], colList[i])
  FFEso0(self.SELF, txt, title=title)
 def VVxwuQ(self, VVhkUd, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCLSXF.VVPDp5(self.SELF, path)
  else    : FFhSFw(self.VVhkUd, "File not found", 1000)
 def VV3UxT(self, VVhkUd):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVhkUd:
   self.VVhkUd.cancel()
  del self
 def VVVXli(self, VVhkUd, title, txt, colList):
  c1, c2, c3 = VVQrak, VVUS1a, VVPr8g
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVutlQ = []
  VVutlQ.append((c1 + "Remove current row"       , "VVVKDe" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVutlQ.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Delete the file (and remove from list)"  , "VVyYwr"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((resumeTxt + " Auto Resume"       , "VVRfKB" ))
  VVutlQ.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVutlQ.append(VVJKCZ)
  cond = FFeDHc(decodedUrl)
  VVutlQ.append(FF47SM("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVC8vy", cond, c3))
  VVutlQ.append(FF47SM("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFre61(self.SELF, BF(self.VVQTlm, VVhkUd), VVutlQ=VVutlQ, title=self.Title, VVNxG7=True, width=800, VVLIB1=True, VVRdqN="#1a001122", VVkSGg="#1a001122")
 def VVQTlm(self, VVhkUd, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVVKDe"  : self.VVVKDe()
   elif ref == "remFinished"   : self.VVPgOi(self.VVmdgo, txt)
   elif ref == "remPending"   : self.VVPgOi(self.VVEoIT, txt)
   elif ref == "VVyYwr" : self.VVyYwr(txt)
   elif ref == "VVC8vy"  : self.VVC8vy()
   elif ref == "VVRfKB"  : FF3Ual(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FF3Ual(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCLSXF, mode=CCLSXF.VVlhCZ, jumpToFile=path)
    else    : FFhSFw(VVhkUd, "Path not found !", 1500)
 def VVUduK(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCLRZv.VVJYyo(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVBTBJ("Could not get download link !\n\nTry again later.")
     return
  for line in CCkpqq.VVZjDr():
   if CCkpqq.VVEnR3(decodedUrl, line):
    if self.VVhkUd:
     self.VVfnQB(decodedUrl)
     FFciRl(BF(FFhSFw, self.VVhkUd, "Already listed !", 2000))
    break
  else:
   params = self.VVRnDM(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVBTBJ(params[0])
   elif len(params) == 2:
    FFfbEx(self.SELF, BF(self.VVZmpA, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCLSXF.VVtnwF(fSize)
    FFfbEx(self.SELF, BF(self.VV7aXw, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV7aXw(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCkpqq.VVnrXa(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVsy8X()
  if self.VVhkUd:
   self.VVhkUd.VVXXgH()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCkpqq.VV4LFd, path, decodedUrl)
   self.VVgKbm(threadName, url, decodedUrl, path, resp)
 def VVfnQB(self, decodedUrl):
  if self.VVhkUd:
   for ndx, row in enumerate(self.VVhkUd.VVNCJx()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVhkUd:
     self.VVhkUd.VVfMAJ(ndx)
     break
 def VVRnDM(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVkeoa(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVWHgu(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCLRZv.VVJYyo(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCLRZv.VV8fYq()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCkpqq.VVfs86(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCkpqq.VVeHKd(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVZmpA(self, resp, decodedUrl):
  if not FFVjaP("ffmpeg"):
   FFfbEx(self.SELF, BF(CC3ZOl.VVHnAe, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVkeoa(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVi3SO(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFfbEx(self.SELF, BF(self.VVudWe, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVudWe(rTxt, rUrl)
  else:
   self.VVBTBJ("Cannot process m3u8 file !")
 def VVi3SO(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVutlQ = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC3ZOl.VVqtvl(rUrl, fPath)
   VVutlQ.append((resol, fullUrl))
  if VVutlQ:
   FFre61(self.SELF, self.VVZkMX, VVutlQ=VVutlQ, title="Resolution", VVNxG7=True, VVLIB1=True)
  else:
   self.VVBTBJ("Cannot get Resolutions list from server !")
 def VVZkMX(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFfbEx(self.SELF, BF(FFciRl, BF(self.VVp0DV, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFciRl(BF(self.VVp0DV, resolUrl))
 def VVp0DV(self, resolUrl):
  txt, err = CCLRZv.VVbnHU(resolUrl)
  if err : self.VVBTBJ(err)
  else : self.VVudWe(txt, resolUrl)
 def VVs2XZ(self, logF, decodedUrl):
  found = False
  lines = CCkpqq.VVZjDr()
  with open(CCkpqq.VVnrXa(), "w") as f:
   for line in lines:
    if CCkpqq.VVEnR3(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCkpqq.VVnrXa(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVsy8X()
  if self.VVhkUd:
   self.VVhkUd.VVXXgH()
 def VVudWe(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC3ZOl.VVqtvl(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVBTBJ("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVs2XZ(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFYhY6("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCkpqq.VV4LFd, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVYoWe(dnldLog):
  if fileExists(dnldLog):
   dur = CCkpqq.VVyMZ4(dnldLog)
   if dur > -1:
    tim = CCkpqq.VVyC81(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVyMZ4(dnldLog):
  lines = FFlfx8("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVyC81(dnldLog):
  lines = FFlfx8("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVWHgu(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFlS6F(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FF2ufE("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVgKbm(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVhkUd.VVZqZI()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVfElS, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVfElS(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVm3nI == path:
       break
     else:
      break
  except:
   return
  if CCkpqq.VVm3nI:
   CCkpqq.VVm3nI = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFrMJ0(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVRnDM(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVfElS(url, decodedUrl, path, resp, totFileSize, True)
 def VVbpVs(self, VVhkUd, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV5ckW() : FFhSFw(self.VVhkUd, self.VVsp6Q(self.VVmdgo), 500)
  elif not self.VVoP8l() : FFhSFw(self.VVhkUd, self.VVsp6Q(self.VVDn2h), 500)
  elif m3u8Log      : FFfbEx(self.SELF, self.VVfrwj, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVch07():
    CCkpqq.VVm3nI = colList[6]
    FFhSFw(self.VVhkUd, "Stopping ...", 1000)
   else:
    FFhSFw(self.VVhkUd, "Stopped", 500)
 def VVfrwj(self, withMsg=True):
  if withMsg:
   FFhSFw(self.VVhkUd, "Stopping ...", 1000)
  FF2ufE("killall -INT ffmpeg")
 def VVypkc(self, *args):
  if   self.VV5ckW() : FFhSFw(self.VVhkUd, self.VVsp6Q(self.VVmdgo) , 500)
  elif self.VVoP8l() : FFhSFw(self.VVhkUd, self.VVsp6Q(self.VVZcIl), 500)
  else:
   resume = False
   m3u8Log = self.VVhkUd.VVZqZI()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFfbEx(self.SELF, BF(self.VVMKNl, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV1yMf():
    resume = True
   if resume: FFVvl9(self.VVhkUd, BF(self.VVsX1O), title="Checking Server ...")
   else  : FFhSFw(self.VVhkUd, "Cannot resume !", 500)
 def VVMKNl(self, m3u8Log):
  FF2ufE("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFVvl9(self.VVhkUd, BF(self.VVsX1O), title="Checking Server ...")
 def VVsX1O(self):
  colList  = self.VVhkUd.VVZqZI()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCLRZv.VVJYyo(decodedUrl)
   if url:
    decodedUrl = self.VV8qEP(decodedUrl, url)
   else:
    self.VVBTBJ("Could not get download link !\n\nTry again later.")
    return
  curSize = FFrMJ0(path)
  params = self.VVRnDM(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVBTBJ(params[0])
   return
  elif len(params) == 2:
   self.VVZmpA(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VV8qEP(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCkpqq.VV4LFd, path, decodedUrl)
  if resumable: self.VVgKbm(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVBTBJ("Cannot resume from server !")
 def VVkeoa(self, decodedUrl):
  fileExt = CC3ZOl.VV3v12(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFfoad(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVBTBJ(self, txt):
  FF9Njt(self.SELF, txt, title=self.Title)
 def VVch07(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCkpqq.VV4LFd, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVoP8l(self):
  decodedUrl = self.VVhkUd.VVZqZI()[9]
  return decodedUrl in self.VVch07()
 def VV5ckW(self):
  colList = self.VVhkUd.VVZqZI()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFrMJ0(path)) == size
 def VV1yMf(self):
  colList = self.VVhkUd.VVZqZI()
  path = colList[6]
  size = int(colList[7])
  curSize = FFrMJ0(path)
  if curSize > -1:
   size -= curSize
  err = CCkpqq.VVeHKd(size)
  if err:
   FF9Njt(self.SELF, err, title=self.Title)
   return False
  return True
 def VVtPE1(self, list):
  with open(CCkpqq.VVnrXa(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VV8qEP(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCkpqq.VVZjDr()
  url = decodedUrl
  with open(CCkpqq.VVnrXa(), "w") as f:
   for line in lines:
    if CCkpqq.VVEnR3(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVsy8X()
  return url
 @staticmethod
 def VVZjDr():
  list = []
  if fileExists(CCkpqq.VVnrXa()):
   for line in FF6UEw(CCkpqq.VVnrXa()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVEnR3(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVeHKd(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCLSXF.VVf7tK(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCLSXF.VVtnwF(size), CCLSXF.VVtnwF(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVEOd2(SELF):
  tot = CCkpqq.VVwaeg()
  if tot:
   FF9Njt(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVwaeg():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCkpqq.VV4LFd):
    c += 1
  return c
 @staticmethod
 def VVmSW2():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCkpqq.VV4LFd, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVkLR8():
  return len(CCkpqq.VVZjDr()) == 0
 @staticmethod
 def VVce7A():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVSJY5():
  mPoints = CCkpqq.VVce7A()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FF2ufE("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVnrXa():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VV4eHX(SELF, waitMsgObj=None):
  FFVvl9(waitMsgObj or SELF, BF(CCkpqq.VVfke0, SELF, CCkpqq.VVdPrY))
 @staticmethod
 def VVRTdo(SELF):
  CCkpqq.VVfke0(SELF, CCkpqq.VVgcMu, startDnld=True)
 @staticmethod
 def VVriiW(SELF, url):
  CCkpqq.VVfke0(SELF, CCkpqq.VVgcMu, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVFddL(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF)
  added, skipped = CCkpqq.VVMyZ8([decodedUrl])
  FFhSFw(SELF, "Added", 1000)
 @staticmethod
 def VVMyZ8(list):
  added = skipped = 0
  for line in CCkpqq.VVZjDr():
   for ndx, url in enumerate(list):
    if url and CCkpqq.VVEnR3(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCkpqq.VVnrXa(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVfke0(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCJ0a3.VVSfC2(SELF):
   return
  if mode == CCkpqq.VVdPrY and CCkpqq.VVkLR8():
   FF9Njt(SELF, "Download list is empty !", title=title)
  else:
   inst = CCkpqq(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVfs86(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCGzpp(Screen, CC4cFe):
 VVRINw = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFzoo9(VVtlKb, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CC4cFe.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFk1xo(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVjdMB())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VVyU28,
  {
   "ok"  : self.VVQHyQ       ,
   "info"  : self.VVXhax      ,
   "epg"  : self.VVXhax      ,
   "menu"  : self.VVU3rj     ,
   "cancel" : self.cancel       ,
   "red"  : self.VV1poD   ,
   "green"  : self.VVnLA5  ,
   "blue"  : self.VVgDrU      ,
   "yellow" : self.VVOHZd ,
   "left"  : BF(self.VVcPgj, -1)    ,
   "right"  : BF(self.VVcPgj,  1)    ,
   "play"  : self.VVE65q      ,
   "pause"  : self.VVE65q      ,
   "playPause" : self.VVE65q      ,
   "stop"  : self.VVE65q      ,
   "rewind" : self.VVoe1d      ,
   "forward" : self.VVuqVF      ,
   "rewindDm" : self.VVoe1d      ,
   "forwardDm" : self.VVuqVF      ,
   "last"  : self.VVxhyk      ,
   "next"  : self.VVeecv      ,
   "pageUp" : BF(self.VVqfmm, True)  ,
   "pageDown" : BF(self.VVqfmm, False)  ,
   "chanUp" : BF(self.VVqfmm, True)  ,
   "chanDown" : BF(self.VVqfmm, False)  ,
   "up"  : BF(self.VVqfmm, True)  ,
   "down"  : BF(self.VVqfmm, False)  ,
   "audio"  : BF(self.VVHzGf, True)  ,
   "subtitle" : BF(self.VVHzGf, False)  ,
   "text"  : self.VVkMzF  ,
   "0"   : BF(self.VVuQo0 , 10)   ,
   "1"   : BF(self.VVuQo0 , 1)   ,
   "2"   : BF(self.VVuQo0 , 2)   ,
   "3"   : BF(self.VVuQo0 , 3)   ,
   "4"   : BF(self.VVuQo0 , 4)   ,
   "5"   : BF(self.VVuQo0 , 5)   ,
   "6"   : BF(self.VVuQo0 , 6)   ,
   "7"   : BF(self.VVuQo0 , 7)   ,
   "8"   : BF(self.VVuQo0 , 8)   ,
   "9"   : BF(self.VVuQo0 , 9)
  }, -1)
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  if not CCGzpp.VVRINw:
   CCGzpp.VVRINw = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFHeVW(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFHeVW(self["myPlayRpt"], "rpt")
  self.VVRkQc()
  self.instance.move(ePoint(40, 40))
  self.VVW1bn(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1Ch2)
  except:
   self.timer.callback.append(self.VV1Ch2)
  self.timer.start(250, False)
  self.VV1Ch2("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVD6rg()
 def VVnLA5(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  self.lastSubtitle = CCYYLz.VVMek8()
  if "chCode" in iptvRef:
   if CCJ0a3.VVSfC2(self):
    self.VVD6rg(True)
  else:
   self.VV1Ch2("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVRkQc(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVKadB()
  chName = FFLAHl(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVO7vL + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFiva8(self["myTitle"], tColor)
  FFiva8(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFiva8(self["myPlay%s" % item], tColor)
  picFile = CCY1HC.VVinHk(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCY1HC.VVMVwo(self)
  cl = CCl6im.VVMews(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VV1Ch2(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCkpqq.VVwaeg()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVKadB()
  if evName:
   evName = "    %s    " % FF0D7j(evName, VVBhz1)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVHWwB():
   FFBD6G(self["myPlayBlu"], "#00FFFFFF")
   FFiva8(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFBD6G(self["myPlayBlu"], "#00FFFF88")
   FFiva8(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CC3ZOl.VVFHkL(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVwos9 + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFiva8(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFl54W(percVal, 0, 100)
   width = int(FFTJBw(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFiva8(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFBD6G(self["myPlayMsg"], "#0000ffff")
   else  : FFBD6G(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFBD6G(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFBD6G(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVqcLF()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VV6bes(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCYYLz.VVTP73(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVxhyk()
  state = self.VVyNPd()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFBD6G(self["myPlayMsg"], "#0000ff00")
  else     : FFBD6G(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVKadB(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFi1IN(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCY1HC.VV30cN(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCSt6f()
   tpTxt, satTxt = tp.VVM9Ow(refCode)
   self.satInfo_TP = tpTxt + "  " + FF0D7j(satTxt, VVqWCE)
  evName = evNameNext = ""
  evLst = CCvK6a.VVsrtb(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FF78Jk(info, iServiceInformation.sVideoWidth) or -1
   h = FF78Jk(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FF78Jk(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCY1HC.VVe28b(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVFYBJ(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFnZVI(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFnZVI(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFnZVI(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVU3rj(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVKadB()
  FFeDHcSeries = FFfoad(decodedUrl)
  VVutlQ = []
  if not "VVwta1" in globals() and not "VVLdrz" in globals():
   VVutlQ.append((VVqWCE + "IPTV Menu", "iptv"))
   VVutlQ.append(VVJKCZ)
  if isIptv and not "&end=" in decodedUrl and not FFeDHcSeries:
   uType, uHost, uUser, uPass, uId, uChName = CC3ZOl.VVakT8(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVutlQ.append((VVqWCE + "Catchup Programs", "catchup" ))
    VVutlQ.append(VVJKCZ)
  if refCode:
   c = VVO7vL
   VVutlQ.append((c + "Stop Current Service"  , "stop"  ))
   VVutlQ.append((c + "Restart Current Service" , "restart"  ))
   VVutlQ.append(FF47SM("Replay with ..." , "replayWith", not isDvb, c))
   VVutlQ.append(VVJKCZ)
  if FFeDHcSeries:
   VVutlQ.append((VVqWCE + "File Size (on server)", "fileSize" ))
   VVutlQ.append(VVJKCZ)
  if self.enableDownloadMenu:
   c = VVqWCE
   addSep = False
   if isIptv and FFeDHcSeries:
    VVutlQ.append((c + "Start Download"  , "dload_cur" ))
    VVutlQ.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCkpqq.VVkLR8():
    VVutlQ.append((VVqWCE + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVutlQ.append(VVJKCZ)
  fPath, fDir, fName = CCLSXF.VVtloK(self)
  if fPath:
   c = VVFWDt
   if not "VVm0Nx" in globals():
    VVutlQ.append((c + "Open path in File Manager", "VVq1Fl"))
   VVutlQ.append((c + "Add to Bouquet"             , "VVsW90" ))
   VVutlQ.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVkhIj"  ))
   VVutlQ.append(VVJKCZ)
  elif isFtp:
   VVutlQ.append((VVPr8g + "Add FTP Media to Bouquet"     , "VVUj24"))
  if isDvb:
   VVutlQ.append((VVqWCE + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVutlQ.append((VVPr8g + "Start Subtitle", "VVcdZn"))
   VVutlQ.append(VVJKCZ)
  if CFG.playerPos.getValue() : VVutlQ.append(("Move Bar to Bottom" , "botm"))
  else      : VVutlQ.append(("Move Bar to Top" , "top" ))
  VVutlQ.append(("Help", "help"))
  FFre61(self, self.VVaqb3, VVutlQ=VVutlQ, width=600, title="Options")
 def VVaqb3(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVOHZd()
   elif item == "stop"     : self.VVNvaI(0)
   elif item == "restart"    : self.VVNvaI(1)
   elif item == "replayWith"   : self.VVbgLt()
   elif item == "fileSize"    : FFVvl9(self, BF(CCY1HC.VVq78j, self), title="Checking Server")
   elif item == "dload_cur"   : CCkpqq.VVRTdo(self)
   elif item == "addToDload"   : CCkpqq.VVFddL(self)
   elif item == "dload_stat"   : CCkpqq.VV4eHX(self)
   elif item == "VVq1Fl" : self.close("close_openInFileMan")
   elif item == "VVsW90" : self.VVsW90()
   elif item == "VVUj24" : self.VVUj24()
   elif item == "VVcdZn"  : self.VV6hO2()
   elif item == "VVkhIj"  : self.VVkhIj()
   elif item == "botm"     : self.VVW1bn(0)
   elif item == "top"     : self.VVW1bn(1)
   elif item == "sigMon"    : self.VV1poD()
   elif item == "help"     : FF1D9G(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCGzpp.VVRINw = None
 def VVNvaI(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVRkQc()
   elif typ == 1:
    self.VV1Ch2("Restarting Service ...")
    FFciRl(BF(self.VVbvF0, serv))
 def VVbvF0(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  if "&end=" in decodedUrl: BF(self.VVD6rg, True)
  else     : self.session.nav.playService(serv)
 def VVbgLt(self):
  FFre61(self, self.VVmTy6, VVutlQ=CC3ZOl.VVq62G(), width=650, title="Select Player", VVRdqN="#11220000", VVkSGg="#11220000")
 def VVmTy6(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFDSaZ(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VV1Ch2("No active service !")
 def VVsW90(self):
  fPath, fDir, fName = CCLSXF.VVtloK(self)
  if fPath: picker = CC0axI(self, self, "Add Current Movie to a Bouquet", BF(self.VVTXER, [fPath]))
  else : FFhSFw(self, "Path not found !", 1500)
 def VVTXER(self, pathLst):
  return CC0axI.VVc005(pathLst)
 def VVUj24(self):
  picker = CC0axI(self, self, "Add FTP Media to Bouquet", self.VVLceC)
 def VVLceC(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  return CC0axI.VVc005([origUrl], rType=refCode.split(":", 1)[0])
 def VVkhIj(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VV1Ch2(txt, highlight=ok)
 def VVW1bn(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FF3Ual(CFG.playerPos, pos)
 def VV1poD(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCY1HC.VV30cN(serv)
   if isDvb: self.close("close_sig")
   else : self.VV1Ch2("No Signal for Current Service")
 def VV6hO2(self):
  self.session.openWithCallback(self.VVCS88, BF(CCYYLz))
 def VVkMzF(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVKadB()
   if posTxt and durTxt: self.VV6hO2()
   else    : self.VV1Ch2("No duration Info. !")
 def VVCS88(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVqfmm(True)
  elif reason == "subtZapDn" : self.VVqfmm(False)
  elif reason == "pause"  : self.VVE65q()
  elif reason == "audio"  : self.VVHzGf(True)
  elif reason == "subtitle" : self.VVHzGf(False)
  elif reason == "rewind"     : self.VVoe1d()
  elif reason == "forward" : self.VVuqVF()
  elif reason == "rewindDm" : self.VVoe1d()
  elif reason == "forwardDm" : self.VVuqVF()
  else      : txt = reason
  if txt:
   FFhSFw(self, txt, 2000)
 def VVQHyQ(self):
  if self.isManualSeek:
   self.VVvuAa()
   self.VV6bes(self.manualSeekPts)
  elif self.shown:
   if CCYYLz.VVdw4r(self): self.VV6hO2()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVvuAa()
  else    : self.close()
 def VVXhax(self):
  FF0gQ0(self, fncMode=CCY1HC.VVfuV4)
 def VVE65q(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VV1Ch2("Toggling Play/Pause ...")
 def VVvuAa(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVcPgj(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVwvsj()
   else:
    self.manualSeekSec += direc * self.VVwvsj()
    self.manualSeekSec = FFl54W(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFTJBw(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFnZVI(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVuQo0(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVjdMB())
   FF3Ual(CFG.playerJumpMin, self.jumpMinutes)
  self.VV1Ch2("Changed Seek Time to : %d%s" % (val, self.VV76Mo()))
 def VVjdMB(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VV76Mo())
 def VV76Mo(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVPsZP(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVwvsj(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVqcLF(self):
  if "VV0P9w" in globals():
   global VV0P9w
   if VV0P9w:
    VV0P9w = VV0P9w[1:-1]
    if len(VV0P9w) == 3: VV0P9w = ""
    else     : return VV0P9w
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVgDrU(self):
  cList = self.VVHWwB()
  if cList:
   VVutlQ = []
   for pts, what in cList:
    txt = FFnZVI(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVutlQ.append((txt, pts))
   FFre61(self, self.VVOphv, VVutlQ=VVutlQ, title="Cut List")
  else:
   self.VV1Ch2("No Cut-List for this channel !")
 def VVOphv(self, item=None):
  if item:
   self.VV6bes(item)
 def VVHWwB(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVuqVF(self) : self.VV5xh9(1)
 def VVoe1d(self) : self.VV5xh9(-1)
 def VV5xh9(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVwvsj() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVPsZP())
    self.VV1Ch2(txt)
  except:
   self.VV1Ch2("Cannot jump")
 def VV6bes(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VV1Ch2("Changing Time ...")
 def VVxhyk(self):
  self.VVNvaI(1)
  self.VV1Ch2("Replaying ...")
  self.VVvuAa()
 def VVeecv(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VV1Ch2("Jumping to end ...")
  except:
   pass
 def VVyNPd(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVqfmm(self, isUp):
  if self.enableZapping:
   self.VV1Ch2("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVvuAa()
   if self.iptvTableParams:
    FFciRl(BF(self.VVQfKo, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
    if "/timeshift/" in decodedUrl:
     self.VV1Ch2("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVQ3ZQ()
  else:
   self.VV1Ch2("Zap Disabled !")
 def VVQ3ZQ(self):
  self.lastPlayPos = 0
  self.VVRkQc()
  self.VVD6rg()
 def VVQfKo(self, isUp):
  CC3ZOl_inatance, VVhkUd, mode = self.iptvTableParams
  if isUp : VVhkUd.VVk8wK()
  else : VVhkUd.VVjxS4()
  colList = VVhkUd.VVZqZI()
  if mode == "localIptv":
   chName, chUrl = CC3ZOl_inatance.VVGtsd(VVhkUd, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC3ZOl_inatance.VVTvfW(VVhkUd, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC3ZOl_inatance.VVs3yZ(mode, VVhkUd, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC3ZOl_inatance.VVx9wg(mode, VVhkUd, colList)
  else:
   self.VV1Ch2("Cannot Zap")
   return
  FFlpKW(self, chUrl, VVeuyP=False)
  self.VVQ3ZQ()
 def VVD6rg(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
   if not self.VVfbLd(refCode, chName, decodedUrl, iptvRef):
    return
   self.VV1Ch2("Refreshing Portal")
   FFciRl(self.VV4bkX)
  except:
   pass
 def VV4bkX(self):
  self.restoreLastPlayPos = self.VVsAcI()
 def VVOHZd(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
  if not decodedUrl or FFfoad(decodedUrl):
   self.VV1Ch2("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC3ZOl.VVakT8(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VV1Ch2("Reading Program List ...")
   ok_fnc = BF(self.VVzaCj, refCode, chName, streamId, uHost, uUser, uPass)
   FFciRl(BF(CC3ZOl.VVVk7T, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VV1Ch2("Cannot process this channel")
 def VVzaCj(self, refCode, chName, streamId, uHost, uUser, uPass, VVhkUd, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVhkUd.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VV1Ch2("Changing Program ...")
   FFciRl(BF(self.VVrjsZ, chUrl))
  else:
   self.VV1Ch2("Incorrect Timestamp !")
 def VVrjsZ(self, chUrl):
  FFlpKW(self, chUrl, VVeuyP=False)
  self.lastPlayPos = 0
  self.VVRkQc()
 def VVHzGf(self, isAudio):
  try:
   VV7fnz = InfoBar.instance
   if VV7fnz:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV7fnz)
    else  : self.session.open(SubtitleSelection, VV7fnz)
  except:
   pass
 @staticmethod
 def VVAM5b(session, mode=None):
  if   mode == "close_sig"   : FFR4Pq(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CC3ZOl)
  elif mode == "close_openInFileMan" : session.open(CCLSXF, gotoMovie=True)
 @staticmethod
 def VVfWLm(session, **kwargs):
  session.openWithCallback(BF(CCGzpp.VVAM5b, session), CCGzpp, **kwargs)
class CCk8OT(Screen):
 def __init__(self, session, title="", VVumEG="Continue?", VVNwKe=True, VVAbek=False):
  self.skin, self.skinParam = FFzoo9(VVJsvf, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVumEG = VVumEG
  self.VVAbek = VVAbek
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVNwKe : VVutlQ = [no , yes]
  else   : VVutlQ = [yes, no ]
  FFk1xo(self, title, VVutlQ=VVutlQ, addLabel=True)
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok" : self.VVQHyQ ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVumEG)
  if self.VVAbek:
   self["myLabel"].instance.setHAlign(0)
  self.VVIeyk()
  FFRLsp(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF7qfI(self["myMenu"])
  FFVHEz(self, self["myMenu"])
 def VVQHyQ(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVIeyk(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCMtdd(Screen):
 def __init__(self, session, title="", VVutlQ=None, width=1000, height=850, VVH0vt=30, barText="", minRows=1, VVnFDy=None, VVRIxl=None, VVuLNH=None, VVzsZa=None, VVMTOL=None, VVmhL9=None, VVNxG7=False, VVLIB1=False, VVBWci=None, VVGW0b=True, VVRdqN="#22003344", VVkSGg="#22002233"):
  self.skin, self.skinParam = FFzoo9(VVzryP, width, height, 50, 40, 30, VVRdqN, VVkSGg, VVH0vt, barHeight=40, topRightBtns=3 if VVRIxl else 0)
  self.session   = session
  self.VVutlQ   = VVutlQ
  self.barText   = barText
  self.minRows   = minRows
  self.VVnFDy   = VVnFDy
  self.VVRIxl   = VVRIxl
  self.VVuLNH   = VVuLNH
  self.VVzsZa  = VVzsZa
  self.VVMTOL  = ("Delete File", BF(self.VVJomM, VVBWci)) if not VVBWci is None else VVMTOL
  self.VVmhL9   = VVmhL9
  self.VVNxG7  = VVNxG7
  self.VVLIB1  = VVLIB1
  self.Title    = title
  FFk1xo(self, title, VVutlQ=VVutlQ)
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok"  : self.VVQHyQ    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVd4lV   ,
   "red"  : self.VVCZu8   ,
   "green"  : self.VVbiUa   ,
   "yellow" : self.VVIaJU   ,
   "blue"  : self.VVm7yY   ,
   "pageUp" : self.VV1l5A ,
   "chanUp" : self.VV1l5A ,
   "pageDown" : self.VVTs3T  ,
   "chanDown" : self.VVTs3T  ,
   "0"   : BF(self.VVlWlH, 0) ,
   "1"   : BF(self.VVlWlH, 1) ,
   "2"   : BF(self.VVlWlH, 2) ,
   "3"   : BF(self.VVlWlH, 3) ,
   "4"   : BF(self.VVlWlH, 4) ,
   "5"   : BF(self.VVlWlH, 5) ,
   "6"   : BF(self.VVlWlH, 6) ,
   "7"   : BF(self.VVlWlH, 7) ,
   "8"   : BF(self.VVlWlH, 8) ,
   "9"   : BF(self.VVlWlH, 9)
  }, -1)
  if VVGW0b:
   FFCRhg(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFRLsp(self["myMenu"])
  FFkPKs(self, minRows=self.minRows)
  FFqFdY(self)
  self.VVrugu(self["keyRed"]  , self.VVuLNH )
  self.VVrugu(self["keyGreen"] , self.VVzsZa )
  self.VVrugu(self["keyYellow"] , self.VVMTOL )
  self.VVrugu(self["keyBlue"]  , self.VVmhL9 )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFlx3W(self)
 def VVrugu(self, btnObj, btnFnc):
  if btnFnc:
   FFWr7z(btnObj, btnFnc[0])
 def VVydH2(self, fnc=None):
  self.VVzsZa = fnc
  if fnc : self.VVrugu(self["keyGreen"], self.VVzsZa)
  else : self["keyGreen"].hide()
 def VVlWlH(self, digit):
  digit = str(digit)
  VVutlQ = self["myMenu"].list
  for ndx, item in enumerate(VVutlQ):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFLAHl(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VV75it(ndx)
     self.VVQHyQ()
     break
 def VVQHyQ(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVnFDy:
    self.VVnFDy((self, txt, ref, ndx))
   else:
    if self.VVNxG7: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVd4lV(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVRIxl and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVRIxl(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVCZu8(self)  : self.VVEwjj(self.VVuLNH)
 def VVbiUa(self) : self.VVEwjj(self.VVzsZa)
 def VVIaJU(self) : self.VVEwjj(self.VVMTOL)
 def VVm7yY(self) : self.VVEwjj(self.VVmhL9)
 def VVEwjj(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVLIB1:
    self.cancel()
 def VV2aSr(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVutlQ = self["myMenu"].list
  VVutlQ.pop(ndx)
  if len(VVutlQ) > 0: self["myMenu"].setList(VVutlQ)
  else    : self.close()
 def VVJomM(self, basePath, menuObj, fName):
  FFfbEx(self, BF(self.VVi3of, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVi3of(self, path):
  FFEUy9(path)
  if fileExists(path) : FFhSFw(self, "Not deleted", 1000)
  else    : self.VV2aSr()
 def VV1C6X(self, VVutlQ):
  if len(VVutlQ) > 0:
   newList = []
   for item in VVutlQ:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFkPKs(self, minRows=self.minRows)
  else:
   self.close("")
 def VVWImw(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFkPKs(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVMkUK(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV75it(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVODgx(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VV75it(ndx)
    break
 def VVU16Q(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VV75it(ndx)
    break
 def VV1l5A(self) : self["myMenu"].moveToIndex(0)
 def VVTs3T(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CClArU(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVUel6=None, VVxWCE=None, VVFNzW=None, VVH0vt=26, isEditor=False, addSort=True, VVNWl5=False, VVdQKE=0, picParams=None, VVOPmD=None, VV5qt4=None, menuButtonFnc=None, VVRsW0=None, VVDle6=None, VVPOPD=None, VVUum8=None, VVj6l9=None, VVAWwW=None, VVfT1c=None, VVuFV9=-1, VV6Uvt=0, searchCol=0, lastFindConfigObj=None, VVRdqN="#22003344", VVkSGg="#22002233", VVjPDf="#00dddddd", VVTJDG="#11002233", VVVcQT=None, VVChAx="#11111111", borderWidth=1, VVDQNf="#0a555555", VV7oG4="#0affffff", VV4UX1="#11552200", VVPxPF="#0055ff55", VVPxPFRev="#0000bbff"):
  self.skin, self.skinParam = FFzoo9(VVbHtF, width, height, 50, 10, vMargin, VVRdqN, VVkSGg, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFk1xo(self, title)
  self.Title     = title
  self.header     = header
  self.VVUel6     = VVUel6
  self.totalCols    = len(VVUel6[0])
  self.VVdQKE   = VVdQKE
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VVNWl5   = VVNWl5
  self.VVQKlp   = 0.01
  self.VVKa5w   = 0.02
  self.VVNq65 = 0.03
  self.VVxCTy  = 1
  self.VVFNzW = VVFNzW
  self.colWidthPixels   = []
  self.VVOPmD   = VVOPmD
  self.OKButtonObj   = None
  self.VV5qt4   = VV5qt4
  self.VVRsW0   = VVRsW0
  self.VVDle6   = VVDle6
  self.VVPOPD  = VVPOPD
  self.VVUum8   = VVUum8
  self.VVj6l9    = VVj6l9
  self.VVAWwW   = VVAWwW
  self.tableRefreshCB   = None
  self.VVfT1c  = VVfT1c
  self.menuButtonFnc   = menuButtonFnc
  self.VVuFV9    = VVuFV9
  self.VV6Uvt   = VV6Uvt
  self.searchCol    = searchCol
  self.VVxWCE    = VVxWCE
  self.keyPressed    = -1
  self.VVH0vt    = FFBCoV(VVH0vt)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VVDng6    = FFFt0C(self.VVH0vt, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVRdqN    = VVRdqN
  self.VVkSGg      = VVkSGg
  self.VVjPDf    = FFkpAV(VVjPDf)
  self.VVTJDG    = FFkpAV(VVTJDG)
  self.VVVcQT    = VVVcQT
  self.VVChAx    = FFkpAV(VVChAx)
  self.borderWidth   = borderWidth
  self.VVDQNf   = FFkpAV(VVDQNf)
  self.VV7oG4    = FFkpAV(VV7oG4)
  self.VV4UX1    = FFkpAV(VV4UX1)
  self.VVPxPF   = FFkpAV(VVPxPF)
  self.VVPxPFRev  = FFkpAV(VVPxPFRev)
  self.VVs7XH  = False
  self.selectedItems   = 0
  self.VVqQQP   = FFkpAV("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VV6Uvt:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VV6Uvt == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok"  : self.VVbNjW  ,
   "red"  : self.VVlxYe  ,
   "green"  : self.VVfnyt ,
   "yellow" : self.VVNVQ9 ,
   "blue"  : self.VVIfGP  ,
   "menu"  : self.VVK8Tn ,
   "info"  : self.VVUt6l  ,
   "cancel" : self.VVCx7S  ,
   "up"  : self.VVjxS4    ,
   "down"  : self.VVk8wK  ,
   "left"  : self.VVwMUP   ,
   "right"  : self.VV5D8z  ,
   "next"  : self.VVVXle  ,
   "last"  : self.VVws12  ,
   "home"  : self.VVmReQ  ,
   "pageUp" : self.VVmReQ  ,
   "chanUp" : self.VVmReQ  ,
   "end"  : self.VVXXgH  ,
   "pageDown" : self.VVXXgH  ,
   "chanDown" : self.VVXXgH
  }, -1)
  FFCRhg(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  try:
   self.VVFog4()
  except Exception as e:
   FF9Njt(self, str(e), title=self.Title)
   self.close(None)
 def VVFog4(self):
  FFlx3W(self)
  self.VVrugu(self.VVRsW0 , self["keyRed"])
  self.VVrugu(self.VVDle6 , self["keyGreen"])
  self.VVrugu(self.VVPOPD, self["keyYellow"])
  self.VVrugu(self.VVUum8 , self["keyBlue"])
  if self.VVOPmD:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVOPmD[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVOPmD[0])
    FFiva8(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVDng6)
  self["myTableH"].l.setFont(0, gFont(VVczsY, self.VVH0vt))
  self["myTable"].l.setItemHeight(self.VVDng6)
  self["myTable"].l.setFont(0, gFont(VVczsY, self.VVH0vt))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVDng6)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVDng6))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVDng6)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVDng6
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVDng6 * len(self.VVUel6) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVFNzW:
   self.VVFNzW = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVFNzW)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVxWCE:
   self.VVxWCE = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVxWCE
   self.VVxWCE = []
   for item in tmpList:
    self.VVxWCE.append(item | RT_VALIGN_CENTER)
  self.VVQNNx()
  if self.VVj6l9:
   self.VVj6l9(self)
 def VVrugu(self, btnFnc, btn):
  if btnFnc : FFWr7z(btn, btnFnc[0])
  else  : FFWr7z(btn, "")
 def VV4gWb(self, waitTxt):
  FFVvl9(self, self.VVQNNx, title=waitTxt)
 def VVQNNx(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVPxPFRev if self.lastSortModeIsReverese else self.VVPxPF
    self["myTableH"].setList([self.VVJlEw(0, self.header, self.VV7oG4, self.VV4UX1, self.VV7oG4, self.VV4UX1, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVUel6):
    self["myTable"].list.append(self.VVJlEw(c, row, self.VVjPDf, self.VVTJDG, self.VVVcQT, self.VVChAx, None))
   self.VVUel6 = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVuFV9 > -1:
    self["myTable"].moveToIndex(self.VVuFV9 )
   self.VVhVBO()
   if self.VV6Uvt:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVDng6 * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFDNFi(self, width, newH)
   if self.VVAWwW:
    self.VVEwjj(self.VVAWwW, None)
   if self.tableRefreshCB:
    self.VVEwjj(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FF9Njt(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVJlEw(self, keyIndex, columns, VVjPDf, VVTJDG, VVVcQT, VVChAx, VVPxPF):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVPxPF and ndx == self.VVdQKE : textColor = VVPxPF
   else           : textColor = VVjPDf
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFkpAV(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVTJDG = c
    entry = span.group(3)
   if not self.isEditor and self.VVxWCE[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVDng6)
           , font   = 0
           , flags   = self.VVxWCE[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVTJDG
           , color_sel  = VVVcQT or textColor
           , backcolor_sel = VVChAx
           , border_width = self.borderWidth
           , border_color = self.VVDQNf
           ))
   posX += self.colWidthPixels[ndx]
  if not VVPxPF and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CClArU.VVAekn(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VVDng6-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVUt6l(self):
  rowData = self.VVpxw9()
  if rowData:
   title, txt, colList = rowData
   if self.VV5qt4:
    fnc  = self.VV5qt4[1]
    params = self.VV5qt4[2]
    fnc(self, title, txt, colList)
   else:
    FFEso0(self, txt, title)
 def VVbNjW(self):
  if   self.VVs7XH : self.VVZdwS(self.VVSWzf(), mode=2)
  elif self.VVOPmD  : self.VVEwjj(self.VVOPmD, None)
  else      : self.VVUt6l()
 def VVlxYe(self) : self.VVEwjj(self.VVRsW0 , self["keyRed"])
 def VVfnyt(self) : self.VVEwjj(self.VVDle6 , self["keyGreen"])
 def VVNVQ9(self): self.VVEwjj(self.VVPOPD , self["keyYellow"])
 def VVIfGP(self) : self.VVEwjj(self.VVUum8 , self["keyBlue"])
 def VVEwjj(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFhSFw(self, buttonFnc[3])
    FFciRl(BF(self.VVsn64, buttonFnc))
   else:
    self.VVsn64(buttonFnc)
 def VVsn64(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVpxw9()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVZdwS(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVqQQP
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVTJDG
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVqQQP
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == 0:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVSWzf() < len(self["myTable"].list) - 1 : self.VVk8wK()
   else              : self.VVhVBO()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VV4ooJ(self)  : FFVvl9(self, BF(self.VV5tAI, True ), title="Selecting all ..."  )
 def VVaYvW(self) : FFVvl9(self, BF(self.VV5tAI, False), title="Unselecting all ...")
 def VV5tAI(self, isSel=True):
  if isSel:
   bg = self.VVqQQP
   self.selectedItems = len(self["myTable"].list)
   self.VVGaoF(True)
  else:
   bg = self.VVTJDG
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVqQQP
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == 0:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVpxw9(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVFNzW[i] > 1 or self.VVFNzW[i] == self.VVQKlp or self.VVFNzW[i] == self.VVNq65:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVCx7S(self):
  self["myTable"].onSelectionChanged = []
  if self.VVfT1c : self.VVfT1c(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VV5xTc(self):
  return self["myTitle"].getText().strip()
 def VVIvJH(self):
  return self.header
 def VV5ujT(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVTtQT(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFBD6G(self["myBar"], color)
 def VVsbUP(self, txt):
  FFhSFw(self, txt)
 def VVRR2a(self, txt, Time=1000):
  FFhSFw(self, txt, Time)
 def VVOPTG(self): self["keyGreen"].show()
 def VVSegU(self): self["keyGreen"].hide()
 def VVpsVv(self): return self["keyGreen"].visible
 def VVmw4V(self):
  FFhSFw(self)
 def VVHrXj(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVA2PV(self):
  return len(self["myTable"].list)
 def VVSWzf(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVc8ws(self):
  return len(self["myTable"].list)
 def VVGaoF(self, isOn):
  self.VVs7XH = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVUum8: self["keyBlue"].hide()
   if self.VVOPmD and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVRdqN
   self["keyMenu"].show()
   if self.VVUum8: self["keyBlue"].show()
   if self.VVOPmD and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVOPmD[0])
   self.VVaYvW()
  FFiva8(self["myTitle"], color)
  FFiva8(self["myBar"]  , color)
 def VVsOQV(self):
  return self.VVs7XH
 def VVznW9(self):
  return self.selectedItems
 def VVmBIp(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVhVBO()
 def VV82vL(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VV4jdE(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVA2PV()
  txt += FFl9yk("Total Unique Items", VVUS1a)
  for i in range(self.totalCols):
   if self.VVFNzW[i - 1] > 1 or self.VVFNzW[i - 1] == self.VVQKlp or self.VVFNzW[i - 1] == self.VVNq65:
    name, tot = self.VV82vL(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFEso0(self, txt)
 def VVxwcf(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVZqZI(self):
  return self.VVbWAe(self["myTable"].l.getCurrentSelectionIndex())
 def VVbWAe(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVoiHv(self, newList, newTitle="", VVanXbMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VV5ujT(newTitle)
  if newList:
   self.VVUel6 = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVNWl5 and self.VVdQKE == 0:
    isNum = True
   else:
    for cols in self.VVUel6:
     if not FF5YNj(cols[self.VVdQKE]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVUel6.sort(key=lambda x: int(x[self.VVdQKE])  , reverse=self.lastSortModeIsReverese)
    else : self.VVUel6.sort(key=lambda x: x[self.VVdQKE].lower() , reverse=self.lastSortModeIsReverese)
   if VVanXbMsg : self.VV4gWb("Refreshing ...")
   else   : self.VVQNNx()
  else:
   FF9Njt(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VV6y5N(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVJlEw(self.VVc8ws(), row, self.VVjPDf, self.VVTJDG, self.VVVcQT, self.VVChAx, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVXXgH()
 def VVfA76(self):
  self["myTable"].list.pop(self.VVSWzf())
  self["myTable"].l.setList(self["myTable"].list)
 def VVTXUN(self, data):
  ndx = self.VVSWzf()
  newRow = self.VVJlEw(ndx, data, self.VVjPDf, self.VVTJDG, self.VVVcQT, self.VVChAx, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVhVBO()
   return True
  else:
   return False
 def VVtaQs(self, tDict):
  ndx = self.VVSWzf()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VVxWCE[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVEQQA()
 def VVmJSt(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVJlEw(ndx, data, self.VVjPDf, self.VVTJDG, self.VVVcQT, self.VVChAx, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVEQQA()
 def VVEQQA(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VVhVBO()
 def VV3qTB(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVrxBR(self, colNum, textToFind, VVJLdL=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVhVBO()
    break
  else:
   if VVJLdL:
    FFhSFw(self, "Not found", 1000)
 def VV9SZy(self, colDict, VVJLdL=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVhVBO()
    return
  if VVJLdL:
   FFhSFw(self, "Not found", 1000)
  return False
 def VVT6PQ(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVD2Nh(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FF5YNj(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVd77Z(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVqQQP:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVQijQ(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVqQQP:
     return ndx
  return -1
 def VVEDPQ(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVqQQP:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVrdPF(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVqQQP : return True
  else        : return False
 def VVNCJx(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVK8Tn(self):
  if self.menuButtonFnc:
   self.VVsn64(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VV6Uvt:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVSWzf()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVutlQ1, VVZLh1 = CCtamE.VVrIwr(self, False, False)
  VVutlQ = []
  VVutlQ.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVutlQ.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVutlQ.append(("Find ...\t\t%s" % (FF0D7j(txt, VVJTsP) if txt else ""), "findNew"   ))
  VVutlQ.append(itemOf(bool(VVutlQ1)    , "Find (from Filter) ..."   , "filter"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Table Statistcis"             , "tableStat"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((FF0D7j("Export Table to .html"     , VVUS1a) , "VVp3cN" ))
  VVutlQ.append((FF0D7j("Export Table to .csv"     , VVUS1a) , "VVLSPg" ))
  VVutlQ.append((FF0D7j("Export Table to .txt (Tab Separated)", VVUS1a) , "VVJB9a" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVFNzW[i] > 1 or self.VVFNzW[i] == self.VVKa5w:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVutlQ.append(VVJKCZ)
    if tot == 1 : VVutlQ.append(("Sort", sList[0][1]))
    else  : VVutlQ += sList
  VVmhL9 = ("Keys Help", self.FFvfptHelp)
  FFre61(self, self.VVrIdK, VVutlQ=VVutlQ, title=self.VV5xTc(), VVmhL9=VVmhL9)
 def VVrIdK(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVgFbn()
   elif item == "findPrev"  : self.VVgFbn(isPrev=True)
   elif item == "findNew"  : self.VV6oOQ()
   elif item == "filter"  : self.VVLKWA()
   elif item == "tableStat" : self.VV4jdE()
   elif item == "VVp3cN": FFVvl9(self, self.VVp3cN, title=title)
   elif item == "VVLSPg" : FFVvl9(self, self.VVLSPg , title=title)
   elif item == "VVJB9a" : FFVvl9(self, self.VVJB9a , title=title)
   else:
    if self.VVdQKE == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVdQKE, self.lastSortModeIsReverese = item, False
    if self.VVNWl5 and self.VVdQKE == 0 or self.VVD2Nh(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVQNNx(onlyHeader=True)
 def FFvfptHelp(self, VVG7pv, path):
  FF1D9G(self, "_help_table", "Table (Keys Help)")
 def VVjxS4(self):
  self["myTable"].up()
  self.VVhVBO()
 def VVk8wK(self):
  self["myTable"].down()
  self.VVhVBO()
 def VVwMUP(self):
  self["myTable"].pageUp()
  self.VVhVBO()
 def VV5D8z(self):
  self["myTable"].pageDown()
  self.VVhVBO()
 def VVmReQ(self):
  self["myTable"].moveToIndex(0)
  self.VVhVBO()
 def VVXXgH(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVhVBO()
 def VVfMAJ(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVhVBO()
 def VVVXle(self):
  if self.lastFindConfigObj.getValue():
   if self.VVSWzf() == len(self["myTable"].list) - 1 : FFhSFw(self, "End reached", 1000)
   else              : self.VVgFbn()
  else:
   FFhSFw(self, 'Set "Find" in Menu', 1500)
 def VVws12(self):
  if self.lastFindConfigObj.getValue():
   if self.VVSWzf() == 0 : FFhSFw(self, "Top reached", 1000)
   else       : self.VVgFbn(isPrev=True)
  else:
   FFhSFw(self, 'Set "Find" in Menu', 1500)
 def VVfeeb(self, txt):
  FF3Ual(self.lastFindConfigObj, txt)
 def VV6oOQ(self):
  FFuRfO(self, self.VVSRKG, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVSRKG(self, VVF3qs):
  if not VVF3qs is None:
   txt = VVF3qs.strip()
   self.VVfeeb(txt)
   if VVF3qs: self.VVgFbn(reset=True)
   else  : FFhSFw(self, "Nothing to find !", 1500)
 def VVLKWA(self):
  VVutlQ, VVZLh1 = CCtamE.VVrIwr(self, False, False)
  VVMTOL = ("Edit Filter", BF(self.VVJxuW, VVZLh1))
  if VVutlQ : FFre61(self, self.VV855a, VVutlQ=VVutlQ, VVMTOL=VVMTOL, title="Find from Filter")
  else  : FFhSFw(self, "Filter Error !", 1500)
 def VV855a(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVfeeb(txt)
    self.VVgFbn(reset=True)
   else:
    FFhSFw(self, "No entry !", 1500)
 def VVJxuW(self, VVZLh1, selectionObj, sel):
  if fileExists(VVZLh1) : CCc3G0(self, VVZLh1, VVFqvg=None)
  else       : FFvsvw(self, VVZLh1)
  selectionObj.cancel()
 def VVgFbn(self, reset=False, isPrev=False):
  curRow = self.VVSWzf()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCtamE.VVy75H(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVfMAJ(i)
      break
    elif any(x in line for x in tupl):
     self.VVfMAJ(i)
     break
   else:
    FFhSFw(self, "Not found", 1000)
  else:
   FFhSFw(self, "Check your query", 1500)
 def VVJB9a(self):
  expFile = self.VVMLZL() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVPvkN()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVbWAe(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVFNzW[ndx] > self.VVxCTy or self.VVFNzW[ndx] == self.VVNq65:
      col = self.VVz29r(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVi4Yp(expFile)
 def VVLSPg(self):
  expFile = self.VVMLZL() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVPvkN()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVbWAe(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVFNzW[ndx] > self.VVxCTy or self.VVFNzW[ndx] == self.VVNq65:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVz29r(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVi4Yp(expFile)
 def VVp3cN(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV5xTc(), PLUGIN_NAME, VVFo84)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV5xTc()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVPvkN()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVFNzW:
   colgroup += '   <colgroup>'
   for w in self.VVFNzW:
    if w > self.VVxCTy or w == self.VVNq65:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVMLZL() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVbWAe(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVFNzW[ndx] > self.VVxCTy or self.VVFNzW[ndx] == self.VVNq65:
      col = self.VVz29r(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVi4Yp(expFile)
 def VVPvkN(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVFNzW[ndx] > self.VVxCTy or self.VVFNzW[ndx] == self.VVNq65:
     newRow.append(col.strip())
  return newRow
 def VVz29r(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFLAHl(col)
 def VVMLZL(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV5xTc())
  fileName = fileName.replace("__", "_")
  path  = FFqvjY(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFKX94()
  return expFile
 def VVi4Yp(self, expFile):
  FFmMPS(self, "File exported to:\n\n%s" % expFile, title=self.VV5xTc())
 def VVhVBO(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == 0 : lastCol = totCols - 1
   else      : lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVAekn(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VVzxT6: return (typ, x, y, w, h, png, bg, bgSel, VVzxT6 | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCl6im():
 def __init__(self, pixmapObj, picPath, VVTJDG=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVTJDG  = VVTJDG or "#2200002a"
 def VVlDiS(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVq2Vy)
    except:
     self.picLoad.PictureData.get().append(self.VVq2Vy)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVTJDG])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVq2Vy(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVWobb(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVMews(pixmapObj, path, VVTJDG=None):
  cl = CCl6im(pixmapObj, path, VVTJDG)
  ok = cl.VVlDiS()
  if ok: return cl
  else : return None
class CCMQgO(Screen):
 def __init__(self, session, VVQVlp, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFUXKU()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFzoo9(VV4GaE, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVQVlp = VVQVlp
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFk1xo(self)
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVbNo7  ,
   "up" : BF(self.VVLyVY, -1),
   "down" : BF(self.VVLyVY,  1),
   "left" : BF(self.VVLyVY, -1),
   "right" : BF(self.VVLyVY,  1)
  }, -1)
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  self.VVyxgL()
  self.picViewer = CCl6im.VVMews(self["myPic"], self.VVQVlp)
  if self.picViewer:
   if self.showGrnMsg:
    FFhSFw(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF9Njt(self, "Cannot view picture file:\n\n%s" % self.VVQVlp)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVWobb()
  if self.cbFnc  : self.cbFnc(self.VVQVlp)
 def VVLyVY(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVQVlp = FFqvjY(os.path.dirname(self.VVQVlp)) + fName
    self.picViewer.picPath = self.VVQVlp
    self.picViewer.VVlDiS()
    self.VVyxgL()
 def VVbNo7(self):
  txt = "%s:\n  %s" % (FF0D7j("Path", VVPr8g), self.fakePath or self.VVQVlp)
  size, sizeTxt, resTxt, form, mode = CC4Zpg.VVW0tv(self.VVQVlp)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FF0D7j("Properties", VVPr8g)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFEso0(self, txt, title="File Information")
 def VVyxgL(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVQVlp)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVR5E7(SELF, VVQVlp, **kwargs):
  SELF.session.open(CCMQgO, VVQVlp, **kwargs)
class CClvUz(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFzoo9(VVS1Zw, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFk1xo(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.onExit)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FF2ufE("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVNhTs(SELF, mviFile):
  SELF.session.openWithCallback(BF(CClvUz.VVl9mp, SELF), CClvUz, mviFile)
 @staticmethod
 def VVl9mp(SELF, reason=None):
  if reason == -1: FF9Njt(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCpO9T(Screen, ConfigListScreen):
 VV87BD = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVJOxT, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFk1xo(self, title=self.Title)
  FFWr7z(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVyzr9()
  self.onShown.append(self.VVywsT)
 def VVyzr9(self):
  kList = {
    "ok" : self.VVQHyQ   ,
    "green" : self.VV7f2N ,
    "menu" : self.VVUDR5 ,
    "cancel": self.VVd4UH ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVxDco, 0)
     kList["chanDown"] = BF(self["config"].VVxDco, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VVyU28, kList, -1)
  else:
   self["actions"] = ActionMap(VVyU28, kList, -1)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFqFdY(self)
  FFRLsp(self["config"])
  FFkPKs(self, self["config"])
  FFlx3W(self)
  self["config"].onSelectionChanged.append(self.VVbYPZ)
  self.VVbYPZ()
  FFiva8(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVbYPZ(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVQHyQ(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVIdT3()
   elif item == CFG.MovieDownloadPath   : self.VVZ9qD(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVLTSD()
   elif isinstance(item, ConfigDirectory) : self.VVvD4P(item)
   else         : CCpO9T.VVsCHV(self, item, title)
 @staticmethod
 def VVsCHV(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)   : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber): lst = [(x, x) for x in confItem.choices.choices]
   elif isinstance(confItem, ConfigSelection)  : lst = confItem.choices.choices
   else           : return
  curNdx = defNdx = -1
  VVutlQ = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVJTsP + txt
    elif val == confItem.default: defNdx, txt = ndx, VVRkew + txt
   VVutlQ.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVmhL9  = ("Current", BF(CCpO9T.VVwAw6, curNdx))
  VVMTOL = ("Default", BF(CCpO9T.VVwAw6, defNdx))
  VVG7pv = FFre61(SELF, BF(CCpO9T.VVYbwj, confItem, cbFnc, isSave), VVutlQ=VVutlQ, width=1200, VVMTOL=VVMTOL, VVmhL9=VVmhL9, title=title, VVRdqN="#33221111", VVkSGg="#33110011")
  VVG7pv.VV75it(curNdx)
 @staticmethod
 def VVYbwj(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FF3Ual(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVwAw6(ndx, selectionObj, item):
  selectionObj.VV75it(ndx)
 @staticmethod
 def VVNGcc(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVZ9qD(self, item, title):
  tot = CCkpqq.VVwaeg()
  if tot : FF9Njt(self, "Cannot change while downloading.", title=title)
  else : self.VVvD4P(item)
 def VVLTSD(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCDQtT.VVExAe(self, "", curEnc)
  if lst:
   VVMTOL = ("Default", self.VVlJoL)
   VVmhL9  = ("Current", self.VV9ASw)
   VVG7pv = FFre61(self, self.VVEVZz, title="Select Priority Encoding", VVutlQ=lst, width=1000, height=1000, VVmhL9=VVmhL9, VVMTOL=VVMTOL, VVRdqN="#22220000", VVkSGg="#22220000", VVNxG7=True)
   VVG7pv.VVODgx(curEnc)
 def VVEVZz(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVlJoL(self, VVG7pv, item): VVG7pv.VVODgx(VVjOGl)
 def VV9ASw(self, VVG7pv, item): VVG7pv.VVODgx(CFG.subtDefaultEnc.getValue())
 def VVIdT3(self):
  VVutlQ = []
  VVutlQ.append(("Auto Find" , "auto"))
  VVutlQ.append(("Custom Path" , "cust"))
  FFre61(self, self.VVeKVb, VVutlQ=VVutlQ, title="IPTV Hosts Files Path")
 def VVeKVb(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVpkJd)
   elif item == "cust":
    VV796F = self.VVTveK()
    if VV796F : self.VVvK0h(VV796F)
    else  : self.session.openWithCallback(self.VV882l, BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5="/"))
 def VVvK0h(self, VV796F):
  VVfT1c = self.VVCXp3
  VVRsW0 = ("Remove"  , self.VViVt5 , [])
  VVPOPD = ("Add "  , self.VVwfog, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVxWCE  = (LEFT   , LEFT  )
  FFvfpt(self, None, title="IPTV Hosts Search Paths", header=header, VVUel6=VV796F, width=1200, height=700, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=26, VVfT1c=VVfT1c, VVRsW0=VVRsW0, VVPOPD=VVPOPD
    , VVRdqN="#22220000", VVkSGg="#22110000", VVTJDG="#22110011", VVChAx="#11223025", VVDQNf="#0a333333", VV4UX1="#11400040")
 def VVCXp3(self, VVhkUd):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VV9ZmY)
  VVhkUd.cancel()
 def VV882l(self, path):
  if path:
   FF3Ual(CFG.iptvHostsDirs, FFqvjY(path.strip()))
   VV796F = self.VVTveK()
   if VV796F : self.VVvK0h(VV796F)
   else  : FFhSFw(self, "Cannot add dir", 1500)
 def VVZwOs(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVpkJd:
   return []
  return lst
 def VVTveK(self):
  lst = self.VVZwOs()
  if lst:
   VV796F = []
   for Dir in lst:
    VV796F.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VV796F.sort(key=lambda x: x[0].lower())
   return VV796F
  else:
   return []
 def VVwfog(self, VVhkUd, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVP2S4, VVhkUd)
         , BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=sDir))
 def VVP2S4(self, VVhkUd, path):
  if path:
   path = FFqvjY(path.strip())
   if self.VVVtpj(VVhkUd, path):
    FFhSFw(VVhkUd, "Already added", 1500)
   else:
    lst = self.VVZwOs()
    lst.append(path)
    FF3Ual(CFG.iptvHostsDirs, ",".join(lst))
    VV796F = self.VVTveK()
    VVhkUd.VVoiHv(VV796F, tableRefreshCB=BF(self.VVC06R, path))
 def VVC06R(self, path, VVhkUd, title, txt, colList):
  self.VVVtpj(VVhkUd, path)
 def VVVtpj(self, VVhkUd, path):
  for ndx, row in enumerate(VVhkUd.VVNCJx()):
   if row[0].strip() == path.strip():
    VVhkUd.VVfMAJ(ndx)
    return True
  return False
 def VViVt5(self, VVhkUd, title, txt, colList):
  path = colList[0]
  FFfbEx(self, BF(self.VVVnlk, VVhkUd), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVVnlk(self, VVhkUd):
  row = VVhkUd.VVZqZI()
  path, rem = row[0], row[1]
  VV796F = []
  lst = []
  for ndx, row in enumerate(VVhkUd.VVNCJx()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VV796F.append((tPath, tRem))
  if len(VV796F) > 0:
   FF3Ual(CFG.iptvHostsDirs, ",".join(lst))
   VVhkUd.VVoiHv(VV796F)
   FFhSFw(VVhkUd, "Deleted", 1500)
  else:
   FF3Ual(CFG.iptvHostsMode, VVpkJd)
   FF3Ual(CFG.iptvHostsDirs, "")
   VVhkUd.cancel()
   FFciRl(BF(FFhSFw, self, "Changed to Auto-Find", 1500))
 def VVvD4P(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVMXke, configObj)
         , BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=sDir))
 def VVMXke(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVd4UH(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFfbEx(self, self.VV7f2N, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VV7f2N(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV80x7()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVUDR5(self):
  VVutlQ = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVutlQ.append((txt    , "VVMybW"   ))
  else        : VVutlQ.append((txt    ,       ))
  VVutlQ.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Reset %s Settings" % PLUGIN_NAME      , "VVHKJs"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Backup %s Settings" % PLUGIN_NAME      , "VVPj2f"  ))
  VVutlQ.append(("Restore %s Settings" % PLUGIN_NAME     , "VV2lsq"  ))
  if fileExists(VVUQHY + CCpO9T.VV87BD):
   VVutlQ.append(VVJKCZ)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVutlQ.append(('%s Checking for Update' % txt1     , txt2     ))
   VVutlQ.append(("Reinstall %s" % PLUGIN_NAME      , "VVbfBl"  ))
   VVutlQ.append(("Update %s" % PLUGIN_NAME      , "VVQTRI"   ))
  FFre61(self, self.VVjfOn, VVutlQ=VVutlQ, title="Config. Options")
 def VVjfOn(self, item=None):
  if item:
   if   item == "VVMybW"  : FFfbEx(self, self.VVMybW , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCcW2f)
   elif item == "VVHKJs"  : FFfbEx(self, BF(self.VVHKJs, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVPj2f" : self.VVPj2f()
   elif item == "VV2lsq" : FFVvl9(self, self.VV2lsq, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FF3Ual(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FF3Ual(CFG.checkForUpdateAtStartup, False)
   elif item == "VVbfBl" : FFVvl9(self, BF(self.VVgjri, True ), "Checking Server ...")
   elif item == "VVQTRI"  : FFVvl9(self, BF(self.VVgjri, False), "Checking Server ...")
 def VVPj2f(self):
  path = "%sajpanel_settings_%s" % (VVUQHY, FFKX94())
  FFIapl("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVGMYl, path))
  FFmMPS(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV2lsq(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFlfx8("find / %s -iname '%s*' | grep %s" % (FFNOMj(1), name, name))
  if files:
   err = CCLSXF.VVTvbh(files)
   if err:
    FFfbEx(self, BF(self.VVkQ0F, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVutlQ = []
    for line in files:
     VVutlQ.append((line, line))
    FFre61(self, BF(self.VV9IeL, title), title=title, VVutlQ=VVutlQ, width=1200, VVBWci="")
  else:
   FF9Njt(self, "No settings files found !", title=title)
 def VVkQ0F(self, title, path=None):
  sDir = "/"
  for path in (VVUQHY, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VV9IeL, title), BF(CCLSXF, patternMode="ajpSet", VVXhi5=sDir))
 def VV9IeL(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF6UEw(path)
    self.VVHKJs()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VV80x7()
    FFlcwU()
    FFhSFw(self, "Apllied", 1500, isGrn=True)
   else:
    FFvsvw(self, path, title=title)
 def VVMybW(self):
  newPath = FFqvjY(VVUQHY)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV80x7()
 @staticmethod
 def VVQhPB():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVHKJs(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV80x7()
  if exit:
   self.close()
 def VV80x7(self):
  configfile.save()
  global VVUQHY
  VVUQHY = CFG.backupPath.getValue()
  FFs1eH()
 def VVgjri(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCpO9T.VVjU4M()
  if   err    : FF9Njt(self, err, title)
  elif isHigher or force : FFfbEx(self, BF(FFVvl9, self, BF(self.VVDtFx, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFmMPS(self, FF0D7j("No update required.", VVRTFm) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVDtFx(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FF3UQa() == "dpkg" else "ipk")
  path, err = FFAqj4(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFciUY(VVpQG6, path)
   else : cmd = FFciUY(VVaEyM, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FF9pl1(self, cmd, title=title)
   else:
    FFdRu7(self, title=title)
  else:
   FF9Njt(self, err, title=title)
 @staticmethod
 def VVjU4M():
  span = iSearch(r"v*(\d.\d.\d)", VVFo84, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVUQHY + CCpO9T.VV87BD
  if fileExists(path):
   span = iSearch(r"(http.+)", FFXk75(path), IGNORECASE)
   if span : url = FFqvjY(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFAqj4(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFXk75(path).strip().replace(" ", "")
   FFEUy9(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCcW2f(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVHtTB, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVowRJ
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFk1xo(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVo8Og("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVo8Og("\c00888888", i) + sp + "GREY\n"
   txt += self.VVo8Og("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVo8Og("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVo8Og("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVo8Og("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVo8Og("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVo8Og("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVo8Og("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVo8Og("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVo8Og("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVo8Og("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok" : self.VVQHyQ ,
   "green" : self.VVQHyQ ,
   "left" : self.VVY4Ig ,
   "right" : self.VV85da ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  self.VVqkUN()
 def VVQHyQ(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFfbEx(self, self.VVBk85, "Change to : %s" % txt, title=self.Title)
 def VVBk85(self):
  FF3Ual(CFG.mixedColorScheme, self.cursorPos)
  global VVowRJ
  VVowRJ = self.cursorPos
  self.VVWdbW()
  self.close()
 def VVY4Ig(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVqkUN()
 def VV85da(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVqkUN()
 def VVqkUN(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVo8Og(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVNgBs(color):
  if VVRkew: return "\\" + color
  else    : return ""
 @staticmethod
 def VVWdbW():
  global VVwos9, VVBhz1, VV8a8m, VVO7vL, VVUS1a, VVQrak, VV0HZq, VVHovR, VVRTFm, VVFWDt, VVRkew, VVPr8g, VVJTsP, VVqWCE, VV7CTN, VV15Fs
  VV15Fs   = CCcW2f.VVo8Og("\c00FFFFFF", VVowRJ)
  VVBhz1    = CCcW2f.VVo8Og("\c00888888", VVowRJ)
  VVwos9  = CCcW2f.VVo8Og("\c005A5A5A", VVowRJ)
  VVHovR    = CCcW2f.VVo8Og("\c00FF0000", VVowRJ)
  VV8a8m   = CCcW2f.VVo8Og("\c00FF5000", VVowRJ)
  VVO7vL   = CCcW2f.VVo8Og("\c00FFBB66", VVowRJ)
  VVRkew   = CCcW2f.VVo8Og("\c00FFFF00", VVowRJ)
  VVPr8g = CCcW2f.VVo8Og("\c00FFFFAA", VVowRJ)
  VVRTFm   = CCcW2f.VVo8Og("\c0000FF00", VVowRJ)
  VVFWDt  = CCcW2f.VVo8Og("\c00AAFFAA", VVowRJ)
  VV0HZq    = CCcW2f.VVo8Og("\c000066FF", VVowRJ)
  VVJTsP    = CCcW2f.VVo8Og("\c0000FFFF", VVowRJ)
  VVqWCE  = CCcW2f.VVo8Og("\c00AAFFFF", VVowRJ)  #
  VV7CTN   = CCcW2f.VVo8Og("\c00FA55E7", VVowRJ)
  VVUS1a    = CCcW2f.VVo8Og("\c00FF8F5F", VVowRJ)
  VVQrak  = CCcW2f.VVo8Og("\c00FFC0C0", VVowRJ)
CCcW2f.VVWdbW()
class CCRQQt(Screen):
 def __init__(self, session, path, VVb8Ad):
  self.skin, self.skinParam = FFzoo9(VVDjOq, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVT9C9   = path
  self.VVoW7q   = ""
  self.VVf35F   = ""
  self.VVb8Ad    = VVb8Ad
  self.VVolcZ    = ""
  self.VVhpFD  = ""
  self.VVfjD5    = False
  self.VVhxhZ  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VV5zAI  = "enigma2-plugin-extensions-"
  self.VVE6sD  = "enigma2-plugin-systemplugins-"
  self.VVaol3 = "enigma2-"
  self.VV6hKl  = 0
  self.VVpHdT  = 1
  self.VVjlQ6  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVPBDE = "DEBIAN"
  else        : self.VVPBDE = "CONTROL"
  self.controlPath = self.Path + self.VVPBDE
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVb8Ad:
   self.packageExt  = ".deb"
   self.VVTJDG  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVTJDG  = "#11001020"
  FFk1xo(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFWr7z(self["keyRed"] , "Create")
  FFWr7z(self["keyGreen"] , "Post Install")
  FFWr7z(self["keyYellow"], "Installation Path")
  FFWr7z(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VVyU28,
  {
   "red"   : self.VVZZXG  ,
   "green"   : self.VVhoTs ,
   "yellow"  : self.VVjA7N  ,
   "blue"   : self.VV6fJ4  ,
   "cancel"  : self.VVTVMW
  }, -1)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFlx3W(self)
  if self.VVTJDG:
   FFiva8(self["myBody"], self.VVTJDG)
   FFiva8(self["myLabel"], self.VVTJDG)
  self.VVzsJk(True)
  self.VVksT1(True)
 def VVksT1(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVFyNN()
  if isFirstTime:
   if   package.startswith(self.VV5zAI) : self.VVT9C9 = VVzry0 + self.VVolcZ + "/"
   elif package.startswith(self.VVE6sD) : self.VVT9C9 = VVATu0 + self.VVolcZ + "/"
   else            : self.VVT9C9 = self.Path
  if self.VVfjD5 : myColor = VVUS1a
  else    : myColor = VV15Fs
  txt  = ""
  txt += "Source Path\t: %s\n" % FF0D7j(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF0D7j(self.VVT9C9, VVRkew)
  if self.VVf35F : txt += "Package File\t: %s\n" % FF0D7j(self.VVf35F, VVBhz1)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF0D7j("Check Control File fields : %s" % errTxt, VV8a8m)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF0D7j("Restart GUI", VVUS1a)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF0D7j("Reboot Device", VVUS1a)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FF0D7j("Post Install", VVRTFm), act)
  if not errTxt and VV8a8m in controlInfo:
   txt += "Warning\t: %s\n" % FF0D7j("Errors in control file may affect the result package.", VV8a8m)
  txt += "\nControl File\t: %s\n" % FF0D7j(self.controlFile, VVBhz1)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVhoTs(self):
  if self["keyGreen"].getVisible():
   VVutlQ = []
   VVutlQ.append(("No Action"    , "noAction"  ))
   VVutlQ.append(("Restart GUI"    , "VVhnmM"  ))
   VVutlQ.append(("Reboot Device"   , "rebootDev"  ))
   FFre61(self, self.VVklrQ, title="Package Installation Option (after completing installation)", VVutlQ=VVutlQ)
 def VVklrQ(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVhnmM"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVzsJk(False)
   self.VVksT1()
 def VVjA7N(self):
  rootPath = FF0D7j("/%s/" % self.VVolcZ, VVPr8g)
  VVutlQ = []
  VVutlQ.append(("Current Path"        , "toCurrent"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Extension Path"       , "toExtensions" ))
  VVutlQ.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVutlQ.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFre61(self, self.VVE0qG, title="Installation Path", VVutlQ=VVutlQ)
 def VVE0qG(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVDjKL(FFiGD2(self.Path, True))
   elif item == "toExtensions"  : self.VVDjKL(VVzry0)
   elif item == "toSystemPlugins" : self.VVDjKL(VVATu0)
   elif item == "toRootPath"  : self.VVDjKL("/")
   elif item == "toRoot"   : self.VVDjKL("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVG9LN, BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=VVUQHY))
 def VVG9LN(self, path):
  if len(path) > 0:
   self.VVDjKL(path)
 def VVDjKL(self, parent, withPackageName=True):
  if withPackageName : self.VVT9C9 = parent + self.VVolcZ + "/"
  else    : self.VVT9C9 = "/"
  mode = self.VVXW5L()
  FF2ufE("sed -i '/Package/c\Package: %s' %s" % (self.VVCyU5(mode), self.controlFile))
  self.VVksT1()
 def VV6fJ4(self):
  if fileExists(self.controlFile):
   lines = FF6UEw(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFuRfO(self, self.VVdLik, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF9Njt(self, "Version not found or incorrectly set !")
  else:
   FFvsvw(self, self.controlFile)
 def VVdLik(self, VVF3qs):
  if VVF3qs:
   version, color = self.VVcjJa(VVF3qs, False)
   if color == VVJTsP:
    FF2ufE("sed -i '/Version:/c\Version: %s' %s" % (VVF3qs, self.controlFile))
    self.VVksT1()
   else:
    FF9Njt(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVTVMW(self):
  if self.newControlPath:
   if self.VVfjD5:
    self.VV0TJL()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF0D7j(self.newControlPath, VVBhz1)
    txt += FF0D7j("Do you want to keep these files ?", VVRkew)
    FFfbEx(self, self.close, txt, callBack_No=self.VV0TJL, title="Create Package", VVAbek=True)
  else:
   self.close()
 def VV0TJL(self):
  FF2ufE("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVCyU5(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVhpFD
  if package.startswith(self.VVaol3):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVaol3, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVpHdT : prefix = self.VV5zAI
  elif mode == self.VVjlQ6 : prefix = self.VVE6sD
  return (prefix + name).lower()
 def VVXW5L(self):
  if   self.VVT9C9.startswith(VVzry0) : return self.VVpHdT
  elif self.VVT9C9.startswith(VVATu0) : return self.VVjlQ6
  else            : return self.VV6hKl
 def VVzsJk(self, isFirstTime):
  self.VVolcZ   = FFY1Mj(self.Path)
  self.VVolcZ   = "_".join(self.VVolcZ.split())
  self.VVhpFD = self.VVolcZ.lower()
  self.VVfjD5 = self.VVhpFD == VVsYl4.lower()
  if self.VVfjD5 and self.VVhpFD.endswith(VVsYl4.lower()):
   self.VVhpFD += "el"
  if self.VVfjD5 : self.VVoW7q = VVUQHY
  else    : self.VVoW7q = CFG.packageOutputPath.getValue()
  self.VVoW7q = FFqvjY(self.VVoW7q)
  if not pathExists(self.controlPath):
   FF2ufE("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVXW5L()
  if fileExists(self.controlFile):
   lines = FF6UEw(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVfjD5 : version, descripton, maintainer = VVFo84 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVolcZ , self.VVolcZ
   txt = ""
   txt += "Package: %s\n"  % self.VVCyU5(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVfjD5 : t = PLUGIN_NAME
  else    : t = self.VVolcZ
  self.VVIgGR(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVIgGR(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVfjD5 : self.VVIgGR(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVFo84))
  else    : self.VVIgGR(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVolcZ)
  if isFirstTime and not mode == self.VV6hKl:
   self.postInstAcion = 1
  txt = self.VV2Xdi(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFXk75(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VV2Xdi(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FF2ufE("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVIgGR(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VV2Xdi(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVFyNN(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF6UEw(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF0D7j(line, VV8a8m)
     elif not line.startswith(" ")    : line = FF0D7j(line, VV8a8m)
     else          : line = FF0D7j(line, VVJTsP)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVJTsP
   else   : color = VV8a8m
   descr = FF0D7j(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VV8a8m
     elif line.startswith((" ", "\t")) : color = VV8a8m
     elif line.startswith("#")   : color = VVBhz1
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVcjJa(val, True)
      elif key == "Version"  : version, color = self.VVcjJa(val, False)
      elif key == "Maintainer" : maint  , color = val, VVJTsP
      elif key == "Architecture" : arch  , color = val, VVJTsP
      else:
       color = VVJTsP
      if not key == "OE" and not key.istitle():
       color = VV8a8m
     else:
      color = VVUS1a
     txt += FF0D7j(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVf35F = self.VVoW7q + packageName
   self.VVhxhZ = True
   errTxt = ""
  else:
   self.VVf35F  = ""
   self.VVhxhZ = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVcjJa(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVJTsP
  else          : return val, VV8a8m
 def VVZZXG(self):
  if not self.VVhxhZ:
   FF9Njt(self, "Please fix Control File errors first.")
   return
  if self.VVb8Ad: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFiGD2(self.VVT9C9, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVolcZ
  symlinkTo  = FFHx8R(self.Path)
  dataDir   = self.VVT9C9.rstrip("/")
  removePorjDir = FFYhY6("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFYhY6("rm -f '%s'" % self.VVf35F)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF8IJx()
  if self.VVb8Ad:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFaZl2("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVfjD5:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVT9C9 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVPBDE)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVf35F, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVf35F
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVf35F, FFLPjB(result  , VVRTFm))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVT9C9, FFLPjB(instPath, VVJTsP))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFLPjB(failed, VV8a8m))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF9pl1(self, cmd)
class CC0axI():
 VVr71W  = "666"
 VVq9R3   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVG7pv   = None
  self.VVZ34y()
 def VVZ34y(self):
  VVutlQ = CC0axI.VVt3TU()
  if VVutlQ:
   VVMTOL = ("Create New", self.VVvIyg)
   self.VVG7pv = FFre61(self.SELF, self.VVsgPj, VVutlQ=VVutlQ, title=self.Title, VVMTOL=VVMTOL, VVNxG7=True, VVRdqN="#22222233", VVkSGg="#22222233")
  else:
   self.VVvIyg()
 def VVsgPj(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVwtRw(bName, bRef)
  else:
   CC0axI.VVaqfi(self)
 def VVvIyg(self, selectionObj=None, item=None):
  FFuRfO(self.SELF, BF(self.VVP6mg), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVP6mg(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVG7pv:
     self.VVG7pv.cancel()
    self.VVwtRw(bName, "")
   else:
    FFhSFw(self.VVG7pv, "Incorrect Bouquet Name !", 2000)
    CC0axI.VVaqfi(self)
 def VVwtRw(self, bName, bRef):
  FFVvl9(self.waitMsgSELF, BF(self.VV6pNM, bName, bRef), title="Adding Services ...")
 def VV6pNM(self, bName, bRef):
  CC0axI.VVbZpk(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVaqfi(classObj):
  del classObj
 @staticmethod
 def VVbZpk(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FF9Njt(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVGMYl + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFvsvw(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CC0axI.VVAClG(bRef)
   bPath = VVGMYl + bFile
  else:
   fName = CC3ZOl.VVBr0k(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVGMYl + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVGMYl + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFViMr(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFViMr(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CC3hRa.VV3CCT()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FF2ufE("cp -f '%s' '%s'" % (poster, picon))
       FF2ufE(CCY1HC.VVlIL4(picon))
       break
  FFURke()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFEso0(SELF, txt, title=title)
 @staticmethod
 def VVcKKE(bName):
  mode = CCDaBC.VVG9ZK(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CC3ZOl.VVBr0k(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVGMYl + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVGMYl + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVGMYl, modeTxt)
  if fileExists(mainBFile):
   FFViMr(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VVxrmW(ref, bName):
  bFile = CC0axI.VVAClG(ref)
  ok = False
  if bFile:
   bFile = VVGMYl + bFile
   if fileExists(bFile):
    lines = FF6UEw(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVt3TU(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVutlQ = []
  if mode in (0, 2): VVutlQ.extend(CC0axI.VVV99r(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVutlQ.extend(CC0axI.VVV99r(1, showTitle, prefix, onlyIptv))
  return VVutlQ
 @staticmethod
 def VVV99r(mode, showTitle, prefix, onlyIptv):
  VVutlQ = []
  lst = CC0axI.VVlBqA(mode)
  if onlyIptv:
   lst = CC0axI.VVL5DC(lst)
  if lst:
   if showTitle:
    VVutlQ.append(FFODSa("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVutlQ.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVutlQ.append((item[0], item[1].toString()))
  return VVutlQ
 @staticmethod
 def VVL5DC(lst):
  fLst = CC3ZOl.VVYQhO(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVJHB3():
  lst = CC0axI.VVlBqA(0)
  lst.extend(CC0axI.VVlBqA(1))
  return lst
 @staticmethod
 def VVlBqA(mode=0):
  bList = []
  VV7fnz = InfoBar.instance
  VVObn7 = VV7fnz and VV7fnz.servicelist
  if VVObn7:
   curMode = VVObn7.mode
   CC0axI.VVeAyo(VVObn7, mode)
   bList.extend(VVObn7.getBouquetList() or [])
   CC0axI.VVeAyo(VVObn7, curMode)
  return bList
 @staticmethod
 def VVeAyo(VVObn7, mode):
  if not mode == VVObn7.mode:
   if   mode == 0: VVObn7.setModeTv()
   elif mode == 1: VVObn7.setModeRadio()
 @staticmethod
 def VVnqVH(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VV0WM0 = eServiceCenter.getInstance()
    if onlyMain:
     info = VV0WM0.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VV0WM0 and VV0WM0.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VV0WM0.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVAClG(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVXPeY(ref, dstFile):
  dstFile = VVGMYl + dstFile
  if fileExists(dstFile):
   FFViMr(dstFile)
   bLine = ""
   srcFile = CC0axI.VVAClG(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVGMYl + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVGMYl + newName
     FF2ufE("cp -f '%s%s' '%s'" % (VVGMYl, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVUNhc():
  try:
   fName = CC0axI.VVAClG(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVGMYl, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVdPHV():
  path = CC0axI.VVUNhc()
  if path:
   txt = FFXk75(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVttck():
  return FFmpJ8(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVYvqm():
  lst = []
  for b in CC0axI.VVJHB3():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVGMYl + CC0axI.VVAClG(bRef)
   if fileExists(path):
    lines = FF6UEw(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVl5eE(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVQLYv(SID="", stripRType=False):
  if SID : patt = CC0axI.VVl5eE(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CC0axI.VVJHB3():
   for service in FFmpJ8(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VV9HVA():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CC0axI.VVJHB3():
   for service in FFmpJ8(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVByyr(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVc005(pathLst, rType=""):
  refLst = CC0axI.VVQLYv(CC0axI.VVr71W, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CC0axI.VVByyr(rType, CC0axI.VVr71W, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCLSXF(Screen):
 VVlhCZ   = 0
 VVXivG  = 1
 VVL22N  = 2
 VVhMkj = 3
 VVzwQS    = 20
 VVv3Pv   = 0
 VV5HHq   = 1
 VVw2Ov   = 2
 def __init__(self, session, VVXhi5="/", mode=VVlhCZ, VVkeEZ="Select", width=1400, height=920, VVH0vt=30, VVRdqN="#22001111", VVkSGg="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFzoo9(VVzryP, width, height, 30, 40, 20, VVRdqN, VVkSGg, VVH0vt, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVRdqN   = VVRdqN
  self.VVkSGg    = VVkSGg
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFk1xo(self)
  FFWr7z(self["keyRed"] , "Exit")
  FFWr7z(self["keyYellow"], "More Options")
  FFWr7z(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVkeEZ = VVkeEZ
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VV7Lr3 = None
  if patternMode:
   self.mode = self.VVhMkj
   if   patternMode == "srt"  : VV7Lr3 = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VV7Lr3 = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VV7Lr3 = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VV7Lr3 = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VV7Lr3 = ("^.*\.(%s)$" % "|".join(CCr5ME.VVbcLX()["mov"]), IGNORECASE)
   else       : VV7Lr3 = None
  if self.mode in (self.VVL22N, self.VVhMkj):
   FFWr7z(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVIEld, self.VVXhi5 = True , FFiGD2(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVIEld, self.VVXhi5 = True , CCLSXF.VVtloK(self)[1] or "/"
  elif self.mode == self.VVlhCZ  : VVIEld, self.VVXhi5 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVL22N : VVIEld, self.VVXhi5 = False, VVXhi5
  elif self.mode == self.VVhMkj : VVIEld, self.VVXhi5 = True , VVXhi5
  else           : VVIEld, self.VVXhi5 = True , VVXhi5
  self.VVXhi5 = FFqvjY(self.VVXhi5)
  self["myMenu"] = CCr5ME(  directory   = None
         , VV7Lr3 = VV7Lr3
         , VVIEld   = VVIEld
         , VV1IKd = True
         , VV26p3 = True
         , VVRiUz   = self.skinParam["width"]
         , VVH0vt   = self.skinParam["bodyFontSize"]
         , VVDng6  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VVyU28,
  {
   "ok" : self.VVQHyQ    ,
   "red" : self.VVmWle   ,
   "green" : self.VVLrdl,
   "yellow": self.VV0sHg  ,
   "blue" : self.VVnxgN ,
   "menu" : self.VVTKzD  ,
   "info" : self.VVbNVn  ,
   "cancel": self.VV1P4S    ,
   "pageUp": self.VVMYax   ,
   "chanUp": self.VVMYax
  }, -1)
  FFCRhg(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVuv4N)
  global VVm0Nx
  VVm0Nx = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVlhCZ:
   FFoVhu("VVm0Nx")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVuv4N)
  FFqFdY(self)
  FFRLsp(self["myMenu"], bg=self.cursorBG)
  FFlx3W(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVL22N, self.VVhMkj):
   FFWr7z(self["keyGreen"], self.VVkeEZ)
   self.VVT1av(self.VV5HHq)
  self.VVuv4N()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVDS8O(self.VVXhi5) > self.bigDirSize: FFVvl9(self, self.VVqW4i, title="Changing directory...")
  else              : self.VVqW4i()
 def VVqW4i(self):
  if self.jumpToFile : self.VVjkIo(self.jumpToFile)
  elif self.gotoMovie : self.VVCT6j(chDir=False)
  else    : self["myMenu"].VVoXBq(self.VVXhi5)
 def VVfMAJ(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVXDWd(self):
  FFVvl9(self, self.VVBZCh, title="Refreshing list ...")
 def VVBZCh(self):
  isSel = self["myMenu"].VVPu68()
  if not isSel:
   self.VVyISI(False)
  FFT3Ui()
 def VVB2f1(self, saved):
  if saved: self.VVXDWd()
 def VVDS8O(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVQHyQ(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVLhbs()
   if ok : self["keyBlue"].setText(self.VVWiH8())
   else : FFhSFw(self, "Cannot select item", 500)
  elif self["myMenu"].VV30g7(): self.VVHMCq()
  else       : self.VVrJqE()
 def VVMYax(self):
  if self.multiSelectState:
   FFhSFw(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVfLzW():
    self.VVHMCq()
 def VVHMCq(self, isDirUp=False):
  if self["myMenu"].VV30g7():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVzODq(self.VVepbj())
   if self.VVDS8O(path) > self.bigDirSize : FFVvl9(self, self.VVyTVE, title="Changing directory...")
   else           : self.VVyTVE()
 def VVyTVE(self):
  self["myMenu"].descent()
  self.VVuv4N()
 def VV1P4S(self):
  if   self.multiSelectState     : self.VVyISI(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVmWle()
  else          : self.VVMYax()
 def VVmWle(self):
  if not FFSHcW(self):
   self.close("")
 def VVLrdl(self):
  path = self.VVzODq(self.VVepbj())
  if self.mode == self.VVL22N:
   self.close(path)
  elif self.mode == self.VVhMkj:
   if os.path.isfile(path) : self.close(path)
   else     : FFhSFw(self, "Cannot access this file", 1000)
 def VVbNVn(self):
  FFVvl9(self, self.VVOAhj, title="Calculating size ...")
 def VVOAhj(self):
  path = self.VVzODq(self.VVepbj())
  param = self.VVQ539(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FF7jZM("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCLSXF.VVCzeu(path)
     freeSize = CCLSXF.VVf7tK(path)
     size = totSize - freeSize
     totSize  = CCLSXF.VVtnwF(totSize)
     freeSize = CCLSXF.VVtnwF(freeSize)
    else:
     size = FFRJjL(path)
   usedSize = CCLSXF.VVtnwF(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF0D7j(pathTxt, VVUS1a) + "\n"
   if slBroken : fileTime = self.VVFuas(path)
   else  : fileTime = self.VV4Gpj(path)
   def VVGQB8(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVGQB8("Path"    , pathTxt)
   txt += VVGQB8("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVGQB8("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVGQB8("Total Size"   , "%s" % totSize)
    txt += VVGQB8("Used Size"   , "%s" % usedSize)
    txt += VVGQB8("Free Size"   , "%s" % freeSize)
   else:
    txt += VVGQB8("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVGQB8("Owner"    , owner)
   txt += VVGQB8("Group"    , group)
   txt += VVGQB8("Perm. (User)"  , permUser)
   txt += VVGQB8("Perm. (Group)"  , permGroup)
   txt += VVGQB8("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVGQB8("Perm. (Ext.)" , permExtra)
   txt += VVGQB8("iNode"    , iNode)
   txt += VVGQB8("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVdiFP(path)
  else:
   FF9Njt(self, "Cannot access information !")
  if len(txt) > 0:
   FFEso0(self, txt)
 def VVQ539(self, path):
  path = path.strip()
  path = FFHx8R(path)
  result = FF7jZM("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV6mfX(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV6mfX(perm, 1, 4)
   permGroup = VV6mfX(perm, 4, 7)
   permOther = VV6mfX(perm, 7, 10)
   permExtra = VV6mfX(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFt7KC("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVdiFP(self, path):
  txt  = ""
  res  = FF7jZM("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF0D7j("File Attributes:", VV7CTN), txt)
  return txt
 def VV4Gpj(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFaLO4(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFaLO4(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFaLO4(os.path.getctime(path))
  return txt
 def VVFuas(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF7jZM("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF7jZM("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF7jZM("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVzODq(self, currentSel):
  currentDir  = self["myMenu"].VVWpOw()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV30g7():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVepbj(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVuv4N(self):
  path = self.VVzODq(self.VVepbj())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVf6lZ()
  if self.mode == self.VVlhCZ:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVhMkj:
   path = self.VVzODq(self.VVepbj())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVTKzD(self):
  color1 = VVQrak
  color2 = VVPr8g
  color3 = VVqWCE
  totSel = 0
  menuW = 1000
  title = "Options"
  VVutlQ= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVs3se()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFCMcT(totSel))
     VVutlQ.append((color1 + txt1     , "VVoZDq1" ))
     VVutlQ.append((color1 + txt1 + txt2   , "VVoZDq2" ))
     VVutlQ.append(VVJKCZ)
    VVutlQ.append(("[6] Copy"       , "copyBulk" ))
    VVutlQ.append(("[7] Move"       , "moveBulk" ))
    VVutlQ.append(("[8] %sDELETE" % VVUS1a , "VVwe9o" ))
   else:
    FFhSFw(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVL22N, self.VVhMkj):
   VVutlQ.append(("Properties"           , "properties" ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVzODq(self.VVepbj())
   isEditable = self["myMenu"].VVnv0E()
   VVutlQ.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVutlQ.append(VVJKCZ)
     VVutlQ.append((color1 + "Archiving / Packaging", "VVDKsU_dir"))
   elif os.path.isfile(path):
    selFile = self.VVepbj()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVutlQ.append((color1 + "Archive ...", "VVDKsU_file"))
    isText = False
    txt = ""
    if   isArch            : VVutlQ.extend(self.VVwpfu(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVutlQ.extend(self.VVHjA8(True))
    elif selFile.endswith(".sh"):
     VVutlQ.extend(self.VVALsn(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCLSXF.VV0Q6W(path):
     VVutlQ.append(VVJKCZ)
     VVutlQ.append((color2 + "View"     , "textView_def"))
     VVutlQ.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVutlQ.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVCIil(path) == "pic":
     VVutlQ.append(VVJKCZ)
     VVutlQ.append((color2 + "Set as PIcon for current channel" , "VV5FF1" ))
     if FFVjaP("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVutlQ.append(VVJKCZ)
      VVutlQ.append((color2 + "Convert to MVI (1280 x 720 )" , "VV9ZikHd"   ))
      VVutlQ.append((color2 + "Convert to MVI (1920 x 1080)" , "VV9ZikFhd"   ))
    elif selFile.endswith(CCLSXF.VV9DId()):
     if selFile.endswith(".mvi"):
      if FFVjaP("showiframe"):
       VVutlQ.append(VVJKCZ)
       VVutlQ.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVutlQ.append(VVJKCZ)
      VVutlQ.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVutlQ.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVutlQ.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVutlQ.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVutlQ.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVutlQ.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVov27" ))
    if len(txt) > 0:
     VVutlQ.append(VVJKCZ)
     VVutlQ.append((color1 + txt, "VVrJqE"))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("[4] Create SymLink", "VVvDRE"))
   if isEditable:
    VVutlQ.append(("[5] Rename"      , "VVfd8V" ))
    VVutlQ.append(("[6] Copy"       , "copyFileOrDir" ))
    VVutlQ.append(("[7] Move"       , "moveFileOrDir" ))
    VVutlQ.append(("[8] %sDELETE" % VVUS1a , "VV6rGc" ))
    if fileExists(path):
     VVutlQ.append(VVJKCZ)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVutlQ.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVutlQ.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVutlQ.append((chmodTxt + "777)", "chmod777"))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVutlQ.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCLSXF.VVtloK(self)
   if fPath:
    VVutlQ.append(VVJKCZ)
    VVutlQ.append((color2 + "Go to Current Movie Dir", "VVCT6j"))
  FFre61(self, self.VVbkZx, width=menuW, height=1050, title=title, VVutlQ=VVutlQ, VVGW0b=False, VVRdqN="#00101020", VVkSGg="#00101A2A")
 def VVbkZx(self, item=None):
  if item is not None:
   path = self.VVzODq(self.VVepbj())
   selFile = self.VVepbj()
   if   item == "VVoZDq1"    : self.VVoZDq(False)
   if   item == "VVoZDq2"    : self.VVoZDq(True)
   elif item == "copyBulk"     : self.VVRu6r(False)
   elif item == "moveBulk"     : self.VVRu6r(True)
   elif item == "VVwe9o"    : self.VVwe9o()
   elif item == "properties"    : self.VVbNVn()
   elif item == "VVDKsU_dir" : self.VVDKsU(path, True)
   elif item == "VVDKsU_file" : self.VVDKsU(path, False)
   elif item == "VVE2KU"  : self.VVE2KU(path)
   elif item == "VVFJ99"  : self.VVFJ99(path)
   elif item.startswith("extract_")  : self.VVVBsW(path, selFile, item)
   elif item.startswith("script_")   : self.VVtMzi(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVoozw(path, selFile, item)
   elif item.startswith("textView_def") : FFc1hL(self, path)
   elif item.startswith("textView_enc") : self.VVQr8t(path)
   elif item.startswith("text_Edit")  : CCc3G0(self, path, VVFqvg=self.VVB2f1)
   elif item.startswith("textSave_encUtf8"): self.VVKDL2(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVKDL2(path, "Save as Other Encoding", False)
   elif item.startswith("VVov27") : self.VVov27(path)
   elif item == "viewAsBootlogo"   : self.VVP5tK(path, True)
   elif item == "addMovieToBouquet"  : self.VVITNs(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVITNs(path, True)
   elif item == "playWith"     : self.VVhMtx(path)
   elif item == "VV5FF1" : self.VV5FF1(path)
   elif item == "VV9ZikHd"   : FFVvl9(self, BF(self.VV9Zik, path, False))
   elif item == "VV9ZikFhd"   : FFVvl9(self, BF(self.VV9Zik, path, True))
   elif item == "VVvDRE"   : self.VVvDRE(path, selFile)
   elif item == "VVfd8V"   : self.VVfd8V(path, selFile)
   elif item == "copyFileOrDir"   : self.VV7Drf(path, False)
   elif item == "moveFileOrDir"   : self.VV7Drf(path, True)
   elif item == "VV6rGc"   : self.VV6rGc(path, selFile)
   elif item == "chmod644"     : self.VVue3b(path, selFile, "644")
   elif item == "chmod755"     : self.VVue3b(path, selFile, "755")
   elif item == "chmod777"     : self.VVue3b(path, selFile, "777")
   elif item == "createNewFile"   : self.VVMFEc(path, True)
   elif item == "createNewDir"    : self.VVMFEc(path, False)
   elif item == "VVCT6j"   : self.VVCT6j()
   elif item == "VVrJqE"    : self.VVrJqE()
 def VVrJqE(self):
  if self.mode == self.VVhMkj and not self.patternMode == "poster":
   return
  selFile = self.VVepbj()
  path  = self.VVzODq(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVCIil(path)
   if   cat == "pic"       : self.VV6fhi(path)
   elif cat == "txt"       : FFc1hL(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVr1D9(path, selFile)
   elif cat == "scr"       : self.VVwSdm(path, selFile)
   elif cat == "m3u"       : self.VV8ppg(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVOhPa(path, selFile)
   elif cat in ("mov", "mus")     : self.VVP5tK(path)
   elif not CCLSXF.VV0Q6W(path) : FFc1hL(self, path)
 def VV6fhi(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVCIil(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCMQgO.VVR5E7(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVwDlP)
 def VVwDlP(self, path):
  self.VVjkIo(path)
 def VVP5tK(self, path, asLogo=False):
  if asLogo : CClvUz.VVNhTs(self, path)
  else  : FFVvl9(self, BF(self.VVPDp5, self, path), title="Playing Media ...")
 def VVnxgN(self):
  if self["keyBlue"].getVisible():
   VVUel6 = self.VVFVxl()
   if VVUel6:
    path = self.VVzODq(self.VVepbj())
    enableGreenBtn = False if path in self.VVFVxl() else True
    newList = []
    for line in VVUel6:
     newList.append((line, line))
    VVuLNH  = ("Delete"    , self.VVvyOm    )
    VVzsZa  = ("Add Current Dir"   , BF(self.VVACq0, path) ) if enableGreenBtn else None
    VVMTOL = ("Move Up"     , self.VVyzxl    )
    VVmhL9  = ("Move Down"   , self.VV4evk    )
    self.bookmarkMenu = FFre61(self, self.VVCSfS, width=1200, title="Bookmarks", VVutlQ=newList, minRows=10 ,VVuLNH=VVuLNH, VVzsZa=VVzsZa, VVMTOL=VVMTOL, VVmhL9=VVmhL9, VVRdqN="#00000022", VVkSGg="#00000022")
 def VVvyOm(self, VVG7pv=None, path=None):
  VVUel6 = self.VVFVxl()
  if VVUel6:
   while path in VVUel6:
    VVUel6.remove(path)
   self.VVGma9(VVUel6)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV1C6X(VVUel6)
   self.bookmarkMenu.VVydH2(("Add Current Dir", BF(self.VVACq0, path)))
  else:
   FFhSFw(self, "Removed", 800)
  self.VVf6lZ()
 def VVACq0(self, path, VVG7pv=None, item=None):
  VVUel6 = self.VVFVxl()
  if len(VVUel6) >= self.VVzwQS:
   FF9Njt(SELF, "Max bookmarks reached (max=%d)." % self.VVzwQS)
  elif not path in VVUel6:
   if not os.path.isdir(path):
    path = FFiGD2(path, True)
   newList = [path] + VVUel6
   self.VVGma9(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV1C6X(newList)
    self.bookmarkMenu.VVydH2()
   else:
    FFhSFw(self, "Added", 800)
  self.VVf6lZ()
 def VVyzxl(self, selectionObj, path):
  if self.bookmarkMenu:
   VVUel6 = self.bookmarkMenu.VVMkUK(True)
   if VVUel6:
    self.VVGma9(VVUel6)
 def VV4evk(self, selectionObj, path):
  if self.bookmarkMenu:
   VVUel6 = self.bookmarkMenu.VVMkUK(False)
   if VVUel6:
    self.VVGma9(VVUel6)
 def VVCSfS(self, folder=None):
  if folder:
   folder = FFqvjY(folder)
   self["myMenu"].VVoXBq(folder)
   self["myMenu"].moveToIndex(0)
  self.VVuv4N()
 def VVFVxl(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV47WH(self):
  return True if VVFVxl() else False
 def VVGma9(self, VVUel6):
  line = ",".join(VVUel6)
  FF3Ual(CFG.browserBookmarks, line)
 def VVjkIo(self, path):
  if fileExists(path):
   fDir  = FFqvjY(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVoXBq(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFhSFw(self, "Not found", 1000)
 def VVCT6j(self, chDir=True):
  fPath, fDir, fName = CCLSXF.VVtloK(self)
  self.VVjkIo(fPath)
 def VV0sHg(self):
  path = self.VVzODq(self.VVepbj())
  isAdd = False if path in self.VVFVxl() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVJTsP, VVFWDt, VVPr8g
  VVutlQ = []
  VVutlQ.append(("Find Files ..." , "find"))
  VVutlQ.append(("Sort ..."   , "sort"))
  VVutlQ.append(VVJKCZ)
  if isAdd: VVutlQ.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVutlQ.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVlhCZ:
   VVutlQ.append(VVJKCZ)
   if self.multiSelectState: VVutlQ.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVutlQ.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVutlQ.append(       (c3 + "Select all"    , "selAll"  ))
  FFre61(self, BF(self.VVevzE, path), width=750, title="More Options", VVutlQ=VVutlQ, VVRdqN="#00221111", VVkSGg="#00221111")
 def VVevzE(self, path, item):
  if item:
   if   item == "find"  : self.VVixYP(path)
   elif item == "sort"  : self.VVG8lt()
   elif item == "addBM" : self.VVACq0(path)
   elif item == "remBM" : self.VVvyOm(None, path)
   elif item == "start" : self.VV8bS7(path)
   elif item == "multiOn" : self.VVyISI(True)
   elif item == "multiOff" : self.VVyISI(False)
   elif item == "selAll" : self.VVyISI(True, True)
 def VVyISI(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFVvl9(self, BF(self["myMenu"].VVJSLT, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVT1av(self.VVw2Ov if isOn else self.VVv3Pv)
 def VVT1av(self, mode=0):
  if   mode == self.VV5HHq : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVw2Ov: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVRdqN, self.VVkSGg
  FFiva8(self["myTitle"], titBg)
  FFiva8(self["myBar"], titBg)
  FFiva8(self["myBody"], bodBg)
  FFiva8(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVWiH8()
  else     : bg, txt = VVVNZR[3], "Bookmarks"
  FFWr7z(self["keyBlue"], txt)
  FFiva8(self["keyBlue"], bg)
  self.VVf6lZ()
 def VVWiH8(self):
  return "Selected Items = %d" % self["myMenu"].VVs3se()
 def VVf6lZ(self):
  if self.VVFVxl() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVixYP(self, path):
  VVutlQ = []
  VVutlQ.append(("Find in Current Directory"    , "findCur"  ))
  VVutlQ.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVutlQ.append(("Find in all Storage Systems"    , "findAll"  ))
  FFre61(self, BF(self.VV0Vsy, path), width=700, title="Find File/Pattern", VVutlQ=VVutlQ, VVNxG7=True, VVLIB1=True, VVRdqN="#00221111", VVkSGg="#00221111")
 def VV0Vsy(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVx7Fm(0, path, title)
   elif item == "findCurR" : self.VVx7Fm(1, path, title)
   elif item == "findAll" : self.VVx7Fm(2, path, title)
 def VVx7Fm(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFuRfO(self, BF(self.VVG3qO, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVG3qO(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FF3Ual(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFhSFw(self, "No entery", 1500)
   elif badLst  : FFhSFw(self, "Too many file !", 1500)
   else   : FFVvl9(self, BF(self.VV1iub, mode, path, title, filePatt), title="Searching ...")
 def VV1iub(self, mode, path, title, filePatt):
  lst = FFlfx8(FF2F4M("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCLSXF.VVTvbh(lst)
   if err:
    FF9Njt(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VV5qt4 = (""     , self.VV9PNB , [])
    VVDle6 = ("Go to File Location", self.VVcH4O  , [])
    FFvfpt(self, None, title="%s : %s" % (title, filePatt), header=header, VVUel6=lst, VVFNzW=widths, VVH0vt=26, VV5qt4=VV5qt4, VVDle6=VVDle6)
  else:
   FFGp67(self, "Not found !", 2000)
 def VVcH4O(self, VVhkUd, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVhkUd.cancel()
   self.VVjkIo(path)
  else:
   FFhSFw(VVhkUd, "Path not found !", 1000)
 def VV9PNB(self, VVhkUd, title, txt, colList):
  txt = "%s\n%s\n\n" % (FF0D7j("File:"  , VVPr8g), colList[0])
  txt += "%s\n%s"  % (FF0D7j("Directory:", VVPr8g), FFqvjY(colList[1]))
  FFEso0(VVhkUd, txt, title=title)
 def VVG8lt(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVDPUa()
  VVutlQ = []
  VVutlQ.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVutlQ.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVutlQ.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVutlQ.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVmhL9 = ("Mix", BF(self.VVIMjM, True))
  FFre61(self, BF(self.VVYGZX, False), barText=txt, width=650, title="Sort Options", VVutlQ=VVutlQ, VVmhL9=VVmhL9, VVLIB1=True, VVRdqN="#00221111", VVkSGg="#00221111")
 def VVIMjM(self, isMix, VVG7pv, item):
  self.VVYGZX(True, item)
 def VVYGZX(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVDPUa()
   title = "Sorting ... "
   if   item == "nameAlp": FFVvl9(self, BF(self["myMenu"].VV9VG6, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFVvl9(self, BF(self["myMenu"].VV9VG6, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFVvl9(self, BF(self["myMenu"].VV9VG6, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFVvl9(self, BF(self["myMenu"].VV9VG6, typeMode , isMix, False), title=title)
 def VV8bS7(self, path):
  if not os.path.isdir(path):
   path = FFiGD2(path, True)
  FF3Ual(CFG.browserStartPath, path)
  FFhSFw(self, "Done", 500)
 def VVmnUa(self, selFile, VVumEG, command):
  FFfbEx(self, BF(FF9pl1, self, command, consFont=True, VVsWF3=self.VVXDWd), "%s\n\n%s" % (VVumEG, selFile))
 def VVwpfu(self, path, calledFromMenu):
  destPath = self.VVW4J1(path)
  lastPart = FFY1Mj(destPath)
  color = VVPr8g if calledFromMenu else ""
  VVutlQ = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVutlQ.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVutlQ.append(VVJKCZ)
   VVutlQ.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVutlQ.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVutlQ.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVutlQ.append(VVJKCZ)
     VVutlQ.append((color + "Convert .zip to .tar.gz"       , "VVE2KU" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVutlQ.append(VVJKCZ)
     VVutlQ.append((color + "Convert .tar.gz to .zip"       , "VVFJ99" ))
  return VVutlQ
 def VVr1D9(self, path, selFile):
  FFre61(self, BF(self.VVVBsW, path, selFile), title="Compressed File Options", VVutlQ=self.VVwpfu(path, False))
 def VVVBsW(self, path, selFile, item=None):
  if item is not None:
   parent  = FFiGD2(path, False)
   destPath = self.VVW4J1(path)
   lastPart = FFY1Mj(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFaZl2("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFaZl2("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FFmUBH(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVE2KU" : self.VVE2KU(path)
    else       : self.VVI0sc(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVFJ99" and path.endswith(".tar.gz"):
    self.VVFJ99(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FF7jZM("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFmMPS(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVXDWd()
    else:
     FF9Njt(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVe1vx(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFYhY6("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVmnUa(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVmnUa(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFiGD2(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVmnUa(selFile, "Extract Here ?"      , cmd)
 def VVW4J1(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVI0sc(self, item, path, parent, destPath, VVumEG):
  FFfbEx(self, BF(self.VVajM0, item, path, parent, destPath), VVumEG)
 def VVajM0(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFaZl2("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFLPjB(destPath, VVRTFm))
  cmd +=   sep
  cmd += "fi;"
  FF6W91(self, cmd, VVsWF3=self.VVXDWd)
 def VVe1vx(self, item, path, parent, destPath, VVumEG):
  FFfbEx(self, BF(self.VV7YlL, item, path, parent, destPath), VVumEG)
 def VV7YlL(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFqvjY(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFaZl2("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFLPjB(destPath, VVRTFm))
  cmd +=   sep
  cmd += "fi;"
  FF6W91(self, cmd, VVsWF3=self.VVXDWd)
 def VVALsn(self, addSep=False):
  VVutlQ = []
  if addSep:
   VVutlQ.append(VVJKCZ)
  VVutlQ.append((VVPr8g + "View Script File"  , "script_View"  ))
  VVutlQ.append((VVPr8g + "Execute Script File" , "script_Execute" ))
  VVutlQ.append((VVPr8g + "Edit"     , "script_Edit"  ))
  return VVutlQ
 def VVwSdm(self, path, selFile):
  FFre61(self, BF(self.VVtMzi, path, selFile), title="Script File Options", VVutlQ=self.VVALsn())
 def VVtMzi(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFc1hL(self, path)
   elif item == "script_Execute" : self.VVmnUa(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCc3G0(self, path, VVFqvg=self.VVB2f1)
 def VVHjA8(self, addSep=False):
  VVutlQ = []
  if addSep:
   VVutlQ.append(VVJKCZ)
  VVutlQ.append((VVPr8g + "Browse IPTV Channels" , "m3u_Browse" ))
  VVutlQ.append((VVPr8g + "Edit"     , "m3u_Edit" ))
  VVutlQ.append((VVPr8g + "View"     , "m3u_View" ))
  return VVutlQ
 def VV8ppg(self, path, selFile):
  FFre61(self, BF(self.VVoozw, path, selFile), title="M3U/M3U8 File Options", VVutlQ=self.VVHjA8())
 def VVoozw(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFVvl9(self, BF(self.session.open, CC3ZOl, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCc3G0(self, path, VVFqvg=self.VVB2f1)
   elif item == "m3u_View"  : FFc1hL(self, path)
 def VVQr8t(self, path):
  if fileExists(path) : FFVvl9(self, BF(CCDQtT.VVuKpV, self, path, BF(self.VVv4C0, path)), title="Loading Codecs ...")
  else    : FFvsvw(self, path)
 def VVv4C0(self, path, item=None):
  if item:
   FFc1hL(self, path, encLst=item)
 def VVKDL2(self, path, title, asUtf8):
  if fileExists(path) : FFVvl9(self, BF(CCDQtT.VVuKpV, self, path, BF(self.VVOlU2, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFvsvw(self, path)
 def VVOlU2(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VV10Q4(path, title, fromEnc, "UTF-8")
   else  : CCDQtT.VVB9XY(self, BF(self.VV10Q4, path, title, fromEnc), title="Convert to Encoding")
 def VV10Q4(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FF0D7j("Successful\n\n", VVRTFm)
      txt += FF0D7j("From Encoding (%s):\n" % fromEnc, VVRkew)
      txt += "%s\n\n" % path
      txt += FF0D7j("To Encoding (%s):\n" % toEnc, VVRkew)
      txt += "%s\n\n" % outFile
      FFEso0(self, txt, title=title)
    except:
     FF9Njt(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFhSFw(self, "Cannot open file", 2000)
   self.VVXDWd()
 def VVov27(self, path):
  title = "File Line-Break Conversion"
  FFfbEx(self, BF(self.VVQmnT, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVQmnT(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FF0D7j("File converted:", VVRTFm), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFmMPS(self, txt, title=title)
  else:
   FFvsvw(self, path, title=title)
 def VVue3b(self, path, selFile, newChmod):
  FFfbEx(self, BF(self.VVza2s, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVza2s(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVYXrW)
  result = FF7jZM(cmd)
  if result == "Successful" : FFmMPS(self, result)
  else      : FF9Njt(self, result)
 def VVvDRE(self, path, selFile):
  parent = FFiGD2(path, False)
  self.session.openWithCallback(self.VVoQWv, BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=parent, VVkeEZ="Create Symlink here"))
 def VVoQWv(self, newPath):
  if len(newPath) > 0:
   target = self.VVzODq(self.VVepbj())
   target = FFHx8R(target)
   linkName = FFY1Mj(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFqvjY(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF9Njt(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFfbEx(self, BF(self.VVZJv1, target, link), "Create Soft Link ?\n\n%s" % txt, VVAbek=True)
 def VVZJv1(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVYXrW)
  result = FF7jZM(cmd)
  if result == "Successful" : FFmMPS(self, result)
  else      : FF9Njt(self, result)
 def VVfd8V(self, path, selFile):
  lastPart = FFY1Mj(path)
  FFuRfO(self, BF(self.VVSzif, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVSzif(self, path, selFile, VVF3qs):
  if VVF3qs:
   parent = FFiGD2(path, True)
   if os.path.isdir(path):
    path = FFHx8R(path)
   newName = parent + VVF3qs
   cmd = "mv '%s' '%s' %s" % (path, newName, VVYXrW)
   if VVF3qs:
    if selFile != VVF3qs:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFfbEx(self, BF(self.VVRvWt, cmd), message, title="Rename file?")
    else:
     FF9Njt(self, "Cannot use same name!", title="Rename")
 def VVRvWt(self, cmd):
  result = FF7jZM(cmd)
  if "Fail" in result:
   FF9Njt(self, result)
  self.VVXDWd()
 def VVoZDq(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVCt1z, title, preserve)
      , VVFqvg = BF(self.VVB5wL, title))
 def VVCt1z(self, title, preserve, VVdu90):
  totSel = self["myMenu"].VVs3se()
  totOk = totFail = 0
  VVdu90.VV7hIf(totSel)
  VVdu90.VVeIVc = ["", totSel, totOk, totFail, ""]
  VVdu90.VVnUuP("Prepareing targz file")
  curDir = self["myMenu"].VVWpOw()
  lastPart = FFY1Mj(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVdu90 or VVdu90.isCancelled:
      return
     if row[2][6]:
      VVdu90.VVRbmv(1)
      name  = FFHx8R(row[0][0])
      lastPath = FFY1Mj(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVdu90:
       VVdu90.VVeIVc = [outF, totSel, totOk, totFail, path]
       VVdu90.VVxRn8(totOk, lastPath)
  except:
   totFail += 1
   if VVdu90:
    VVdu90.VVeIVc = [outF, totSel, totOk, totFail, path]
 def VVB5wL(self, title, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVeIVc
  txt  = "%s:\n%s\n\n"   % (FF0D7j("Output File", VVRTFm), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FF0D7j("Failed\t: %d\n" % totFail, VVUS1a)
  if not VVegYv: txt += "%s\n%s" % (FF0D7j("\nCancelled while copying:", VVUS1a), path)
  FFEso0(self, txt, title=title)
  self.VVXDWd()
 def VVRu6r(self, isMove):
  self.session.openWithCallback(BF(self.VV4zBz, isMove), BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=self["myMenu"].VVWpOw(), VVkeEZ="Move to here" if isMove else "Paste here"))
 def VV4zBz(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVXJzR, title, action, isMove, newPath)
       , VVFqvg = BF(self.VV788W, title, action, isMove, newPath))
 def VVXJzR(self, title, action, isMove, newPath, VVdu90):
  curDir = self["myMenu"].VVWpOw()
  totOk = totFail = 0
  totSel = self["myMenu"].VVs3se()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVdu90.VV7hIf(totSel)
  VVdu90.VVeIVc = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVdu90 or VVdu90.isCancelled:
    return
   if row[2][6]:
    VVdu90.VVRbmv(1)
    VVdu90.VVgJEk(action, totOk, FFY1Mj(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFY1Mj(path)
    if os.path.isdir(path): path = FFHx8R(path)
    dest = os.path.join(newPath, lastPart)
    if FF2ufE("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVdu90:
     VVdu90.VVeIVc = [totSel, totOk, totFail, path]
     VVdu90.VVgJEk(action, totOk, FFY1Mj(row[0][0]))
 def VV788W(self, title, action, isMove, newPath, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVeIVc
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FF0D7j("Failed\t: %d\n" % totFail, VVUS1a)
  if not VVegYv: txt += "%s\n%s" % (FF0D7j("\nCancelled while copying:", VVUS1a), path)
  FFEso0(self, txt, title=title)
  self.VVXDWd()
 def VVwe9o(self):
  tot = self["myMenu"].VVs3se()
  FFfbEx(self, BF(FFVvl9, self, self.VVz5I0, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFCMcT(tot)), title="Delete Selection")
 def VVz5I0(self):
  path = self["myMenu"].VVWpOw()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFEYIA(os.path.join(path, row[0][0]))
  FFhSFw(self)
  self.VVXDWd()
 def VV7Drf(self, path, isMove):
  self.session.openWithCallback(BF(self.VVEAOu, isMove, path), BF(CCLSXF, mode=CCLSXF.VVL22N, VVXhi5=FFiGD2(path, False), VVkeEZ="Move to here" if isMove else "Paste here"))
 def VVEAOu(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFHx8R(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFHx8R(src)
  dst = os.path.join(dst, FFY1Mj(src))
  if src == dst:
   FF9Njt(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFfbEx(self, BF(self.VVOoD2, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFfbEx(self, BF(self.VVOoD2, prams), "Overwrite Destination Files", title=title)
  else         : self.VVOoD2(prams)
 def VVOoD2(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCLSXF.VVzPhC(src) == CCLSXF.VVzPhC(dst):
   FFVvl9(self, BF(self.VVtPmQ, prams), title="Moving %s ..." % srcSubj)
  else:
   FFVvl9(self, BF(self.VVf7oe, prams), title="Calculating Size ...")
 def VVtPmQ(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FF7jZM("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVXDWd()
  else:
   FF9Njt(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVf7oe(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFrMJ0(src)
  else  : size = FFRJjL(src)
  if size > -1:
   self.session.open(CC1jbq, barTheme=CC1jbq.VVsWWa, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVCCWl, prams, size)
       , VVFqvg = BF(self.VVtkp9, prams))
  else:
   FF9Njt(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVCCWl(self, prams, size, VVdu90):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVdu90.VV7hIf(size)
  VVdu90.VVeIVc = ("", "", False)
  def VVOv31(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFEUy9(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVdu90 or VVdu90.isCancelled:
        VVdu90.VVeIVc = (srcFile, "", True)
        FFEUy9(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVdu90.VVRbmv(len(data))
       except Exception as e:
        VVdu90.VVeIVc = (srcFile, str(e), False)
        FFEUy9(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFEUy9(srcFile)
   return True
  if isFile:
   tot = 1
   VVOv31(src, dst)
  else:
   VVdu90.VVnUuP("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFldVs(src)
   if not VVdu90 or VVdu90.isCancelled:
    VVdu90.VVeIVc = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVdu90.VVeIVc = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVdu90.VVnUuP("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVOv31(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FF2ufE("rm -fr '%s'" % Dir)
   if isMove:
    FF2ufE("rm -fr '%s'" % src)
 def VVtkp9(self, prams, VVegYv, VVeIVc, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVeIVc
  if err:
   FF9Njt(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFhSFw(self, "Canelled", 1000)
   else  : FF9Njt(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFhSFw(self, "Done", 1500, isGrn=True)
  if VVegYv and isMove:
   self.VVXDWd()
 def VV6rGc(self, path, fileName):
  path = FFHx8R(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFfbEx(self, BF(FFVvl9, self, BF(self.VV8iw8, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV8iw8(self, path):
  FFEYIA(path)
  FFhSFw(self)
  self.VVXDWd()
 def VVMFEc(self, path, isFile):
  dirName = FFqvjY(os.path.dirname(path))
  if isFile : objName, VVF3qs = "File"  , self.edited_newFile
  else  : objName, VVF3qs = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFuRfO(self, BF(self.VV6jhP, dirName, isFile, title), title=title, defaultText=VVF3qs, message="Enter %s Name:" % objName)
 def VV6jhP(self, dirName, isFile, title, VVF3qs):
  if VVF3qs:
   if isFile : self.edited_newFile = VVF3qs
   else  : self.edited_newDir  = VVF3qs
   path = dirName + VVF3qs
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVYXrW)
    else  : cmd = "mkdir '%s' %s" % (path, VVYXrW)
    result = FF7jZM(cmd)
    if "Fail" in result:
     FF9Njt(self, result)
    self.VVXDWd()
   else:
    FF9Njt(self, "Name already exists !\n\n%s" % path, title)
 def VVOhPa(self, path, selFile):
  c1, c2, c3 = VVFWDt, VVPr8g, VVQrak
  VVutlQ = []
  VVutlQ.append((c1 + "List Package Files"         , "VVas9D"     ))
  VVutlQ.append((c1 + "Package Information"         , "VVdhnQ"     ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Install Package"          , "VVvGXP_CheckVersion" ))
  VVutlQ.append((c2 + "Install Package (force reinstall)"     , "VVvGXP_ForceReinstall" ))
  VVutlQ.append((c2 + "Install Package (force overwrite)"     , "VVvGXP_ForceOverwrite" ))
  VVutlQ.append((c2 + "Install Package (force downgrade)"     , "VVvGXP_ForceDowngrade" ))
  VVutlQ.append((c2 + "Install Package (ignore failed dependencies)"  , "VVvGXP_IgnoreDepends" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c3 + "Remove Related Package"        , "VV2YRB_ExistingPackage" ))
  VVutlQ.append((c3 + "Remove Related Package (force remove)"    , "VV2YRB_ForceRemove"  ))
  VVutlQ.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VV2YRB_IgnoreDepends" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Extract Files"           , "VVf6TA"     ))
  VVutlQ.append(("Unbuild Package"           , "VVFjdy"     ))
  FFre61(self, BF(self.VVuoM2, path, selFile), VVutlQ=VVutlQ)
 def VVuoM2(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVas9D"      : self.VVas9D(path, selFile)
   elif item == "VVdhnQ"      : self.VVdhnQ(path)
   elif item == "VVvGXP_CheckVersion"  : self.VVvGXP(path, selFile, VVtZiS     )
   elif item == "VVvGXP_ForceReinstall" : self.VVvGXP(path, selFile, VVpQG6 )
   elif item == "VVvGXP_ForceOverwrite" : self.VVvGXP(path, selFile, VVaEyM )
   elif item == "VVvGXP_ForceDowngrade" : self.VVvGXP(path, selFile, VVobz0 )
   elif item == "VVvGXP_IgnoreDepends" : self.VVvGXP(path, selFile, VVbZpU )
   elif item == "VV2YRB_ExistingPackage" : self.VV2YRB(path, selFile, VVRTxu     )
   elif item == "VV2YRB_ForceRemove"  : self.VV2YRB(path, selFile, VVHJv5  )
   elif item == "VV2YRB_IgnoreDepends"  : self.VV2YRB(path, selFile, VV472U )
   elif item == "VVf6TA"     : self.VVf6TA(path, selFile)
   elif item == "VVFjdy"     : self.VVFjdy(path, selFile)
 def VVas9D(self, path, selFile):
  if FFVjaP("ar") : cmd = "allOK='1';"
  else    : cmd  = FF8IJx()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFPlAt(self, cmd, VVsWF3=self.VVXDWd)
 def VVf6TA(self, path, selFile):
  lastPart = FFY1Mj(path)
  dest  = FFiGD2(path, True) + selFile[:-4]
  cmd  =  FF8IJx()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFYhY6("mkdir '%s'" % dest)
  cmd +=    FFYhY6("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFLPjB(dest, VVRTFm))
  cmd += "fi;"
  FF9pl1(self, cmd, VVsWF3=self.VVXDWd)
 def VVFjdy(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVdjLk = os.path.splitext(path)[0]
  else        : VVdjLk = path + "_"
  if path.endswith(".deb")   : VVPBDE = "DEBIAN"
  else        : VVPBDE = "CONTROL"
  cmd  = FF8IJx()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVdjLk
  cmd += "  mkdir '%s';"      % VVdjLk
  cmd += "  CONTPATH='%s/%s';"    % (VVdjLk, VVPBDE)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVdjLk
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVdjLk, VVdjLk)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVdjLk
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVdjLk, VVdjLk)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVdjLk
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVdjLk
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVdjLk, FFLPjB(VVdjLk, VVRTFm))
  cmd += "fi;"
  FF9pl1(self, cmd, VVsWF3=self.VVXDWd)
 def VVdhnQ(self, path):
  listCmd  = FFwyvS(VVf00o, "")
  infoCmd  = FFciUY(VV7ZXX , "")
  filesCmd = FFciUY(VV3lW5, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFGl7m(VVRkew)
   notInst = "Package not installed."
   cmd  = FFm5eu("File Info", VVRkew)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFm5eu("System Info", VVRkew)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFLPjB(notInst, VVUS1a))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFm5eu("Related Files", VVRkew)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFmUBH(self, cmd)
  else:
   FFdRu7(self)
 def VVvGXP(self, path, selFile, cmdOpt):
  cmd = FFciUY(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFfbEx(self, BF(FF9pl1, self, cmd, VVsWF3=FFT3Ui), "Install Package ?\n\n%s" % selFile)
  else:
   FFdRu7(self)
 def VV2YRB(self, path, selFile, cmdOpt):
  listCmd  = FFwyvS(VVf00o, "")
  infoCmd  = FFciUY(VV7ZXX, "")
  instRemCmd = FFciUY(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFLPjB(errTxt, VVUS1a))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFLPjB(cannotTxt, VVUS1a))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFLPjB(tryTxt, VVUS1a))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFfbEx(self, BF(FF9pl1, self, cmd, VVsWF3=FFT3Ui), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFdRu7(self)
 def VV1MHY(self, path):
  hostName = FF7jZM("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVDKsU(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVutlQ = []
  VVutlQ.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVutlQ.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVutlQ.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVutlQ.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVutlQ.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVutlQ.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVutlQ.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVutlQ.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVutlQ.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVutlQ.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFre61(self, BF(self.VVnCAd, path, isDir, title), VVutlQ=VVutlQ, title=title, VVRdqN=c1, VVkSGg=c2)
 def VVnCAd(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVaKFW(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVaKFW(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVaKFW(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVaKFW(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVaKFW(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVaKFW(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVaKFW(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVaKFW(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVaKFW(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVaKFW(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVvhvC(path, False)
   elif item == "convertDirToDeb" : self.VVvhvC(path, True)
 def VVvhvC(self, path, VVb8Ad):
  self.session.openWithCallback(self.VVXDWd, BF(CCRQQt, path=path, VVb8Ad=VVb8Ad))
 def VVaKFW(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFiGD2(path, True)
  lastPart = FFY1Mj(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFaZl2("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFaZl2("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFaZl2("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFYhY6("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFLPjB(failed, VVO7vL))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFLPjB(srcTxt, VVJTsP))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFLPjB("Output", VVRTFm))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFLPjB(failed, VV8a8m))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFPlAt(self, cmd, VVsWF3=self.VVXDWd, title=title)
 def VVITNs(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCLSXF.VVcvPO(FFiGD2(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CC0axI(self, self, title, BF(self.VVTXER, pathLst))
 def VVTXER(self, pathLst):
  return CC0axI.VVc005(pathLst)
 def VVE2KU(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVy4Ei, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFfbEx(self, BF(FFVvl9, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFVvl9(self, fnc, title=txt)
  else:
   FF9Njt(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVy4Ei(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFEso0(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVXDWd()
  else:
   FFEUy9(tarPath)
   FF9Njt(self, "Error while converting.", title=title)
 def VVFJ99(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVEy7Z, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFfbEx(self, BF(FFVvl9, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFVvl9(self, fnc, title=txt)
  else:
   FF9Njt(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVEy7Z(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFEso0(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVXDWd()
  else:
   FFEUy9(zipPath)
   FF9Njt(self, "Error while converting.", title=title)
 def VV9Zik(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFqvjY(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FF2ufE("rm -f '%s' '%s'" % (m1v, mvi))
  if FF2ufE("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FF2ufE("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVXDWd()
   FFmMPS(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FF9Njt(self, "Cannot convert this file !", title=title)
 def VV5FF1(self, path):
  title = "Set as PIcon for current channel"
  pPath = CC3hRa.VV3CCT()
  if pathExists(pPath):
   if CC4Zpg.VVafHZ(self, title, False, cbFnc=BF(self.VV5FF1, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVutlQ = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVutlQ.append(("%d x %d" % (item), item))
    VVRIxl = self.VVbApn
    VVmhL9 = ("Stretch", BF(self.VVO98J, title, path, picon))
    VVG7pv = FFre61(self, BF(self.VV06hj, title, path, picon, False), VVutlQ=VVutlQ, width=700, title='PIcon Max. Size', VVRIxl=VVRIxl, VVmhL9=VVmhL9, barText="OK = Fit within size")
    VVG7pv.VV75it(3)
  else:
   FF9Njt(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVO98J(self, title, path, picon, selectionObj, item):
  self.VV06hj(title, path, picon, True, item)
  selectionObj.cancel()
 def VV06hj(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FF0gQ0(self, fncMode=CCY1HC.VVbVB0)
   except Exception as e:
    FF9Njt(self, "Image Processing error:\n\n%s" % e)
 def VVbApn(self, VVG7pv, txt, ref, ndx):
  FF1D9G(self, "_help_resize", "Picture File Resizing")
 def VVhMtx(self, path):
  FFre61(self, BF(self.VVVSLF, path), VVutlQ=CC3ZOl.VVq62G(), width=650, title="Select Player", VVRdqN="#11220000", VVkSGg="#11220000")
 def VVVSLF(self, path, rType=None):
  if rType:
   FFVvl9(self, BF(self.VVPDp5, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVPDp5(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCGzpp.VVfWLm(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVtloK(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFqvjY(fDir), fName
  return "", "", ""
 @staticmethod
 def VVCzeu(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVf7tK(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVtnwF(size, mode=0):
  txt = CCLSXF.VVlJ4C(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVlJ4C(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VV0Q6W(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVpzqc(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FF9Njt(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV9DId():
  tDict = CCr5ME.VVbcLX()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVcvPO(path):
  lst = []
  for ext in CCLSXF.VV9DId():
   lst.extend(FFJwmB(path, "*.%s" % ext))
  return sorted(lst, key=FF2BO2(FFhvfk))
 @staticmethod
 def VVGkwN(path):
  return FF2ufE("tar -tzf '%s'" % path)
 @staticmethod
 def VVzPhC(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVTvbh(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVLdCF:
   return VVLdCF
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCr5ME(MenuList):
 VVBVeZ   = 0
 VVnqiB   = 1
 VVhS3m   = 2
 VVigsY   = 3
 VV0GAs   = 4
 VVSIRj   = 5
 VV8nS5   = 6
 VVZB6D   = 7
 VVaEEj   = "<List of Storage Devices>"
 VVHgCU  = "<Parent Directory>"
 VVFccn   = 0
 VV1MFJ   = 1
 VVzney = 2
 VVC9IW  = 3
 VVLqMB   = 4
 VVmtFJ   = 5
 FILE_TYPE_LINK   = 6
 VVQ7tp  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VV26p3=False, directory="/", VVcXwj=True, VVIEld=True, VV1IKd=True, VV7Lr3=None, VVfPZ9=False, VVY47Q=False, VVRSyf=False, isTop=False, VVB95Y=None, VVRiUz=1000, VVH0vt=30, VVDng6=30):
  MenuList.__init__(self, list, VV26p3, eListboxPythonMultiContent)
  self.VVcXwj  = VVcXwj
  self.VVIEld    = VVIEld
  self.VV1IKd  = VV1IKd
  self.VV7Lr3  = VV7Lr3
  self.VVfPZ9   = VVfPZ9
  self.VVY47Q   = VVY47Q or []
  self.VVRSyf   = VVRSyf or []
  self.isTop     = isTop
  self.additional_extensions = VVB95Y
  self.VVRiUz    = VVRiUz
  self.VVH0vt    = VVH0vt
  self.VVDng6    = VVDng6
  self.EXTENSIONS    = CCr5ME.VVbcLX()
  self.VV0WM0   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFkpAV("#11ff4444")
  self.l.setFont(0, gFont(VVczsY, self.VVH0vt))
  self.l.setItemHeight(self.VVDng6)
  self.png_mem   = CCr5ME.VVQDUE("mem")
  self.png_usb   = CCr5ME.VVQDUE("usb")
  self.png_fil   = CCr5ME.VVQDUE("fil")
  self.png_dir   = CCr5ME.VVQDUE("dir")
  self.png_dirup   = CCr5ME.VVQDUE("dirup")
  self.png_srv   = CCr5ME.VVQDUE("srv")
  self.png_slwfil   = CCr5ME.VVQDUE("slwfil")
  self.png_slbfil   = CCr5ME.VVQDUE("slbfil")
  self.png_slwdir   = CCr5ME.VVQDUE("slwdir")
  self.VVnagy()
  self.VVoXBq(directory)
 @staticmethod
 def VVQDUE(category):
  return LoadPixmap("%s%s.png" % (VV8pP1, category), getDesktop(0))
 @staticmethod
 def VVbcLX():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVwKzf(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFHx8R(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF0D7j(" -> " , VVRkew) + FF0D7j(os.readlink(path), VVRTFm)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVDng6 + 10, 0, self.VVRiUz, self.VVDng6, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CClArU.VVAekn(0, 2, self.VVDng6-4, self.VVDng6-4, png))
  return tableRow
 def VVCIil(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVnagy(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVPEwB(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VViRhe(self, file):
  if os.path.realpath(file) == file:
   return self.VVPEwB(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVPEwB(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVPEwB(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVLhbs(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VV1J7L(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVJSLT(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VV1J7L(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VV1J7L(self, row, bg):
  if self.VVcp26(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVcp26(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVmtFJ, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVLqMB:
    if   VVS9jK           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVnv0E(self):
  return self.VVcp26(self.list[self.l.getCurrentSelectionIndex()])
 def VVs3se(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVyMnm(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVoXBq(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VV1IKd:
    self.current_mountpoint = self.VViRhe(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VV1IKd:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVRSyf and not self.VVyMnm(path, self.VVY47Q):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVwKzf(name=p.description, absolute=path, isDir=True, typ=self.VVFccn, png=png))
    path = "/"
    if path not in self.VVRSyf and not self.VVyMnm(path, self.VVY47Q):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVwKzf(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VV1MFJ, png=self.png_mem))
  elif self.VVfPZ9:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV0WM0 = eServiceCenter.getInstance()
   list = VV0WM0.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVcXwj and not self.isTop:
   if directory == self.current_mountpoint and self.VV1IKd:
    self.list.append(self.VVwKzf(name=self.VVaEEj, absolute=None, isDir=True, typ=self.VVzney, png=self.png_dirup))
   elif (directory != "/") and not (self.VVRSyf and self.VVPEwB(directory) in self.VVRSyf):
    self.list.append(self.VVwKzf(name=self.VVHgCU, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVC9IW, png=self.png_dirup))
  if self.VVcXwj:
   for x in directories:
    if not (self.VVRSyf and self.VVPEwB(x) in self.VVRSyf) and not self.VVyMnm(x, self.VVY47Q):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVwKzf(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFHx8R(x)) else self.VVLqMB, png=png))
  if self.VVIEld:
   for x in files:
    if self.VVfPZ9:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FF0D7j(" -> " , VVRkew) + FF0D7j(target, VVRTFm)
       else:
        png = self.png_slbfil
        name += FF0D7j(" -> " , VVRkew) + FF0D7j(target, VV8a8m)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVCIil(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV8pP1, category))
    if (self.VV7Lr3 is None) or iCompile(self.VV7Lr3[0], flags=self.VV7Lr3[1]).search(path):
     self.list.append(self.VVwKzf(name=name, absolute=x , isDir=False, typ=self.VVmtFJ, png=png))
  if self.VV1IKd and len(self.list) == 0:
   self.list.append(self.VVwKzf(name=FF0D7j("No USB connected", VVBhz1), absolute=None, isDir=False, typ=self.VVQ7tp, png=self.png_usb))
  self.l.setList(self.list)
  self.VV9VG6()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVWpOw(self):
  return self.current_directory
 def VV30g7(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVfLzW(self):
  return self.VVJSAD() and self.VVWpOw()
 def VVJSAD(self):
  return self.list[0][1][7] in (self.VVaEEj, self.VVHgCU)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVoXBq(self.getSelection()[0], self.current_directory)
 def VVwumr(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVAvuR)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVAvuR)
 def VVAvuR(self, action, device):
  self.VVnagy()
  if self.current_directory is None:
   self.VVPu68()
 def VVPu68(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVoXBq(self.current_directory, self.VVwumr())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVDPUa(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVBVeZ : nameAlpMode, nameAlpTxt = self.VVnqiB, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVBVeZ, sAZ
  if mode == self.VVhS3m : nameNumMode, nameNumTxt = self.VVigsY, s90
  else       : nameNumMode, nameNumTxt = self.VVhS3m, s09
  if mode == self.VV0GAs : dateMode, dateTxt = self.VVSIRj, sON
  else       : dateMode, dateTxt = self.VV0GAs, sNO
  if mode == self.VV8nS5 : typeMode, typeTxt = self.VVZB6D, sZA
  else       : typeMode, typeTxt = self.VV8nS5, sAZ
  if   mode in (self.VVBVeZ, self.VVnqiB): txt = "Name (%s)" % (sAZ if mode == self.VVBVeZ else sZA)
  elif mode in (self.VVhS3m, self.VVigsY): txt = "Name (%s)" % (s09 if mode == self.VVBVeZ else s90)
  elif mode in (self.VV0GAs, self.VVSIRj): txt = "Date (%s)" % (sNO if mode == self.VV0GAs else sON)
  elif mode in (self.VV8nS5, self.VVZB6D): txt = "Type (%s)" % (sAZ if mode == self.VV8nS5 else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VV9VG6(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FF3Ual(CFG.browserSortMode, mode)
   FF3Ual(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVJSAD() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVBVeZ, self.VVnqiB):
    rev = True if mode == self.VVnqiB else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVhS3m, self.VVigsY):
    rev = True if mode == self.VVigsY else False
    self.list = sorted(self.list[item0:], key=FF2BO2(BF(self.VVlCjD, isMix, rev)), reverse=rev)
   elif mode in (self.VV0GAs, self.VVSIRj):
    rev = True if mode == self.VVSIRj else False
    self.list = sorted(self.list[item0:], key=FF2BO2(BF(self.VVZDQa, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVZB6D else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVlCjD(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFhvfk(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFe0ql(dir2, dir1) or FFhvfk(name1, name2)
 def VVZDQa(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFe0ql(stat2.st_ctime, stat1.st_ctime)
    else : return FFe0ql(dir2, dir1) or FFe0ql(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCTwdG(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFzoo9(VVCTW9, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVUel6   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVezUg(defFG, "#00FFFFFF")
  self.defBG   = self.VVezUg(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFk1xo(self, self.Title)
  self["keyRed"].show()
  FFWr7z(self["keyGreen"] , "< > Transp.")
  FFWr7z(self["keyYellow"], "Foreground")
  FFWr7z(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VVyU28,
  {
   "ok"   : self.VVfA5g     ,
   "green"   : self.VVfA5g     ,
   "yellow"  : BF(self.VVDBwV, False)  ,
   "blue"   : BF(self.VVDBwV, True)  ,
   "up"   : self.VVDWrv       ,
   "down"   : self.VV2Slw      ,
   "left"   : self.VVY4Ig      ,
   "right"   : self.VV85da      ,
   "last"   : BF(self.VVpz9u, -5) ,
   "next"   : BF(self.VVpz9u, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVywsT)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFiva8(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFiva8(self["keyRed"] , c)
  FFiva8(self["keyGreen"] , c)
  self.VVTe6J()
  self.VVkuYN()
  FFBD6G(self["myColorTst"], self.defFG)
  FFiva8(self["myColorTst"], self.defBG)
 def VVezUg(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVkuYN(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV0knJ(0, 0)
     return
 def VVfA5g(self):
  self.close(self.defFG, self.defBG)
 def VVDWrv(self): self.VV0knJ(-1, 0)
 def VV2Slw(self): self.VV0knJ(1, 0)
 def VVY4Ig(self): self.VV0knJ(0, -1)
 def VV85da(self): self.VV0knJ(0, 1)
 def VV0knJ(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVMKnR()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVkwTG()
 def VVTe6J(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVkwTG(self):
  color = self.VVMKnR()
  if self.isBgMode: FFiva8(self["myColorTst"], color)
  else   : FFBD6G(self["myColorTst"], color)
 def VVDBwV(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVTe6J()
   self.VVkuYN()
 def VVpz9u(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV0knJ(0, 0)
 def VVVC6z(self):
  return hex(self.transp)[2:].zfill(2)
 def VVMKnR(self):
  return ("#%s%s" % (self.VVVC6z(), self.colors[self.curRow][self.curCol])).upper()
class CCYYLz(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFzoo9(VVjGxK, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFk1xo(self, title="%s%s%s" % (self.Title, " " * 10, FF0D7j("Change values with Up , Down, < , 0 , >", VVBhz1)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VVyU28,
  {
   "ok"  : self.VVQHyQ      ,
   "cancel" : self.VVgUEA      ,
   "info"  : self.VVx4ui    ,
   "red"  : self.VVR7iT  ,
   "green"  : self.VVePcq   ,
   "yellow" : BF(self.VVnE0F, 0)  ,
   "blue"  : self.VVCKbO    ,
   "menu"  : self.VVjOh9      ,
   "left"  : self.VVY4Ig      ,
   "right"  : self.VV85da      ,
   "last"  : self.VVHQRp     ,
   "next"  : self.VVn0XE     ,
   "0"   : self.VV8zbW    ,
   "up"  : self.VVDWrv       ,
   "down"  : self.VV2Slw      ,
   "pageUp" : BF(self.VV2mEW, True) ,
   "pageDown" : BF(self.VV2mEW, False) ,
   "chanUp" : BF(self.VV2mEW, True) ,
   "chanDown" : BF(self.VV2mEW, False) ,
   "play"  : BF(self.VVuy73, "pause")  ,
   "pause"  : BF(self.VVuy73, "pause")  ,
   "playPause" : BF(self.VVuy73, "pause")  ,
   "stop"  : BF(self.VVuy73, "pause")  ,
   "audio"  : BF(self.VVuy73, "audio")  ,
   "subtitle" : BF(self.VVuy73, "subtitle") ,
   "rewind" : BF(self.VVuy73, "rewind" ) ,
   "forward" : BF(self.VVuy73, "forward" ) ,
   "rewindDm" : BF(self.VVuy73, "rewindDm") ,
   "forwardDm" : BF(self.VVuy73, "forwardDm")
  }, -1)
  self.VVAxod()
  self.onShown.append(self.VVywsT)
  self.onClose.append(self.VVkelS)
 def VVAxod(self):
  lst = []
  for fil in FFJwmB(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVgWB4:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVywsT(self):
  self.onShown.remove(self.VVywsT)
  FFlx3W(self)
  FFqFdY(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVW4tV()
  self.VVtx9M()
  self.VVcdZn()
 def VVkelS(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVgeZf(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFiva8(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VV4EFi()
 def VVW4tV(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFiva8(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVQHyQ(self):
  if self.settingShown:
   confItem = self.VVIrEv()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVutlQ = []
   if isinstance(lst[0], tuple):
    for item in lst: VVutlQ.append((item[1], item[0]))
   else:
    for item in lst: VVutlQ.append((item, item))
   VVG7pv = FFre61(self, self.VVc3v7, VVutlQ=VVutlQ, width=700, title=title, VVRdqN="#33221111", VVkSGg="#33110011")
   VVG7pv.VVU16Q(confItem.getText())
  else:
   self.close("subtExit")
 def VVc3v7(self, item=None):
  if item:
   self.VVIrEv()[self.CursorPos].setValue(item)
   self.VV4EFi()
   self.VVtx9M()
   self.VVZYu6(True)
 def VVgUEA(self):
  for confItem in self.VVIrEv():
   if confItem.isChanged():
    FFfbEx(self, BF(self.VVP0ab, cbFnc=self.VVSII2), "Save Changes ?", callBack_No=self.VVuR7o, title=self.Title)
    break
  else:
   self.VVSII2()
 def VVSII2(self):
   if self.settingShown: self.VVW4tV()
   else    : self.close("subtExit")
 def VVjOh9(self):
  if self.settingShown: self.VVFzRe()
  else    : self.VVgeZf()
 def VVY4Ig(self): self.VVu26s(-1)
 def VV85da(self): self.VVu26s(1)
 def VVu26s(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVQyGS()
   if pos == -1: ndx = self.VVraqe(posVal)
   else  : ndx = self.VV59yt(posVal)
   if   ndx < 0      : FFhSFw(self, "Not found" , 500)
   elif ndx == 0      : FFhSFw(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFhSFw(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVEnqK(frmSec)
    if allow:
     self.VVnE0F(delay, True)
     self.VVZYu6(force=True)
     CCfirR(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFhSFw(self, "Delay out of range", 800)
 def VV2mEW(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVuy73(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVHQRp(self) : self.VVLQEE(5)
 def VVn0XE(self) : self.VVLQEE(6)
 def VV8zbW(self) : self.VVLQEE(-1)
 def VVDWrv(self):
  if self.settingShown: self.VVLQEE(1)
  else    : self.VV2mEW(True)
 def VV2Slw(self):
  if self.settingShown: self.VVLQEE(0)
  else    : self.VV2mEW(False)
 def VVLQEE(self, direction):
  if self.settingShown:
   confItem = self.VVIrEv()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VV4EFi()
   self.VVtx9M()
   self.VVZYu6(True)
 def VVIrEv(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVuR7o(self):
  for confItem in self.VVIrEv(): confItem.cancel()
  self.VV4EFi()
  self.VVtx9M()
  self.VVW4tV()
 def VVR7iT(self):
  if self.settingShown:
   FFfbEx(self, self.VV6rur, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV6rur(self):
  for confItem in self.VVIrEv(): confItem.setValue(confItem.default)
  self.VVP0ab()
  self.VV4EFi()
  self.VVtx9M()
 def VVnE0F(self, delay, force=False):
  if self.settingShown or force:
   FF3Ual(CFG.subtDelaySec, delay)
   self.VVjT8m()
   self.VV4EFi()
   self.VVtx9M()
   if self.settingShown:
    FFhSFw(self, 'Reset to "0"', 800, isGrn=True)
 def VVePcq(self):
  if self.settingShown:
   self.VVP0ab()
   self.VVW4tV()
 def VVP0ab(self, cbFnc=None):
  for confItem in self.VVIrEv(): confItem.save()
  configfile.save()
  self.VVjT8m()
  FFhSFw(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VV4EFi(self):
  cfgLst = self.VVIrEv()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVtx9M(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFkKOE(path, fnt, isRepl=1)
  else:
   fnt = VVczsY
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFTJBw(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFBD6G(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFiva8(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFFt0C(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFTJBw(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFUXKU()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFDNFi(self, winW, winH)
 def VVx4ui(self):
  sp = "    "
  txt  = "%s\n"   % FF0D7j("Subtitle File:", VVPr8g)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FF0D7j("Subtitle Settings:", VVPr8g)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVQyGS()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFnZVI(frmSec1)
   time2 = FFnZVI(toSec2)
   txt += "\n"
   txt += "%s\n"       % FF0D7j("Timing:", VVPr8g)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFnZVI(durVal)
   txt += sp + "Progress\t: %s\n" % FFnZVI(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FF0D7j("Subtitle end reached.", VVO7vL)
  FFEso0(self, txt, title="Current Subtitle")
 def VVcdZn(self, path="", delay=0, enc=""):
  FFVvl9(self, BF(self.VVcjiY, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVcjiY(self, path="", delay=0, enc=""):
  FFhSFw(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVo20Y(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VV4EFi()
     self.VVA7nq()
   else:
    path, delay, enc = CCYYLz.VVW2g5(self)
    if path:
     self.VVcdZn(path=path, delay=delay, enc=enc)
    else:
     self.VVFzRe()
  except:
   pass
 def VVA7nq(self):
  posVal, durVal = self.VVQyGS()
  if self.VVpwpy(posVal):
   return
  CCYYLz.VVTP73(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVZYu6)
  except:
   self.timerUpdate.callback.append(self.VVZYu6)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVnMM7)
  except:
   self.timerEndText.callback.append(self.VVnMM7)
  FFhSFw(self, "Subtitle started", 700, isGrn=True)
 def VVpwpy(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCYYLz.VVvrRJ(self)
   FFEUy9(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVFzRe(self):
  c1, c2, c3, c4, c5 = "", VVPr8g, VVqWCE, VVQrak, VVO7vL
  VVutlQ = []
  VVutlQ.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVutlQ.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVutlQ.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVutlQ.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVutlQ.append(VVJKCZ)
   VVutlQ.append(("Help (Keys)"        , "help"  ))
  FFre61(self, self.VVSesL, VVutlQ=VVutlQ, width=700, title='Find Subtitle ".srt" File', VVRdqN="#33221111", VVkSGg="#33110011")
 def VVSesL(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVfGFc(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVfGFc(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVAqyJ, BF(CCLSXF, patternMode="srt", VVXhi5=sDir))
   elif item.startswith("sugSrt") : self.VVfGFc(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFVvl9(self, BF(CCDQtT.VVuKpV, self, self.lastSubtFile, self.VVHn8R, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFhSFw(self, "SRT File error", 1000)
   elif item == "disab":
    FFEUy9(CCYYLz.VVvrRJ(self))
    self.close("subtExit")
   elif item == "help"    : FF1D9G(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVHn8R(self, item=None):
  if item:
   FFVvl9(self, BF(self.VVcdZn, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVAqyJ(self, path):
  if path:
   FF3Ual(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVcdZn(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVfGFc(self, defSrt="", mode=0, coeff=0.25):
  FFVvl9(self, BF(self.VVrzmk, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVrzmk(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCYYLz.VVBuKm(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFlfx8('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFNOMj(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVNLl5(srtList, coeff)
     if err:
      if self.settingShown: FFGp67(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VV796F = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFqvjY(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VV796F.append((fName, Dir))
   VVOPmD  = ("Select"    , self.VVJ5RP     , [])
   VVfT1c = self.VV1NeP
   VV5qt4 = (""     , self.VVxEpb       , [])
   VVAWwW = (""     , BF(self.VVFR6G, defSrt, False) , [])
   VVDle6 = ("Find Current File" , BF(self.VVFR6G, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVFNzW=widths, VVH0vt=28, VVOPmD=VVOPmD, VVfT1c=VVfT1c, VV5qt4=VV5qt4, VVAWwW=VVAWwW, VVDle6=VVDle6, lastFindConfigObj=CFG.lastFindSubtitle
     , VVRdqN="#11002222", VVkSGg="#33001111", VVTJDG="#33001111", VVVcQT="#11ffff00", VVChAx="#11445544", VVDQNf="#22222222", VV4UX1="#11002233")
  elif self.settingShown : FFGp67(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VV1NeP(self, VVhkUd):
  VVhkUd.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVxEpb(self, VVhkUd, title, txt, colList):
  fName, Dir = colList
  FFEso0(VVhkUd, "%s\n\n%s%s" % (FF0D7j("Path:", VVPr8g), Dir, fName), title=title)
 def VVFR6G(self, path, VVJLdL, VVhkUd, title, txt, colList):
  for ndx, row in enumerate(VVhkUd.VVNCJx()):
   if path == row[1].strip() + row[0].strip():
    VVhkUd.VVfMAJ(ndx)
    break
  else:
   if VVJLdL:
    FFhSFw(VVhkUd, "Not in list !", 1000)
 def VVJ5RP(self, VVhkUd, title, txt, colList):
  VVhkUd.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVcdZn(path=path)
 def VVNLl5(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvK6a.VVseo6(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCvK6a.VVZTbf(evName, "en")[0] or evName
   lst, err = CCYYLz.VVgpVd(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVo20Y(self, path, enc=None):
  if enc and CCDQtT.VV9DXi(path, enc)      : enc = enc
  elif CCDQtT.VV9DXi(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFrMJ0(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF6UEw(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVHT5U(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VV4P16(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVjT8m()
  return subtList, ""
 def VV4P16(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVHT5U(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVjT8m(self):
  path = CCYYLz.VVvrRJ(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVZYu6(self, force=False):
  posVal, durVal = self.VVQyGS()
  if self.VVpwpy(posVal):
   return
  curIndex = self.VVOolj(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVnMM7()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFBD6G(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVQyGS(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCGzpp.VVFYBJ(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvK6a.VVseo6(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVOolj(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVraqe(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV59yt(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVnMM7(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFBD6G(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVCKbO(self):
  FFVvl9(self, self.VVykR1, title="Loading Lines ...")
 def VVykR1(self):
  VV796F = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VV796F.append((cap, FFnZVI(frm), str(frm), firstLine))
  if VV796F:
   title = "Select Current Subtitle Line"
   VVj6l9  = self.VVFBak
   VVfT1c = self.VV6ZaW
   VVOPmD  = ("Select"   , self.VV6n85 , [title])
   VVDle6 = ("Current Line" , self.VV42if , [True])
   VVPOPD = ("Reset Delay" , self.VVFHfr , [])
   VVUum8 = ("New Delay"  , self.VVBBpE   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVxWCE  = (CENTER , CENTER, CENTER , LEFT    )
   VVhkUd = FFvfpt(self, None, title=title, header=header, VVUel6=VV796F, VVxWCE=VVxWCE, VVFNzW=widths, VVH0vt=28, VVj6l9=VVj6l9, VVfT1c=VVfT1c, VVOPmD=VVOPmD, VVDle6=VVDle6, VVPOPD=VVPOPD, VVUum8=VVUum8
          , VVRdqN="#33002222", VVkSGg="#33001111", VVTJDG="#33110011", VVVcQT="#11ffff00", VVChAx="#0a334455", VVDQNf="#22222222", VV4UX1="#33002233")
  else:
   FFGp67(self, "Cannot read lines !", 2000)
 def VVFBak(self, VVhkUd):
  self.subtLinesTable = VVhkUd
  if CFG.subtDelaySec.getValue():
   VVhkUd["keyYellow"].show()
   VVhkUd["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVhkUd["keyYellow"].hide()
  VVhkUd["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFiva8(VVhkUd["keyBlue"], "#22222222")
  VVhkUd.VVHrXj(BF(self.VV3M07, VVhkUd))
  self.VV42if(VVhkUd, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVzyOb)
  except:
   self.timerSubtLines.callback.append(self.VVzyOb)
  self.timerSubtLines.start(1000, False)
 def VV6ZaW(self, VVhkUd):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVhkUd.cancel()
 def VVzyOb(self):
  if self.subtLinesTable:
   VVhkUd = self.subtLinesTable
   posVal, durVal = self.VVQyGS()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVOolj(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVhkUd.VVbWAe(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVhkUd.VVmJSt(self.subtLinesTableNdx, row)
     row = VVhkUd.VVbWAe(curIndex)
     row[0] = color + row[0]
     VVhkUd.VVmJSt(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VV6n85(self, VVhkUd, Title):
  delay, color, allow = self.VV8Y2F(VVhkUd)
  if allow:
   self.VV6ZaW(VVhkUd)
   self.VVnE0F(delay, True)
  else:
   FFhSFw(VVhkUd, "Delay out of range", 1500)
 def VV42if(self, VVhkUd, VVJLdL, onlyColor=False):
  if VVhkUd:
   posVal, durVal = self.VVQyGS()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVOolj(posVal)
    if curIndex > -1:
     VVhkUd.VVfMAJ(curIndex)
    else:
     ndx = self.VVraqe(posVal)
     if ndx > -1:
      VVhkUd.VVfMAJ(ndx)
 def VVFHfr(self, VVhkUd, title, txt, colList):
  if VVhkUd["keyYellow"].getVisible():
   self.VVnE0F(0, True)
   VVhkUd["keyYellow"].hide()
   self.VV42if(VVhkUd, False)
 def VV3M07(self, VVhkUd):
  delay, color, allow = self.VV8Y2F(VVhkUd)
  VVhkUd["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VV8Y2F(self, VVhkUd):
  lineTime = float(VVhkUd.VVZqZI()[2].strip())
  return self.VVEnqK(lineTime)
 def VVEnqK(self, lineTime):
  posVal, durVal = self.VVQyGS()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVFWDt
   else     : allow, color = False, VVO7vL
   delay = FFl54W(val, -600, 600)
  return delay, color, allow
 def VVBBpE(self, VVhkUd, title, txt, colList):
  pass
 @staticmethod
 def VVdw4r(SELF):
  path, delay, enc = CCYYLz.VVW2g5(SELF)
  return True if path else False
 @staticmethod
 def VVW2g5(SELF):
  path, delay, enc = CCYYLz.VVEO3E(SELF)
  if not path:
   path = CCYYLz.VVg1TX(SELF)
  return path, delay, enc
 @staticmethod
 def VVEO3E(SELF):
  srtCfgPath = CCYYLz.VVvrRJ(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF6UEw(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVvrRJ(SELF):
  fPath, fDir, fName = CCLSXF.VVtloK(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvK6a.VVseo6(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFi1IN(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVg1TX(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCLSXF.VVtloK(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCYYLz.VVBuKm(SELF)
    bLst, err = CCYYLz.VVgpVd(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVBuKm(SELF):
  fPath, fDir, fName = CCLSXF.VVtloK(SELF)
  if pathExists(fDir):
   files = FFJwmB(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVgpVd(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVMek8():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVTP73(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCYYLz.VVJSnJ()
 @staticmethod
 def VVJSnJ():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCbd2t(ScrollLabel):
 def __init__(self, parentSELF, text="", VVIxoC=True):
  ScrollLabel.__init__(self, text)
  self.VVIxoC   = VVIxoC
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVT9KB  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVH0vt    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VVyU28,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVmN8T ,
   "green"   : self.VVbiI2 ,
   "yellow"  : self.VVhyy0 ,
   "blue"   : self.VVN4om ,
   "up"   : self.VVwMUP   ,
   "down"   : self.VV5D8z  ,
   "left"   : self.VVwMUP   ,
   "right"   : self.VV5D8z  ,
   "last"   : BF(self.VVfkdT, 0) ,
   "0"    : BF(self.VVfkdT, 1) ,
   "next"   : BF(self.VVfkdT, 2) ,
   "pageUp"  : self.VVcwwa   ,
   "chanUp"  : self.VVcwwa   ,
   "pageDown"  : self.VVRYcR   ,
   "chanDown"  : self.VVRYcR
  }, -1)
 def VVABQW(self, isResizable=True, VVz31H=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFBD6G(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFiva8(self.parentSELF["keyRedTop"], "#113A5365")
  FFlx3W(self.parentSELF, True)
  self.isResizable = isResizable
  if VVz31H:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVH0vt  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFiva8(self, color)
 def VVdd1T(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVDng6  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVDng6)
  margin   = int(VVDng6 / 6)
  self.pageHeight = int(self.pageLines * VVDng6)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVT9KB - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVdoIx()
 def VVwMUP(self):
  if self.VVT9KB > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VV5D8z(self):
  if self.VVT9KB > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVcwwa(self):
  self.setPos(0)
 def VVRYcR(self):
  self.setPos(self.VVT9KB-self.pageHeight)
 def VVkDVa(self):
  return self.VVT9KB <= self.pageHeight or self.curPos == self.VVT9KB - self.pageHeight
 def getText(self):
  return self.message
 def VVdoIx(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVT9KB, 3))
   start = int((100 - vis) * self.curPos / (self.VVT9KB - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVognF=VVb3Z6):
  old_VVkDVa = self.VVkDVa()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVT9KB = self.long_text.calculateSize().height()
   if self.VVIxoC and self.VVT9KB > self.pageHeight:
    self.scrollbar.show()
    self.VVdoIx()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVT9KB))
    self.VVT9KB = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVT9KB))
   else:
    self.scrollbar.hide()
   if   VVognF == VVy5UE: self.setPos(0)
   elif VVognF == VVlBOt : self.VVRYcR()
   elif old_VVkDVa    : self.VVRYcR()
 def appendText(self, text, VVognF=VVlBOt):
  self.setText(self.message + str(text), VVognF=VVognF)
 def VVhyy0(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVySh2(size)
 def VVN4om(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVySh2(size)
 def VVbiI2(self):
  self.VVySh2(self.VVH0vt)
 def VVySh2(self, VVH0vt):
  self.long_text.setFont(gFont(self.fontFamily, VVH0vt))
  self.setText(self.message, VVognF=VVb3Z6)
  self.VVydFj()
 def VVfkdT(self, align):
  self.long_text.setHAlign(align)
 def VVmN8T(self):
  VVutlQ = []
  VVutlQ.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Align Left" , "left" ))
  VVutlQ.append(("Align Center" , "center" ))
  VVutlQ.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVutlQ.append(VVJKCZ)
   VVutlQ.append((FF0D7j("Save to File", VVPr8g), "save"))
  VVutlQ.append(VVJKCZ)
  VVutlQ.append(("Keys (Shortcuts)", "help"))
  FFre61(self.parentSELF, self.VVYxdy, VVutlQ=VVutlQ, title="Text Option", width=500)
 def VVYxdy(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVfkdT(0)
   elif item == "center" : self.VVfkdT(1)
   elif item == "right" : self.VVfkdT(2)
   elif item == "save"  : self.VVTSqn()
   elif item == "help"  : FF1D9G(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVTSqn(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFqvjY(expPath), self.outputFileToSave, FFKX94())
   with open(outF, "w") as f:
    f.write(FFLAHl(self.message))
   FFmMPS(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FF9Njt(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVydFj(self, minHeight=0):
  if self.isResizable:
   VVDng6 = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVDng6 * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVT9KB < self.pageHeight:
    textH = max(textH, self.VVT9KB)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
