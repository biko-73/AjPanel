import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVR4kJ   = "v5.2.0"
VV1ndx    = "12-05-2022"
EASY_MODE    = 0
VVZPzO   = 0
VV0Fki   = 0
VVObQC  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVDDy9  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVXKuz    = "/media/usb/"
VVgq9y    = "/usr/share/enigma2/picon/"
VVi5hU = "/etc/enigma2/blacklist"
VV9gDR   = "/etc/enigma2/"
VV0wrk  = "ajpanel_update_url"
VVs2jC   = "AJPan"
VVKky1    = "AUTO FIND"
VVsoxs    = ""
VVcNG9    = "Regular"
VVM6J3      = "-" * 80
VVmGWQ    = ("-" * 100, )
VVQhtK    = ""
VV1lRr   = " && echo 'Successful' || echo 'Failed!'"
VV4kve    = []
VVKvgB  = "Cannot continue (No Enough Memory) !"
VVDzaH  = False
VV98Ue  = False
VVYKPa = False
VVD8FW     = 0
VVoWAS    = 1
VVr6Ek    = 2
VVeoVT   = 3
VVFCPk    = 4
VVZ61v    = 5
VV7AyH = 6
VVoavT = 7
VVAopB  = 8
VV7eYp   = 9
VVuNXI   = 10
VVfZlu   = 11
VVDtsd  = 12
VVN1qf  = 13
VVsSd2    = 14
VVAgBh   = 15
VVHQsb   = 16
VVlXnV    = 17
WINDOW_SUBTITLE    = 18
VVggSt  = 19
VVFcS3   = 0
VVzgBH   = 1
VVQ2Bk   = 2
def FFQQAT():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVcNG9]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVKky1, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVgq9y, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVXKuz, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVcNG9, choices=[ (x,  x) for x in FFQQAT() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFrgJ8():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVfkrP  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVkxul = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVfkrP  : return 0
  elif VVkxul : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVg9YJ = FFrgJ8()
VVWmbA = VVyTfh = VVOC4t = VVtODU = VVBXnD = VV6Y3Y = VV4U0A = VVJF5Y = COLOR_CONS_BRIGHT_YELLOW = VVejU1 = VVo3CO = VVQiYp = VV1LkE = ""
def FF7LBQ()  : FFtU4R(FFN6eT())
def FFOS10()  : FFtU4R(FFax2u())
def FFtACT(tDict): FFtU4R(iDumps(tDict, indent=4, sort_keys=True))
def FFrPDs(*args): FFdCkq(True, False, *args)
def FFtU4R(*args) : FFdCkq(True , True , *args)
def FFOHbj(*args): FFdCkq(False, True , *args)
def FFdCkq(addSep=True, oneLine=True, *args):
 if VVZPzO:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFSc2N(txt, isAppend=True, ignoreErr=False):
 if VVZPzO:
  tm = FFCLV9()
  err = ""
  if not ignoreErr:
   err = FFax2u()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFtU4R(err)
  FFtU4R("Output Log File : %s" % fileName)
def FFax2u():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFCLV9()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFN6eT():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VV4kve = []
def FF0xYi(win):
 global VV4kve
 if not win in VV4kve:
  VV4kve.append(win)
def FFNnw3(*args):
 global VV4kve
 for win in VV4kve:
  try:
   win.close()
  except:
   pass
 VV4kve = []
def FFfJSU():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVHk1Q = FFfJSU()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFP96d()     : return PluginDescriptor(fnc=FFAQxU, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FF12Do()      : return getDescriptor(FF72sj   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FF84XS()       : return getDescriptor(FFNeHM  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFVExn()   : return getDescriptor(FF0n5b , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFhUHQ(): return getDescriptor(FFyo3f , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFKaiN()  : return getDescriptor(FFYOxV  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FF9Vdz()     : return getDescriptor(FFuTzF , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF12Do() , FF84XS() , FFP96d() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFVExn())
  result.append(FFhUHQ())
  result.append(FFKaiN())
 if CFG.EventsInfoMenu.getValue():
  result.append(FF9Vdz())
 return result
def FFAQxU(reason, **kwargs):
 if reason == 0:
  FFq1VW()
  if "session" in kwargs:
   session = kwargs["session"]
   FFU0Rx(session)
   CC4PgF(session)
  CCIa4v.VVNYou()
def FFNeHM(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF72sj, PLUGIN_NAME, 45)]
 else:
  return []
def FF72sj(session, **kwargs):
 session.open(Main_Menu)
def FF0n5b(session, **kwargs):
 session.open(CCMTIp)
def FFyo3f(session, **kwargs):
 FFh9iv(session, isFromSession=True)
def FFYOxV(session, **kwargs):
 session.open(CCfMBx)
def FFuTzF(session, **kwargs):
 session.open(CCR0BS, fncMode=CCR0BS.VV3oR1)
def FFw7EK():
 FF8IiW(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFVExn(), FFhUHQ(), FFKaiN() ])
 FF8IiW(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FF9Vdz() ])
def FF8IiW(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVwGfz = None
def FFq1VW():
 try:
  global VVwGfz
  if VVwGfz is None:
   VVwGfz    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFONWv
  ChannelContextMenu.FFnWSZ = FFnWSZ
 except:
  pass
def FFONWv(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVwGfz(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFnWSZ, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFnWSZ, title1, csel, isFind=True))))
def FFnWSZ(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFopjl(refCode)
 except:
  pass
 self.session.open(boundFunction(CCj59b, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFU0Rx(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFhIlZ, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFhIlZ, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFhIlZ, session, "lred")
def FFhIlZ(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFh9iv(session, isFromSession=True)
def FFpJPp(SELF, title="", addLabel=False, addScrollLabel=False, VVRj9e=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFSTdn()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCqrm5(SELF)
 if VVRj9e:
  SELF["myMenu"] = MenuList(VVRj9e)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VV4R5P        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFjyc0(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFTZ6C, SELF, "0") ,
  "1"    : boundFunction(FFTZ6C, SELF, "1") ,
  "2"    : boundFunction(FFTZ6C, SELF, "2") ,
  "3"    : boundFunction(FFTZ6C, SELF, "3") ,
  "4"    : boundFunction(FFTZ6C, SELF, "4") ,
  "5"    : boundFunction(FFTZ6C, SELF, "5") ,
  "6"    : boundFunction(FFTZ6C, SELF, "6") ,
  "7"    : boundFunction(FFTZ6C, SELF, "7") ,
  "8"    : boundFunction(FFTZ6C, SELF, "8") ,
  "9"    : boundFunction(FFTZ6C, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFPgNp, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFTZ6C(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV1LkE:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV1LkE + SELF.keyPressed + VVyTfh)
    txt = VVyTfh + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFNWTN(SELF, txt)
def FFPgNp(SELF, tableObj, colNum):
 FFNWTN(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VV0Yzk(i)
     break
 except:
  pass
def FFUrUX(SELF, setMenuAction=True):
 if setMenuAction:
  global VVQhtK
  VVQhtK = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFSTdn():
 return ("  %s" % VVQhtK)
def FFpqes(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFz82T(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FF3EtY(color):
 return parseColor(color).argb()
def FFOEeE(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFL3RG(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFBx6G(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFMRMu(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV1LkE)
 else:
  return ""
def FF1ZnE(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVM6J3, word, VVM6J3, VV1LkE)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVM6J3, word, VVM6J3)
def FFhTMc(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV1LkE
def FFwDGd(color):
 if color: return "echo -e '%s' %s;" % (VVM6J3, FFMRMu(VVM6J3, VVJF5Y))
 else : return "echo -e '%s';" % VVM6J3
def FFO6Fd(title, color):
 title = "%s\n%s\n%s\n" % (VVM6J3, title, VVM6J3)
 return FFhTMc(title, color)
def FFl7ED(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFN9mt(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFbH1W(callBackFunction):
 tCons = CC82pG()
 tCons.ePopen("echo", boundFunction(FFSQYW, callBackFunction))
def FFSQYW(callBackFunction, result, retval):
 callBackFunction()
def FFjNEj(SELF, fnc, title="Processing ...", clearMsg=True):
 FFNWTN(SELF, title)
 tCons = CC82pG()
 tCons.ePopen("echo", boundFunction(FFPDjG, SELF, fnc, clearMsg))
def FFPDjG(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFNWTN(SELF)
def FFHpNj(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVKvgB
  else       : return ""
def FF6vhB(cmd):
 txt = FFHpNj(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFT5H5(cmd):
 lines = FF6vhB(cmd)
 if lines: return lines[0]
 else : return ""
def FFQVDp(SELF, cmd):
 lines = FF6vhB(cmd)
 VV16hm = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV16hm.append((key, val))
  elif line:
   VV16hm.append((line, ""))
 if VV16hm:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFxW7z(SELF, None, header=header, VV9o2E=VV16hm, VVec0v=widths, VVfhdd=28)
 else:
  FFSdci(SELF, cmd)
def FFSdci(    SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, VV6z3U=True, VVjlB2=VVzgBH, **kwargs)
def FFrpGA(  SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, **kwargs)
def FFsnYb(   SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, VVhDbY=True, VVAM3E=True, VVjlB2=VVzgBH, **kwargs)
def FFZNP9(  SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, VVhDbY=True, VVAM3E=True, VVjlB2=VVQ2Bk, **kwargs)
def FFF3Kc(  SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, VVj4jG=True , **kwargs)
def FFLlyw( SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, VVOdjF=True   , **kwargs)
def FFJiGS( SELF, cmd, **kwargs): SELF.session.open(CCWAnM, VV46qm=cmd, VVQ20z=True  , **kwargs)
def FFH6kH(cmd):
 return cmd + " > /dev/null 2>&1"
def FFCUic():
 return " > /dev/null 2>&1"
def FFYQJY(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FF85RC(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFZfAA():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFT5H5(cmd)
VVtMrS     = 0
VVVSqa      = 1
VVP0LQ   = 2
VVuptD      = 3
VVO3W1      = 4
VVQKic     = 5
VVn4yS     = 6
VVNzzW = 7
VVjk7Z = 8
VVxUBG = 9
VV1HbW  = 10
VVmVbB     = 11
VVK2Bq  = 12
VV9XKC  = 13
def FFdVFr(parmNum, grepTxt):
 if   parmNum == VVtMrS  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVVSqa   : param = ["list"   , "apt list" ]
 elif parmNum == VVP0LQ: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFZfAA()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFq4eO(parmNum, package):
 if   parmNum == VVuptD      : param = ["info"      , "apt show"         ]
 elif parmNum == VVO3W1      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVQKic     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVn4yS     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVNzzW : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVjk7Z : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVxUBG : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VV1HbW  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVmVbB     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVK2Bq  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV9XKC  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFZfAA()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFzDPn():
 result = FFT5H5("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFq4eO(VVn4yS , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFH6kH("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFH6kH("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFMRMu(failed1, VVJF5Y))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFMRMu(failed2, VVJF5Y))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFMRMu(failed3, VVOC4t))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFhOy2(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFq4eO(VVn4yS , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFH6kH("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFMRMu(failed1, VVJF5Y))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFMRMu(failed2, VVOC4t))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFcX1Z(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFH6kH('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFH6kH("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFBgGE(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCIa4v.VVXejN()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFwZqG(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFBgGE(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFqg4C(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFtYtQ(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFBgGE(path, maxSize=maxSize, encLst=encLst)
  if lines: FFCsft(SELF, lines, title=title, VVjlB2=VVzgBH)
  else : FF3XbB(SELF, path, title=title)
 else:
  FF9mKB(SELF, path, title)
def FFom2P(SELF, path, title):
 if fileExists(path):
  txt = FFBgGE(path)
  txt = txt.replace("#W#", VV1LkE)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVyTfh)
  txt = txt.replace("#C#", VVejU1)
  txt = txt.replace("#P#", VVtODU)
  FFCsft(SELF, txt, title=title)
 else:
  FF9mKB(SELF, path, title)
def FF1ivq(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFk8hH(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF1KSt(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFZ2H0(parent)
 else    : return FF09PB(parent)
def FFtYtQ(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFZ2H0(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FF09PB(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFVXrY():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVObQC)
 paths.append(VVObQC.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFk8hH(ba)
 for p in list:
  p = ba + p + VVObQC
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVs2jC, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVObQC, VVs2jC , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVZQQ4, VVpTxo = FFVXrY()
def FF7V9v():
 def VV0WH4(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVKky1 and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVKky1)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVKky1
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VV0WH4(CFG.MovieDownloadPath, CCtZ0M.VVJgX0())
 VVAIWk   = VV0WH4(CFG.backupPath, CCZovK.VVF5yk())
 VV99t4   = VV0WH4(CFG.downloadedPackagesPath, t)
 VVppoU  = VV0WH4(CFG.exportedTablesPath, t)
 VVFYpr  = VV0WH4(CFG.exportedPIconsPath, t)
 VV3XFo   = VV0WH4(CFG.packageOutputPath, t)
 global VVXKuz
 VVXKuz = FFZ2H0(CFG.backupPath.getValue())
 if VVAIWk or VV3XFo or VV99t4 or VVppoU or VVFYpr or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVAIWk, VV3XFo, VV99t4, VVppoU, VVFYpr, oldIptvHostsPath, oldMovieDownloadPath
def FFbVy4(path):
 path = FF09PB(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFSNG0(SELF, pathList, tarFileName, addTimeStamp=True):
 VV9o2E = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV9o2E.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV9o2E.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV9o2E.append(path)
 if not VV9o2E:
  FFikHE(SELF, "Files not found!")
 elif not pathExists(VVXKuz):
  FFikHE(SELF, "Path not found!\n\n%s" % VVXKuz)
 else:
  VVmmeH = FFZ2H0(VVXKuz)
  tarFileName = "%s%s" % (VVmmeH, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFOeCU())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV9o2E:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVM6J3
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFMRMu(tarFileName, VV4U0A))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFMRMu(failed, VV4U0A))
  cmd += "fi;"
  cmd +=  sep
  FFrpGA(SELF, cmd)
def FFe9R7(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFMmCK(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFMmCK(SELF["keyInfo"], "info")
def FFMmCK(barObj, fName):
 path = "%s%s%s" % (VVpTxo, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFFxRe(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFMNbQ(satNum)
  return satName
def FFMNbQ(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFHyEt(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFFxRe(val)
  else  : sat = FFMNbQ(val)
 return sat
def FFleLE(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFFxRe(num)
 except:
  pass
 return sat
def FFnvnw(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFFa90(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFuM16(info, iServiceInformation.sServiceref)
   prov = FFuM16(info, iServiceInformation.sProvider)
   state = str(FFuM16(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF0haM(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFGrEr(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFuM16(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF301l(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFopjl(refCode):
 info = FFJDW7(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFGtRH(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFXJXu(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFJDW7(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVTBRF = eServiceCenter.getInstance()
  if VVTBRF:
   info = VVTBRF.info(service)
 return info
def FFZXnt(SELF, refCode, VVPUAy=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFgMc0(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVPUAy:
   FFh9iv(SELF, isFromSession)
 try:
  VVy039 = InfoBar.instance
  if VVy039:
   VVUSso = VVy039.servicelist
   if VVUSso:
    servRef = eServiceReference(refCode)
    VVUSso.saveChannel(servRef)
 except:
  pass
def FFgMc0(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCHhYj()
    if pr.VVsN6j(refCode, chName, decodedUrl, iptvRef):
     pr.VVGTfM(SELF, isFromSession)
def FF0haM(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFKi35(url): return FFeKZd(url) or FFF8Lk(url)
def FFeKZd(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFF8Lk(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFGrEr(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFRmmV(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFpGUj(userBfile):
 txt = ""
 bFile = VV9gDR + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VV9gDR + userBfile):
  fTxt = FFBgGE(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFT5H5('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFRmmV(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFu3Zi(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FF1YU5(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFJ3Mw(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFX8xo(txt):
 try:
  return FF1YU5(FFJ3Mw(txt)) == txt
 except:
  return False
def FFh9iv(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCxKzH, isFromExternal=isFromSession)
 else      : FFE92K(session, reopen=True, isFromExternal=isFromSession)
def FFE92K(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFE92K, session, isFromExternal=isFromExternal), boundFunction(CCnwKs, isFromExternal=isFromExternal))
  except:
   try:
    FFhdU4(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFQVBm(refCode):
 tp = CCWZOp()
 if tp.VVycsu(refCode) : return True
 else        : return False
def FFgRoS(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFVzbz():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFylDs():
 VVy039 = InfoBar.instance
 if VVy039:
  VVUSso = VVy039.servicelist
  if VVUSso:
   return VVUSso.getBouquetList()
 return None
def FFoikP():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFqa4x():
 path = FFoikP()
 if path:
  txt = FFBgGE(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFCw14():
 return FFb1PG(InfoBar.instance.servicelist.getRoot())
def FFb1PG(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVTBRF = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVTBRF.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFcBHV():
 VVDmXY = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVO3Uv = list(VVDmXY)
 return VVO3Uv, VVDmXY
def FFA2or():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFb3oW(session, VVcTI9):
 VVpHrm, VVpvKh, VV6PCI, camCommand = FFTxJf()
 if VVpvKh:
  runLog = False
  if   VVcTI9 == CClHkx.VVlLHQ : runLog = True
  elif VVcTI9 == CClHkx.VVPQ8h : runLog = True
  elif not VV6PCI          : FFhdU4(session, message="SoftCam not started yet!")
  elif fileExists(VV6PCI)        : runLog = True
  else             : FFhdU4(session, message="File not found !\n\n%s" % VV6PCI)
  if runLog:
   session.open(boundFunction(CClHkx, VVpHrm=VVpHrm, VVpvKh=VVpvKh, VV6PCI=VV6PCI, VVcTI9=VVcTI9))
 else:
  FFhdU4(session, message="No active OSCam/NCam found !", title="Live Log")
def FFTxJf():
 VVpHrm = "/etc/tuxbox/config/"
 VVpvKh = None
 VV6PCI  = None
 camCommand = FFT5H5("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVpvKh = "oscam"
 elif "ncam"  in camCommand : VVpvKh = "ncam"
 if VVpvKh:
  path = FFT5H5(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFZ2H0(path)
  if pathExists(path):
   VVpHrm = path
  tFile = VVpHrm + VVpvKh + ".conf"
  tFile = FFT5H5("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV6PCI = tFile
 return VVpHrm, VVpvKh, VV6PCI, camCommand
def FFIb5k(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFHy2o():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFOeCU():
 return FFHy2o().replace(" ", "_").replace("-", "").replace(":", "")
def FFhztG(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFCLV9():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFnx0u(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCfMBx.VVTzl0(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCfMBx.VVYpUo_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFH6kH("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFsOVH(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFmOj8(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVOZj3 = 0
def FF09Bm():
 global VVOZj3
 VVOZj3 = iTime()
def FFvMQp():
 FFtU4R(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVOZj3).rstrip("0").rstrip("."))
def FF7k8q(SELF, message, title=""):
 SELF.session.open(boundFunction(CCrmmz, title=title, message=message, VVsLA9=True))
def FFCsft(SELF, message, title="", VVjlB2=VVzgBH, **kwargs):
 SELF.session.open(boundFunction(CCrmmz, title=title, message=message, VVjlB2=VVjlB2, **kwargs))
def FFikHE(SELF, message, title="")  : FFhdU4(SELF.session, message, title)
def FF9mKB(SELF, path, title="") : FFhdU4(SELF.session, "File not found !\n\n%s" % path, title)
def FF3XbB(SELF, path, title="") : FFhdU4(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFNDX7(SELF, title="")  : FFhdU4(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFhdU4(session, message, title="") : session.open(boundFunction(CCosR8, title=title, message=message))
def FFJeIH(SELF, VVl0w9, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVl0w9, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVl0w9, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVl0w9, boundFunction(CCKddj, title=title, message=message, VVUtSx=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFikHE(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FF2QoN(SELF, callBack_Yes, VVqTs3, callBack_No=None, title="", VV9d4I=False, VVqxqt=True):
 SELF.session.openWithCallback(boundFunction(FFUMry, callBack_Yes, callBack_No)
        , boundFunction(CCVKuT, title=title, VVqTs3=VVqTs3, VVqxqt=VVqxqt, VV9d4I=VV9d4I))
def FFUMry(callBack_Yes, callBack_No, FF2QoNed):
 if FF2QoNed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFNWTN(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFL3RG(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFPJ8X(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFtZy4(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVvI01 = eTimer()
def FFPJ8X(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FF7oxh, SELF))
 fnc = boundFunction(FF7oxh, SELF)
 try:
  t = VVvI01.timeout.connect(fnc)
 except:
  VVvI01.callback.append(fnc)
 VVvI01.start(milliSeconds, 1)
def FF7oxh(SELF):
 VVvI01.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFxW7z(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC1Q7b, **kwargs))
  else   : win = SELF.session.open(boundFunction(CC1Q7b, **kwargs))
  FF0xYi(win)
  return win
 except:
  return None
def FFLATx(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCRG3J, **kwargs))
 FF0xYi(win)
 return win
def FFgBdr(SELF, **kwargs):
 SELF.session.open(CCR0BS, **kwargs)
def FFKDC6(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFCEFt(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVcNG9, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFwbY1(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFCEFt(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFRhrh():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF7cPD(VVfhdd):
 screenSize  = FFRhrh()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVfhdd)
 return bodyFontSize
def FFc6K0(VVfhdd, extraSpace):
 font = gFont(VVcNG9, VVfhdd)
 VVn4Lz = fontRenderClass.getInstance().getLineHeight(font) or (VVfhdd * 1.25)
 return int(VVn4Lz + VVn4Lz * extraSpace)
def FFRqpN(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFRhrh()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVcNG9, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFc6K0(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVcNG9, titleFontSize, alignLeftCenter)
 if winType == VVD8FW or winType == VVoWAS:
  if winType == VVoWAS : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVggSt:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VVsSd2:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FF7k8qL = b2Left2 + timeW + marginLeft
  FF7k8qW = b2Left3 - marginLeft - FF7k8qL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FF7k8qL  , b2Top, FF7k8qW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVAgBh:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVFCPk:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVr6Ek:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVeoVT:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVcNG9, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVcNG9, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVuNXI:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FF7k8qH = int(bodyH * 0.5)
  inpTop = bodyTop + FF7k8qH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FF7k8qH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVcNG9, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVcNG9, mapF, alignCenter)
 elif winType == VVfZlu:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVDtsd:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVcNG9, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVHQsb:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVcNG9, fontH, alignCenter)
 elif winType == VVN1qf:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVcNG9, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVcNG9, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVcNG9, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVlXnV:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVZ61v:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVoavT : align = alignLeftCenter
  elif winType == VV7AyH : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV7eYp:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVcNG9
  if usefixedFont and winType == VV7AyH:
   fnt = "Fixed"
   if fnt in FFQQAT():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVfhdd = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVcNG9, VVfhdd, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVn7jC = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVcNG9, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVn7jC[i], VVcNG9, barFont, alignCenter)
   left += btnW + gap
 if winType == VV7AyH:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVn7jC = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVn7jC[i], VVcNG9, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVmUKv = ""
  self.themsList  = []
  VVRj9e = []
  if VV0Fki:
   VVRj9e.append(("-- MY TEST --"    , "myTest"   ))
  VVRj9e.append(("  File Manager"     , "FileManager"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("  Services/Channels"    , "ChannelsTools" ))
  VVRj9e.append(("  IPTV"       , "IptvTools"  ))
  VVRj9e.append(("  PIcons"       , "PIconsTools"  ))
  VVRj9e.append(("  SoftCam"      , "SoftCam"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("  Plugins"      , "PluginsTools" ))
  VVRj9e.append(("  Terminal"      , "Terminal"  ))
  VVRj9e.append(("  Backup & Restore"    , "BackupRestore" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("  Date/Time"      , "Date_Time"  ))
  VVRj9e.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVRj9e)
  FFpJPp(self, VVRj9e=VVRj9e)
  FFpqes(self["keyRed"] , "Exit")
  FFpqes(self["keyGreen"] , "Settings")
  FFpqes(self["keyYellow"], "Dev. Info.")
  FFpqes(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VV8eKY       ,
   "yellow"  : self.VV917I       ,
   "blue"   : self.VVlOHv       ,
   "info"   : self.VVlOHv       ,
   "next"   : self.VVh8JX       ,
   "menu"   : self.VVrm1Y     ,
   "text"   : self.VVH6r1      ,
   "0"    : boundFunction(self.VVzFbr, 0) ,
   "1"    : boundFunction(self.VVR7js, 1)   ,
   "2"    : boundFunction(self.VVR7js, 2)   ,
   "3"    : boundFunction(self.VVR7js, 3)   ,
   "4"    : boundFunction(self.VVR7js, 4)   ,
   "5"    : boundFunction(self.VVR7js, 5)   ,
   "6"    : boundFunction(self.VVR7js, 6)   ,
   "7"    : boundFunction(self.VVR7js, 7)   ,
   "8"    : boundFunction(self.VVR7js, 8)   ,
   "9"    : boundFunction(self.VVR7js, 9)
  })
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
  global VVDzaH, VV98Ue, VVYKPa
  VVDzaH = VV98Ue = VVYKPa = False
 def VV4R5P(self):
  item = FFUrUX(self)
  self.VVR7js(item)
 def VVR7js(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVdbk5()
   elif item in ("FileManager"  , 1) : self.session.open(CCMTIp)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCAzDv)
   elif item in ("IptvTools"  , 3) : self.session.open(CCfMBx)
   elif item in ("PIconsTools"  , 4) : self.VVrfoV()
   elif item in ("SoftCam"   , 5) : self.session.open(CCgg9x)
   elif item in ("PluginsTools" , 6) : self.session.open(CCyxBI)
   elif item in ("Terminal"  , 7) : self.session.open(CCiaN0)
   elif item in ("BackupRestore" , 8) : self.session.open(CCtaa9)
   elif item in ("Date_Time"  , 9) : self.session.open(CC52EY)
   elif item in ("CheckInternet" , 10) : self.session.open(CCXD05)
   else         : self.close()
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
  FFKDC6(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVR4kJ)
  self["myTitle"].setText(title)
  VVAIWk, VV3XFo, VV99t4, VVppoU, VVFYpr, oldIptvHostsPath, oldMovieDownloadPath = FF7V9v()
  self.VVck1e()
  if VVAIWk or VV3XFo or VV99t4 or VVppoU or VVFYpr or oldIptvHostsPath or oldMovieDownloadPath:
   VVm7lK = lambda path, subj: "%s:\n%s\n\n" % (subj, FFhTMc(path, VVOC4t)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVm7lK(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVm7lK(VVAIWk   , "Backup/Restore Path"    )
   txt += VVm7lK(VV3XFo  , "Created Package Files (IPK/DEB)" )
   txt += VVm7lK(VV99t4  , "Download Packages (from feeds)" )
   txt += VVm7lK(VVppoU , "Exported Tables"     )
   txt += VVm7lK(VVFYpr , "Exported PIcons"     )
   txt += VVm7lK(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFCsft(self, txt, title="Settings Paths")
  if (EASY_MODE or VVZPzO or VV0Fki):
   FFL3RG(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFNWTN(self, "Welcome", 300)
  FFbH1W(boundFunction(self.VV6stl, title))
 def VV6stl(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCZovK.VVxOhU()
   if url:
    newWebVer = CCZovK.VVxOvC(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFH6kH("rm /tmp/ajpanel*"))
  global VVDzaH, VV98Ue, VVYKPa
  VVDzaH = VV98Ue = VVYKPa = False
 def VVzFbr(self, digit):
  self.VVmUKv += str(digit)
  ln = len(self.VVmUKv)
  global VVDzaH, VVYKPa
  if ln == 4:
   if self.VVmUKv == "0" * ln:
    VVDzaH = True
    FFL3RG(self["myTitle"], "#800080")
   else:
    self.VVmUKv = "x"
  elif self.VVmUKv == "0" * 8:
   VVYKPa = True
 def VVh8JX(self):
  self.VVmUKv += ">"
  if self.VVmUKv == "0" * 4 + ">" * 2:
   global VV98Ue
   VV98Ue = True
   FFL3RG(self["myTitle"], "#dd5588")
 def VVH6r1(self):
  if self.VVmUKv == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFNWTN(self, txt, 2000, isGrn=ok)
 def VVrfoV(self):
  found = False
  pPath = CC0sln.VVij8s()
  if pathExists(pPath):
   for fName, fType in CC0sln.VVj6fI(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC0sln)
  else:
   VVRj9e = []
   VVRj9e.append(("PIcons Manager" , "CC0sln" ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(CC0sln.VVQwwO())
   VVRj9e.append(VVmGWQ)
   VVRj9e += CC0sln.VVeJND()
   FFLATx(self, self.VVGOep, VVRj9e=VVRj9e)
 def VVGOep(self, item=None):
  if item:
   if   item == "CC0sln"   : self.session.open(CC0sln)
   elif item == "VVtQeB"  : CC0sln.VVtQeB(self)
   elif item == "VVeWit"  : CC0sln.VVeWit(self)
   elif item == "findPiconBrokenSymLinks" : CC0sln.VVrNIE(self, True)
   elif item == "FindAllBrokenSymLinks" : CC0sln.VVrNIE(self, False)
 def VV8eKY(self):
  self.session.open(CCZovK)
 def VV917I(self):
  self.session.open(CCYikR)
 def VVlOHv(self):
  changeLogFile = VVpTxo + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFwZqG(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFhTMc("\n%s\n%s\n%s" % (VVM6J3, line, VVM6J3), VVtODU, VV1LkE)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFhTMc(line, VVyTfh, VV1LkE)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFCsft(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVR4kJ), VVfhdd=26)
 def VVrm1Y(self):
  VVRj9e = []
  VVRj9e.append(("Title Colors"   , "title" ))
  VVRj9e.append(("Menu Area Colors"  , "body" ))
  VVRj9e.append(("Menu Pointer Colors" , "cursor" ))
  VVRj9e.append(("Bottom Bar Colors" , "bar"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFLATx(self, boundFunction(self.VVvxPX, title), VVRj9e=VVRj9e, width=500, title=title)
 def VVvxPX(self, title, item=None):
  if item:
   if item == "reset":
    FF2QoN(self, self.VV6K27, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV2agK()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVYrbA, tDict, item), CCKJ2y, defFG=fg, defBG=bg)
 def VV84FK(self):
  return VVXKuz + "ajpanel_colors"
 def VV2agK(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VV84FK()
  if fileExists(p):
   txt = FFBgGE(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVYrbA(self, tDict, item, fg, bg):
  if fg:
   self.VV6lTK(item, fg)
   self.VVRQsU(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVKC2Z(tDict)
 def VVKC2Z(self, tDict):
   p = self.VV84FK()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV6lTK(self, item, fg):
  if   item == "title" : FFOEeE(self["myTitle"], fg)
  elif item == "body"  :
   FFOEeE(self["myMenu"], fg)
   FFOEeE(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFL3RG(self["myBar"], fg)
   FFOEeE(self["keyRed"], fg)
   FFOEeE(self["keyGreen"], fg)
   FFOEeE(self["keyYellow"], fg)
   FFOEeE(self["keyBlue"], fg)
 def VVRQsU(self, item, bg):
  if   item == "title" : FFL3RG(self["myTitle"], bg)
  elif item == "body"  :
   FFL3RG(self["myMenu"], bg)
   FFL3RG(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFL3RG(self["myBar"], bg)
 def VV6K27(self):
  os.system(FFH6kH("rm %s" % self.VV84FK()))
  self.close()
 def VVck1e(self):
  tDict = self.VV2agK()
  self.VVzg4D(tDict, "title")
  self.VVzg4D(tDict, "body")
  self.VVzg4D(tDict, "cursor")
  self.VVzg4D(tDict, "bar")
 def VVzg4D(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV6lTK(name, fg)
  if bg: self.VVRQsU(name, bg)
 def VVdbk5(self):
  FFh9iv(self)
class CCIa4v():
 @staticmethod
 def VVXejN():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVNYou(isApply=False):
  global VVodPD, VVysIp
  VVodPD  = True
  VVysIp = CCIa4v.VVtpfX()
  CCIa4v.VV74WG()
 @staticmethod
 def VV74WG():
  if VVysIp:
   global VVodPD
   if CFG.forceUtf8Encoding.getValue():
    if CCIa4v.VVuzOf() : VVodPD = True
    else        : VVodPD = False
   else:
    CCIa4v.VVjD6h()
    VVodPD = False
 @staticmethod
 def VVtpfX(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFBgGE(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVuzOf():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVjD6h():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VVrRWu(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFxW7z(SELF, None, VV9o2E=lst, VVfhdd=30, VVeJ2z=True)
 @staticmethod
 def VVvRi6(path, SELF=None):
  for enc in CCIa4v.VVXejN():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFikHE(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVREeD(SELF, path, cbFnc, defEnc="", pos=0):
  FFNWTN(SELF)
  lst = CCIa4v.VVhFT2(path)
  if lst:
   VVRj9e = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFhTMc(txt, VV4U0A)
    VVRj9e.append((txt, enc))
   win = FFLATx(SELF, cbFnc, title="Select Encoding", VVRj9e=VVRj9e, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFNWTN(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVhFT2(path):
  encLst = []
  cPath = VVpTxo + "codecs"
  if fileExists(cPath):
   lines = FFwZqG(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCIa4v.VVXejN())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCYikR(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVRj9e = []
  VVRj9e.append(("Settings File"        , "SettingsFile"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Box Info"          , "VVuKve"    ))
  VVRj9e.append(("Tuners Info"         , "VVvbHk"   ))
  VVRj9e.append(("Python Version"        , "VVEFxQ"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Screen Size"         , "ScreenSize"    ))
  VVRj9e.append(("Language/Locale"        , "Locale"     ))
  VVRj9e.append(("Processor"         , "Processor"    ))
  VVRj9e.append(("Operating System"        , "OperatingSystem"   ))
  VVRj9e.append(("Drivers"          , "drivers"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("System Users"         , "SystemUsers"    ))
  VVRj9e.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVRj9e.append(("Uptime"          , "Uptime"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Host Name"         , "HostName"    ))
  VVRj9e.append(("MAC Address"         , "MACAddress"    ))
  VVRj9e.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVRj9e.append(("Network Status"        , "NetworkStatus"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Disk Usage"         , "VVbpch"    ))
  VVRj9e.append(("Mount Points"         , "MountPoints"    ))
  VVRj9e.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVRj9e.append(("USB Devices"         , "USB_Devices"    ))
  VVRj9e.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVRj9e.append(("Directory Size"        , "DirectorySize"   ))
  VVRj9e.append(("Memory"          , "Memory"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVRj9e.append(("Running Processes"       , "RunningProcesses"  ))
  VVRj9e.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFpJPp(self, VVRj9e=VVRj9e, title="Device Information")
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC78wY)
   elif item == "VVuKve"    : self.VVuKve()
   elif item == "VVvbHk"   : self.VVvbHk()
   elif item == "VVEFxQ"   : self.VVEFxQ()
   elif item == "ScreenSize"    : FFCsft(self, "Width\t: %s\nHeight\t: %s" % (FFRhrh()[0], FFRhrh()[1]))
   elif item == "Locale"     : CCIa4v.VVrRWu(self)
   elif item == "Processor"    : self.VVQWVp()
   elif item == "OperatingSystem"   : FFSdci(self, "uname -a"        )
   elif item == "drivers"     : self.VVMIi1()
   elif item == "SystemUsers"    : FFSdci(self, "id"          )
   elif item == "LoggedInUsers"   : FFSdci(self, "who -a"         )
   elif item == "Uptime"     : FFSdci(self, "uptime"         )
   elif item == "HostName"     : FFSdci(self, "hostname"        )
   elif item == "MACAddress"    : self.VVXO88()
   elif item == "NetworkConfiguration"  : FFSdci(self, "ifconfig %s %s" % (FFMRMu("HWaddr", VVQiYp), FFMRMu("addr:", VVJF5Y)))
   elif item == "NetworkStatus"   : FFSdci(self, "netstat -tulpn"       )
   elif item == "VVbpch"    : self.VVbpch()
   elif item == "MountPoints"    : FFSdci(self, "mount %s" % (FFMRMu(" on ", VVJF5Y)))
   elif item == "FileSystemTable"   : FFSdci(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFSdci(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFSdci(self, "blkid"         )
   elif item == "DirectorySize"   : FFSdci(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVZr1Z="Reading size ...")
   elif item == "Memory"     : FFSdci(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVooji()
   elif item == "RunningProcesses"   : FFSdci(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFSdci(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVgfLI()
   else         : self.close()
 def VVXO88(self):
  res = FFHpNj("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFCsft(self, txt)
  else:
   FFSdci(self, "ip link")
 def VVimzu(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF6vhB(cmd)
  return lines
 def VVLISW(self, lines, headerRepl, widths, VVujrY):
  VV16hm = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV16hm.append(parts)
  if VV16hm and len(header) == len(widths):
   VV16hm.sort(key=lambda x: x[0].lower())
   FFxW7z(self, None, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=28, VVeJ2z=True)
   return True
  else:
   return False
 def VVbpch(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVimzu(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVujrY = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVLISW(lines, headerRepl, widths, VVujrY)
  if not allOK:
   lines = FF6vhB(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FF09PB(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV4U0A:
     note = "\n%s" % FFhTMc("Green = Mounted Partitions", VV4U0A)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVJF5Y
     elif line.endswith(mountList) : color = VV4U0A
     else       : color = VVyTfh
     txt += FFhTMc(line, color) + "\n"
    FFCsft(self, txt + note)
   else:
    FFikHE(self, "Not data from system !")
 def VVooji(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVimzu(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVujrY = (LEFT , CENTER, LEFT )
  allOK = self.VVLISW(lines, headerRepl, widths, VVujrY)
  if not allOK:
   FFSdci(self, cmd)
 def VVMIi1(self):
  cmd = FFdVFr(VVP0LQ, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFSdci(self, cmd)
  else : FFNDX7(self)
 def VVQWVp(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFSdci(self, cmd)
 def VVgfLI(self):
  cmd = FFdVFr(VVVSqa, "| grep secondstage")
  if cmd : FFSdci(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFNDX7(self)
 def VVuKve(self):
  c = VV4U0A
  VV9o2E = []
  VV9o2E.append((FFhTMc("Box Type"  , c), FFhTMc(self.VVOzz4("boxtype").upper(), c)))
  VV9o2E.append((FFhTMc("Board Version", c), FFhTMc(self.VVOzz4("board_revision") , c)))
  VV9o2E.append((FFhTMc("Chipset"  , c), FFhTMc(self.VVOzz4("chipset")  , c)))
  VV9o2E.append((FFhTMc("S/N"   , c), FFhTMc(self.VVOzz4("sn")    , c)))
  VV9o2E.append((FFhTMc("Version"  , c), FFhTMc(self.VVOzz4("version")  , c)))
  VVf6PT   = []
  VVrVwa = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVrVwa = SystemInfo[key]
     else:
      VVf6PT.append((FFhTMc(str(key), VVejU1), FFhTMc(str(SystemInfo[key]), VVejU1)))
  except:
   pass
  if VVrVwa:
   VVs1XP = self.VVk5HU(VVrVwa)
   if VVs1XP:
    VVs1XP.sort(key=lambda x: x[0].lower())
    VV9o2E += VVs1XP
  if VVf6PT:
   VVf6PT.sort(key=lambda x: x[0].lower())
   VV9o2E += VVf6PT
  if VV9o2E:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFxW7z(self, None, header=header, VV9o2E=VV9o2E, VVec0v=widths, VVfhdd=28, VVeJ2z=True)
  else:
   FFCsft(self, "Could not read info!")
 def VVOzz4(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFwZqG(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVk5HU(self, mbDict):
  try:
   mbList = list(mbDict)
   VV9o2E = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV9o2E.append((FFhTMc(subject, VVJF5Y), FFhTMc(value, VVJF5Y)))
  except:
   pass
  return VV9o2E
 def VVvbHk(self):
  txt = self.VV8HBL("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VV8HBL("/proc/bus/nim_sockets")
  if not txt: txt = self.VVX0X1()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFCsft(self, txt)
 def VVX0X1(self):
  txt = ""
  VVm7lK = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVm7lK("Slot Name" , slot.getSlotName())
     txt += FFhTMc(slotName, VVJF5Y)
     txt += VVm7lK("Description"  , slot.getFullDescription())
     txt += VVm7lK("Frontend ID"  , slot.frontend_id)
     txt += VVm7lK("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VV8HBL(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFwZqG(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFhTMc(line, VVJF5Y)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVEFxQ(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFCsft(self, txt)
class CC78wY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVRj9e = []
  VVRj9e.append(("Settings (All)"   , "Settings_All"   ))
  VVRj9e.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VV98Ue:
   VVRj9e.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVRj9e.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVRj9e.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVRj9e.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVRj9e.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVRj9e.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFpJPp(self, VVRj9e=VVRj9e)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFSdci(self, cmd                )
   elif item == "Settings_HotKeys"   : FFSdci(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFSdci(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFSdci(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFSdci(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFSdci(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFSdci(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFSdci(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCgg9x(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVpHrm, VVpvKh, VV6PCI, camCommand = FFTxJf()
  self.VVpvKh = VVpvKh
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVRj9e = []
  VVRj9e.append(("OSCam Files"        , "OSCamFiles"  ))
  VVRj9e.append(("NCam Files"        , "NCamFiles"  ))
  VVRj9e.append(("CCcam Files"        , "CCcamFiles"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVRj9e.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVRj9e.append(VVmGWQ)
  if VVpvKh:
   if   "oscam" in VVpvKh : camName = "OSCam"
   elif "ncam"  in VVpvKh : camName = "NCam"
   VVRj9e.append((camName + " Info."      , "camInfo"   ))
   VVRj9e.append((camName + " Live Status"    , "camLiveStatus" ))
   VVRj9e.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVRj9e.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVRj9e.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFpJPp(self, VVRj9e=VVRj9e)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCTxRi, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCTxRi, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCTxRi, "cccam"))
   elif item == "OSCamReaders"  : self.VVjQ4E("os")
   elif item == "NSCamReaders"  : self.VVjQ4E("n")
   elif item == "camInfo"   : FFQVDp(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFb3oW(self.session, CClHkx.VVlLHQ)
   elif item == "camLiveReaders" : FFb3oW(self.session, CClHkx.VVPQ8h)
   elif item == "camLiveLog"  : FFb3oW(self.session, CClHkx.VVJce3)
   else       : self.close()
 def VVjQ4E(self, camPrefix):
  VV16hm = self.VVWeDH(camPrefix)
  if VV16hm:
   VV16hm.sort(key=lambda x: int(x[0]))
   if self.VVpvKh and self.VVpvKh.startswith(camPrefix):
    VVSYUp = ("Toggle State", self.VVDH8b, [camPrefix], "Changing State ...")
   else:
    VVSYUp = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVujrY  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFxW7z(self, None, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVSYUp=VVSYUp, VVvdC4=True)
 def VVWeDH(self, camPrefix):
  readersFile = self.VVpHrm + camPrefix + "cam.server"
  VV16hm = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFwZqG(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV16hm.append((str(len(VV16hm) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV16hm:
    FFikHE(self, "No readers found !")
  else:
   FF9mKB(self, readersFile)
  return VV16hm
 def VVDH8b(self, VVzpqh, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVpHrm, camPrefix)
  readerState  = VVzpqh.VVhJrx(1)
  readerLabel  = VVzpqh.VVhJrx(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCgg9x.VVnDIp(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVzpqh.VVKeCF()
    FFikHE(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV16hm = self.VVWeDH(camPrefix)
   if VV16hm:
    VVzpqh.VVgYkt(VV16hm)
 @staticmethod
 def VVnDIp(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFwZqG(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFikHE(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFikHE(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF9mKB(SELF, confFile)
   return None
  if not iRequest:
   FFikHE(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFikHE(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFikHE(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCTxRi(Screen):
 def __init__(self, VVas2Y, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVpHrm, VVpvKh, VV6PCI, camCommand = FFTxJf()
  if   VVas2Y == "ncam" : self.prefix = "n"
  elif VVas2Y == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVRj9e = []
  if self.prefix == "":
   VVRj9e.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVRj9e.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVRj9e.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVRj9e.append(("constant.cw"         , "x_constant_cw" ))
   VVRj9e.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVRj9e.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVRj9e.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVRj9e.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVRj9e.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVRj9e.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVRj9e.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVRj9e.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVRj9e.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVRj9e.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVRj9e.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFpJPp(self, VVRj9e=VVRj9e)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFqg4C(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFqg4C(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFqg4C(self, self.VVpHrm + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFqg4C(self, self.VVpHrm + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VV12PG("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VV12PG("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VV12PG("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VV12PG("cam.provid"        )
   elif item == "x_cam_server"  : self.VV12PG("cam.server"        )
   elif item == "x_cam_services" : self.VV12PG("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VV12PG("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VV12PG("cam.user"        )
   elif item == "x_VVM6J3"   : pass
   elif item == "x_SoftCam_Key" : self.VVn8Mv()
   elif item == "x_CCcam_cfg"  : FFqg4C(self, self.VVpHrm + "CCcam.cfg"    )
   elif item == "x_VVM6J3"   : pass
   elif item == "x_cam_log"  : FFqg4C(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFqg4C(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFqg4C(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VV12PG(self, fileName):
  FFqg4C(self, self.VVpHrm + self.prefix + fileName)
 def VVn8Mv(self):
  path = self.VVpHrm + "SoftCam.Key"
  if fileExists(path) : FFqg4C(self, path)
  else    : FFqg4C(self, path.replace(".Key", ".key"))
class CClHkx(Screen):
 VVlLHQ  = 0
 VVPQ8h = 1
 VVJce3 = 2
 def __init__(self, session, VVpHrm="", VVpvKh="", VV6PCI="", VVcTI9=VVlLHQ):
  self.skin, self.skinParam = FFRqpN(VV7AyH, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV6PCI   = VV6PCI
  self.VVcTI9  = VVcTI9
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVpHrm + VVpvKh + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVpvKh : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVpHrm, self.camPrefix)
  if self.VVcTI9 == self.VVlLHQ:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVcTI9 == self.VVPQ8h:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFpJPp(self, self.Title, addScrollLabel=True)
  FFpqes(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV4jyf
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self["myLabel"].VVGV2Z(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFKDC6(self)
  self.VV4jyf()
 def onExit(self):
  self.timer.stop()
 def VVl7Vm(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVeHEw)
  except:
   self.timer.callback.append(self.VVeHEw)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFNWTN(self, "Started", 1000)
 def VVMrHN(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVeHEw)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFNWTN(self, "Stopped", 1000)
 def VV4jyf(self):
  if self.timerRunning:
   self.VVMrHN()
  else:
   self.VVl7Vm()
   if self.VVcTI9 == self.VVlLHQ or self.VVcTI9 == self.VVPQ8h:
    if self.VVcTI9 == self.VVlLHQ : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCgg9x.VVnDIp(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFbH1W(self.VVgNG0)
    else:
     self.close()
   else:
    self.VVr2LJ()
 def VVeHEw(self):
  if self.timerRunning:
   if   self.VVcTI9 == self.VVlLHQ : self.VVyVAO()
   elif self.VVcTI9 == self.VVPQ8h : self.VVyVAO()
   else            : self.VVr2LJ()
 def VVr2LJ(self):
  if fileExists(self.VV6PCI):
   fTime = FFIb5k(os.path.getmtime(self.VV6PCI))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVv7Rj(), VVjlB2=VVQ2Bk)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV6PCI)
 def VVgNG0(self):
  self.VVyVAO()
 def VVyVAO(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFhTMc("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVtODU))
   self.camWebIfErrorFound = True
   self.VVMrHN()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVcTI9 == self.VVlLHQ : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFhTMc("Error while parsing data elements !\n\nError = %s" % str(e), VVOC4t)
   self.camWebIfErrorFound = True
   self.VVMrHN()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVtJJ8(root)
  self["myLabel"].setText(txt, VVjlB2=VVQ2Bk)
  self["myBar"].setText("Last Update : %s" % FFHy2o())
 def VVtJJ8(self, rootElement):
  def VVm7lK(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVcTI9 == self.VVlLHQ:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFhTMc(status, VV4U0A)
    else          : status = FFhTMc(status, VVOC4t)
    txt += VVM6J3 + "\n"
    txt += VVm7lK("Name"  , name)
    txt += VVm7lK("Description" , desc)
    txt += VVm7lK("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVm7lK("Protocol" , protocol)
    txt += VVm7lK("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFhTMc("Yes", VV4U0A)
    else    : enabTxt = FFhTMc("No", VVOC4t)
    txt += VVM6J3 + "\n"
    txt += VVm7lK("Label"  , label)
    txt += VVm7lK("Protocol" , protocol)
    txt += VVm7lK("Enabled" , enabTxt)
  return txt
 def VVv7Rj(self):
  wordsDict = self.VV0uUM()
  color = [ VVJF5Y, VVQiYp, VV4U0A, VVOC4t, VVejU1, VVBXnD]
  lines = FF6vhB("tail -n %d %s" % (100, self.VV6PCI))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVtODU + line[:19] + VVyTfh + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VV1LkE + line[ndx + 3:] + VVyTfh
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVJF5Y + line[ndx + 8 : ndx1 + 4] + VVyTfh + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVyTfh)
   elif line.startswith("----") or ">>" in line:
    line = FFhTMc(line, VVJF5Y)
   txt += line + "\n"
  return txt
 def VV0uUM(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFwZqG(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCtaa9(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVRj9e = []
  VVRj9e.append(("Backup Channels"    , "VVp3he"   ))
  VVRj9e.append(("Restore Channels"    , "Restore_Channels"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Backup SoftCAM Files"   , "VVGiaO" ))
  VVRj9e.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVRj9e.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVRj9e.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Backup Network Settings"  , "VVlnK7"   ))
  VVRj9e.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VV98Ue:
   VVRj9e.append(VVmGWQ)
   VVRj9e.append((VVtODU + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVY9q9"   ))
   VVRj9e.append((VV4U0A + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VV1ndx) , "createMyIpk"   ))
   VVRj9e.append((VV4U0A + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VV1ndx) , "createMyDeb"   ))
   VVRj9e.append((VVejU1 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVRj9e.append((VVejU1 + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVIzrL" ))
  FFpJPp(self, VVRj9e=VVRj9e)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVp3he"    : self.VVp3he()
   elif item == "Restore_Channels"    : self.VVUyHY("channels_backup*.tar.gz", self.VVRlnh)
   elif item == "VVGiaO"   : self.VVGiaO()
   elif item == "Restore_SoftCAM_Files"  : self.VVUyHY("softcam_backup*.tar.gz", self.VVzXDC)
   elif item == "Backup_TunerDiSEqC"   : self.VVpflU("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVUyHY("tuner_backup*.backup", boundFunction(self.VVQxdF, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVpflU("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVUyHY("hotkey_*backup*.backup", boundFunction(self.VVQxdF, "misc"))
   elif item == "VVlnK7"    : self.VVlnK7()
   elif item == "Restore_Network"    : self.VVUyHY("network_backup*.tar.gz", self.VVU13W)
   elif item == "VVY9q9"     : FF2QoN(self, boundFunction(FFjNEj, self, boundFunction(CCtaa9.VVY9q9, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVa50J(False)
   elif item == "createMyDeb"     : self.VVa50J(True)
   elif item == "createMyTar"     : self.VVRPdK()
   elif item == "VVIzrL"   : self.VVIzrL()
 @staticmethod
 def VVY9q9(SELF):
  OBF_Path = VVZQQ4 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVZQQ4, VVR4kJ, VV1ndx)
   if err : FFikHE(SELF, err)
   else : FFCsft(SELF, txt)
  else:
   FF9mKB(SELF, OBF_Path)
 def VVa50J(self, VVcKW9):
  OBF_Path = VVZQQ4 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFikHE(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVZQQ4)
  os.system("mv -f %s %s" % (VVZQQ4 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVZQQ4 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVZQQ4 + "plugin.py"))
  self.session.openWithCallback(self.VVa50J1, boundFunction(CCTskn, path=VVZQQ4, VVcKW9=VVcKW9))
 def VVa50J1(self):
  os.system("mv -f %s %s" % (VVZQQ4 + "OBF/main.py"  , VVZQQ4))
  os.system("mv -f %s %s" % (VVZQQ4 + "OBF/plugin.py" , VVZQQ4))
 def VVIzrL(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFikHE(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFikHE(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVmYuu("%s*.list" % path)
  if err:
   FF9mKB(self, path + "*.list")
   return
  srcF, err = self.VVmYuu("%s*main_final.py" % path)
  if err:
   FF9mKB(self, path + "*.final.py")
   return
  VV9o2E = []
  for f in files:
   f = os.path.basename(f)
   VV9o2E.append((f, f))
  FFLATx(self, boundFunction(self.VVzeHx, path, codF, srcF), VVRj9e=VV9o2E)
 def VVzeHx(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FF9mKB(self, logF)
   else     : FFjNEj(self, boundFunction(self.VVYGs5, logF, codF, srcF))
 def VVYGs5(self, logF, codF, srcF):
  lst  = []
  lines = FFwZqG(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFikHE(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVUlLZ(lst, logF, newLogF)
  totSrc  = self.VVUlLZ(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFCsft(self, txt)
 def VVmYuu(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVUlLZ(self, lst, f1, f2):
  txt = FFBgGE(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVRPdK(self):
  VV9o2E = []
  VV9o2E.append("%s%s" % (VVZQQ4, "*.py"))
  VV9o2E.append("%s%s" % (VVZQQ4, "*.png"))
  VV9o2E.append("%s%s" % (VVZQQ4, "*.xml"))
  VV9o2E.append("%s"  % (VVpTxo))
  FFSNG0(self, VV9o2E, "%s_%s" % (PLUGIN_NAME, VVR4kJ), addTimeStamp=False)
 def VVp3he(self):
  path1 = VV9gDR
  path2 = "/etc/tuxbox/"
  VV9o2E = []
  VV9o2E.append("%s%s" % (path1, "*.tv"))
  VV9o2E.append("%s%s" % (path1, "*.radio"))
  VV9o2E.append("%s%s" % (path1, "*list"))
  VV9o2E.append("%s%s" % (path1, "lamedb*"))
  VV9o2E.append("%s%s" % (path2, "*.xml"))
  FFSNG0(self, VV9o2E, "channels_backup", addTimeStamp=True)
 def VVGiaO(self):
  VV9o2E = []
  VV9o2E.append("/etc/tuxbox/config/")
  VV9o2E.append("/usr/keys/")
  VV9o2E.append("/usr/scam/")
  VV9o2E.append("/etc/CCcam.cfg")
  FFSNG0(self, VV9o2E, "softcam_backup", addTimeStamp=True)
 def VVlnK7(self):
  VV9o2E = []
  VV9o2E.append("/etc/hostname")
  VV9o2E.append("/etc/default_gw")
  VV9o2E.append("/etc/resolv.conf")
  VV9o2E.append("/etc/wpa_supplicant*.conf")
  VV9o2E.append("/etc/network/interfaces")
  VV9o2E.append("/etc/enigma2/nameserversdns.conf")
  FFSNG0(self, VV9o2E, "network_backup", addTimeStamp=True)
 def VVRlnh(self, fileName=None):
  if fileName:
   FF2QoN(self, boundFunction(self.VVZF2G, fileName), "Overwrite current channels ?")
 def VVZF2G(self, fileName):
  path = "%s%s" % (VVXKuz, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCAzDv.VVTgc7()
   lamedb5File, diabled5File = CCAzDv.VVStd1()
   cmd = ""
   cmd += FFH6kH("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFH6kH("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFVzbz()
   if res == 0 : FF7k8q(self, "Channels Restored.")
   else  : FFikHE(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FF9mKB(self, path)
 def VVzXDC(self, fileName=None):
  if fileName:
   FF2QoN(self, boundFunction(self.VV0SJK, fileName), "Overwrite SoftCAM files ?")
 def VV0SJK(self, fileName):
  fileName = "%s%s" % (VVXKuz, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVM6J3
   note = "You may need to restart your SoftCAM."
   FFZNP9(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFMRMu(note, VVJF5Y), sep))
  else:
   FF9mKB(self, fileName)
 def VVU13W(self, fileName=None):
  if fileName:
   FF2QoN(self, boundFunction(self.VVzN8V, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVzN8V(self, fileName):
  fileName = "%s%s" % (VVXKuz, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFF3Kc(self,  cmd)
  else:
   FF9mKB(self, fileName)
 def VVUyHY(self, pattern, callBackFunction, isTuner=False):
  title = FFSTdn()
  if pathExists(VVXKuz):
   myFiles = iGlob("%s%s" % (VVXKuz, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV9o2E = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV9o2E.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVrdmH = ("Sat. List", self.VVyJP1)
    else  : VVrdmH = None
    VVr5GC = ("Delete File", self.VVn8xR)
    FFLATx(self, callBackFunction, title=title, VVRj9e=VV9o2E, VVrdmH=VVrdmH, VVr5GC=VVr5GC)
   else:
    FFikHE(self, "No files found in:\n\n%s" % VVXKuz, title)
  else:
   FFikHE(self, "Path not found:\n\n%s" % VVXKuz, title)
 def VVn8xR(self, VVq5cQObj, path):
  FF2QoN(self, boundFunction(self.VVZhRA, VVq5cQObj, path), "Delete this file ?\n\n%s" % path)
 def VVZhRA(self, VVq5cQObj, path):
  path = VVXKuz + path
  os.system(FFH6kH("rm -f '%s'" % path))
  if fileExists(path) : FFNWTN(VVq5cQObj, "Not deleted", 1000)
  else    : VVq5cQObj.VVsgrR()
 def VVpflU(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CC82pG()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VV4nfl, filePrefix))
 def VV4nfl(self, filePrefix, result, retval):
  title = FFSTdn()
  if pathExists(VVXKuz):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFikHE(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVXKuz, filePrefix, FFOeCU())
    try:
     VV9o2E = str(result.strip()).split()
     if VV9o2E:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV9o2E:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVM6J3, FFhTMc(fName, VVJF5Y), VVM6J3)
       FFCsft(self, txt, title=title, VVjlB2=VVQ2Bk)
      else:
       FFikHE(self, "File creation failed!", title)
     else:
      FFikHE(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFH6kH("rm %s" % fName))
     FFikHE(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFH6kH("rm %s" % fName))
     FFikHE(self, "Error while writing file.")
  else:
   FFikHE(self, "Path not found:\n\n%s" % VVXKuz, title)
 def VVQxdF(self, mode, path=None):
  if path:
   path = "%s%s" % (VVXKuz, path)
   if fileExists(path):
    lines = FFwZqG(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FF2QoN(self, boundFunction(self.VVzJsk, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF3XbB(self, path, title=FFSTdn())
   else:
    FF9mKB(self, path)
 def VVzJsk(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VV46qm = []
  VV46qm.append("echo -e 'Reading current settings ...'")
  VV46qm.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VV46qm.append("echo -e 'Preparing new settings ...'")
  VV46qm.append(settingsLines)
  VV46qm.append("echo -e 'Applying new settings ...'")
  VV46qm.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFJiGS(self, VV46qm)
 def VVyJP1(self, VVq5cQObj, path):
  if not path:
   return
  path = VVXKuz + path
  if not fileExists(path):
   FF9mKB(self, path)
   return
  txt = FFBgGE(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV9o2E  = []
   for item in satList:
    VV9o2E.append("%s\t%s" % (item[0], FFFxRe(item[1])))
   FFCsft(self, VV9o2E, title="  Satellites List")
  else:
   FFikHE(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCyxBI(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVRj9e = []
  VVRj9e.append(("Plugins Browser List"       , "VVttEk"   ))
  VVRj9e.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVRj9e.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVRj9e.append(("Remove Packages (show all)"     , "VVAWRysAll"   ))
  VVRj9e.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Update List of Available Packages"   , "VVhsBT"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Packaging Tool"        , "VVHC0K"    ))
  VVRj9e.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFpJPp(self, VVRj9e=VVRj9e)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVttEk"   : self.VVttEk()
   elif item == "pluginsMenus"     : self.VVQOaw(0)
   elif item == "pluginsStartup"    : self.VVQOaw(1)
   elif item == "pluginsDirList"    : self.VVOkTF()
   elif item == "downloadInstallPackages"  : FFjNEj(self, boundFunction(self.VV7G7R, 0, ""))
   elif item == "VVAWRysAll"   : FFjNEj(self, boundFunction(self.VV7G7R, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFjNEj(self, boundFunction(self.VV7G7R, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVhsBT"   : self.VVhsBT()
   elif item == "VVHC0K"    : self.VVHC0K()
   elif item == "packagesFeeds"    : self.VV1Qcj()
   else          : self.close()
 def VVOkTF(self):
  extDirs  = FFk8hH(VVObQC)
  sysDirs  = FFk8hH(VVDDy9)
  VV9o2E  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV9o2E.append((item, VVObQC + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV9o2E.append((item, VVDDy9 + item))
  if VV9o2E:
   VV9o2E = sorted(VV9o2E, key=lambda x: x[0].lower())
   VVM10w = ("Package Info.", self.VVLH4K, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFxW7z(self, None, header=header, VV9o2E=VV9o2E, VVec0v=widths, VVfhdd=28, VVM10w=VVM10w)
  else:
   FFikHE(self, "Nothing found!")
 def VVLH4K(self, VVzpqh, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVObQC) : loc = "extensions"
  elif path.startswith(VVDDy9) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVHMe5(package)
  else:
   FFikHE(self, "No info!")
 def VV1Qcj(self):
  pkg = FFZfAA()
  if pkg : FFSdci(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFNDX7(self)
 def VVttEk(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVm7lK(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVM6J3 + "\n"
    txt += VVm7lK("Number"   , str(c))
    txt += VVm7lK("Name"   , FFhTMc(str(p.name), VVJF5Y))
    txt += VVm7lK("Path"  , p.path  )
    txt += VVm7lK("Description" , p.description )
    txt += VVm7lK("Icon"  , p.iconstr  )
    txt += VVm7lK("Wakeup Fnc" , p.wakeupfnc )
    txt += VVm7lK("NeedsRestart", p.needsRestart)
    txt += VVm7lK("Internal" , p.internal )
    txt += VVm7lK("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFCsft(self, txt)
 def VVQOaw(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VV9o2E = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VV9o2E.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VV9o2E:
   VV9o2E.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFxW7z(self, None, title=title, header=header, VV9o2E=VV9o2E, VVec0v=widths, VVfhdd=26)
  else:
   FFikHE(self, "Nothing Found", title=title)
 def VVhsBT(self):
  cmd = FFdVFr(VVtMrS, "")
  if cmd : FFF3Kc(self, cmd, checkNetAccess=True)
  else : FFNDX7(self)
 def VVHC0K(self):
  pkg = FFZfAA()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF7k8q(self, txt)
 def VV7G7R(self, mode, grep, VVzpqh=None, title=""):
  if   mode == 0: cmd = FFdVFr(VVVSqa    , grep)
  elif mode == 1: cmd = FFdVFr(VVP0LQ , grep)
  elif mode == 2: cmd = FFdVFr(VVP0LQ , grep)
  if not cmd:
   FFNDX7(self)
   return
  VV16hm = FF6vhB(cmd)
  if not VV16hm:
   if VVzpqh: VVzpqh.VVKeCF()
   FFikHE(self, "No packages found!")
   return
  elif len(VV16hm) == 1 and VV16hm[0] == VVKvgB:
   FFikHE(self, VVKvgB)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV9o2E  = []
  for item in VV16hm:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV9o2E.append((name, package, version))
  if mode > 0:
   extensions = FF6vhB("ls %s -l | grep '^d' | awk '{print $9}'" % VVObQC)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV9o2E:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV9o2E.append((name, VVObQC + item, "-"))
   systemPlugins = FF6vhB("ls %s -l | grep '^d' | awk '{print $9}'" % VVDDy9)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV9o2E:
      if item.lower() == row[0].lower():
       break
     else:
      VV9o2E.append((item, VVDDy9 + item, "-"))
  if not VV9o2E:
   FFikHE(self, "No packages found!")
   return
  if VVzpqh:
   VV9o2E.sort(key=lambda x: x[0].lower())
   VVzpqh.VVgYkt(VV9o2E, title)
  else:
   widths = (20, 50, 30)
   VVSYUp = None
   VVodFz = None
   if mode == 0:
    VV9OiG = ("Install" , self.VVrcc4   , [])
    VVSYUp = ("Download" , self.VV7cwK   , [])
    VVodFz = ("Filter"  , self.VVjloF , [])
   elif mode == 1:
    VV9OiG = ("Uninstall", self.VVAWRy, [])
   elif mode == 2:
    VV9OiG = ("Uninstall", self.VVAWRy, [])
    widths= (18, 57, 25)
   VV9o2E = sorted(VV9o2E, key=lambda x: x[0].lower())
   VVM10w = ("Package Info.", self.VV2lZE, [])
   header   = ("Name" ,"Package" , "Version" )
   FFxW7z(self, None, header=header, VV9o2E=VV9o2E, VVec0v=widths, VVfhdd=28, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz, VViXmI=self.lastSelectedRow
     , VVSYTz="#22110011", VV8c5A="#22191111", VVn7jC="#22191111", VVQceP="#00003030", VV2gSR="#00333333")
 def VV2lZE(self, VVzpqh, title, txt, colList):
  package = colList[1]
  self.VVHMe5(package)
 def VVjloF(self, VVzpqh, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVRj9e = []
  VVRj9e.append(("All Packages", "all"))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVRj9e.append(VVmGWQ)
  for word in words:
   VVRj9e.append((word, word))
  FFLATx(self, boundFunction(self.VVbU3k, VVzpqh), VVRj9e=VVRj9e, title="Select Filter")
 def VVbU3k(self, VVzpqh, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFjNEj(VVzpqh, boundFunction(self.VV7G7R, 0, grep, VVzpqh, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVAWRy(self, VVzpqh, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVObQC, VVDDy9)):
   FF2QoN(self, boundFunction(self.VVcfGG, VVzpqh, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVRj9e = []
   VVRj9e.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVRj9e.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVRj9e.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFLATx(self, boundFunction(self.VV72O9, VVzpqh, package), VVRj9e=VVRj9e)
 def VVcfGG(self, VVzpqh, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV1lRr)
  FFF3Kc(self, cmd, VV7kSC=boundFunction(self.VVFSu6, VVzpqh))
 def VV72O9(self, VVzpqh, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVmVbB
   elif item == "remove_ForceRemove"  : cmdOpt = VVK2Bq
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV9XKC
   FF2QoN(self, boundFunction(self.VV1oen, VVzpqh, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV1oen(self, VVzpqh, package, cmdOpt):
  self.lastSelectedRow = VVzpqh.VVG1bP()
  cmd = FFq4eO(cmdOpt, package)
  if cmd : FFF3Kc(self, cmd, VV7kSC=boundFunction(self.VVFSu6, VVzpqh))
  else : FFNDX7(self)
 def VVFSu6(self, VVzpqh):
  VVzpqh.cancel()
  FFA2or()
 def VVrcc4(self, VVzpqh, title, txt, colList):
  package  = colList[1]
  VVRj9e = []
  VVRj9e.append(("Install Package"         , "install_CheckVersion" ))
  VVRj9e.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVRj9e.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVRj9e.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVRj9e.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFLATx(self, boundFunction(self.VVrohf, package), VVRj9e=VVRj9e)
 def VVrohf(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVn4yS
   elif item == "install_ForceReinstall" : cmdOpt = VVNzzW
   elif item == "install_ForceOverwrite" : cmdOpt = VVjk7Z
   elif item == "install_ForceDowngrade" : cmdOpt = VVxUBG
   elif item == "install_IgnoreDepends" : cmdOpt = VV1HbW
   FF2QoN(self, boundFunction(self.VVzGBT, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVzGBT(self, package, cmdOpt):
  cmd = FFq4eO(cmdOpt, package)
  if cmd : FFF3Kc(self, cmd, VV7kSC=FFA2or, checkNetAccess=True)
  else : FFNDX7(self)
 def VV7cwK(self, VVzpqh, title, txt, colList):
  package  = colList[1]
  FF2QoN(self, boundFunction(self.VVVUN7, package), "Download Package ?\n\n%s" % package)
 def VVVUN7(self, package):
  if FFcX1Z():
   cmd = FFq4eO(VVQKic, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFMRMu(success, VV4U0A))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFMRMu(fail, VVOC4t))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFF3Kc(self, cmd, VV87Dz=[VVOC4t, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFNDX7(self)
  else:
   FFikHE(self, "No internet connection !")
 def VVHMe5(self, package):
  infoCmd  = FFq4eO(VVuptD, package)
  filesCmd = FFq4eO(VVO3W1, package)
  listInstCmd = FFdVFr(VVP0LQ, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFwDGd(VVJF5Y)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFMRMu(notInst, VVtODU))
   cmd += "else "
   cmd +=   FF1ZnE("System Info", VVJF5Y)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF1ZnE("Related Files", VVJF5Y)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFsnYb(self, cmd)
  else:
   FFNDX7(self)
class CCAzDv(Screen):
 VV2DlB  = 0
 VVKBOU = 1
 VVH6c0  = 2
 VV9I91  = 3
 VVLB1y = 4
 VVTH10 = 5
 VViT51 = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVvqIy = None
  self.lastfilterUsed  = None
  VVRj9e = self.VVQyOm()
  FFpJPp(self, VVRj9e=VVRj9e, title="Services/Channels")
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self["myMenu"].setList(self.VVQyOm())
  FFl7ED(self["myMenu"])
  FFwbY1(self)
 def VVQyOm(self):
  VVRj9e = []
  VVRj9e.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVRj9e.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVRj9e.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVRj9e.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVRj9e.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVRj9e.append(("Services with PIcons for the System"  , "VVfrZg"     ))
  VVRj9e.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVRj9e.append(VVmGWQ)
  lamedbFile, disabledFile = CCAzDv.VVTgc7()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVRj9e.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVRj9e.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVRj9e.append(("Reset Parental Control Settings"   , "VVrLm3"    ))
  VVRj9e.append(("Delete Channels with no names"   , "VVgY4c"    ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Reload Channels and Bouquets"    , "VVmT8a"      ))
  return VVRj9e
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFh9iv(self)
   elif item == "currentServiceInfo"     : FFgBdr(self, fncMode=CCR0BS.VV3oR1)
   elif item == "TranspondersStats"     : FFjNEj(self, self.VVPtMo     )
   elif item == "lameDB_allChannels_with_refCode"  : FFjNEj(self, self.VVInQK )
   elif item == "lameDB_allChannels_with_tranaponder" : FFjNEj(self, self.VVfj4U)
   elif item == "lameDB_allChannels_with_details"  : FFjNEj(self, self.VVPgfz )
   elif item == "parentalControlChannels"    : FFjNEj(self, self.VVAoAU   )
   elif item == "showHiddenChannels"     : FFjNEj(self, self.VVgzWI     )
   elif item == "VVfrZg"     : FFjNEj(self, self.VVDkGd     )
   elif item == "servicesWithMissingPIcons"   : FFjNEj(self, self.VViPWo   )
   elif item == "enableHiddenChannels"     : self.VVWtl7(True)
   elif item == "disableHiddenChannels"    : self.VVWtl7(False)
   elif item == "VVrLm3"    : FF2QoN(self, self.VVrLm3, "Reset and Restart ?" )
   elif item == "VVgY4c"    : FFjNEj(self, self.VVgY4c)
   elif item == "VVmT8a"      : FFjNEj(self, boundFunction(CCAzDv.VVmT8a, self))
   else            : self.close()
 @staticmethod
 def VVmT8a(SELF):
  FFVzbz()
  FF7k8q(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVInQK(self):
  self.VVvqIy = None
  self.lastfilterUsed  = None
  self.filterObj   = CC1WKO(self)
  VV16hm = CCAzDv.VVRwNz(self, self.VV2DlB)
  if VV16hm:
   VV16hm.sort(key=lambda x: x[0].lower())
   VVOrFX  = ("Zap"   , self.VVUntV     , [])
   VVEJ7p = (""    , self.VVcYK9   , [])
   VVM10w = ("Options"  , self.VVte7w , [])
   VVSYUp = ("Current Service", self.VVxPUt , [])
   VVodFz = ("Filter"   , self.VVNuYl  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVujrY  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFxW7z(self, None, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz)
 def VVfj4U(self):
  self.VVvqIy = None
  self.lastfilterUsed  = None
  self.filterObj   = CC1WKO(self)
  VV16hm = CCAzDv.VVRwNz(self, self.VVKBOU)
  if VV16hm:
   VV16hm.sort(key=lambda x: x[0].lower())
   VVOrFX  = ("Zap"   , self.VVUntV      , [])
   VVEJ7p = (""    , self.VVcYK9    , [])
   VVSYUp = ("Current Service", self.VVxPUt  , [])
   VVM10w = ("Options"  , self.VVFaHj , [])
   VVodFz = ("Filter"   , self.VVmJFW  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVujrY  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFxW7z(self, None, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz)
 def VVte7w(self, VVzpqh, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCXiQX(self, VVzpqh, 3)
  mSel.VVobLB(servName, refCode, pcState, hidState)
 def VVFaHj(self, VVzpqh, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCXiQX(self, VVzpqh, 3)
  mSel.VV1quF(servName, refCode)
 def VV8Oa4(self, VVzpqh, refCode, isAddToBlackList):
  VVzpqh.VV8kAl("Processing ...")
  FFbH1W(boundFunction(self.VVYAZX, VVzpqh, [refCode], isAddToBlackList))
 def VVsE0H(self, VVzpqh, isAddToBlackList):
  refCodeList = VVzpqh.VVe8MB(3)
  if not refCodeList:
   FFikHE(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVzpqh.VV8kAl("Processing ...")
  FFbH1W(boundFunction(self.VVYAZX, VVzpqh, refCodeList, isAddToBlackList))
 def VVYAZX(self, VVzpqh, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVi5hU, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVi5hU):
   lines = FFwZqG(VVi5hU)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVi5hU, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVzpqh.VVS8vj
   if isMulti:
    self.VV266C(VVzpqh, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV8Nar(VVzpqh, refCode)
    VVzpqh.VVKeCF()
  else:
   VVzpqh.VVjkTY("No changes")
 def VVSrC3(self, VVzpqh, refCode, isHide):
  title = "Change Hidden State"
  if FFQVBm(refCode):
   VVzpqh.VV8kAl("Processing ...")
   ret = FFgRoS(refCode, isHide)
   if ret : FFjNEj(self, boundFunction(self.VV8Nar, VVzpqh, refCode))
   else : FFikHE(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFikHE(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV8Nar(self, VVzpqh, refCode):
  VV16hm = CCAzDv.VVRwNz(self, self.VV2DlB, VVOw6V=[3, [refCode], False])
  done = False
  if VV16hm:
   data = VV16hm[0]
   if data[3] == refCode:
    done = VVzpqh.VVt4Mg(data)
  if not done:
   self.VVGwzC(VVzpqh, VVzpqh.VVPsg7(), self.VV2DlB)
  VVzpqh.VVKeCF()
 def VV266C(self, VVzpqh, totRefCodes):
  VV16hm = CCAzDv.VVRwNz(self, self.VV2DlB, VVOw6V=self.VVvqIy)
  VVzpqh.VVgYkt(VV16hm)
  VVzpqh.VV0fYN(False)
  VVzpqh.VVjkTY("%d Processed" % totRefCodes)
 def VV7iFM(self, VVzpqh, isHide):
  refCodeList = VVzpqh.VVe8MB(3)
  if not refCodeList:
   FFikHE(self, "Nothing selected", title="Change Hidden State")
   return
  VVzpqh.VV8kAl("Processing ...")
  FFbH1W(boundFunction(self.VVkR45, VVzpqh, refCodeList, isHide))
 def VVkR45(self, VVzpqh, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFgRoS(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VV266C(VVzpqh, len(refCodeList))
  else:
   VVzpqh.VVjkTY("No changes")
 def VVNuYl(self, VVzpqh, title, txt, colList):
  self.filterObj.VV9UbP(1, VVzpqh, 2, boundFunction(self.VV4q61, VVzpqh))
 def VV4q61(self, VVzpqh, item):
  self.VVQ90Y(VVzpqh, item, 2, self.VV2DlB)
 def VVmJFW(self, VVzpqh, title, txt, colList):
  self.filterObj.VV9UbP(2, VVzpqh, 4, boundFunction(self.VVZnzJ, VVzpqh))
 def VVZnzJ(self, VVzpqh, item):
  self.VVQ90Y(VVzpqh, item, 4, self.VVKBOU)
 def VVwPFp(self, VVzpqh, title, txt, colList):
  self.filterObj.VV9UbP(0, VVzpqh, 4, boundFunction(self.VVAFXy, VVzpqh))
 def VVAFXy(self, VVzpqh, item):
  self.VVQ90Y(VVzpqh, item, 4, self.VVH6c0)
 def VVQ90Y(self, VVzpqh, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVzpqh.VVhJrx(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVvqIy = None
  else:
   words, asPrefix = CC1WKO.VVYNyo(words)
   self.VVvqIy = [col, words, asPrefix]
  if words: FFjNEj(self, boundFunction(self.VVGwzC, VVzpqh, title, mode), title="Reading Services ...")
  else : FFNWTN(VVzpqh, "Incorrect filter", 2000)
 def VVGwzC(self, VVzpqh, title, mode):
  VV16hm = CCAzDv.VVRwNz(self, mode, VVOw6V=self.VVvqIy, VVCLSM=False)
  if VV16hm:
   VV16hm.sort(key=lambda x: x[0].lower())
   VVzpqh.VVgYkt(VV16hm, title)
  else:
   VVzpqh.VVKeCF()
   FFNWTN(VVzpqh, "Not found!", 1500)
 def VVdRLc(self, VV9o2E, VVOrFX=None, VVEJ7p=None, VV9OiG=None, VVSYUp=None, VVM10w=None, VVodFz=None):
  VVSYUp = ("Current Service", self.VVxPUt, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVujrY = (LEFT  , LEFT  , CENTER, LEFT    )
  FFxW7z(self, None, header=header, VV9o2E=VV9o2E, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz)
 def VVxPUt(self, VVzpqh, title, txt, colList):
  self.VV7mBu(VVzpqh)
 def VVnhWa(self, VVzpqh, title, txt, colList):
  self.VV7mBu(VVzpqh, True)
 def VV7mBu(self, VVzpqh, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVzpqh.VVSEni(colDict, VVztK4=True)
   else:
    VVzpqh.VViaYk(3, refCode, True)
   return
  FFikHE(self, "Colud not read current Reference Code !")
 def VVPgfz(self):
  self.VVvqIy = None
  self.lastfilterUsed  = None
  self.filterObj   = CC1WKO(self)
  VV16hm = CCAzDv.VVRwNz(self, self.VVH6c0)
  if VV16hm:
   VV16hm.sort(key=lambda x: x[0].lower())
   VVEJ7p = (""    , self.VVE2OA , []      )
   VVSYUp = ("Current Service", self.VVnhWa  , []      )
   VVodFz = ("Filter"   , self.VVwPFp   , [], "Loading Filters ..." )
   VVOrFX  = ("Zap"   , self.VVaZmC      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVujrY  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFxW7z(self, None, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVSYUp=VVSYUp, VVodFz=VVodFz)
 def VVE2OA(self, VVzpqh, title, txt, colList):
  refCode  = self.VVOTkN(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFgBdr(self, fncMode=CCR0BS.VVHvQ0, refCode=refCode, chName=chName, text=txt)
 def VVaZmC(self, VVzpqh, title, txt, colList):
  refCode = self.VVOTkN(colList)
  FFZXnt(self, refCode)
 def VVUntV(self, VVzpqh, title, txt, colList):
  FFZXnt(self, colList[3])
 def VVOTkN(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVRwNz(SELF, mode, VVOw6V=None, VVCLSM=True, VVgUIE=True):
  lamedbFile, disabledFile = CCAzDv.VVTgc7()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVOw6V:
    filterCol = VVOw6V[0]
    filterWords = VVOw6V[1]
    asPrefix = VVOw6V[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCAzDv.VV2DlB:
    blackList = None
    if fileExists(VVi5hU):
     blackList = FFwZqG(VVi5hU)
     if blackList:
      blackList = set(blackList)
   elif mode == CCAzDv.VVKBOU:
    tp = CCWZOp()
   VVO3Uv, VVDmXY = FFcBHV()
   tagFound  = False
   if mode in (CCAzDv.VVTH10, CCAzDv.VViT51):
    VV16hm = {}
   else:
    VV16hm = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFMNbQ(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCAzDv.VVH6c0:
        if sTypeInt in VVO3Uv:
         STYPE = VVDmXY[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV16hm.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV16hm.append(tRow)
        else:
         VV16hm.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCAzDv.VVTH10:
         VV16hm[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCAzDv.VViT51:
         VV16hm[chName] = refCode
        elif mode == CCAzDv.VV2DlB:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV16hm.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV16hm.append(tRow)
         else:
          VV16hm.append(tRow)
        elif mode == CCAzDv.VVKBOU:
         if sTypeInt in VVO3Uv:
          STYPE = VVDmXY[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVAUQo(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV16hm.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV16hm.append(tRow)
         else:
          VV16hm.append(tRow)
        elif mode == CCAzDv.VV9I91:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV16hm.append((chName, chProv, sat, refCode))
        elif mode == CCAzDv.VVLB1y:
         VV16hm.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV16hm and VVCLSM:
    FFikHE(SELF, "No services found!")
   return VV16hm
  else:
   if VVgUIE:
    FF9mKB(SELF, lamedbFile)
   return None
 def VVAoAU(self):
  if fileExists(VVi5hU):
   lines = FFwZqG(VVi5hU)
   if lines:
    newRows  = []
    VV16hm = CCAzDv.VVRwNz(self, self.VVLB1y)
    if VV16hm:
     lines = set(lines)
     for item in VV16hm:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV16hm = newRows
      VV16hm.sort(key=lambda x: x[0].lower())
      VVEJ7p = ("", self.VVcYK9, [])
      VVOrFX = ("Zap", self.VVUntV, [])
      self.VVdRLc(VV9o2E=VV16hm, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p)
     else:
      FFCsft(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV16hm)))
   else:
    FF7k8q(self, "No active Parental Control services.", FFSTdn())
  else:
   FF9mKB(self, VVi5hU)
 def VVgzWI(self):
  VV16hm = CCAzDv.VVRwNz(self, self.VV9I91)
  if VV16hm:
   VV16hm.sort(key=lambda x: x[0].lower())
   VVEJ7p = ("" , self.VVcYK9, [])
   VVOrFX  = ("Zap", self.VVUntV, [])
   self.VVdRLc(VV9o2E=VV16hm, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p)
  else:
   FF7k8q(self, "No hidden services.", FFSTdn())
 def VVPtMo(self):
  totT, totC, totA, totS, totS2, satList = self.VVEcVQ()
  txt = FFhTMc("Total Transponders:\n\n", VVejU1)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFhTMc("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVejU1)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFnvnw(item), satList.count(item))
  FFCsft(self, txt)
 def VVEcVQ(self):
  lamedbFile, disabledFile = CCAzDv.VVTgc7()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FF9mKB(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVDkGd(self)   : self.VVfrZg(True)
 def VViPWo(self) : self.VVfrZg(False)
 def VVfrZg(self, isWithPIcons):
  piconsPath = CC0sln.VVij8s()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC0sln.VVj6fI(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV16hm = CCAzDv.VVRwNz(self, self.VVLB1y)
    if VV16hm:
     channels = []
     for (chName, chProv, sat, refCode) in VV16hm:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFXJXu(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV16hm)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVm7lK(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVm7lK("PIcons Path"  , piconsPath)
     txt += VVm7lK("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVm7lK("Total services" , totalServices)
     txt += VVm7lK("With PIcons"  , totalWithPIcons)
     txt += VVm7lK("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFCsft(self, txt)
     else:
      VVEJ7p     = (""      , self.VVcYK9 , [])
      if isWithPIcons : VVodFz = ("Export Current PIcon", self.VVDYsv  , [])
      else   : VVodFz = None
      VVM10w     = ("Statistics", FFCsft, [txt])
      VVOrFX      = ("Zap", self.VVUntV, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVdRLc(VV9o2E=channels, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVM10w=VVM10w, VVodFz=VVodFz)
   else:
    FFikHE(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFikHE(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVcYK9(self, VVzpqh, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFgBdr(self, fncMode=CCR0BS.VVHvQ0, refCode=refCode, chName=chName, text=txt)
 def VVDYsv(self, VVzpqh, title, txt, colList):
  png, path = CC0sln.VVA0Cp(colList[3], colList[0])
  if path:
   CC0sln.VVq2g2(self, png, path)
 @staticmethod
 def VVTgc7():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVStd1():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVWtl7(self, isEnable):
  lamedbFile, disabledFile = CCAzDv.VVTgc7()
  if isEnable and not fileExists(disabledFile):
   FF7k8q(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFikHE(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FF2QoN(self, boundFunction(self.VV7Z3a, isEnable), "%s Hidden Channels ?" % word)
 def VV7Z3a(self, isEnable):
  lamedbFile , disabledFile = CCAzDv.VVTgc7()
  lamedb5File, diabled5File = CCAzDv.VVStd1()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFVzbz()
  if res == 0 : FF7k8q(self, "Hidden List %s" % word)
  else  : FFikHE(self, "Error while restoring:\n\n%s" % fileName)
 def VVrLm3(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFJiGS(self, cmd)
 def VVgY4c(self):
  lamedbFile, disabledFile = CCAzDv.VVTgc7()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFH6kH("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFwZqG(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFH6kH("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFVzbz()
   FFCsft(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FF9mKB(self, lamedbFile)
class CCR0BS(Screen):
 VV3oR1  = 0
 VVAF5u   = 1
 VVGDay   = 2
 VVHvQ0    = 3
 VVIJPI    = 4
 VVpgmd   = 5
 VVpv4M   = 6
 VVMXLh    = 7
 VV9PtM   = 8
 VVLJKv   = 9
 VVerG0   = 10
 VVGTvQ   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFRqpN(VV7AyH, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV3oR1)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFhTMc("%s\n", VVWmbA) % VVM6J3
  self.picViewer  = None
  FFpJPp(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VV99LD })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self["myLabel"].VVGV2Z(textOutFile="chann_info")
  if   self.fncMode == self.VV3oR1 : fnc = self.VVM8a6_VV3oR1
  elif self.fncMode == self.VVAF5u  : fnc = self.VVM8a6_VV3oR1
  elif self.fncMode == self.VVGDay  : fnc = self.VVM8a6_VV3oR1
  elif self.fncMode == self.VVHvQ0  : fnc = self.VVM8a6_VVHvQ0
  elif self.fncMode == self.VVIJPI  : fnc = self.VVM8a6_VVIJPI
  elif self.fncMode == self.VVpgmd  : fnc = self.VVM8a6_VVpgmd
  elif self.fncMode == self.VVpv4M  : fnc = self.VVM8a6_VVpv4M
  elif self.fncMode == self.VVMXLh  : fnc = self.VVM8a6_VVMXLh
  elif self.fncMode == self.VV9PtM  : fnc = self.VVM8a6_VV9PtM
  elif self.fncMode == self.VVLJKv : fnc = self.VVM8a6_VVLJKv
  elif self.fncMode == self.VVerG0  : fnc = self.VVM8a6_VVerG0
  elif self.fncMode == self.VVGTvQ : fnc = self.VVM8a6_VVGTvQ
  self["myLabel"].setText("\n   Reading Info ...")
  FFbH1W(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV7d2R()
 def VVkapn(self, err):
  self["myLabel"].setText(err)
  FFL3RG(self["myTitle"], "#22200000")
  FFL3RG(self["myBody"], "#22200000")
  self["myLabel"].FFL3RGColor("#22200000")
  self["myLabel"].VVJmq8()
 def VVM8a6_VV3oR1(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  self.refCode = refCode
  self.VVtwxj(chName)
 def VVM8a6_VVHvQ0(self):
  self.VVtwxj(self.chName)
 def VVM8a6_VVIJPI(self):
  self.VVtwxj(self.chName)
 def VVM8a6_VVpgmd(self):
  self.VVtwxj(self.chName)
 def VVM8a6_VVpv4M(self):
  self.VVtwxj("Picon Info")
 def VVM8a6_VVMXLh(self):
  self.VVtwxj(self.chName)
 def VVM8a6_VV9PtM(self):
  self.VVtwxj(self.chName)
 def VVM8a6_VVLJKv(self):
  self.VVtwxj(self.chName)
 def VVM8a6_VVerG0(self):
  self.chUrl = self.refCode + self.callingSELF.VVpRwI(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVtwxj(self.chName)
 def VVM8a6_VVGTvQ(self):
  self.VVtwxj(self.chName)
 def VVtwxj(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFFa90(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVda9g(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFhTMc(self.VVV3zy(tUrl), VVyTfh)
  if not self.epg:
   epg = self.VVk564(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV7S2E(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC0sln.VVA0Cp(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV7S2E(path)
  self.VVZiPo()
  self.VVfPfg()
  self["myLabel"].setText(self.text, VVjlB2=VVzgBH)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVJmq8(minHeight=minH)
 def VVfPfg(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF0haM(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVqbcl(FFRmmV(url))
  if epg:
   self.text += "\n" + FFO6Fd("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVZiPo()
 def VVZiPo(self):
  if not self.piconShown and self.picUrl:
   path, err = FFnx0u(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV7S2E(path)
    if self.piconShown and self.refCode:
     self.VVh82z(path, self.refCode)
 def VVh82z(self, path, refCode):
  if path and fileExists(path) and os.system(FFH6kH("which ffmpeg")) == 0:
   pPath = CC0sln.VVij8s()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFH6kH("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV7S2E(self, path):
  if path and fileExists(path):
   err, w, h = self.VVoe8S(path)
   if not err:
    if h > w:
     self.VV06bQ(self["myPicF"], w, h, True)
     self.VV06bQ(self["myPic"] , w, h, False)
   self.picViewer = CCaOlz.VVE2NE(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VV06bQ(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVoe8S(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFT5H5(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVda9g(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFhTMc(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVm7lK(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFhTMc(state, VVtODU)
   txt += "State\t: %s\n" % state
  w = FFuM16(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFuM16(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVl6ZL(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVm7lK(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVm7lK(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVm7lK(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVWIrG()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVxkJR()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCR0BS.VVpXIP(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFhTMc("IPTV", VVejU1)
   txt += self.VVqmSg(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVFsmb(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCWZOp()
    tpTxt, namespace = tp.VVT7JV(refCode)
    del tp
    if tpTxt:
     txt += FFhTMc("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFhTMc("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVm7lK(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVm7lK(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVm7lK(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVm7lK(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVm7lK(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVm7lK(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVm7lK(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVm7lK(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVm7lK(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVl6ZL(info):
  if info:
   aspect = FFuM16(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVm7lK(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFuM16(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVOYpD(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVOYpD(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVWIrG(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVxkJR(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVFsmb(self, refCode, iptvRef, chName):
  refCode = FF301l(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFBgGE(VV9gDR + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFBgGE(VV9gDR + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV9o2E = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VV9gDR + item
   if fileExists(path):
    txt = FFBgGE(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV9o2E.append(bName)
  txt = self.Sep
  if VV9o2E:
   if len(VV9o2E) == 1:
    txt += "%s\t: %s\n" % (FFhTMc("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV9o2E[0])
   else:
    txt += FFhTMc("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV9o2E):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVk564(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVFXXz(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVFXXz(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVFXXz(event, 0)
     except:
      pass
  return epg
 def VVFXXz(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVhDbv(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFhTMc(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFhTMc(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFIb5k(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFIb5k(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFhztG(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFhztG(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFhztG(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFhTMc(evShort, VVo3CO)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFhTMc(evDesc , VVo3CO)
    if txt:
     txt = FFhTMc("\n%s\n%s Event:\n%s\n" % (VVM6J3, ("Current", "Next")[evNum], VVM6J3), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVqmSg(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFGrEr(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CC1ywg()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVqaCG(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFhTMc("URL:", VVejU1) + "\n%s\n" % self.VVV3zy(decodedUrl)
  else:
   txt = "\n"
   txt += FFhTMc("Reference:", VVejU1) + "\n%s\n" % refCode
  return txt
 def VVV3zy(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VV98Ue:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVqbcl(self, decodedUrl):
  if not FFcX1Z():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCfMBx.VVTzl0(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCfMBx.VVlh6L(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVdjBg(tDict)
   elif uType == "movie" : epg, picUrl = self.VVerrO(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVdjBg(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCfMBx.VV7oGw(item, "title"    , is_base64=True )
     lang    = CCfMBx.VV7oGw(item, "lang"         ).upper()
     description   = CCfMBx.VV7oGw(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCfMBx.VV7oGw(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCfMBx.VV7oGw(item, "start_timestamp"      )
     stop_timestamp  = CCfMBx.VV7oGw(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCfMBx.VV7oGw(item, "stop_timestamp"       )
     now_playing   = CCfMBx.VV7oGw(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV1LkE, ""
      else     : color, txt = VVtODU , "    (CURRENT EVENT)"
      epg += FFhTMc("_" * 32 + "\n", VVWmbA)
      epg += FFhTMc("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFhTMc(description, VVyTfh)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVs2Qe(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVerrO(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCfMBx.VV7oGw(item, "movie_image" )
    genre  = CCfMBx.VV7oGw(item, "genre"   ) or "-"
    plot  = CCfMBx.VV7oGw(item, "plot"   ) or "-"
    cast  = CCfMBx.VV7oGw(item, "cast"   ) or "-"
    rating  = CCfMBx.VV7oGw(item, "rating"   ) or "-"
    director = CCfMBx.VV7oGw(item, "director"  ) or "-"
    releasedate = CCfMBx.VV7oGw(item, "releasedate" ) or "-"
    duration = CCfMBx.VV7oGw(item, "duration"  ) or "-"
    try:
     lang = CCfMBx.VV7oGw(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFhTMc(cast, VVyTfh)
    epg += "Plot:\n%s"    % FFhTMc(self.VVhDbv(plot), VVyTfh)
   except:
    pass
  return epg, movie_image
 def VVhDbv(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVvb3m(evTxt, lang)
   return CCR0BS.VVPANn(txt).strip() or evTxt
 @staticmethod
 def VVPANn(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVvb3m(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFu3Zi(txt))
   txt, err = CCfMBx.VVlh6L(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFRmmV(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVs2Qe(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVlFfo(SELF):
  if not CCAvMQ.VVJdIu(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(SELF)
  err = url =  fSize = resumable = ""
  if FFKi35(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CC1ywg.VV3YGN(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CC1ywg.VV4p8EHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFikHE(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCMTIp.VVJrmt(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFhTMc(" (M3U/M3U8 File)", VVyTfh)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCtZ0M.VVo5u5(resp) else "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVWMqO(subj, val):
   return "%s\n%s\n\n" % (FFhTMc("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVWMqO(title , fSize or "?")
  txt += VVWMqO("Name" , chName)
  txt += VVWMqO("URL" , url)
  if resumable: txt += VVWMqO("Supports Download-Resume", resumable)
  if err  : txt += FFhTMc("Error:\n", VVtODU) + err
  FFCsft(SELF, txt, title=title)
 @staticmethod
 def VVpXIP(SELF):
  fPath, fDir, fName = CCMTIp.VVw0KC(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VV99LD(self):
  if VV98Ue:
   def VVm7lK(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVm7lK(n[i], v[i])
   if "chCode" in iptvRef:
    p = CC1ywg()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVqaCG(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVm7lK(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVM6J3, txt))
   FFNWTN(self, "Saved to:", 1000)
class CC1ywg():
 def __init__(self):
  self.VVnccW   = ""
  self.VVaKxu    = ""
  self.VVPf2X   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.colored_user   = "#f#11ffffaa#User"
  self.colored_server   = "#f#11aaffff#Server"
 def VVFpY6(self, url, mac, VVztK4=True):
  self.VVnccW   = ""
  self.VVaKxu    = ""
  self.VVPf2X   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  host = self.VVK8Dc(url)
  if not host:
   if VVztK4:
    self.VVztK4or("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVfsMQ(mac)
  if not host:
   if VVztK4:
    self.VVztK4or("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVnccW = host
  self.VVaKxu  = mac
  return True
 def VVK8Dc(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVfsMQ(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVeUNh(self):
  res, err = self.VVoyfY(self.VV1yVj())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVnccW:
   self.VVnccW = self.VVnccW.replace(urlPath, "")
   res, err = self.VVoyfY(self.VV1yVj())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCfMBx.VV7oGw(tDict["js"], "token")
    rand  = CCfMBx.VV7oGw(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVoAYP(self, VVztK4=True):
  err = blkMsg = FF7k8qTxt = ""
  try:
   token, rand, err = self.VVeUNh()
   if token:
    self.VVPf2X = token
    self.portal_moreAuthRand = rand
    if rand:
     self.portal_moreAuthType = 2
    prof, retTxt = self.VVB7JA(True)
    if prof:
     self.portal_moreAuthMsg = retTxt
     if "device_id mismatch" in retTxt:
      self.portal_moreAuthType = 3
      prof, retTxt = self.VVB7JA(False)
      if retTxt:
       self.portal_moreAuthMsg = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF7k8qTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF7k8qTxt: tErr += "\n%s" % FF7k8qTxt
  if VVztK4:
   self.VVztK4or(tErr)
  return "", "", tErr
 def VVB7JA(self, capMac):
  res, err = self.VVoyfY(self.VVPO5y(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCfMBx.VV7oGw(tDict["js"], "block_%s" % word)
    FF7k8qTxt = CCfMBx.VV7oGw(tDict["js"], word)
    return tDict, FF7k8qTxt.strip() or blkMsg.strip()
   except Exception as e:
    pass
  return "", ""
 def VVPO5y(self, capMac):
  if self.portal_moreAuthMsg or self.portal_moreAuthRand:
   import hashlib
   if capMac: mac = self.VVaKxu.upper()
   else  : mac = self.VVaKxu.lower()
   macUtf8 = mac.encode('utf-8')
   sn = hashlib.md5(macUtf8).hexdigest().upper()[:13]
   Id = hashlib.sha256(macUtf8).hexdigest().upper()
   sig = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % Id
   param += "&device_id2=%s" % Id
   param += "&signature=%s" % sig
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVaKxu, sn, self.portal_moreAuthRand)
  else:
   param = ""
  return self.VVtEuk() + "type=stb&action=get_profile" + param
 def VVCxXR(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVFDmW()
  if len(rows) < 10:
   rows = self.VVOstX()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVnccW ))
   rows.append(("MAC (from URL)" , self.VVaKxu ))
   rows.append(("Token"   , self.VVPf2X ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVaKxu ))
   rows.append(("2", self.colored_server, "Host" , self.VVnccW ))
   rows.append(("2", self.colored_server, "Token" , self.VVPf2X ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVk0Cg(self, isPhp=True, VVztK4=False):
  token, profile, tErr = self.VVoAYP(VVztK4)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVUkRp()
  res, err = self.VVoyfY(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCfMBx.VV7oGw(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFu3Zi(span.group(2))
     pass1 = FFu3Zi(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVFDmW(self):
  m3u_Url, err = self.VVk0Cg()
  rows = []
  if m3u_Url:
   res, err = self.VVoyfY(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFIb5k(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFIb5k(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVOstX(self):
  token, profile, tErr = self.VVoAYP()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFX8xo(val): val = FFJ3Mw(val.decode("UTF-8"))
     else     : val = self.VVaKxu
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFIb5k(int(parts[1]))
      if parts[2] : ends = FFIb5k(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFIb5k(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVpRwI(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVoAYP(VVztK4=False)
  if not token:
   return ""
  crLinkUrl = self.VViLA6(mode, chCm, epNum, epId)
  res, err = self.VVoyfY(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCfMBx.VV7oGw(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVtEuk(self):
  return self.VVnccW + "/server/load.php?"
 def VV1yVj(self):
  return self.VVtEuk() + "type=stb&action=handshake&token=&mac=%s" % self.VVaKxu
 def VV1FdD(self, mode):
  url = self.VVtEuk() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVHL2L(self, catID):
  return self.VVtEuk() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVxLIi(self, mode, catID, page):
  url = self.VVtEuk() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVwPBJ(self, mode, searchName, page):
  return self.VVtEuk() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVF2FF(self, mode, catID):
  return self.VVtEuk() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VViLA6(self, mode, chCm, serCode, serId):
  url = self.VVtEuk() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVUkRp(self):
  return self.VVtEuk() + "type=itv&action=create_link"
 def VV4JLB(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV1MBM(catID, stID, chNum)
  query = self.VVw290(mode, FF1YU5(host), FF1YU5(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVw290(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVqaCG(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVw290(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFJ3Mw(host)
  mac   = FFJ3Mw(mac)
  valid = False
  if self.VVK8Dc(playHost) and self.VVK8Dc(host) and self.VVK8Dc(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVoyfY(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CC1ywg.VV4p8EHeader()
   if self.VVPf2X:
    headers["Authorization"] = "Bearer %s" % self.VVPf2X
   if useCookies : cookies = {"mac": self.VVaKxu, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVjMyK(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CC1ywg.VV4p8EHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VV4p8EHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVTBOE(host, mac, tType, action, keysList=[]):
  myPortal = CC1ywg()
  ok = myPortal.VVFpY6(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVoAYP(VVztK4=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVoyfY(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV3AD7(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV3AD7(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVztK4or(self, err, title="Portal Browser"):
  FFikHE(self, str(err), title=title)
 def VVVCNc(self, mode):
  if   mode in ("itv"  , CCfMBx.VVmTKI , CCfMBx.VV204C)  : return "Live"
  elif mode in ("vod"  , CCfMBx.VVVm1a , CCfMBx.VVpewk)  : return "VOD"
  elif mode in ("series" , CCfMBx.VVcbkF , CCfMBx.VV33vV) : return "Series"
  else                          : return "IPTV"
 def VVU3tK(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVVCNc(mode), searchName)
 def VVcS38(self, catchup=False):
  VVRj9e = []
  VVRj9e.append(("Live"    , "live"  ))
  VVRj9e.append(("VOD"    , "vod"   ))
  VVRj9e.append(("Series"   , "series"  ))
  if catchup:
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Catchup TV" , "catchup"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Account Info." , "accountInfo" ))
  return VVRj9e
 @staticmethod
 def VVKjCW(decodedUrl):
  m3u_Url = ""
  p = CC1ywg()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVqaCG(decodedUrl)
  if valid:
   ok = p.VVFpY6(host, mac, VVztK4=False)
   if ok:
    m3u_Url, err = p.VVk0Cg(isPhp=False, VVztK4=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VV3YGN(decodedUrl):
  p = CC1ywg()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVqaCG(decodedUrl)
  if valid:
   if CC1ywg.VV8WK4(chCm):
    return FFRmmV(chCm)
   else:
    ok = p.VVFpY6(host, mac, VVztK4=False)
    if ok:
     try:
      chUrl = p.VVpRwI(mode, chCm, epNum, epId)
      return FFRmmV(chUrl)
     except Exception as e:
      pass
  return ""
 @staticmethod
 def VV8WK4(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCHhYj(CC1ywg):
 def __init__(self):
  CC1ywg.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVsN6j(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVqaCG(decodedUrl)
  if valid:
   if self.VVFpY6(host, mac, VVztK4=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVGTfM(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVpRwI(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CC1ywg.VV8WK4(self.chCm):
   chUrl = FFRmmV(self.chCm)
   chUrl = FFu3Zi(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   chUrl += "?"
   isDirect = True
  elif "ffrt" in self.chCm:
   chUrl = chUrl.replace("ffrt ", "")
   chUrl = FFRmmV(chUrl)
   chUrl = FFu3Zi(chUrl)
   chUrl = chUrl.replace("%253a", "%3a")
   chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVzize(chUrl)
  if newIptvRef:
   success = self.VVJTCp(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFZXnt(passedSELF, newIptvRef, VVPUAy=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFZXnt(self, newIptvRef, VVPUAy=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVzize(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVJTCp(self, oldCode, newCode, isDirect):
  bPath = FFoikP()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FFwZqG(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFVzbz()
       return True
   else:
    txt = FFBgGE(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFVzbz()
     return True
  return False
class CC4PgF(CCHhYj):
 def __init__(self, passedSession):
  CCHhYj.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVQEcR, iPlayableService.evEOF: self.VVD7y9, iPlayableService.evEnd: self.VVmYwW})
  except:
   pass
 def VVQEcR(self):
  self.starttime = iTime()
 def VVD7y9(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self.passedSession, isFromSession=True)
    if iptvRef and not FFKi35(decodedUrl):
     span = iSearch(r"(mode=itv.+end=)", decodedUrl, IGNORECASE)
     if span:
      self.isFromEOF = True
     CCQGI5(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVmYwW(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVTQHE)
  except:
   self.timer1.callback.append(self.VVTQHE)
  self.timer1.start(100, True)
 def VVTQHE(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVsN6j(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCxKzH.VVGchH:
       self.isFromEOF = False
       self.VVGTfM(self.passedSession, isFromSession=True)
class CCT9pC():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*[\[(|:].{1,5}[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VVysIp and not VVodPD
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVMrdo(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCfMBx.VV5Hng(name):
   return CCfMBx.VVpXEP(name)
  name = self.VVzXw4(name)
  return name.strip() or name
 def VVzXw4(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2)
  return name
 def VVltu3(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVzXw4(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVmmRr(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVi45R(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVOl2R(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCAvMQ(CC1ywg):
 def __init__(self):
  CC1ywg.__init__(self)
 def VVpfZm(self):
  if CCAvMQ.VVJdIu(self):
   FFjNEj(self, self.VV8TTs, title="Searching ...")
 def VVVfnf(self, winSession, url, mac):
  if CCAvMQ.VVJdIu(self):
   if self.VVFpY6(url, mac):
    FFjNEj(winSession, self.VVmQHH, title="Checking Server ...")
   else:
    FFikHE(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV8TTs(self):
  path = CCfMBx.VVRRDc()
  lines = FF6vhB('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FF85RC(1)))
  if lines:
   lines.sort()
   VVRj9e = []
   for line in lines:
    VVRj9e.append((line, line))
   OKBtnFnc  = self.VV0Wi9
   VVr5GC = ("Delete File", self.VVbaLI)
   FFLATx(self, None, title="Select Portals File", VVRj9e=VVRj9e, width=1200, OKBtnFnc=OKBtnFnc, VVr5GC=VVr5GC)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFikHE(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVbaLI(self, VVq5cQObj, path):
  FF2QoN(self, boundFunction(self.VVqvrG, VVq5cQObj, path), "Delete this file ?\n\n%s" % path)
 def VVqvrG(self, VVq5cQObj, path):
  os.system(FFH6kH("rm -f '%s'" % path))
  if fileExists(path) : FFNWTN(VVq5cQObj, "Not deleted", 1000)
  else    : VVq5cQObj.VVsgrR()
 def VV0Wi9(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCIa4v.VVvRi6(path, self)
   if enc == -1:
    return
   self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVxfIR, path, enc)
       , VVl0w9 = boundFunction(self.VVZ3b4, menuInstance, path))
 def VVxfIR(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVeQL2(totLines)
  progBarObj.VVXjH0 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVxenn(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVK8Dc(url)
     mac  = self.VVfsMQ(mac)
     if host and mac and progBarObj:
      progBarObj.VVXjH0.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVK8Dc(url)
      mac  = self.VVfsMQ(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVXjH0.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVZ3b4(self, menuInstance, path, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVXjH0:
   VV9OiG  = ("Home Menu", FFNnw3, [])
   VVodFz  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVM10w = ("Edit File" , boundFunction(self.VVNAZ7, path) , [])
   VVSYUp = ("Open as M3U", self.VVsth2     , [])
   VVOrFX  = ("Select"  , self.VVVfnf_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVujrY  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVzpqh = FFxW7z(self, None, title=title, header=header, VV9o2E=VVXjH0, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz, VVSYTz="#0a001122", VV8c5A="#0a001122", VVn7jC="#0a001122", VVQceP="#00004455", VV2gSR="#0a333333", VV3wi4="#11331100", VVvdC4=True, searchCol=1)
   if not VVfloe:
    FFNWTN(VVzpqh, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVfloe:
    FFikHE(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVsth2(self, VVzpqh, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFjNEj(VVzpqh, boundFunction(self.VVuxW0, VVzpqh, host, mac), title="Checking Server ...")
 def VVuxW0(self, VVzpqh, host, mac):
  p = CC1ywg()
  m3u_Url = ""
  ok = p.VVFpY6(host, mac, VVztK4=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVk0Cg(VVztK4=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVFlgt(title, m3u_Url)
  else:
   FFikHE(self, err or "No response from Server !", title=title)
 def VVVfnf_fromMacFiles(self, VVzpqh, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVVfnf(VVzpqh, url, mac)
 def VVNAZ7(self, path, VVzpqh, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC4vHM(self, path, VVl0w9=boundFunction(self.VVJGuK, VVzpqh), curRowNum=rowNum)
  else    : FF9mKB(self, path)
 def VVLmb5(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFJ3Mw(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVmQHH(self):
  token, profile, tErr = self.VVoAYP()
  if token:
   dots = "." * self.portal_moreAuthType
   VVRj9e  = self.VVcS38()
   OKBtnFnc = self.VVYJHI
   VV5GJ7 = ("Home Menu", FFNnw3)
   VVBBKW = ("Bookmark Server", boundFunction(CCfMBx.VVGG3r, self, True, self.VVnccW + "\t" + self.VVaKxu))
   FFLATx(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVaKxu, dots), VVRj9e=VVRj9e, OKBtnFnc=OKBtnFnc, VV5GJ7=VV5GJ7, VVBBKW=VVBBKW)
 def VVYJHI(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFjNEj(menuInstance, boundFunction(self.VVGAaC, mode), title="Reading Categories ...")
   else : FFjNEj(menuInstance, boundFunction(self.VVnU1r, menuInstance, title), title="Reading Account ...")
 def VVnU1r(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVCxXR(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVaKxu)
  VV9OiG  = ("Home Menu" , FFNnw3            , [])
  VVSYUp  = None
  if VVDzaH:
   VVSYUp = ("Get JS"  , boundFunction(self.VVSjDf, self.VVnccW) , [])
  if totCols == 2:
   VVodFz = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVodFz = ("More Info.", boundFunction(self.VVfdvt, menuInstance) , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFxW7z(self, None, title=title, width=1200, header=header, VV9o2E=rows, VVec0v=widths, VVfhdd=26, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVodFz=VVodFz, VVSYTz="#0a00292B", VV8c5A="#0a002126", VVn7jC="#0a002126", VVQceP="#00000000", searchCol=searchCol)
 def VVSjDf(self, url, VVzpqh, title, txt, colList):
  FFjNEj(VVzpqh, boundFunction(self.VVlY5U, url), title="Getting JS ...")
 def VVlY5U(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VVoyfY("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VVoyfY("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFCsft(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VVfdvt(self, menuInstance, VVzpqh, title, txt, colList):
  VVzpqh.cancel()
  FFjNEj(menuInstance, boundFunction(self.VVnU1r, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVGAaC(self, mode):
  token, profile, tErr = self.VVoAYP()
  if not token:
   return
  res, err = self.VVoyfY(self.VV1FdD(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCT9pC()
     chList = tDict["js"]
     for item in chList:
      Id   = CCfMBx.VV7oGw(item, "id"       )
      Title  = CCfMBx.VV7oGw(item, "title"      )
      censored = CCfMBx.VV7oGw(item, "censored"     )
      Title = processChanName.VVmmRr(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVDzaH:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVVCNc(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM(mode)
   mName = self.VVVCNc(mode)
   VVOrFX   = ("Show List"   , boundFunction(self.VVWM3y, mode) , [])
   VV9OiG  = ("Home Menu"   , FFNnw3         , [])
   if mode in ("vod", "series"):
    VVM10w = ("Find in %s" % mName , boundFunction(self.VV1oTQ, mode), [])
   else:
    VVM10w = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFxW7z(self, None, title=title, width=1200, header=header, VV9o2E=list, VVec0v=widths, VVfhdd=30, VV9OiG=VV9OiG, VVM10w=VVM10w, VVOrFX=VVOrFX, VVSYTz=VVSYTz, VV8c5A=VV8c5A, VVn7jC=VVn7jC, VVQceP=VVQceP)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FFikHE(self, txt, title=title)
 def VVjLsH(self, mode, VVzpqh, title, txt, colList):
  FFjNEj(VVzpqh, boundFunction(self.VV93a5, mode, VVzpqh, title, txt, colList), title="Downloading ...")
 def VV93a5(self, mode, VVzpqh, title, txt, colList):
  token, profile, tErr = self.VVoAYP()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVoyfY(self.VVHL2L(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCfMBx.VV7oGw(item, "id"    )
      actors   = CCfMBx.VV7oGw(item, "actors"   )
      added   = CCfMBx.VV7oGw(item, "added"   )
      age    = CCfMBx.VV7oGw(item, "age"   )
      category_id  = CCfMBx.VV7oGw(item, "category_id" )
      description  = CCfMBx.VV7oGw(item, "description" )
      director  = CCfMBx.VV7oGw(item, "director"  )
      genres_str  = CCfMBx.VV7oGw(item, "genres_str"  )
      name   = CCfMBx.VV7oGw(item, "name"   )
      path   = CCfMBx.VV7oGw(item, "path"   )
      screenshot_uri = CCfMBx.VV7oGw(item, "screenshot_uri" )
      series   = CCfMBx.VV7oGw(item, "series"   )
      cmd    = CCfMBx.VV7oGw(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVOrFX  = ("Play"    , boundFunction(self.VVpCqg, mode)       , [])
   VVEJ7p = (""     , boundFunction(self.VV0jkK, mode)     , [])
   VV9OiG = ("Home Menu"   , FFNnw3               , [])
   VVSYUp = ("Download Options" , boundFunction(self.VVsLcU, mode, "sp", seriesName) , [])
   VVM10w = ("Options" , boundFunction(self.VV9DLg, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVujrY  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFxW7z(self, None, title=seriesName, width=1200, header=header, VV9o2E=list, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVSYTz="#0a00292B", VV8c5A="#0a002126", VVn7jC="#0a002126", VVQceP="#00000000")
  else:
   FFikHE(self, "Could not get Episodes from server!", title=seriesName)
 def VV1oTQ(self, mode, VVzpqh, title, txt, colList):
  VVRj9e = []
  VVRj9e.append(("Keyboard"  , "manualEntry"))
  VVRj9e.append(("From Filter" , "fromFilter"))
  FFLATx(self, boundFunction(self.VVbJyL, VVzpqh, mode), title="Input Type", VVRj9e=VVRj9e, width=400)
 def VVbJyL(self, VVzpqh, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFJeIH(self, boundFunction(self.VVHz34, VVzpqh, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC1WKO(self)
    filterObj.VV6HGH(boundFunction(self.VVHz34, VVzpqh, mode))
 def VVHz34(self, VVzpqh, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVU3tK(mode, searchName)
   if len(searchName) < 3:
    FFikHE(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCT9pC()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVi45R([searchName]):
     FFikHE(self, processChanName.VVOl2R(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVFRtz(mode, searchName, "", searchName)
 def VVWM3y(self, mode, VVzpqh, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVFRtz(mode, bName, catID, "")
 def VVFRtz(self, mode, bName, catID, searchName):
  self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVtRep, mode, bName, catID, searchName)
      , VVl0w9 = boundFunction(self.VVa4fv, mode, bName, catID, searchName))
 def VVa4fv(self, mode, bName, catID, searchName, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVU3tK(mode, searchName)
  else   : title = "%s : %s" % (self.VVVCNc(mode), bName)
  if VVXjH0:
   VVSYUp = None
   VVM10w = None
   if mode == "series":
    VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM("series2")
    VVOrFX  = ("Episodes", boundFunction(self.VVjLsH, mode) , [])
   else:
    VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM("")
    VVOrFX  = ("Play"    , boundFunction(self.VVpCqg, mode)           , [])
    VVSYUp = ("Download Options" , boundFunction(self.VVsLcU, mode, "vp" if mode == "vod" else "", "") , [])
    VVM10w = ("Options"   , boundFunction(self.VV9DLg, 1, "pCh", mode, bName)      , [])
   VVEJ7p = (""      , boundFunction(self.VVomEh, mode)          , [])
   VV9OiG = ("Home Menu"    , FFNnw3                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVujrY  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVzpqh = FFxW7z(self, None, title=title, header=header, VV9o2E=VVXjH0, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVSYTz=VVSYTz, VV8c5A=VV8c5A, VVn7jC=VVn7jC, VVQceP=VVQceP, VVvdC4=True, searchCol=1)
   if not VVfloe:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVzpqh.VVjgkZ(VVzpqh.VVPsg7() + tot)
    if threadErr: FFNWTN(VVzpqh, "Error while reading !", 2000)
    else  : FFNWTN(VVzpqh, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFikHE(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFikHE(self, "Could not get list from server !", title=title)
 def VVomEh(self, mode, VVzpqh, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFgBdr(self, fncMode=CCR0BS.VVGTvQ, portalHost=self.VVnccW, portalMac=self.VVaKxu, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVLum5(mode, VVzpqh, title, txt, colList)
 def VV0jkK(self, mode, VVzpqh, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFhTMc(colList[10], VVyTfh)
  txt += "Description:\n%s" % FFhTMc(colList[11], VVyTfh)
  self.VVLum5(mode, VVzpqh, title, txt, colList)
 def VVLum5(self, mode, VVzpqh, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVKXD5(mode, colList)
  refCode, chUrl = self.VV4JLB(self.VVnccW, self.VVaKxu, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFgBdr(self, fncMode=CCR0BS.VVerG0, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVtRep(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVoAYP()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVXjH0, total_items, max_page_items, err = self.VVKd8Q(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVXjH0 and total_items > -1 and max_page_items > -1:
    progBarObj.VVeQL2(total_items)
    progBarObj.VVxenn(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVKd8Q(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVlFD6()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVXjH0 += list
      progBarObj.VVxenn(len(list), True)
  except:
   pass
 def VVKd8Q(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVwPBJ(mode, searchName, page)
  else   : url = self.VVxLIi(mode, catID, page)
  res, err = self.VVoyfY(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVIsTK(CCfMBx.VV7oGw(item, "total_items" ))
     max_page_items = self.VVIsTK(CCfMBx.VV7oGw(item, "max_page_items" ))
     processChanName = CCT9pC()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCfMBx.VV7oGw(item, "id"    )
      name   = CCfMBx.VV7oGw(item, "name"   )
      o_name   = CCfMBx.VV7oGw(item, "o_name"   )
      tv_genre_id  = CCfMBx.VV7oGw(item, "tv_genre_id" )
      number   = CCfMBx.VV7oGw(item, "number"   ) or str(counter)
      logo   = CCfMBx.VV7oGw(item, "logo"   )
      screenshot_uri = CCfMBx.VV7oGw(item, "screenshot_uri" )
      cmd    = CCfMBx.VV7oGw(item, "cmd"   )
      censored  = CCfMBx.VV7oGw(item, "censored"  )
      if name == "video_name_format" and o_name:
       name = o_name
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt " in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      cmd = cmd.replace("auto ", "")
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVnccW + picon).replace(sp * 2, sp)
      counter += 1
      name = processChanName.VVMrdo(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVLNbJ(self, mode, bName, VVzpqh, title, txt, colList):
  bNameFile = CCfMBx.VVYpUo_forBouquet(bName)
  num  = 0
  path = VV9gDR + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VV9gDR + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVzpqh.VVS8vj
   for ndx, row in enumerate(VVzpqh.VVbBP2()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVKXD5(mode, row)
    refCode, chUrl = self.VV4JLB(self.VVnccW, self.VVaKxu, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVzpqh.VVS5Wm(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFpGUj(os.path.basename(path))
  self.VVHHMj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVIsTK(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVpCqg(self, mode, VVzpqh, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVKXD5(mode, colList)
  refCode, chUrl = self.VV4JLB(self.VVnccW, self.VVaKxu, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VV5Hng(chName):
   FFNWTN(VVzpqh, "This is a marker!", 300)
  else:
   FFjNEj(VVzpqh, boundFunction(self.VV2swo, mode, VVzpqh, chUrl), title="Playing ...")
 def VV2swo(self, mode, VVzpqh, chUrl):
  FFZXnt(self, chUrl, VVPUAy=False)
  self.session.open(CCxKzH, portalTableParam=(self, VVzpqh, mode))
 def VVJIvJ(self, mode, VVzpqh, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVKXD5(mode, colList)
  refCode, chUrl = self.VV4JLB(self.VVnccW, self.VVaKxu, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVKXD5(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVJdIu(SELF):
  try:
   import requests
   return True
  except:
   FF2QoN(SELF, boundFunction(CCAvMQ.VVgfz9, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVgfz9(SELF):
  from sys import version_info
  cmdUpd = FFdVFr(VVtMrS, "")
  if cmdUpd:
   cmdInst = FFq4eO(VVn4yS, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFF3Kc(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFNDX7(SELF)
class CCfMBx(Screen, CCAvMQ):
 VVuJ2M    = 0
 VV0oJQ    = 1
 VVzBSY    = 2
 VVwvnQ    = 3
 VVE2CL     = 4
 VVKCRG     = 5
 VV28fj     = 6
 VVWufy     = 7
 VVNSYZ      = 8
 VVEN9I     = 9
 VVtJ2K     = 10
 VVN7Yh     = 11
 VVKaiw     = 12
 VVOLY7      = 13
 VVad1a      = 14
 VVfkfh      = 15
 VVv97Z      = 16
 VVvbsQ      = 17
 VV3WgZ    = 0
 VVmTKI   = 1
 VVVm1a   = 2
 VVcbkF   = 3
 VVE5zN  = 4
 VVuWrC  = 5
 VV204C   = 6
 VVpewk   = 7
 VV33vV  = 8
 VVMtkp  = 9
 VVfoFc  = 10
 VVT0wc = 0
 VVXTlX = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVzpqh  = None
  self.tableTitle   = "IPTV Channels List"
  self.VV0n7FData  = {}
  self.lastFindIptvName = ""
  CCAvMQ.__init__(self)
  VVRj9e= self.VVFs0Q()
  FFpJPp(self, title="IPTV", VVRj9e=VVRj9e)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
  FF0xYi(self)
  if self.m3uOrM3u8File:
   self.VVIzID(self.m3uOrM3u8File)
 def VVFs0Q(self):
  files = self.VVaqw3()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VV0n7F_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VV0n7F_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VV0n7F_fromM3u"  ))
  qUrl, iptvRef = self.VVisWm()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VV0n7F_fromCurrChan" ))
  VVRj9e = []
  if files:
   if self.VVzpqh:
    VVRj9e.append(("Add Current List to a New Bouquet"      , "VVMoaP"  ))
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("Change Current List References to Unique Codes"   , "VVzYD6"))
    VVRj9e.append(("Change Current List References to Identical Codes"  , "VVuAyK_rows" ))
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVG2QW"   ))
    VVRj9e.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVIjj6"   ))
   else:
    VVRj9e += tList
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("M3U/M3U8 Channels Browser"        , "VV3GiF"   ))
    VVRj9e.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVRj9e.append(VVmGWQ)
     VVRj9e.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("Count Available IPTV Channels"       , "VVyo4h"    ))
    VVRj9e.append(("Check Reference Codes Format"        , "VV1iQD"   ))
    VVRj9e.append(("Check System Acceptable Reference Types"     , "VVdojG"   ))
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VV5ynI" ))
    VVRj9e.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVt7k0"  ))
    VVRj9e.append(("Change ALL References to Unique Codes"     , "VVGdGd" ))
    VVRj9e.append(("Change ALL References to Identical Codes"     , "VVuAyK_all" ))
  if not self.VVzpqh:
   if not files:
    VVRj9e += tList
   if not CCtZ0M.VVvkan():
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("Download Manager"           , "dload_stat"    ))
  return VVRj9e
 def VVR7js(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVMoaP"   : FFJeIH(self, self.VVMoaP, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVzYD6" : FF2QoN(self, boundFunction(FFjNEj, self.VVzpqh, self.VVzYD6 ), "Change Current List References to Unique Codes ?")
   elif item == "VVuAyK_rows" : FF2QoN(self, boundFunction(FFjNEj, self.VVzpqh, self.VVuAyK   ), "Change Current List References to Identical Codes ?")
   elif item == "VVG2QW"   : self.VVG2QW(tTitle)
   elif item == "VVIjj6"   : self.VVIjj6(tTitle)
   elif item == "VV0n7F_fromPlayList" : FFjNEj(self, self.VVB4Nm, title=title)
   elif item == "VV0n7F_fromM3u"  : FFjNEj(self, boundFunction(self.VVk9Iy, 0), title=title)
   elif item == "VV0n7F_fromMac"  : self.VVpfZm()
   elif item == "VV0n7F_fromCurrChan" : self.VVVfnf_fromCurrChan()
   elif item == "VV3GiF"   : self.VV3GiF()
   elif item == "iptvTable_live"   : FFjNEj(self, boundFunction(self.VVVbu4, self.VVWufy ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFjNEj(self, boundFunction(self.VVVbu4, self.VVuJ2M) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVxCpT()
   elif item == "VVyo4h"    : FFjNEj(self, self.VVyo4h)
   elif item == "VV1iQD"    : FFjNEj(self, self.VV1iQD)
   elif item == "VVdojG"   : FFjNEj(self, self.VVdojG)
   elif item == "VV5ynI"  : FF2QoN(self, boundFunction(FFjNEj, self, self.VV5ynI ), "Continue ?")
   elif item == "VVt7k0"  : self.VVt7k0()
   elif item == "VVGdGd" : FF2QoN(self, boundFunction(FFjNEj, self, self.VVGdGd ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVuAyK_all" : FF2QoN(self, boundFunction(FFjNEj, self, self.VVuAyK  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCtZ0M.VVBGzA(self)
   elif item == "VVmT8a"   : FFjNEj(self, boundFunction(CCAzDv.VVmT8a, self))
 def VV3GiF(self):
  if CCAvMQ.VVJdIu(self):
   FFjNEj(self, boundFunction(self.VVk9Iy, 1), title="Searching ...")
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVR7js(item)
 def VVVbu4(self, mode):
  VV16hm = self.VV33xi(mode)
  if VV16hm:
   VVSYUp = ("Current Service", self.VVYnaY  , [])
   VVM10w = ("Options"  , self.VVcOEr    , [])
   VVodFz = ("Filter"   , self.VV4hxx    , [])
   VVOrFX  = ("Play"   , boundFunction(self.VV4N1Y) , [])
   VVEJ7p = (""    , self.VVz10P     , [])
   VVXhFg = (""    , self.VVstws      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVujrY  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFxW7z(self, None, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26
     , VVOrFX=VVOrFX, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz, VVEJ7p=VVEJ7p, VVXhFg=VVXhFg
     , VVSYTz="#0a00292B", VV8c5A="#0a002126", VVn7jC="#0a002126", VVQceP="#00000000", VVvdC4=True, searchCol=1)
  else:
   if mode == self.VVWufy: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFikHE(self, err)
 def VVstws(self, VVzpqh, title, txt, colList):
  self.VVzpqh = VVzpqh
 def VVcOEr(self, VVzpqh, title, txt, colList):
  VVRj9e= self.VVFs0Q()
  FFLATx(self, self.VVR7js, title="IPTV Tools", VVRj9e=VVRj9e)
 def VV4hxx(self, VVzpqh, title, txt, colList):
  VVRj9e = []
  VVRj9e.append(("All"         , "all"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Prefix of Selected Channel"   , "sameName" ))
  VVRj9e.append(("Suggest Words from Selected Channel" , "partName" ))
  VVRj9e.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Live TV"        , "live"  ))
  VVRj9e.append(("VOD"         , "vod"   ))
  VVRj9e.append(("Series"        , "series"  ))
  VVRj9e.append(("Uncategorised"      , "uncat"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Video"        , "video"  ))
  VVRj9e.append(("Audio"        , "audio"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("MKV"         , "MKV"   ))
  VVRj9e.append(("MP4"         , "MP4"   ))
  VVRj9e.append(("MP3"         , "MP3"   ))
  VVRj9e.append(("AVI"         , "AVI"   ))
  VVRj9e.append(("FLV"         , "FLV"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VV4ume()
  if bNames:
   bNames.sort()
   VVRj9e.append(VVmGWQ)
   for item in bNames:
    VVRj9e.append((item, "__b__" + item))
  filterObj = CC1WKO(self)
  filterObj.VVKROE(VVRj9e, VVRj9e, boundFunction(self.VVDBXw, VVzpqh))
 def VVDBXw(self, VVzpqh, item=None):
  prefix = VVzpqh.VVhJrx(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVuJ2M, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV0oJQ , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVzBSY , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVwvnQ , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVWufy  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVNSYZ   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVEN9I  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVtJ2K  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVN7Yh  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVKaiw  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVOLY7   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVad1a   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVfkfh   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVv97Z   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVvbsQ   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VV28fj  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVE2CL  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVKCRG  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVzBSY:
   VVRj9e = []
   chName = VVzpqh.VVhJrx(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVRj9e.append((item, item))
    if not VVRj9e and chName:
     VVRj9e.append((chName, chName))
    FFLATx(self, boundFunction(self.VVygmE_partOfName, title), title="Words from Current Selection", VVRj9e=VVRj9e)
   else:
    VVzpqh.VVjkTY("Invalid Channel Name")
  else:
   words, asPrefix = CC1WKO.VVYNyo(words)
   if not words and mode in (self.VVE2CL, self.VVKCRG):
    FFNWTN(self.VVzpqh, "Incorrect filter", 2000)
   else:
    FFjNEj(self.VVzpqh, boundFunction(self.VV6Lcp, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVygmE_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFjNEj(self.VVzpqh, boundFunction(self.VV6Lcp, self.VVzBSY, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVpXEP(txt):
  return "#f#11ffff00#" + txt
 def VV6Lcp(self, mode, words, asPrefix, title):
  VV16hm = self.VV33xi(mode=mode, words=words, asPrefix=asPrefix)
  if VV16hm : self.VVzpqh.VVgYkt(VV16hm, title)
  else  : self.VVzpqh.VVjkTY("Not found")
 def VV33xi(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV16hm = []
  files  = self.VVaqw3()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFBgGE(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVibEg = span.group(1)
    else : VVibEg = ""
    VVibEg_lCase = VVibEg.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV5Hng(chName): chNameMod = self.VVpXEP(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVibEg, chType, refCode, url)
     ok = False
     tUrl = FFRmmV(url).lower()
     if mode == self.VVuJ2M       : ok = True
     elif mode == self.VV28fj       : ok = True
     elif mode == self.VVN7Yh:
      if CCfMBx.VVTzl0(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVKaiw:
      if CCfMBx.VVTzl0(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVWufy:
      if CCfMBx.VVTzl0(tUrl, compareType="live")  : ok = True
     elif mode == self.VVNSYZ:
      if CCfMBx.VVTzl0(tUrl, compareType="movie") : ok = True
     elif mode == self.VVEN9I:
      if CCfMBx.VVTzl0(tUrl, compareType="series") : ok = True
     elif mode == self.VVtJ2K:
      if CCfMBx.VVTzl0(tUrl, compareType="")   : ok = True
     elif mode == self.VVOLY7:
      if CCfMBx.VVTzl0(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVad1a:
      if CCfMBx.VVTzl0(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVfkfh:
      if CCfMBx.VVTzl0(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVv97Z:
      if CCfMBx.VVTzl0(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVvbsQ:
      if CCfMBx.VVTzl0(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VV0oJQ:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVzBSY:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVwvnQ:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVE2CL:
      if words[0] == VVibEg_lCase:
       ok = True
     elif mode == self.VVKCRG:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV16hm.append(row)
      chNum += 1
  if VV16hm and mode == self.VV28fj:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV16hm)
   for item in VV16hm:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV16hm = newRows
  return VV16hm
 def VVMoaP(self, bName):
  if bName:
   FFjNEj(self.VVzpqh, boundFunction(self.VV5dis, bName), title="Adding Channels ...")
 def VV5dis(self, bName):
  num = 0
  path = VV9gDR + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VV9gDR + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVzpqh.VVbBP2():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFz82T(row[1]))
    totChange += 1
  FFpGUj(os.path.basename(path))
  self.VVHHMj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVt7k0(self):
  txt = "Stream Type "
  VVRj9e = []
  VVRj9e.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVRj9e.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVRj9e.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVRj9e.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVRj9e.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVRj9e.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFLATx(self, self.VVPoBQ, title="Change Reference Types to:", VVRj9e=VVRj9e)
 def VVPoBQ(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVfZ3r("1"   )
   elif item == "RT_4097" : self.VVfZ3r("4097")
   elif item == "RT_5001" : self.VVfZ3r("5001")
   elif item == "RT_5002" : self.VVfZ3r("5002")
   elif item == "RT_8192" : self.VVfZ3r("8192")
   elif item == "RT_8193" : self.VVfZ3r("8193")
 def VVfZ3r(self, rType):
  FF2QoN(self, boundFunction(FFjNEj, self, boundFunction(self.VVYhNj, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVYhNj(self, refType):
  totChange = 0
  files  = self.VVaqw3()
  if files:
   for path in files:
    txt = FFBgGE(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFpGUj(os.path.basename(path))
  self.VVHHMj(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVyo4h(self):
  totFiles = 0
  files  = self.VVaqw3()
  if files:
   totFiles = len(files)
  totChans = 0
  VV16hm = self.VV33xi()
  if VV16hm:
   totChans = len(VV16hm)
  FFCsft(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV1iQD(self):
  files  = self.VVaqw3()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFBgGE(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV4U0A
   else    : color = VVtODU
   totInvalid = FFhTMc(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFhTMc("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFCsft(self, txt, title="Check IPTV References")
 def VVdojG(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VV9gDR + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFpGUj(os.path.basename(path))
  FFVzbz()
  acceptedList = []
  VVuC0v = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVuC0v:
   VVp1ZK = FFb1PG(VVuC0v)
   if VVp1ZK:
    for service in VVp1ZK:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VV9gDR + userBName
  bFile = VV9gDR + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFH6kH("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFH6kH("rm -f '%s'" % path)
  os.system(cmd)
  FFVzbz()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV4U0A
    else     : res, color = "No" , VVtODU
    txt += "    %s\t: %s\n" % (item, FFhTMc(res, color))
   FFCsft(self, txt, title=title)
  else:
   txt = FFikHE(self, "Could not complete the test on your system!", title=title)
 def VV5ynI(self):
  lameDbChans = CCAzDv.VVRwNz(self, CCAzDv.VViT51)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVaqw3():
    toSave = False
    txt = FFBgGE(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVHHMj(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFikHE(self, 'No channels in "lamedb" !')
 def VVGdGd(self):
  files  = self.VVaqw3()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFwZqG(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVYvAY(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVHHMj(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVzYD6(self):
  iptvRefList = []
  files  = self.VVaqw3()
  if files:
   for path in files:
    txt = FFBgGE(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVzpqh.VVjZj8(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVYvAY(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVaqw3()
  if files:
   for path in files:
    lines = FFwZqG(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVHHMj(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVYvAY(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVuAyK(self):
  list = None
  if self.VVzpqh:
   list = []
   for row in self.VVzpqh.VVbBP2():
    list.append(row[4] + row[5])
  files  = self.VVaqw3()
  totChange = 0
  if files:
   for path in files:
    lines = FFwZqG(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVHHMj(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVHHMj(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFVzbz()
   if refreshTable and self.VVzpqh:
    VV16hm = self.VV33xi()
    if VV16hm and self.VVzpqh:
     self.VVzpqh.VVgYkt(VV16hm, self.tableTitle)
     self.VVzpqh.VVjkTY(txt)
   FFCsft(self, txt, title=title)
  else:
   FF7k8q(self, "No changes.")
 def VV4ume(self):
  files = self.VVaqw3()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVuDQ1 = FFylDs()
    if VVuDQ1:
     for b in VVuDQ1:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVaqw3(self):
  return CCfMBx.VVA7dS(self)
 @staticmethod
 def VVA7dS(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VV9gDR + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFBgGE(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVz10P(self, VVzpqh, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFRmmV(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFgBdr(self, fncMode=CCR0BS.VVMXLh, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVJ4vJ(self, VVzpqh, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VV4N1Y(self, VVzpqh, title, txt, colList):
  chName, chUrl = self.VVJ4vJ(VVzpqh, colList)
  self.VV0RCN(VVzpqh, chName, chUrl, "localIptv")
 def VVi9TO(self, mode, VVzpqh, colList):
  chName, chUrl, picUrl, refCode = self.VV1C5c(mode, colList)
  return chName, chUrl
 def VV2g0M(self, mode, VVzpqh, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV1C5c(mode, colList)
  self.VV0RCN(VVzpqh, chName, chUrl, mode)
 def VV0RCN(self, VVzpqh, chName, chUrl, playerFlag):
  chName = FFz82T(chName)
  if self.VV5Hng(chName):
   FFNWTN(VVzpqh, "This is a marker!", 300)
  else:
   FFjNEj(VVzpqh, boundFunction(self.VVCzqN, VVzpqh, chUrl, playerFlag), title="Playing ...")
 def VVCzqN(self, VVzpqh, chUrl, playerFlag):
  FFZXnt(self, chUrl, VVPUAy=False)
  self.session.open(CCxKzH, portalTableParam=(self, VVzpqh, playerFlag))
 @staticmethod
 def VV5Hng(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVYnaY(self, VVzpqh, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  if refCode:
   bName = FFqa4x()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FF301l(refCode, origUrl, chName) }
   VVzpqh.VVSEni_partial(colDict, VVztK4=True)
 def VVk9Iy(self, m3uMode):
  path = CCfMBx.VVRRDc()
  lines = FF6vhB("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FF85RC(1)))
  if lines:
   lines.sort()
   VVRj9e = []
   for line in lines:
    VVRj9e.append((line, line))
   if m3uMode == self.VVT0wc:
    title = "Browse Server from M3U URLs"
    VVBBKW = ("All to Playlist", self.VVLNyG)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVBBKW = None
   OKBtnFnc = boundFunction(self.VV2FTv, m3uMode, title)
   VVrdmH  = ("Show Full Path", self.VVCHwx)
   VVr5GC = ("Delete File", self.VVbaLI)
   FFLATx(self, None, title=title, VVRj9e=VVRj9e, width=1200, OKBtnFnc=OKBtnFnc, VVrdmH=VVrdmH, VVr5GC=VVr5GC, VVBBKW=VVBBKW)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFikHE(self, 'No ".m3u" files found %s' % txt)
 def VVCHwx(self, VVq5cQObj, url):
  FFCsft(self, url, title="Full Path")
 def VV2FTv(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVT0wc:
    FFjNEj(menuInstance, boundFunction(self.VV3DB7, title, path))
   else:
    FFjNEj(menuInstance, boundFunction(self.VVIzID, path))
 def VVIzID(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFBgGE(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCT9pC()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVD6bm(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVMrdo(group):
    groups.add(group)
  VV16hm = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV16hm.append((group, group))
   VV16hm.append(("ALL", ""))
   VV16hm.sort(key=lambda x: x[0].lower())
   VVQOfi = self.VVZBd3
   VVOrFX  = ("Select" , boundFunction(self.VV6Jcp, srcPath), [])
   widths   = (100  , 0)
   VVujrY  = (LEFT  , LEFT)
   FFxW7z(self, None, title=title, width= 800, header=None, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=30, VVOrFX=VVOrFX, VVQOfi=VVQOfi
     , VVSYTz="#11110022", VV8c5A="#11110022", VVn7jC="#11110022", VVQceP="#00444400")
  else:
   txt = FFBgGE(srcPath)
   self.VVCrfZ(txt, filterGroup="")
 def VV6Jcp(self, srcPath, VVzpqh, title, txt, colList):
  group = colList[1]
  txt = FFBgGE(srcPath)
  self.VVCrfZ(txt, filterGroup=group)
 def VVCrfZ(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVSa6w, lst, filterGroup)
       , VVl0w9 = boundFunction(self.VVAzyz, title, bName))
  else:
   self.VV5qW8("No valid lines found !", title)
 def VVSa6w(self, lst, filterGroup, progBarObj):
  progBarObj.VVXjH0 = []
  progBarObj.VVeQL2(len(lst))
  processChanName = CCT9pC()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVxenn(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVD6bm(propLine, "tvg-logo")
   group = self.VVD6bm(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVMrdo(group) : skip = True
    if chName and not processChanName.VVMrdo(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVXjH0.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VV5AWx_forcedUpdate("Loading %d Channels" % len(progBarObj.VVXjH0))
 def VVAzyz(self, title, bName, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  if VVXjH0:
   VVQOfi = self.VVZBd3
   VVOrFX  = ("Select"    , boundFunction(self.VVBxXG, title) , [])
   VVEJ7p = (""     , self.VV5qlB         , [])
   VVSYUp = ("Download PIcons" , self.VVOA22        , [])
   VVM10w = ("Options" , boundFunction(self.VV9DLg, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVujrY  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFxW7z(self, None, title=title, header=header, VV9o2E=VVXjH0, VVujrY=VVujrY, VVec0v=widths, VVfhdd=28, VVOrFX=VVOrFX, VVQOfi=VVQOfi, VVEJ7p=VVEJ7p, VVSYUp=VVSYUp, VVM10w=VVM10w, VVvdC4=True, searchCol=1
     , VVSYTz="#0a00192B", VV8c5A="#0a00192B", VVn7jC="#0a00192B", VVQceP="#00000000")
  else:
   self.VV5qW8("No valid lines found !", title)
 def VVOA22(self, VVzpqh, title, txt, colList):
  self.VV9abi(VVzpqh, "m3u/m3u8")
 def VVuOOb(self, mode, bName, VVzpqh, title, txt, colList):
  bNameFile = CCfMBx.VVYpUo_forBouquet(bName)
  num  = 0
  path = VV9gDR + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VV9gDR + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVzpqh.VVS8vj
   for ndx, row in enumerate(VVzpqh.VVbBP2()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVUV6V(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVzpqh.VVS5Wm(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFpGUj(os.path.basename(path))
  self.VVHHMj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVUV6V(self, rowNum, url, chName):
  refCode = self.VVak2l(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFu3Zi(url), chName)
  return chUrl
 def VVak2l(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VV1MBM(catID, stID, chNum)
  return refCode
 def VVD6bm(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVBxXG(self, Title, VVzpqh, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFjNEj(VVzpqh, boundFunction(self.VVgpAI, Title, VVzpqh, colList), title="Checking Server ...")
  else:
   self.VVzhtm(VVzpqh, url, chName)
 def VVgpAI(self, title, VVzpqh, colList):
  if not CCAvMQ.VVJdIu(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CC1ywg.VVjMyK(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVRj9e = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCfMBx.VVChBV(url, fPath)
     VVRj9e.append((resol, fullUrl))
    if VVRj9e:
     if len(VVRj9e) > 1:
      FFLATx(self, boundFunction(self.VVoqKH, VVzpqh, chName), VVRj9e=VVRj9e, title="Resolution", VVhiDK=True, VVrTTp=True)
     else:
      self.VVzhtm(VVzpqh, VVRj9e[0][1], chName)
    else:
     self.VVztK4or("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVCrfZ(txt, filterGroup="")
      return
    self.VVzhtm(VVzpqh, url, chName)
   else:
    self.VV5qW8("Cannot process this channel !", title)
  else:
   self.VV5qW8(err, title)
 def VVoqKH(self, VVzpqh, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVzhtm(VVzpqh, resolUrl, chName)
 def VVzhtm(self, VVzpqh, url, chName):
  FFjNEj(VVzpqh, boundFunction(self.VVl23E, VVzpqh, url, chName), title="Playing ...")
 def VVl23E(self, VVzpqh, url, chName):
  chUrl = self.VVUV6V(VVzpqh.VVG1bP(), url, chName)
  FFZXnt(self, chUrl, VVPUAy=False)
  self.session.open(CCxKzH, portalTableParam=(self, VVzpqh, "m3u/m3u8"))
 def VVZmSe(self, VVzpqh, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVUV6V(VVzpqh.VVG1bP(), url, chName)
  return chName, chUrl
 def VV5qlB(self, VVzpqh, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFgBdr(self, fncMode=CCR0BS.VVMXLh, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VV5qW8(self, err, title):
  FFikHE(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVZBd3(self, VVzpqh):
  if self.m3uOrM3u8File:
   self.close()
  VVzpqh.cancel()
 def VVLNyG(self, VVq5cQObj, item=None):
  FFjNEj(VVq5cQObj, boundFunction(self.VVtpqr, VVq5cQObj, item))
 def VVtpqr(self, VVq5cQObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVq5cQObj.VVRj9e):
    path = item[1]
    if fileExists(path):
     enc = CCIa4v.VVvRi6(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVq9ka(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCfMBx.VVRRDc(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFOeCU())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVq5cQObj.VVRj9e)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFCsft(self, txt, title=title)
   else:
    FFikHE(self, "Could not obtain URLs from this file list !", title=title)
 def VVB4Nm(self):
  path = CCfMBx.VVRRDc()
  lines = FF6vhB('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FF85RC(1)))
  if lines:
   lines.sort()
   VVRj9e = []
   for line in lines:
    VVRj9e.append((line, line))
   OKBtnFnc  = self.VVfXw2
   VVr5GC = ("Delete File", self.VVbaLI)
   FFLATx(self, None, title="Select Playlist File", VVRj9e=VVRj9e, width=1200, OKBtnFnc=OKBtnFnc, VVr5GC=VVr5GC)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFikHE(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVfXw2(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFjNEj(menuInstance, boundFunction(self.VVkwVq, menuInstance, path), title="Processing File ...")
 def VVkwVq(self, fileMenuInstance, path):
  enc = CCIa4v.VVvRi6(path, self)
  if enc == -1:
   return
  VV16hm = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFZ2H0(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfMBx.VVKi7C(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV16hm:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV16hm.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV16hm:
   title = "Playlist File"
   VVOrFX  = ("Start"    , boundFunction(self.VVP6NR, title)  , [])
   VV9OiG = ("Home Menu"   , FFNnw3         , [])
   VVSYUp = ("Download M3U File" , self.VV2iL4     , [])
   VVM10w = ("Edit File"   , boundFunction(self.VVzgvW, path) , [])
   VVodFz = ("Check & Filter"  , boundFunction(self.VVKnBl, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVujrY  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFxW7z(self, None, title=title, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VV9OiG=VV9OiG, VVodFz=VVodFz, VVSYUp=VVSYUp, VVM10w=VVM10w, VVSYTz="#11001116", VV8c5A="#11001116", VVn7jC="#11001116", VVQceP="#00003635", VV2gSR="#0a333333", VV3wi4="#11331100", VVvdC4=True)
  else:
   FFikHE(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV2iL4(self, VVzpqh, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FF2QoN(self, boundFunction(FFjNEj, VVzpqh, boundFunction(self.VVntMx, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVntMx(self, title, url):
  path, err = FFnx0u(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFikHE(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFBgGE(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFH6kH("rm -f '%s'" % path))
    FFikHE(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFH6kH("rm -f '%s'" % path))
    FFikHE(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCfMBx.VVRRDc(orExportPath=True) + fName
    os.system(FFH6kH("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF7k8q(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFikHE(self, "Could not download the M3U file!", title=errTitle)
 def VVP6NR(self, Title, VVzpqh, title, txt, colList):
  url = colList[6]
  FFjNEj(VVzpqh, boundFunction(self.VVFlgt, Title, url), title="Checking Server ...")
 def VVzgvW(self, path, VVzpqh, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC4vHM(self, path, VVl0w9=boundFunction(self.VVJGuK, VVzpqh), curRowNum=rowNum)
  else    : FF9mKB(self, path)
 def VVJGuK(self, VVzpqh, fileChanged):
  if fileChanged:
   VVzpqh.cancel()
 def VVG2QW(self, title):
  curChName = self.VVzpqh.VVhJrx(1)
  FFJeIH(self, boundFunction(self.VVRswf, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVRswf(self, title, name):
  if name:
   lameDbChans = CCAzDv.VVRwNz(self, CCAzDv.VVLB1y, VVCLSM=False, VVgUIE=False)
   list = []
   if lameDbChans:
    processChanName = CCT9pC()
    name = processChanName.VVltu3(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFleLE(item[2]), item[3], ratio))
   if list : self.VVbO62(list, title)
   else : FFikHE(self, "Not found:\n\n%s" % name, title=title)
 def VVIjj6(self, title):
  curChName = self.VVzpqh.VVhJrx(1)
  self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVsmyo
      , VVl0w9 = boundFunction(self.VVaKPp, title, curChName))
 def VVsmyo(self, progBarObj):
  curChName = self.VVzpqh.VVhJrx(1)
  lameDbChans = CCAzDv.VVRwNz(self, CCAzDv.VVTH10, VVCLSM=False, VVgUIE=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVXjH0 = []
  progBarObj.VVeQL2(len(lameDbChans))
  processChanName = CCT9pC()
  curCh = processChanName.VVltu3(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CC0sln.VVPTz7(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVxenn(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVXjH0.append((chName, FFleLE(sat), refCode.replace("_", ":"), str(ratio)))
 def VVaKPp(self, title, curChName, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  if VVXjH0: self.VVbO62(VVXjH0, title)
  elif VVfloe: FFikHE(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVbO62(self, VV16hm, title):
  curChName = self.VVzpqh.VVhJrx(1)
  curRefCode = self.VVzpqh.VVhJrx(4)
  curUrl  = self.VVzpqh.VVhJrx(5)
  VV16hm = sorted(VV16hm, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVOrFX  = ("Share Sat/C/T Ref.", boundFunction(self.VVolO5, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFxW7z(self, None, title=title, header=header, VV9o2E=VV16hm, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVSYTz="#0a00112B", VV8c5A="#0a001126", VVn7jC="#0a001126", VVQceP="#00000000")
 def VVolO5(self, newtitle, curChName, curRefCode, curUrl, VVzpqh, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FF2QoN(self.VVzpqh, boundFunction(FFjNEj, self.VVzpqh, boundFunction(self.VVUL2K, VVzpqh, data)), ques, title=newtitle, VV9d4I=True)
 def VVUL2K(self, VVzpqh, data):
  VVzpqh.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVaqw3():
    txt = FFBgGE(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFVzbz()
    newRow = []
    for i in range(6):
     newRow.append(self.VVzpqh.VVhJrx(i))
    newRow[4] = newRefCode
    done = self.VVzpqh.VVt4Mg(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFbH1W(boundFunction(FF7k8q , self, resTxt, title=title))
  elif resErr: FFbH1W(boundFunction(FFikHE , self, resErr, title=title))
 def VVKnBl(self, fileMenuInstance, path, VVzpqh, title, txt, colList):
  self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVAW1K, VVzpqh)
      , VVl0w9 = boundFunction(self.VVxVfC, fileMenuInstance, path, VVzpqh))
 def VVAW1K(self, VVzpqh, progBarObj):
  progBarObj.VVeQL2(VVzpqh.VVYuPB())
  progBarObj.VVXjH0 = []
  for row in VVzpqh.VVbBP2():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVxenn(1, True)
   qUrl = self.VVrMuf(self.VV3WgZ, row[6])
   txt, err = self.VVlh6L(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV7oGw(item, "auth") == "0":
       progBarObj.VVXjH0.append(qUrl)
    except:
     pass
 def VVxVfC(self, fileMenuInstance, path, VVzpqh, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  if VVfloe:
   list = VVXjH0
   title = "Authorized Servers"
   if list:
    totChk = VVzpqh.VVYuPB()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFOeCU()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVB4Nm()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFhTMc(str(totAuth), VV4U0A)
     txt += "%s\n\n%s"    %  (FFhTMc("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFCsft(self, txt, title=title)
     VVzpqh.close()
     fileMenuInstance.close()
    else:
     FF7k8q(self, "All URLs are authorized.", title=title)
   else:
    FFikHE(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVlh6L(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVKi7C(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVTzl0(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVrMuf(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVKi7C(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VV3WgZ   : return "%s"            % url
  elif mode == self.VVmTKI   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVVm1a   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVcbkF  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVE5zN  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVuWrC : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV204C   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVpewk    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV33vV  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVfoFc : return "%s&action=get_live_streams"      % url
  elif mode == self.VVMtkp  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV7oGw(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFIb5k(int(val))
    elif is_base64 : val = FFJ3Mw(val)
    elif isToHHMMSS : val = FFhztG(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV3DB7(self, title, path):
  if fileExists(path):
   enc = CCIa4v.VVvRi6(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVq9ka(line)
     if qUrl:
      break
   if qUrl : self.VVFlgt(title, qUrl)
   else : FFikHE(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFikHE(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVVfnf_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVisWm()
  if qUrl or "chCode" in iptvRef:
   p = CC1ywg()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVqaCG(iptvRef)
   if valid:
    self.VVVfnf(self, host, mac)
    return
   elif qUrl:
    FFjNEj(self, boundFunction(self.VVFlgt, title, qUrl), title="Checking Server ...")
    return
  FFikHE(self, "Error in current channel URL !", title=title)
 def VVisWm(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  qUrl = self.VVq9ka(decodedUrl)
  return qUrl, iptvRef
 def VVq9ka(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVFlgt(self, title, url):
  self.VV0n7FData = {}
  qUrl = self.VVrMuf(self.VV3WgZ, url)
  txt, err = self.VVlh6L(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV0n7FData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV0n7FData["username"    ] = self.VV7oGw(item, "username"        )
    self.VV0n7FData["password"    ] = self.VV7oGw(item, "password"        )
    self.VV0n7FData["message"    ] = self.VV7oGw(item, "message"        )
    self.VV0n7FData["auth"     ] = self.VV7oGw(item, "auth"         )
    self.VV0n7FData["status"    ] = self.VV7oGw(item, "status"        )
    self.VV0n7FData["exp_date"    ] = self.VV7oGw(item, "exp_date"    , isDate=True )
    self.VV0n7FData["is_trial"    ] = self.VV7oGw(item, "is_trial"        )
    self.VV0n7FData["active_cons"   ] = self.VV7oGw(item, "active_cons"       )
    self.VV0n7FData["created_at"   ] = self.VV7oGw(item, "created_at"   , isDate=True )
    self.VV0n7FData["max_connections"  ] = self.VV7oGw(item, "max_connections"      )
    self.VV0n7FData["allowed_output_formats"] = self.VV7oGw(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV0n7FData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV0n7FData["url"    ] = self.VV7oGw(item, "url"        )
    self.VV0n7FData["port"    ] = self.VV7oGw(item, "port"        )
    self.VV0n7FData["https_port"  ] = self.VV7oGw(item, "https_port"      )
    self.VV0n7FData["server_protocol" ] = self.VV7oGw(item, "server_protocol"     )
    self.VV0n7FData["rtmp_port"   ] = self.VV7oGw(item, "rtmp_port"       )
    self.VV0n7FData["timezone"   ] = self.VV7oGw(item, "timezone"       )
    self.VV0n7FData["timestamp_now"  ] = self.VV7oGw(item, "timestamp_now"  , isDate=True )
    self.VV0n7FData["time_now"   ] = self.VV7oGw(item, "time_now"       )
    VVRj9e  = self.VVcS38(True)
    OKBtnFnc = self.VV0n7FOptions
    VV5GJ7 = ("Home Menu", FFNnw3)
    VVBBKW = ("Bookmark Server", boundFunction(CCfMBx.VVGG3r, self, False, self.VV0n7FData["playListURL"]))
    FFLATx(self, None, title="IPTV Server Resources", VVRj9e=VVRj9e, OKBtnFnc=OKBtnFnc, VV5GJ7=VV5GJ7, VVBBKW=VVBBKW)
   else:
    err = "Could not get data from server !"
  if err:
   FFikHE(self, err, title=title)
  FFNWTN(self)
 def VV0n7FOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFjNEj(menuInstance, boundFunction(self.VVYhYN, self.VVmTKI  , title=title), title=wTxt)
   elif ref == "vod"   : FFjNEj(menuInstance, boundFunction(self.VVYhYN, self.VVVm1a  , title=title), title=wTxt)
   elif ref == "series"  : FFjNEj(menuInstance, boundFunction(self.VVYhYN, self.VVcbkF , title=title), title=wTxt)
   elif ref == "catchup"  : FFjNEj(menuInstance, boundFunction(self.VVYhYN, self.VVE5zN , title=title), title=wTxt)
   elif ref == "accountInfo" : FFjNEj(menuInstance, boundFunction(self.VV66sF           , title=title), title=wTxt)
 def VV66sF(self, title):
  rows = []
  for key, val in self.VV0n7FData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VV9OiG  = ("Home Menu", FFNnw3, [])
  VVSYUp  = None
  if VVDzaH:
   VVSYUp = ("Get JS" , boundFunction(self.VVSjDf, "/".join(self.VV0n7FData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFxW7z(self, None, title=title, width=1200, header=header, VV9o2E=rows, VVec0v=widths, VVfhdd=26, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVSYTz="#0a00292B", VV8c5A="#0a002126", VVn7jC="#0a002126", VVQceP="#00000000", searchCol=2)
 def VVZT5S(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCT9pC()
    if mode in (self.VV204C, self.VVMtkp):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV7oGw(item, "num"         )
      name     = self.VV7oGw(item, "name"        )
      stream_id    = self.VV7oGw(item, "stream_id"       )
      stream_icon    = self.VV7oGw(item, "stream_icon"       )
      epg_channel_id   = self.VV7oGw(item, "epg_channel_id"      )
      added     = self.VV7oGw(item, "added"    , isDate=True )
      is_adult    = self.VV7oGw(item, "is_adult"       )
      category_id    = self.VV7oGw(item, "category_id"       )
      tv_archive    = self.VV7oGw(item, "tv_archive"       )
      name = processChanName.VVMrdo(name)
      if name:
       if mode == self.VV204C or mode == self.VVMtkp and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVpewk:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV7oGw(item, "num"         )
      name    = self.VV7oGw(item, "name"        )
      stream_id   = self.VV7oGw(item, "stream_id"       )
      stream_icon   = self.VV7oGw(item, "stream_icon"       )
      added    = self.VV7oGw(item, "added"    , isDate=True )
      is_adult   = self.VV7oGw(item, "is_adult"       )
      category_id   = self.VV7oGw(item, "category_id"       )
      container_extension = self.VV7oGw(item, "container_extension"     ) or "mp4"
      name = processChanName.VVMrdo(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VV33vV:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV7oGw(item, "num"        )
      name    = self.VV7oGw(item, "name"       )
      series_id   = self.VV7oGw(item, "series_id"      )
      cover    = self.VV7oGw(item, "cover"       )
      genre    = self.VV7oGw(item, "genre"       )
      episode_run_time = self.VV7oGw(item, "episode_run_time"    )
      category_id   = self.VV7oGw(item, "category_id"      )
      container_extension = self.VV7oGw(item, "container_extension"    ) or "mp4"
      name = processChanName.VVMrdo(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVYhYN(self, mode, title):
  cList, err = self.VVpH2p(mode)
  if cList and mode == self.VVE5zN:
   cList = self.VVoYvW(cList)
  if err:
   FFikHE(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM(mode)
   mName = self.VVVCNc(mode)
   if   mode == self.VVmTKI  : fMode = self.VV204C
   elif mode == self.VVVm1a  : fMode = self.VVpewk
   elif mode == self.VVcbkF : fMode = self.VV33vV
   elif mode == self.VVE5zN : fMode = self.VVMtkp
   if mode == self.VVE5zN:
    VVM10w = None
   else:
    VVM10w = ("Find in %s" % mName , boundFunction(self.VV7jrw, fMode) , [])
   VVOrFX   = ("Show List"   , boundFunction(self.VVrqK0, mode) , [])
   VV9OiG  = ("Home Menu"   , FFNnw3          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFxW7z(self, None, title=title, width=1200, header=header, VV9o2E=cList, VVec0v=widths, VVfhdd=30, VV9OiG=VV9OiG, VVM10w=VVM10w, VVOrFX=VVOrFX, VVSYTz=VVSYTz, VV8c5A=VV8c5A, VVn7jC=VVn7jC, VVQceP=VVQceP)
  else:
   FFikHE(self, "No list from server !", title=title)
  FFNWTN(self)
 def VVpH2p(self, mode):
  qUrl  = self.VVrMuf(mode, self.VV0n7FData["playListURL"])
  txt, err = self.VVlh6L(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCT9pC()
    for item in tDict:
     category_id  = self.VV7oGw(item, "category_id"  )
     category_name = self.VV7oGw(item, "category_name" )
     parent_id  = self.VV7oGw(item, "parent_id"  )
     category_name = processChanName.VVmmRr(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVoYvW(self, catList):
  mode  = self.VVMtkp
  qUrl  = self.VVrMuf(mode, self.VV0n7FData["playListURL"])
  txt, err = self.VVlh6L(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVZT5S(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVrqK0(self, mode, VVzpqh, title, txt, colList):
  title = colList[1]
  FFjNEj(VVzpqh, boundFunction(self.VVKbSr, mode, VVzpqh, title, txt, colList), title="Downloading ...")
 def VVKbSr(self, mode, VVzpqh, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVVCNc(mode) + " : "+ bName
  if   mode == self.VVmTKI  : mode = self.VV204C
  elif mode == self.VVVm1a  : mode = self.VVpewk
  elif mode == self.VVcbkF : mode = self.VV33vV
  elif mode == self.VVE5zN : mode = self.VVMtkp
  qUrl  = self.VVrMuf(mode, self.VV0n7FData["playListURL"], catID)
  txt, err = self.VVlh6L(qUrl)
  list  = []
  if not err and mode in (self.VV204C, self.VVpewk, self.VV33vV, self.VVMtkp):
   list, err = self.VVZT5S(mode, txt)
  if err:
   FFikHE(self, err, title=title)
  elif list:
   VV9OiG  = ("Home Menu"   , FFNnw3             , [])
   if mode in (self.VV204C, self.VVMtkp):
    VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM(mode)
    VVEJ7p = (""     , boundFunction(self.VV5XD2, mode)     , [])
    VVSYUp = ("Download Options" , boundFunction(self.VVsLcU, mode, "", "")  , [])
    VVM10w = ("Options" , boundFunction(self.VV9DLg, 1, "lv", mode, bName)  , [])
    if mode == self.VV204C:
     VVOrFX = ("Play"    , boundFunction(self.VV2g0M, mode)     , [])
    elif mode == self.VVMtkp:
     VVOrFX  = ("Programs", boundFunction(self.VVHiAS_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVujrY  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVpewk:
    VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM(mode)
    VVOrFX  = ("Play"    , boundFunction(self.VV2g0M, mode)    , [])
    VVEJ7p = (""     , boundFunction(self.VV5XD2, mode)    , [])
    VVSYUp = ("Download Options" , boundFunction(self.VVsLcU, mode, "v", ""), [])
    VVM10w = ("Options" , boundFunction(self.VV9DLg, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVujrY  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VV33vV:
    VVSYTz, VV8c5A, VVn7jC, VVQceP = self.VVabQM("series2")
    VVOrFX  = ("Show Seasons", boundFunction(self.VVrmiT, mode) , [])
    VVEJ7p = ("", boundFunction(self.VVQdae, mode)  , [])
    VVSYUp = None
    VVM10w = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVujrY  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFxW7z(self, None, title=title, header=header, VV9o2E=list, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVEJ7p=VVEJ7p, VVSYTz=VVSYTz, VV8c5A=VV8c5A, VVn7jC=VVn7jC, VVQceP=VVQceP, VVvdC4=True, searchCol=1)
  else:
   FFikHE(self, "No Channels found !", title=title)
  FFNWTN(self)
 def VVHiAS_fromIptvTable(self, mode, bName, VVzpqh, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV0n7FData["playListURL"]
  ok_fnc  = boundFunction(self.VVWuJk, hostUrl, chName, catId, streamId)
  FFjNEj(VVzpqh, boundFunction(CCfMBx.VVHiAS, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVWuJk(self, chUrl, chName, catId, streamId, VVzpqh, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfMBx.VVKi7C(chUrl)
   chNum = "333"
   refCode = CCfMBx.VV1MBM(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFZXnt(self, chUrl, VVPUAy=False)
   self.session.open(CCxKzH)
  else:
   FFikHE(self, "Incorrect Timestamp", pTitle)
 def VVrmiT(self, mode, VVzpqh, title, txt, colList):
  title = colList[1]
  FFjNEj(VVzpqh, boundFunction(self.VV7Gij, mode, VVzpqh, title, txt, colList), title="Downloading ...")
 def VV7Gij(self, mode, VVzpqh, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVrMuf(self.VVuWrC, self.VV0n7FData["playListURL"], series_id)
  txt, err = self.VVlh6L(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV7oGw(tDict["info"], "name"   )
      category_id = self.VV7oGw(tDict["info"], "category_id" )
      icon  = self.VV7oGw(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV7oGw(EP, "id"     )
        episode_num   = self.VV7oGw(EP, "episode_num"   )
        epTitle    = self.VV7oGw(EP, "title"     )
        container_extension = self.VV7oGw(EP, "container_extension" )
        seasonNum   = self.VV7oGw(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFikHE(self, err, title=title)
  elif list:
   VV9OiG = ("Home Menu"   , FFNnw3             , [])
   VVSYUp = ("Download Options" , boundFunction(self.VVsLcU, mode, "s", title) , [])
   VVM10w = ("Options" , boundFunction(self.VV9DLg, 0, "s", mode, title)  , [])
   VVEJ7p = (""     , boundFunction(self.VV5XD2, mode)     , [])
   VVOrFX  = ("Play"    , boundFunction(self.VV2g0M, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVujrY  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFxW7z(self, None, title=title, header=header, VV9o2E=list, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVM10w=VVM10w, VVSYTz="#0a00292B", VV8c5A="#0a002126", VVn7jC="#0a002126", VVQceP="#00000000")
  else:
   FFikHE(self, "No Channels found !", title=title)
  FFNWTN(self)
 def VV7jrw(self, mode, VVzpqh, title, txt, colList):
  VVRj9e = []
  VVRj9e.append(("Keyboard"  , "manualEntry"))
  VVRj9e.append(("From Filter" , "fromFilter"))
  FFLATx(self, boundFunction(self.VVgOnD, VVzpqh, mode), title="Input Type", VVRj9e=VVRj9e, width=400)
 def VVgOnD(self, VVzpqh, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFJeIH(self, boundFunction(self.VVlNe0, VVzpqh, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC1WKO(self)
    filterObj.VV6HGH(boundFunction(self.VVlNe0, VVzpqh, mode))
 def VVlNe0(self, VVzpqh, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCT9pC()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVi45R(words):
     FFikHE(self, processChanName.VVOl2R(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVCcGI, VVzpqh, mode, title, words, toFind, asPrefix, processChanName)
         , VVl0w9 = boundFunction(self.VVlJzJ, mode, toFind, title))
   else:
    FFikHE(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVCcGI(self, VVzpqh, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVeQL2(VVzpqh.VVv7ZO())
  progBarObj.VVXjH0 = []
  for row in VVzpqh.VVbBP2():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVxenn(1)
   progBarObj.VV5AWx_fromIptvFind(catName)
   qUrl  = self.VVrMuf(mode, self.VV0n7FData["playListURL"], catID)
   txt, err = self.VVlh6L(qUrl)
   if not err:
    tList, err = self.VVZT5S(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVMrdo(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VV204C:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVXjH0.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVpewk:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVXjH0.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VV33vV:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVXjH0.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVlJzJ(self, mode, toFind, title, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  if VVXjH0:
   title = self.VVU3tK(mode, toFind)
   if mode == self.VV204C or mode == self.VVpewk:
    if mode == self.VVpewk : typ = "v"
    else          : typ = ""
    bName   = CCfMBx.VVYpUo_forBouquet(toFind)
    VVOrFX  = ("Play"     , boundFunction(self.VV2g0M, mode)    , [])
    VVSYUp = ("Download Options" , boundFunction(self.VVsLcU, mode, typ, ""), [])
    VVM10w = ("Options" , boundFunction(self.VV9DLg, 1, "fnd", mode, bName)  , [])
   elif mode == self.VV33vV:
    VVOrFX  = ("Show Seasons"  , boundFunction(self.VVrmiT, mode)    , [])
    VVM10w = None
    VVSYUp = None
   VVEJ7p  = (""     , boundFunction(self.VV5XD2, mode)    , [])
   VV9OiG  = ("Home Menu"   , FFNnw3            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVujrY  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVzpqh = FFxW7z(self, None, title=title, header=header, VV9o2E=VVXjH0, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VVEJ7p=VVEJ7p, VVSYTz="#0a00292B", VV8c5A="#0a002126", VVn7jC="#0a002126", VVQceP="#00000000", VVvdC4=True, searchCol=1)
   if not VVfloe:
    FFNWTN(VVzpqh, "Stopped" , 1000)
  else:
   if VVfloe:
    FFikHE(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VV1C5c(self, mode, colList):
  if mode in (self.VV204C, self.VVMtkp):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVpewk:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFz82T(chName)
  url = self.VV0n7FData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVKi7C(url)
  refCode = self.VV1MBM(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV5XD2(self, mode, VVzpqh, title, txt, colList):
  FFjNEj(VVzpqh, boundFunction(self.VVEAzy, mode, VVzpqh, title, txt, colList))
 def VVEAzy(self, mode, VVzpqh, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV1C5c(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFgBdr(self, fncMode=CCR0BS.VV9PtM, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVQdae(self, mode, VVzpqh, title, txt, colList):
  FFjNEj(VVzpqh, boundFunction(self.VVHP7k, mode, VVzpqh, title, txt, colList))
 def VVHP7k(self, mode, VVzpqh, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFgBdr(self, fncMode=CCR0BS.VVLJKv, chName=name, text=txt, picUrl=Cover)
 def VVlv7g(self, mode, bName, VVzpqh, title, txt, colList):
  url = self.VV0n7FData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVKi7C(url)
  bNameFile = CCfMBx.VVYpUo_forBouquet(bName)
  num  = 0
  path = VV9gDR + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VV9gDR + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVzpqh.VVS8vj
   for ndx, row in enumerate(VVzpqh.VVbBP2()):
    chName, chUrl, picUrl, refCode = self.VV1C5c(mode, row)
    if not isMulti or VVzpqh.VVS5Wm(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFpGUj(os.path.basename(path))
  self.VVHHMj(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVsLcU(self, mode, typ, seriesName, VVzpqh, title, txt, colList):
  VVRj9e = []
  isMulti = VVzpqh.VVS8vj
  tot  = VVzpqh.VVpH5i()
  if isMulti:
   if tot < 1:
    FFNWTN(VVzpqh, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVRj9e.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVRj9e.append(VVmGWQ)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVRj9e.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVRj9e.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVRj9e.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCtZ0M.VVvkan():
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(("Download Manager"      , "dload_stat" ))
  FFLATx(self, boundFunction(self.VVR7js_VVQYZb, VVzpqh, mode, typ, seriesName, colList), title="Download Options", VVRj9e=VVRj9e)
 def VVR7js_VVQYZb(self, VVzpqh, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV9abi(VVzpqh, mode)
   elif item == "dnldSel"  : self.VVj6aX(VVzpqh, mode, typ, colList, True)
   elif item == "addSel"  : self.VVj6aX(VVzpqh, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVZCaJ(VVzpqh, mode, typ, seriesName)
   elif item == "dload_stat" : CCtZ0M.VVBGzA(self)
 def VVj6aX(self, VVzpqh, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVM1kw(mode, typ, colList)
  if startDnld:
   CCtZ0M.VV9NFd_url(self, decodedUrl)
  else:
   self.VVQYZb_FF2QoN(VVzpqh, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVZCaJ(self, VVzpqh, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVzpqh.VVbBP2():
   chName, decodedUrl = self.VVM1kw(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVQYZb_FF2QoN(VVzpqh, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVQYZb_FF2QoN(self, VVzpqh, title, chName, decodedUrl_list, startDnld):
  FF2QoN(self, boundFunction(self.VVALWA, VVzpqh, decodedUrl_list, startDnld), chName, title=title)
 def VVALWA(self, VVzpqh, decodedUrl_list, startDnld):
  added, skipped = CCtZ0M.VVmfuhList(decodedUrl_list)
  FFNWTN(VVzpqh, "Added", 1000)
 def VVM1kw(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VV1C5c(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVKXD5(mode, colList)
   refCode, chUrl = self.VV4JLB(self.VVnccW, self.VVaKxu, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFGrEr(chUrl)
  return chName, decodedUrl
 def VV9abi(self, VVzpqh, mode):
  if os.system(FFH6kH("which ffmpeg")) == 0:
   self.session.open(CCtIzA, barTheme=CCtIzA.VVu45l
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVeqDV, VVzpqh, mode)
       , VVl0w9 = self.VVKIMs)
  else:
   FF2QoN(self, boundFunction(CCfMBx.VVCM1R, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVKIMs(self, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVXjH0["proces"], VVXjH0["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVXjH0["ok"], VVXjH0["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVXjH0["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVXjH0["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVXjH0["badURL"]
  txt += "Download Failure\t: %d\n"   % VVXjH0["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVXjH0["path"]
  if not VVfloe  : color = "#11402000"
  elif VVXjH0["err"]: color = "#11201000"
  else     : color = None
  if VVXjH0["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVXjH0["err"], txt)
  title = "PIcons Download Result"
  if not VVfloe:
   title += "  (cancelled)"
  FFCsft(self, txt, title=title, VVn7jC=color)
 def VVeqDV(self, VVzpqh, mode, progBarObj):
  isMulti = VVzpqh.VVS8vj
  if isMulti : totRows = VVzpqh.VVpH5i()
  else  : totRows = VVzpqh.VVv7ZO()
  progBarObj.VVeQL2(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CC0sln.VVij8s()
  progBarObj.VVXjH0 = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVzpqh.VVbBP2()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVzpqh.VVS5Wm(rowNum):
     progBarObj.VVXjH0["proces"] += 1
     progBarObj.VVxenn(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVKXD5(mode, row)
      refCode = CCfMBx.VV1MBM(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVak2l(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VV1C5c(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVXjH0["attempt"] += 1
       path, err = FFnx0u(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVXjH0["ok"] += 1
        if FFtYtQ(path) > 0:
         cmd = ""
         if not mode == CCfMBx.VV204C:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFH6kH("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVXjH0["size0"] += 1
         os.system(FFH6kH("rm -f '%s'" % path))
       elif err:
        progBarObj.VVXjH0["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVXjH0["err"] = err.title()
         break
      else:
       progBarObj.VVXjH0["exist"] += 1
     else:
      progBarObj.VVXjH0["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVCM1R(SELF):
  cmd = FFq4eO(VVn4yS, "ffmpeg")
  if cmd : FFF3Kc(SELF, cmd, title="Installing FFmpeg")
  else : FFNDX7(SELF)
 def VVxCpT(self):
  self.session.open(CCtIzA, barTheme=CCtIzA.VVu45l
      , titlePrefix = ""
      , fncToRun  = self.VVT9zK
      , VVl0w9 = self.VVqvZk)
 def VVT9zK(self, progBarObj):
  bName = FFqa4x()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVXjH0 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFCw14()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVeQL2(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVxenn(1)
    progBarObj.VV5AWx_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FF0haM(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFGrEr(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CC1ywg.VVKjCW(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCfMBx.VVTzl0(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCfMBx.VVTzl0(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCfMBx.VVTzl0(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCfMBx.VVTEh2(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCR0BS.VVs2Qe(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVXjH0 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVXjH0 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVqvZk(self, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVXjH0
  title = "IPTV EPG Import"
  if err:
   FFikHE(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFhTMc(str(totNotIptv), VVtODU)
    if totServErr : txt += "Server Errors\t: %s\n" % FFhTMc(str(totServErr) + t1, VVtODU)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFhTMc(str(totInv), VVtODU)
   if not VVfloe:
    title += "  (stopped)"
   FFCsft(self, txt, title=title)
 @staticmethod
 def VVTEh2(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCfMBx.VVKi7C(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCfMBx.VVlh6L(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCfMBx.VV7oGw(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCfMBx.VV7oGw(item, "has_archive"      )
    lang    = CCfMBx.VV7oGw(item, "lang"        ).upper()
    now_playing   = CCfMBx.VV7oGw(item, "now_playing"      )
    start    = CCfMBx.VV7oGw(item, "start"        )
    start_timestamp  = CCfMBx.VV7oGw(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCfMBx.VV7oGw(item, "start_timestamp"     )
    stop_timestamp  = CCfMBx.VV7oGw(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCfMBx.VV7oGw(item, "stop_timestamp"      )
    tTitle    = CCfMBx.VV7oGw(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV1MBM(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCfMBx.VVDeBq(catID, MAX_4b)
  TSID = CCfMBx.VVDeBq(chNum, MAX_4b)
  ONID = CCfMBx.VVDeBq(chNum, MAX_4b)
  NS  = CCfMBx.VVDeBq(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVDeBq(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVYpUo_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVabQM(mode):
  if   mode in ("itv"  , CCfMBx.VVmTKI)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCfMBx.VVVm1a)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCfMBx.VVcbkF) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCfMBx.VVE5zN) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCfMBx.VVMtkp    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVRRDc(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVKky1:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFZ2H0(path)
 @staticmethod
 def VVHiAS(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCfMBx.VVTEh2(hostUrl, streamId, True)
  if err:
   FFikHE(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVSYTz, VV8c5A, VVn7jC, VVQceP = CCfMBx.VVabQM("")
   VV9OiG = ("Home Menu" , FFNnw3, [])
   VVOrFX  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVujrY  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFxW7z(SELF, None, title="Programs for : " + chName, header=header, VV9o2E=pList, VVujrY=VVujrY, VVec0v=widths, VVfhdd=24, VVOrFX=VVOrFX, VV9OiG=VV9OiG, VVSYTz=VVSYTz, VV8c5A=VV8c5A, VVn7jC=VVn7jC, VVQceP=VVQceP)
  else:
   FFikHE(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVChBV(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVGG3r(SELF, isPortal, line, VVq5cQObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCfMBx.VVRRDc(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFikHE(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF7k8q(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFikHE(SELF, "Error:\n\n%s" % str(e), title=title)
 def VV9DLg(self, nameCol, source, mode, bName, VVzpqh, title, txt, colList):
  isMulti = VVzpqh.VVS8vj
  mSel = CCXiQX(self, VVzpqh, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVzpqh.VVpH5i()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVRj9e.append(VVmGWQ)
   mSel.VVRj9e.append((title        , "addToBoquet"))
  FFLATx(self, boundFunction(self.VVTcUh, mSel, source, mode, bName, VVzpqh, title, txt, colList), title="Options", VVRj9e=mSel.VVRj9e)
 def VVTcUh(self, mSelObj, source, mode, bName, VVzpqh, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVzpqh.VV0fYN(True)
   elif item == "MultSelDisab"     : mSelObj.VVzpqh.VV0fYN(False)
   elif item == "selectAll"     : mSelObj.VVzpqh.VVKfFs()
   elif item == "unselectAll"     : mSelObj.VVzpqh.VVidyT()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVLNbJ
    elif source == "pCh" : fnc = self.VVLNbJ
    elif source == "m3Ch" : fnc = self.VVuOOb
    elif source == "lv"  : fnc = self.VVlv7g
    elif source == "v"  : fnc = self.VVlv7g
    elif source == "s"  : fnc = self.VVlv7g
    elif source == "fnd" : fnc = self.VVlv7g
    else     : return
    FFjNEj(VVzpqh, boundFunction(fnc, mode, bName, VVzpqh, title, txt, colList), title="Adding Channels ...")
class CCj59b(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVdLkL  = 0
  self.VV8OEy = 1
  self.VV6ZjX  = 2
  VVRj9e = []
  VVRj9e.append(("Find in All Service (from filter)" , "VVy9Od" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Find in All (Manual Entry)"   , "VVYEt6"    ))
  VVRj9e.append(("Find in TV"       , "VVT0Q1"    ))
  VVRj9e.append(("Find in Radio"      , "VVefAQ"   ))
  if self.VVbizy():
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Hide Channel: %s" % self.servName , "VVyOHT"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Zap History"       , "VV3sli"    ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("IPTV Tools"       , "iptv"      ))
  VVRj9e.append(("PIcons Tools"       , "PIconsTools"     ))
  VVRj9e.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFpJPp(self, VVRj9e=VVRj9e, title=title)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
  if self.isFindMode:
   self.VVMuLJ(self.VV0vRf())
 def VV4R5P(self):
  global VVQhtK
  VVQhtK = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVYEt6"    : self.VVYEt6()
   elif item == "VVy9Od" : self.VVy9Od()
   elif item == "VVT0Q1"    : self.VVT0Q1()
   elif item == "VVefAQ"   : self.VVefAQ()
   elif item == "VVyOHT"   : self.VVyOHT()
   elif item == "VV3sli"    : self.VV3sli()
   elif item == "iptv"       : self.session.open(CCfMBx)
   elif item == "PIconsTools"     : self.session.open(CC0sln)
   elif item == "ChannelsTools"    : self.session.open(CCAzDv)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVT0Q1(self) : self.VVMuLJ(self.VVdLkL)
 def VVefAQ(self) : self.VVMuLJ(self.VV8OEy)
 def VVYEt6(self) : self.VVMuLJ(self.VV6ZjX)
 def VVMuLJ(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFJeIH(self, boundFunction(self.VVwRYs, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVy9Od(self):
  filterObj = CC1WKO(self)
  filterObj.VV6HGH(self.VV8xSd)
 def VV8xSd(self, item):
  self.VVwRYs(self.VV6ZjX, item)
 def VVbizy(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF0haM(self.refCode)        : return False
  return True
 def VVwRYs(self, mode, VVuODe):
  FFjNEj(self, boundFunction(self.VVpkvx, mode, VVuODe), title="Searching ...")
 def VVpkvx(self, mode, VVuODe):
  if VVuODe:
   self.findTxt = VVuODe
   if   mode == self.VVdLkL  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV8OEy : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVuODe)
   if len(title) > 55:
    title = title[:55] + ".."
   VV16hm = self.VVNrwd(VVuODe, servTypes)
   if self.isFindMode or mode == self.VV6ZjX:
    VV16hm += self.VVlihX(VVuODe)
   if VV16hm:
    VV16hm.sort(key=lambda x: x[0].lower())
    VVQOfi = self.VV7KkE
    VVOrFX  = ("Zap"   , self.VV5skk    , [])
    VVSYUp = ("Current Service", self.VVVrlM , [])
    VVM10w = ("Options"  , self.VVH9uS , [])
    VVEJ7p = (""    , self.VVdt9w , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVujrY  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFxW7z(self, None, title=title, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVQOfi=VVQOfi, VVSYUp=VVSYUp, VVM10w=VVM10w, VVEJ7p=VVEJ7p)
   else:
    self.VVMuLJ(self.VV0vRf())
    FF7k8q(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVNrwd(self, VVuODe, servTypes):
  VVTBRF  = eServiceCenter.getInstance()
  VVwcpq   = '%s ORDER BY name' % servTypes
  VVadmJ   = eServiceReference(VVwcpq)
  VVIrgj = VVTBRF.list(VVadmJ)
  if VVIrgj: VV9o2E = VVIrgj.getContent("CN", False)
  else     : VV9o2E = None
  VV16hm = []
  if VV9o2E:
   VVO3Uv, VVDmXY = FFcBHV()
   tp   = CCWZOp()
   words, asPrefix = CC1WKO.VVYNyo(VVuODe)
   colorYellow  = CCacbo.VVYaeM(VVJF5Y)
   colorWhite  = CCacbo.VVYaeM(VV1LkE)
   for s in VV9o2E:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFHyEt(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVO3Uv:
        STYPE = VVDmXY[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVAUQo(refCode)
       if not "-S" in syst:
        sat = syst
       VV16hm.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV16hm
 def VVlihX(self, VVuODe):
  VVuODe = VVuODe.lower()
  VVuDQ1 = FFylDs()
  VV16hm = []
  colorYellow  = CCacbo.VVYaeM(VVJF5Y)
  colorWhite  = CCacbo.VVYaeM(VV1LkE)
  if VVuDQ1:
   for b in VVuDQ1:
    VVibEg  = b[0]
    VVmEZ2  = b[1].toString()
    VVuC0v = eServiceReference(VVmEZ2)
    VVp1ZK = FFb1PG(VVuC0v)
    for service in VVp1ZK:
     refCode  = service[0]
     if FF0haM(refCode):
      servName = service[1]
      if VVuODe in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVuODe), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV16hm.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV16hm
 def VV0vRf(self):
  VVy039 = InfoBar.instance
  if VVy039:
   VVUSso = VVy039.servicelist
   if VVUSso:
    return VVUSso.mode == 1
  return self.VV6ZjX
 def VV7KkE(self, VVzpqh):
  self.close()
  VVzpqh.cancel()
 def VV5skk(self, VVzpqh, title, txt, colList):
  FFZXnt(VVzpqh, colList[2], VVPUAy=False, checkParentalControl=True)
 def VVVrlM(self, VVzpqh, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(VVzpqh)
  if refCode:
   VVzpqh.VViaYk(2, FF301l(refCode, iptvRef, chName), True)
 def VVH9uS(self, VVzpqh, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCXiQX(self, VVzpqh, 2)
  mSel.VV1quF(servName, refCode)
 def VVdt9w(self, VVzpqh, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFgBdr(self, fncMode=CCR0BS.VVIJPI, refCode=refCode, chName=chName, text=txt)
 def VVyOHT(self):
  FF2QoN(self, self.VVFIWT, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVFIWT(self):
  ret = FFgRoS(self.refCode, True)
  if ret:
   self.VVBEny()
   self.close()
  else:
   FFNWTN(self, "Cannot change state" , 1000)
 def VVBEny(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVIgt1()
  except:
   self.VVQ4gL()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFgMc0(self, serviceRef)
 def VVJmaT(self):
  VVy039 = InfoBar.instance
  if VVy039:
   VVUSso = VVy039.servicelist
   if VVUSso:
    VVUSso.setMode()
 def VVIgt1(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVy039 = InfoBar.instance
   if VVy039:
    VVUSso = VVy039.servicelist
    if VVUSso:
     hList = VVUSso.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVUSso.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVUSso.history  = newList
       VVUSso.history_pos = pos
 def VVQ4gL(self):
  VVy039 = InfoBar.instance
  if VVy039:
   VVUSso = VVy039.servicelist
   if VVUSso:
    VVUSso.history  = []
    VVUSso.history_pos = 0
 def VV3sli(self):
  VVy039 = InfoBar.instance
  VV16hm = []
  if VVy039:
   VVUSso = VVy039.servicelist
   if VVUSso:
    VVO3Uv, VVDmXY = FFcBHV()
    for chParams in VVUSso.history:
     refCode = chParams[-1].toString()
     chName = FFopjl(refCode)
     isIptv = FF0haM(refCode)
     if isIptv: sat = "-"
     else  : sat = FFHyEt(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVO3Uv:
       STYPE = VVDmXY[sTypeInt]
     VV16hm.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV16hm:
   VVOrFX  = ("Zap"   , self.VVJXVo   , [])
   VVM10w = ("Clear History" , self.VVbaxJ   , [])
   VVEJ7p = (""    , self.VVM8a6FromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVujrY  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFxW7z(self, None, title=title, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=28, VVOrFX=VVOrFX, VVM10w=VVM10w, VVEJ7p=VVEJ7p)
  else:
   FF7k8q(self, "Not found", title=title)
 def VVJXVo(self, VVzpqh, title, txt, colList):
  FFZXnt(VVzpqh, colList[3], VVPUAy=False, checkParentalControl=True)
 def VVbaxJ(self, VVzpqh, title, txt, colList):
  FF2QoN(self, boundFunction(self.VVecpL, VVzpqh), "Clear Zap History ?")
 def VVecpL(self, VVzpqh):
  self.VVQ4gL()
  VVzpqh.cancel()
 def VVM8a6FromZapHistory(self, VVzpqh, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFgBdr(self, fncMode=CCR0BS.VVpgmd, refCode=refCode, chName=chName, text=txt)
class CC0sln(Screen):
 VVq9kW   = 0
 VVz3e0  = 1
 VVxXnZ  = 2
 VVHdFz  = 3
 VVLsi9  = 4
 VVIUjJ  = 5
 VVOe2C  = 6
 VVvccG  = 7
 VVUgA8 = 8
 VVZMgX = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFRqpN(VVN1qf, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFpJPp(self, self.Title)
  FFpqes(self["keyRed"] , "OK = Zap")
  FFpqes(self["keyGreen"] , "Current Service")
  FFpqes(self["keyYellow"], "Page Options")
  FFpqes(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC0sln.VVij8s()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV9o2E    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVSAUU        ,
   "green"   : self.VVfThu       ,
   "yellow"  : self.VVIqXP        ,
   "blue"   : self.VVCUtI        ,
   "menu"   : self.VVaeZL        ,
   "info"   : self.VVM8a6         ,
   "up"   : self.VVFwmU          ,
   "down"   : self.VV5ndD         ,
   "left"   : self.VVWfTh         ,
   "right"   : self.VV6a4U         ,
   "pageUp"  : boundFunction(self.VVaZCA, True) ,
   "chanUp"  : boundFunction(self.VVaZCA, True) ,
   "pageDown"  : boundFunction(self.VVaZCA, False) ,
   "chanDown"  : boundFunction(self.VVaZCA, False) ,
   "next"   : self.VVyHzH        ,
   "last"   : self.VV080I         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFe9R7(self)
  FFKDC6(self)
  FFL3RG(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFjNEj(self, boundFunction(self.VVKUGo, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVaeZL(self):
  if not self.isBusy:
   VVRj9e = []
   VVRj9e.append(("Statistics"           , "VVoxpI"    ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Suggest PIcons for Current Channel"     , "VV3hnG"   ))
   VVRj9e.append(("Set to Current Channel (copy file)"     , "VV1ibf_file"  ))
   VVRj9e.append(("Set to Current Channel (as SymLink)"     , "VV1ibf_link"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(CC0sln.VVQwwO())
   VVRj9e.append(VVmGWQ)
   if self.filterTitle == "PIcons without Channels":
    c = VVtODU
    VVRj9e.append((FFhTMc("Move Unused PIcons to a Directory", c) , "VVLoW1"  ))
    VVRj9e.append((FFhTMc("DELETE Unused PIcons", c)    , "VVO8ld" ))
    VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVtBKT"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e += CC0sln.VVeJND()
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("RCU Keys Help"          , "VVAUZW"    ))
   FFLATx(self, self.VVR7js, title=self.Title, VVRj9e=VVRj9e)
 def VVR7js(self, item=None):
  if item is not None:
   if   item == "VVoxpI"     : self.VVoxpI()
   elif item == "VV3hnG"    : self.VV3hnG()
   elif item == "VV1ibf_file"   : self.VV1ibf(0)
   elif item == "VV1ibf_link"   : self.VV1ibf(1)
   elif item == "VVNKym_file"  : self.VVNKym(0)
   elif item == "VVNKym_link"  : self.VVNKym(1)
   elif item == "VVTnLw"   : self.VVTnLw()
   elif item == "VVlc28"  : self.VVlc28()
   elif item == "VVLoW1"    : self.VVLoW1()
   elif item == "VVO8ld"   : self.VVO8ld()
   elif item == "VVtBKT"   : self.VVtBKT()
   elif item == "VVtQeB"   : CC0sln.VVtQeB(self)
   elif item == "VVeWit"   : CC0sln.VVeWit(self)
   elif item == "findPiconBrokenSymLinks"  : CC0sln.VVrNIE(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC0sln.VVrNIE(self, False)
   elif item == "VVAUZW"      : self.VVAUZW()
 def VVIqXP(self):
  if not self.isBusy:
   VVRj9e = []
   VVRj9e.append(("Go to First PIcon"  , "VVBks2"  ))
   VVRj9e.append(("Go to Last PIcon"   , "VVJBFV"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Sort by Channel Name"     , "sortByChan" ))
   VVRj9e.append(("Sort by File Name"  , "sortByFile" ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Find from File List .." , "VV8QCt" ))
   FFLATx(self, self.VVOLd8, title=self.Title, VVRj9e=VVRj9e)
 def VVOLd8(self, item=None):
  if item is not None:
   if   item == "VVBks2"   : self.VVBks2()
   elif item == "VVJBFV"   : self.VVJBFV()
   elif item == "sortByChan"  : self.VVzjZK(2)
   elif item == "sortByFile"  : self.VVzjZK(0)
   elif item == "VV8QCt"  : self.VV8QCt()
 def VVAUZW(self):
  FFom2P(self, VVpTxo + "_help_picons", "PIcons Manager (Keys Help)")
 def VVFwmU(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVJBFV()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVQXkR()
 def VV5ndD(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBks2()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVQXkR()
 def VVWfTh(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVJBFV()
  else:
   self.curCol -= 1
   self.VVQXkR()
 def VV6a4U(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBks2()
  else:
   self.curCol += 1
   self.VVQXkR()
 def VV080I(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVQXkR(True)
 def VVyHzH(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVQXkR(True)
 def VVBks2(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVQXkR(True)
 def VVJBFV(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVQXkR(True)
 def VV8QCt(self):
  VVRj9e = []
  for item in self.VV9o2E:
   VVRj9e.append((item[0], item[0]))
  FFLATx(self, self.VVkad2, title='PIcons ".png" Files', VVRj9e=VVRj9e, VVhiDK=True)
 def VVkad2(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVoBRt(ndx)
 def VVSAUU(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVXKPu()
   if refCode:
    FFZXnt(self, refCode)
    self.VViHuU()
    self.VVxmEC()
 def VVaZCA(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VViHuU()
   self.VVxmEC()
  except:
   pass
 def VVfThu(self):
  if self["keyGreen"].getVisible():
   self.VVoBRt(self.curChanIndex)
 def VVoBRt(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVQXkR(True)
  else:
   FFNWTN(self, "Not found", 1000)
 def VVzjZK(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFjNEj(self, boundFunction(self.VVKUGo, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV1ibf(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVXKPu()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVRj9e = []
     VVRj9e.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVRj9e.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFLATx(self, boundFunction(self.VVe8mz, mode, curChF, selPiconF), VVRj9e=VVRj9e, title="Current Channel PIcon (already exists)")
    else:
     self.VVe8mz(mode, curChF, selPiconF, "overwrite")
   else:
    FFikHE(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFikHE(self, "Could not read current channel info. !", title=title)
 def VVe8mz(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFjNEj(self, boundFunction(self.VVKUGo, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVNKym(self, mode):
  pass
 def VVTnLw(self):
  pass
 def VVlc28(self):
  pass
 def VVLoW1(self):
  defDir = FFZ2H0(CC0sln.VVij8s() + "picons_backup")
  os.system(FFH6kH("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVxG0X, defDir), boundFunction(CCMTIp
         , mode=CCMTIp.VVIzr0, VV3a7H=CC0sln.VVij8s()))
 def VVxG0X(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC0sln.VVij8s():
    FFikHE(self, "Cannot move to same directory !", title=title)
   else:
    if not FFZ2H0(path) == FFZ2H0(defDir):
     self.VVsONM(defDir)
    FF2QoN(self, boundFunction(FFjNEj, self, boundFunction(self.VVmchq, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV9o2E), path), title=title)
  else:
   self.VVsONM(defDir)
 def VVmchq(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVsONM(defDir)
   FFikHE(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFZ2H0(toPath)
  pPath = CC0sln.VVij8s()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV9o2E:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV9o2E)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFCsft(self, txt, title=title, VVn7jC="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVygmE("all")
 def VVsONM(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVO8ld(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV9o2E)
  s = "s" if tot > 1 else ""
  FF2QoN(self, boundFunction(FFjNEj, self, boundFunction(self.VVNcwd, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVNcwd(self, title):
  pPath = CC0sln.VVij8s()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV9o2E:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV9o2E)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFhTMc(str(totErr), VVtODU)
  FFCsft(self, txt, title=title)
 def VVtBKT(self):
  lines = FF6vhB("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FF2QoN(self, boundFunction(self.VVYDzg, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VV9d4I=True)
  else:
   FF7k8q(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVYDzg(self, fList):
  os.system(FFH6kH("find -L '%s' -type l -delete" % self.pPath))
  FF7k8q(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVM8a6(self):
  FFjNEj(self, self.VVpIdL)
 def VVpIdL(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVXKPu()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFhTMc("PIcon Directory:\n", VVejU1)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFbVy4(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFbVy4(path)
   txt += FFhTMc("PIcon File:\n", VVejU1)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FF6vhB(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFhTMc("Found %d SymLink%s to this file from:\n" % (tot, s), VVejU1)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFopjl(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFhTMc(tChName, VV4U0A)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFhTMc(line, VVyTfh), tChName)
    txt += "\n"
   if chName:
    txt += FFhTMc("Channel:\n", VVejU1)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFhTMc(chName, VV4U0A)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFhTMc("Remarks:\n", VVejU1)
    txt += "  %s\n" % FFhTMc("Unused", VVtODU)
  else:
   txt = "No info found"
  FFgBdr(self, fncMode=CCR0BS.VVpv4M, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVXKPu(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV9o2E[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFleLE(sat)
  return fName, refCode, chName, sat, inDB
 def VViHuU(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV9o2E):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVxmEC(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVXKPu()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFhTMc("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVejU1))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVXKPu()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFhTMc(self.curChanName, VVJF5Y)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVoxpI(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV9o2E:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFT5H5("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFCsft(self, txt, title=self.Title)
 def VVCUtI(self):
  if not self.isBusy:
   VVRj9e = []
   VVRj9e.append(("All"         , "all"   ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Used by Channels"      , "used"  ))
   VVRj9e.append(("Unused PIcons"      , "unused"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("PIcons Files"       , "pFiles"  ))
   VVRj9e.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVRj9e.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVRj9e.append(VVmGWQ)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFMNbQ(val)
      VVRj9e.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC1WKO(self)
   filterObj.VVKROE(VVRj9e, self.nsList, self.VVyyiI)
 def VVyyiI(self, item=None):
  if item is not None:
   self.VVygmE(item)
 def VVygmE(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVq9kW   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVz3e0   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVxXnZ  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVHdFz  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVLsi9  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVIUjJ  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVOe2C   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVvccG   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVUgA8 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVIUjJ:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF6vhB("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFNWTN(self, "Not found", 1000)
     return
   elif mode == self.VVZMgX:
    return
   else:
    words, asPrefix = CC1WKO.VVYNyo(words)
   if not words and mode in (self.VVvccG, self.VVUgA8):
    FFNWTN(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFjNEj(self, boundFunction(self.VVKUGo, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VV3hnG(self):
  self.session.open(CCtIzA, barTheme=CCtIzA.VVL4ds
      , titlePrefix = ""
      , fncToRun  = self.VV7Iop
      , VVl0w9 = self.VVO3st)
 def VV7Iop(self, progBarObj):
  lameDbChans = CCAzDv.VVRwNz(self, CCAzDv.VVTH10, VVCLSM=False, VVgUIE=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVXjH0 = []
  progBarObj.VVeQL2(len(lameDbChans))
  if lameDbChans:
   processChanName = CCT9pC()
   curCh = processChanName.VVltu3(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVxenn(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CC0sln.VVPTz7(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC0sln.VVS5WZ(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVXjH0.append(f.replace(".png", ""))
 def VVO3st(self, VVfloe, VVXjH0, threadCounter, threadTotal, threadErr):
  if VVXjH0:
   self.timer = eTimer()
   fnc = boundFunction(FFjNEj, self, boundFunction(self.VVKUGo, mode=self.VVZMgX, words=VVXjH0), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFNWTN(self, "Not found", 2000)
 def VVKUGo(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVfOGB(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCAzDv.VVRwNz(self, CCAzDv.VVTH10, VVCLSM=False, VVgUIE=False)
  iptvRefList = self.VVQUp3()
  tList = []
  for fName, fType in CC0sln.VVj6fI(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVq9kW:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVz3e0  and chName         : isAdd = True
   elif mode == self.VVxXnZ and not chName        : isAdd = True
   elif mode == self.VVHdFz  and fType == 0        : isAdd = True
   elif mode == self.VVLsi9  and fType == 1        : isAdd = True
   elif mode == self.VVIUjJ  and fName in words       : isAdd = True
   elif mode == self.VVZMgX and fName in words       : isAdd = True
   elif mode == self.VVOe2C  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVvccG  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVUgA8:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV9o2E   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFNWTN(self)
  else:
   self.isBusy = False
   FFNWTN(self, "Not found", 1000)
   return
  self.VV9o2E.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VViHuU()
  self.totalPIcons = len(self.VV9o2E)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVQXkR(True)
 def VVfOGB(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC0sln.VVj6fI(self.pPath):
    if fName:
     return True
   if isFirstTime : FFikHE(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFNWTN(self, "Not found", 1000)
  else:
   FFikHE(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVQUp3(self):
  VV16hm = {}
  files  = CCfMBx.VVA7dS(self)
  if files:
   for path in files:
    txt = FFBgGE(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV16hm[refCode] = item[1]
  return VV16hm
 def VVQXkR(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVNqTq = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVNqTq: self.curPage = VVNqTq
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVVNWr()
  if self.curPage == VVNqTq:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVxmEC()
  filName, refCode, chName, sat, inDB = self.VVXKPu()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVVNWr(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV9o2E[ndx]
   fName = self.VV9o2E[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFhTMc(chName, VV4U0A))
    else : lbl.setText("-")
   except:
    lbl.setText(FFhTMc(chName, VVQiYp))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVPTz7(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVQwwO():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVtQeB"   )
 @staticmethod
 def VVeJND():
  VVRj9e = []
  VVRj9e.append(("Find SymLinks (to PIcon Directory)"   , "VVeWit"   ))
  VVRj9e.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVRj9e.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVRj9e
 @staticmethod
 def VVtQeB(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(SELF)
  png, path = CC0sln.VVA0Cp(refCode)
  if path : CC0sln.VVq2g2(SELF, png, path)
  else : FFikHE(SELF, "No PIcon found for current channel in:\n\n%s" % CC0sln.VVij8s())
 @staticmethod
 def VVeWit(SELF):
  if VVJF5Y:
   sed1 = FFMRMu("->", VVJF5Y)
   sed2 = FFMRMu("picon", VVtODU)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVQiYp, VV1LkE)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFsnYb(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FF85RC(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVrNIE(SELF, isPIcon):
  sed1 = FFMRMu("->", VVQiYp)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFMRMu("picon", VVtODU)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFsnYb(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FF85RC(), grep, sed1, sed2))
 @staticmethod
 def VVj6fI(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVij8s():
  path = CFG.PIconsPath.getValue()
  return FFZ2H0(path)
 @staticmethod
 def VVA0Cp(refCode, chName=None):
  if FF0haM(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFGrEr(refCode)
  allPath, fName, refCodeFile, pList = CC0sln.VVS5WZ(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVq2g2(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFMRMu("%s%s" % (dest, png), VV4U0A))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFMRMu(errTxt, VVOC4t))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFSdci(SELF, cmd)
 @staticmethod
 def VVS5WZ(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC0sln.VVij8s()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFz82T(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCRz4x():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVwWaV  = None
  self.VV6fBb = ""
  self.VV0FHt  = noService
  self.VV8WEK = 0
  self.VVzH0P  = noService
  self.VVvGcW = 0
  self.VVxNPV  = "-"
  self.VV52ad = 0
  self.VVdrDK  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVDsgG(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVwWaV = frontEndStatus
     self.VVmzBL()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVmzBL(self):
  if self.VVwWaV:
   val = self.VVwWaV.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VV6fBb = "%3.02f dB" % (val / 100.0)
   else         : self.VV6fBb = ""
   val = self.VVwWaV.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV8WEK = int(val)
   self.VV0FHt  = "%d%%" % val
   val = self.VVwWaV.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVvGcW = int(val)
   self.VVzH0P  = "%d%%" % val
   val = self.VVwWaV.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVxNPV  = "%d" % val
   val = int(val * 100 / 500)
   self.VV52ad = min(500, val)
   val = self.VVwWaV.get("tuner_locked", 0)
   if val == 1 : self.VVdrDK = "Locked"
   else  : self.VVdrDK = "Not locked"
 def VVODik(self)   : return self.VV6fBb
 def VVYOMl(self)   : return self.VV0FHt
 def VVEg3r(self)  : return self.VV8WEK
 def VVSK5c(self)   : return self.VVzH0P
 def VV7xA9(self)  : return self.VVvGcW
 def VVCPKC(self)   : return self.VVxNPV
 def VVZoq4(self)  : return self.VV52ad
 def VV9xIi(self)   : return self.VVdrDK
 def VVy1NW(self) : return self.serviceName
class CCWZOp():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVwOya(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFGtRH(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVbgde(self.ORPOS  , mod=1   )
      self.sat2  = self.VVbgde(self.ORPOS  , mod=2   )
      self.freq  = self.VVbgde(self.FREQ  , mod=3   )
      self.sr   = self.VVbgde(self.SR   , mod=4   )
      self.inv  = self.VVbgde(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVbgde(self.POL  , self.D_POL )
      self.fec  = self.VVbgde(self.FEC  , self.D_FEC )
      self.syst  = self.VVbgde(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVbgde("modulation" , self.D_MOD )
       self.rolof = self.VVbgde("rolloff"  , self.D_ROLOF )
       self.pil = self.VVbgde("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVbgde("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVbgde("pls_code"  )
       self.iStId = self.VVbgde("is_id"   )
       self.t2PlId = self.VVbgde("t2mi_plp_id" )
       self.t2PId = self.VVbgde("t2mi_pid"  )
 def VVbgde(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFMNbQ(val)
  elif mod == 2   : return FFFxRe(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVT7JV(self, refCode):
  txt = ""
  self.VVwOya(refCode)
  if self.data:
   def VVm7lK(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVm7lK("System"   , self.syst)
    txt += VVm7lK("Satellite"  , self.sat2)
    txt += VVm7lK("Frequency"  , self.freq)
    txt += VVm7lK("Inversion"  , self.inv)
    txt += VVm7lK("Symbol Rate"  , self.sr)
    txt += VVm7lK("Polarization" , self.pol)
    txt += VVm7lK("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVm7lK("Modulation" , self.mod)
     txt += VVm7lK("Roll-Off" , self.rolof)
     txt += VVm7lK("Pilot"  , self.pil)
     txt += VVm7lK("Input Stream", self.iStId)
     txt += VVm7lK("T2MI PLP ID" , self.t2PlId)
     txt += VVm7lK("T2MI PID" , self.t2PId)
     txt += VVm7lK("PLS Mode" , self.plsMod)
     txt += VVm7lK("PLS Code" , self.plsCod)
   else:
    txt += VVm7lK("System"   , self.txMedia)
    txt += VVm7lK("Frequency"  , self.freq)
  return txt, self.namespace
 def VV5ocI(self, refCode):
  txt = "Transpoder : ?"
  self.VVwOya(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVejU1 + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVAUQo(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFGtRH(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVbgde(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVbgde(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVbgde(self.SYST, self.D_SYS_S)
     freq = self.VVbgde(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVbgde(self.POL , self.D_POL)
      fec = self.VVbgde(self.FEC , self.D_FEC)
      sr = self.VVbgde(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVycsu(self, refCode):
  self.data = None
  self.VVwOya(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC4vHM():
 def __init__(self, VVmrHt, path, VVl0w9=None, curRowNum=-1):
  self.VVmrHt  = VVmrHt
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVl0w9  = VVl0w9
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFH6kH("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVCE60(curRowNum)
  else:
   FFikHE(self.VVmrHt, "Error while preparing edit!")
 def VVCE60(self, curRowNum):
  VV16hm = self.VV2KPc()
  VV9OiG = None #("Delete Line" , self.deleteLine  , [])
  VVSYUp = ("Save Changes" , self.VVp0bs   , [])
  VVOrFX  = ("Edit Line"  , self.VVspcs    , [])
  VVodFz = ("Line Options" , self.VVkUf5   , [])
  VVXhFg = (""    , self.VVGtrY , [])
  VVQOfi = self.VVW8Bw
  VVZVRH  = self.VVg4PT
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVujrY  = (CENTER  , LEFT  )
  VVzpqh = FFxW7z(self.VVmrHt, None, title=self.Title, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVOrFX=VVOrFX, VVodFz=VVodFz, VVQOfi=VVQOfi, VVZVRH=VVZVRH, VVXhFg=VVXhFg, VVvdC4=True
    , VVSYTz   = "#11001111"
    , VV8c5A   = "#11001111"
    , VVn7jC   = "#11001111"
    , VVQceP  = "#05333333"
    , VV2gSR  = "#00222222"
    , VV3wi4  = "#11331133"
    )
  VVzpqh.VVTdXg(curRowNum)
 def VVkUf5(self, VVzpqh, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVzpqh.VVYuPB()
  VVRj9e = []
  VVRj9e.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVRj9e.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVNfL8"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVsoxs:
   VVRj9e.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(  ("Delete Line"         , "deleteLine"   ))
  FFLATx(self.VVmrHt, boundFunction(self.VV2mln, VVzpqh, lineNum), VVRj9e=VVRj9e, title="Line Options")
 def VV2mln(self, VVzpqh, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVPAzU("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVzpqh)
   elif item == "VVNfL8"  : self.VVNfL8(VVzpqh, lineNum)
   elif item == "copyToClipboard"  : self.VVEYMF(VVzpqh, lineNum)
   elif item == "pasteFromClipboard" : self.VVom1h(VVzpqh, lineNum)
   elif item == "deleteLine"   : self.VVPAzU("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVzpqh)
 def VVg4PT(self, VVzpqh):
  VVzpqh.VV0zWr()
 def VVGtrY(self, VVzpqh, title, txt, colList):
  if   self.insertMode == 1: VVzpqh.VVskJD()
  elif self.insertMode == 2: VVzpqh.VVm6it()
  self.insertMode = 0
 def VVNfL8(self, VVzpqh, lineNum):
  if lineNum == VVzpqh.VVYuPB():
   self.insertMode = 1
   self.VVPAzU("echo '' >> '%s'" % self.tmpFile, VVzpqh)
  else:
   self.insertMode = 2
   self.VVPAzU("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVzpqh)
 def VVEYMF(self, VVzpqh, lineNum):
  global VVsoxs
  VVsoxs = FFT5H5("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVzpqh.VVjkTY("Copied to clipboard")
 def VVp0bs(self, VVzpqh, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFH6kH("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFH6kH("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVzpqh.VVjkTY("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVzpqh.VV0zWr()
    else:
     FFikHE(self.VVmrHt, "Cannot save file!")
   else:
    FFikHE(self.VVmrHt, "Cannot create backup copy of original file!")
 def VVW8Bw(self, VVzpqh):
  if self.fileChanged:
   FF2QoN(self.VVmrHt, boundFunction(self.VVczY6, VVzpqh), "Cancel changes ?")
  else:
   finalOK = os.system(FFH6kH("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVczY6(VVzpqh)
 def VVczY6(self, VVzpqh):
  VVzpqh.cancel()
  os.system(FFH6kH("rm -f '%s'" % self.tmpFile))
  if self.VVl0w9:
   self.VVl0w9(self.fileSaved)
 def VVspcs(self, VVzpqh, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VV1LkE + "ORIGINAL TEXT:\n" + VVyTfh + lineTxt
  FFJeIH(self.VVmrHt, boundFunction(self.VVyBKk, lineNum, VVzpqh), title="File Line", defaultText=lineTxt, message=message)
 def VVyBKk(self, lineNum, VVzpqh, VVUtSx):
  if not VVUtSx is None:
   if VVzpqh.VVYuPB() <= 1:
    self.VVPAzU("echo %s > '%s'" % (VVUtSx, self.tmpFile), VVzpqh)
   else:
    self.VVXpwz(VVzpqh, lineNum, VVUtSx)
 def VVom1h(self, VVzpqh, lineNum):
  if lineNum == VVzpqh.VVYuPB() and VVzpqh.VVYuPB() == 1:
   self.VVPAzU("echo %s >> '%s'" % (VVsoxs, self.tmpFile), VVzpqh)
  else:
   self.VVXpwz(VVzpqh, lineNum, VVsoxs)
 def VVXpwz(self, VVzpqh, lineNum, newTxt):
  VVzpqh.VV8kAl("Saving ...")
  lines = FFwZqG(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVzpqh.VVHcCa()
  VV16hm = self.VV2KPc()
  VVzpqh.VVgYkt(VV16hm)
 def VVPAzU(self, cmd, VVzpqh):
  tCons = CC82pG()
  tCons.ePopen(cmd, boundFunction(self.VVZ0VH, VVzpqh))
  self.fileChanged = True
  VVzpqh.VVHcCa()
 def VVZ0VH(self, VVzpqh, result, retval):
  VV16hm = self.VV2KPc()
  VVzpqh.VVgYkt(VV16hm)
 def VV2KPc(self):
  if fileExists(self.tmpFile):
   lines = FFwZqG(self.tmpFile)
   VV16hm = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV16hm.append((str(ndx), line.strip()))
   if not VV16hm:
    VV16hm.append((str(1), ""))
   return VV16hm
  else:
   FF9mKB(self.VVmrHt, self.tmpFile)
class CC1WKO():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVRj9e   = []
  self.satList   = []
 def VV6HGH(self, VVl0w9):
  self.VVRj9e = []
  VVRj9e, VVXeRR = self.VVij6I(False, True)
  if VVRj9e:
   self.VVRj9e += VVRj9e
   self.VVOqMM(VVl0w9, VVXeRR)
 def VV9UbP(self, mode, VVzpqh, satCol, VVl0w9):
  VVzpqh.VV8kAl("Loading Filters ...")
  self.VVRj9e = []
  self.VVRj9e.append(("All Services" , "all"))
  if mode == 1:
   self.VVRj9e.append(VVmGWQ)
   self.VVRj9e.append(("Parental Control", "parentalControl"))
   self.VVRj9e.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVRj9e.append(VVmGWQ)
   self.VVRj9e.append(("Selected Transponder"   , "selectedTP" ))
   self.VVRj9e.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV1YtB(VVzpqh, satCol)
  VVRj9e, VVXeRR = self.VVij6I(True, False)
  if VVRj9e:
   VVRj9e.insert(0, VVmGWQ)
   self.VVRj9e += VVRj9e
  VVzpqh.VVKeCF()
  self.VVOqMM(VVl0w9, VVXeRR)
 def VVKROE(self, VVRj9e, sats, VVl0w9):
  self.VVRj9e = VVRj9e
  VVRj9e, VVXeRR = self.VVij6I(True, False)
  if VVRj9e:
   self.VVRj9e.append(VVmGWQ)
   self.VVRj9e += VVRj9e
  self.VVOqMM(VVl0w9, VVXeRR)
 def VVOqMM(self, VVl0w9, VVXeRR):
  VVr5GC = ("Edit Filter", boundFunction(self.VVsNGB, VVXeRR))
  VVBBKW  = ("Filter Help", boundFunction(self.VVxkWb, VVXeRR))
  FFLATx(self.callingSELF, boundFunction(self.VVyvzz, VVl0w9), VVRj9e=self.VVRj9e, title="Select Filter", VVr5GC=VVr5GC, VVBBKW=VVBBKW)
 def VVyvzz(self, VVl0w9, item):
  if item:
   VVl0w9(item)
 def VVsNGB(self, VVXeRR, VVq5cQObj, sel):
  if fileExists(VVXeRR) : CC4vHM(self.callingSELF, VVXeRR, VVl0w9=None)
  else       : FF9mKB(self.callingSELF, VVXeRR)
  VVq5cQObj.cancel()
 def VVxkWb(self, VVXeRR, VVq5cQObj, sel):
  FFom2P(self.callingSELF, VVpTxo + "_help_service_filter", "Service Filter")
 def VV1YtB(self, VVzpqh, satColNum):
  if not self.satList:
   satList = VVzpqh.VVjZj8(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFleLE(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVmGWQ)
  if self.VVRj9e:
   self.VVRj9e += self.satList
 def VVij6I(self, addTag, VVztK4):
  FF7V9v()
  fileName  = "ajpanel_services_filter"
  VVXeRR = VVXKuz + fileName
  VVRj9e  = []
  if not fileExists(VVXeRR):
   os.system(FFH6kH("cp -f '%s' '%s'" % (VVpTxo + fileName, VVXeRR)))
  fileFound = False
  if fileExists(VVXeRR):
   fileFound = True
   lines = FFwZqG(VVXeRR)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVRj9e.append((line, "__w__" + line))
       else  : VVRj9e.append((line, line))
  if VVztK4:
   if   not fileFound : FF9mKB(self.callingSELF , VVXeRR)
   elif not VVRj9e : FF3XbB(self.callingSELF , VVXeRR)
  return VVRj9e, VVXeRR
 @staticmethod
 def VVYNyo(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCXiQX():
 def __init__(self, callingSELF, VVzpqh, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVzpqh = VVzpqh
  self.refCodeColNum = refCodeColNum
  self.VVRj9e = []
  iMulSel = self.VVzpqh.VVpQGN()
  if iMulSel : self.VVRj9e.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVRj9e.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVzpqh.VVpH5i()
  self.VVRj9e.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVRj9e.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVRj9e.append(VVmGWQ)
 def VVfylh(self, servName):
  tot = self.VVzpqh.VVpH5i()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVRj9e.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVX6W7_multi" ))
  else    : self.VVRj9e.append( ("Add to Bouquet : %s"      % servName , "VVX6W7_one" ))
 def VV1quF(self, servName, refCode):
  self.VVfylh(servName)
  self.VVBu71(servName, refCode)
 def VVobLB(self, servName, refCode, pcState, hidState):
  isMulti = self.VVzpqh.VVS8vj
  if isMulti:
   refCodeList = self.VVzpqh.VVe8MB(3)
   if refCodeList:
    self.VVRj9e.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVRj9e.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVRj9e.append(VVmGWQ)
    self.VVRj9e.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVRj9e.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVRj9e.pop(len(self.VVRj9e) - 1)
  else:
   if pcState == "No" : self.VVRj9e.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVRj9e.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVRj9e.append(VVmGWQ)
   if hidState == "No" : self.VVRj9e.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVRj9e.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVRj9e.append(VVmGWQ)
  self.VVfylh(servName)
  self.VVBu71(servName, refCode)
 def VVBu71(self, servName, refCode):
  FFLATx(self.callingSELF, boundFunction(self.VVKvTv, servName, refCode), title="Options", VVRj9e=self.VVRj9e)
 def VVKvTv(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVzpqh.VV0fYN(True)
   elif item == "MultSelDisab"     : self.VVzpqh.VV0fYN(False)
   elif item == "selectAll"     : self.VVzpqh.VVKfFs()
   elif item == "unselectAll"     : self.VVzpqh.VVidyT()
   elif item == "parentalControl_add"   : self.callingSELF.VV8Oa4(self.VVzpqh, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VV8Oa4(self.VVzpqh, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVSrC3(self.VVzpqh, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVSrC3(self.VVzpqh, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVsE0H(self.VVzpqh, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVsE0H(self.VVzpqh, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VV7iFM(self.VVzpqh, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VV7iFM(self.VVzpqh, False)
   elif item == "VVX6W7_multi"  : self.VVX6W7(refCode, True)
   elif item == "VVX6W7_one"  : self.VVX6W7(refCode, False)
 def VV1qKf(self, VVzpqh):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCXiQX(self, VVzpqh, 3)
  mSel.VV1quF(servName, refCode)
 def VVX6W7(self, refCode, isMulti):
  bouquets = FFylDs()
  if bouquets:
   VVRj9e = []
   for item in bouquets:
    VVRj9e.append((item[0], item[1].toString()))
   VVr5GC = ("Create New", boundFunction(self.VVAsmg, refCode, isMulti))
   FFLATx(self.callingSELF, boundFunction(self.VVqk5X, refCode, isMulti), VVRj9e=VVRj9e, title="Add to Bouquet", VVr5GC=VVr5GC, VVhiDK=True, VVrTTp=True)
  else:
   FF2QoN(self.callingSELF, boundFunction(self.VVy4K9, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVqk5X(self, refCode, isMulti, bName=None):
  if bName:
   FFjNEj(self.VVzpqh, boundFunction(self.VVMeRo, refCode, isMulti, bName), title="Adding Channels ...")
 def VVMeRo(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVDfPD(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVy039 = InfoBar.instance
    if VVy039:
     VVUSso = VVy039.servicelist
     if VVUSso:
      mutableList = VVUSso.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVzpqh.VVKeCF()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FF7k8q(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFikHE(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVDfPD(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVzpqh.VVe8MB(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVAsmg(self, refCode, isMulti, VVq5cQObj, path):
  self.VVy4K9(refCode, isMulti)
 def VVy4K9(self, refCode, isMulti):
  FFJeIH(self.callingSELF, boundFunction(self.VVnyw7, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVnyw7(self, refCode, isMulti, name):
  if name:
   FFjNEj(self.VVzpqh, boundFunction(self.VVDaob, refCode, isMulti, name), title="Adding Channels ...")
 def VVDaob(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVDfPD(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVy039 = InfoBar.instance
    if VVy039:
     VVUSso = VVy039.servicelist
     if VVUSso:
      try:
       VVUSso.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVUSso.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVzpqh.VVKeCF()
   title = "Add to Bouquet"
   if allOK: FF7k8q(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFikHE(self.callingSELF, "Nothing added!", title=title)
class CC52EY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVeoVT, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFpJPp(self)
  FFpqes(self["keyRed"]  , "Exit")
  FFpqes(self["keyGreen"]  , "Save")
  FFpqes(self["keyYellow"] , "Refresh")
  FFpqes(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVUXbc  ,
   "green"   : self.VVyuw8 ,
   "yellow"  : self.VVUxeh  ,
   "blue"   : self.VVeTTH   ,
   "up"   : self.VVFwmU    ,
   "down"   : self.VV5ndD   ,
   "left"   : self.VVWfTh   ,
   "right"   : self.VV6a4U   ,
   "cancel"  : self.VVUXbc
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVUxeh()
  self.VVvICD()
  FFKDC6(self)
 def VVUXbc(self) : self.close(True)
 def VVJwmf(self) : self.close(False)
 def VVeTTH(self):
  self.session.openWithCallback(self.VVreEt, boundFunction(CCCza3))
 def VVreEt(self, closeAll):
  if closeAll:
   self.close()
 def VVFwmU(self):
  self.VVoTHj(1)
 def VV5ndD(self):
  self.VVoTHj(-1)
 def VVWfTh(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVvICD()
 def VV6a4U(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVvICD()
 def VVoTHj(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVxqls(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVxqls(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVxqls(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVBAbC(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVBAbC(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVvICD(self):
  for obj in self.list:
   FFL3RG(obj, "#11404040")
  FFL3RG(self.list[self.index], "#11ff8000")
 def VVUxeh(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVyuw8(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC82pG()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVjEob)
 def VVjEob(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF7k8q(self, "Nothing returned from the system!")
  else:
   FF7k8q(self, str(result))
class CCCza3(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVoavT, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFpJPp(self, addLabel=True)
  FFpqes(self["keyRed"]  , "Exit")
  FFpqes(self["keyGreen"]  , "Sync")
  FFpqes(self["keyYellow"] , "Refresh")
  FFpqes(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVUXbc   ,
   "green"   : self.VVgZZF  ,
   "yellow"  : self.VVqE8a ,
   "blue"   : self.VVbZys  ,
   "cancel"  : self.VVUXbc
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVxyVt()
  self.onShow.append(self.start)
 def start(self):
  FFbH1W(self.refresh)
  FFKDC6(self)
 def refresh(self):
  self.VVcVJ7()
  self.VVU0sx(False)
 def VVUXbc(self)  : self.close(True)
 def VVbZys(self) : self.close(False)
 def VVxyVt(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVcVJ7(self):
  self.VV7lKF()
  self.VVvTpA()
  self.VV2uvM()
  self.VV8K08()
 def VVqE8a(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVxyVt()
   self.VVcVJ7()
   FFbH1W(self.refresh)
 def VVgZZF(self):
  if len(self["keyGreen"].getText()) > 0:
   FF2QoN(self, self.VVloST, "Synchronize with Internet Date/Time ?")
 def VVloST(self):
  self.VVcVJ7()
  FFbH1W(boundFunction(self.VVU0sx, True))
 def VV7lKF(self)  : self["keyRed"].show()
 def VVqmtz(self)  : self["keyGreen"].show()
 def VVMSaX(self) : self["keyYellow"].show()
 def VVLV5i(self)  : self["keyBlue"].show()
 def VVvTpA(self)  : self["keyGreen"].hide()
 def VV2uvM(self) : self["keyYellow"].hide()
 def VV8K08(self)  : self["keyBlue"].hide()
 def VVU0sx(self, sync):
  localTime = FFHy2o()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVfZlN(server)
   if epoch_time is not None:
    ntpTime = FFIb5k(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC82pG()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVjEob, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVMSaX()
  self.VVLV5i()
  if ok:
   self.VVqmtz()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVjEob(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVU0sx(False)
  except:
   pass
 def VVfZlN(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFcX1Z():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCXD05(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRqpN(VVAopB, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFpJPp(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFbH1W(self.VV39ZG)
 def VV39ZG(self):
  if FFcX1Z(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFL3RG(self["myBody"], color)
   FFL3RG(self["myLabel"], color)
  except:
   pass
class CCnwKs(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFRhrh()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFRqpN(VVDtsd, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCWatn(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCWatn(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCWatn(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCRz4x()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFpJPp(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVFwmU          ,
   "down"  : self.VV5ndD         ,
   "left"  : self.VVWfTh         ,
   "right"  : self.VV6a4U         ,
   "info"  : self.VVTDOz        ,
   "epg"  : self.VVTDOz        ,
   "menu"  : self.VVAUZW         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VViyV6       ,
   "last"  : boundFunction(self.VVZarP, -1)  ,
   "next"  : boundFunction(self.VVZarP, 1)  ,
   "pageUp" : boundFunction(self.VVMBz5, True) ,
   "chanUp" : boundFunction(self.VVMBz5, True) ,
   "pageDown" : boundFunction(self.VVMBz5, False) ,
   "chanDown" : boundFunction(self.VVMBz5, False) ,
   "0"   : boundFunction(self.VVZarP, 0)  ,
   "1"   : boundFunction(self.VV0RbI, pos=1) ,
   "2"   : boundFunction(self.VV0RbI, pos=2) ,
   "3"   : boundFunction(self.VV0RbI, pos=3) ,
   "4"   : boundFunction(self.VV0RbI, pos=4) ,
   "5"   : boundFunction(self.VV0RbI, pos=5) ,
   "6"   : boundFunction(self.VV0RbI, pos=6) ,
   "7"   : boundFunction(self.VV0RbI, pos=7) ,
   "8"   : boundFunction(self.VV0RbI, pos=8) ,
   "9"   : boundFunction(self.VV0RbI, pos=9) ,
  }, -1)
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self.sliderSNR.VVN3mS()
  self.sliderAGC.VVN3mS()
  self.sliderBER.VVN3mS(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV0RbI()
  self.VVVgYDInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVVgYD)
  except:
   self.timer.callback.append(self.VVVgYD)
  self.timer.start(500, False)
 def VVVgYDInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVDsgG(service)
  serviceName = self.tunerInfo.VVy1NW()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  tp = CCWZOp()
  txt = tp.VV5ocI(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVVgYD(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVDsgG(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVODik())
   self["mySNR"].setText(self.tunerInfo.VVYOMl())
   self["myAGC"].setText(self.tunerInfo.VVSK5c())
   self["myBER"].setText(self.tunerInfo.VVCPKC())
   self.sliderSNR.VVJwPO(self.tunerInfo.VVEg3r())
   self.sliderAGC.VVJwPO(self.tunerInfo.VV7xA9())
   self.sliderBER.VVJwPO(self.tunerInfo.VVZoq4())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVJwPO(0)
   self.sliderAGC.VVJwPO(0)
   self.sliderBER.VVJwPO(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
    if state and not state == "Tuned":
     FFNWTN(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVTDOz(self):
  FFgBdr(self, fncMode=CCR0BS.VVAF5u)
 def VVAUZW(self):
  FFom2P(self, VVpTxo + "_help_signal", "Signal Monitor (Keys)")
 def VViyV6(self):
  self.session.open(CCxKzH, isFromExternal=self.isFromExternal)
  self.close()
 def VVFwmU(self)  : self.VV0RbI(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV5ndD(self) : self.VV0RbI(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVWfTh(self) : self.VV0RbI(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV6a4U(self) : self.VV0RbI(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV0RbI(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVZarP(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFsOVH(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVMBz5(self, isUp):
  FFNWTN(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVVgYDInfo()
  except:
   pass
class CCWatn(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVN3mS(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFL3RG(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVpTxo +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFL3RG(self.covObj, self.covColor)
   else:
    FFL3RG(self.covObj, "#00006688")
    self.isColormode = True
  self.VVJwPO(0)
 def VVJwPO(self, val):
  val  = FFsOVH(val, self.minN, self.maxN)
  width = int(FFmOj8(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFsOVH(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCtIzA(Screen):
 VVL4ds    = 0
 VVu45l = 1
 VVpyWB = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVl0w9=None, barTheme=VVL4ds):
  ratio = self.VVCvbi(barTheme)
  self.skin, self.skinParam = FFRqpN(VVHQsb, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVl0w9 = VVl0w9
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVXjH0 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFpJPp(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self.VVbXWG()
  self["myProgBarVal"].setText("0%")
  FFL3RG(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVA5Fs()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVA5Fs)
  except:
   self.timer.callback.append(self.VVA5Fs)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVeQL2(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV5AWx_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVXjH0), self.counter, self.maxValue, catName)
 def VV5AWx_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV5AWx_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVA5Fs()
  except:
   pass
 def VVxenn(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVXjH0), self.counter, self.maxValue)
  except:
   pass
 def VV2U9h(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVdjYB(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVlFD6(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFNWTN(self, "Cancelling ...")
  self.isCancelled = True
  self.VV9qLa(False)
 def VV9qLa(self, isDone):
  if self.VVl0w9:
   self.VVl0w9(isDone, self.VVXjH0, self.counter, self.maxValue, self.isError)
  self.close()
 def VVA5Fs(self):
  val = FFsOVH(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFmOj8(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VV9qLa(True)
 def VVbXWG(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVu45l, self.VVpyWB):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVCvbi(self, barTheme):
  if   barTheme == self.VVu45l : return 0.7
  if   barTheme == self.VVpyWB : return 0.5
  else             : return 1
class CC82pG(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVl0w9 = {}
  self.commandRunning = False
  self.VVcKW9  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVl0w9, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVl0w9[name] = VVl0w9
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVcKW9:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVMQkO, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VV2Sti , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVMQkO, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VV2Sti , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV2Sti(name, retval)
  return True
 def VVMQkO(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV2Sti(self, name, retval):
  if not self.VVcKW9:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVl0w9[name]:
   self.VVl0w9[name](self.appResults[name], retval)
  del self.VVl0w9[name]
 def VVi40x(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCWAnM(Screen):
 def __init__(self, session, title="", VV46qm=None, VV6z3U=False, VVAM3E=False, VVOdjF=False, VVQ20z=False, VVhDbY=False, VVj4jG=False, VVjlB2=VVFcS3, VV7kSC=None, VVPjJV=False, VV87Dz=None, VVZr1Z="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFRqpN(VV7AyH, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFpJPp(self, addScrollLabel=True)
  if not VVZr1Z:
   VVZr1Z = "Processing ..."
  self["myLabel"].setText("   %s" % VVZr1Z)
  self.VV6z3U   = VV6z3U
  self.VVAM3E   = VVAM3E
  self.VVOdjF   = VVOdjF
  self.VVQ20z  = VVQ20z
  self.VVhDbY = VVhDbY
  self.VVj4jG = VVj4jG
  self.VVjlB2   = VVjlB2
  self.VV7kSC = VV7kSC
  self.VVPjJV  = VVPjJV
  self.VV87Dz  = VV87Dz
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC82pG()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFSTdn()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV46qm, str):
   self.VV46qm = [VV46qm]
  else:
   self.VV46qm = VV46qm
  if self.VVOdjF or self.VVQ20z:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVM6J3, VVM6J3)
   self.VV46qm.append("echo -e '\n%s\n' %s" % (restartNote, FFMRMu(restartNote, VVJF5Y)))
   if self.VVOdjF:
    self.VV46qm.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV46qm.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVhDbY:
   FFNWTN(self, "Processing ...")
  self.onLayoutFinish.append(self.VVhcMj)
  self.onClose.append(self.VVeMiK)
 def VVhcMj(self):
  self["myLabel"].VVGV2Z(textOutFile="console" if self.enableSaveRes else "")
  if self.VV6z3U:
   self["myLabel"].VVJmq8()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVodOV()
  else:
   self.VV8ud1()
 def VVodOV(self):
  if FFcX1Z():
   self["myLabel"].setText("Processing ...")
   self.VV8ud1()
  else:
   self["myLabel"].setText(FFhTMc("\n   No connection to internet!", VVtODU))
 def VV8ud1(self):
  allOK = self.container.ePopen(self.VV46qm[0], self.VVTlkc, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVTlkc("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVj4jG or self.VVOdjF or self.VVQ20z:
    self["myLabel"].setText(FFO6Fd("STARTED", VVJF5Y) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV87Dz:
   colorWhite = CCacbo.VVYaeM(VV1LkE)
   color  = CCacbo.VVYaeM(self.VV87Dz[0])
   words  = self.VV87Dz[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVjlB2=self.VVjlB2)
 def VVTlkc(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV46qm):
   allOK = self.container.ePopen(self.VV46qm[self.cmdNum], self.VVTlkc, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVTlkc("Cannot connect to Console!", -1)
  else:
   if self.VVhDbY and FFtZy4(self):
    FFNWTN(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVj4jG:
    self["myLabel"].appendText("\n" + FFO6Fd("FINISHED", VVJF5Y), self.VVjlB2)
   if self.VV6z3U or self.VVAM3E:
    self["myLabel"].VVJmq8()
   if self.VV7kSC is not None:
    self.VV7kSC()
   if not retval and self.VVPjJV:
    self.VVeMiK()
 def VVeMiK(self):
  if self.container.VVi40x():
   self.container.killAll()
class CCiaN0(Screen):
 def __init__(self, session, VV46qm=None, VVhDbY=False):
  self.skin, self.skinParam = FFRqpN(VV7AyH, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVXKuz + "ajpanel_terminal.history"
  self.customCommandsFile = VVXKuz + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFT5H5("pwd") or "/home/root"
  self.container   = CC82pG()
  FFpJPp(self, addScrollLabel=True)
  FFpqes(self["keyRed"] , "Exit = Stop Command")
  FFpqes(self["keyGreen"] , "OK = History")
  FFpqes(self["keyYellow"], "Menu = Custom Cmds")
  FFpqes(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV3qKZ ,
   "cancel" : self.VVcYOK  ,
   "menu"  : self.VVNUZK ,
   "last"  : self.VVXxFQ  ,
   "next"  : self.VVXxFQ  ,
   "1"   : self.VVXxFQ  ,
   "2"   : self.VVXxFQ  ,
   "3"   : self.VVXxFQ  ,
   "4"   : self.VVXxFQ  ,
   "5"   : self.VVXxFQ  ,
   "6"   : self.VVXxFQ  ,
   "7"   : self.VVXxFQ  ,
   "8"   : self.VVXxFQ  ,
   "9"   : self.VVXxFQ  ,
   "0"   : self.VVXxFQ
  })
  self.onLayoutFinish.append(self.VVk68Z)
  self.onClose.append(self.VVt4n3)
 def VVk68Z(self):
  self["myLabel"].VVGV2Z(isResizable=False, textOutFile="terminal")
  FFOEeE(self["keyRed"]  , "#00ff8000")
  FFL3RG(self["keyRed"]  , self.skinParam["titleColor"])
  FFL3RG(self["keyGreen"]  , self.skinParam["titleColor"])
  FFL3RG(self["keyYellow"] , self.skinParam["titleColor"])
  FFL3RG(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVh8HD(FFT5H5("date"), 5)
  result = FFT5H5("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VV4xxt()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVpTxo + "LinuxCommands.lst"
   newTemplate = VVpTxo + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFH6kH("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFH6kH("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVt4n3(self):
  if self.container.VVi40x():
   self.container.killAll()
   self.VVh8HD("Process killed\n", 4)
   self.VV4xxt()
 def VVcYOK(self):
  if self.container.VVi40x():
   self.VVt4n3()
  else:
   FF2QoN(self, self.close, "Exit ?", VVqxqt=False)
 def VV4xxt(self):
  self.VVh8HD(self.prompt, 1)
  self["keyRed"].hide()
 def VVh8HD(self, txt, mode):
  if   mode == 1 : color = VVJF5Y
  elif mode == 2 : color = VVejU1
  elif mode == 3 : color = VV1LkE
  elif mode == 4 : color = VVtODU
  elif mode == 5 : color = VVyTfh
  elif mode == 6 : color = VVWmbA
  else   : color = VV1LkE
  try:
   self["myLabel"].appendText(FFhTMc(txt, color))
  except:
   pass
 def VVUKhh(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVh8HD(cmd, 2)
   self.VVh8HD("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVh8HD(ch, 0)
   self.VVh8HD("\nor\n", 4)
   self.VVh8HD("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VV4xxt()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFhTMc(parts[0].strip(), VVejU1)
    right = FFhTMc("#" + parts[1].strip(), VVWmbA)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVh8HD(txt, 2)
   lastLine = self.VVfBdU()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV8E1s(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVTlkc, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFikHE(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVh8HD(data, 3)
 def VVTlkc(self, data, retval):
  if not retval == 0:
   self.VVh8HD("Exit Code : %d\n" % retval, 4)
  self.VV4xxt()
 def VV3qKZ(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVfBdU() == "":
   self.VV8E1s("cd /tmp")
   self.VV8E1s("ls")
  VV16hm = []
  if fileExists(self.commandHistoryFile):
   lines  = FFwZqG(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV16hm.append((str(c), line, str(lNum)))
   self.VVyYci(VV16hm, title, self.commandHistoryFile, isHistory=True)
  else:
   FF9mKB(self, self.commandHistoryFile, title=title)
 def VVfBdU(self):
  lastLine = FFT5H5("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV8E1s(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVNUZK(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFwZqG(self.customCommandsFile)
   lastLineIsSep = False
   VV16hm = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV16hm.append((str(c), line, str(lNum)))
   self.VVyYci(VV16hm, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF9mKB(self, self.customCommandsFile, title=title)
 def VVyYci(self, VV16hm, title, filePath=None, isHistory=False):
  if VV16hm:
   VVQceP = "#05333333"
   if isHistory: VVSYTz = VV8c5A = VVn7jC = "#11000020"
   else  : VVSYTz = VV8c5A = VVn7jC = "#06002020"
   VVM10w = VVodFz = None
   VVOrFX   = ("Send"   , self.VVlsGa        , [])
   VVSYUp  = ("Modify & Send" , self.VVdf08        , [])
   if isHistory:
    VVM10w = ("Clear History" , self.VVjwci        , [])
   elif filePath:
    VVodFz = ("Edit File"  , boundFunction(self.VVMwoP, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVujrY     = (CENTER  , LEFT   , CENTER )
   FFxW7z(self, None, title=title, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVSYUp=VVSYUp, VVM10w=VVM10w, VVodFz=VVodFz, VVvdC4=True
     , VVSYTz   = VVSYTz
     , VV8c5A   = VV8c5A
     , VVn7jC   = VVn7jC
     , VVM9HS  = "#05ffff00"
     , VVQceP  = VVQceP
    )
  else:
   FF3XbB(self, filePath, title=title)
 def VVlsGa(self, VVzpqh, title, txt, colList):
  cmd = colList[1].strip()
  VVzpqh.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVh8HD("\n%s\n" % cmd, 6)
   self.VVh8HD(self.prompt, 1)
  else:
   self.VVUKhh(cmd)
 def VVdf08(self, VVzpqh, title, txt, colList):
  cmd = colList[1]
  self.VVQoj9(VVzpqh, cmd)
 def VVjwci(self, VVzpqh, title, txt, colList):
  FF2QoN(self, boundFunction(self.VV2NUt, VVzpqh), "Reset History File ?", title="Command History")
 def VV2NUt(self, VVzpqh):
  os.system(FFH6kH("echo '' > %s" % self.commandHistoryFile))
  VVzpqh.cancel()
 def VVMwoP(self, filePath, VVzpqh, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC4vHM(self, filePath, VVl0w9=boundFunction(self.VVEJwk, VVzpqh), curRowNum=rowNum)
  else     : FF9mKB(self, filePath)
 def VVEJwk(self, VVzpqh, fileChanged):
  if fileChanged:
   VVzpqh.cancel()
   FFbH1W(self.VVNUZK)
 def VVXxFQ(self):
  self.VVQoj9(None, self.lastCommand)
 def VVQoj9(self, VVzpqh, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFJeIH(self, boundFunction(self.VV1hVD, VVzpqh), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VV1hVD(self, VVzpqh, cmd):
  if cmd and len(cmd) > 0:
   self.VVUKhh(cmd)
   if VVzpqh:
    VVzpqh.cancel()
class CCKddj(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVUtSx="", VVgvsD=False, VVoHYj=False, isTrimEnds=True):
  self.skin, self.skinParam = FFRqpN(VVuNXI, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFpJPp(self, title, addLabel=True)
  FFpqes(self["keyRed"] , "Up/Down = Change")
  FFpqes(self["keyGreen"] , "Overwrite")
  FFpqes(self["keyYellow"], "Pick Key Map")
  FFpqes(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVoHYj   = VVoHYj
  self.VVgvsD  = VVgvsD
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVUtSx, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVcw3E      ,
   "green"    : self.VVDo3t    ,
   "yellow"   : self.VVqp3G      ,
   "blue"    : self.VV0R7F     ,
   "menu"    : self.VVwB7y     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVFvwE, True) ,
   "down"    : boundFunction(self.VVFvwE, False) ,
   "left"    : self.VV1wXa       ,
   "right"    : self.VVYdFq       ,
   "home"    : self.VVFBqm       ,
   "end"    : self.VVm09W       ,
   "next"    : self.VVcAOf      ,
   "last"    : self.VVf0al      ,
   "deleteForward"  : self.VVcAOf      ,
   "deleteBackward" : self.VVf0al      ,
   "tab"    : self.VV5kuc       ,
   "toggleOverwrite" : self.VVDo3t    ,
   "0"     : self.VVbqYn     ,
   "1"     : self.VVbqYn     ,
   "2"     : self.VVbqYn     ,
   "3"     : self.VVbqYn     ,
   "4"     : self.VVbqYn     ,
   "5"     : self.VVbqYn     ,
   "6"     : self.VVbqYn     ,
   "7"     : self.VVbqYn     ,
   "8"     : self.VVbqYn     ,
   "9"     : self.VVbqYn
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VV5f9h()
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFe9R7(self)
  self["myLabel"].setText(self.message)
  self.VVDilT()
  if self.VVgvsD : self.VVDo3t()
  else    : self.VVsdeW()
  FFKDC6(self)
  FFL3RG(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVgQoP)
  except:
   self.timer.callback.append(self.VVgQoP)
 def onExit(self):
  self.timer.stop()
 def VVcw3E(self):
  self.VVzDu8()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVzDu8()
  self.close(None)
 def VVwB7y(self):
  VVRj9e = []
  VVRj9e.append(("Home"         , "home"    ))
  VVRj9e.append(("End"         , "end"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Clear All"       , "clearAll"   ))
  VVRj9e.append(("Clear To Home"      , "clearToHome"   ))
  VVRj9e.append(("Clear To End"       , "clearToEnd"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVsoxs:
   VVRj9e.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("To Capital Letters"     , "toCapital"   ))
  VVRj9e.append(("To Small Letters"      , "toSmall"    ))
  FFLATx(self, self.VVWnBh, title="Edit Options", VVRj9e=VVRj9e)
 def VVWnBh(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVFBqm()
   elif item == "end"     : self.VVm09W()
   elif item == "clearAll"    : self.VVuZbl()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVFBqm()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVsoxs
    VVsoxs = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVsoxs)
    self.VVFBqm()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVgQoP(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVDo3t(self):
  self["myInput"].toggleOverwrite()
  self.VVsdeW()
 def VVqp3G(self):
  self.session.openWithCallback(self.VVVqJu, boundFunction(CCnif2, mode=self.charMode, VVoHYj=self.VVoHYj))
 def VVVqJu(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVDilT()
 def VVsdeW(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VV5f9h(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVzDu8(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVwaof(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VV1wXa(self)     : self.VVDxIi(self["myInput"].left)
 def VVYdFq(self)     : self.VVDxIi(self["myInput"].right)
 def VVcAOf(self)     : self.VVDxIi(self["myInput"].delete)
 def VVFBqm(self)     : self.VVDxIi(self["myInput"].home)
 def VVm09W(self)     : self.VVDxIi(self["myInput"].end)
 def VVf0al(self)    : self.VVDxIi(self["myInput"].deleteBackward)
 def VV5kuc(self)     : self.VVDxIi(self["myInput"].tab)
 def VVuZbl(self)     : self["myInput"].setText("")
 def VVDxIi(self, fnc):
  fnc()
  self.VVgQoP()
 def VVbqYn(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVwaof(newChar, overwrite)
   self.VV4559(newChar, self["myInput"].mapping[number])
 def VVFvwE(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCnif2.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCnif2.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVwaof(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV4559(newChar, group)
     break
 def VV4559(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VV1LkE:
    group = VVyTfh + group.replace(newChar, FFhTMc(newChar, VV1LkE, VVyTfh))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VV0R7F(self):
  if self.VVoHYj : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVDilT()
 def VVDilT(self):
  self["myInput"].mapping = CCnif2.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCnif2.RCU_MAP_TITLES[self.charMode])
class CCnif2(Screen):
 VV4E5H  = 0
 VVHGeR  = 1
 VV2dzs  = 2
 VV2b2c  = 3
 VVfnjh = 4
 VVG3AD = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VV4E5H, VVoHYj=False):
  self.skin, self.skinParam = FFRqpN(VVfZlu, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVoHYj  = VVoHYj
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFpJPp(self, title=self.Title)
  FFpqes(self["keyRed"] ,"OK = Select")
  FFpqes(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVvaDg     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVtSRB, -1) ,
   "next"  : boundFunction(self.VVtSRB, +1) ,
   "left"  : boundFunction(self.VVtSRB, -1) ,
   "right"  : boundFunction(self.VVtSRB, +1) ,
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFL3RG(self["keyRed"], "#11222222")
  FFL3RG(self["keyGreen"], "#11222222")
  self.VVw4Lr()
 def VVw4Lr(self):
  self.VV0YoY()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VV0YoY(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVtSRB(self, direction):
  if self.VVoHYj : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVw4Lr()
 def VVvaDg(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCrmmz(Screen):
 def __init__(self, session, title="", message="", VVjlB2=VVFcS3, VVsLA9=False, VVn7jC=None, VVfhdd=30, canSaveToFile=""):
  self.skin, self.skinParam = FFRqpN(VV7AyH, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVfhdd)
  self.session   = session
  FFpJPp(self, title, addScrollLabel=True)
  self.VVjlB2   = VVjlB2
  self.VVsLA9   = VVsLA9
  self.VVn7jC   = VVn7jC
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self["myLabel"].VVGV2Z(VVsLA9=self.VVsLA9, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVjlB2)
  if self.VVn7jC:
   FFL3RG(self["myBody"], self.VVn7jC)
   FFL3RG(self["myLabel"], self.VVn7jC)
   FFBx6G(self["myLabel"], self.VVn7jC)
  self["myLabel"].VVJmq8()
class CCosR8(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFRqpN(VV7eYp, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFpJPp(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFMmCK(self["errPic"], "err")
class CC2WBM(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFRqpN(VVggSt, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFpJPp(self, " ", addCloser=True)
class CCQGI5():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CC2WBM, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVUnS0)
  except:
   self.timer.callback.append(self.VVUnS0)
  self.timer.start(1500, True)
 def VVUnS0(self):
  self.session.deleteDialog(self.win)
class CCtZ0M():
 VVC86a    = 0
 VVRFWI  = 1
 VVdnH4   = ""
 VVJHfk    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVzpqh   = None
  self.timer     = eTimer()
  self.VVpEKW   = 0
  self.VVZeiB  = 1
  self.VVOpkK  = 2
  self.VVhEq4   = 3
  self.VVzdoj   = 4
  VV16hm = self.VVFkyJ()
  if VV16hm:
   self.VVzpqh = self.VVvwav(VV16hm)
  if not VV16hm and mode == self.VVC86a:
   self.VVztK4or("Download list is empty !")
   self.cancel()
  if mode == self.VVRFWI:
   FFjNEj(self.VVzpqh or self.SELF, boundFunction(self.VVbSwb, startDnld, decodedUrl), title="Checking Server ...")
  self.VV7tCY(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV7tCY)
  except:
   self.timer.callback.append(self.VV7tCY)
  self.timer.start(1000, False)
 def VVvwav(self, VV16hm):
  VV16hm.sort(key=lambda x: int(x[0]))
  VVQOfi = self.VV2c90
  VVOrFX  = ("Play"  , self.VVLuWC , [])
  VVEJ7p = (""   , self.VVOBVV  , [])
  VV9OiG = ("Stop"  , self.VVHz0r  , [])
  VVSYUp = ("Resume"  , self.VVddLV , [])
  VVM10w = ("Options" , self.VVaeZL  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVujrY  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFxW7z(self.SELF, None, title=self.Title, header=header, VV9o2E=VV16hm, VVujrY=VVujrY, VVec0v=widths, VVfhdd=26, VVOrFX=VVOrFX, VVEJ7p=VVEJ7p, VVQOfi=VVQOfi, VV9OiG=VV9OiG, VVSYUp=VVSYUp, VVM10w=VVM10w, VV8c5A="#11110011", VVSYTz="#11220022", VVn7jC="#11110011", VVM9HS="#00ffff00", VVQceP="#00223025", VV2gSR="#0a333333", VV3wi4="#0a400040", VVvdC4=True, searchCol=1)
 def VVFkyJ(self):
  lines = CCtZ0M.VVlKmy()
  VV16hm = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVMluF(decodedUrl)
      if fName:
       if   FFeKZd(decodedUrl) : sType = "Movie"
       elif FFF8Lk(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVTp1x(decodedUrl, fName)
       if size > -1: sizeTxt = CCMTIp.VVJrmt(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV16hm.append((str(len(VV16hm) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV16hm
 def VVzwwy(self):
  VV16hm = self.VVFkyJ()
  if VV16hm:
   if self.VVzpqh : self.VVzpqh.VVgYkt(VV16hm, VVxyVtMsg=False)
   else     : self.VVzpqh = self.VVvwav(VV16hm)
  else:
   self.cancel()
 def VV7tCY(self, force=False):
  if self.VVzpqh:
   thrList = self.VVesP6()
   VV16hm = []
   changed = False
   for ndx, row in enumerate(self.VVzpqh.VVbBP2()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVpEKW
    if m3u8Log:
     percent = self.VVsMUh(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVhEq4 , "%.2f %%" % percent
      else   : flag, progr = self.VVzdoj , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFtYtQ(mPath)
     if curSize > -1:
      fSize = CCMTIp.VVJrmt(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCMTIp.VVJrmt(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFtYtQ(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVhEq4 , "%.2f %%" % percent
       else   : flag, progr = self.VVzdoj , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCMTIp.VVJrmt(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVOpkK
     if m3u8Log :
      if not speed and not force : flag = self.VVZeiB
      elif curSize == -1   : self.VVHGaB(False)
    elif flag == self.VVpEKW  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVpEKW  : color2 = "#f#00555555#"
    elif flag == self.VVZeiB : color2 = "#f#0000FFFF#"
    elif flag == self.VVOpkK : color2 = "#f#0000FFFF#"
    elif flag == self.VVhEq4  : color2 = "#f#00FF8000#"
    elif flag == self.VVzdoj  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV4sdO(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV16hm.append(row)
   if changed or force:
    self.VVzpqh.VVgYkt(VV16hm, VVxyVtMsg=False)
 def VV4sdO(self, flag):
  tDict = self.VVqsvp()
  return tDict.get(flag, "?")
 def VVFrsR(self, state):
  for flag, txt in self.VVqsvp().items():
   if txt == state:
    return flag
  return -1
 def VVqsvp(self):
  return { self.VVpEKW: "Not started", self.VVZeiB: "Connecting", self.VVOpkK: "Downloading", self.VVhEq4: "Stopped", self.VVzdoj: "Completed" }
 def VVVPUb(self, title):
  colList = self.VVzpqh.VV8Eyg()
  path = colList[6]
  url  = colList[8]
  if self.VVVbOb() : self.VVztK4or("Cannot delete !\n\nFile is downloading.")
  else      : FF2QoN(self.SELF, boundFunction(self.VV5D3O, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV5D3O(self, path, url):
  m3u8Log = self.VVzpqh.VV8Eyg()[12].strip()
  if m3u8Log : os.system(FFH6kH("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFH6kH("rm -r '%s'" % path))
  self.VVbnqN(False)
  self.VVzwwy()
 def VVbnqN(self, VVztK4=True):
  if self.VVVbOb():
   FFNWTN(self.VVzpqh, self.VV4sdO(self.VVOpkK), 500)
  else:
   colList  = self.VVzpqh.VV8Eyg()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVFrsR(state) in (self.VVpEKW, self.VVzdoj, self.VVhEq4):
    lines = CCtZ0M.VVlKmy()
    newLines = []
    found = False
    for line in lines:
     if CCtZ0M.VV5ZYq(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVxtdU(newLines)
     self.VVzwwy()
     FFNWTN(self.VVzpqh, "Removed.", 1000)
    else:
     FFNWTN(self.VVzpqh, "Not found.", 1000)
   elif VVztK4:
    self.VVztK4or("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVYWMg(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FF2QoN(self.SELF, boundFunction(self.VVurVk, flag), ques, title=title)
 def VVurVk(self, flag):
  list = []
  for ndx, row in enumerate(self.VVzpqh.VVbBP2()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVFrsR(state)
   if   flag == flagVal == self.VVzdoj: list.append(decodedUrl)
   elif flag == flagVal == self.VVpEKW : list.append(decodedUrl)
  lines = CCtZ0M.VVlKmy()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVxtdU(newLines)
   self.VVzwwy()
   FFNWTN(self.VVzpqh, "%d removed." % totRem, 1000)
  else:
   FFNWTN(self.VVzpqh, "Not found.", 1000)
 def VV5pmj(self):
  colList  = self.VVzpqh.VV8Eyg()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFNWTN(self.VVzpqh, "Poster exists", 1500)
  else    : FFjNEj(self.VVzpqh, boundFunction(self.VVz9KS, decodedUrl, path, png), title="Checking Server ...")
 def VVz9KS(self, decodedUrl, path, png):
  err = self.VVh3ej(decodedUrl, path, png)
  if err:
   FFikHE(self.SELF, err, title="Poster Download")
 def VVh3ej(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CC1ywg.VV3YGN(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCfMBx.VVTzl0(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCfMBx.VVlh6L(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCfMBx.VV7oGw(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFnx0u(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFH6kH("mv -f '%s' '%s'" % (tPath, png)))
   CCZG9b.VVlyqK(self.SELF, VVgyZU=png, showGrnMsg="Downloaded")
   return ""
 def VVOBVV(self, VVzpqh, title, txt, colList):
  def VVWMqO(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVm7lK(key, val) : return "\n%s:\n%s\n" % (FFhTMc(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVzpqh.VVkO6k()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVWMqO(heads[i]  , CCMTIp.VVJrmt(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVWMqO("Downloaded" , CCMTIp.VVJrmt(int(curSize), mode=0))
   else:
    txt += VVWMqO(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVm7lK(heads[i], colList[i])
  FFCsft(self.SELF, txt, title=title)
 def VVLuWC(self, VVzpqh, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCMTIp.VVyqyP(self.SELF, path)
  else    : FFNWTN(self.VVzpqh, "File not found", 1000)
 def VV2c90(self, VVzpqh):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVzpqh:
   self.VVzpqh.cancel()
  del self
 def VVaeZL(self, VVzpqh, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVRj9e = []
  VVRj9e.append(("Remove current row"      , "VVbnqN"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(('Remove all "Completed"'     , "remFinished"    ))
  VVRj9e.append(('Remove all "Not started"'     , "remPending"    ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Delete the file (and remove from list)" , "VVVPUb" ))
  if FFeKZd(decodedUrl):
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(("Download Movie Poster (from server)" , "VV5pmj"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append((resumeTxt + " Auto Resume"     , "VV0nTt"  ))
  FFLATx(self.SELF, self.VVyCJE, VVRj9e=VVRj9e, title=self.Title, VVhiDK=True, VVrTTp=True)
 def VVyCJE(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVbnqN"  : self.VVbnqN()
   elif ref == "remFinished"   : self.VVYWMg(self.VVzdoj, txt)
   elif ref == "remPending"   : self.VVYWMg(self.VVpEKW, txt)
   elif ref == "VVVPUb" : self.VVVPUb(txt)
   elif ref == "VV5pmj"  : self.VV5pmj()
   elif ref == "VV0nTt"  : self.VV0nTt()
 def VVbSwb(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CC1ywg.VV3YGN(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVztK4or("Could not get download link !\n\nTry again later.")
     return
  for line in CCtZ0M.VVlKmy():
   if CCtZ0M.VV5ZYq(decodedUrl, line):
    self.VVxFdf(decodedUrl)
    FFbH1W(boundFunction(FFNWTN, self.VVzpqh, "Already listed !", 2000))
    break
  else:
   params = self.VVAezC(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVztK4or(params[0])
   elif len(params) == 2:
    FF2QoN(self.SELF, boundFunction(self.VVbdTY, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCMTIp.VVJrmt(fSize)
    FF2QoN(self.SELF, boundFunction(self.VVkPAS, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVkPAS(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCtZ0M.VV3rmL(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVzwwy()
  if self.VVzpqh:
   self.VVzpqh.VVm6it()
  if startDnld:
   threadName = self.VVJHfk + decodedUrl
   self.VVR50Q(threadName, url, decodedUrl, path, resp)
 def VVxFdf(self, decodedUrl):
  for ndx, row in enumerate(self.VVzpqh.VVbBP2()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVzpqh:
    self.VVzpqh.VV0Yzk(ndx)
    break
 def VVAezC(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVMluF(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVTp1x(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CC1ywg.VV3YGN(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CC1ywg.VV4p8EHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCtZ0M.VVo5u5(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCtZ0M.VVgN8s(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVbdTY(self, resp, decodedUrl):
  if not os.system(FFH6kH("which ffmpeg")) == 0:
   FF2QoN(self.SELF, boundFunction(CCfMBx.VVCM1R, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVMluF(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVHCVW(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FF2QoN(self.SELF, boundFunction(self.VVVc1W, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVVc1W(rTxt, rUrl)
  else:
   self.VVztK4or("Cannot process m3u8 file !")
 def VVHCVW(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVRj9e = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCfMBx.VVChBV(rUrl, fPath)
   VVRj9e.append((resol, fullUrl))
  if VVRj9e:
   FFLATx(self.SELF, self.VVPw3t, VVRj9e=VVRj9e, title="Resolution", VVhiDK=True, VVrTTp=True)
  else:
   self.VVztK4or("Cannot get Resolutions list from server !")
 def VVPw3t(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FF2QoN(self.SELF, boundFunction(FFbH1W, boundFunction(self.VVh5QO, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFbH1W(boundFunction(self.VVh5QO, resolUrl))
 def VVh5QO(self, resolUrl):
  txt, err = CC1ywg.VVjMyK(resolUrl)
  if err : self.VVztK4or(err)
  else : self.VVVc1W(txt, resolUrl)
 def VV8iGo(self, logF, decodedUrl):
  found = False
  lines = CCtZ0M.VVlKmy()
  with open(CCtZ0M.VV3rmL(), "w") as f:
   for line in lines:
    if CCtZ0M.VV5ZYq(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCtZ0M.VV3rmL(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVzwwy()
  if self.VVzpqh:
   self.VVzpqh.VVm6it()
 def VVVc1W(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCfMBx.VVChBV(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVztK4or("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV8iGo(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFH6kH("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVJHfk + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVsMUh(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVynN6(dnldLog)
   if dur > -1:
    tim = self.VVIhFG(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVynN6(self, dnldLog):
  lines = FF6vhB("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVIhFG(self, dnldLog):
  lines = FF6vhB("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVTp1x(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFF8Lk(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFH6kH("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVR50Q(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVzpqh.VV8Eyg()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVcXoy, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVcXoy(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCtZ0M.VVdnH4 == path:
       break
     else:
      break
  except:
   return
  if CCtZ0M.VVdnH4:
   CCtZ0M.VVdnH4 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFtYtQ(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVAezC(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVcXoy(url, decodedUrl, path, resp, totFileSize, True)
 def VVHz0r(self, VVzpqh, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV7zh2() : FFNWTN(self.VVzpqh, self.VV4sdO(self.VVzdoj), 500)
  elif not self.VVVbOb() : FFNWTN(self.VVzpqh, self.VV4sdO(self.VVhEq4), 500)
  elif m3u8Log      : FF2QoN(self.SELF, self.VVHGaB, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVesP6():
    CCtZ0M.VVdnH4 = colList[6]
    FFNWTN(self.VVzpqh, "Stopping ...", 1000)
   else:
    FFNWTN(self.VVzpqh, "Stopped", 500)
 def VVHGaB(self, withMsg=True):
  if withMsg:
   FFNWTN(self.VVzpqh, "Stopping ...", 1000)
  os.system(FFH6kH("killall -INT ffmpeg"))
 def VV0nTt(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVddLV(self, *args):
  if   self.VV7zh2() : FFNWTN(self.VVzpqh, self.VV4sdO(self.VVzdoj) , 500)
  elif self.VVVbOb() : FFNWTN(self.VVzpqh, self.VV4sdO(self.VVOpkK), 500)
  else:
   resume = False
   m3u8Log = self.VVzpqh.VV8Eyg()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FF2QoN(self.SELF, boundFunction(self.VVXhyO, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VViyFg():
    resume = True
   if resume: FFjNEj(self.VVzpqh, boundFunction(self.VVM2vj), title="Checking Server ...")
   else  : FFNWTN(self.VVzpqh, "Cannot resume !", 500)
 def VVXhyO(self, m3u8Log):
  os.system(FFH6kH("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFjNEj(self.VVzpqh, boundFunction(self.VVM2vj), title="Checking Server ...")
 def VVM2vj(self):
  colList  = self.VVzpqh.VV8Eyg()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CC1ywg.VV3YGN(decodedUrl)
   if url:
    decodedUrl = self.VVASXG(decodedUrl, url)
   else:
    self.VVztK4or("Could not get download link !\n\nTry again later.")
    return
  curSize = FFtYtQ(path)
  params = self.VVAezC(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVztK4or(params[0])
   return
  elif len(params) == 2:
   self.VVbdTY(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVASXG(decodedUrl, url, fSize)
  threadName = self.VVJHfk + decodedUrl
  if resumable: self.VVR50Q(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVztK4or("Cannot resume from server !")
 def VVMluF(self, decodedUrl):
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
     ok  = True
   if not ok and FFKi35(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    fName =  mix.split(":")[0]
    chName = ":".join(mix.split(":")[1:])
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVztK4or(self, txt):
  FFikHE(self.SELF, txt, title=self.Title)
 def VVesP6(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVJHfk in thr.name:
    thrList.append(thr.name.replace(self.VVJHfk, ""))
  return thrList
 def VVVbOb(self):
  decodedUrl = self.VVzpqh.VV8Eyg()[9].strip()
  return decodedUrl in self.VVesP6()
 def VV7zh2(self):
  colList = self.VVzpqh.VV8Eyg()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFtYtQ(path)) == size
 def VViyFg(self):
  colList = self.VVzpqh.VV8Eyg()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFtYtQ(path)
  if curSize > -1:
   size -= curSize
  err = CCtZ0M.VVgN8s(size)
  if err:
   FFikHE(self.SELF, err, title=self.Title)
   return False
  return True
 def VVxtdU(self, list):
  with open(CCtZ0M.VV3rmL(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVASXG(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCtZ0M.VVlKmy()
  url = decodedUrl
  with open(CCtZ0M.VV3rmL(), "w") as f:
   for line in lines:
    if CCtZ0M.VV5ZYq(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVzwwy()
  return url
 @staticmethod
 def VVlKmy():
  list = []
  if fileExists(CCtZ0M.VV3rmL()):
   for line in FFwZqG(CCtZ0M.VV3rmL()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VV5ZYq(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVgN8s(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCMTIp.VVu6ch(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCMTIp.VVJrmt(size), CCMTIp.VVJrmt(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVzS4C(SELF):
  tot = CCtZ0M.VVYolv()
  if tot:
   FFikHE(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVYolv():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCtZ0M.VVJHfk):
    c += 1
  return c
 @staticmethod
 def VVvkan():
  return len(CCtZ0M.VVlKmy()) == 0
 @staticmethod
 def VVqX71():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVJgX0():
  mPoints = CCtZ0M.VVqX71()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFH6kH("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VV3rmL():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVBGzA(SELF):
  CCtZ0M.VVNZrN(SELF, CCtZ0M.VVC86a)
 @staticmethod
 def VV9NFd_cur(SELF):
  CCtZ0M.VVNZrN(SELF, CCtZ0M.VVRFWI, startDnld=True)
 @staticmethod
 def VV9NFd_url(SELF, url):
  CCtZ0M.VVNZrN(SELF, CCtZ0M.VVRFWI, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVmfuhCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(SELF)
  added, skipped = CCtZ0M.VVmfuhList([decodedUrl])
  FFNWTN(SELF, "Added", 1000)
 @staticmethod
 def VVmfuhList(list):
  added = skipped = 0
  for line in CCtZ0M.VVlKmy():
   for ndx, url in enumerate(list):
    if url and CCtZ0M.VV5ZYq(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCtZ0M.VV3rmL(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVNZrN(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCAvMQ.VVJdIu(SELF):
   return
  if mode == CCtZ0M.VVC86a and CCtZ0M.VVvkan():
   FFikHE(SELF, "Download list is empty !", title=title)
  else:
   inst = CCtZ0M(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVo5u5(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCxKzH(Screen, CCHhYj):
 VVGchH = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFRqpN(VVsSd2, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCHhYj.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFpJPp(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVHg0c())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4R5P         ,
   "info"  : self.VVTDOz        ,
   "epg"  : self.VVTDOz        ,
   "menu"  : self.VVXBg0       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVBhDV        ,
   "green"  : self.VVJNV3    ,
   "yellow" : self.VVUF5e   ,
   "left"  : boundFunction(self.VVjHNR, -1)   ,
   "right"  : boundFunction(self.VVjHNR,  1)   ,
   "play"  : self.VV7O2S        ,
   "pause"  : self.VV7O2S        ,
   "playPause" : self.VV7O2S        ,
   "stop"  : self.VV7O2S        ,
   "rewind" : self.VVjSvx        ,
   "forward" : self.VVppKL        ,
   "rewindDm" : self.VVjSvx        ,
   "forwardDm" : self.VVppKL        ,
   "last"  : self.VV5QsY        ,
   "next"  : self.VVvM85        ,
   "pageUp" : boundFunction(self.VVeeZO, True) ,
   "pageDown" : boundFunction(self.VVeeZO, False) ,
   "chanUp" : boundFunction(self.VVeeZO, True) ,
   "chanDown" : boundFunction(self.VVeeZO, False) ,
   "up"  : boundFunction(self.VVeeZO, True) ,
   "down"  : boundFunction(self.VVeeZO, False) ,
   "audio"  : boundFunction(self.VVpMfp, True) ,
   "subtitle" : boundFunction(self.VVpMfp, False) ,
   "0"   : boundFunction(self.VVGt3f , 10)  ,
   "1"   : boundFunction(self.VVGt3f , 1)  ,
   "2"   : boundFunction(self.VVGt3f , 2)  ,
   "3"   : boundFunction(self.VVGt3f , 3)  ,
   "4"   : boundFunction(self.VVGt3f , 4)  ,
   "5"   : boundFunction(self.VVGt3f , 5)  ,
   "6"   : boundFunction(self.VVGt3f , 6)  ,
   "7"   : boundFunction(self.VVGt3f , 7)  ,
   "8"   : boundFunction(self.VVGt3f , 8)  ,
   "9"   : boundFunction(self.VVGt3f , 9)
  }, -1)
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFe9R7(self)
  if not CCxKzH.VVGchH:
   CCxKzH.VVGchH = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFMmCK(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFMmCK(self["myPlayRpt"], "rpt")
  self.VVnJqH()
  self.instance.move(ePoint(40, 40))
  self.VV75eg(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGF4Q)
  except:
   self.timer.callback.append(self.VVGF4Q)
  self.timer.start(250, False)
  self.VVGF4Q("Checking ...")
  self.VVVe5i()
 def VVJNV3(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  if "chCode" in iptvRef:
   if CCAvMQ.VVJdIu(self):
    self.VVVe5i(True)
 def VVnJqH(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   if "get_download_link" in origUrl: color = "#1120101a"
   else        : color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFL3RG(self["myTitle"], color)
 def VVXBg0(self):
  if self.SubtWin:
   self.SubtWin.VVGcRi()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  VVRj9e = []
  if self.isFromExternal:
   VVRj9e.append(("IPTV Menu"     , "iptv"  ))
   VVRj9e.append(VVmGWQ)
  if FF0haM(iptvRef) and not "&end=" in decodedUrl and not FFKi35(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCfMBx.VVTzl0(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVRj9e.append(("Catchup Programs"   , "catchup"  ))
    VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Stop Current Service"    , "stop"  ))
  VVRj9e.append(("Restart Current Service"   , "restart"  ))
  VVRj9e.append(VVmGWQ)
  FFeKZdSeries = FFKi35(decodedUrl)
  if FFeKZdSeries:
   VVRj9e.append(("File Size"     , "fileSize" ))
   VVRj9e.append(VVmGWQ)
  if self.enableDownloadMenu:
   addSep = False
   if FF0haM(iptvRef) and FFeKZdSeries:
    VVRj9e.append(("Start Download"   , "dload_cur" ))
    VVRj9e.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCtZ0M.VVvkan():
    VVRj9e.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVRj9e.append(VVmGWQ)
  addSep = False
  fPath, fDir, fName = CCMTIp.VVw0KC(self)
  if fPath:
   if not CCMTIp.VVvRDo:
    VVRj9e.append((VVJF5Y + "Open path in File Manager" , "VV7WiK" ))
    addSep = True
   if fPath:
    VVRj9e.append((VVJF5Y + 'Add to "My Movies" Bouquet' , "VVl4Lu" ))
    VVRj9e.append((VVJF5Y + "Start Subtitle"    , "VVZnM3"  ))
    addSep = True
   if addSep:
    VVRj9e.append(VVmGWQ)
   VVRj9e.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVOlrW" ))
   VVRj9e.append(VVmGWQ)
  if CFG.playerPos.getValue() : VVRj9e.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VVRj9e.append(("Move Bar to Top"  , "top"   ))
  VVRj9e.append(("Help"             , "help"  ))
  FFLATx(self, self.VVzsi7, VVRj9e=VVRj9e, width=550, title="Options")
 def VVzsi7(self, item=None):
  if item:
   if item == "iptv"     : self.VVR9Rw()
   elif item == "catchup"    : self.VVUF5e()
   elif item == "stop"     : self.VVV3ca(0)
   elif item == "restart"    : self.VVV3ca(1)
   elif item == "fileSize"    : FFjNEj(self, boundFunction(CCR0BS.VVlFfo, self), title="Checking Server")
   elif item == "dload_cur"   : CCtZ0M.VV9NFd_cur(self)
   elif item == "addToDload"   : CCtZ0M.VVmfuhCurrent(self)
   elif item == "dload_stat"   : CCtZ0M.VVBGzA(self)
   elif item == "VV7WiK" : self.VV7WiK()
   elif item == "VVl4Lu" : FFjNEj(self, self.VVl4Lu)
   elif item == "VVZnM3"  : self.VVZnM3(CC3CXk.VVvo9X)
   elif item == "VVOlrW"  : self.VVOlrW()
   elif item == "botm"     : self.VV75eg(0)
   elif item == "top"     : self.VV75eg(1)
   elif item == "help"     : FFom2P(self, VVpTxo + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCxKzH.VVGchH = None
  self.VV6uXw()
 def VVxsts(self):
  if CCxKzH.VVGchH:
   self.session.open(CCxKzH, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VV7WiK(self):
  self.session.open(CCMTIp, gotoMovie=True)
  self.VVxsts()
 def VVR9Rw(self):
  self.session.open(CCfMBx)
  self.VVxsts()
 def VVV3ca(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVGF4Q("Restarting Service ...")
    FFbH1W(boundFunction(self.VVDqmj, serv))
 def VVDqmj(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  if "&end=" in decodedUrl: boundFunction(self.VVVe5i, True)
  else     : self.session.nav.playService(serv)
 def VVl4Lu(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VV9gDR + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  fPath, fDir, fName = CCMTIp.VVw0KC(self)
  if not fPath or not chName:
   FFikHE(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCfMBx.VV1MBM(catID, stID, chNum)
  if not isNew:
   fTxt = FFBgGE(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFikHE(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCfMBx.VV1MBM(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFikHE(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVy5x4(refCode)
   FFpGUj(os.path.basename(path))
   FFVzbz()
   FF7k8q(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFikHE(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVOlrW(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVGF4Q(txt, highlight=ok)
 def VVZnM3(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CC3CXk, mode=mode, endCallback=self.VVzzhh)
  self.SubtWin.show()
  self.SubtWin.VVbRSr(useSubtFile)
 def VVzzhh(self, err):
  if err:
   if err == "noResume": self.VV6uXw(False)
   else    : self.VV6uXw(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CC3CXk.VV9HZc(self, self.VVBv0K)
   else      : FFNWTN(self, err, 2000)
 def VVBv0K(self, path):
  if path:
   self.VVZnM3(CC3CXk.VVvo9X, useSubtFile=path)
 def VVy5x4(self, refCode):
  fPath, fDir, fName, picFile = CCR0BS.VVpXIP(self)
  pPath = CC0sln.VVij8s()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFH6kH("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFH6kH("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VV75eg(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VV4R5P(self):
  if self.isManualSeek:
   self.VVQk4t()
   self.VVqik4(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVZnM3(CC3CXk.VVuYHz)
   else:
    self.VV6uXw()
 def VV6uXw(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVQk4t()
  elif self.SubtWin : self.VV6uXw()
  else    : self.close()
 def VVTDOz(self):
  if self.SubtWin:
   self.SubtWin.VV1FKu("noErr")
  FFgBdr(self, fncMode=CCR0BS.VVGDay)
 def VV7O2S(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVGF4Q("Toggling Play/Pause ...")
 def VVQk4t(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVjHNR(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVkeBa()
   else:
    self.manualSeekSec += direc * self.VVkeBa()
    self.manualSeekSec = FFsOVH(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFmOj8(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFhztG(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVGt3f(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVHg0c())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVGF4Q("Changed Seek Time to : %d%s" % (val, self.VVZHy9()))
 def VVHg0c(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVZHy9())
 def VVZHy9(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVYkYO(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVkeBa(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVGF4Q(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFFa90(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFuM16(info, iServiceInformation.sVideoWidth) or -1
   h = FFuM16(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFuM16(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCR0BS.VVl6ZL(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFsOVH(percVal, 0, 100)
    width = int(FFmOj8(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFL3RG(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFL3RG(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VV0X4w() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFOEeE(self["myPlayMsg"], "#0000ffff")
   else  : FFOEeE(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFHyEt(refCode, True))
   FFOEeE(self["myPlayMsg"], "#00ff8066")
  tot = CCtZ0M.VVYolv()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV62tA()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVqik4(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV5QsY()
  state = self.VVZa4A()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFOEeE(self["myPlayMsg"], "#0000ff00")
  else     : FFOEeE(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VV9oI9(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFhztG(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFhztG(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFhztG(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VV62tA(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVBhDV(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VV0X4w()
   if cList:
    VVRj9e = []
    for pts, what in cList:
     txt = FFhztG(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVRj9e.append((txt, pts))
    FFLATx(self, self.VVc8z2, VVRj9e=VVRj9e, title="Cut List")
   else:
    self.VVGF4Q("No Cut-List for this channel !")
 def VVc8z2(self, item=None):
  if item:
   self.VVqik4(item)
 def VV0X4w(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVppKL(self) : self.VVAVmk(1)
 def VVjSvx(self) : self.VVAVmk(-1)
 def VVAVmk(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVkeBa() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVYkYO())
    self.VVGF4Q(txt)
  except:
   self.VVGF4Q("Cannot jump")
 def VVqik4(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVGF4Q("Changing Time ...")
 def VV5QsY(self):
  self.VVV3ca(1)
  self.VVGF4Q("Replaying ...")
  self.VVQk4t()
 def VVvM85(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVGF4Q("Jumping to end ...")
  except:
   pass
 def VVZa4A(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVeeZO(self, isUp):
  if self.enableZapping:
   self.VVGF4Q("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVQk4t()
   if self.portalTableParam:
    FFbH1W(boundFunction(self.VVn6HR, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
    if "/timeshift/" in decodedUrl:
     self.VVGF4Q("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVn46C()
 def VVn46C(self):
  self.lastPlayPos = 0
  self.VVnJqH()
  self.VVVe5i()
 def VVn6HR(self, isUp):
  CCfMBx_inatance, VVzpqh, mode = self.portalTableParam
  if isUp : VVzpqh.VVLNgy()
  else : VVzpqh.VVBOEk()
  colList = VVzpqh.VV8Eyg()
  if mode == "localIptv":
   chName, chUrl = CCfMBx_inatance.VVJ4vJ(VVzpqh, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCfMBx_inatance.VVZmSe(VVzpqh, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCfMBx_inatance.VVi9TO(mode, VVzpqh, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCfMBx_inatance.VVJIvJ(mode, VVzpqh, colList)
  else:
   self.VVGF4Q("Cannot Zap")
   return
  FFZXnt(self, chUrl, VVPUAy=False)
  self.VVn46C()
 def VVVe5i(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
   if not self.VVsN6j(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVGF4Q("Refreshing Portal")
   FFbH1W(self.VVClxm)
  except:
   pass
 def VVClxm(self):
  self.restoreLastPlayPos = self.VVGTfM()
 def VVUF5e(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFFa90(self)
  if not decodedUrl or FFKi35(decodedUrl):
   self.VVGF4Q("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCfMBx.VVTzl0(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVGF4Q("Reading Program List ...")
   ok_fnc = boundFunction(self.VVgPI7, refCode, chName, streamId, uHost, uUser, uPass)
   FFbH1W(boundFunction(CCfMBx.VVHiAS, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVGF4Q("Cannot process this channel")
 def VVgPI7(self, refCode, chName, streamId, uHost, uUser, uPass, VVzpqh, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVzpqh.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVGF4Q("Changing Program ...")
   FFbH1W(boundFunction(self.VVXC00, chUrl))
  else:
   self.VVGF4Q("Incorrect Timestamp !")
 def VVXC00(self, chUrl):
   FFZXnt(self, chUrl, VVPUAy=False)
   self.lastPlayPos = 0
   self.VVnJqH()
 def VVpMfp(self, isAudio):
  try:
   VVy039 = InfoBar.instance
   if VVy039:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVy039)
    else  : self.session.open(SubtitleSelection, VVy039)
  except:
   pass
class CCVKuT(Screen):
 def __init__(self, session, title="", VVqTs3="Continue?", VVqxqt=True, VV9d4I=False):
  self.skin, self.skinParam = FFRqpN(VVFCPk, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVqTs3 = VVqTs3
  self.VV9d4I = VV9d4I
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVqxqt : VVRj9e = [no , yes]
  else   : VVRj9e = [yes, no ]
  FFpJPp(self, title, VVRj9e=VVRj9e, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4R5P ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVqTs3)
  if self.VV9d4I:
   self["myLabel"].instance.setHAlign(0)
  self.VVBP3f()
  FFl7ED(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFN9mt(self["myMenu"])
  FFCEFt(self, self["myMenu"])
 def VV4R5P(self):
  item = FFUrUX(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVBP3f(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCRG3J(Screen):
 def __init__(self, session, title="", VVRj9e=None, width=1000, height=0, OKBtnFnc=None, VV5GJ7=None, VVrdmH=None, VVr5GC=None, VVBBKW=None, VVhiDK=False, VVrTTp=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFRqpN(VVD8FW, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVRj9e   = VVRj9e
  self.OKBtnFnc   = OKBtnFnc
  self.VV5GJ7   = VV5GJ7
  self.VVrdmH  = VVrdmH
  self.VVr5GC  = VVr5GC
  self.VVBBKW   = VVBBKW
  self.VVhiDK  = VVhiDK
  self.VVrTTp  = VVrTTp
  FFpJPp(self, title, VVRj9e=VVRj9e)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV4R5P          ,
   "cancel" : self.cancel          ,
   "red"  : self.VV38kk         ,
   "green"  : self.VVE1DQ         ,
   "yellow" : self.VVJmCm         ,
   "blue"  : self.VVhLGb         ,
   "pageUp" : self.VVnQne       ,
   "chanUp" : self.VVnQne       ,
   "pageDown" : self.VV6BHo        ,
   "chanDown" : self.VV6BHo
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["myMenu"])
  FFwbY1(self)
  self.VVVw0r(self["keyRed"]  , self.VV5GJ7 )
  self.VVVw0r(self["keyGreen"] , self.VVrdmH )
  self.VVVw0r(self["keyYellow"] , self.VVr5GC )
  self.VVVw0r(self["keyBlue"]  , self.VVBBKW )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFKDC6(self)
 def VVVw0r(self, btnObj, btnFnc):
  if btnFnc:
   FFpqes(btnObj, btnFnc[0])
 def VV4R5P(self):
  item = FFUrUX(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVhiDK: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VV38kk(self)  : self.VVDxIi(self.VV5GJ7)
 def VVE1DQ(self) : self.VVDxIi(self.VVrdmH)
 def VVJmCm(self) : self.VVDxIi(self.VVr5GC)
 def VVhLGb(self) : self.VVDxIi(self.VVBBKW)
 def VVDxIi(self, btnFnc):
  if btnFnc:
   item = FFUrUX(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVrTTp:
    self.cancel()
 def VVsgrR(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVRj9e = self["myMenu"].list
  VVRj9e.pop(ndx)
  if len(VVRj9e) > 0: self["myMenu"].setList(VVRj9e)
  else    : self.close()
 def VVSy0k(self, VVRj9e):
  if len(VVRj9e) > 0:
   newList = []
   for item in VVRj9e:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VV9gpO(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVnQne(self):
  self["myMenu"].moveToIndex(0)
 def VV6BHo(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC1Q7b(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VV9o2E=None, VVujrY=None, VVec0v=None, VVfhdd=26, VVvdC4=False, VVOrFX=None, VVEJ7p=None, VV9OiG=None, VVSYUp=None, VVM10w=None, VVodFz=None, VVZVRH=None, VVXhFg=None, VVQOfi=None, VViXmI=-1, VVeJ2z=False, searchCol=0, VVSYTz=None, VV8c5A=None, VVeJtS="#00dddddd", VVn7jC="#11002233", VVM9HS="#00ff8833", VVQceP="#11111111", VV2gSR="#0a555555", VVoepE="#0affffff", VV3wi4="#11552200", VVOjMS="#0055ff55"):
  self.skin, self.skinParam = FFRqpN(VVr6Ek, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFpJPp(self, title)
  self.header     = header
  self.VV9o2E     = VV9o2E
  self.totalCols    = len(VV9o2E[0])
  self.VVIioO   = 0
  self.lastSortModeIsReverese = False
  self.VVvdC4   = VVvdC4
  self.VV18U9   = 0.01
  self.VVNYy0   = 0.02
  self.VVYguo = 0.03
  self.VV7LMa  = 1
  self.VVec0v = VVec0v
  self.colWidthPixels   = []
  self.VVOrFX   = VVOrFX
  self.OKButtonObj   = None
  self.VVEJ7p   = VVEJ7p
  self.VV9OiG   = VV9OiG
  self.VVSYUp   = VVSYUp
  self.VVM10w  = VVM10w
  self.VVodFz   = VVodFz
  self.VVZVRH    = VVZVRH
  self.VVXhFg   = VVXhFg
  self.VVQOfi  = VVQOfi
  self.VViXmI    = VViXmI
  self.VVeJ2z   = VVeJ2z
  self.searchCol    = searchCol
  self.VVujrY    = VVujrY
  self.keyPressed    = -1
  self.VVfhdd    = FF7cPD(VVfhdd)
  self.VVn4Lz    = FFc6K0(self.VVfhdd, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVSYTz    = VVSYTz
  self.VV8c5A      = VV8c5A
  self.VVeJtS    = FF3EtY(VVeJtS)
  self.VVn7jC    = FF3EtY(VVn7jC)
  self.VVM9HS    = FF3EtY(VVM9HS)
  self.VVQceP    = FF3EtY(VVQceP)
  self.VV2gSR   = FF3EtY(VV2gSR)
  self.VVoepE    = FF3EtY(VVoepE)
  self.VV3wi4    = FF3EtY(VV3wi4)
  self.VVOjMS   = FF3EtY(VVOjMS)
  self.VVS8vj  = False
  self.selectedItems   = 0
  self.VVK27q   = FF3EtY("#01fefe01")
  self.VVAhn5   = FF3EtY("#11400040")
  self.VVBKrD  = self.VVK27q
  self.VVI9RV  = self.VVQceP
  if self.VVeJ2z:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVrHD7  ,
   "red"   : self.VVOTVf  ,
   "green"   : self.VVoBXr ,
   "yellow"  : self.VVpBdw ,
   "blue"   : self.VVdoan  ,
   "menu"   : self.VVV4Wb ,
   "info"   : self.VVObxT  ,
   "cancel"  : self.VVj9hc  ,
   "up"   : self.VVBOEk    ,
   "down"   : self.VVLNgy  ,
   "left"   : self.VV080I   ,
   "right"   : self.VVyHzH  ,
   "pageUp"  : self.VVVzYq  ,
   "chanUp"  : self.VVVzYq  ,
   "pageDown"  : self.VVm6it  ,
   "chanDown"  : self.VVm6it
  }, -1)
  FFjyc0(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFe9R7(self)
  try:
   self.VVo6n3()
  except Exception as err:
   FFikHE(self, str(err))
   self.close(None)
 def VVo6n3(self):
  FFKDC6(self)
  if self.VVSYTz:
   FFL3RG(self["myTitle"], self.VVSYTz)
  if self.VV8c5A:
   FFL3RG(self["myBody"] , self.VV8c5A)
   FFL3RG(self["myTableH"] , self.VV8c5A)
   FFL3RG(self["myTable"] , self.VV8c5A)
   FFL3RG(self["myBar"]  , self.VV8c5A)
  self.VVVw0r(self.VV9OiG  , self["keyRed"])
  self.VVVw0r(self.VVSYUp  , self["keyGreen"])
  self.VVVw0r(self.VVM10w , self["keyYellow"])
  self.VVVw0r(self.VVodFz  , self["keyBlue"])
  if self.VVOrFX:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVOrFX[0])
    FFL3RG(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVn4Lz)
  self["myTableH"].l.setFont(0, gFont(VVcNG9, self.VVfhdd))
  self["myTable"].l.setItemHeight(self.VVn4Lz)
  self["myTable"].l.setFont(0, gFont(VVcNG9, self.VVfhdd))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVn4Lz)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVn4Lz))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVn4Lz)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVn4Lz
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVn4Lz * len(self.VV9o2E) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVec0v:
   self.VVec0v = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVec0v)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVujrY:
   self.VVujrY = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVujrY
   self.VVujrY = []
   for item in tmpList:
    self.VVujrY.append(item | RT_VALIGN_CENTER)
  self.VVnwB8()
  if self.VVZVRH:
   self.VVZVRH(self)
 def VVVw0r(self, btnFnc, btn):
  if btnFnc : FFpqes(btn, btnFnc[0])
  else  : FFpqes(btn, "")
 def VVl4ib(self, waitTxt):
  FFjNEj(self, self.VVnwB8, title=waitTxt)
 def VVnwB8(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVvxj7(0, self.header, self.VVoepE, self.VV3wi4, self.VVoepE, self.VV3wi4, self.VVOjMS)])
   rows = []
   for c, row in enumerate(self.VV9o2E):
    rows.append(self.VVvxj7(c, row, self.VVeJtS, self.VVn7jC, self.VVM9HS, self.VVQceP, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VViXmI > -1:
    self["myTable"].moveToIndex(self.VViXmI )
   self.VVBRKT()
   if self.VVeJ2z:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVn4Lz * len(self.VV9o2E)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVXhFg:
    self.VVDxIi(self.VVXhFg, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFikHE(self, str(err))
    self.close()
   except:
    pass
 def VVvxj7(self, keyIndex, columns, VVeJtS, VVn7jC, VVM9HS, VVQceP, VVOjMS):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVOjMS and ndx == self.VVIioO : textColor = VVOjMS
   else           : textColor = VVeJtS
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FF3EtY(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVn7jC = c
    entry = span.group(3)
   if self.VVujrY[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVn4Lz)
           , font   = 0
           , flags   = self.VVujrY[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVn7jC
           , color_sel  = VVM9HS
           , backcolor_sel = VVQceP
           , border_width = 1
           , border_color = self.VV2gSR
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVObxT(self):
  rowData = self.VVzPTL()
  if rowData:
   title, txt, colList = rowData
   if self.VVEJ7p:
    fnc  = self.VVEJ7p[1]
    params = self.VVEJ7p[2]
    fnc(self, title, txt, colList)
   else:
    FFCsft(self, txt, title)
 def VVrHD7(self):
  if   self.VVS8vj : self.VVtkK3(self.VVG1bP(), mode=2)
  elif self.VVOrFX  : self.VVDxIi(self.VVOrFX, None)
  else      : self.VVObxT()
 def VVOTVf(self) : self.VVDxIi(self.VV9OiG , self["keyRed"])
 def VVoBXr(self) : self.VVDxIi(self.VVSYUp , self["keyGreen"])
 def VVpBdw(self): self.VVDxIi(self.VVM10w , self["keyYellow"])
 def VVdoan(self) : self.VVDxIi(self.VVodFz , self["keyBlue"])
 def VVDxIi(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFNWTN(self, buttonFnc[3])
    FFbH1W(boundFunction(self.VVy9eZ, buttonFnc))
   else:
    self.VVy9eZ(buttonFnc)
 def VVy9eZ(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVzPTL()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVtkK3(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV9o2E[ndx]
   isSelected = row[1][9] == self.VVK27q
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVvxj7(ndx, item, self.VVeJtS, self.VVn7jC, self.VVM9HS, self.VVQceP, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVvxj7(ndx, item, self.VVK27q, self.VVAhn5, self.VVBKrD, self.VVI9RV, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVBRKT()
 def VVKfFs(self):
  FFjNEj(self, self.VVbkXY, title="Selecting all ...")
 def VVbkXY(self):
  self.VV0fYN(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVK27q
   if not isSelected:
    item = self.VV9o2E[ndx]
    newRow = self.VVvxj7(ndx, item, self.VVK27q, self.VVAhn5, self.VVBKrD, self.VVI9RV, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVBRKT()
  self.VVPKKH()
 def VVidyT(self):
  FFjNEj(self, self.VVZHmy, title="Unselecting all ...")
 def VVZHmy(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVK27q:
    item = self.VV9o2E[ndx]
    newRow = self.VVvxj7(ndx, item, self.VVeJtS, self.VVn7jC, self.VVM9HS, self.VVQceP, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVBRKT()
  self.VVPKKH()
 def VVPKKH(self):
  self.hide()
  self.show()
 def VVzPTL(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVec0v[i] > 1 or self.VVec0v[i] == self.VV18U9 or self.VVec0v[i] == self.VVYguo:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VV9o2E))
   return rowNum, txt, colList
  else:
   return None
 def VVj9hc(self):
  if self.VVQOfi : self.VVQOfi(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVPsg7(self):
  return self["myTitle"].getText().strip()
 def VVkO6k(self):
  return self.header
 def VVjgkZ(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV8kAl(self, txt):
  FFNWTN(self, txt)
 def VVjkTY(self, txt):
  FFNWTN(self, txt, 1000)
 def VVKeCF(self):
  FFNWTN(self)
 def VVYuPB(self):
  return len(self.VV9o2E)
 def VVHcCa(self): self["keyGreen"].show()
 def VV0zWr(self): self["keyGreen"].hide()
 def VVG1bP(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVv7ZO(self):
  return len(self["myTable"].list)
 def VV0fYN(self, isOn):
  self.VVS8vj = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVodFz: self["keyBlue"].hide()
   if self.VVOrFX and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVodFz: self["keyBlue"].show()
   if self.VVOrFX and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVOrFX[0])
   self.VVidyT()
  FFL3RG(self["myTitle"], color)
  FFL3RG(self["myBar"]  , color)
 def VVpQGN(self):
  return self.VVS8vj
 def VVpH5i(self):
  return self.selectedItems
 def VVTdXg(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVBRKT()
 def VVskJD(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVBRKT()
 def VV32jG(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV9o2E:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVw87Y(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVYuPB()
  txt += FFO6Fd("Total Unique Items", VVtODU)
  for i in range(self.totalCols):
   if self.VVec0v[i - 1] > 1 or self.VVec0v[i - 1] == self.VV18U9 or self.VVec0v[i - 1] == self.VVYguo:
    name, tot = self.VV32jG(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFCsft(self, txt)
 def VVhJrx(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV8Eyg(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVgYkt(self, newList, newTitle="", VVxyVtMsg=True):
  if newList:
   self.VV9o2E = newList
   if self.VVvdC4 and self.VVIioO == 0:
    self.VV9o2E = sorted(self.VV9o2E, key=lambda x: int(x[self.VVIioO])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV9o2E = sorted(self.VV9o2E, key=lambda x: x[self.VVIioO].lower(), reverse=self.lastSortModeIsReverese)
   if VVxyVtMsg : self.VVl4ib("Refreshing ...")
   else   : self.VVnwB8()
   if newTitle:
    self.VVjgkZ(newTitle)
  else:
   FFikHE(self, "Cannot refresh list")
   self.cancel()
 def VVt4Mg(self, data):
  ndx = self.VVG1bP()
  newRow = self.VVvxj7(ndx, data, self.VVeJtS, self.VVn7jC, self.VVM9HS, self.VVQceP, None)
  if newRow:
   self.VV9o2E[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVBRKT()
   return True
  else:
   return False
 def VViaYk(self, colNum, textToFind, VVztK4=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVBRKT()
    break
  else:
   if VVztK4:
    FFNWTN(self, "Not found", 1000)
 def VVSEni(self, colDict, VVztK4=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVBRKT()
    return
  if VVztK4:
   FFNWTN(self, "Not found", 1000)
 def VVSEni_partial(self, colDict, VVztK4=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVBRKT()
    return
  if VVztK4:
   FFNWTN(self, "Not found", 1000)
 def VVjZj8(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVe8MB(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVK27q:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVS5Wm(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVK27q: return True
  else        : return False
 def VVbBP2(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVV4Wb(self):
  if not self["keyMenu"].getVisible() or self.VVeJ2z:
   return
  VVRj9e = []
  VVRj9e.append(("Table Statistcis"             , "tableStat"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append((FFhTMc("Export Table to .html"     , VVtODU) , "VVG4ri" ))
  VVRj9e.append((FFhTMc("Export Table to .csv"     , VVtODU) , "VVxWjL" ))
  VVRj9e.append((FFhTMc("Export Table to .txt (Tab Separated)", VVtODU) , "VVuLzB" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVec0v[i] > 1 or self.VVec0v[i] == self.VVNYy0:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVRj9e.append(VVmGWQ)
   if tot == 1 : VVRj9e.append(("Sort", sList[0][1]))
   else  : VVRj9e += sList
  FFLATx(self, self.VVwnXN, VVRj9e=VVRj9e, title=self.VVPsg7())
 def VVwnXN(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVw87Y()
   elif item == "VVG4ri": FFjNEj(self, self.VVG4ri, title=title)
   elif item == "VVxWjL" : FFjNEj(self, self.VVxWjL , title=title)
   elif item == "VVuLzB" : FFjNEj(self, self.VVuLzB , title=title)
   else:
    isReversed = False
    if self.VVIioO == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVvdC4 and item == 0:
     self.VV9o2E = sorted(self.VV9o2E, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV9o2E = sorted(self.VV9o2E, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVIioO = item
    self.VVl4ib("Sorting ...")
 def VVBOEk(self):
  self["myTable"].up()
  self.VVBRKT()
 def VVLNgy(self):
  self["myTable"].down()
  self.VVBRKT()
 def VV080I(self):
  self["myTable"].pageUp()
  self.VVBRKT()
 def VVyHzH(self):
  self["myTable"].pageDown()
  self.VVBRKT()
 def VVVzYq(self):
  self["myTable"].moveToIndex(0)
  self.VVBRKT()
 def VVm6it(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVBRKT()
 def VV0Yzk(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVBRKT()
 def VVuLzB(self):
  expFile = self.VVGeyU() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV0eM2()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV9o2E:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVec0v[ndx] > self.VV7LMa or self.VVec0v[ndx] == self.VVYguo:
      col = self.VVsx8y(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VV9f5u(expFile)
 def VVxWjL(self):
  expFile = self.VVGeyU() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV0eM2()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV9o2E:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVec0v[ndx] > self.VV7LMa or self.VVec0v[ndx] == self.VVYguo:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVsx8y(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VV9f5u(expFile)
 def VVG4ri(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVPsg7(), PLUGIN_NAME, VVR4kJ)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVPsg7()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV0eM2()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVec0v:
   colgroup += '   <colgroup>'
   for w in self.VVec0v:
    if w > self.VV7LMa or w == self.VVYguo:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVGeyU() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV9o2E:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVec0v[ndx] > self.VV7LMa or self.VVec0v[ndx] == self.VVYguo:
      col = self.VVsx8y(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VV9f5u(expFile)
 def VV0eM2(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVec0v[ndx] > self.VV7LMa or self.VVec0v[ndx] == self.VVYguo:
     newRow.append(col.strip())
  return newRow
 def VVsx8y(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFz82T(col)
 def VVGeyU(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVPsg7())
  fileName = fileName.replace("__", "_")
  path  = FFZ2H0(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFOeCU()
  return expFile
 def VV9f5u(self, expFile):
  FF7k8q(self, "File exported to:\n\n%s" % expFile, title=self.VVPsg7())
 def VVBRKT(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCaOlz():
 def __init__(self, pixmapObj, picPath):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
 def VVMZRL(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVB7Ek)
    except Exception as e:
     self.picLoad.PictureData.get().append(self.VVB7Ek)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#2200002a"])
    self.picLoad.startDecode(self.picPath)
    return True
   except Exception as e:
    pass
  return False
 def VVB7Ek(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VV7d2R(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVE2NE(pixmapObj, path):
  cl = CCaOlz(pixmapObj, path)
  ok = cl.VVMZRL()
  if ok: return cl
  else : return None
class CCZG9b(Screen):
 def __init__(self, session, title="", VVgyZU=None, showGrnMsg=""):
  self.skin, self.skinParam = FFRqpN(VVZ61v, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VVgyZU),
  self.session = session
  FFpJPp(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VVgyZU = VVgyZU
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VVk68Z)
  self.onClose.append(self.onExit)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self.picViewer = CCaOlz.VVE2NE(self["myPic"], self.VVgyZU)
  if self.picViewer:
   if self.showGrnMsg:
    FFNWTN(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFikHE(self, "Cannot view picture file:\n\n%s" % self.VVgyZU)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV7d2R()
 @staticmethod
 def VVlyqK(SELF, VVgyZU, title="", showGrnMsg=""):
  SELF.session.open(boundFunction(CCZG9b, title=title, VVgyZU=VVgyZU, showGrnMsg=showGrnMsg))
class CCZovK(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFRqpN(VVoWAS, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFpJPp(self, title=self.Title)
  FFpqes(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVYKPa:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVysIp:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVM6J3 *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVM6J3 *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVM6J3 *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVuCnW()
  self.onShown.append(self.VVk68Z)
 def VVuCnW(self):
  kList = {
    "ok"  : self.VV4R5P    ,
    "green"  : self.VVoCsu   ,
    "menu"  : self.VV4O5c  ,
    "cancel" : self.VVgEiL  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVILOD, 0)
     kList["chanDown"] = boundFunction(self["config"].VVILOD, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFe9R7(self)
  FFl7ED(self["config"])
  FFwbY1(self, self["config"])
  FFKDC6(self)
 def VV4R5P(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VV5BPX()
   elif item == CFG.MovieDownloadPath   : self.VVc6IV(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVx5Fp(item)
   elif item == CFG.backupPath    : self.VVx5Fp(item)
   elif item == CFG.packageOutputPath  : self.VVx5Fp(item)
   elif item == CFG.downloadedPackagesPath : self.VVx5Fp(item)
   elif item == CFG.exportedTablesPath  : self.VVx5Fp(item)
   elif item == CFG.exportedPIconsPath  : self.VVx5Fp(item)
 def VVc6IV(self, item, title):
  tot = CCtZ0M.VVYolv()
  if tot : FFikHE(self, "Cannot change while downloading.", title=title)
  else : self.VVx5Fp(item)
 def VV5BPX(self):
  VVRj9e = []
  VVRj9e.append(("Auto Find" , "auto"))
  VVRj9e.append(("Custom Path" , "path"))
  FFLATx(self, self.VVpIxl, VVRj9e=VVRj9e, title="IPTV Hosts Files Path")
 def VVpIxl(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVKky1)
   elif item == "path": self.VVx5Fp(CFG.iptvHostsPath)
 def VVx5Fp(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVKky1:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVmJpu, configObj)
         , boundFunction(CCMTIp, mode=CCMTIp.VVIzr0, VV3a7H=sDir))
 def VVmJpu(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVgEiL(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FF2QoN(self, self.VVoCsu, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVoCsu(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVraS2()
  self.VVi7Wb()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVi7Wb(self):
  CCIa4v.VV74WG()
 def VV4O5c(self):
  VVRj9e = []
  VVRj9e.append(("Use Backup directory in all other paths"      , "VVZJ4X"   ))
  VVRj9e.append(("Reset all to default (including File Manager bookmarks)"  , "VVCekW"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Backup %s Settings" % PLUGIN_NAME        , "VVIOmQ"  ))
  VVRj9e.append(("Restore %s Settings" % PLUGIN_NAME       , "VVIh2s"  ))
  if fileExists(VVXKuz + VV0wrk):
   VVRj9e.append(VVmGWQ)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVRj9e.append(('%s Checking for Update' % txt1       , txt2     ))
   VVRj9e.append(("Reinstall %s" % PLUGIN_NAME        , "VVczRW"  ))
   VVRj9e.append(("Update %s" % PLUGIN_NAME        , "VVZzYT"   ))
  FFLATx(self, self.VVGHXe, VVRj9e=VVRj9e, title="Config. Options")
 def VVGHXe(self, item=None):
  if item:
   if   item == "VVZJ4X"  : FF2QoN(self, self.VVZJ4X , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVCekW"  : FF2QoN(self, self.VVCekW, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCacbo)
   elif item == "VVIOmQ" : self.VVIOmQ()
   elif item == "VVIh2s" : FFjNEj(self, self.VVIh2s, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VV3heV(True)
   elif item == "disableChkUpdate" : self.VV3heV(False)
   elif item == "VVczRW" : FFjNEj(self, self.VVczRW , "Checking Server ...")
   elif item == "VVZzYT"  : FFjNEj(self, self.VVZzYT  , "Checking Server ...")
 def VVIOmQ(self):
  path = "%sajpanel_settings_%s" % (VVXKuz, FFOeCU())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FF7k8q(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVIh2s(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FF6vhB("find / %s -iname '%s*' | grep %s" % (FF85RC(1), name, name))
  if lines:
   lines.sort()
   VVRj9e = []
   for line in lines:
    VVRj9e.append((line, line))
   FFLATx(self, boundFunction(self.VVMZIc, title), title=title, VVRj9e=VVRj9e, width=1200)
  else:
   FFikHE(self, "No settings files found !", title=title)
 def VVMZIc(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFwZqG(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVraS2()
    FF7V9v()
   else:
    FF9mKB(SELF, path, title=title)
 def VV3heV(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVZJ4X(self):
  newPath = FFZ2H0(VVXKuz)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVraS2()
 @staticmethod
 def VVF5yk():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVCekW(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVKky1)
  CFG.MovieDownloadPath.setValue(CCtZ0M.VVJgX0())
  CFG.PIconsPath.setValue(VVgq9y)
  CFG.backupPath.setValue(CCZovK.VVF5yk())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVraS2()
  self.close()
 def VVraS2(self):
  configfile.save()
  global VVXKuz
  VVXKuz = CFG.backupPath.getValue()
  FFw7EK()
 def VVZzYT(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVAtS7(title)
  if webVer:
   FF2QoN(self, boundFunction(FFjNEj, self, boundFunction(self.VVS5pB, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVczRW(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVAtS7(title, True)
  if webVer:
   FF2QoN(self, boundFunction(FFjNEj, self, boundFunction(self.VVS5pB, webVer, title, True)), "Install and Restart ?", title=title)
 def VVS5pB(self, webVer, title, isReinst=False):
  url = self.VVxOhU(self, title)
  if url:
   VVcKW9 = FFZfAA() == "dpkg"
   if VVcKW9 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVcKW9 else "ipk")
   path, err = FFnx0u(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFq4eO(VVNzzW, path)
    else  : cmd = FFq4eO(VVjk7Z, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFF3Kc(self, cmd)
    else:
     FFNDX7(self, title=title)
   else:
    FFikHE(self, err, title=title)
 def VVAtS7(self, title, anyVer=False):
  url = self.VVxOhU(self, title)
  if not url:
   return ""
  path, err = FFnx0u(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFikHE(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFBgGE(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFikHE(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVR4kJ.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FF6vhB(cmd)
   if list and curVer == list[0]:
    return webVer
  FF7k8q(self, FFhTMc("No update required.", VV4U0A) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVxOhU(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVXKuz + VV0wrk
  if fileExists(path):
   span = iSearch(r"(http.+)", FFBgGE(path), IGNORECASE)
   if span : url = FFZ2H0(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFikHE(SELF, err, title)
  return url
 @staticmethod
 def VVxOvC(url):
  path, err = FFnx0u(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFBgGE(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVR4kJ.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FF6vhB(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCacbo(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFRqpN(VVAgBh, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVg9YJ
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFpJPp(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VViPKf("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VViPKf("\c00888888", i) + sp + "GREY\n"
   txt += self.VViPKf("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VViPKf("\c00FF0000", i) + sp + "RED\n"
   txt += self.VViPKf("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VViPKf("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VViPKf("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VViPKf("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VViPKf("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VViPKf("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VViPKf("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VViPKf("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV4R5P ,
   "green"   : self.VV4R5P ,
   "left"   : self.VVWfTh ,
   "right"   : self.VV6a4U ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  self.VVThan()
 def VV4R5P(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FF2QoN(self, self.VVSGjl, "Change to : %s" % txt, title=self.Title)
 def VVSGjl(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVg9YJ
  VVg9YJ = self.cursorPos
  self.VVZnK7()
  self.close()
 def VVWfTh(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVThan()
 def VV6a4U(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVThan()
 def VVThan(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VViPKf(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVYaeM(color):
  if VVJF5Y: return "\\" + color
  else    : return ""
 @staticmethod
 def VVZnK7():
  global VVWmbA, VVyTfh, VVOC4t, VVtODU, VVBXnD, VV6Y3Y, VV4U0A, VVJF5Y, COLOR_CONS_BRIGHT_YELLOW, VVejU1, VVo3CO, VVQiYp, VV1LkE
  VV1LkE   = CCacbo.VViPKf("\c00FFFFFF", VVg9YJ)
  VVyTfh    = CCacbo.VViPKf("\c00888888", VVg9YJ)
  VVWmbA  = CCacbo.VViPKf("\c005A5A5A", VVg9YJ)
  VV6Y3Y    = CCacbo.VViPKf("\c00FF0000", VVg9YJ)
  VVOC4t   = CCacbo.VViPKf("\c00FF5000", VVg9YJ)
  VVJF5Y   = CCacbo.VViPKf("\c00FFFF00", VVg9YJ)
  COLOR_CONS_BRIGHT_YELLOW = CCacbo.VViPKf("\c00FFFFAA", VVg9YJ)
  VV4U0A   = CCacbo.VViPKf("\c0000FF00", VVg9YJ)
  VVBXnD    = CCacbo.VViPKf("\c000066FF", VVg9YJ)
  VVejU1    = CCacbo.VViPKf("\c0000FFFF", VVg9YJ)
  VVo3CO  = CCacbo.VViPKf("\c00DSFFFF", VVg9YJ)  #
  VVQiYp   = CCacbo.VViPKf("\c00FA55E7", VVg9YJ)
  VVtODU    = CCacbo.VViPKf("\c00FF8F5F", VVg9YJ)
CCacbo.VVZnK7()
class CCTskn(Screen):
 def __init__(self, session, path, VVcKW9):
  self.skin, self.skinParam = FFRqpN(VVoavT, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVqFKq   = path
  self.VVvlLv   = ""
  self.VVkByn   = ""
  self.VVcKW9    = VVcKW9
  self.VVIpyD    = ""
  self.VVRasm  = ""
  self.VV7wEn    = False
  self.VV0fdK  = False
  self.postInstAcion   = 0
  self.VVjetF  = "enigma2-plugin-extensions"
  self.VVSL1Q  = "enigma2-plugin-systemplugins"
  self.VVpAJr = "enigma2"
  self.VVCIN6  = 0
  self.VViQr8  = 1
  self.VVe46K  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVyuZo = "DEBIAN"
  else        : self.VVyuZo = "CONTROL"
  self.controlPath = self.Path + self.VVyuZo
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVcKW9:
   self.packageExt  = ".deb"
   self.VVn7jC  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVn7jC  = "#11001020"
  FFpJPp(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFpqes(self["keyRed"] , "Create")
  FFpqes(self["keyGreen"] , "Post Install")
  FFpqes(self["keyYellow"], "Installation Path")
  FFpqes(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVTqwj  ,
   "green"   : self.VVRBdU ,
   "yellow"  : self.VVWTKe  ,
   "blue"   : self.VVY2mG  ,
   "cancel"  : self.VVUXbc
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFKDC6(self)
  if self.VVn7jC:
   FFL3RG(self["myBody"], self.VVn7jC)
   FFL3RG(self["myLabel"], self.VVn7jC)
  self.VVMgzo(True)
  self.VVM8a6(True)
 def VVM8a6(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVZ1gt()
  if isFirstTime:
   if   package.startswith(self.VVjetF) : self.VVqFKq = VVObQC + self.VVIpyD + "/"
   elif package.startswith(self.VVSL1Q) : self.VVqFKq = VVDDy9 + self.VVIpyD + "/"
   else            : self.VVqFKq = self.Path
  if self.VV7wEn : myColor = VVtODU
  else    : myColor = VV1LkE
  txt  = ""
  txt += "Source Path\t: %s\n" % FFhTMc(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFhTMc(self.VVqFKq, VVJF5Y)
  if self.VVkByn : txt += "Package File\t: %s\n" % FFhTMc(self.VVkByn, VVyTfh)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFhTMc("Check Control File fields : %s" % errTxt, VVOC4t)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFhTMc("Restart GUI", VVtODU)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFhTMc("Reboot Device", VVtODU)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFhTMc("Post Install", VV4U0A), act)
  if not errTxt and VVOC4t in controlInfo:
   txt += "Warning\t: %s\n" % FFhTMc("Errors in control file may affect the result package.", VVOC4t)
  txt += "\nControl File\t: %s\n" % FFhTMc(self.controlFile, VVyTfh)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVRBdU(self):
  VVRj9e = []
  VVRj9e.append(("No Action"    , "noAction"  ))
  VVRj9e.append(("Restart GUI"    , "VVOdjF"  ))
  VVRj9e.append(("Reboot Device"   , "rebootDev"  ))
  FFLATx(self, self.VVBW22, title="Package Installation Option (after completing installation)", VVRj9e=VVRj9e)
 def VVBW22(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVOdjF"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVMgzo(False)
   self.VVM8a6()
 def VVWTKe(self):
  rootPath = FFhTMc("/%s/" % self.VVIpyD, VVWmbA)
  VVRj9e = []
  VVRj9e.append(("Current Path"        , "toCurrent"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Extension Path"       , "toExtensions" ))
  VVRj9e.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVRj9e.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFLATx(self, self.VVr8iu, title="Installation Path", VVRj9e=VVRj9e)
 def VVr8iu(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVe4sl(FF1KSt(self.Path, True))
   elif item == "toExtensions"  : self.VVe4sl(VVObQC)
   elif item == "toSystemPlugins" : self.VVe4sl(VVDDy9)
   elif item == "toRootPath"  : self.VVe4sl("/")
   elif item == "toRoot"   : self.VVe4sl("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVLPmb, boundFunction(CCMTIp, mode=CCMTIp.VVIzr0, VV3a7H=VVXKuz))
 def VVLPmb(self, path):
  if len(path) > 0:
   self.VVe4sl(path)
 def VVe4sl(self, parent, withPackageName=True):
  if withPackageName : self.VVqFKq = parent + self.VVIpyD + "/"
  else    : self.VVqFKq = "/"
  mode = self.VVQv2F()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVFb9f(mode), self.controlFile))
  self.VVM8a6()
 def VVY2mG(self):
  if fileExists(self.controlFile):
   lines = FFwZqG(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFJeIH(self, self.VV4DkX, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFikHE(self, "Version not found or incorrectly set !")
  else:
   FF9mKB(self, self.controlFile)
 def VV4DkX(self, VVUtSx):
  if VVUtSx:
   version, color = self.VVKgP0(VVUtSx, False)
   if color == VVejU1:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVUtSx, self.controlFile))
    self.VVM8a6()
   else:
    FFikHE(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVUXbc(self):
  if self.newControlPath:
   if self.VV7wEn:
    self.VVMGTL()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFhTMc(self.newControlPath, VVyTfh)
    txt += FFhTMc("Do you want to keep these files ?", VVJF5Y)
    FF2QoN(self, self.close, txt, callBack_No=self.VVMGTL, title="Create Package", VV9d4I=True)
  else:
   self.close()
 def VVMGTL(self):
  os.system(FFH6kH("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVFb9f(self, mode):
  if   mode == self.VViQr8 : prefix = self.VVjetF
  elif mode == self.VVe46K : prefix = self.VVSL1Q
  else        : prefix = self.VVpAJr
  return prefix + "-" + self.VVRasm
 def VVQv2F(self):
  if   self.VVqFKq.startswith(VVObQC) : return self.VViQr8
  elif self.VVqFKq.startswith(VVDDy9) : return self.VVe46K
  else            : return self.VVCIN6
 def VVMgzo(self, isFirstTime):
  self.VVIpyD   = os.path.basename(os.path.normpath(self.Path))
  self.VVIpyD   = "_".join(self.VVIpyD.split())
  self.VVRasm = self.VVIpyD.lower()
  self.VV7wEn = self.VVRasm == VVs2jC.lower()
  if self.VV7wEn and self.VVRasm.endswith("ajpan"):
   self.VVRasm += "el"
  if self.VV7wEn : self.VVvlLv = VVXKuz
  else    : self.VVvlLv = CFG.packageOutputPath.getValue()
  self.VVvlLv = FFZ2H0(self.VVvlLv)
  if not pathExists(self.controlPath):
   os.system(FFH6kH("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VV7wEn : t = PLUGIN_NAME
  else    : t = self.VVIpyD
  self.VV4dS1(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVZQQ4.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VV7wEn : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VV4dS1(self.postrmFile, txt)
  if self.VV7wEn:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVR4kJ)
   self.VV4dS1(self.preinstFile, txt)
  else:
   self.VV4dS1(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVIpyD)
  mode = self.VVQv2F()
  if isFirstTime and not mode == self.VVCIN6:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVM6J3
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VV4dS1(self.postinstFile, txt, VVgvsD=True)
  os.system(FFH6kH("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VV7wEn : version, descripton, maintainer = VVR4kJ , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVIpyD , self.VVIpyD
   txt = ""
   txt += "Package: %s\n"  % self.VVFb9f(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VV4dS1(self, path, lines, VVgvsD=False):
  if not fileExists(path) or VVgvsD:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVZ1gt(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFwZqG(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFhTMc(line, VVOC4t)
     elif not line.startswith(" ")    : line = FFhTMc(line, VVOC4t)
     else          : line = FFhTMc(line, VVejU1)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVejU1
   else   : color = VVOC4t
   descr = FFhTMc(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVOC4t
     elif line.startswith((" ", "\t")) : color = VVOC4t
     elif line.startswith("#")   : color = VVyTfh
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVKgP0(val, True)
      elif key == "Version"  : version, color = self.VVKgP0(val, False)
      elif key == "Maintainer" : maint  , color = val, VVejU1
      elif key == "Architecture" : arch  , color = val, VVejU1
      else:
       color = VVejU1
      if not key == "OE" and not key.istitle():
       color = VVOC4t
     else:
      color = VVtODU
     txt += FFhTMc(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVkByn = self.VVvlLv + packageName
   self.VV0fdK = True
   errTxt = ""
  else:
   self.VVkByn  = ""
   self.VV0fdK = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVKgP0(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVejU1
  else          : return val, VVOC4t
 def VVTqwj(self):
  if not self.VV0fdK:
   FFikHE(self, "Please fix Control File errors first.")
   return
  if self.VVcKW9: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF1KSt(self.VVqFKq, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVIpyD
  symlinkTo  = FF09PB(self.Path)
  dataDir   = self.VVqFKq.rstrip("/")
  removePorjDir = FFH6kH("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFH6kH("rm -f '%s'" % self.VVkByn) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFzDPn()
  if self.VVcKW9:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFhOy2("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV7wEn:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVqFKq == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVyuZo)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVkByn, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVkByn
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVkByn, FFMRMu(result  , VV4U0A))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVqFKq, FFMRMu(instPath, VVejU1))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFMRMu(failed, VVOC4t))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFF3Kc(self, cmd)
class CCMTIp(Screen):
 VV5tos   = 0
 VVIzr0  = 1
 VVr5N1 = 20
 VVvRDo  = None
 def __init__(self, session, VV3a7H="/", mode=VV5tos, VVVodz="Select", VVfhdd=30, gotoMovie=False):
  self.skin, self.skinParam = FFRqpN(VVD8FW, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFpJPp(self)
  FFpqes(self["keyRed"] , "Exit")
  FFpqes(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVVodz = VVVodz
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCMTIp.VVvRDo = self
  if   self.gotoMovie        : VVhSUH, self.VV3a7H = True , CCMTIp.VVw0KC(self)[1] or "/"
  elif self.mode == self.VV5tos  : VVhSUH, self.VV3a7H = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVIzr0 : VVhSUH, self.VV3a7H = False, VV3a7H
  else           : VVhSUH, self.VV3a7H = True , VV3a7H
  self.VV3a7H = FFZ2H0(self.VV3a7H)
  self["myMenu"] = CCyFrD(  directory   = "/"
         , VVhSUH   = VVhSUH
         , VVCpQL = True
         , VVs47w   = self.skinParam["width"]
         , VVfhdd   = self.skinParam["bodyFontSize"]
         , VVn4Lz  = self.skinParam["bodyLineH"]
         , VVYKLY  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV4R5P      ,
   "red"    : self.VVvxQz     ,
   "green"    : self.VVNMx5    ,
   "yellow"   : self.VVUvI7   ,
   "blue"    : self.VVzZY1   ,
   "menu"    : self.VVpeq5    ,
   "info"    : self.VVb9Si    ,
   "cancel"   : self.VVlCx0     ,
   "pageUp"   : self.VVlCx0     ,
   "chanUp"   : self.VVlCx0
  }, -1)
  FFjyc0(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVvICD)
 def onExit(self):
  CCMTIp.VVvRDo = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVvICD)
  FFe9R7(self)
  FFl7ED(self["myMenu"], bg="#06003333")
  FFKDC6(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVIzr0:
   FFpqes(self["keyGreen"], self.VVVodz)
   color = "#22000022"
   FFL3RG(self["myBody"], color)
   FFL3RG(self["myMenu"], color)
   color = "#22220000"
   FFL3RG(self["myTitle"], color)
   FFL3RG(self["myBar"], color)
  self.VVvICD()
  if self.VVS4tv(self.VV3a7H) > self.bigDirSize:
   FFNWTN(self, "Changing directory...")
   FFbH1W(self.VVd9Sr)
  else:
   self.VVd9Sr()
 def VVd9Sr(self):
  self["myMenu"].VV1Cml(self.VV3a7H)
  if self.gotoMovie:
   self.VVCpyz(chDir=False)
 def VV0Yzk(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVmwiv(self):
  self["myMenu"].refresh()
  FFA2or()
 def VVS4tv(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VV4R5P(self):
  if self["myMenu"].VVqVIN():
   path = self.VVKjZx(self.VVq5cQ())
   if self.VVS4tv(path) > self.bigDirSize:
    FFNWTN(self, "Changing directory...")
    FFbH1W(self.VVPP7m)
   else:
    self.VVPP7m()
  else:
   self.VVksV3()
 def VVPP7m(self):
  self["myMenu"].descent()
  self.VVvICD()
 def VVlCx0(self):
  if self["myMenu"].VVW3Vx():
   self["myMenu"].moveToIndex(0)
   self.VVPP7m()
 def VVvxQz(self):
  if not FFtZy4(self):
   self.close("")
 def VVNMx5(self):
  if self.mode == self.VVIzr0:
   path = self.VVKjZx(self.VVq5cQ())
   self.close(path)
 def VVb9Si(self):
  FFjNEj(self, self.VVVyuD, title="Calculating size ...")
 def VVVyuD(self):
  path = self.VVKjZx(self.VVq5cQ())
  param = self.VVKXDa(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFT5H5("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCMTIp.VVQtWe(path)
     freeSize = CCMTIp.VVu6ch(path)
     size = totSize - freeSize
     totSize  = CCMTIp.VVJrmt(totSize)
     freeSize = CCMTIp.VVJrmt(freeSize)
    else:
     size = FFT5H5("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCMTIp.VVJrmt(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFhTMc(pathTxt, VVtODU) + "\n"
   if slBroken : fileTime = self.VV6LUC(path)
   else  : fileTime = self.VV4Zkg(path)
   def VVWMqO(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVWMqO("Path"    , pathTxt)
   txt += VVWMqO("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVWMqO("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVWMqO("Total Size"   , "%s" % totSize)
    txt += VVWMqO("Used Size"   , "%s" % usedSize)
    txt += VVWMqO("Free Size"   , "%s" % freeSize)
   else:
    txt += VVWMqO("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVWMqO("Owner"    , owner)
   txt += VVWMqO("Group"    , group)
   txt += VVWMqO("Perm. (User)"  , permUser)
   txt += VVWMqO("Perm. (Group)"  , permGroup)
   txt += VVWMqO("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVWMqO("Perm. (Ext.)" , permExtra)
   txt += VVWMqO("iNode"    , iNode)
   txt += VVWMqO("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVM6J3, VVM6J3)
    txt += hLinkedFiles
   txt += self.VVUc02(path)
  else:
   FFikHE(self, "Cannot access information !")
  if len(txt) > 0:
   FFCsft(self, txt)
 def VVKXDa(self, path):
  path = path.strip()
  path = FF09PB(path)
  result = FFT5H5("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV0GDX(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV0GDX(perm, 1, 4)
   permGroup = VV0GDX(perm, 4, 7)
   permOther = VV0GDX(perm, 7, 10)
   permExtra = VV0GDX(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFHpNj("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVUc02(self, path):
  txt  = ""
  res  = FFT5H5("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFhTMc("File Attributes:", VVQiYp), txt)
  return txt
 def VV4Zkg(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFIb5k(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFIb5k(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFIb5k(os.path.getctime(path))
  return txt
 def VV6LUC(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFT5H5("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFT5H5("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFT5H5("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVKjZx(self, currentSel):
  currentDir  = self["myMenu"].VVW3Vx()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVqVIN():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVq5cQ(self):
  return self["myMenu"].getSelection()[0]
 def VVvICD(self):
  FFNWTN(self)
  path = self.VVKjZx(self.VVq5cQ())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV9o2E = self.VVFkPP()
  if VV9o2E and len(VV9o2E) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVGqaQ(path)
  if self.mode == self.VV5tos and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVGqaQ(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVsWOr(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVpeq5(self):
  if self.mode == self.VV5tos:
   path  = self.VVKjZx(self.VVq5cQ())
   isDir  = os.path.isdir(path)
   VVRj9e = []
   VVRj9e.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVuCso(path):
     sepShown = True
     VVRj9e.append(VVmGWQ)
     VVRj9e.append( (VVtODU + "Archiving / Packaging"      , "VVWxGy"  ))
    if self.VVujqL(path):
     if not sepShown:
      VVRj9e.append(VVmGWQ)
     VVRj9e.append( (VVtODU + "Read Backup information"     , "VVDxtL"  ))
     VVRj9e.append( (VVtODU + "Compress Octagon Image (to zip File)"  , "VV7K52" ))
   elif os.path.isfile(path):
    selFile = self.VVq5cQ()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVRj9e.extend(self.VVHSZi(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVRj9e.extend(self.VVNvOj(True))
    elif selFile.endswith(".m3u")              : VVRj9e.extend(self.VVbwTf(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF1ivq(path):
     VVRj9e.append(VVmGWQ)
     VVRj9e.append((VVtODU + "View"     , "textView_def" ))
     VVRj9e.append((VVtODU + "View (Select Encoder)" , "textView_enc" ))
     VVRj9e.append((VVtODU + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVRj9e.append(VVmGWQ)
     VVRj9e.append(   (VVtODU + txt      , "VVksV3"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(     ("Create SymLink"       , "VVyJkw" ))
   if not self.VVuCso(path):
    VVRj9e.append(   ("Rename"          , "VVHhSO" ))
    VVRj9e.append(   ("Copy"           , "copyFileOrDir" ))
    VVRj9e.append(   ("Move"           , "moveFileOrDir" ))
    VVRj9e.append(   ("DELETE"          , "VVnvMZ" ))
    if fileExists(path):
     VVRj9e.append(VVmGWQ)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVRj9e.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVRj9e.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVRj9e.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVRj9e.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCMTIp.VVw0KC(self)
   if fPath:
    VVRj9e.append(VVmGWQ)
    VVRj9e.append(   (VVJF5Y + "Go to current movie"  , "VVCpyz"))
   VVRj9e.append(VVmGWQ)
   VVRj9e.append(    ("Set current directory as \"Startup Path\"" , "VV6nIy" ))
   FFLATx(self, self.VVc6Zu, title="Options", VVRj9e=VVRj9e)
 def VVc6Zu(self, item=None):
  if self.mode == self.VV5tos:
   if item is not None:
    path = self.VVKjZx(self.VVq5cQ())
    selFile = self.VVq5cQ()
    if   item == "properties"    : self.VVb9Si()
    elif item == "VVWxGy"  : self.VVWxGy(path)
    elif item == "VVDxtL"  : self.VVDxtL(path)
    elif item == "VV7K52" : self.VV7K52(path)
    elif item.startswith("extract_")  : self.VVTkCu(path, selFile, item)
    elif item.startswith("script_")   : self.VVtfOM(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVR7jsItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFqg4C(self, path)
    elif item.startswith("textView_enc") : self.VVla65(path)
    elif item.startswith("text_Edit")  : CC4vHM(self, path)
    elif item == "chmod644"     : self.VVPJf3(path, selFile, "644")
    elif item == "chmod755"     : self.VVPJf3(path, selFile, "755")
    elif item == "chmod777"     : self.VVPJf3(path, selFile, "777")
    elif item == "VVyJkw"   : self.VVyJkw(path, selFile)
    elif item == "VVHhSO"   : self.VVHhSO(path, selFile)
    elif item == "copyFileOrDir"   : self.VVDn4T(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVDn4T(path, selFile, True)
    elif item == "VVnvMZ"   : self.VVnvMZ(path, selFile)
    elif item == "createNewFile"   : self.VViuj6(path, True)
    elif item == "createNewDir"    : self.VViuj6(path, False)
    elif item == "VVCpyz"   : self.VVCpyz()
    elif item == "VV6nIy"   : self.VV6nIy(path)
    elif item == "VVksV3"    : self.VVksV3()
    else         : self.close()
 def VVksV3(self):
  selFile = self.VVq5cQ()
  path  = self.VVKjZx(selFile)
  if os.path.isfile(path):
   VV46qm = []
   category = self["myMenu"].VVSeML(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVurnB(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CCZG9b.VVlyqK(self, path)
   elif category == "txt"         : FFqg4C(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVFpdk(path, selFile)
   elif category == "scr"         : self.VVibaR(path, selFile)
   elif category == "m3u"         : self.VV8Hj7(path, selFile)
   elif category in ("ipk", "deb")       : self.VVPWDC(path, selFile)
   elif category == "mus"         : self.VVyqyP(self, path)
   elif category == "mov"         : self.VVyqyP(self, path)
   elif not FF1ivq(path)        : FFqg4C(self, path)
 def VVUvI7(self):
  path = self.VVKjZx(self.VVq5cQ())
  action = self.VVGqaQ(path)
  if action == 1:
   self.VVOwoG(path)
   FFNWTN(self, "Added", 500)
  elif action == -1:
   self.VVxQCW(path)
   FFNWTN(self, "Removed", 500)
  self.VVGqaQ(path)
 def VVOwoG(self, path):
  VV9o2E = self.VVFkPP()
  if not VV9o2E:
   VV9o2E = []
  if len(VV9o2E) >= self.VVr5N1:
   FFikHE(SELF, "Max bookmarks reached (max=%d)." % self.VVr5N1)
  elif not path in VV9o2E:
   VV9o2E = [path] + VV9o2E
   self.VVPUtB(VV9o2E)
 def VVzZY1(self):
  VV9o2E = self.VVFkPP()
  if VV9o2E:
   newList = []
   for line in VV9o2E:
    newList.append((line, line))
   VV5GJ7  = ("Delete"  , self.VVafcE )
   VVr5GC = ("Move Up"   , self.VV1uyk )
   VVBBKW  = ("Move Down" , self.VVlg90 )
   self.bookmarkMenu = FFLATx(self, self.VV5KmL, title="Bookmarks", VVRj9e=newList, VV5GJ7=VV5GJ7, VVr5GC=VVr5GC, VVBBKW=VVBBKW)
 def VVafcE(self, VVq5cQObj, path):
  if self.bookmarkMenu:
   VV9o2E = self.VVxQCW(path)
   self.bookmarkMenu.VVSy0k(VV9o2E)
 def VV1uyk(self, VVq5cQObj, path):
  if self.bookmarkMenu:
   VV9o2E = self.bookmarkMenu.VV9gpO(True)
   if VV9o2E:
    self.VVPUtB(VV9o2E)
 def VVlg90(self, VVq5cQObj, path):
  if self.bookmarkMenu:
   VV9o2E = self.bookmarkMenu.VV9gpO(False)
   if VV9o2E:
    self.VVPUtB(VV9o2E)
 def VV5KmL(self, folder=None):
  if folder:
   folder = FFZ2H0(folder)
   self["myMenu"].VV1Cml(folder)
   self["myMenu"].moveToIndex(0)
  self.VVvICD()
 def VVFkPP(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVsWOr(self, path):
  VV9o2E = self.VVFkPP()
  if VV9o2E and path in VV9o2E:
   return True
  else:
   return False
 def VVQ5Ft(self):
  if VVFkPP():
   return True
  else:
   return False
 def VVPUtB(self, VV9o2E):
  line = ",".join(VV9o2E)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVxQCW(self, path):
  VV9o2E = self.VVFkPP()
  if VV9o2E:
   while path in VV9o2E:
    VV9o2E.remove(path)
   self.VVPUtB(VV9o2E)
   return VV9o2E
 def VVCpyz(self, chDir=True):
  fPath, fDir, fName = CCMTIp.VVw0KC(self)
  if fPath:
   if chDir:
    self["myMenu"].VV1Cml(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFNWTN(self, "Not found", 1000)
 def VV6nIy(self, path):
  if not os.path.isdir(path):
   path = FF1KSt(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVurnB(self, selFile, VVqTs3, command):
  FF2QoN(self, boundFunction(FFF3Kc, self, command, VV7kSC=self.VVmwiv), "%s\n\n%s" % (VVqTs3, selFile))
 def VVHSZi(self, path, calledFromMenu):
  destPath = self.VVcNfZ(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVRj9e = []
  if calledFromMenu:
   VVRj9e.append(VVmGWQ)
   color = VVtODU
  else:
   color = ""
  VVRj9e.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVRj9e.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVRj9e.append((color + "Extract Here"            , "extract_here"  ))
  if VV98Ue and path.endswith(".tar.gz"):
   VVRj9e.append(VVmGWQ)
   VVRj9e.append((color + 'Convert to ".ipk" Package' , "VVVuFq"  ))
   VVRj9e.append((color + 'Convert to ".deb" Package' , "VVA1hd"  ))
  return VVRj9e
 def VVFpdk(self, path, selFile):
  FFLATx(self, boundFunction(self.VVTkCu, path, selFile), title="Compressed File Options", VVRj9e=self.VVHSZi(path, False))
 def VVTkCu(self, path, selFile, item=None):
  if item is not None:
   parent  = FF1KSt(path, False)
   destPath = self.VVcNfZ(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVM6J3
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFhOy2("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFhOy2("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVM6J3, VVM6J3)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFsnYb(self, cmd)
   elif path.endswith(".zip"):
    self.VVo0da(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVSFvt(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFH6kH("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVurnB(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVurnB(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FF1KSt(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVurnB(selFile, "Extract Here ?"      , cmd)
   elif item == "VVVuFq" : self.VVVuFq(path)
   elif item == "VVA1hd" : self.VVA1hd(path)
 def VVcNfZ(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVo0da(self, item, path, parent, destPath, VVqTs3):
  FF2QoN(self, boundFunction(self.VVSHR6, item, path, parent, destPath), VVqTs3)
 def VVSHR6(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVM6J3
  cmd  = FFhOy2("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFMRMu(destPath, VV4U0A))
  cmd +=   sep
  cmd += "fi;"
  FFZNP9(self, cmd, VV7kSC=self.VVmwiv)
 def VVSFvt(self, item, path, parent, destPath, VVqTs3):
  FF2QoN(self, boundFunction(self.VVV6Ki, item, path, parent, destPath), VVqTs3)
 def VVV6Ki(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFZ2H0(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVM6J3
  cmd  = FFhOy2("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFMRMu(destPath, VV4U0A))
  cmd +=   sep
  cmd += "fi;"
  FFZNP9(self, cmd, VV7kSC=self.VVmwiv)
 def VVNvOj(self, addSep=False):
  VVRj9e = []
  if addSep:
   VVRj9e.append(VVmGWQ)
  VVRj9e.append((VVtODU + "View Script File"  , "script_View"  ))
  VVRj9e.append((VVtODU + "Execute Script File" , "script_Execute" ))
  VVRj9e.append((VVtODU + "Edit"     , "script_Edit" ))
  return VVRj9e
 def VVibaR(self, path, selFile):
  FFLATx(self, boundFunction(self.VVtfOM, path, selFile), title="Script File Options", VVRj9e=self.VVNvOj())
 def VVtfOM(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFqg4C(self, path)
   elif item == "script_Execute" : self.VVurnB(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC4vHM(self, path)
 def VVbwTf(self, addSep=False):
  VVRj9e = []
  if addSep:
   VVRj9e.append(VVmGWQ)
  VVRj9e.append((VVtODU + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVRj9e.append((VVtODU + "Edit"      , "m3u_Edit" ))
  VVRj9e.append((VVtODU + "View"      , "m3u_View" ))
  return VVRj9e
 def VV8Hj7(self, path, selFile):
  FFLATx(self, boundFunction(self.VVR7jsItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVRj9e=self.VVbwTf())
 def VVR7jsItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFjNEj(self, boundFunction(self.session.open, CCfMBx, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CC4vHM(self, path)
   elif item == "m3u_View"  : FFqg4C(self, path)
 def VVla65(self, path):
  if fileExists(path) : FFjNEj(self, boundFunction(CCIa4v.VVREeD, self, path, boundFunction(self.VVcxhc, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FF9mKB(self, path)
 def VVcxhc(self, path, item=None):
  if item:
   FFqg4C(self, path, encLst=item)
 def VVPJf3(self, path, selFile, newChmod):
  FF2QoN(self, boundFunction(self.VV7UDr, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV7UDr(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV1lRr)
  result = FFT5H5(cmd)
  if result == "Successful" : FF7k8q(self, result)
  else      : FFikHE(self, result)
 def VVyJkw(self, path, selFile):
  parent = FF1KSt(path, False)
  self.session.openWithCallback(self.VVb5ZK, boundFunction(CCMTIp, mode=CCMTIp.VVIzr0, VV3a7H=parent, VVVodz="Create Symlink here"))
 def VVb5ZK(self, newPath):
  if len(newPath) > 0:
   target = self.VVKjZx(self.VVq5cQ())
   target = FF09PB(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFZ2H0(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFikHE(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FF2QoN(self, boundFunction(self.VVwcze, target, link), "Create Soft Link ?\n\n%s" % txt, VV9d4I=True)
 def VVwcze(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV1lRr)
  result = FFT5H5(cmd)
  if result == "Successful" : FF7k8q(self, result)
  else      : FFikHE(self, result)
 def VVHhSO(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFJeIH(self, boundFunction(self.VVckC7, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVckC7(self, path, selFile, VVUtSx):
  if VVUtSx:
   parent = FF1KSt(path, True)
   if os.path.isdir(path):
    path = FF09PB(path)
   newName = parent + VVUtSx
   cmd = "mv '%s' '%s' %s" % (path, newName, VV1lRr)
   if VVUtSx:
    if selFile != VVUtSx:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FF2QoN(self, boundFunction(self.VVUOvy, cmd), message, title="Rename file?")
    else:
     FFikHE(self, "Cannot use same name!", title="Rename")
 def VVUOvy(self, cmd):
  result = FFT5H5(cmd)
  if "Fail" in result:
   FFikHE(self, result)
  self.VVmwiv()
 def VVDn4T(self, path, selFile, isMove):
  if isMove : VVVodz = "Move to here"
  else  : VVVodz = "Copy to here"
  parent = FF1KSt(path, False)
  self.session.openWithCallback(boundFunction(self.VVFM1W, isMove, path, selFile)
         , boundFunction(CCMTIp, mode=CCMTIp.VVIzr0, VV3a7H=parent, VVVodz=VVVodz))
 def VVFM1W(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FF09PB(path)
   newPath = FFZ2H0(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FF2QoN(self, boundFunction(FFSdci, self, cmd, VV7kSC=self.VVmwiv), txt, VV9d4I=True)
   else:
    FFikHE(self, "Cannot %s to same directory !" % action.lower())
 def VVnvMZ(self, path, fileName):
  path = FF09PB(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FF2QoN(self, boundFunction(self.VVsVFb, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVsVFb(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVmwiv()
 def VVuCso(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVDzaH and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VViuj6(self, path, isFile):
  dirName = FFZ2H0(os.path.dirname(path))
  if isFile : objName, VVUtSx = "File"  , self.edited_newFile
  else  : objName, VVUtSx = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFJeIH(self, boundFunction(self.VV8aLN, dirName, isFile, title), title=title, defaultText=VVUtSx, message="Enter %s Name:" % objName)
 def VV8aLN(self, dirName, isFile, title, VVUtSx):
  if VVUtSx:
   if isFile : self.edited_newFile = VVUtSx
   else  : self.edited_newDir  = VVUtSx
   path = dirName + VVUtSx
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV1lRr)
    else  : cmd = "mkdir '%s' %s" % (path, VV1lRr)
    result = FFT5H5(cmd)
    if "Fail" in result:
     FFikHE(self, result)
    self.VVmwiv()
   else:
    FFikHE(self, "Name already exists !\n\n%s" % path, title)
 def VVPWDC(self, path, selFile):
  VVRj9e = []
  VVRj9e.append(("List Package Files"          , "VVEQ0j"     ))
  VVRj9e.append(("Package Information"          , "VVGTmY"     ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Install Package"           , "VVxJNU_CheckVersion" ))
  VVRj9e.append(("Install Package (force reinstall)"      , "VVxJNU_ForceReinstall" ))
  VVRj9e.append(("Install Package (force overwrite)"      , "VVxJNU_ForceOverwrite" ))
  VVRj9e.append(("Install Package (force downgrade)"      , "VVxJNU_ForceDowngrade" ))
  VVRj9e.append(("Install Package (ignore failed dependencies)"    , "VVxJNU_IgnoreDepends" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Remove Related Package"         , "VVnwmV_ExistingPackage" ))
  VVRj9e.append(("Remove Related Package (force remove)"     , "VVnwmV_ForceRemove"  ))
  VVRj9e.append(("Remove Related Package (ignore failed dependencies)"  , "VVnwmV_IgnoreDepends" ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Extract Files"           , "VVCHZH"     ))
  VVRj9e.append(("Unbuild Package"           , "VV94zk"     ))
  FFLATx(self, boundFunction(self.VVi7ze, path, selFile), VVRj9e=VVRj9e)
 def VVi7ze(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVEQ0j"      : self.VVEQ0j(path, selFile)
   elif item == "VVGTmY"      : self.VVGTmY(path)
   elif item == "VVxJNU_CheckVersion"  : self.VVxJNU(path, selFile, VVn4yS     )
   elif item == "VVxJNU_ForceReinstall" : self.VVxJNU(path, selFile, VVNzzW )
   elif item == "VVxJNU_ForceOverwrite" : self.VVxJNU(path, selFile, VVjk7Z )
   elif item == "VVxJNU_ForceDowngrade" : self.VVxJNU(path, selFile, VVxUBG )
   elif item == "VVxJNU_IgnoreDepends" : self.VVxJNU(path, selFile, VV1HbW )
   elif item == "VVnwmV_ExistingPackage" : self.VVnwmV(path, selFile, VVmVbB     )
   elif item == "VVnwmV_ForceRemove"  : self.VVnwmV(path, selFile, VVK2Bq  )
   elif item == "VVnwmV_IgnoreDepends"  : self.VVnwmV(path, selFile, VV9XKC )
   elif item == "VVCHZH"     : self.VVCHZH(path, selFile)
   elif item == "VV94zk"     : self.VV94zk(path, selFile)
   else           : self.close()
 def VVEQ0j(self, path, selFile):
  if FFYQJY("ar") : cmd = "allOK='1';"
  else    : cmd  = FFzDPn()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVM6J3, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVM6J3, VVM6J3)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFrpGA(self, cmd, VV7kSC=self.VVmwiv)
 def VVCHZH(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FF1KSt(path, True) + selFile[:-4]
  cmd  =  FFzDPn()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFH6kH("mkdir '%s'" % dest) + ";"
  cmd +=    FFH6kH("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFMRMu(dest, VV4U0A))
  cmd += "fi;"
  FFF3Kc(self, cmd, VV7kSC=self.VVmwiv)
 def VV94zk(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVmmeH = os.path.splitext(path)[0]
  else        : VVmmeH = path + "_"
  if path.endswith(".deb")   : VVyuZo = "DEBIAN"
  else        : VVyuZo = "CONTROL"
  cmd  = FFzDPn()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVmmeH, FFCUic())
  cmd += "  mkdir '%s';"    % VVmmeH
  cmd += "  CONTPATH='%s/%s';"  % (VVmmeH, VVyuZo)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVmmeH
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVmmeH, VVmmeH)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVmmeH
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVmmeH, VVmmeH)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVmmeH
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVmmeH
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVmmeH, FFMRMu(VVmmeH, VV4U0A))
  cmd += "fi;"
  FFF3Kc(self, cmd, VV7kSC=self.VVmwiv)
 def VVGTmY(self, path):
  listCmd  = FFdVFr(VVP0LQ, "")
  infoCmd  = FFq4eO(VVuptD , "")
  filesCmd = FFq4eO(VVO3W1, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFwDGd(VVJF5Y)
   notInst = "Package not installed."
   cmd  = FF1ZnE("File Info", VVJF5Y)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF1ZnE("System Info", VVJF5Y)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFMRMu(notInst, VVtODU))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF1ZnE("Related Files", VVJF5Y)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFsnYb(self, cmd)
  else:
   FFNDX7(self)
 def VVxJNU(self, path, selFile, cmdOpt):
  cmd = FFq4eO(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FF2QoN(self, boundFunction(FFF3Kc, self, cmd, VV7kSC=FFA2or), "Install Package ?\n\n%s" % selFile)
  else:
   FFNDX7(self)
 def VVnwmV(self, path, selFile, cmdOpt):
  listCmd  = FFdVFr(VVP0LQ, "")
  infoCmd  = FFq4eO(VVuptD, "")
  instRemCmd = FFq4eO(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFMRMu(errTxt, VVtODU))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFMRMu(cannotTxt, VVtODU))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFMRMu(tryTxt, VVtODU))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FF2QoN(self, boundFunction(FFF3Kc, self, cmd, VV7kSC=FFA2or), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFNDX7(self)
 def VVAU59(self, path):
  hostName = FFT5H5("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVujqL(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVAU59(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVWxGy(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVRj9e = []
  VVRj9e.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVRj9e.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVRj9e.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVRj9e.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVRj9e.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVRj9e.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVRj9e.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVRj9e.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVRj9e.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVRj9e.append(VVmGWQ)
  VVRj9e.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVRj9e.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFLATx(self, boundFunction(self.VVNBpM, path), VVRj9e=VVRj9e)
 def VVNBpM(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVRscN(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVRscN(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVRscN(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVRscN(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVRscN(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVRscN(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVRscN(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVRscN(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVRscN(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVRscN(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVII2I(path, False)
   elif item == "convertDirToDeb"   : self.VVII2I(path, True)
   else         : self.close()
 def VVII2I(self, path, VVcKW9):
  self.session.openWithCallback(self.VVmwiv, boundFunction(CCTskn, path=path, VVcKW9=VVcKW9))
 def VVRscN(self, path, fileExt, preserveDirStruct):
  parent  = FF1KSt(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFhOy2("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFhOy2("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFhOy2("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVM6J3
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFH6kH("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFMRMu(resultFile, VV4U0A))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFMRMu(failed, VVOC4t))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFrpGA(self, cmd, VV7kSC=self.VVmwiv)
 def VVDxtL(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFqg4C(self, versionFile)
 def VV7K52(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVAU59(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFikHE(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFwZqG(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FF1KSt(path, False)
  VVmmeH = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFMRMu(errCmd, VVOC4t))
  installCmd = FFq4eO(VVn4yS , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVmmeH, VVmmeH)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVmmeH
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVmmeH
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVmmeH, VVmmeH)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFF3Kc(self, cmd, VV7kSC=self.VVmwiv)
 def VVVuFq(self, path):
  FFikHE(self, "Under Construction.")
 def VVA1hd(self, path):
  FFikHE(self, "Under Construction.")
 @staticmethod
 def VVyqyP(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCxKzH, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVw0KC(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFZ2H0(fDir), fName
  return "", "", ""
 @staticmethod
 def VVQtWe(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVu6ch(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVJrmt(size, mode=0):
  txt = CCMTIp.VVsMX8(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVsMX8(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCyFrD(MenuList):
 def __init__(self, VVCpQL=False, directory="/", VVW9qE=True, VVhSUH=True, VVqVA7=True, VVx3oC=None, VVJ0bh=False, VV4nNk=False, VVBdwt=False, isTop=False, VVA6pY=None, VVs47w=1000, VVfhdd=30, VVn4Lz=30, VVYKLY="#00000000"):
  MenuList.__init__(self, list, VVCpQL, eListboxPythonMultiContent)
  self.VVW9qE  = VVW9qE
  self.VVhSUH    = VVhSUH
  self.VVqVA7  = VVqVA7
  self.VVx3oC  = VVx3oC
  self.VVJ0bh   = VVJ0bh
  self.VV4nNk   = VV4nNk or []
  self.VVBdwt   = VVBdwt or []
  self.isTop     = isTop
  self.additional_extensions = VVA6pY
  self.VVs47w    = VVs47w
  self.VVfhdd    = VVfhdd
  self.VVn4Lz    = VVn4Lz
  self.pngBGColor    = FF3EtY(VVYKLY)
  self.EXTENSIONS    = self.VVN6LN()
  self.VVTBRF   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVcNG9, self.VVfhdd))
  self.l.setItemHeight(self.VVn4Lz)
  self.png_mem   = self.VVtOrC("mem")
  self.png_usb   = self.VVtOrC("usb")
  self.png_fil   = self.VVtOrC("fil")
  self.png_dir   = self.VVtOrC("dir")
  self.png_dirup   = self.VVtOrC("dirup")
  self.png_srv   = self.VVtOrC("srv")
  self.png_slwfil   = self.VVtOrC("slwfil")
  self.png_slbfil   = self.VVtOrC("slbfil")
  self.png_slwdir   = self.VVtOrC("slwdir")
  self.VVRZsS()
  self.VV1Cml(directory)
 def VVtOrC(self, category):
  return LoadPixmap("%s%s.png" % (VVpTxo, category), getDesktop(0))
 def VVN6LN(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVoy6B(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FF09PB(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFhTMc(" -> " , VVJF5Y) + FFhTMc(os.readlink(path), VV4U0A)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVn4Lz + 10, 0, self.VVs47w, self.VVn4Lz, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVHk1Q: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVn4Lz-4, self.VVn4Lz-4, png, self.pngBGColor, self.pngBGColor, VVHk1Q))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVn4Lz-4, self.VVn4Lz-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVSeML(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVRZsS(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVITh1(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVszXL(self, file):
  if os.path.realpath(file) == file:
   return self.VVITh1(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVITh1(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVITh1(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVfz32(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVTBRF.info(l[0][0]).getEvent(l[0][0])
 def VVZvh2(self):
  return self.list
 def VVQz5f(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV1Cml(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVqVA7:
    self.current_mountpoint = self.VVszXL(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVqVA7:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVBdwt and not self.VVQz5f(path, self.VV4nNk):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVoy6B(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVJ0bh:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVTBRF = eServiceCenter.getInstance()
   list = VVTBRF.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVW9qE and not self.isTop:
   if directory == self.current_mountpoint and self.VVqVA7:
    self.list.append(self.VVoy6B(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVBdwt and self.VVITh1(directory) in self.VVBdwt):
    self.list.append(self.VVoy6B(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVW9qE:
   for x in directories:
    if not (self.VVBdwt and self.VVITh1(x) in self.VVBdwt) and not self.VVQz5f(x, self.VV4nNk):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVoy6B(name = name, absolute = x, isDir = True, png = png))
  if self.VVhSUH:
   for x in files:
    if self.VVJ0bh:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFhTMc(" -> " , VVJF5Y) + FFhTMc(target, VV4U0A)
       else:
        png = self.png_slbfil
        name += FFhTMc(" -> " , VVJF5Y) + FFhTMc(target, VVOC4t)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVSeML(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVpTxo, category))
    if (self.VVx3oC is None) or iCompile(self.VVx3oC).search(path):
     self.list.append(self.VVoy6B(name = name, absolute = x , isDir = False, png = png))
  if self.VVqVA7 and len(self.list) == 0:
   self.list.append(self.VVoy6B(name = FFhTMc("No USB connected", VVyTfh), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVW3Vx(self):
  return self.current_directory
 def VVqVIN(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV1Cml(self.getSelection()[0], select = self.current_directory)
 def VV7NdX(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV5veg(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVBBzC)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVBBzC)
 def refresh(self):
  self.VV1Cml(self.current_directory, self.VV7NdX())
 def VVBBzC(self, action, device):
  self.VVRZsS()
  if self.current_directory is None:
   self.refresh()
class CCKJ2y(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFRqpN(VVlXnV, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV9o2E   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VV2ARE(defFG, "#00FFFFFF")
  self.defBG   = self.VV2ARE(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFpJPp(self, self.Title)
  self["keyRed"].show()
  FFpqes(self["keyGreen"] , "< > Transp.")
  FFpqes(self["keyYellow"], "Foreground")
  FFpqes(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVKr6m        ,
   "yellow"   : boundFunction(self.VVp8Lj, False)  ,
   "blue"   : boundFunction(self.VVp8Lj, True)  ,
   "up"   : self.VVFwmU          ,
   "down"   : self.VV5ndD         ,
   "left"   : self.VVWfTh         ,
   "right"   : self.VV6a4U         ,
   "last"   : boundFunction(self.VValU9, -5) ,
   "next"   : boundFunction(self.VValU9, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFL3RG(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFL3RG(self["keyRed"] , c)
  FFL3RG(self["keyGreen"] , c)
  self.VVgfja()
  self.VV1YzJ()
  FFOEeE(self["myColorTst"], self.defFG)
  FFL3RG(self["myColorTst"], self.defBG)
 def VV2ARE(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VV1YzJ(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVd7gd(0, 0)
     return
 def VVKr6m(self):
  self.close(self.defFG, self.defBG)
 def VVFwmU(self): self.VVd7gd(-1, 0)
 def VV5ndD(self): self.VVd7gd(1, 0)
 def VVWfTh(self): self.VVd7gd(0, -1)
 def VV6a4U(self): self.VVd7gd(0, 1)
 def VVd7gd(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VV6NSg()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVZONc()
 def VVgfja(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVZONc(self):
  color = self.VV6NSg()
  if self.isBgMode: FFL3RG(self["myColorTst"], color)
  else   : FFOEeE(self["myColorTst"], color)
 def VVp8Lj(self, isBg):
  self.isBgMode = isBg
  self.VVgfja()
  self.VV1YzJ()
 def VValU9(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVd7gd(0, 0)
 def VVFvk8(self):
  return hex(self.transp)[2:].zfill(2)
 def VV6NSg(self):
  return ("#%s%s" % (self.VVFvk8(), self.colors[self.curRow][self.curCol])).upper()
class CC3CXk(Screen):
 VVvo9X  = 0
 VVuYHz = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFRhrh()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFRqpN(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFpJPp(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VV1FKu)
 def VVbRSr(self, path=""):
  if path :
   self.VVMfy6()
   FFjNEj(self, boundFunction(self.VVDLwl, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVDLwl()
 def VVDLwl(self, path=""):
  if path:
   subtList, err = self.VVObs0(path)
   if err    : self.VV1FKu(err)
   elif not subtList : self.VV1FKu("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVVTx5()
  else:
   if self.VVROd7():
    self.VVVTx5()
   elif self.subtitleMode == CC3CXk.VVuYHz:
    self.VV1FKu("noResume")
   else:
    if self.VVAPTN(): self.VVVTx5()
    else         : self.VV1FKu("noAutoSrt")
 def VVVTx5(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FFNWTN(self, "Subtitle started", 1000, isGrn=True)
  self.VVMfy6()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVRADf)
  except:
   self.timerUpdate.callback.append(self.VVRADf)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVlytH)
  except:
   self.timerEndText.callback.append(self.VVlytH)
  self.VVnG3o(True)
 def VV1FKu(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVnG3o(False)
  self.endCallback(res)
 def VVnG3o(self, isAdd):
  lst = [CFG.subtDelay, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VVMfy6
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except Exception as e:
      pass
 def VVROd7(self):
  fPath, fDir, fName = CCMTIp.VVw0KC(self)
  if fPath:
   path = fPath + ".ajp"
   if fileExists(path):
    lines = FFwZqG(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVObs0(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVAPTN(self):
  bestSrt, bestRatio = CC3CXk.VVtyfc(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVObs0(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVGcRi(self):
  VVRj9e = []
  if self.lastSubtFile:
   VVRj9e.append(("Settings"      , "set"  ))
   VVRj9e.append(("Change Encoding"    , "enc"  ))
   VVRj9e.append(("Disable Current Subtitle"  , "disab" ))
   VVRj9e.append(VVmGWQ)
  VVRj9e.append(("Find all srt file"    , "findSrt" ))
  lst = CC3CXk.VVBaG7(self)
  if lst:
   VVRj9e.append(VVmGWQ)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FFhTMc(fName, VV4U0A)
    VVRj9e.append((fName, item))
  win = FFLATx(self, self.VVQyXy, VVRj9e=VVRj9e, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVQyXy(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FFL3RG(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VVGcox, CCjaGY)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFjNEj(self, boundFunction(CCIa4v.VVREeD, self, self.lastSubtFile, self.VVcVFu, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFNWTN(self, "SRT File error", 1000)
   elif item == "disab":
    fPath, fDir, fName = CCMTIp.VVw0KC(self)
    os.system(FFH6kH("rm -f '%s'" % fPath + ".ajp"))
    self.VV1FKu("noErr")
   elif item == "findSrt":
    CC3CXk.VV9HZc(self, self.VVRx8z, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVRx8z(item)
 def VVGcox(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FFL3RG(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VVLHRD()
   self.VVMfy6()
 def VVMfy6(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFQQAT():
   fnt = VVcNG9
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFOEeE(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFc6K0(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVRx8z(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVObs0(path, enc)
  if err    : FFNWTN(self, err, 2000)
  elif not subtList : FFNWTN(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FFOEeE(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFNWTN(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVcVFu(self, item=None):
  if item:
   self.VVRx8z(self.lastSubtFile, item)
 @staticmethod
 def VVBaG7(SELF):
  fPath, fDir, fName = CCMTIp.VVw0KC(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVtyfc(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCMTIp.VVw0KC(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CC3CXk.VVBaG7(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CC0sln.VVPTz7(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVAPWF(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVObs0(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFtYtQ(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFwZqG(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVAPWF(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVLHRD()
  return subtList, ""
 def VVLHRD(self):
  fPath, fDir, fName = CCMTIp.VVw0KC(self)
  if fPath and pathExists(fDir):
   with open(fPath + ".ajp", "w") as f:
    f.write("srt=%s\n" % self.lastSubtFile)
    f.write("delay=%s\n" % CFG.subtDelay.getValue())
    if self.lastSubtEnc:
     f.write("enc=%s\n" % self.lastSubtEnc)
 def VVRADf(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCxKzH.VV9oI9(self)
  txtDur = 0
  lines = []
  self.VVzmD4(posVal)
  if self.currentIndex == -2:
   return
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FFOEeE(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFOEeE(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVzmD4(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVlytH(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VV9HZc(SELF, cbFnc, defSrt="", pos=0):
  FFjNEj(SELF, boundFunction(CC3CXk.VVTZ8l, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVTZ8l(SELF, cbFnc, defSrt="", pos=0):
  FFNWTN(SELF)
  lines = FF6vhB('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FF85RC(1)))
  if lines:
   lines.sort()
   VVRj9e = []
   for item in lines:
    VVRj9e.append(((VV4U0A if defSrt == item else "") + item, item))
   VVrdmH = ("Show Full Path", CC3CXk.VVCHwx)
   win = FFLATx(SELF, boundFunction(CC3CXk.VV86KS, cbFnc), title="Subtitle Files", VVRj9e=VVRj9e, width=1200, height=500 if pos == 1 else 900, VVrdmH=VVrdmH)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFNWTN(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVCHwx(VVq5cQObj, path):
  FFCsft(VVq5cQObj, path, title="Full Path")
 @staticmethod
 def VV86KS(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VV8LWY():
  c = s = m = h = 0
  with open(VVXKuz + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCjaGY(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFRqpN(VVoWAS, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFpJPp(self, title=self.Title)
  FFpqes(self["keyRed"] , "Exit")
  FFpqes(self["keyGreen"] , "Save")
  FFpqes(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VVM6J3 *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVM6J3 *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVgEiL  ,
   "green"   : self.VVoCsu   ,
   "yellow"  : boundFunction(FF2QoN, self, self.VVCekW, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVgEiL
  }, -1)
  self.onShown.append(self.VVk68Z)
 def VVk68Z(self):
  self.onShown.remove(self.VVk68Z)
  FFl7ED(self["config"])
  FFwbY1(self, self["config"])
  FFKDC6(self)
  self.instance.move(ePoint(40, 40))
 def VVgEiL(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FF2QoN(self, self.VVoCsu, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVoCsu(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVCekW(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVcNG9)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVoCsu()
class CCqrm5(ScrollLabel):
 def __init__(self, parentSELF, text="", VV9Bx9=True):
  ScrollLabel.__init__(self, text)
  self.VV9Bx9=VV9Bx9
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVwYj2  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVfhdd    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVL09h     ,
   "green"   : self.VVQafV    ,
   "yellow"  : self.VVSh78    ,
   "blue"   : self.VVg8ql    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VVDuLh, 0) ,
   "next"   : boundFunction(self.VVDuLh, 2) ,
   "0"    : boundFunction(self.VVDuLh, 1) ,
   "pageUp"  : self.VVI7S0      ,
   "chanUp"  : self.VVI7S0      ,
   "pageDown"  : self.VVNqTq      ,
   "chanDown"  : self.VVNqTq
  }, -1)
 def VVGV2Z(self, isResizable=True, VVsLA9=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFKDC6(self.parentSELF, True)
  self.isResizable = isResizable
  if VVsLA9:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVfhdd  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFL3RG(self, color)
 def FFL3RGColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVwYj2 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVPgkV()
 def pageUp(self):
  if self.VVwYj2 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVwYj2 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVI7S0(self):
  self.setPos(0)
 def VVNqTq(self):
  self.setPos(self.VVwYj2-self.pageHeight)
 def VVFfXC(self):
  return self.VVwYj2 <= self.pageHeight or self.curPos == self.VVwYj2 - self.pageHeight
 def VVPgkV(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVwYj2, 3))
   start = int((100 - vis) * self.curPos / (self.VVwYj2 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVjlB2=VVFcS3):
  old_VVFfXC = self.VVFfXC()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVwYj2 = self.long_text.calculateSize().height()
   if self.VV9Bx9 and self.VVwYj2 > self.pageHeight:
    self.scrollbar.show()
    self.VVPgkV()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVwYj2))
   if   VVjlB2 == VVzgBH: self.setPos(0)
   elif VVjlB2 == VVQ2Bk : self.VVNqTq()
   elif old_VVFfXC    : self.VVNqTq()
 def appendText(self, text, VVjlB2=VVQ2Bk):
  self.setText(self.message + str(text), VVjlB2)
 def VVSh78(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVBTb7(size)
 def VVg8ql(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVBTb7(size)
 def VVQafV(self):
  self.VVBTb7(self.VVfhdd)
 def VVBTb7(self, VVfhdd):
  self.long_text.setFont(gFont(self.fontFamily, VVfhdd))
  self.setText(self.message, VVjlB2=VVFcS3)
  self.VVJmq8(calledFromFontSizer=True)
 def VVDuLh(self, align):
  self.long_text.setHAlign(align)
 def VVL09h(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFZ2H0(expPath), self.textOutFile, FFOeCU())
    with open(outF, "w") as f:
     f.write(FFz82T(self.message))
    FF7k8q(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFikHE(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVJmq8(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVwYj2 > 0 and self.pageHeight > 0:
   if self.VVwYj2 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVwYj2
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
