import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVoSRl   = "v8.6.3"
VVEexn    = "02-03-2023"
EASY_MODE    = 0
VVthOR   = 0
VVJuMy   = 0
VVgk0E  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVJdOR  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVBI3c    = "/media/usb/"
VVNOZw    = "/usr/share/enigma2/picon/"
VVMLsI = "/etc/enigma2/blacklist"
VVORe1   = "/etc/enigma2/"
VVupPm   = "AJPan"
VV4mJx  = "AUTO FIND"
VVBZu4  = "Custom"
VVObca  = None
VVvnxr    = ""
VVOZAa = "Regular"
VV9aFU = "Fixed"
VVeMes  = "AJP_Main"
VVNXZt = "AJP_Terminal"
VVXkur = "AJP_System"
VV9whc  = VVOZAa
VVZiux    = ""
VVfKPQ   = " && echo 'Successful' || echo 'Failed!'"
VVQkUw  = "Cannot continue (No Enough Memory) !"
VVlQE0  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVEYMF  = "utf8"
VVnK97    = ("-" * 100, )
SEP      = "-" * 80
VVcsO2  = False
VVksGH  = False
VVX871     = 0
VVQ1ff    = 1
VV7eKu    = 2
VVZbiC   = 3
VVButu    = 4
VVkFYy    = 5
VVECKd = 6
VV1QnR = 7
VVnSFr  = 8
VVaqWa   = 9
VVElI4  = 10
VVDE1v  = 11
VVQDxF = 12
VVLPi8 = 13
VV6mg1 = 14
VVV2FZ  = 15
VVpcXS    = 16
VVbInz   = 17
VVfADj   = 18
VVy20n    = 19
VV73Mc    = 20
VVD0XK  = 21
VVQoWM    = 22
VV1E5l   = 0
VVBeVn   = 1
VVFkyJ   = 2
def FFs581():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VV9whc
  if VVeMes in lst and CFG.fontPathMain.getValue(): VV9whc = VVeMes
  else               : VV9whc = VVOZAa
  return lst
 else:
  return [VVOZAa]
def FF2UGB(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVEYMF)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VV4mJx, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelection(default=2, choices=[(x, str(x)) for x in range(1, 6, 1)])
CFG.PIconsPath     = ConfigDirectory(default=VVNOZw, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVBI3c, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VV9whc, choices=[(x,  x) for x in FFs581()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFqZ6Y():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVcH3J  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVJ4lT = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVcH3J  : return 0
  elif VVJ4lT : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVE6Dq = FFqZ6Y()
VVuopv = VViSml = VVD6mq = VVvkGK = VVSBcQ = VV4d6Z = VVM17H = VVD1jS = VVomgc = VV30Pd = VV691Y = VVSFOM = VVZkFQ = VVLAFW = VVrexq = VVkbX3 = ""
def FFDHmK()  : FFYJ2q(FFICQv())
def FF5neB()  : FFYJ2q(FF5rVX())
def FFTPS4(tDict): FFYJ2q(iDumps(tDict, indent=4, sort_keys=True))
def FF9fwT(*args): FF6is6(True, True, *args)
def FFYJ2q(*args) : FF6is6(True , False , *args)
def FFc6mi(*args): FF6is6(False, False, *args)
def FF6is6(addSep=True, isArray=True, *args):
 if VVthOR:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFMrqJ(fnc):
 def VV2ekF(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFYJ2q(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VV2ekF
def FFlyGT(*args):
 if VVthOR:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFc6mi("Added to : %s" % path)
def FFAlB5(txt, isAppend=True, ignoreErr=False):
 if VVthOR:
  tm = FFm7sd()
  err = ""
  if not ignoreErr:
   err = FF5rVX()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFYJ2q(err)
  FFYJ2q("Output Log File : %s" % fileName)
def FF5rVX():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFm7sd()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFICQv():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVVgyP = 0
def FFuxxm():
 global VVVgyP
 VVVgyP = iTime()
def FFqNvW(txt=""):
 FFYJ2q(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVVgyP)).rstrip("0"), txt))
VVfevb = []
def FFEBbG(win):
 global VVfevb
 if not win in VVfevb:
  VVfevb.append(win)
def FFKSrd(*args):
 global VVfevb
 for win in VVfevb:
  try:
   win.close()
  except:
   pass
 VVfevb = []
def FFuDgP():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVcP0F = FFuDgP()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFqNyB()    : return PluginDescriptor(fnc=FFk5PO, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFFrMu()      : return getDescriptor(FFiZwa , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FF3nyO()     : return getDescriptor(FFbzyP  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFl4cI()  : return getDescriptor(FFpZf1, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFlXzw() : return getDescriptor(FFNaXY , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFmdFI()  : return getDescriptor(FFdjGD , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFFpZP()  : return getDescriptor(FFs50z  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFh4qO()      : return getDescriptor(FFPVv9, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF3nyO() , FFFrMu() , FFqNyB() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFl4cI())
  result.append(FFlXzw())
  result.append(FFmdFI())
  result.append(FFFpZP())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFh4qO())
 return result
def FFk5PO(reason, **kwargs):
 if reason == 0:
  CCU9He.VVhaju()
  if "session" in kwargs:
   session = kwargs["session"]
   FFJqU5(session)
   CCiFDq(session)
def FFiZwa(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFbzyP, PLUGIN_NAME, 45)]
 else:
  return []
def FFbzyP(session, **kwargs):
 session.open(Main_Menu)
def FFpZf1(session, **kwargs):
 session.open(CCFric)
def FFNaXY(session, **kwargs):
 session.open(CC1B0Q)
def FFdjGD(session, **kwargs):
 CCLDrN.VVLpPr(session)
def FFs50z(session, **kwargs):
 FFXBRY(session, reopen=True)
def FFPVv9(session, **kwargs):
 session.open(CCOQON, fncMode=CCOQON.VVbCqZ)
def FFH03V():
 FFjs00(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFl4cI(), FFlXzw(), FFmdFI(), FFFpZP() ])
 FFjs00(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFh4qO() ])
def FFjs00(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFJqU5(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFK1wj, session, "lok")
 hk.actions["longCancel"]= BF(FFK1wj, session, "lesc")
 hk.actions["longRed"] = BF(FFK1wj, session, "lred")
 for k in (CC0IN8.VVuJyY, CC0IN8.VVmem8, CC0IN8.VVNyMY):
  hk.actions[k] = BF(CC0IN8.VVlfu2, session, k)
def FFK1wj(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCCY2T.VVXsHw:
    CCCY2T.VVXsHw.close()
   if not CCLDrN.VVgkJK:
    CCLDrN.VVLpPr(session)
  except:
   pass
def FFaoHf(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FF74S2(SELF, title="", addLabel=False, addScrollLabel=False, VV8kKb=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFyVZy()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VV6e39 = eTimer()
 try: SELF.VVssgG = SELF.VV6e39.timeout.connect(BF(FF3gTy, SELF))
 except: SELF.VV6e39.callback.append(BF(FF3gTy, SELF))
 SELF.onClose.append(SELF.VV6e39.stop)
 FF3gTy(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCAZUu(SELF)
 if VV8kKb:
  SELF["myMenu"] = MenuList(VV8kKb)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VV0TcE ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFD8ln(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FF7bhs, SELF, "0"),
  "1" : BF(FF7bhs, SELF, "1"),
  "2" : BF(FF7bhs, SELF, "2"),
  "3" : BF(FF7bhs, SELF, "3"),
  "4" : BF(FF7bhs, SELF, "4"),
  "5" : BF(FF7bhs, SELF, "5"),
  "6" : BF(FF7bhs, SELF, "6"),
  "7" : BF(FF7bhs, SELF, "7"),
  "8" : BF(FF7bhs, SELF, "8"),
  "9" : BF(FF7bhs, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFdNKk, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF7bhs(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVkbX3:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVkbX3 + SELF.keyPressed + VViSml)
    txt = VViSml + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFAM12(SELF, txt)
def FFdNKk(SELF, tableObj, colNum, isMenu):
 FFAM12(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFJYbZ(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVCb6L(i)
     else  : SELF.VVagt1(i)
     break
 except:
  pass
def FFyVZy():
 return ("  %s" % VVZiux)
def FFFQrh(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFJYbZ(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFhX1r(color):
 return parseColor(color).argb()
def FFIyfV(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFIY0q(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFK641(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFQQct(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVkbX3)
 else:
  return ""
def FFDeRs(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVkbX3)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FF7kJS(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVkbX3
def FF0dSC(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFQQct(SEP, VV691Y))
 else : return "echo -e '%s';" % SEP
def FFXlM7(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FF7kJS(title, color)
def FFl94Z(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFI2s0(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF2Wwv(fncCB):
 tCons = CClZCM()
 tCons.ePopen(":", BF(FF8Jev, fncCB))
def FF8Jev(fncCB, result, retval):
 fncCB()
def FF0GsP(SELF, fnc, title="Processing ...", clearMsg=True):
 FFAM12(SELF, title)
 tCons = CClZCM()
 tCons.ePopen(":", BF(FF523b, SELF, fnc, clearMsg))
def FF523b(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFAM12(SELF)
def FFv0e0(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVQkUw
  else       : return ""
def FFO8C9(cmd):
 txt = FFv0e0(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFdVkh(cmd):
 lines = FFO8C9(cmd)
 if lines: return lines[0]
 else : return ""
def FFdKBa(SELF, cmd):
 lines = FFO8C9(cmd)
 VVDb2Q = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVDb2Q.append((key, val))
  elif line:
   VVDb2Q.append((line, ""))
 if VVDb2Q:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFyZJ5(SELF, None, header=header, VVI2kC=VVDb2Q, VVWFHs=widths, VVC5IT=28)
 else:
  FFX3ck(SELF, cmd)
def FFWnHJ(cmd):
 return os.system(FFhyjZ(cmd)) == 0
def FF9QaZ(cmd):
 return os.system(FFREuT(cmd)) == 0
def FFhyjZ(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFREuT(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFX3ck(    SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, VVGqay=True, VViXLk=VVBeVn, **kwargs)
def FFYk4h(  SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, **kwargs)
def FFTJt5(   SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, VVOVrJ=True, VVjBKV=True, VViXLk=VVBeVn, **kwargs)
def FF07Rj(  SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, VVOVrJ=True, VVjBKV=True, VViXLk=VVFkyJ, **kwargs)
def FFSEeb(  SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, VVXnTt=True , **kwargs)
def FFuoAz(  session, cmd, **kwargs):      session.open(CCkAox, VVfhG5=cmd, VVXnTt=True , **kwargs)
def FFHHD1( SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, VVWwHQ=True   , **kwargs)
def FFkmQh( SELF, cmd, **kwargs): SELF.session.open(CCkAox, VVfhG5=cmd, VVMfsP=True  , **kwargs)
def FFFS65(cmd):
 return FFWnHJ("which %s" % cmd)
def FFiXBo():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFdVkh(cmd)
def FFViIp(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VV1Lhp     = 0
VVtSO6      = 1
VV4Vav   = 2
VVbV65   = 3
VVfpYt      = 4
VVHjnx      = 5
VVocZq     = 6
VVLIn3     = 7
VVcIUq     = 8
VVpHks = 9
VV7Fa0 = 10
VV3fQ1 = 11
VVyCx7  = 12
VV45S3     = 13
VVe6LU  = 14
VVA0No  = 15
def FFYQcS(parmNum, grepTxt):
 if   parmNum == VV1Lhp  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVtSO6   : param = ["list"   , "apt list"    ]
 elif parmNum == VV4Vav: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVbV65: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFiXBo()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFMlY4(parmNum, package):
 if   parmNum == VVfpYt      : param = ["info"      , "apt show"         ]
 elif parmNum == VVHjnx      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVocZq     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVLIn3     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVcIUq     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVpHks : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV7Fa0 : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VV3fQ1 : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVyCx7  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV45S3     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVe6LU  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVA0No  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFiXBo()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFEDUQ():
 result = FFdVkh("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFMlY4(VVcIUq, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFhyjZ("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFhyjZ("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFQQct(failed1, VV691Y))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFQQct(failed2, VV691Y))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFQQct(failed3, VVD6mq))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFLwTR(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFMlY4(VVcIUq , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFhyjZ("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFQQct(failed1, VV691Y))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFQQct(failed2, VVD6mq))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFQByV(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCP2t1.VVKSaT()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFKcIu(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFQByV(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFRB7k(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FF7PcS(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFQByV(path, maxSize=maxSize, encLst=encLst)
  if lines: FFaIgn(SELF, lines, title=title, VViXLk=VVBeVn, width=1600, height=1000, titleFontSize=30)
  else : FFerNJ(SELF, path, title=title)
 else:
  FFiEaB(SELF, path, title)
def FFZzIv(SELF, fName, title):
 path = VV8hpn + fName
 if fileExists(path):
  txt = FFQByV(path)
  txt = txt.replace("#W#", VVkbX3)
  txt = txt.replace("#Y#", VVSFOM)
  txt = txt.replace("#G#", VViSml)
  txt = txt.replace("#C#", VVZkFQ)
  txt = txt.replace("#P#", VVSBcQ)
  FFaIgn(SELF, txt, title=title)
 else:
  FFiEaB(SELF, path, title)
def FFLPrp(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFoVse(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFxiJi(parent)
 else    : return FFz551(parent)
def FFM4mE(path):
 return os.path.basename(os.path.normpath(path))
def FFBjaU(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FF7PcS(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFY24E(path):
 path = FFz551(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFCcy5(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFFrYw(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFfIuR(path):
 try: os.remove(path)
 except: pass
def FFTYOF(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FF37bK(path):
 return FFWnHJ("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFyRfT(path):
 return FFWnHJ("cp -f '%s' '%s.bak'" % (path, path))
def FFxiJi(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFz551(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFlzja():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVgk0E)
 paths.append(VVgk0E.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFLPrp(ba)
 for p in list:
  p = ba + p + VVgk0E
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVupPm, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVgk0E, VVupPm , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVIBn1, VV8hpn = FFlzja()
def FFpVsc():
 def VVfdmI(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVMaos   = VVfdmI(CFG.backupPath, CC8YBo.VVtxg4())
 VVXTxT   = VVfdmI(CFG.downloadedPackagesPath, t)
 VVeOpj  = VVfdmI(CFG.exportedTablesPath, t)
 VVUZB7  = VVfdmI(CFG.exportedPIconsPath, t)
 VVpyqo   = VVfdmI(CFG.packageOutputPath, t)
 global VVBI3c
 VVBI3c = FFxiJi(CFG.backupPath.getValue())
 if VVMaos or VVpyqo or VVXTxT or VVeOpj or VVUZB7 or oldMovieDownloadPath:
  configfile.save()
 return VVMaos, VVpyqo, VVXTxT, VVeOpj, VVUZB7, oldMovieDownloadPath
def FFjpIf(path):
 path = FFz551(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFWHnI(SELF, pathList, tarFileName, addTimeStamp=True):
 VVI2kC = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVI2kC.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVI2kC.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVI2kC.append(path)
 if not VVI2kC:
  FFrj68(SELF, "Files not found!")
 elif not pathExists(VVBI3c):
  FFrj68(SELF, "Path not found!\n\n%s" % VVBI3c)
 else:
  VVtBn6 = FFxiJi(VVBI3c)
  tarFileName = "%s%s" % (VVtBn6, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFC2jX())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVI2kC:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFQQct(tarFileName, VVomgc))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFQQct(failed, VVomgc))
  cmd += "fi;"
  cmd +=  sep
  FFYk4h(SELF, cmd)
def FFgqCi(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF0pjL(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF0pjL(SELF["keyInfo"], "info")
def FF0pjL(barObj, fName):
 path = "%s%s%s" % (VV8hpn, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFVZIv(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFcuvM(satNum)
  return satName
def FFcuvM(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFcVIt(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFVZIv(val)
  else  : sat = FFcuvM(val)
 return sat
def FFhxEM(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFVZIv(num)
 except:
  pass
 return sat
def FF0NYq(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFN3N8(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFPfNs(info, iServiceInformation.sServiceref)
   prov = FFPfNs(info, iServiceInformation.sProvider)
   state = str(FFPfNs(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF8yv3(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFWeS7(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFPfNs(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFnnjU(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFettQ(refCode):
 info = FFbXCY(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FF9nVY(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FF8cwz(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFbXCY(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVZ15i = eServiceCenter.getInstance()
  if VVZ15i:
   info = VVZ15i.info(service)
 return info
def FFHFXk(SELF, refCode, VVLARq=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFWeS7(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCbnKw()
  if pr.VV15dO(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVgpfW(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFewyb(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVLARq:
   FFjD6J(SELF, isFromSession)
 try:
  VVWHhY = InfoBar.instance
  if VVWHhY:
   VVaBL4 = VVWHhY.servicelist
   if VVaBL4:
    servRef = eServiceReference(refCode)
    VVaBL4.saveChannel(servRef)
 except:
  pass
def FFewyb(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCbnKw()
    if pr.VV15dO(refCode, chName, decodedUrl, iptvRef):
     pr.VVgpfW(SELF, isFromSession)
def FF8yv3(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFIkRt(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FF4HLW(url): return FFTXJG(url) or FFD0w7(url)
def FFTXJG(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFD0w7(url): return any(x in url for x in ("/series/", "mode=series"))
def FFWeS7(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFD0Hz(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFD0Hz(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFw8K0(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFTNiH(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFKVqd(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFjwce(txt):
 try:
  return FFTNiH(FFKVqd(txt)) == txt
 except:
  return False
def FFYaSE(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFxiJi(newPath), patt))
def FFjD6J(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCLDrN.VVLpPr(session)
 else      : FFXBRY(session, reopen=True)
def FFXBRY(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFXBRY, session), CCCY2T)
  except:
   try:
    FFt7JI(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFtVJx(refCode):
 tp = CC5k8k()
 if tp.VV19v8(refCode) : return True
 else        : return False
def FFUsLp(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFczPJ(True)
     return True
 return False
def FFczPJ(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFD8ZY()
def FFD8ZY():
 VVWHhY = InfoBar.instance
 if VVWHhY:
  VVaBL4 = VVWHhY.servicelist
  if VVaBL4:
   VVaBL4.setMode()
def FFxPkx(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVZ15i = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVZ15i.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFRmby():
 VViowm = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVxlaR = list(VViowm)
 return VVxlaR, VViowm
def FFzWhD():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFVK8S(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFDwGN(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFJMG5():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFC2jX():
 return FFJMG5().replace(" ", "_").replace("-", "").replace(":", "")
def FFjXk8(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFm7sd():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFadHO(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC1B0Q.VVIq7x(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC1B0Q.VVxag1(fName)
     phpFile = tmpDir + fName + ext
     FFWnHJ("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFcx6Z(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FF7O1V(num):
 return "s" if num > 1 else ""
def FFB9GB(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFFgzn(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FF62TB(a, b):
 return (a > b) - (a < b)
def FFY2X3(a, b):
 def VVndo8(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVndo8(a)
 b = VVndo8(b)
 return (a > b) - (a < b)
def FFMEBl(mycmp):
 class CCNYXR(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCNYXR
def FF9glI(SELF, message, title="", VVVnlJ=None):
 SELF.session.openWithCallback(VVVnlJ, CCIJTa, title=title, message=message, VV7Pvn=True)
def FFaIgn(SELF, message, title="", VViXLk=VVBeVn, VVVnlJ=None, **kwargs):
 SELF.session.openWithCallback(VVVnlJ, CCIJTa, title=title, message=message, VViXLk=VViXLk, **kwargs)
def FFrj68(SELF, message, title="")  : FFt7JI(SELF.session, message, title)
def FFiEaB(SELF, path, title="") : FFt7JI(SELF.session, "File not found !\n\n%s" % path, title)
def FFerNJ(SELF, path, title="") : FFt7JI(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFUrcP(SELF, title="")  : FFt7JI(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFt7JI(session, message, title="") : session.open(BF(CCrLLi, title=title, message=message))
def FFTtos(SELF, VVVnlJ, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVVnlJ, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVVnlJ, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFrj68(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFo32K(SELF, callBack_Yes, VVzpP3, callBack_No=None, title="", VVjDSl=False, VVhp5L=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFWURM, callBack_Yes, callBack_No)
         , BF(CCwg6C, title=title, VVzpP3=VVzpP3, VVhp5L=VVhp5L, VVjDSl=VVjDSl))
def FFWURM(callBack_Yes, callBack_No, FFo32Ked):
 if FFo32Ked : callBack_Yes()
 elif callBack_No: callBack_No()
def FFAM12(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFIY0q(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VV6e39.start(timeout, True)
  except: pass
 else: FF3gTy(SELF)
def FFIZWt(*kargs, **kwargs):
 FF2Wwv(BF(FFAM12, *kargs, **kwargs))
def FF3gTy(SELF):
 try:
  SELF.VV6e39.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFHGMZ(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFyZJ5(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CC7zip, **kwargs))
  else   : win = SELF.session.open(BF(CC7zip, **kwargs))
  FFEBbG(win)
  return win
 except:
  return None
def FFHAbB(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCfOtB, **kwargs))
 FFEBbG(win)
 return win
def FFDGmo(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FF4UJX(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFjcFt(SELF, **kwargs):
 SELF.session.open(CCOQON, **kwargs)
def FFtJRK(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FF4dg8(SELF[name], "#000000", 3)
  except:
   pass
def FF4dg8(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FF66Ab(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV9whc, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FF1hGr(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF66Ab(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFSHXD(SELF, winSize.width(), winSize.height())
def FFSHXD(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFKONN():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFaxOr(VVC5IT):
 screenSize  = FFKONN()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVC5IT)
 return bodyFontSize
def FFrSHG(VVC5IT, extraSpace):
 font = gFont(VV9whc, VVC5IT)
 VVS9mk = fontRenderClass.getInstance().getLineHeight(font) or (VVC5IT * 1.25)
 return int(VVS9mk + VVS9mk * extraSpace)
def FFpC8B(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFKONN()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VV9whc, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFrSHG(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VV9whc, titleFontSize, alignLeftCenter)
 if winType in (VVX871, VVQ1ff):
  if winType == VVQ1ff : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVD0XK:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VV73Mc:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VV9whc, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVpcXS:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF9glIL = b2Left2 + timeW + marginLeft
  FF9glIW = b2Left3 - marginLeft - FF9glIL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF9glIL , b2Top, FF9glIW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVbInz:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVButu:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV7eKu:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVZbiC:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV9whc, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV9whc, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVElI4:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV9whc, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVfADj:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV9whc, fontH, alignCenter)
 elif winType in (VVDE1v, VVQDxF, VVLPi8, VV6mg1, VVV2FZ):
  if   winType == VVDE1v  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVQDxF : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVLPi8 : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VV6mg1 : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVDE1v:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VV9whc, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VV9whc, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VV9whc, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VV9whc, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VV9whc, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VV9whc, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VV9whc, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVy20n:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVkFYy:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VV1QnR : align = alignLeftCenter
  elif winType == VVECKd : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVaqWa:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VV9whc
  if usefixedFont and winType == VVECKd:
   fLst = FFs581()
   if   VVNXZt in fLst and CFG.fontPathTerm.getValue(): fontName = VVNXZt
   elif VV9aFU in fLst         : fontName = VV9aFU
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVC5IT = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV9whc, VVC5IT, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV9whc, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVlQE0[i], VV9whc, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVECKd:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVlQE0[i], VV9whc, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVBeWR = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVoSRl)
  VV8kKb = []
  if VVJuMy:
   VV8kKb.append(("-- MY TEST --", "myTest" ))
  VV8kKb.append(("File Manager"  , "fMan" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("IPTV"    , "iptv" ))
  VV8kKb.append(("Movies Browser" , "movie" ))
  VV8kKb.append(("Services/Channels", "chan" ))
  VV8kKb.append(("PIcons"   , "picon" ))
  VV8kKb.append(("EPG"    , "epg"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Terminal"   , "term" ))
  VV8kKb.append(("SoftCam"   , "soft" ))
  VV8kKb.append(("Plugins"   , "plug" ))
  VV8kKb.append(("Backup & Restore" , "bakup" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Date/Time"  , "date" ))
  VV8kKb.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VV8kKb):
   item = list(item)
   item[0] = "  %s" % item[0]
   VV8kKb[ndx] = tuple(item)
  FF74S2(self, title=self.Title, VV8kKb=VV8kKb)
  FFFQrh(self["keyRed"] , "Exit")
  FFFQrh(self["keyGreen"] , "Settings")
  FFFQrh(self["keyYellow"], "Dev. Info.")
  FFFQrh(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VV0eQa      ,
   "yellow": self.VVfgz4      ,
   "blue" : self.VVOWFz     ,
   "info" : BF(FF0GsP, self, self.VVUlzT) ,
   "text" : self.VVAxvc      ,
   "menu" : self.VV2Kkz    ,
   "0"  : BF(self.VVI0Y3, 0)   ,
   "1"  : BF(self.VVZ0gv, "fMan")   ,
   "2"  : BF(self.VVZ0gv, "iptv")   ,
   "3"  : BF(self.VVZ0gv, "movie")   ,
   "4"  : BF(self.VVZ0gv, "chan")   ,
   "5"  : BF(self.VVZ0gv, "picon")   ,
   "6"  : BF(self.VVZ0gv, "epg")   ,
   "7"  : BF(self.VVZ0gv, "term")   ,
   "8"  : BF(self.VVZ0gv, "soft")   ,
   "9"  : BF(self.VVZ0gv, "plug")   ,
   "last" : BF(self.VVZ0gv, "bakup")   ,
   "next" : BF(self.VVZ0gv, "date")
  })
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
  global VVcsO2, VVksGH, VVUfcc
  VVcsO2 = VVksGH = False
  VVUfcc = True
 def VV0TcE(self):
  self.VVZ0gv(self["myMenu"].l.getCurrentSelection()[1])
 def VVZ0gv(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVZiux
   VVZiux = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVw0rk()
   elif item == "fMan"  : self.session.open(CCFric)
   elif item == "iptv"  : self.session.open(CC1B0Q)
   elif item == "movie" : FF0GsP(self, BF(CC7lgd.VV9ZzQ, self))
   elif item == "chan"  : self.session.open(CCGJtF)
   elif item == "picon" : self.VVUVCS()
   elif item == "epg"  : self.session.open(CCS6Mr)
   elif item == "term"  : self.session.open(CCm5ha)
   elif item == "soft"  : self.session.open(CCayiU)
   elif item == "plug"  : self.session.open(CChnXU)
   elif item == "bakup" : self.session.open(CCTHSP)
   elif item == "date"  : self.session.open(CCCO9V)
   elif item == "net"  : self.session.open(CCxheX)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
  FFtJRK(self)
  FFgqCi(self)
  VVMaos, VVpyqo, VVXTxT, VVeOpj, VVUZB7, oldMovieDownloadPath = FFpVsc()
  if VVMaos or VVpyqo or VVXTxT or VVeOpj or VVUZB7 or oldMovieDownloadPath:
   VVPmyh = lambda path, subj: "%s:\n%s\n\n" % (subj, FF7kJS(path, VVvkGK)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVPmyh(VVMaos   , "Backup/Restore Path"    )
   txt += VVPmyh(VVpyqo  , "Created Package Files (IPK/DEB)" )
   txt += VVPmyh(VVXTxT  , "Download Packages (from feeds)" )
   txt += VVPmyh(VVeOpj , "Exported Tables"     )
   txt += VVPmyh(VVUZB7 , "Exported PIcons"     )
   txt += VVPmyh(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFaIgn(self, txt, title="Settings Paths")
  self.VVkHY6()
  if (EASY_MODE or VVthOR or VVJuMy):
   FFIY0q(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFAM12(self, "Welcome", 300)
  FF2Wwv(self.VVHEeI)
 def VVHEeI(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CC8YBo.VVfamk()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFWnHJ("rm -f /tmp/ajp_*")
  global VVcsO2, VVksGH, VVUfcc
  VVcsO2 = VVksGH = False
  del VVUfcc
 def VVI0Y3(self, digit):
  self.VVBeWR += str(digit)
  ln = len(self.VVBeWR)
  global VVcsO2
  if ln == 4:
   if self.VVBeWR == "0" * ln:
    VVcsO2 = True
    FFIY0q(self["myTitle"], "#11805040")
   else:
    self.VVBeWR = "x"
 def VVAxvc(self):
  self.VVBeWR += "t"
  if self.VVBeWR == "0" * 4 + "t" * 2:
   global VVksGH
   VVksGH = True
   FFIY0q(self["myTitle"], "#dd5588")
 def VVUVCS(self):
  found = False
  pPath = CCHnG6.VVYipk()
  if pathExists(pPath):
   for fName, fType in CCHnG6.VVgzfz(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCHnG6)
  else:
   VV8kKb = []
   VV8kKb.append(("PIcons Tools" , "CCHnG6" ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(CCHnG6.VV00tx())
   VV8kKb.append(VVnK97)
   VV8kKb += CCHnG6.VVdTfr()
   FFHAbB(self, self.VVRtKA, VV8kKb=VV8kKb)
 def VVRtKA(self, item=None):
  if item:
   if   item == "CCHnG6"   : self.session.open(CCHnG6)
   elif item == "VV6LB2"  : CCHnG6.VV6LB2(self)
   elif item == "VVkXbW"  : CCHnG6.VVkXbW(self)
   elif item == "findPiconBrokenSymLinks" : CCHnG6.VVvQTB(self, True)
   elif item == "FindAllBrokenSymLinks" : CCHnG6.VVvQTB(self, False)
 def VVUlzT(self):
  changeLogFile = VV8hpn + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFKcIu(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF7kJS("\n%s\n%s\n%s" % (SEP, line, SEP), VV691Y, VVkbX3)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF7kJS(line, VViSml, VVkbX3)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFaIgn(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVoSRl, PLUGIN_DESCRIPTION), VVC5IT=28, width=1600, height=1000, VV2ftx="#11000011")
 def VV2Kkz(self):
  VV8kKb = []
  VV8kKb.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Keys Help"     , "hlp" ))
  FFHAbB(self, self.VVtCOi, VV8kKb=VV8kKb, width=650, title="Options")
 def VVtCOi(self, item=None):
  if item:
   if   item == "libr" : FF0GsP(self, BF(self.VVtkmD))
   elif item == "hlp" : FFZzIv(self, "_help_main", "Main Page (Keys Help)")
 def VV0eQa(self) : self.session.open(CC8YBo)
 def VVfgz4(self) : self.session.open(CCOOXN)
 def VVOWFz(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VV30Pd, VVvkGK, VVSFOM, VV4d6Z
  VV8kKb = []
  VV8kKb.append((c1 + "Change Title Colors"   , "title"  ))
  VV8kKb.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VV8kKb.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VV8kKb.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VV8kKb.append((c2 + "Reset Colors"    , "resetColor" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VV8kKb.append((c3 + "Change Termianl Font"   , "termFont" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c4 + "Change System Font"    , "sysFont"  ))
  FFHAbB(self, BF(self.VV1kMP, title), VV8kKb=VV8kKb, width=600, title=title)
 def VV1kMP(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVXP32()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVfO3M, tDict, item), CCNsZw, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFo32K(self, self.VVQ8gU, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVss4x(VVeMes  )
   elif item == "termFont"  : self.VVss4x(VVNXZt)
   elif item == "sysFont"  : self.VVss4x(VVXkur  )
 def VVtkmD(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVDb2Q, pkgs = self.VVGPrE()
  VVaq9G = ("Install", BF(self.VVHoAI, title, pkgs)  , [])
  VVTO3h  = ("Update Sys. Packages", self.VVkJPL , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVmBED = (LEFT  , CENTER , LEFT  )
  VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, width=1350, VVaq9G=VVaq9G, VVTO3h=VVTO3h, VV0p3X="#00ffffaa", VVLC3P=1)
 def VVHoAI(self, Title, pkgs, VVt27A, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVRkA4, VVt27A)
   item = colList[0]
   if   item == "requests" : CCVrap.VV06qX(self, cbFnc=cbFnc)
   elif item == "Imaging" : CC0IN8.VVUVhe(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFSEeb(self, FFEDUQ(), VVOc3A=cbFnc)
   elif item in pkgs  : FFSEeb(self, FFLwTR(item, item, item.capitalize()), VVOc3A=cbFnc)
  else:
   FFAM12(VVt27A, "Already installed.", 700, isGrn=True)
 def VVkJPL(self, VVt27A, title, txt, colList):
  CChnXU.VVkPNy(self)
 def VVRkA4(self, VVt27A):
  VVDb2Q, pkgs = self.VVGPrE()
  VVt27A.VVtG6o(VVDb2Q[VVt27A.VV2fe8()])
 def VVGPrE(self):
  tDict = {}
  path = VV8hpn + "_sup_lib"
  if fileExists(path):
   for line in FFKcIu(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVPmyh(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FF7kJS("Installed", VVomgc), txt)
   else : return (lib, FF7kJS("Not installed", VVD6mq), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVDb2Q = []
  VVDb2Q.append(VVPmyh("requests", CCVrap.VV06qX(self, install=False)))
  VVDb2Q.append(VVPmyh("Imaging" , CC0IN8.VVUVhe(self, "", False, install=False)))
  VVDb2Q.append(VVPmyh("ar"   , FFWnHJ("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVDb2Q.append(VVPmyh(item, FFFS65(item)))
  VVDb2Q.sort(key=lambda x: x[0].lower())
  return VVDb2Q, pkgs
 def VVt054(self):
  return VVBI3c + "ajpanel_colors"
 def VVXP32(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVt054()
  if fileExists(p):
   txt = FFQByV(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVfO3M(self, tDict, item, fg, bg):
  if fg:
   self.VV8d0J(item, fg)
   self.VV8igT(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVpSeb(tDict)
 def VVpSeb(self, tDict):
   p = self.VVt054()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV8d0J(self, item, fg):
  if   item == "title" : FFIyfV(self["myTitle"], fg)
  elif item == "body"  :
   FFIyfV(self["myMenu"], fg)
   FFIyfV(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFIyfV(self[item], fg)
 def VV8igT(self, item, bg):
  if   item == "title" : FFIY0q(self["myTitle"], bg)
  elif item == "body"  :
   FFIY0q(self["myMenu"], bg)
   FFIY0q(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFIY0q(self["myBar"], bg)
 def VVQ8gU(self):
  FFWnHJ("rm '%s'" % self.VVt054())
  self.close()
 def VVkHY6(self):
  tDict = self.VVXP32()
  for item in ("title", "body", "cursor", "bar"):
   self.VVbi6H(tDict, item)
 def VVbi6H(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV8d0J(name, fg)
  if bg: self.VV8igT(name, bg)
 def VVss4x(self, which):
  if   which == VVeMes  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVNXZt : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVXkur  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCRuKV.VVWxC5(self, "Change %s Font" % title, defFnt, rest, BF(self.VVUZsg, which))
 def VVUZsg(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVeMes  : FFaoHf(CFG.fontPathMain, path)
   elif which == VVNXZt: FFaoHf(CFG.fontPathTerm, path)
   elif which == VVXkur  : FFaoHf(CFG.fontPathSys , path)
   err = Main_Menu.VVjMHW(which)
   if err          : FFrj68(self, err, title=title)
   elif which == VVeMes   : self.close()
   elif which == VVNXZt  : FFAM12(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVXkur and path: FFAM12(self, "System font applied", 1500, isGrn=True)
   elif which == VVXkur   : FFo32K(self, BF(Main_Menu.VVWwHQ, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVWwHQ(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVjMHW(name):
  if   name == VVeMes : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVNXZt: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVXkur : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFs581()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVXkur:
   nameLst = []
   for nm in FFs581():
    if not nm in (VVeMes, VVNXZt):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FF2UGB(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFs581()
  else    : return "Could not add font"
 def VVw0rk(self):
  CCLDrN.VVLpPr(self.session)
class CCxheX(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVBI3c, "ajpanel_network")
  c1, c2 = VVSFOM, VV30Pd
  VV8kKb = []
  VV8kKb.append((c1 + "Network Devices"     , "dev" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Network Scanner (ping)"    , "ping"))
  VV8kKb.append(("Port Scanner (scan for famous ports)" , "port"))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Check Internet Connection"  , "intr"))
  FF74S2(self, title="Network Tools", VV8kKb=VV8kKb)
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FF0GsP(self, self.VV5eyi, title="REading Devices ...")
  elif item == "ping" : FF0GsP(self, self.VVMXVV, title="Scanning ...")
  elif item == "port" : CCiKm1.VVwuqm(self, self.VVcehF, title="Select host to scan")
  elif item == "intr" : self.session.open(CC0Jqs)
 def VV5eyi(self, canCencel=False):
  title = "Network Devices"
  VVDb2Q = self.VVItMp()
  if VVDb2Q:
   bg = "#0a223333"
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVqFCi = BF(self.VV5a51, canCencel)
   VVt6tD  = ("Start FTP"   , self.VVXb8s    , [])
   VV9CSs = ("Entry Options"  , self.VVAWaT  , [])
   VVTO3h = ("Scan for Devices" , self.VVLH2K , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVmBED = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, width=1500, height=900, VVWFHs=widths, VVC5IT=28, VVt6tD=VVt6tD, VVqFCi=VVqFCi, VV9CSs=VV9CSs, VVTO3h=VVTO3h
       , VVuGSD=bg, VVO7CL=bg, VV2ftx=bg, VV0p3X="#11ffff00", VVgjmd="#11220000", VVZ0ud="#00333333", VVGQoh="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVt27A.VVagt1(ndx)
  else:
   FFo32K(self, BF(FF0GsP, self, BF(self.VVys7J, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VV5a51, canCencel), title=title)
 def VVAWaT(self, VVt27A, title, txt, colList):
  VV8kKb = []
  VV8kKb.append(("Change Username"   , "user"))
  VV8kKb.append(("Change Password"   , "pass"))
  VV8kKb.append(("Change Remarks"   , "rem"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Remove Selected Server" , "del"))
  FFHAbB(self, BF(self.VVTlXQ, VVt27A), VV8kKb=VV8kKb, title="Entry Options")
 def VVTlXQ(self, VVt27A, item=None):
  if item:
   if   item == "user" : self.VVKFX2("u", VVt27A)
   elif item == "pass" : self.VVKFX2("p", VVt27A)
   elif item == "rem" : self.VVKFX2("r", VVt27A)
   elif item == "del" : FFo32K(self, BF(FF0GsP, self, BF(self.VVLOAL, VVt27A), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VV5a51(self, canCencel, VVt27A=None):
  if VVt27A: VVt27A.cancel()
  if canCencel : self.close()
 def VVXb8s(self, VVt27A, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFaoHf(CFG.lastNetworkDevice, VVt27A.VV2fe8())
  self.session.openWithCallback(BF(self.VVJQsG, entry, VVt27A), CC3KwQ, entry)
 def VVJQsG(self, entry, VVt27A, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVZMXG("d", newPath, ip, u, p, path, rem)
    self.VVCoDk(VVt27A)
 def VVLH2K(self, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVys7J, mainTableInst=VVt27A), title="Scanning Network ...")
 def VVys7J(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCiKm1.VV5yzI(CCiKm1.VVsWE7)
  if err:
   FFrj68(self, err, title=title)
   return
  telLst, err = CCiKm1.VV5yzI(CCiKm1.VV70Os)
  if err:
   FFrj68(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVADXW(p1, p2): return FFY2X3(p1[0], p2[0])
   lst.sort(key=FFMEBl(VVADXW))
   bg = "#0a202020"
   VVqFCi = BF(self.VV5a51, canCencel)
   VVt6tD  = ("Add to Devices" , BF(self.VV9H5u, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVmBED = (LEFT   , CENTER   , CENTER  )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=lst, VVmBED=VVmBED, VVWFHs=widths, width=1200, VVC5IT=30, VVt6tD=VVt6tD, VVqFCi=VVqFCi, VVLC3P=2
     , VVuGSD=bg, VVO7CL=bg, VV2ftx=bg, VVgjmd="#0a225555", VVGQoh="#11403040")
  else:
   FFrj68(self, "No devices found !", title=title)
 def VVMXVV(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCiKm1.VV5yzI(-1)
  if err:
   FFrj68(self, err, title=title)
  elif lst:
   def VVADXW(p1, p2): return FFY2X3(p1[0], p2[0])
   lst.sort(key=FFMEBl(VVADXW))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVmBED = (LEFT   , LEFT   )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=lst, VVmBED=VVmBED, VVWFHs=widths, width=1000, height=700, VVC5IT=30
     , VVuGSD=bg, VVO7CL=bg, VV2ftx=bg, VVgjmd="#0a225555", VVGQoh="#11403040")
  else:
   FFrj68(self, "Network scanning failed !", title=title)
 def VVcehF(self, ip=None):
  if ip:
   FF0GsP(self, BF(self.VV3GyN, ip), title="Scanning %s" % ip)
 def VV3GyN(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCiKm1.VVY5fU(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCiKm1.VVSRDh(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFaIgn(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVItMp(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFQByV(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVADXW(p1, p2): return FFY2X3(p1[0], p2[0])
  tLst.sort(key=FFMEBl(VVADXW))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVItMp(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFQByV(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVADXW(p1, p2): return FFY2X3(p1[0], p2[0])
  tLst.sort(key=FFMEBl(VVADXW))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VV9H5u(self, mainTableInst, canCencel, VVt27A, title, txt, colList):
  ip, mac, typ = VVt27A.VV4w1S(VVt27A.VV2fe8())
  if "Own" in ip:
   FFAM12(VVt27A, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVItMp():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFTYOF(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVOBBY(ip, u, p, path, rem))
   if mainTableInst: self.VVCoDk(mainTableInst, [ip, u, p, path, rem])
   else   : self.VV5eyi(canCencel)
   VVt27A.cancel()
 def VVOBBY(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVLOAL(self, VVt27A):
  num, ip, u, p, path, rem = VVt27A.VV4w1S(VVt27A.VV2fe8())
  lst = self.VVItMp()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVOBBY(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVCoDk(VVt27A)
  else:
   VVt27A.cancel()
 def VVKFX2(self, col, VVt27A):
  num, ip, u, p, path, rem = VVt27A.VV4w1S(VVt27A.VV2fe8())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFTtos(self, BF(self.VV3LuK, col, orig, VVt27A, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VV3LuK(self, col, orig, VVt27A, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFAM12(VVt27A, "No change", 1500)
   elif not newTxt and col == "u":
    FFAM12(VVt27A, "No user !", 2000)
   else:
    self.VVZMXG(col, newTxt, ip, u, p, path, rem)
    self.VVCoDk(VVt27A)
 def VVZMXG(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVItMp()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVOBBY(ip1, u1, p1, path1, rem1))
 def VVCoDk(self, VVt27A, newEntry=None):
  VVDb2Q = self.VVItMp()
  if VVDb2Q : VVt27A.VVByC5(VVDb2Q, tableRefreshCB=BF(self.VVO0VD, newEntry))
  else  : VVt27A.cancel()
 def VVO0VD(self, newEntry, VVt27A, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVt27A.VVXwRB()):
    if row[1:] == newEntry:
     VVt27A.VVagt1(ndx)
 def VV5a51(self, canCencel, VVt27A=None):
  if VVt27A: VVt27A.cancel()
  if canCencel : self.close()
class CCiKm1():
 VVsWE7 = 21
 VV70Os = 23
 def __init__(self):
  self.VV97Y7()
 def VV97Y7(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVBPcU(self, ip, User, Pass, timeout=5):
  myIp = CCiKm1.VVXMWe()
  if ip != myIp:
   if CCiKm1.VVSRDh(ip, CCiKm1.VVsWE7):
    self.VV97Y7()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVN4uF(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VV9ukl(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVm5wb(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VV9ukl()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VV26Bn(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVg2UV(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVW60w(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVuTGQ(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVIKjE(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVuTGQ()
   if self.VVW60w(path) : typ = "d"
   else      : typ = "b"
   self.VVW60w(curDir)
   return typ
 def VVjYOW(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVW60w(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVqW4h(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVsHtF(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVw9Pa(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVV1g0(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVjYOW(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFfIuR(locFile)
   return "", sz, str(e)
 def VV1HjQ(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VV97Y7()
 @staticmethod
 def VVjdJ5():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVXMWe():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VV0fbd():
  myIp = CCiKm1.VVXMWe()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVsis6():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFdVkh("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VV320f(port=-1):
  lst = []
  def VVNZrq(ip):
   if port > -1: ok = CCiKm1.VVSRDh(ip, port)
   else  : ok = CCiKm1.VVY5fU(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCiKm1.VV0fbd()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVNZrq, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VV5yzI(port):
  myIp = CCiKm1.VVXMWe()
  myGw = CCiKm1.VVsis6()
  tDict = { myIp: CCiKm1.VVjdJ5() }
  devLst, err = CCiKm1.VV320f(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFv0e0("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVSFOM
    elif key == myGw: txt = " %s Gateway" % VVSFOM
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVY5fU(ip):
  return FFWnHJ("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVSRDh(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVQ8ve(ip="1.1.1.1", timeout=1):
  if CCiKm1.VVSRDh(ip, 53, timeout):
   return True
  if CCiKm1.VVY5fU(ip):
   return True
  return FFWnHJ("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVwuqm(SELF, okFnc, title):
  baseIp = CCiKm1.VV0fbd()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFHAbB(SELF, okFnc, VV8kKb=lst, width=600, title=title, VVuGSD="#222222", VVO7CL="#222222")
class CC3KwQ(Screen, CCiKm1):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFpC8B(VVX871, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVC5IT  = self.skinParam["bodyFontSize"]
  self.VVS9mk  = self.skinParam["bodyLineH"]
  self.VVcI5n  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCz7OO.VVzoFM("fil")
  self.png_dir  = CCz7OO.VVzoFM("dir")
  self.png_dirup  = CCz7OO.VVzoFM("dirup")
  self.png_slwfil  = CCz7OO.VVzoFM("slwfil")
  self.png_slbfil  = CCz7OO.VVzoFM("slbfil")
  self.png_slwdir  = CCz7OO.VVzoFM("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCiKm1.__init__(self)
  VV8kKb = [("Item-%d" % x,) for x in range(50)]
  FF74S2(self, title=self.Title, VV8kKb=VV8kKb)
  FFFQrh(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VV8kKb, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VV9whc, self.VVC5IT))
  self["myMenu"].l.setItemHeight(self.VVS9mk)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : BF(self.VVrEeW, True) ,
   "ok" : self.VV0TcE    ,
   "cancel": self.VVrEeW    ,
   "menu" : self.VVWh4S   ,
   "info" : self.VVT6C9  ,
   "pageUp": self.VVxw2C    ,
   "chanUp": self.VVxw2C
  })
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVX2Rk)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
  FFtJRK(self)
  FFgqCi(self)
  FFIY0q(self["keyBlue"], "#11333333")
  FF0GsP(self, self.VVVEfx, title="Connecting ...")
 def VVVEfx(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVBPcU(ip, u, p)
  if err:
   FFrj68(self, err, title=self.Title)
   FFFQrh(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFFQrh(self["keyBlue"], self.ftpIp)
   if not self.VVW60w(path):
    path = "/"
   self.VVjQA3(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VV9ukl():
   self.VV1HjQ()
 def VV0TcE(self):
  if self.VVqiSx():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVjQA3(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVxw2C()
    else         : self.VVqdg4(os.path.join(self.curDir, name))
 def VVrEeW(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVxw2C()
 def VVqiSx(self):
  if self.VV9ukl():
   return True
  else:
   FFrj68(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVqdg4(self, path):
  cat = self.VVI0fh(path)
  if cat in ("pic"):
   FF0GsP(self, BF(self.VV6F5G, path))
  elif cat in ("mov", "mus"):
   if CC1B0Q.VVOBYe("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FF0GsP(self, BF(CCFric.VVDGqS, self, url, rType=rType), title="Playing Media ...")
 def VV6F5G(self, path):
  locFile, size, err = self.VVV1g0(path)
  if err: FFrj68(self, err, title="View Picture File")
  else  : CCJCdT.VVHj4i(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFfIuR))
 def VVX2Rk(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCz7OO.VVOIhw else sel[0][0])
  else  : title=  VVD6mq + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVxw2C(self):
  if self.VVqiSx():
   lastPart = FFM4mE(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVjQA3(parentDir, lastPart, "d")
 def VVjQA3(self, Dir, moveTo="", moveToType=""):
  FF0GsP(self, BF(self.VVcLjJ, Dir, moveTo, moveToType))
 def VVcLjJ(self, Dir, moveTo, moveToType):
  files, err = self.VVg2UV(Dir, isLong=True)
  self.curDir = self.VVuTGQ() or "/"
  self.VVYZD3(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVYZD3(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVULqm(CCz7OO.VVOIhw, CCz7OO.VVOIhw, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVIKjE(target)
    color = VVD6mq if targetState == "b" else VVomgc
    origName = name + VV691Y + linkSep + color + " "+ target
   self.list.append(self.VVULqm(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVULqm(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVI0fh(name)
    if cat: png = LoadPixmap("%s%s.png" % (VV8hpn, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCz7OO.VVOIhw: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVS9mk + 10, 0, self.VVcI5n, self.VVS9mk, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VVcP0F: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVS9mk-4, self.VVS9mk-4, png, None, None, VVcP0F))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVS9mk-4, self.VVS9mk-4, png, None, None))
  return tableRow
 def VVI0fh(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCz7OO.VVFMqt().items():
    if ext in lst:
     return cat
  return ""
 def VVWh4S(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCz7OO.VVOIhw
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VV5rYD(titl, ref, chk, color=""):
   if chk: return VV8kKb.append((color + titl, ref))
   else  : return VV8kKb.append((titl, ))
  VV8kKb = []
  VV5rYD("Properties", "VVT6C9", not isTop)
  c = VVSFOM
  VV8kKb.append(VVnK97)
  VV5rYD("Download Selected File ..."    , "FFadHOFromServer", isFile, c)
  VV5rYD("Upload a Local File to Remote Server ...", "VVWC68" , True  , c)
  VV8kKb.append(VVnK97)
  VV5rYD("Create new directory", "VVNHsf", True)
  VV5rYD("Rename", "VVC13c", not isTop)
  VV5rYD("DELETE", "VV2D19", not isTop, VVSBcQ)
  VV8kKb.append(VVnK97)
  VV5rYD("FTP Server Information", "VVuIVM", True)
  VV8kKb.append(VVnK97)
  VV5rYD("Refresh File List", "refresh", True)
  FFHAbB(self, self.VVVGFj, VV8kKb=VV8kKb, title="Options")
 def VVVGFj(self, item=None):
  if item:
   if   item == "VVT6C9"     : self.VVT6C9()
   elif item == "FFadHOFromServer"   : self.FFadHOFromServer()
   elif item == "VVWC68"   : self.VVWC68()
   elif item == "VVNHsf"   : self.VVNHsf()
   elif item == "VVC13c"   : self.VVC13c()
   elif item == "VV2D19"   : self.VV2D19()
   elif item == "VVuIVM"    : self.VVuIVM()
   elif item == "refresh"and self.VVqiSx() : self.VVjQA3(self.curDir)
 def VVT6C9(self):
  if self.VVqiSx():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FF7kJS("Path", VVSFOM), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVjYOW(path)
    if sz > -1: txt += "Size\t: %s" % CCFric.VVgYti(sz)
   else:
    txt = "Nothing selected"
   FFaIgn(self, txt, title="Properties")
 def VVuIVM(self):
  if self.VVqiSx():
   Sys  = self.VVN4uF() or " -"
   txt = "%s\n  %s\n\n" % (FF7kJS("System:", VVSFOM), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VV26Bn() or " -"
   txt += "%s\n" % (FF7kJS("Status:", VVSFOM))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFaIgn(self, txt, title="FTP Server Information")
 def VVNHsf(self, name=""):
  if self.VVqiSx():
   title = "Add New Directory"
   FFTtos(self, BF(self.VVRlHQ, title), defaultText=name, title=title, message="Enter Directory name")
 def VVRlHQ(self, title, name):
  if name and name.strip():
   if self.VVqW4h(name) : self.VVjQA3(self.curDir, name, "d")
   else     : FFrj68(self, "Failed to create : %s" % name, title)
 def VVC13c(self):
  if self.VVqiSx():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFTtos(self, BF(self.VVfL31, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVfL31(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVw9Pa(name, newName.strip()) : self.VVjQA3(self.curDir, newName, flag)
   else          : FFrj68(self, "Failed to rename to : %s" % newName, title)
 def VV2D19(self):
  if self.VVqiSx():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFo32K(self, BF(FF0GsP, self, BF(self.VV9QCS, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VV9QCS(self, name, flag):
  if self.VVsHtF(name, flag) : self.VVjQA3(self.curDir)
  else         : FFrj68(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFadHOFromServer(self):
  if self.VVqiSx():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVjYOW(remFile)
    if size == -1:
     FFrj68(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVBI3c
     self.session.openWithCallback(BF(self.VVySyv, title, remFile, name, size), BF(CCFric, mode=CCFric.VVocwE, VV9ghp="Download here", VVZmiW=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVySyv(self, title, remFile, name, size, locPath):
  if locPath:
   FFaoHf(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVzr3H, remFile, size, locFile)
       , VVVnlJ = BF(self.VVnF8Z, remFile, size, locFile))
 def VVzr3H(self, remFile, size, locFile, VVtEPC):
  VVtEPC.VVodiL(size)
  VVtEPC.VVsc2i = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVQHvB(data):
     if not VVtEPC or VVtEPC.isCancelled:
      return
     locFileObj.write(data)
     VVtEPC.VV2Wgw(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVQHvB)
   except Exception as e:
    VVtEPC.VVsc2i = str(e)
 def VVnF8Z(self, remFile, size, locFile, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVsc2i:
   FFrj68(self, "%s\n\nftp:/%s" % (VVsc2i, remFile), title="Download Error")
   delF = True
  elif not VVYFmk:
   FFrj68(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FF7PcS(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FF9glI(self, txt, title=title)
   else:
    FFrj68(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFfIuR(locFile)
 def VVWC68(self):
  if self.VVqiSx():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVBI3c
   self.session.openWithCallback(self.VVwOeC, BF(CCFric, VV9ghp="Upload selected file", VVZmiW=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVwOeC(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFaoHf(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FF7PcS(locFile)
   if size == -1:
    FFrj68(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVHrTy, locFile, size, remFile)
        , VVVnlJ = BF(self.VVRdLy, locFile, size, remFile))
 def VVHrTy(self, locFile, size, remFile, VVtEPC):
  VVtEPC.VVodiL(size)
  VVtEPC.VVsc2i = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVHWJw(data):
     if not VVtEPC or VVtEPC.isCancelled:
      VVtEPC.VVsc2i = "Upload cancelled"
      locFileObj.close()
      return
     VVtEPC.VV2Wgw(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVHWJw)
   except Exception as e:
    VVtEPC.VVsc2i = VVtEPC.VVsc2i or str(e)
 def VVRdLy(self, locFile, size, remFile, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVYFmk:
   if size == FF7PcS(locFile) : FF9glI(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVsc2i : err = "%s\n\n%s" % (VVsc2i, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFrj68(self, err, title=title)
   self.VVm5wb()
   self.VVsHtF(remFile, "")
  self.VVjQA3(self.curDir)
class CC0IN8():
 VVuJyY  = "all"
 VVmem8 = "vid"
 VVNyMY  = "osd"
 @staticmethod
 def VVlfu2(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFFS65("grab"):
    winShown = session.current_dialog.shown
    if k == CC0IN8.VVmem8 and winShown: session.current_dialog.hide()
    FF2Wwv(BF(CC0IN8.VVkjG2, title, session, k, winShown))
   else:
    FFt7JI(session, "No Grab command !", title=title)
 @staticmethod
 def VVkjG2(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CC0IN8.VVNyMY:
   if not winShown:
    FFt7JI(session, "No Window to capture !", title=title)
    return
   if not CC0IN8.VVUVhe(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CC0IN8.VVynLw(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFt7JI(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFxiJi(CFG.exportedPIconsPath.getValue()), fTitle, FFC2jX(), ext)
  ok = FF9QaZ("grab -q -s %s > '%s'" % (typ, path))
  if k == CC0IN8.VVmem8 and winShown:
   session.current_dialog.show()
  elif k == CC0IN8.VVNyMY:
   ok = CC0IN8.VVNYuj(path, x, y, w, h)
   if not ok:
    FFfIuR(path)
    FFt7JI(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCJCdT, title=path, VVRuzQ=path))
  else      : FFt7JI(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVUVhe(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFo32K(SELF, BF(CC0IN8.VVZEo8, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVZEo8(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFuoAz, VVOc3A=cbFnc)
  else    : fnc = BF(FFSEeb , VVOc3A=cbFnc)
  fnc(SELF, FFMlY4(VVcIUq, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVynLw(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVNYuj(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFKONN()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFFgzn(x , 0, scrW, 0, w)
     y  = FFFgzn(y , 0, scrH, 0, h)
     x1 = FFFgzn(x1, 0, scrW, 0, w)
     y1 = FFFgzn(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVfLtI(path):
  size = FF7PcS(path)
  sizeTxt = CCFric.VVgYti(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCRuKV(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFpC8B(VVX871, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FF7kJS(" (Requires GUI Restart)", VV4d6Z) if withRestart else ""
  VV8kKb = []
  for path in self.fontsList:
   VV8kKb.append((os.path.splitext(os.path.basename(path))[0], path))
  VV8kKb.sort(key=lambda x: x[0].lower())
  VV8kKb.insert(0, VVnK97)
  VV8kKb.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VV8kKb):
    if len(item) == 2 and item[1] == self.defFnt:
     VV8kKb[ndx] = (VVomgc + item[0], item[1])
     curIndex = ndx
     break
  else:
   VV8kKb[curIndex] = (VVomgc + VV8kKb[curIndex][0], VV8kKb[curIndex][1])
  FF74S2(self, VV8kKb=VV8kKb, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
  self["myMenu"].onSelectionChanged.append(self.VVgMoP)
  self["myBar"].setText(self.VVshdx())
  self["myBar"].instance.setHAlign(1)
  self.VVgMoP()
 def VV0TcE(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVgMoP(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FF2UGB(path, fnt, isRepl=1)
  else:
   fnt = VVOZAa
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVshdx(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVWxC5(SELF, title, defFnt, rest, VVVnlJ):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFYaSE(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVVnlJ, CCRuKV, title, fontsList, defFnt, rest)
  else  : FFrj68(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCoI8d(Screen):
 def __init__(self, session, path, VV8kKb, title):
  self.skin, self.skinParam = FFpC8B(VVX871, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FF74S2(self, VV8kKb=VV8kKb, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0TcE   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VV81TQ,
   "chanUp" : self.VV81TQ,
   "pageDown" : self.VVnEyx ,
   "chanDown" : self.VVnEyx ,
  }, -1)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
  FFIY0q(self["myLabelFrm"], "#11110000")
  FFIY0q(self["myLabelTit"], "#11663322")
  FFIY0q(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VV1S9i)
  self.VV1S9i()
 def VV1S9i(self):
  if fileExists(self.path): txt = FFQByV(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VV0TcE(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV81TQ(self) : self["myMenu"].moveToIndex(0)
 def VVnEyx(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCP2t1():
 @staticmethod
 def VVKSaT():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVC2rS(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFyZJ5(SELF, None, VVI2kC=lst, VVC5IT=30, VVLC3P=1)
 @staticmethod
 def VVhvNn(path, SELF=None):
  for enc in CCP2t1.VVKSaT():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFrj68(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VV1idm(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVDX2J(SELF, path, cbFnc, curEnc=VVEYMF, title="Select Encoding"):
  lst = CCP2t1.VV2clf(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCoI8d, path, lst, title)
 @staticmethod
 def VVZ9IC(SELF, cbFnc, curEnc=VVEYMF, title="Select Encoding"):
  lst = CCP2t1.VV2clf(SELF, "", "")
  if lst:
   FFHAbB(SELF, cbFnc, title=title, VV8kKb=lst, width=1000, height=1000, VVuGSD="#22220000", VVO7CL="#22220000", VVPYdF=True)
 @staticmethod
 def VV2clf(SELF, path, curEnc):
  lst = CCP2t1.VVniwH(path)
  if lst:
   VV8kKb = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVomgc
    elif enc == VVEYMF: c = VV691Y
    else      : c = ""
    VV8kKb.append((c + txt, enc))
   return VV8kKb
  else:
   FFIZWt(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVniwH(path=""):
  encLst = []
  cPath = VV8hpn + "_sup_codecs"
  if fileExists(cPath):
   lines = FFKcIu(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCP2t1.VVKSaT())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCOOXN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV8kKb = []
  VV8kKb.append(("Settings File"   , "SettingsFile"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Box Info"     , "VVlKib"   ))
  VV8kKb.append(("Tuners Info"    , "VVlU39"  ))
  VV8kKb.append(("Python Version"   , "VV2yId"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Screen Size"    , "ScreenSize"   ))
  VV8kKb.append(("Language/Locale"   , "Locale"    ))
  VV8kKb.append(("Processor"    , "Processor"   ))
  VV8kKb.append(("Operating System"   , "OperatingSystem"  ))
  VV8kKb.append(("Drivers"     , "drivers"    ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("System Users"    , "SystemUsers"   ))
  VV8kKb.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VV8kKb.append(("Uptime"     , "Uptime"    ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Host Name"    , "HostName"   ))
  VV8kKb.append(("MAC Address"    , "MACAddress"   ))
  VV8kKb.append(("Network Configuration" , "NetworkConfiguration"))
  VV8kKb.append(("Network Status"   , "NetworkStatus"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Disk Usage"    , "VVJDWj"   ))
  VV8kKb.append(("Mount Points"    , "MountPoints"   ))
  VV8kKb.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VV8kKb.append(("USB Devices"    , "USB_Devices"   ))
  VV8kKb.append(("List Block-Devices"  , "listBlockDevices" ))
  VV8kKb.append(("Directory Size"   , "DirectorySize"  ))
  VV8kKb.append(("Memory"     , "Memory"    ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VV8kKb.append(("Running Processes"  , "RunningProcesses" ))
  VV8kKb.append(("Processes with open files", "ProcessesOpenFiles" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FF74S2(self, VV8kKb=VV8kKb, title="Device Information")
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCx0rY)
   elif item == "VVlKib"   : self.VVlKib()
   elif item == "VVlU39"  : self.VVlU39()
   elif item == "VV2yId"  : self.VV2yId()
   elif item == "ScreenSize"   : FFaIgn(self, "Width\t: %s\nHeight\t: %s" % (FFKONN()[0], FFKONN()[1]))
   elif item == "Locale"    : CCP2t1.VVC2rS(self)
   elif item == "Processor"   : self.VVnXHL()
   elif item == "OperatingSystem"  : FFX3ck(self, "uname -a")
   elif item == "drivers"    : self.VVwsL7()
   elif item == "SystemUsers"   : FFX3ck(self, "id")
   elif item == "LoggedInUsers"  : FFX3ck(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFX3ck(self, "uptime")
   elif item == "HostName"    : FFX3ck(self, "hostname")
   elif item == "MACAddress"   : self.VVexyW()
   elif item == "NetworkConfiguration" : FFX3ck(self, "ifconfig %s %s" % (FFQQct("HWaddr", VVrexq), FFQQct("addr:", VV691Y)))
   elif item == "NetworkStatus"  : FFX3ck(self, "netstat -tulpn", VVC5IT=24, consFont=True)
   elif item == "VVJDWj"   : self.VVJDWj()
   elif item == "MountPoints"   : FFX3ck(self, "mount %s" % (FFQQct(" on ", VV691Y)))
   elif item == "FileSystemTable"  : FFX3ck(self, "cat /etc/fstab", VVC5IT=24, consFont=True)
   elif item == "USB_Devices"   : FFX3ck(self, "lsusb")
   elif item == "listBlockDevices"  : FFX3ck(self, "blkid")
   elif item == "DirectorySize"  : FFX3ck(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV3WWe="Reading size ...")
   elif item == "Memory"    : FFX3ck(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVm9GP()
   elif item == "RunningProcesses"  : FFX3ck(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFX3ck(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VV3k7Y()
   else        : self.close()
 def VVexyW(self):
  res = FFv0e0("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFaIgn(self, txt)
  else:
   FFX3ck(self, "ip link")
 def VVVoYZ(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFO8C9(cmd)
  return lines
 def VVE99i(self, lines, headerRepl, widths, VVmBED):
  VVDb2Q = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVDb2Q.append(parts)
  if VVDb2Q and len(header) == len(widths):
   VVDb2Q.sort(key=lambda x: x[0].lower())
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, VVLC3P=1)
   return True
  else:
   return False
 def VVJDWj(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFv0e0(cmd)
  if not "invalid option" in txt:
   lines  = self.VVVoYZ(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVmBED = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVE99i(lines, headerRepl, widths, VVmBED)
  else:
   cmd = "df -h"
   lines  = self.VVVoYZ(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVmBED = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVE99i(lines, headerRepl, widths, VVmBED)
  if not allOK:
   lines = FFO8C9(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFz551(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVomgc:
     note = "\n%s" % FF7kJS("Green = Mounted Partitions", VVomgc)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VV691Y
     elif line.endswith(mountList) : color = VVomgc
     else       : color = VViSml
     txt += FF7kJS(line, color) + "\n"
    FFaIgn(self, txt + note)
   else:
    FFrj68(self, "Not data from system !")
 def VVm9GP(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVVoYZ(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVmBED = (LEFT , CENTER, LEFT )
  allOK = self.VVE99i(lines, headerRepl, widths, VVmBED)
  if not allOK:
   FFX3ck(self, cmd)
 def VVwsL7(self):
  cmd = FFYQcS(VV4Vav, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFX3ck(self, cmd)
  else : FFUrcP(self)
 def VVnXHL(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFX3ck(self, cmd)
 def VV3k7Y(self):
  cmd = FFYQcS(VVtSO6, "| grep secondstage")
  if cmd : FFX3ck(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFUrcP(self)
 def VVlKib(self):
  c = VVomgc
  VVI2kC = []
  VVI2kC.append((FF7kJS("Box Type"  , c), FF7kJS(self.VViQ09("boxtype").upper(), c)))
  VVI2kC.append((FF7kJS("Board Version", c), FF7kJS(self.VViQ09("board_revision") , c)))
  VVI2kC.append((FF7kJS("Chipset"  , c), FF7kJS(self.VViQ09("chipset")  , c)))
  VVI2kC.append((FF7kJS("S/N"   , c), FF7kJS(self.VViQ09("sn")    , c)))
  VVI2kC.append((FF7kJS("Version"  , c), FF7kJS(self.VViQ09("version")  , c)))
  VVVb2n   = []
  VVjsUf = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVjsUf = SystemInfo[key]
     else:
      VVVb2n.append((FF7kJS(str(key), VVZkFQ), FF7kJS(str(SystemInfo[key]), VVZkFQ)))
  except:
   pass
  if VVjsUf:
   VV1T4S = self.VVGGvI(VVjsUf)
   if VV1T4S:
    VV1T4S.sort(key=lambda x: x[0].lower())
    VVI2kC += VV1T4S
  if VVVb2n:
   VVVb2n.sort(key=lambda x: x[0].lower())
   VVI2kC += VVVb2n
  if VVI2kC:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFyZJ5(self, None, header=header, VVI2kC=VVI2kC, VVWFHs=widths, VVC5IT=28, VVLC3P=1)
  else:
   FFaIgn(self, "Could not read info!")
 def VViQ09(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFKcIu(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVGGvI(self, mbDict):
  try:
   mbList = list(mbDict)
   VVI2kC = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVI2kC.append((FF7kJS(subject, VV691Y), FF7kJS(value, VV691Y)))
  except:
   pass
  return VVI2kC
 def VVlU39(self):
  txt = self.VVYZEK("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVYZEK("/proc/bus/nim_sockets")
  if not txt: txt = self.VV0n3c()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFaIgn(self, txt)
 def VV0n3c(self):
  txt = ""
  VVPmyh = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVPmyh("Slot Name" , slot.getSlotName())
     txt += FF7kJS(slotName, VV691Y)
     txt += VVPmyh("Description"  , slot.getFullDescription())
     txt += VVPmyh("Frontend ID"  , slot.frontend_id)
     txt += VVPmyh("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVYZEK(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFKcIu(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF7kJS(line, VV691Y)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV2yId(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFaIgn(self, txt)
 @staticmethod
 def VVgTbs():
  def VVPmyh(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVPmyh(v,0), "/etc/issue.net": VVPmyh(v,1), "/etc/image-version": VVPmyh(v,2)}
  for p1, d in v.items():
   img = CCOOXN.VVNiSu(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVPmyh(v,0), p + "Plugins/": VVPmyh(v,1), VVJdOR: VVPmyh(v,2), VVgk0E: VVPmyh(v,3)}
  for p1, d in v.items():
   img = CCOOXN.VVFlm6(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVNiSu(path, d):
  if fileExists(path):
   txt = FFQByV(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVFlm6(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCx0rY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV8kKb = []
  VV8kKb.append(("Settings (All)"   , "Settings_All"   ))
  VV8kKb.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VV8kKb.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VV8kKb.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VV8kKb.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VV8kKb.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VV8kKb.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVksGH:
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VV8kKb.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVORe1
   grep = " | grep "
   if   item == "Settings_All"   : FFX3ck(self, cmd)
   elif item == "Settings_HotKeys"  : FFX3ck(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFX3ck(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFX3ck(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFX3ck(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFX3ck(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFX3ck(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFX3ck(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFX3ck(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCayiU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVRfrY, VVNRoN, VVO49t, camCommand = CCayiU.VV2MOQ()
  self.VVNRoN = VVNRoN
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVNRoN:
   c = VV30Pd if VVO49t else VVLAFW
   if   "oscam" in VVNRoN : camName, oC = "OSCam", c
   elif "ncam"  in VVNRoN : camName, nC = "NCam" , c
  VV8kKb = []
  VV8kKb.append(("OSCam Files" , "OSCamFiles" ))
  VV8kKb.append(("NCam Files" , "NCamFiles" ))
  VV8kKb.append(("CCcam Files" , "CCcamFiles" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((VVSFOM + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVSAFv" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VV8kKb.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VV8kKb.append(VVnK97)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VV8kKb.append(FF4UJX(txt, "camInfo", VVNRoN, c))
  VV8kKb.append(VVnK97)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVNRoN:
   for item in camLst: VV8kKb.append(item)
  else:
   for item in camLst: VV8kKb.append((item[0], ))
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCZlKt, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCZlKt, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCZlKt, "cccam"))
   elif item == "VVSAFv" : self.VVSAFv()
   elif item == "OSCamReaders"  : self.VVfUGe("os")
   elif item == "NSCamReaders"  : self.VVfUGe("n")
   elif item == "camInfo"   : FFdKBa(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCayiU.VVzhys(self.session, CCSTYR.VVSNTy)
   elif item == "camLiveReaders" : CCayiU.VVzhys(self.session, CCSTYR.VVBTRm)
   elif item == "camLiveLog"  : CCayiU.VVzhys(self.session, CCSTYR.VVllkm)
   else       : self.close()
 def VVSAFv(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVBI3c, FFC2jX())
  if fileExists(path):
   lines = FFKcIu("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVPmyh = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVPmyh("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVPmyh("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVPmyh("protocol"   , "cccam"))
      f.write(VVPmyh("device"    , "%s,%s" % (host, port)))
      f.write(VVPmyh("user"    , User))
      f.write(VVPmyh("password"   , Pass))
      f.write(VVPmyh("fallback"   , "1"))
      f.write(VVPmyh("group"    , "64"))
      f.write(VVPmyh("cccversion"   , "2.3.2"))
      f.write(VVPmyh("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF9glI(self, "Output = %d Reader%s in:\n\n%s" % (tot, FF7O1V(tot), outFile))
   else:
    FFAM12(self, "No valid CCcam lines", 1500)
  else:
   FFAM12(self, "%s not found" % path, 1500)
 def VVfUGe(self, camPrefix):
  VVDb2Q = self.VVsvWU(camPrefix)
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: int(x[0]))
   if self.VVNRoN and self.VVNRoN.startswith(camPrefix):
    VVaq9G = ("Toggle State", self.VVsywz, [camPrefix], "Changing State ...")
   else:
    VVaq9G = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVmBED  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVaq9G=VVaq9G, VV2v46=True)
 def VVsvWU(self, camPrefix):
  readersFile = self.VVRfrY + camPrefix + "cam.server"
  VVDb2Q = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFKcIu(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVDb2Q.append((str(len(VVDb2Q) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVDb2Q:
    FFrj68(self, "No readers found !")
  else:
   FFiEaB(self, readersFile)
  return VVDb2Q
 def VVsywz(self, VVt27A, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVRfrY, camPrefix)
  readerState  = VVt27A.VVIciO(1)
  readerLabel  = VVt27A.VVIciO(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCayiU.VVEhqD(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVt27A.VVtIYK()
    FFrj68(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVDb2Q = self.VVsvWU(camPrefix)
   if VVDb2Q:
    VVt27A.VVByC5(VVDb2Q)
  else:
   VVt27A.VVtIYK()
 @staticmethod
 def VVEhqD(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFKcIu(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFrj68(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFrj68(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFiEaB(SELF, confFile)
   return None
  if not iRequest:
   FFrj68(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCayiU.VVUUNd(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFrj68(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVUUNd(SELF):
  if iElem:
   return True
  else:
   FFrj68(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVzhys(session, VV0XLI):
  VVRfrY, VVNRoN, VVO49t, camCommand = CCayiU.VV2MOQ()
  if VVNRoN:
   runLog = False
   if   VV0XLI == CCSTYR.VVSNTy : runLog = True
   elif VV0XLI == CCSTYR.VVBTRm : runLog = True
   elif not VVO49t          : FFt7JI(session, message="SoftCam not started yet!")
   elif fileExists(VVO49t)        : runLog = True
   else             : FFt7JI(session, message="File not found !\n\n%s" % VVO49t)
   if runLog:
    session.open(BF(CCSTYR, VVRfrY=VVRfrY, VVNRoN=VVNRoN, VVO49t=VVO49t, VV0XLI=VV0XLI))
  else:
   FFt7JI(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VV2MOQ():
  VVRfrY = "/etc/tuxbox/config/"
  VVNRoN = None
  VVO49t  = None
  camCommand = FFdVkh("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVNRoN = "oscam"
   elif camCmd.startswith("ncam") : VVNRoN = "ncam"
  if VVNRoN:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFQByV(path), IGNORECASE)
     if span:
      VVRfrY = FFxiJi(span.group(1))
      break
   else:
    path = FFdVkh(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFxiJi(path)
    if pathExists(path):
     VVRfrY = path
   tFile = FFxiJi(VVRfrY) + VVNRoN + ".conf"
   tFile = FFdVkh("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVO49t = tFile
  return VVRfrY, VVNRoN, VVO49t, camCommand
class CCZlKt(Screen):
 def __init__(self, VVSbJv, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVRfrY, VVNRoN, VVO49t, camCommand = CCayiU.VV2MOQ()
  if   VVSbJv == "ncam" : self.prefix = "n"
  elif VVSbJv == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VV8kKb = []
  if self.prefix == "":
   VV8kKb.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VV8kKb.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VV8kKb.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VV8kKb.append(("constant.cw"         , "x_constant_cw" ))
   VV8kKb.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VV8kKb.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VV8kKb.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VV8kKb.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VV8kKb.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VV8kKb.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VV8kKb.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VV8kKb.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VV8kKb.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VV8kKb.append(VVnK97)
   VV8kKb.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VV8kKb.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VV8kKb.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFRB7k(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFRB7k(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFRB7k(self, self.VVRfrY + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFRB7k(self, self.VVRfrY + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVxxRD("cam.ccache")
   elif item == "x_cam_conf"  : self.VVxxRD("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVxxRD("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVxxRD("cam.provid")
   elif item == "x_cam_server"  : self.VVxxRD("cam.server")
   elif item == "x_cam_services" : self.VVxxRD("cam.services")
   elif item == "x_cam_srvid2"  : self.VVxxRD("cam.srvid2")
   elif item == "x_cam_user"  : self.VVxxRD("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVIIQV()
   elif item == "x_CCcam_cfg"  : FFRB7k(self, self.VVRfrY + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFRB7k(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFRB7k(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFRB7k(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVxxRD(self, fileName):
  FFRB7k(self, self.VVRfrY + self.prefix + fileName)
 def VVIIQV(self):
  path = self.VVRfrY + "SoftCam.Key"
  if fileExists(path) : FFRB7k(self, path)
  else    : FFRB7k(self, path.replace(".Key", ".key"))
class CCSTYR(Screen):
 VVSNTy  = 0
 VVBTRm = 1
 VVllkm = 2
 def __init__(self, session, VVRfrY="", VVNRoN="", VVO49t="", VV0XLI=VVSNTy):
  self.skin, self.skinParam = FFpC8B(VVECKd, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVO49t   = VVO49t
  self.VV0XLI  = VV0XLI
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVRfrY + VVNRoN + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVNRoN : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVRfrY, self.camPrefix)
  if self.VV0XLI == self.VVSNTy:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VV0XLI == self.VVBTRm:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF74S2(self, self.Title, addScrollLabel=True)
  FFFQrh(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVOR84
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self["myLabel"].VVnulZ(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFtJRK(self)
  self.VVOR84()
 def onExit(self):
  self.timer.stop()
 def VVgk0B(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV6vFc)
  except:
   self.timer.callback.append(self.VV6vFc)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFAM12(self, "Started", 1000)
 def VVQ3A7(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV6vFc)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFAM12(self, "Stopped", 1000)
 def VVOR84(self):
  if self.timerRunning:
   self.VVQ3A7()
  else:
   self.VVgk0B()
   if self.VV0XLI == self.VVSNTy or self.VV0XLI == self.VVBTRm:
    if self.VV0XLI == self.VVSNTy : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCayiU.VVEhqD(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF2Wwv(self.VVDSRO)
    else:
     self.close()
   else:
    self.VVDRzO()
 def VV6vFc(self):
  if self.timerRunning:
   if   self.VV0XLI == self.VVSNTy : self.VVVEI4()
   elif self.VV0XLI == self.VVBTRm : self.VVVEI4()
   else            : self.VVDRzO()
 def VVDRzO(self):
  if fileExists(self.VVO49t):
   fTime = FFDwGN(os.path.getmtime(self.VVO49t))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVtx74(), VViXLk=VVFkyJ)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVO49t)
 def VVDSRO(self):
  self.VVVEI4()
 def VVVEI4(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF7kJS("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVSBcQ))
   self.camWebIfErrorFound = True
   self.VVQ3A7()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VV0XLI == self.VVSNTy : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF7kJS("Error while parsing data elements !\n\nError = %s" % str(e), VVD6mq)
   self.camWebIfErrorFound = True
   self.VVQ3A7()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVPa8u(root)
  self["myLabel"].setText(txt, VViXLk=VVFkyJ)
  self["myBar"].setText("Last Update : %s" % FFJMG5())
 def VVPa8u(self, rootElement):
  def VVPmyh(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VV0XLI == self.VVSNTy:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF7kJS(status, VVomgc)
    else          : status = FF7kJS(status, VVD6mq)
    txt += SEP + "\n"
    txt += VVPmyh("Name"  , name)
    txt += VVPmyh("Description" , desc)
    txt += VVPmyh("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVPmyh("Protocol" , protocol)
    txt += VVPmyh("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF7kJS("Yes", VVomgc)
    else    : enabTxt = FF7kJS("No", VVD6mq)
    txt += SEP + "\n"
    txt += VVPmyh("Label"  , label)
    txt += VVPmyh("Protocol" , protocol)
    txt += VVPmyh("Enabled" , enabTxt)
  return txt
 def VVtx74(self):
  lines = FFO8C9("tail -n %d %s" % (100, self.VVO49t))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VV4d6Z + line[:19] + VViSml + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVM17H + "WebIf" + VViSml)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVZkFQ + h1 + h2 + VViSml + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVomgc + span.group(2) + VVSFOM + span.group(3) + VViSml + span.group(4)
    line = self.VVAgfP(line, VVSFOM, ("(webif)", ))
    line = self.VVAgfP(line, VVSFOM, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVAgfP(line, VVomgc, ("OSCam", "NCam", "log switched"))
    line = self.VVAgfP(line, VVvkGK, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VV691Y + line[ndx + 3:] + VViSml
   elif line.startswith("----") or ">>" in line:
    line = FF7kJS(line, VVkbX3)
   txt += line + "\n"
  return txt
 def VVAgfP(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VViSml + t3
  return line
class CCTHSP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VV8kKb = []
  VV8kKb.append(("Backup Channels"    , "VVVL4Q"   ))
  VV8kKb.append(("Restore Channels"    , "Restore_Channels"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Backup SoftCAM Files"   , "VV5plc" ))
  VV8kKb.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VV8kKb.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VV8kKb.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Backup Network Settings"  , "VV2jFg"   ))
  VV8kKb.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVksGH:
   VV8kKb.append(VVnK97)
   VV8kKb.append((VVSBcQ + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVtrsA"   ))
   VV8kKb.append((VVomgc + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVEexn), "createMyIpk"   ))
   VV8kKb.append((VVomgc + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVEexn), "createMyDeb"   ))
   VV8kKb.append((VVZkFQ + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VV8kKb.append((VVZkFQ + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVcL6K" ))
   VV8kKb.append((VVZkFQ + "Show Windows Stats"           , "VVtbRX" ))
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVVL4Q"    : self.VVVL4Q()
   elif item == "Restore_Channels"    : self.VVnhZc("channels_backup*.tar.gz", self.VVFAp2, isChan=True)
   elif item == "VV5plc"   : self.VV5plc()
   elif item == "Restore_SoftCAM_Files"  : self.VVnhZc("softcam_backup*.tar.gz", self.VVMYYv)
   elif item == "Backup_TunerDiSEqC"   : self.VVY5cB("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVnhZc("tuner_backup*.backup", BF(self.VVEp2u, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVY5cB("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVnhZc("hotkey_*backup*.backup", BF(self.VVEp2u, "misc"))
   elif item == "VV2jFg"    : self.VV2jFg()
   elif item == "Restore_Network"    : self.VVnhZc("network_backup*.tar.gz", self.VVlfrf)
   elif item == "VVtrsA"     : FFo32K(self, BF(FF0GsP, self, BF(CCTHSP.VVtrsA, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVsvi9(False)
   elif item == "createMyDeb"     : self.VVsvi9(True)
   elif item == "createMyTar"     : self.VVRabM()
   elif item == "VVcL6K"   : self.VVcL6K()
   elif item == "VVtbRX"    : CCTHSP.VVtbRX(self)
 @staticmethod
 def VVlBHB(SELF):
  OBF_Path = VVIBn1 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFiEaB(SELF, OBF_Path)
   return None
 @staticmethod
 def VVtbRX(SELF):
  obf = CCTHSP.VVlBHB(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFaIgn(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVtrsA(SELF):
  obf = CCTHSP.VVlBHB(SELF)
  if obf:
   txt, err = obf.fixCode(VVIBn1, VVoSRl, VVEexn)
   if err : FFrj68(SELF, err)
   else : FFaIgn(SELF, txt)
 def VVsvi9(self, VVpmZd):
  OBF_Path = VVIBn1 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFrj68(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFWnHJ("rm -f %s__pycache__/" % VVIBn1)
  FFWnHJ("mv -f '%smain.py' '%s'" % (VVIBn1, OBF_Path))
  FFWnHJ("mv -f '%splugin.py' '%s'" % (VVIBn1, OBF_Path))
  FFWnHJ("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVIBn1))
  self.session.openWithCallback(self.VVHnmw, BF(CCrfCS, path=VVIBn1, VVpmZd=VVpmZd))
 def VVHnmw(self):
  FFWnHJ("mv -f %s %s" % (VVIBn1 + "OBF/main.py" , VVIBn1))
  FFWnHJ("mv -f %s %s" % (VVIBn1 + "OBF/plugin.py", VVIBn1))
 def VVcL6K(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFrj68(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFrj68(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVprbS("%s*.list" % path)
  if err:
   FFiEaB(self, path + "*.list")
   return
  srcF, err = self.VVprbS("%s*main_final.py" % path)
  if err:
   FFiEaB(self, path + "*.final.py")
   return
  VVI2kC = []
  for f in files:
   f = os.path.basename(f)
   VVI2kC.append((f, f))
  FFHAbB(self, BF(self.VV7EN5, path, codF, srcF), VV8kKb=VVI2kC)
 def VV7EN5(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFiEaB(self, logF)
   else     : FF0GsP(self, BF(self.VVJAmu, logF, codF, srcF))
 def VVJAmu(self, logF, codF, srcF):
  lst  = []
  lines = FFKcIu(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFrj68(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVtyjt(lst, logF, newLogF)
  totSrc  = self.VVtyjt(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFaIgn(self, txt)
 def VVprbS(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVtyjt(self, lst, f1, f2):
  txt = FFQByV(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVRabM(self):
  VVI2kC = []
  VVI2kC.append("%s%s" % (VVIBn1, "*.py"))
  VVI2kC.append("%s%s" % (VVIBn1, "*.png"))
  VVI2kC.append("%s%s" % (VVIBn1, "*.xml"))
  VVI2kC.append("%s"  % (VV8hpn))
  FFWHnI(self, VVI2kC, "%s_%s" % (PLUGIN_NAME, VVoSRl), addTimeStamp=False)
 def VVVL4Q(self):
  path1 = VVORe1
  path2 = "/etc/tuxbox/"
  VVI2kC = []
  VVI2kC.append("%s%s" % (path1, "*.tv"))
  VVI2kC.append("%s%s" % (path1, "*.radio"))
  VVI2kC.append("%s%s" % (path1, "*list"))
  VVI2kC.append("%s%s" % (path1, "lamedb*"))
  VVI2kC.append("%s%s" % (path2, "*.xml"))
  FFWHnI(self, VVI2kC, self.VVDKFR("channels_backup"), addTimeStamp=True)
 def VV5plc(self):
  VVI2kC = []
  VVI2kC.append("/etc/tuxbox/config/")
  VVI2kC.append("/usr/keys/")
  VVI2kC.append("/usr/scam/")
  VVI2kC.append("/etc/CCcam.cfg")
  FFWHnI(self, VVI2kC, self.VVDKFR("softcam_backup"), addTimeStamp=True)
 def VV2jFg(self):
  VVI2kC = []
  VVI2kC.append("/etc/hostname")
  VVI2kC.append("/etc/default_gw")
  VVI2kC.append("/etc/resolv.conf")
  VVI2kC.append("/etc/wpa_supplicant*.conf")
  VVI2kC.append("/etc/network/interfaces")
  VVI2kC.append("%snameserversdns.conf" % VVORe1)
  FFWHnI(self, VVI2kC, self.VVDKFR("network_backup"), addTimeStamp=True)
 def VVDKFR(self, fName):
  img = CCOOXN.VVgTbs()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVFAp2(self, fileName=None):
  if fileName:
   FFo32K(self, BF(FF0GsP, self, BF(self.VVVBLV, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVVBLV(self, fileName):
  path = "%s%s" % (VVBI3c, fileName)
  if fileExists(path):
   if CCFric.VVcxWV(path):
    VVZ7cu , VVVzLj = CCGJtF.VVZsGO()
    VVffe1, VV8Sqy = CCGJtF.VVeEqk()
    cmd  = FFhyjZ("cd %s" % VVORe1)
    cmd += FFhyjZ("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVVzLj, VV8Sqy))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFWnHJ(cmd)
    FFczPJ()
    if ok: FF9glI(self, "Channels Restored.")
    else : FFrj68(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFrj68(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFiEaB(self, path)
 def VVMYYv(self, fileName=None):
  if fileName:
   FFo32K(self, BF(self.VVSmJJ, fileName), "Overwrite SoftCAM files ?")
 def VVSmJJ(self, fileName):
  fileName = "%s%s" % (VVBI3c, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF07Rj(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFQQct(note, VV691Y), sep))
  else:
   FFiEaB(self, fileName)
 def VVlfrf(self, fileName=None):
  if fileName:
   FFo32K(self, BF(self.VVlbqH, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVlbqH(self, fileName):
  fileName = "%s%s" % (VVBI3c, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFSEeb(self,  cmd)
  else:
   FFiEaB(self, fileName)
 def VVnhZc(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFyVZy()
  if pathExists(VVBI3c):
   myFiles = FFYaSE(VVBI3c, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVI2kC = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVI2kC.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV0MQu = ("Sat. List", self.VVSY8f)
    elif isChan and iTar: VV0MQu = ("Bouquets Importer", CCDTYa.VV0OLJ)
    else    : VV0MQu = None
    FFHAbB(self, callBackFunction, title=title, width=1200, VV8kKb=VVI2kC, VV0MQu=VV0MQu, VVj7dk=VVBI3c)
   else:
    FFrj68(self, "No files found in:\n\n%s" % VVBI3c, title)
  else:
   FFrj68(self, "Path not found:\n\n%s" % VVBI3c, title)
 def VVY5cB(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVORe1
  tCons = CClZCM()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VV5ZsI, filePrefix))
 def VV5ZsI(self, filePrefix, result, retval):
  title = FFyVZy()
  if pathExists(VVBI3c):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFrj68(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVBI3c, filePrefix, self.VVDKFR(""), FFC2jX())
    try:
     VVI2kC = str(result.strip()).split()
     if VVI2kC:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVI2kC:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FF7kJS(fName, VV691Y), SEP)
       FFaIgn(self, txt, title=title, VViXLk=VVFkyJ)
      else:
       FFrj68(self, "File creation failed!", title)
     else:
      FFrj68(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFWnHJ("rm %s" % fName)
     FFrj68(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFWnHJ("rm %s" % fName)
     FFrj68(self, "Error while writing file.")
  else:
   FFrj68(self, "Path not found:\n\n%s" % VVBI3c, title)
 def VVEp2u(self, mode, path=None):
  if path:
   path = "%s%s" % (VVBI3c, path)
   if fileExists(path):
    lines = FFKcIu(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFo32K(self, BF(self.VV6kJm, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFerNJ(self, path, title=FFyVZy())
   else:
    FFiEaB(self, path)
 def VV6kJm(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVfhG5 = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVfhG5.append("echo -e 'Reading current settings ...'")
  VVfhG5.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVfhG5.append("echo -e 'Preparing new settings ...'")
  VVfhG5.append(settingsLines)
  VVfhG5.append("echo -e 'Applying new settings ...'")
  VVfhG5.append("mv -f %s %s" % (tFile, sFile))
  FFkmQh(self, VVfhG5)
 def VVSY8f(self, VV476KObj, path):
  if not path:
   return
  path = VVBI3c + path
  if not fileExists(path):
   FFiEaB(self, path)
   return
  txt = FFQByV(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFVZIv(item[1]))
   FFaIgn(self, txt, title="Satellites List")
  else:
   FFrj68(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCDTYa():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VV0OLJ(SELF, fName):
  bi = CCDTYa(SELF)
  bi.instance = bi
  bi.VV18Km(SELF, fName)
 @staticmethod
 def VVbA4S(SELF):
  bi = CCDTYa(SELF)
  bi.instance = bi
  bi.VVVslS()
 def VV18Km(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVBI3c + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FF0GsP(waitObg, self.VVAnaa, title="Reading bouquets ...")
  else      : self.VV7PNA(self.filePath)
 def VVwaVA(self, txt) : FFrj68(self.SELF, txt, title=self.Title)
 def VVSOst(self, txt)  : FFAM12(self, txt, 1500)
 def VV7PNA(self, path) : FFiEaB(self.SELF, path, title=self.Title)
 def VVVslS(self):
  if pathExists(VVBI3c):
   lst = FFYaSE(VVBI3c, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVwra4())
   if len(lst) > 0:
    VV8kKb = []
    for item in lst:
     item = os.path.basename(item)
     txt = FF7kJS(item, VVSFOM) if item.endswith(".zip") else item
     VV8kKb.append((txt, item))
    VV8kKb.sort(key=lambda x: x[1].lower())
    VVodvg = self.VVJZyk
    FFHAbB(self.SELF, self.VVe2yr, minRows=3, title=self.Title, width=1200, VV8kKb=VV8kKb, VVodvg=VVodvg, VVj7dk=VVBI3c, VVuGSD="#22111111", VVO7CL="#22111111")
   else:
    self.VVwaVA("No valid backup files found in:\n\n%s" % VVBI3c)
  else:
   self.VVwaVA("Backup Directory not found:\n\n%s" % VVBI3c)
 def VVJZyk(self, item=None):
  if item:
   VVNmGv, txt, fName, ndx = item
   self.VV18Km(VVNmGv, fName)
 def VVe2yr(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVwra4(self):
  files = FFYaSE(VVBI3c, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVAnaa(self):
  lines, err = CCDTYa.VVK4XW(self.filePath, "bouquets.tv")
  if err:
   self.VVwaVA(err)
   return
  bTvSortLst  = self.VVlXvl(lines)
  lines, err = CCDTYa.VVK4XW(self.filePath, "bouquets.radio")
  if err:
   self.VVwaVA(err)
   return
  bRadSortLst = self.VVlXvl(lines)
  VVDb2Q = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVUDS8(f, mode, len(VVDb2Q), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVDb2Q.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVUDS8(f, mode, len(VVDb2Q), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVUDS8(f, mode, len(VVDb2Q), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVDb2Q.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVUDS8(f, mode, len(VVDb2Q), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVDb2Q): VVDb2Q[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVDb2Q):
     if key == os.path.basename(row[9]):
      VVDb2Q = VVDb2Q[:ndx+1] + lst + VVDb2Q[ndx+1:]
      break
   for ndx, item in enumerate(VVDb2Q): VVDb2Q[ndx][0] = str(ndx + 1)
   VV2ftx = "#11000600"
   VVt6tD  = ("Show Services" , self.VVSPnN  , [], "Reading ..." )
   VVk5TH = (""    , self.VVlesr, [])
   VV9CSs = ("Options"  , self.VVK6mi, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVmBED  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFyZJ5(self.SELF, None, title=self.Title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=24, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VV9CSs=VV9CSs, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVuGSD=VV2ftx, VVO7CL=VV2ftx, VV2ftx=VV2ftx, VVgjmd="#00004455", VVZ0ud="#0a282828")
  else:
   self.VVwaVA("No valid bouquets in:\n\n%s" % self.filePath)
 def VVlXvl(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVlesr(self, VVt27A, title, txt, colList):
  FFaIgn(self.SELF, FFJYbZ(txt), title=title)
 def VVK6mi(self, VVt27A, title, txt, colList):
  mSel = CC9SG5(self.SELF, VVt27A)
  if VVt27A.VVY4gV:
   totSel = VVt27A.VVWJ0c()
   if totSel: VV8kKb = [("Import %s Bouquet%s" % (FF7kJS(str(totSel), VVomgc), FF7O1V(totSel)), "imp")]
   else  : VV8kKb = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FF7kJS(bName, VVomgc)
   VV8kKb = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FF0GsP, VVt27A, BF(CCDTYa.VVE6m1, self.SELF, VVt27A, self.filePath))}
  mSel.VVV2XD(VV8kKb, cbFncDict)
 def VVSPnN(self, VVt27A, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCDTYa.VVK4XW(self.filePath, "lamedb")
   if err:
    self.VVwaVA(err)
    return
   dbServLst = CCGJtF.VVmbjg(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVt27A.VVM4Gr()
   lines, err = CCDTYa.VVK4XW(self.filePath, os.path.basename(fName))
   if err:
    self.VVwaVA(err)
    return
   VVDb2Q = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVDb2Q.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVDb2Q.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVDb2Q.append((span.group(1).strip() or "-", "Stream Relay" if FFIkRt(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVDb2Q.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVDb2Q.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCGJtF.VVrLe7(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVDb2Q.append((name.strip() or "-", FFcVIt(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVDb2Q):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCDTYa.VVK4XW(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVDb2Q[ndx] = (bName, descr)
   if VVDb2Q:
    VV2ftx = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVmBED = (LEFT  , CENTER)
    FFyZJ5(self.SELF, None, title="Services in : %s" % bName, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, VVuGSD=VV2ftx, VVO7CL=VV2ftx, VV2ftx=VV2ftx, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFAM12(VVt27A, err, 1500)
  else : VVt27A.VVtIYK()
 def VVUDS8(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVwaVA("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFIkRt(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVrCdg(var):
   return str(var) if var else VVuopv + str(var)
  totItem = VV691Y + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVSBcQ   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVSFOM, "Sub-B."
  else  : bColor, totBnb = ""      , VVrCdg(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVrCdg(totDVB), VVrCdg(totIptv), VVrCdg(totSRelay), VVrCdg(totLoc), VVrCdg(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVE6m1(SELF, VVt27A, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVORe1 + "bouquets.tv"
  radBouquetFile = VVORe1 + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFiEaB(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFiEaB(SELF, radBouquetFile, title=title)
   return
  isMulti = VVt27A.VVY4gV
  if isMulti : rows = VVt27A.VVzrJF()
  else  : rows = [VVt27A.VVM4Gr()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFrj68(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFJYbZ(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFJYbZ(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVORe1 + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVORe1 + newFile
    CCDTYa.VVJNoz(archPath, fName, VVORe1, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFTYOF(tvBouquetFile)
   FFTYOF(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCDTYa.VVNAbB(SELF, archPath, bList)
   FFczPJ()
  txt  = FF7kJS("Added:\n", VVSFOM)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FF7kJS("Imported to lamedab:\n", VVSFOM)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FF7kJS("Missing from archived lamedb:\n", VVSBcQ)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFaIgn(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVNAbB(SELF, archPath, bList):
  VVZ7cu, err = CCGJtF.VVTJB2(SELF, VV9iqe=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCGJtF.VViWNT(VVZ7cu, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFKcIu(VVORe1 + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCGJtF.VVrLe7(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCGJtF.VV28cX(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCDTYa.VVbDDL(archPath, dbName)
   CCDTYa.VVJNoz(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCGJtF.VViWNT(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCGJtF.VViWNT(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCGJtF.VViWNT(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCGJtF.VViWNT(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFfIuR(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVZ7cu + ".tmp"
   lines   = FFKcIu(VVZ7cu)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFWnHJ("mv -f '%s' '%s'" % (tmpDbFile, VVZ7cu))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVFA46(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVbDDL(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVJNoz(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVK4XW(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCJ8Cb():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVADse()
 def VVADse(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VV8MCN(self):
  FF0GsP(self, self.VVG93S)
 def VVG93S(self):
  if pathExists(self.projMainPath):
   lst = FFLPrp(self.projMainPath)
   VV8kKb = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VV8kKb.append((prName, prName))
   if VV8kKb:
    VV8kKb.sort(key=lambda x: x[1].lower())
    VVodvg = self.VVG3iF
    VV0MQu = ("Add new project", self.VVTgOG)
    VVinPK= ("Delete Project" , self.VV6J6I)
    self.projMenu = FFHAbB(self, None, VV8kKb=VV8kKb, width=1100, VVodvg=VVodvg, VV0MQu=VV0MQu, VVinPK=VVinPK, minRows=5, VVuGSD="#22111133", VVO7CL="#22111133")
   else:
    FFo32K(self, self.VVmO1A, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VV4n3i("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVmO1A(self)    : FF0GsP(self, BF(self.VVkTsZ))
 def VVTgOG(self, VVNmGv, item) : FF0GsP(self.projMenu, BF(self.VVkTsZ))
 def VVkTsZ(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVYuk1(name)
 def VVYuk1(self, name, cbFnc=None):
  FFTtos(self, cbFnc or self.VV3QD4, defaultText=name, title="New Project Name", message="Enter project name")
 def VV3QD4(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFo32K(self, BF(self.VVYuk1, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFBjaU(path)
    if err:
     self.VV4n3i("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVswqb((item, item), isSort=True)
     else   : self.VV8MCN()
 def VV6J6I(self, VVNmGv, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFFrYw(path)
    FFo32K(self, BF(self.VV7zec, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VV7zec(self, path):
  if FFWnHJ("rm -rf '%s'" % path):
   self.projMenu.VVmfbm()
 def VVG3iF(self, item=None):
  if item:
   VVNmGv, txt, Dir, ndx = item
   self.VVADse()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VV8hpn
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FFKcIu(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFJMG5()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVpR1i()
   else      : self.VV4n3i("Cannot create project file:\n\n%s" % self.projFile)
 def VVpR1i(self, VVNmGv=None, jmpDict=None):
  FF0GsP(VVNmGv or self.projTable or self, BF(self.VVmbBA, jmpDict))
 def VVmbBA(self, jmpDict):
  self.VVADse()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FFKcIu(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVOigB(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VV4n3i('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FF7PcS(path)
    if sz > -1: size = CCFric.VVgYti(sz, mode=4)
    else   : size = FF7kJS("Size error", VVSBcQ)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FFKcIu(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVFQZx(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVYBcf(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FF7kJS("Unknown value", VVSBcQ), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FF7kJS(rem, VVSBcQ), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVDb2Q = pkgRows
  VVDb2Q.extend(actnRows)
  VVDb2Q.extend(ctrlRows)
  VVDb2Q.extend(fileRows)
  VVDb2Q.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVDb2Q):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FF7kJS("Valid", VVomgc), " ... " + Remarks if Remarks else "")
    VVDb2Q[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVByC5(VVDb2Q, tableRefreshCB=BF(self.VVDD8j, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVk5TH = (""     , self.VV0o3Q   , [])
   menuButtonFnc = (""     , self.VVFvb7   , [])
   VVOFQa = ("Create Package"  , self.VVqxUs , [])
   VV9CSs = ("Post Install Action", self.VVJHu1, [])
   VVTO3h = ("Edit File"   , self.VVOHAU  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVmBED = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, width=1850, height=1040, VVC5IT=26, VVk5TH=VVk5TH, menuButtonFnc=menuButtonFnc, VVOFQa=VVOFQa, VV9CSs=VV9CSs, VVTO3h=VVTO3h, searchCol=2
         , VVuGSD=bg, VVO7CL=bg, VV2ftx=bg, VVgjmd="#00664411", VVZ0ud="#00444444", VVGQoh="#08442211")
   self.projTable.VVFoTM(self.VV2Nds)
   self.VV2Nds()
 def VVDD8j(self, jmpDict, VVt27A, title, txt, colList):
  self.projTable.VV95eY(jmpDict)
 def VV2Nds(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVM4Gr()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVOigB(self, line):
  def VVNZrq(patt, val, Len):
   if len(val) < Len   : return FF7kJS("Length error" , VVSBcQ)
   elif not iMatch(patt, val) : return FF7kJS("Invalid format" , VVSBcQ)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVNZrq(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVNZrq(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVFQZx(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFY24E(path)
  path = FFz551(path)
  c = VVSBcQ
  if   typ == "Mount" : rem = FF7kJS("Not allowed", c)
  elif not typ  : rem = FF7kJS("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FF7kJS("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFCcy5(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFY24E(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FF7kJS("Not allowed", c)
     elif targetType == "Directory" : sz = FFCcy5(targetPath)
     elif targetType == "File"  : sz = FF7PcS(targetPath)
     else       : sz, rem = FF7PcS(path), FF7kJS("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FF7PcS(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCFric.VVgYti(sz, mode=4)
     else:
      size = FF7kJS("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVYBcf(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVOHAU(self, VVt27A, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCAoYu(self, path, VVVnlJ=self.VVYvPG, curRowNum=lineNdx)
  else    : FFiEaB(self, path)
 def VVYvPG(self, fileChanged):
  if fileChanged:
   self.VVpR1i()
 def VV4n3i(self, txt):
  FFrj68(self, txt, title=self.projTitle)
 def VV0o3Q(self, VVt27A, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVSFOM
  s  = FFXlM7("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFXlM7("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCFric.VVgYti(self.projFilesSize))
  FFaIgn(self, s, title="Project Info", width=1600)
 def VVFvb7(self, VVt27A, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VV30Pd, VVLAFW, VVSFOM
  VV8kKb = []
  VV8kKb.append((c1 + "Add Resource File"  , "addFile" ))
  VV8kKb.append((c1 + "Add Resource Directory" , "addDir" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change Package Name"   , "pkgNam" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Add Dependency"   , "addDep" ))
  VV8kKb.append((c2 + "Remove Dependency"  , "delDep" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VV8kKb.append(FF4UJX('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VV8kKb.append(VVnK97)
  VV8kKb.append(FF4UJX("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVSBcQ))
  FFHAbB(self, self.VV9kRS, VV8kKb=VV8kKb, width=1050, title="Options", VVuGSD="#11001122", VVO7CL="#11001122")
 def VV9kRS(self, item=None):
  if item:
   if   item == "addFile" : self.VVOE3o(False)
   elif item == "addDir" : self.VVOE3o(True)
   elif item == "pkgNam" : self.VVmOhu()
   elif item == "addDep" : FF0GsP(self.projTable, self.VV9Qdn)
   elif item == "delDep" : self.VViTvy()
   elif item == "ctrlFMan" : self.VVfPVU()
   elif item == "ctrlImprt": FF0GsP(self.projTable, self.VVsYH3)
   elif item == "ctrlUndo" : self.VViTwi()
   elif item == "delRow" : self.VVClc6()
 def VVOE3o(self, isDir):
  Dir = FFoVse(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVKOn6, BF(CCFric, mode=CCFric.VVocwE, VVZmiW=Dir))
  else : self.session.openWithCallback(self.VVKOn6, BF(CCFric, patternMode="all", VVZmiW=Dir))
 def VVKOn6(self, path):
  if path:
   FFaoHf(CFG.lastPkgProjDir, path)
   self.VVoOfA(path, 2)
 def VVfPVU(self):
  Dir = FFoVse(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVZQCV, BF(CCFric, patternMode="pkgCtrl", VVZmiW=Dir))
 def VVZQCV(self, path):
  if path:
   FFaoHf(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFWnHJ("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVpR1i()
    self.projTable.VV95eY({1:"Script", 2:fName})
 def VVsYH3(self):
  cmd = FFYQcS(VV4Vav, "")
  if not cmd:
   FFUrcP(self)
   return
  lst = FFO8C9(cmd)
  if lst:
   err = CCFric.VVvwlA(lst, fromFind=False)
   if err:
    self.VV4n3i(err)
    return
   lst.sort()
   VVDb2Q = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVDb2Q.append(("", span.group(1), span.group(2)))
   if VVDb2Q:
    VVaq9G = ("Import 'control' data", self.VVw9AG, [])
    VV9CSs = ("Package Info.", self.VV3MLM     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVWFHs=widths, VVC5IT=30, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVElod=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVuGSD="#22110011", VVO7CL="#22191111", VV2ftx="#22191111", VVgjmd="#00003030", VVZ0ud="#00333333")
   else:
    self.VV4n3i("Cannot process installed packages !")
  else:
   self.VV4n3i("Cannot read installed packages !")
 def VViTwi(self):
  if FFWnHJ("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVpR1i(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VV4n3i("Process Failed !")
 def VVw9AG(self, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVU75P, VVt27A, colList[1]))
 def VVU75P(self, VVt27A, pkg):
  lines = []
  for line in FFO8C9(FFMlY4(VVfpYt, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFo32K(self, BF(self.VVF0sa, VVt27A, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VV4n3i("Cannot import from this package:\n\n%s" % pkg)
 def VVF0sa(self, VVt27A, lines):
  VVt27A.cancel()
  FFyRfT(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVpR1i(jmpDict={1:"Control", 2:"Package"})
 def VVClc6(self):
  lineNum = int(self.projTable.VVM4Gr()[0]) + 1
  FFWnHJ("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVpR1i()
 def VVoOfA(self, line, jmp):
  if fileExists(self.projFile):
   FFyRfT(self.projFile)
   FFTYOF(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVpR1i(jmpDict=jmpDict)
  else:
   FFiEaB(self, self.projFile, title=self.projTitle)
 def VVJHu1(self, VVt27A, title, txt, colList):
  VV8kKb = []
  VV8kKb.append(FF4UJX("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VV8kKb.append(FF4UJX("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VV8kKb.append(FF4UJX("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VV8kKb.append(VVnK97)
  VV8kKb.append(FF4UJX("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VV8kKb.append(FF4UJX("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VV8kKb.append(FF4UJX("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFHAbB(self, self.VVnfqU, VV8kKb=VV8kKb, title="Action (after the package is installed/removed)")
 def VVnfqU(self, item=None):
  if item:
   if   item == "instNon" : self.VVRj3N("postinst", 0)
   elif item == "instRes" : self.VVRj3N("postinst", 1)
   elif item == "instReb" : self.VVRj3N("postinst", 2)
   elif item == "rmNon" : self.VVRj3N("postrm", 0)
   elif item == "rmRes" : self.VVRj3N("postrm", 1)
   elif item == "rmReb" : self.VVRj3N("postrm", 2)
 def VVRj3N(self, subj, val):
  if fileExists(self.projFile):
   lines = FFKcIu(self.projFile)
   FFyRfT(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVoOfA("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVpR1i()
 def VVmOhu(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VV8kKb = []
  VV8kKb.append((pkg, pkg))
  VV8kKb.append(VVnK97)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVSFOM if name == self.projPkg else ""
    VV8kKb.append((c + name, name))
   else:
    VV8kKb.append(VVnK97)
  FFHAbB(self, self.VVYjip, VV8kKb=VV8kKb, title="Package Name")
 def VVYjip(self, item=None):
  if item:
   self.VVYpk3("Package", item)
 def VV9Qdn(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VV8kKb = []
   for item in lst: VV8kKb.append((item, item))
   VV8kKb.sort(key=lambda x: x[0].lower())
   VVNmGv = FFHAbB(self, self.VV1wBJ, VV8kKb=VV8kKb, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVNmGv.VVeV8t(self.projLastDepends)
  else:
   self.VV4n3i("Cannot read dependencies list !")
 def VV1wBJ(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FFKcIu(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVYpk3("Depends", ", ".join(lst))
   else:
    FFAM12(self.projTable, "Already added", 1500)
    self.projTable.VV95eY({1:"Control", 2:"Depends"})
 def VViTvy(self):
  lst = []
  for row in self.projTable.VVXwRB():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VV8kKb = []
   for item in lst: VV8kKb.append((item, item))
   FFHAbB(self, BF(self.VVtrLc, lst), VV8kKb=VV8kKb, title="Remove Dependency")
  else:
   self.VV4n3i("No dependencies to remove !")
 def VVtrLc(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVYpk3("Depends", ", ".join(lst))
   else:
    FFWnHJ("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVpR1i()
 def VVYpk3(self, subj, val):
  lines = FFKcIu(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVpR1i(jmpDict={1:"Control", 2:subj})
 def VVqxUs(self, VVt27A, title, txt, colList):
  VV8kKb = []
  VV8kKb.append(("Create .ipk"  , "ipk"))
  VV8kKb.append(("Create .deb"  , "deb"))
  VV8kKb.append(("Create .tar.gz" , "tar"))
  FFHAbB(self, self.VVqCsn, VV8kKb=VV8kKb, width=500, title=self.projTitle)
 def VVqCsn(self, item=None):
  if item:
   FF0GsP(self.projTable, BF(self.VVG5Uy, item))
 def VVG5Uy(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VV4n3i("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVpmZd, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVpmZd, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VV4n3i(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFhyjZ("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFQQct(result  , VVomgc))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFQQct(failed, VVD6mq))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFhyjZ("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVXwRB()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFSEeb(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFWnHJ(cmd) or not pathExists(ctrlDir):
   VV4n3i(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVNZrq(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFWnHJ("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVNZrq(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFTYOF(dstF)
   FFWnHJ("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFEDUQ()
  if VVpmZd:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFLwTR("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFSEeb(self, cmd)
class CChnXU(Screen, CCJ8Cb):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVX871, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCJ8Cb.__init__(self)
  c1, c2, c3, c4 = VV30Pd, VVLAFW, VV4d6Z, VVSFOM
  VV8kKb = []
  VV8kKb.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c3 + "Remove Packages (show all)"     , "VVk0NRsAll"  ))
  VV8kKb.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Update Packages List from Feed"    , "VVkPNy"  ))
  VV8kKb.append((c2 + "Upgradable Packages"       , "VVgjt4" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Packaging Tool"         , "VVT1nO"   ))
  VV8kKb.append(("Active Feeds"          , "VVWwQb"   ))
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCYqAD.VVThU6(self)
   elif item == "downloadInstallPackages"  : FF0GsP(self, BF(self.VV9efE, 0, ""))
   elif item == "VVk0NRsAll"   : FF0GsP(self, BF(self.VV9efE, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF0GsP(self, BF(self.VV9efE, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVkPNy"   : CChnXU.VVkPNy(self)
   elif item == "VVgjt4"  : FF0GsP(self, self.VVgjt4)
   elif item == "packageCreator"    : self.VV8MCN()
   elif item == "VVT1nO"    : self.VVT1nO()
   elif item == "VVWwQb"    : FF0GsP(self, self.VVWwQb)
   else          : self.close()
 def VVWwQb(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVDb2Q = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVDb2Q.append((os.path.basename(path), str(tot)))
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVmBED = (LEFT  , CENTER )
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, width=1000, VVC5IT=26, VVLC3P=2)
  else:
   self.VV4n3i("Cannot read packages list !")
 def VVgjt4(self, VVt27A=None):
  lst = FFO8C9(FFYQcS(VVbV65, ""))
  VVDb2Q = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVDb2Q.append((str(len(VVDb2Q) + 1), pkg, curV, newVer))
   if VVDb2Q:
    if VVt27A:
     VVt27A.VVByC5(VVDb2Q, VV78xZMsg=True)
    else:
     bg = "#00221111"
     VVaq9G = ("Upgrade", self.VVoLV2   , [])
     VV9CSs = ("Package Info.", self.VV3MLM , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVmBED = (CENTER , LEFT  , LEFT  , LEFT   )
     FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, width=1700, VVC5IT=26, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VV2v46=True, VVGRvn=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVuGSD=bg, VVO7CL=bg, VV2ftx=bg, VV0p3X="#00ffff55", VVgjmd="#00003040")
  if not VVDb2Q:
   FFIZWt(self, "Nothing to upgrade", 1500)
   if VVt27A: VVt27A.cancel()
 def VVoLV2(self, VVt27A, title, txt, colList):
  pkg = colList[1]
  cmd = FFMlY4(VVcIUq, pkg)
  if cmd : FFSEeb(self, cmd, title="Installing : %s" % pkg, VVOc3A=BF(self.VVgjt4, VVt27A))
  else : FFUrcP(SELF)
 def VVT1nO(self):
  pkg = FFiXBo()
  aptT = "apt - Advanced Package Tool" if FFFS65("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FF9glI(self, txt or "No packaging tools found!")
 def VV9efE(self, mode, grep, VVt27A=None, title=""):
  if   mode == 0: cmd = FFYQcS(VVtSO6    , grep)
  elif mode == 1: cmd = FFYQcS(VV4Vav , grep)
  elif mode == 2: cmd = FFYQcS(VV4Vav , grep)
  if not cmd:
   FFUrcP(self)
   return
  VVDb2Q = FFO8C9(cmd)
  if VVDb2Q:
   err = CCFric.VVvwlA(VVDb2Q, fromFind=False)
   if err:
    FFrj68(self, err)
    return
  else:
   if VVt27A: VVt27A.VVtIYK()
   FFrj68(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVI2kC  = []
  for item in VVDb2Q:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVI2kC.append((name, package, version))
  if mode > 0:
   extensions = FFO8C9("ls %s -l | grep '^d' | awk '{print $9}'" % VVgk0E)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVI2kC:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVupPm: name += "el"
      VVI2kC.append((name, VVgk0E + item, "-"))
   systemPlugins = FFO8C9("ls %s -l | grep '^d' | awk '{print $9}'" % VVJdOR)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVI2kC:
      if item.lower() == row[0].lower():
       break
     else:
      VVI2kC.append((item, VVJdOR + item, "-"))
  if not VVI2kC:
   FFrj68(self, "No packages found!")
   return
  if VVt27A:
   VVI2kC.sort(key=lambda x: x[0].lower())
   VVt27A.VVByC5(VVI2kC, title)
  else:
   widths = (20, 50, 30)
   VVaq9G = None
   VVTO3h = None
   if mode == 0:
    VVOFQa = ("Install" , self.VVjn55   , [])
    VVaq9G = ("Download" , self.VVn6k2   , [])
    VVTO3h = ("Filter"  , self.VVuT4N , [])
   elif mode == 1:
    VVOFQa = ("Uninstall", self.VVk0NR, [])
   elif mode == 2:
    VVOFQa = ("Uninstall", self.VVk0NR, [])
    widths= (18, 57, 25)
   VVI2kC.sort(key=lambda x: x[0].lower())
   VV9CSs = ("Package Info.", self.VV3MLM, [])
   header   = ("Name" ,"Package" , "Version" )
   FFyZJ5(self, None, header=header, VVI2kC=VVI2kC, VVWFHs=widths, VVC5IT=28, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVElod=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVuGSD="#22110011", VVO7CL="#22191111", VV2ftx="#22191111", VVgjmd="#00003030", VVZ0ud="#00333333")
 def VV3MLM(self, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVEha5, VVt27A, colList[1]))
 def VVEha5(self, VVt27A, pkg):
  if pathExists(pkg):
   pkg, err = CChnXU.VVpk3f(pkg)
   if err:
    FFIZWt(VVt27A, err, 1000)
    return
  CChnXU.VV4gJ4(self, pkg)
 def VVuT4N(self, VVt27A, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VV8kKb = []
  VV8kKb.append(("All Packages", "all"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Plugin/SoftCAM/Skin", "plugins"))
  VV8kKb.append(VVnK97)
  for word in words:
   VV8kKb.append((word, word))
  FFHAbB(self, BF(self.VVDYSG, VVt27A), VV8kKb=VV8kKb, title="Select Filter")
 def VVDYSG(self, VVt27A, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF0GsP(VVt27A, BF(self.VV9efE, 0, grep, VVt27A, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVk0NR(self, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVKPsH, VVt27A, colList[1]))
 def VVKPsH(self, VVt27A, package):
  if pathExists(package):
   pkg, err = CChnXU.VVpk3f(package)
   if pkg:
    package = pkg
  if package.startswith((VVgk0E, VVJdOR)):
   FFo32K(self, BF(self.VVgHNF, VVt27A, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VV8kKb = []
   VV8kKb.append(("Remove Package"         , "remove_ExistingPackage" ))
   VV8kKb.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VV8kKb.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFHAbB(self, BF(self.VVsrO8, VVt27A, package), VV8kKb=VV8kKb)
 def VVgHNF(self, VVt27A, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVfKPQ)
  FFSEeb(self, cmd, VVOc3A=BF(self.VVtfpR, VVt27A))
 def VVsrO8(self, VVt27A, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV45S3
   elif item == "remove_ForceRemove"  : cmdOpt = VVe6LU
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVA0No
   FFo32K(self, BF(self.VVbABA, VVt27A, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVbABA(self, VVt27A, package, cmdOpt):
  self.lastSelectedRow = VVt27A.VV2fe8()
  cmd = FFMlY4(cmdOpt, package)
  if cmd : FFSEeb(self, cmd, VVOc3A=BF(self.VVtfpR, VVt27A))
  else : FFUrcP(self)
 def VVtfpR(self, VVt27A):
  VVt27A.cancel()
  FFzWhD()
 def VVjn55(self, VVt27A, title, txt, colList):
  package  = colList[1]
  VV8kKb = []
  VV8kKb.append(("Install Package"        , "install_CheckVersion" ))
  VV8kKb.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VV8kKb.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VV8kKb.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VV8kKb.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFHAbB(self, BF(self.VVsmIQ, package), VV8kKb=VV8kKb)
 def VVsmIQ(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVcIUq
   elif item == "install_ForceReinstall" : cmdOpt = VVpHks
   elif item == "install_ForceOverwrite" : cmdOpt = VV7Fa0
   elif item == "install_ForceDowngrade" : cmdOpt = VV3fQ1
   elif item == "install_IgnoreDepends" : cmdOpt = VVyCx7
   FFo32K(self, BF(self.VVJADG, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVJADG(self, package, cmdOpt):
  cmd = FFMlY4(cmdOpt, package)
  if cmd : FFSEeb(self, cmd, VVOc3A=FFzWhD, checkNetAccess=True)
  else : FFUrcP(self)
 def VVn6k2(self, VVt27A, title, txt, colList):
  package  = colList[1]
  FFo32K(self, BF(self.VVmNCN, package), "Download Package ?\n\n%s" % package)
 def VVmNCN(self, package):
  if CCiKm1.VVQ8ve():
   cmd = FFMlY4(VVLIn3, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFQQct(success, VVomgc))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFQQct(fail, VVD6mq))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFSEeb(self, cmd, VVuQzu=[VVD6mq, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFUrcP(self)
  else:
   FFrj68(self, "No internet connection !")
 @staticmethod
 def VVkPNy(SELF):
  cmd = FFYQcS(VV1Lhp, "")
  if cmd : FFSEeb(SELF, cmd, checkNetAccess=True)
  else : FFUrcP(SELF)
 @staticmethod
 def VVpk3f(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFO8C9(FFMlY4(VVocZq, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VV4gJ4(SELF, package, title=""):
  title = title or package
  infoCmd  = FFMlY4(VVfpYt, package)
  filesCmd = FFMlY4(VVHjnx, package)
  listInstCmd = FFYQcS(VV4Vav, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF0dSC(VV691Y)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFQQct(notInst, VVSBcQ))
   cmd += "else "
   cmd +=   FFDeRs("System Info", VV691Y)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFDeRs("Related Files", VV691Y)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFTJt5(SELF, cmd, title=title)
  else:
   FFUrcP(SELF, title=title)
class CC6Npm():
 def VV35ad(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVJHeB()
 def VVJHeB(self):
  files = FFYaSE(VVBI3c, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VV8kKb = []
   for fil in files:
    VV8kKb.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVuGSD, VVO7CL = "#22221133", "#22221133"
   else    : VVuGSD, VVO7CL = "#22003344", "#22002233"
   VV0MQu  = ("Add new File", self.VVUhD5)
   FFHAbB(self, self.VVBiqc, VV8kKb=VV8kKb, width=1100, VV0MQu=VV0MQu, VVj7dk="", minRows=4, VVuGSD=VVuGSD, VVO7CL=VVO7CL)
  else:
   FFo32K(self, self.VVYlPB, "No files found.\n\nCreate a new file ?")
 def VVYlPB(self):
  path = self.VVRHsl()
  if fileExists(path) : self.VVJHeB()
  else    : FFAM12(self, "Cannot create file", 1500)
 def VVUhD5(self, VVNmGv, path):
  path = self.VVRHsl()
  VVNmGv.VVswqb((os.path.basename(path), path), isSort=True)
 def VVRHsl(self):
  path = "%s%s%s.xml" % (VVBI3c, self.shareFilePrefix, FFC2jX())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVBiqc(self, path=None):
  if path:
   FF0GsP(self, BF(self.VV6f0G, path))
 def VV6f0G(self, path):
  if not fileExists(path):
   FFiEaB(self, path)
   return
  elif not CCFric.VV4nww(self, path, FFyVZy()):
   return
  else:
   self.shareFilePath = path
  if not CCayiU.VVUUNd(self):
   return
  tree = CCGJtF.VVd2wR(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCQo5X.VVhDrb()
  def VVPmyh(refCode):
   if   FFtVJx(refCode): return FF7kJS("DVB", VV30Pd)
   elif refCode in refLst     : return FF7kJS("IPTV", VV30Pd)
   else         : return ""
  VVDb2Q= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VV76Yv(ch)
   if ok:
    srcTxt = VVPmyh(srcRef)
    dstTxt = VVPmyh(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVDb2Q:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVDb2Q.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVDb2Q:
   if self.shareIsRef : VVuGSD, VVO7CL, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVuGSD, VVO7CL, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVZApD = (""    , BF(self.VVdWca, dupl), [])
   VVk5TH = (""    , self.VV33qc    , [])
   VVOFQa = ("Delete Entry" , self.VVeVSZ   , [])
   VVaq9G = ("Add Entry"  , self.VV96qf   , [])
   VV9CSs = (optTxt   , self.VVl0nC  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVmBED = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVt27A = FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=24, VVZApD=VVZApD, VVk5TH=VVk5TH, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VV2v46=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VVO7CL, VVgjmd="#0a000000")
  else:
   FFrj68(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVdWca(self, dupl, VVt27A, title, txt, colList):
  if dupl:
   VVt27A.VVq4Rc("Skipped %d duplicate%s" % (dupl, FF7O1V(dupl)), 2000)
 def VV33qc(self, VVt27A, title, txt, colList):
  def VVPmyh(key, val): return "%s\t: %s\n" % (key, val or FF7kJS("?", VVvkGK))
  Keys = VVt27A.VVz8N9()
  Vals = VVt27A.VVM4Gr()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVPmyh(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVomgc, VVvkGK
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFaIgn(self, txt + txt1, title=title)
 def VV76Yv(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVeVSZ(self, VVt27A, title, txt, colList):
  if VVt27A.VV2fe8() == 0 and VVt27A.VV9aLU() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFo32K(self, BF(self.VVSKQq, isLast, VVt27A), ques)
 def VVSKQq(self, isLast, VVt27A):
  if isLast:
   FFfIuR(self.shareFilePath)
   VVt27A.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVt27A.VVM4Gr()
   if self.VVuCkn(srcName, srcRef, dstName, dstRef):
    VVt27A.VVRabD()
    VVt27A.VVN2Hw()
    FFAM12(VVt27A, "Deleted", 500, isGrn=True)
   else:
    FFAM12(VVt27A, "Cannot delete from file", 2000)
 def VV96qf(self, VVt27A, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVOK0K(VVt27A, isDvb=True)
  else    : self.VVnxou(VVt27A, "Source Channel", "#22003344", "#22002233")
 def VVnxou(self, mainTableInst, title, VVuGSD, VVO7CL):
  FFHAbB(self, BF(self.VVHGeA, mainTableInst, title), VV8kKb=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVuGSD=VVuGSD, VVO7CL=VVO7CL)
 def VVHGeA(self, mainTableInst, title, item=None):
  if item:
   FF0GsP(mainTableInst, BF(self.VVlJBC, mainTableInst, title, item), clearMsg=False)
 def VVlJBC(self, mainTableInst, title, item):
  FFAM12(mainTableInst)
  if item == "DVB": self.VVOK0K(mainTableInst, isDvb=True)
  else   : self.VVOK0K(mainTableInst, isDvb=False)
 def VVY0tC(self, mainTableInst, chType, VVt27A, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVt27A.VV2fe8()
  if   chType == "DVB" : FFaoHf(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFaoHf(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVXwRB()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFrj68(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVb6kZ(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVuGVo((str(mainTableInst.VV9aLU() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFAM12(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFAM12(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFAM12(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVOK0K(mainTableInst, isDvb=False)
   else    : FF2Wwv(BF(self.VVnxou, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVt27A.cancel()
 def VVAfXF(self, item, VVt27A, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVt27A.VVagt1(ndx)
 def VVOK0K(self, VVt27A, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVY0tC, VVt27A, typ)
  doneFnc = BF(self.VVAfXF, typ)
  if isDvb: CC6Npm.VV4rUo(VVt27A , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CC6Npm.VV1TAn(VVt27A, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VV4rUo(SELF, title, okFnc, doneFnc=None):
  FF0GsP(SELF, BF(CC6Npm.VVkLNI, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVkLNI(SELF, title, okFnc, doneFnc=None):
  VVDb2Q, err = CCGJtF.VV2Ohl(SELF, CCGJtF.VVKpzE)
  if VVDb2Q:
   color = "#0a000022"
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVt6tD = ("Select" , okFnc, [])
   VVZApD= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVmBED = (LEFT  , LEFT  , CENTER, LEFT    )
   FFyZJ5(SELF, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVuGSD=color, VVO7CL=color, VV2ftx=color, VVt6tD=VVt6tD, VVZApD=VVZApD, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFrj68(SELF, "No DVB Services !")
 @staticmethod
 def VV1TAn(SELF, title, okFnc, doneFnc=None):
  FF0GsP(SELF, BF(CC6Npm.VVg82D, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVg82D(SELF, title, okFnc, doneFnc=None):
  VVDb2Q = CC6Npm.VVmS3m()
  if VVDb2Q:
   color = "#0a112211"
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVt6tD = ("Select" , okFnc, [])
   VVZApD= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFyZJ5(SELF, None, title=title, header=header, VVI2kC=VVDb2Q, VVWFHs=widths, VVC5IT=26, VVuGSD=color, VVO7CL=color, VV2ftx=color, VVt6tD=VVt6tD, VVZApD=VVZApD, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFrj68(SELF, "No IPTV Services !")
 @staticmethod
 def VVmS3m():
  VVDb2Q = []
  files  = CC1B0Q.VVqr8J()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFQByV(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVHVrB = span.group(1)
    else : VVHVrB = ""
    VVHVrB_lCase = VVHVrB.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVDb2Q.append((chName, VVHVrB, url, refCode))
  return VVDb2Q
 def VVb6kZ(self, srcName, srcRef, dstName, dstRef):
  tree = CCGJtF.VVd2wR(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VV4n46(tree, root)
  return True
 def VVuCkn(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCGJtF.VVd2wR(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VV76Yv(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VV4n46(tree, root)
  return found
 def VV4n46(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCGJtF.VVCho1(xmlTxt)
  parser = CCGJtF.CCAeqm()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVl0nC(self, VVt27A, title, txt, colList):
  if self.onlyEpg:
   self.VVhc9L(VVt27A, "epg")
  else:
   if self.shareIsRef:
    FFo32K(self, BF(FF0GsP, VVt27A, BF(self.VVPbb8, VVt27A)), "Copy all References from Source to Destination ?")
   else:
    VV8kKb = []
    VV8kKb.append(("Copy EPG\t (All List)" , "epg"  ))
    VV8kKb.append(("Copy Picons\t (All List)" , "picon" ))
    FFHAbB(self, BF(self.VVhc9L, VVt27A), VV8kKb=VV8kKb, width=1000)
 def VVhc9L(self, VVt27A, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVqqah  , "EPG"
   elif item == "picon": fnc, txt = self.VVvWWy , "PIcons"
   title = "Copy %s" % txt
   tot   = VVt27A.VV9aLU()
   FFo32K(self, BF(FF0GsP, VVt27A, BF(fnc, VVt27A, title)), "Overwrite %s for %d Service%s ?" % (FF7kJS(txt, VV691Y), tot, FF7O1V(tot)), title=title)
 def VVPbb8(self, VVt27A):
  files = CC1B0Q.VVqr8J()
  totChange = 0
  if files:
   for path in files:
    txt = FFQByV(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVt27A.VVXwRB():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFczPJ()
  tot = VVt27A.VV9aLU()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFaIgn(self, txt)
 def VVvWWy(self, VVt27A, title):
  if not iCopyfile:
   FFrj68(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCHnG6.VVYipk()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVt27A.VVXwRB():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVt27A.VV9aLU()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFaIgn(self, txt, title=title)
 def VVqqah(self, VVt27A, title):
  txt, err = CCS6Mr.VVr2mv(VVt27A, title)
  if err : FFrj68(self, err, title=title)
  else : FFaIgn(self, txt, title=title)
 class CCAeqm(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVd2wR(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCGJtF.CCAeqm())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FF7kJS("XML Parse Error in:", VVvkGK), path)
   txt += "%s\n%s\n\n" % (FF7kJS("Error:", VVvkGK), str(e))
   FFaIgn(SELF, txt, VV2ftx="#11220000", title=title)
   return None
 @staticmethod
 def VVCho1(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCS6Mr(Screen, CC6Npm):
 VVgNz8  = "BDTSE"
 VVxO8I   = "save"
 VVdApY   = "load"
 VVfeMD  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VVX871, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCS6Mr.VVuAJq()
  qUrl, iptvRef = CC1B0Q.VVHLAZ(self)
  VV8kKb = []
  VV8kKb.append((VV30Pd + "Cache File Info." , "inf"))
  VV8kKb.append(VVnK97)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VV8kKb.append(FF4UJX("Save EPG to File%s" % fTxt , self.VVxO8I, valid))
  VV8kKb.append(FF4UJX("Load EPG from File%s" % fTxt , self.VVdApY, valid))
  VV8kKb.append(VVnK97)
  VV8kKb.append((VVSBcQ + "Delete EPG (from RAM only)", self.VVfeMD))
  VV8kKb.append(VVnK97)
  VV8kKb.append(FF4UJX("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VV8kKb.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Translate Current Channel EPG %s(Experimental)" % VVSBcQ, "VV7rb2"))
  FF74S2(self, VV8kKb=VV8kKb)
  self.onShown.append(self.VVHrlo)
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVv643()
   elif item in (self.VVxO8I, self.VVdApY, self.VVfeMD):
    reset = item == self.VVdApY
    FFo32K(self, BF(FF0GsP, self, BF(self.VVzpez, item, reset)), VVzpP3="Continue ?")
   elif item == "refreshIptvEPG"  : CC1B0Q.VV1D30(self)
   elif item == "VV7rb2" : self.VV7rb2()
   elif item == "copyEpg"    : self.VV35ad(False, onlyEpg=True)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VVzpez(self, act, reset=False):
  ok = CCS6Mr.VVZufY(act)
  if ok:
   if reset:
    CCS6Mr.VVlfmj(self)
   FF9glI(self, "Done")
  else:
   FF9glI(self, "Failed!")
 def VVv643(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCS6Mr.VVuAJq()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FF7kJS("File not found (check System EPG settings).", VVSBcQ))
   FFaIgn(self, txt, title=title)
  else:
   FFrj68(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVtS1A():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VV7rb2(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVt6tD  = (""  , BF(self.VVaCSp, title, True) , [])
  VVaq9G = ("Start" , BF(self.VVaCSp, title, False), [])
  VVTO3h = ("Change Language", self.VVBPMW      , [])
  widths  = (70 , 30)
  VVmBED = (LEFT , CENTER)
  FFyZJ5(self, None, title=title, VVI2kC=self.VVrB2h(), VVmBED=VVmBED, VVWFHs=widths, width=1200, vMargin=20, VVC5IT=30, VVt6tD=VVt6tD, VVaq9G=VVaq9G, VVTO3h=VVTO3h, VVLC3P=2
    , VVuGSD="#11201010", VVO7CL=bg, VV2ftx=bg, VVgjmd="#00004455", VVZ0ud=bg)
 def VVrB2h(self):
  Def, ch = "DISABLED", dict(CCS6Mr.VVtS1A())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVI2kC = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVI2kC
 def VVBPMW(self, VVt27A, title, txt, colList):
  ndx = VVt27A.VV2fe8()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CC8YBo.VVZpf5(self, confItem, title, lst=CCS6Mr.VVtS1A(), cbFnc=BF(self.VVSFCU, VVt27A), isSave=True)
 def VVSFCU(self, VVt27A):
  for ndx, row in enumerate(self.VVrB2h()):
   VVt27A.VVwR5j(ndx, row)
 def VVaCSp(self, Title, isAsk, VVt27A, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFAM12(VVt27A, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
   refCode, evList, err = CCS6Mr.VVjy0O(refCode)
   fnc = BF(self.VV9nLb, Title, refCode, evList, VVt27A)
   if   err : FFrj68(self, err, title=Title)
   elif isAsk : FFo32K(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VV9nLb(self, title, refCode, evList, VVt27A):
  self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV34kb, evList)
      , VVVnlJ = BF(self.VVdjKg, title, refCode))
  VVt27A.cancel()
 def VV34kb(self, evList, VVtEPC):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVtEPC.VVodiL(totEv)
  VVtEPC.VVsc2i = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCS6Mr.VVnTXp(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VV2Wgw(1)
   VVtEPC.VVXh2n(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVtEPC.VVsc2i = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVdjKg(self, title, refCode, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVsc2i
  if newLst: totEv, totOK = CCS6Mr.VVCij8(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCS6Mr.VVRnze()
   CCS6Mr.VVlfmj(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFaIgn(self, txt, title=title)
 @staticmethod
 def VVnTXp(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVPmyh(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCS6Mr.VVyB0w(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVPmyh, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVyB0w(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFw8K0(txt))
   txt, err = CC1B0Q.VVEaWb(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFD0Hz(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCS6Mr.VVt4fm(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVuAJq():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FF7PcS(path)
   szTxt = CCFric.VVgYti(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VV2GfK():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVRnze(): CCS6Mr.VVZufY(CCS6Mr.VVxO8I)
 @staticmethod
 def VVZufY(act):
  ec, inst = CCS6Mr.VV2GfK()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVlfmj(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVjy0O(refCode):
  ec, inst = CCS6Mr.VV2GfK()
  if inst:
   try:
    evList = inst.lookupEvent([CCS6Mr.VVgNz8, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVCij8(refCode, events, longDescDays=0):
  ec, inst = CCS6Mr.VV2GfK()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVp9jG(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCS6Mr.VV2GfK()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCS6Mr.VVfxYW(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCOQON.CCS6Mr(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVfxYW(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCS6Mr.VV07EA(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVV6lv(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCS6Mr.VV2GfK()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCS6Mr.VVfxYW(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFDwGN(evTime)
       evEndTxt  = FFDwGN(evEnd)
       evDurTxt  = FFjXk8(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFjXk8(evPos)
        evRem = evEnd - now
        evRemTxt = FFjXk8(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFjXk8(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VV07EA(event):
  genre = PR = ""
  try:
   genre  = CCS6Mr.VVB2lZ(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCS6Mr.VVpxid(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVpxid(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVB2lZ(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCS6Mr.VV21iQ()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VV21iQ():
  path = VV8hpn + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFQByV(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFQByV(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVr2mv(VVt27A, title):
  ec, inst = CCS6Mr.VV2GfK()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVt27A.VVXwRB():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCS6Mr.VVgNz8, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCS6Mr.VVCij8(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCS6Mr.VVRnze()
  txt  = "Services\t: %d\n"  % VVt27A.VV9aLU()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVh3fh(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCS6Mr.VVxo4H(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCS6Mr.VVxo4H(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCS6Mr.VVxo4H(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVxo4H(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCS6Mr.VVfxYW(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCS6Mr.VVnTXp(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FF7kJS(evName, VVSFOM)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FF7kJS(evNameTransl, VVSFOM))
    if evTime           : txt += "Start Time\t: %s\n" % FFDwGN(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFDwGN(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFjXk8(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFjXk8(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFjXk8(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF7kJS(evShort, VVLAFW)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF7kJS(evDesc , VVLAFW)
    if txt:
     txt = FF7kJS("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVSFOM) + txt
  return txt
 @staticmethod
 def VVt4fm(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCGJtF(Screen, CC6Npm):
 VVacaE  = 0
 VVEkoW = 1
 VViqD9  = 2
 VVAo0d  = 3
 VV6Yt8 = 4
 VVgToU = 5
 VVKV7y = 6
 VVKpzE   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VVX871, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVjPCP = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VV8kKb = self.VVQ8GC()
  FF74S2(self, VV8kKb=VV8kKb, title="Services/Channels")
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self["myMenu"].setList(self.VVQ8GC())
  FFl94Z(self["myMenu"])
  FF1hGr(self)
 def VVQ8GC(self):
  VV8kKb = []
  c = VV30Pd
  VV8kKb.append((c + "Open Player Bar"         , "openPlayer"       ))
  VV8kKb.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VV8kKb.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VV8kKb.append(VVnK97)
  c = VVSFOM
  VV8kKb.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VV8kKb.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VV8kKb.append((VVvkGK + "More tables ..."     , "VVPOo9"    ))
  c = VVLAFW
  VV8kKb.append(VVnK97)
  txt = "Import Bouquets from Backup Files"
  if iTar : VV8kKb.append((c + txt          , "VVbA4S"  ))
  else : VV8kKb.append((txt           ,          ))
  VV8kKb.append((c + 'Export Services to "channels.xml"'    , "VVKBmH"      ))
  VV8kKb.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VV4d6Z
  VV8kKb.append(VVnK97)
  VV8kKb.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VV8kKb.append((c + "Invalid Services Cleaner"       , "VVM3GM"    ))
  c = VV4d6Z
  VV8kKb.append(VVnK97)
  VV8kKb.append((c + "Delete Channels with no names"     , "VVnaTS"    ))
  VV8kKb.append((c + "Delete Empty Bouquets"       , "VVbNbu"     ))
  VV8kKb.append(VVnK97)
  VVZ7cu, VVVzLj = CCGJtF.VVZsGO()
  if fileExists(VVZ7cu):
   enab = fileExists(VVVzLj)
   if enab: VV8kKb.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VV8kKb.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VV8kKb.append(("Reset Parental Control Settings"      , "VVZXIz"    ))
  VV8kKb.append(("Reload Channels and Bouquets"       , "VV53C5"      ))
  return VV8kKb
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCLDrN.VVLpPr(self.session)
   elif item == "openSignal"       : FFXBRY(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFjcFt(self, fncMode=CCOQON.VVbCqZ)
   elif item == "lameDB_allChannels_with_refCode"  : FF0GsP(self, self.VVnfYp)
   elif item == "lameDB_allChannels_with_tranaponder" : FF0GsP(self, self.VVzmTr)
   elif item == "VVPOo9"     : self.VVPOo9()
   elif item == "VVbA4S"  : CCDTYa.VVbA4S(self)
   elif item == "VVKBmH"      : self.VVKBmH()
   elif item == "copyEpgPicons"      : self.VV35ad(False)
   elif item == "SatellitesCleaner"     : FF0GsP(self, self.FF0GsP_SatellitesCleaner)
   elif item == "VVM3GM"    : FF0GsP(self, BF(self.VVM3GM))
   elif item == "VVnaTS"    : FF0GsP(self, self.VVnaTS)
   elif item == "VVbNbu"     : self.VVbNbu(self)
   elif item == "enableHiddenChannels"     : self.VVpu6C(True)
   elif item == "disableHiddenChannels"    : self.VVpu6C(False)
   elif item == "VVZXIz"    : FFo32K(self, self.VVZXIz, "Reset and Restart ?")
   elif item == "VV53C5"      : FF0GsP(self, BF(CCGJtF.VV53C5, self))
 def VVPOo9(self):
  VV8kKb = []
  VV8kKb.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VV8kKb.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VV8kKb.append(("Services with PIcons for the System"  , "VVbORW"    ))
  VV8kKb.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VV8kKb.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFHAbB(self, self.VVqtPw, VV8kKb=VV8kKb, title="Service Information", VVPYdF=True)
 def VVqtPw(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FF0GsP(self, BF(self.VVVPaM, title))
   elif ref == "parentalControlChannels"   : FF0GsP(self, BF(self.VV3y8p, title))
   elif ref == "showHiddenChannels"    : FF0GsP(self, BF(self.VVR1PW, title))
   elif ref == "VVbORW"    : FF0GsP(self, BF(self.VV2jFB, title))
   elif ref == "servicesWithMissingPIcons"   : FF0GsP(self, BF(self.VVtc5H, title))
   elif ref == "TranspondersStats"     : FF0GsP(self, BF(self.VVOryb, title))
   elif ref == "SatellitesXmlStats"    : FF0GsP(self, BF(self.VVxJLO, title))
 def VVKBmH(self):
  VV8kKb = []
  VV8kKb.append(("All DVB-S/C/T Services", "all"))
  VV8kKb.extend(CCQo5X.VVgD5I())
  FFHAbB(self, self.VVusDc, VV8kKb=VV8kKb, title="", VVPYdF=True)
 def VVusDc(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCGJtF.VVB3gd("1:7:")
   else   : lst = FFxPkx(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFcVIt(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFIkRt(r)  : sat = "Stream Relay"
       elif FF8yv3(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFxiJi(CFG.exportedTablesPath.getValue()), FFC2jX())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF9glI(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFAM12(self, "No Services found !", 1500)
 @staticmethod
 def VV53C5(SELF):
  FFczPJ()
  FF9glI(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVnfYp(self):
  self.VVjPCP = None
  self.lastfilterUsed  = None
  self.filterObj   = CCkJDN(self)
  VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VVacaE)
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVt6tD  = ("Zap"   , self.VV8mda     , [])
   VVk5TH = (""    , self.VVPHCQ   , [])
   VV9CSs = ("Options"  , self.VVhIOv , [])
   VVaq9G = ("Current Service", self.VVhszQ , [])
   VVTO3h = ("Filter"   , self.VVsG1c  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVmBED  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindServices)
 def VVzmTr(self):
  self.VVjPCP = None
  self.lastfilterUsed  = None
  self.filterObj   = CCkJDN(self)
  VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VVEkoW)
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVt6tD  = ("Zap"   , self.VV8mda      , [])
   VVk5TH = (""    , self.VVPHCQ    , [])
   VVaq9G = ("Current Service", self.VVhszQ  , [])
   VV9CSs = ("Options"  , self.VVSo9U , [])
   VVTO3h = ("Filter"   , self.VVxqnp  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVmBED  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindServices)
 def VVhIOv(self, VVt27A, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CC9SG5(self, VVt27A)
  VV8kKb = []
  isMulti = VVt27A.VVY4gV
  if isMulti:
   refCodeList = VVt27A.VVbrJg(3)
   if refCodeList:
    VV8kKb.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VV8kKb.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VV8kKb.append(VVnK97)
    VV8kKb.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VV8kKb.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VV8kKb.append(VVnK97)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VV8kKb.append((txt1, "parentalControl_add" ))
    VV8kKb.append((txt2,        ))
   else:
    VV8kKb.append((txt1,       ))
    VV8kKb.append((txt2, "parentalControl_remove" ))
   VV8kKb.append(VVnK97)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VV8kKb.append((txt1, "hiddenServices_add"  ))
    VV8kKb.append((txt2,       ))
   else:
    VV8kKb.append((txt1,        ))
    VV8kKb.append((txt2, "hiddenServices_remove" ))
   VV8kKb.append(VVnK97)
  cbFncDict = { "parentalControl_add"   : BF(self.VV6B3r, VVt27A, refCode, True)
     , "parentalControl_remove"  : BF(self.VV6B3r, VVt27A, refCode, False)
     , "hiddenServices_add"   : BF(self.VVomNq, VVt27A, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVomNq, VVt27A, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVeGOo, VVt27A, True)
     , "parentalControl_sel_remove" : BF(self.VVeGOo, VVt27A, False)
     , "hiddenServices_sel_add"  : BF(self.VVIuG9, VVt27A, True)
     , "hiddenServices_sel_remove" : BF(self.VVIuG9, VVt27A, False)
     }
  VV8kKb1, cbFncDict1 = CCGJtF.VVISFP(self, VVt27A, servName, 3)
  VV8kKb.extend(VV8kKb1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVV2XD(VV8kKb, cbFncDict)
 def VVSo9U(self, VVt27A, title, txt, colList):
  servName = colList[0]
  mSel = CC9SG5(self, VVt27A)
  VV8kKb, cbFncDict = CCGJtF.VVISFP(self, VVt27A, servName, 3)
  mSel.VVV2XD(VV8kKb, cbFncDict)
 @staticmethod
 def VVISFP(SELF, VVt27A, servName, refCodeCol):
  tot = VVt27A.VVWJ0c()
  if tot > 0:
   sTxt = FF7kJS("%d Service%s" % (tot, FF7O1V(tot)), VVSFOM)
   VV8kKb = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFJYbZ(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FF7kJS(servName, VVSFOM)
   VV8kKb = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCGJtF.VVo2OQ, SELF, VVt27A, refCodeCol, True)
     , "addToBouquet_one" : BF(CCGJtF.VVo2OQ, SELF, VVt27A, refCodeCol, False)
     }
  return VV8kKb, cbFncDict
 @staticmethod
 def VVo2OQ(SELF, VVt27A, refCodeCol, isMulti):
  picker = CCQo5X(SELF, VVt27A, "Add to Bouquet", BF(CCGJtF.VVCGRt, VVt27A, refCodeCol, isMulti))
 @staticmethod
 def VVCGRt(VVt27A, refCodeCol, isMulti):
  if isMulti : refCodeList = VVt27A.VVbrJg(refCodeCol)
  else  : refCodeList = [VVt27A.VVM4Gr()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VV6B3r(self, VVt27A, refCode, isAddToBlackList):
  VVt27A.VVHSZd("Processing ...")
  FF2Wwv(BF(self.VVnaT3, VVt27A, [refCode], isAddToBlackList))
 def VVeGOo(self, VVt27A, isAddToBlackList):
  refCodeList = VVt27A.VVbrJg(3)
  if not refCodeList:
   FFrj68(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVt27A.VVHSZd("Processing ...")
  FF2Wwv(BF(self.VVnaT3, VVt27A, refCodeList, isAddToBlackList))
 def VVnaT3(self, VVt27A, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVMLsI, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVMLsI):
   lines = FFKcIu(VVMLsI)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVMLsI, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVt27A.VVY4gV
   if isMulti:
    self.VVIm9W(VVt27A, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVasf5(VVt27A, refCode)
    VVt27A.VVtIYK()
  else:
   VVt27A.VVq4Rc("No changes")
 def VVomNq(self, VVt27A, refCode, isHide):
  title = "Change Hidden State"
  if FFtVJx(refCode):
   VVt27A.VVHSZd("Processing ...")
   ret = FFUsLp(refCode, isHide)
   if ret : FF0GsP(self, BF(self.VVasf5, VVt27A, refCode))
   else : FFrj68(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFrj68(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVasf5(self, VVt27A, refCode):
  VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VVacaE, VV0w4s=[3, [refCode], False])
  done = False
  if VVDb2Q:
   data = VVDb2Q[0]
   if data[3] == refCode:
    done = VVt27A.VVtG6o(data)
  if not done:
   self.VVQVz2(VVt27A, VVt27A.VVp4FO(), self.VVacaE)
  VVt27A.VVtIYK()
 def VVIm9W(self, VVt27A, totRefCodes):
  VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VVacaE, VV0w4s=self.VVjPCP)
  VVt27A.VVByC5(VVDb2Q)
  VVt27A.VV5XOs(False)
  VVt27A.VVq4Rc("%d Processed" % totRefCodes)
 def VVIuG9(self, VVt27A, isHide):
  refCodeList = VVt27A.VVbrJg(3)
  if not refCodeList:
   FFrj68(self, "Nothing selected", title="Change Hidden State")
   return
  VVt27A.VVHSZd("Processing ...")
  FF2Wwv(BF(self.VVhvgi, VVt27A, refCodeList, isHide))
 def VVhvgi(self, VVt27A, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFUsLp(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFczPJ(True)
   self.VVIm9W(VVt27A, len(refCodeList))
  else:
   VVt27A.VVq4Rc("No changes")
 def VVsG1c(self, VVt27A, title, txt, colList):
  inFilterFnc = BF(self.VV2jqq, VVt27A) if self.VVjPCP else None
  self.filterObj.VVOKj4(1, VVt27A, 2, BF(self.VVANfA, VVt27A), inFilterFnc=inFilterFnc)
 def VVANfA(self, VVt27A, item):
  self.VVxKTE(VVt27A, False, item, 2, self.VVacaE)
 def VV2jqq(self, VVt27A, VVNmGv, item):
  self.VVxKTE(VVt27A, True, item, 2, self.VVacaE)
 def VVxqnp(self, VVt27A, title, txt, colList):
  inFilterFnc = BF(self.VVkmpP, VVt27A) if self.VVjPCP else None
  self.filterObj.VVOKj4(2, VVt27A, 4, BF(self.VVmGpv, VVt27A), inFilterFnc=inFilterFnc)
 def VVmGpv(self, VVt27A, item):
  self.VVxKTE(VVt27A, False, item, 4, self.VVEkoW)
 def VVkmpP(self, VVt27A, VVNmGv, item):
  self.VVxKTE(VVt27A, True, item, 4, self.VVEkoW)
 def VVn73Y(self, VVt27A, title, txt, colList):
  inFilterFnc = BF(self.VVm0Oe, VVt27A) if self.VVjPCP else None
  self.filterObj.VVOKj4(0, VVt27A, 4, BF(self.VVRo65, VVt27A), inFilterFnc=inFilterFnc)
 def VVRo65(self, VVt27A, item):
  self.VVxKTE(VVt27A, False, item, 4, self.VViqD9)
 def VVm0Oe(self, VVt27A, VVNmGv, item):
  self.VVxKTE(VVt27A, True, item, 4, self.VViqD9)
 def VVxKTE(self, VVt27A, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVt27A.VVIciO(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVjPCP = None
  else:
   words, asPrefix = CCkJDN.VVN7mE(words)
   self.VVjPCP = [col, words, asPrefix]
  if words: FF0GsP(VVt27A, BF(self.VVQVz2, VVt27A, title, mode), clearMsg=False)
  else : FFAM12(VVt27A, "Incorrect filter", 2000)
 def VVQVz2(self, VVt27A, title, mode):
  VVDb2Q, err = CCGJtF.VV2Ohl(self, mode, VV0w4s=self.VVjPCP, VVfYV4=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVt27A.VVXwRB():
    try:
     ndx = VVDb2Q.index(tuple(list(map(str.strip, row))))
     lst.append(VVDb2Q[ndx])
    except:
     pass
   VVDb2Q = lst
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVt27A.VVByC5(VVDb2Q, title, VV78xZMsg=True)
  else:
   FFAM12(VVt27A, "Not found!", 1500)
 def VVqnON(self, title, VVI2kC, VVt6tD=None, VVk5TH=None, VVOFQa=None, VVaq9G=None, VV9CSs=None, VVTO3h=None):
  VVaq9G = ("Current Service", self.VVhszQ, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVmBED = (LEFT  , LEFT  , CENTER, LEFT    )
  FFyZJ5(self, None, title=title, header=header, VVI2kC=VVI2kC, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindServices)
 def VVhszQ(self, VVt27A, title, txt, colList):
  self.VVfAU4(VVt27A)
 def VV32iM(self, VVt27A, title, txt, colList):
  self.VVfAU4(VVt27A, True)
 def VVfAU4(self, VVt27A, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVt27A.VV95eY(colDict, VVSOst=True)
   else:
    VVt27A.VVEIcu(3, refCode, True)
   return
  FFrj68(self, "Cannot read current Reference Code !")
 def VVVPaM(self, title):
  self.VVjPCP = None
  self.lastfilterUsed  = None
  self.filterObj   = CCkJDN(self)
  VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VViqD9)
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVk5TH = (""    , self.VVu9w1 , []      )
   VVaq9G = ("Current Service", self.VV32iM  , []      )
   VVTO3h = ("Filter"   , self.VVn73Y   , [], "Loading Filters ..." )
   VVt6tD  = ("Zap"   , self.VVkcnU      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVmBED  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VVaq9G=VVaq9G, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindServices)
 def VVu9w1(self, VVt27A, title, txt, colList):
  refCode  = self.VV1rud(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFjcFt(self, fncMode=CCOQON.VVPTLY, refCode=refCode, chName=chName, text=txt)
 def VVkcnU(self, VVt27A, title, txt, colList):
  refCode = self.VV1rud(colList)
  FFHFXk(self, refCode)
 def VV8mda(self, VVt27A, title, txt, colList):
  FFHFXk(self, colList[3])
 def VV1rud(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VViWNT(VVZ7cu, mode=0):
  lines = FFKcIu(VVZ7cu, encLst=["UTF-8"])
  return CCGJtF.VVmbjg(lines, mode)
 @staticmethod
 def VVmbjg(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VV2Ohl(SELF, mode, VV0w4s=None, VVfYV4=True, VV9iqe=True):
  VVZ7cu, err = CCGJtF.VVTJB2(SELF, VV9iqe)
  if err:
   return None, err
  asPrefix = False
  if VV0w4s:
   filterCol = VV0w4s[0]
   filterWords = VV0w4s[1]
   asPrefix = VV0w4s[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCGJtF.VVacaE:
   blackList = None
   if fileExists(VVMLsI):
    blackList = FFKcIu(VVMLsI)
    if blackList:
     blackList = set(blackList)
  elif mode == CCGJtF.VVEkoW:
   tp = CC5k8k()
  VVxlaR, VViowm = FFRmby()
  if mode in (CCGJtF.VVgToU, CCGJtF.VVKV7y):
   VVDb2Q = {}
  else:
   VVDb2Q = []
  tagFound = False
  with ioOpen(VVZ7cu, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFcuvM(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCGJtF.VViqD9:
       if sTypeInt in VVxlaR:
        STYPE = VViowm[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVDb2Q.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVDb2Q.append(tRow)
       else:
        VVDb2Q.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCGJtF.VVKpzE:
        VVDb2Q.append((chName, chProv, sat, refCode))
       elif mode == CCGJtF.VVgToU:
        VVDb2Q[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCGJtF.VVKV7y:
        VVDb2Q[chName] = refCode
       elif mode == CCGJtF.VVacaE:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVDb2Q.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVDb2Q.append(tRow)
        else:
         VVDb2Q.append(tRow)
       elif mode == CCGJtF.VVEkoW:
        if sTypeInt in VVxlaR:
         STYPE = VViowm[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVBfDu(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVDb2Q.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVDb2Q.append(tRow)
        else:
         VVDb2Q.append(tRow)
       elif mode == CCGJtF.VVAo0d:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVDb2Q.append((chName, chProv, sat, refCode))
       elif mode == CCGJtF.VV6Yt8:
        VVDb2Q.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVDb2Q and VVfYV4:
   FFrj68(SELF, "No services found!")
  return VVDb2Q, ""
 def VV3y8p(self, title):
  if fileExists(VVMLsI):
   lines = FFKcIu(VVMLsI)
   if lines:
    newRows = []
    VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VV6Yt8)
    if VVDb2Q:
     lines = set(lines)
     for item in VVDb2Q:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVDb2Q = newRows
      VVDb2Q.sort(key=lambda x: x[0].lower())
      VVk5TH = ("", self.VVPHCQ, [])
      VVt6tD = ("Zap", self.VV8mda, [])
      self.VVqnON(title, VVDb2Q, VVt6tD=VVt6tD, VVk5TH=VVk5TH)
     else:
      FFaIgn(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVDb2Q)))
   else:
    FF9glI(self, "No active Parental Control services.", FFyVZy())
  else:
   FFiEaB(self, VVMLsI)
 def VVR1PW(self, title):
  VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VVAo0d)
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVk5TH = ("" , self.VVPHCQ, [])
   VVt6tD  = ("Zap", self.VV8mda, [])
   self.VVqnON(title, VVDb2Q, VVt6tD=VVt6tD, VVk5TH=VVk5TH)
  elif err:
   pass
  else:
   FF9glI(self, "No hidden services.", FFyVZy())
 def VVM3GM(self):
  title = "Services unused in Tuner Configuration"
  VVZ7cu, err = CCGJtF.VVTJB2(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCGJtF.VV3ITy()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VV80ik(str(item[0]))
    nsLst.add(ns)
  sysLst = CCGJtF.VVB3gd("1:7:")
  tpLst  = CCGJtF.VViWNT(VVZ7cu, mode=1)
  VVDb2Q = []
  for refCode, chName in sysLst:
   servID = CCGJtF.VVrLe7(refCode)
   tpID = CCGJtF.VV28cX(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVDb2Q.append((chName, FFcVIt(refCode, False), refCode, servID))
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VV9CSs = ("Options"   , BF(self.VVJK8D, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVmBED  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VV9CSs=VV9CSs, VVuGSD="#0a001122", VVO7CL="#0a001122", VV2ftx="#0a001122", VVgjmd="#00004455", VVZ0ud="#0a333333", VVGQoh="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF9glI(self, "No invalid service found !", title=title)
 def VVJK8D(self, Title, VVt27A, title, txt, colList):
  mSel = CC9SG5(self, VVt27A)
  isMulti = VVt27A.VVY4gV
  if isMulti : txt = "Remove %s Services" % FF7kJS(str(VVt27A.VVWJ0c()), VVvkGK)
  else  : txt = "Remove : %s" % FF7kJS(VVt27A.VVM4Gr()[0], VVvkGK)
  VV8kKb = [(txt, "del")]
  cbFncDict = {"del": BF(FF0GsP, VVt27A, BF(self.VVhTr7, VVt27A, Title))}
  mSel.VVV2XD(VV8kKb, cbFncDict)
 def VVhTr7(self, VVt27A, title):
  VVZ7cu, err = CCGJtF.VVTJB2(self, title=title)
  if err:
   return
  isMulti = VVt27A.VVY4gV
  skipLst = []
  if isMulti : skipLst = VVt27A.VVbrJg(3)
  else  : skipLst = [VVt27A.VVM4Gr()[3]]
  tpLst = CCGJtF.VViWNT(VVZ7cu, mode=0)
  servLst = CCGJtF.VViWNT(VVZ7cu, mode=10)
  tmpDbFile = VVZ7cu + ".tmp"
  lines   = FFKcIu(VVZ7cu)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFWnHJ("mv -f '%s' '%s'" % (tmpDbFile, VVZ7cu))
  VVDb2Q = []
  for row in VVt27A.VVXwRB():
   if not row[3] in skipLst:
    VVDb2Q.append(row)
  FFczPJ()
  FFaIgn(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVDb2Q:
   VVt27A.VVByC5(VVDb2Q, title)
   VVt27A.VV5XOs(False)
  else:
   VVt27A.cancel()
 def VVOryb(self, title):
  VVZ7cu, err = CCGJtF.VVTJB2(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVmBuT(VVZ7cu)
  txt = FF7kJS("Total Transponders:\n\n", VVZkFQ)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF7kJS("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVZkFQ)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF0NYq(item), satList.count(item))
  FFaIgn(self, txt, title)
 def VVmBuT(self, VVZ7cu):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVZ7cu, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVxJLO(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFiEaB(self, path, title=title)
   return
  elif not CCFric.VV4nww(self, path, title):
   return
  if not CCayiU.VVUUNd(self):
   return
  tree = CCGJtF.VVd2wR(self, path, title=title)
  if not tree:
   return
  VVDb2Q = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFcuvM(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVDb2Q.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVDb2Q:
   VVDb2Q.sort(key=lambda x: int(x[1]))
   VVaq9G = ("Current Satellite", BF(self.VV8plR, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVmBED  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=25, VVGRvn=1, VVaq9G=VVaq9G, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFrj68(self, "No data found !", title=title)
 def VV8plR(self, satCol, VVt27A, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  sat = FFcVIt(refCode, False)
  for ndx, row in enumerate(VVt27A.VVXwRB()):
   if sat == row[satCol].strip():
    VVt27A.VVagt1(ndx)
    break
  else:
   FFAM12(VVt27A, "No listed !", 1500)
 def FF0GsP_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFrj68(self, "No Satellites found !")
   return
  usedSats = CCGJtF.VV3ITy()
  VVDb2Q = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVDb2Q.append((sat[1], posTxt, FFcuvM(sat[0]), tuners, str(posVal)))
  if VVDb2Q:
   VV2ftx = "#11222222"
   VVDb2Q.sort(key=lambda x: int(x[1]))
   VVaq9G = ("Current Satellite" , BF(self.VV8plR, 2) , [])
   VV9CSs = ("Options"   , self.VVYNZ6  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVmBED  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVuGSD=VV2ftx, VVO7CL=VV2ftx, VV2ftx=VV2ftx, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFrj68(self, "No data found !")
 def VVYNZ6(self, VVt27A, title, txt, colList):
  mSel = CC9SG5(self, VVt27A)
  isMulti = VVt27A.VVY4gV
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FF7kJS(str(VVt27A.VVWJ0c()), VVvkGK)
  else  : txt = "Remove ALL Services on : %s" % FF7kJS(VVt27A.VVM4Gr()[0], VVvkGK)
  VV8kKb = []
  VV8kKb.append((txt, "deleteSat"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Delete Empty Bouquets", "VVbNbu"))
  cbFncDict = { "deleteSat"   : BF(FF0GsP, VVt27A, BF(self.VV0sTF, VVt27A))
     , "VVbNbu" : BF(self.VVbNbu, VVt27A)
     }
  mSel.VVV2XD(VV8kKb, cbFncDict)
 def VV0sTF(self, VVt27A):
  posLst = []
  isMulti = VVt27A.VVY4gV
  posLst = []
  if isMulti : posLst = VVt27A.VVbrJg(4)
  else  : posLst = [VVt27A.VVM4Gr()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VV80ik(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVsOcl(nsLst)
  FFczPJ(True)
  FFaIgn(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVbNbu(self, winObj):
  title = "Delete Empty Bouquets"
  FFo32K(self, BF(FF0GsP, winObj, BF(self.VVSfu9, title)), "Delete bouquets with no services ?", title=title)
 def VVSfu9(self, title):
  bList = CCQo5X.VVcKgQ()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCQo5X.VVXFOT(bRef)
    bPath = VVORe1 + bFile
    FFfIuR(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVORe1 + fil
     if fileExists(path):
      lines = FFKcIu(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFczPJ(True)
  if bNames: txt = "%s\n\n%s" % (FF7kJS("Deleted Bouquets:", VVSFOM), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFaIgn(self, txt, title=title)
 def VV80ik(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVsOcl(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVORe1)
  for srcF in files:
   if fileExists(srcF):
    lines = FFKcIu(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FF9nVY(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV2jFB(self, title)   : self.VVbORW(title, True)
 def VVtc5H(self, title) : self.VVbORW(title, False)
 def VVbORW(self, title, isWithPIcons):
  piconsPath = CCHnG6.VVYipk()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCHnG6.VVgzfz(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVDb2Q, err = CCGJtF.VV2Ohl(self, self.VV6Yt8)
    if VVDb2Q:
     channels = []
     for (chName, chProv, sat, refCode) in VVDb2Q:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF8cwz(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVDb2Q)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVPmyh(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVPmyh("PIcons Path"  , piconsPath)
     txt += VVPmyh("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVPmyh("Total services" , totalServices)
     txt += VVPmyh("With PIcons"  , totalWithPIcons)
     txt += VVPmyh("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFaIgn(self, txt)
     else:
      VVk5TH     = (""      , self.VVPHCQ , [])
      if isWithPIcons : VVTO3h = ("Export Current PIcon", self.VVRmmh  , [])
      else   : VVTO3h = None
      VV9CSs     = ("Statistics", FFaIgn, [txt])
      VVt6tD      = ("Zap", self.VV8mda, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVqnON(title, channels, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VV9CSs=VV9CSs, VVTO3h=VVTO3h)
   else:
    FFrj68(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFrj68(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVPHCQ(self, VVt27A, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFjcFt(self, fncMode=CCOQON.VVPTLY, refCode=refCode, chName=chName, text=txt)
 def VVRmmh(self, VVt27A, title, txt, colList):
  png, path = CCHnG6.VVp0Sq(colList[3], colList[0])
  if path:
   CCHnG6.VVwqgp(self, png, path)
 @staticmethod
 def VVZsGO():
  VVZ7cu  = "%slamedb" % VVORe1
  VVVzLj = "%slamedb.disabled" % VVORe1
  return VVZ7cu, VVVzLj
 @staticmethod
 def VVeEqk():
  VVffe1  = "%slamedb5" % VVORe1
  VV8Sqy = "%slamedb5.disabled" % VVORe1
  return VVffe1, VV8Sqy
 def VVpu6C(self, isEnable):
  VVZ7cu, VVVzLj = CCGJtF.VVZsGO()
  if isEnable and not fileExists(VVVzLj):
   FF9glI(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVZ7cu):
   FFrj68(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFo32K(self, BF(self.VVY1Pw, isEnable), "%s Hidden Channels ?" % word)
 def VVY1Pw(self, isEnable):
  VVZ7cu , VVVzLj = CCGJtF.VVZsGO()
  VVffe1, VV8Sqy = CCGJtF.VVeEqk()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVVzLj, VVVzLj, VVZ7cu)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV8Sqy, VV8Sqy, VVffe1)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVZ7cu  , VVZ7cu , VVVzLj)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVffe1 , VVffe1, VV8Sqy)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVVzLj, VVZ7cu )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV8Sqy, VVffe1)
  ok = FFWnHJ(cmd)
  FFczPJ()
  if ok: FF9glI(self, "Hidden List %s" % word)
  else : FFrj68(self, "Error while restoring:\n\n%s" % fileName)
 def VVZXIz(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVORe1
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVORe1
  FFkmQh(self, cmd)
 def VVnaTS(self):
  VVZ7cu, err = CCGJtF.VVTJB2(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFfIuR(tmpFile)
  totChan = totRemoved = 0
  lines = FFKcIu(VVZ7cu, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFo32K(self, BF(FF0GsP, self, BF(self.VVrIyF, tmpFile, VVZ7cu, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FF7O1V(totRemoved), totChan, FF7O1V(totChan))
      , callBack_No=BF(self.VVJcGU, tmpFile))
  else:
   FFaIgn(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVrIyF(self, tmpFile, VVZ7cu, totRemoved, totChan):
  FFWnHJ("mv -f '%s' '%s'" % (tmpFile, VVZ7cu))
  FFczPJ()
  FFaIgn(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVJcGU(self, tmpFile):
  FFfIuR(tmpFile)
 @staticmethod
 def VVTJB2(SELF, VV9iqe=True, title=""):
  VVZ7cu, VVVzLj = CCGJtF.VVZsGO()
  if   not fileExists(VVZ7cu)       : err = "File not found !\n\n%s" % VVZ7cu
  elif not CCFric.VV4nww(SELF, VVZ7cu) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VV9iqe:
   FFrj68(SELF, err, title=title)
  return VVZ7cu, err
 @staticmethod
 def VV28cX(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVrLe7(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVB3gd(servTypes):
  VVZ15i  = eServiceCenter.getInstance()
  VVXmGK   = '%s ORDER BY name' % servTypes
  VVUgBZ   = eServiceReference(VVXmGK)
  VVHSTC = VVZ15i.list(VVUgBZ)
  if VVHSTC: return VVHSTC.getContent("CN", False)
  else     : return []
 @staticmethod
 def VV3ITy():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCOQON(Screen):
 VVbCqZ  = 0
 VVkrMs   = 1
 VVUFHA   = 2
 VVPTLY    = 3
 VVCG2x    = 4
 VV4HVt   = 5
 VVSMmD   = 6
 VVOM7g    = 7
 VVkTRU   = 8
 VVMVJq   = 9
 VVfNYZ   = 10
 VVK7oS   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFpC8B(VVECKd, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVbCqZ)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FF7kJS("%s\n", VVuopv) % SEP
  self.picViewer  = None
  FF74S2(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVgQzA })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self["myLabel"].VVnulZ(outputFileToSave="chann_info")
  if   self.fncMode == self.VVbCqZ : fnc = self.VVwUcT
  elif self.fncMode == self.VVkrMs  : fnc = self.VVwUcT
  elif self.fncMode == self.VVUFHA  : fnc = self.VVwUcT
  elif self.fncMode == self.VVPTLY  : fnc = self.VV3B1P
  elif self.fncMode == self.VVCG2x  : fnc = self.VVFa50
  elif self.fncMode == self.VV4HVt  : fnc = self.VVF73X
  elif self.fncMode == self.VVSMmD  : fnc = self.VVGZyX
  elif self.fncMode == self.VVOM7g  : fnc = self.VVCbZs
  elif self.fncMode == self.VVkTRU  : fnc = self.VV6F2s
  elif self.fncMode == self.VVMVJq : fnc = self.VVVYD1
  elif self.fncMode == self.VVfNYZ  : fnc = self.VVLjQ7
  elif self.fncMode == self.VVK7oS : fnc = self.VVlVkW
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVewHM()
  FF2Wwv(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVRE9x()
 def VVjiJX(self, err):
  self["myLabel"].setText(err)
  FFIY0q(self["myTitle"], "#22200000")
  FFIY0q(self["myBody"], "#22200000")
  self["myLabel"].VV5oNy("#22200000")
  self["myLabel"].VVewHM()
 def VVwUcT(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  self.refCode = refCode
  self.VVywHi(chName)
 def VV3B1P(self):
  self.VVywHi(self.chName)
 def VVFa50(self):
  self.VVywHi(self.chName)
 def VVF73X(self):
  self.VVywHi(self.chName)
 def VVGZyX(self):
  self.VVywHi("Picon Info")
 def VVCbZs(self):
  self.VVywHi(self.chName)
 def VV6F2s(self):
  self.VVywHi(self.chName)
 def VVVYD1(self):
  self.VVywHi(self.chName)
 def VVLjQ7(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFKVqd(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVgule(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVywHi(self.chName)
 def VVlVkW(self):
  self.VVywHi(self.chName)
 def VVywHi(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFN3N8(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVnDvp(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF7kJS(self.VVhXpl(tUrl), VViSml)
  if not self.epg:
   epg = CCS6Mr.VVh3fh(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV2r8F(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCHnG6.VVp0Sq(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV2r8F(path)
  self.VVb6MX()
  self.VV2yNu(decodedUrl)
  self["myLabel"].setText(self.text or "   No active service", VViXLk=VVBeVn)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVewHM(minHeight=minH)
 def VV2yNu(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FF8yv3(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVgp3P(FFD0Hz(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCXeC7.VVEwWd(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCXeC7.VVEwWd(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFXlM7("EPG:", VVSFOM) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVb6MX()
 def VVb6MX(self):
  if not self.piconShown and self.picUrl:
   path, err = FFadHO(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV2r8F(path)
    if self.piconShown and self.refCode:
     self.VVXwFO(path, self.refCode)
 def VVXwFO(self, path, refCode):
  if path and fileExists(path) and FFFS65("ffmpeg"):
   pPath = CCHnG6.VVYipk()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCOQON.VVTaWN(path)
    cmd += FFhyjZ("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFWnHJ(cmd)
 def VV2r8F(self, path):
  if path and fileExists(path):
   err, w, h = self.VVpZ7I(path)
   if not err:
    if h > w:
     self.VVevjZ(self["myPicF"], w, h, True)
     self.VVevjZ(self["myPicB"], w, h, False)
     self.VVevjZ(self["myPic"] , w, h, False)
   self.picViewer = CCCyfp.VVbhHo(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVevjZ(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVpZ7I(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFdVkh(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVnDvp(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF7kJS(chName, VVSFOM)
  txt += self.VVPmyh(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF7kJS(state, VVSBcQ)
   txt += "State\t: %s\n" % state
  w = FFPfNs(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFPfNs(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVPKQl(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVPmyh(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVPmyh(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVPmyh(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVC6mh()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVggXU()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCOQON.VVD2Qj(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF7kJS("Stream-Relay" if FFIkRt(decodedUrl) else "IPTV", VVZkFQ)
   txt += self.VVzF1t(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VV8ZW1(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC5k8k()
    tpTxt, namespace = tp.VVupR4(refCode)
    if tpTxt:
     txt += FF7kJS("Tuner:\n", VVSFOM)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF7kJS("Codes:\n", VVSFOM)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVPmyh(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVPmyh(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVPmyh(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVPmyh(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVPmyh(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVPmyh(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVPmyh(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVPmyh(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVPmyh(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVPKQl(info):
  if info:
   aspect = FFPfNs(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVPmyh(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFPfNs(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVhLa8(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVhLa8(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVC6mh(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVggXU(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VV8ZW1(self, refCode, iptvRef, chName):
  refCode = FFnnjU(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFQByV(VVORe1 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFQByV(VVORe1 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVI2kC = []
  tmpRefCode = FFD0Hz(refCode)
  for item in fList:
   path = VVORe1 + item
   if fileExists(path):
    txt = FFQByV(path)
    if tmpRefCode in FFD0Hz(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVI2kC.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVI2kC:
   if len(VVI2kC) == 1:
    txt += "%s\t: %s%s\n" % (FF7kJS("Bouquet", VVSFOM), VVI2kC[0][0], " (%s)" % VVI2kC[0][1] if VVcsO2 else "")
   else:
    txt += FF7kJS("Bouquets:\n", VVSFOM)
    for ndx, item in enumerate(VVI2kC):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVcsO2 else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVzF1t(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFWeS7(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCXeC7()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF7kJS("URL:", VVZkFQ) + "\n%s\n" % self.VVhXpl(decodedUrl)
  else:
   txt = "\n"
   txt += FF7kJS("Reference:", VVZkFQ) + "\n%s\n" % refCode
  return txt
 def VVhXpl(self, url):
  if not FFIkRt(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVksGH:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFD0Hz(url)
 def VVgp3P(self, decodedUrl):
  if not CCiKm1.VVQ8ve():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC1B0Q.VVIq7x(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC1B0Q.VVEaWb(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVxzfd(tDict)
   elif uType == "movie" : epg, picUrl = CCOQON.VV4Gum(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVxzfd(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC1B0Q.VVrKuD(item, "title"    , is_base64=True )
     lang    = CC1B0Q.VVrKuD(item, "lang"         ).upper()
     description   = CC1B0Q.VVrKuD(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC1B0Q.VVrKuD(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC1B0Q.VVrKuD(item, "start_timestamp"      )
     stop_timestamp  = CC1B0Q.VVrKuD(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC1B0Q.VVrKuD(item, "stop_timestamp"       )
     now_playing   = CC1B0Q.VVrKuD(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVkbX3, ""
      else     : color, txt = VVSBcQ , "    (CURRENT EVENT)"
      epg += FF7kJS("_" * 32 + "\n", VVuopv)
      epg += FF7kJS("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF7kJS(description, VViSml)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCS6Mr.VVCij8(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VV4Gum(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC1B0Q.VVrKuD(item, "movie_image" )
    genre  = CC1B0Q.VVrKuD(item, "genre"   ) or "-"
    plot  = CC1B0Q.VVrKuD(item, "plot"   ) or "-"
    country  = CC1B0Q.VVrKuD(item, "country"  ) or "-"
    actors  = CC1B0Q.VVrKuD(item, "actors"   ) or "-"
    cast  = CC1B0Q.VVrKuD(item, "cast"   ) or "-"
    rating  = CC1B0Q.VVrKuD(item, "rating"   ) or "-"
    director = CC1B0Q.VVrKuD(item, "director"  ) or "-"
    releasedate = CC1B0Q.VVrKuD(item, "releasedate" ) or "-"
    duration = CC1B0Q.VVrKuD(item, "duration"  ) or "-"
    try:
     lang = CC1B0Q.VVrKuD(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF7kJS(cast if cast != "-" else actors, VViSml)
    epg += "Plot:\n%s"    % FF7kJS(plot, VViSml)
   except:
    pass
  return epg, movie_image
 def VVgQzA(self):
  if VVksGH:
   def VVPmyh(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVPmyh(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCXeC7()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVPmyh(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFAM12(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVVvik(SELF):
  if not CCVrap.VV06qX(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF)
  err = url =  fSize = resumable = ""
  if FF4HLW(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCXeC7.VVnMiS(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCXeC7.VVXH11(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFrj68(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCFric.VVgYti(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF7kJS(" (M3U/M3U8 File)", VViSml)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCnvmH.VVhRbd(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVrCdg(subj, val):
   return "%s\n%s\n\n" % (FF7kJS("%s:" % subj, VVSFOM), val)
  title = "File Size"
  txt  = VVrCdg(title , fSize or "?")
  txt += VVrCdg("Name" , chName)
  txt += VVrCdg("URL" , url)
  if resumable: txt += VVrCdg("Supports Download-Resume", resumable)
  if err  : txt += FF7kJS("Error:\n", VVSBcQ) + err
  FFaIgn(SELF, txt, title=title)
 @staticmethod
 def VVD2Qj(SELF):
  fPath, fDir, fName = CCFric.VVEl1L(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVTaWN(path):
  return FFhyjZ("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVQips(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCHnG6.VVYipk() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVsfU7(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FF8yv3(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FF9nVY(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCXeC7():
 def __init__(self):
  self.VV2Pme()
  self.VV33VB    = ""
  self.VV0oW8   = "#f#11ffffaa#User"
  self.VV6qBY   = "#f#11aaffff#Server"
 def VV2Pme(self):
  self.VVkL6K   = ""
  self.VVPcbV    = ""
  self.VVC0Ul   = ""
  self.VV5vIg = ""
  self.VVWbTd  = ""
  self.VVUgkP = 0
 def VVOAxo(self, url, mac, ph1="", VVSOst=True):
  self.VV2Pme()
  self.VV33VB = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVrih5(url)
  if not host:
   if VVSOst:
    self.VVwaVA("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVwLz6(mac)
  if not host:
   if VVSOst:
    self.VVwaVA("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVkL6K = host
  self.VVPcbV  = mac
  return True
 def VVFVTC(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VV33VB, "")
 def VVrih5(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVwLz6(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV3VIf(self):
  res, err = self.VVc0lf(self.VVu3XB())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVkL6K.endswith("/c"):
    self.VVkL6K = self.VVkL6K[:-2]
    res, err = self.VVc0lf(self.VVu3XB())
   elif self.VVkL6K.endswith("/stalker_portal"):
    self.VVkL6K = self.VVkL6K[:-15]
    res, err = self.VVc0lf(self.VVu3XB())
   else:
    self.VVkL6K += "/c"
    res, err = self.VVc0lf(self.VVu3XB())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC1B0Q.VVrKuD(tDict["js"], "token")
    rand  = CC1B0Q.VVrKuD(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVdKly(self, VVSOst=True):
  if not self.VV33VB:
   self.VVX7HH()
  err = blkMsg = FF9glITxt = ""
  try:
   token, rand, err = self.VV3VIf()
   if token:
    self.VVC0Ul = token
    self.VV5vIg = rand
    if rand:
     self.VVUgkP = 2
    prof, retTxt = self.VVRpG3(True)
    if prof:
     self.VVWbTd = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVUgkP = 3
      prof, retTxt = self.VVRpG3(False)
      if retTxt:
       self.VVWbTd = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF9glITxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF9glITxt: tErr += "\n%s" % FF9glITxt
  if VVSOst:
   self.VVwaVA(tErr)
  return "", "", tErr
 def VVX7HH(self):
  try:
   import requests
   url = self.VVvLwV()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCXeC7.VVXH11(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCXeC7.VVXH11(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVkL6K = url
       self.VV33VB = span.group(1)
       return
  except:
   pass
  self.VV33VB = "/server/load.php"
 def VVvLwV(self):
  url = self.VVkL6K.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVOsPv(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVc0lf("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVc0lf("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVRpG3(self, capMac):
  res, err = self.VVc0lf(self.VVZrKY(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC1B0Q.VVrKuD(tDict["js"], "block_%s" % word)
    FF9glITxt = CC1B0Q.VVrKuD(tDict["js"], word)
    return tDict, FF9glITxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVZrKY(self, capMac):
  param = ""
  if self.VVWbTd or self.VV5vIg:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVPcbV.upper() if capMac else self.VVPcbV.lower(), self.VV5vIg))
  return self.VVseIs() + "type=stb&action=get_profile" + param
 exec(FFKVqd("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVoaP8(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVvQ3A()
  if len(rows) < 10:
   rows = self.VVmQBq()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVkL6K ))
   rows.append(("MAC (from URL)" , self.VVPcbV ))
   rows.append(("Token"   , self.VVC0Ul ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VV0oW8  , "MAC" , self.VVPcbV ))
   rows.append(("2", self.VV6qBY, "Host" , self.VVkL6K ))
   rows.append(("2", self.VV6qBY, "Token" , self.VVC0Ul ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV4Iy7(self, isPhp=True, VVSOst=False):
  token, profile, tErr = self.VVdKly(VVSOst)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VV1Svw()
  res, err = self.VVc0lf(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC1B0Q.VVrKuD(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFw8K0(span.group(2))
     pass1 = FFw8K0(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVvQ3A(self):
  m3u_Url, host, user1, pass1, err = self.VV4Iy7()
  rows = []
  if m3u_Url:
   res, err = self.VVc0lf(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFDwGN(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VV0oW8, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFDwGN(int(val))
      else      : val = str(val)
      rows.append(("2", self.VV6qBY, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVmQBq(self):
  token, profile, tErr = self.VVdKly()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFjwce(val): val = FFKVqd(val.decode("UTF-8"))
     else     : val = self.VVPcbV
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFDwGN(int(parts[1]))
      if parts[2] : ends = FFDwGN(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFDwGN(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVgule(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVdKly(VVSOst=False)
  if not token:
   return ""
  crLinkUrl = self.VVMNPz(mode, chCm, epNum, epId)
  res, err = self.VVc0lf(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC1B0Q.VVrKuD(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVseIs(self):
  return self.VVkL6K + self.VV33VB + "?"
 def VVu3XB(self):
  return self.VVseIs() + "type=stb&action=handshake&token=&mac=%s" % self.VVPcbV
 def VV9K6M(self, mode):
  url = self.VVseIs() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVAu3R(self, catID):
  return self.VVseIs() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVKQrz(self, mode, catID, page):
  url = self.VVseIs() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVyBPW(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVseIs() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VV0dVQ(self, stID):
  return self.VVseIs() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVMNPz(self, mode, chCm, serCode, serId):
  url = self.VVseIs() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV1Svw(self):
  return self.VVseIs() + "type=itv&action=create_link"
 def VVGEc1(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV2QBX(catID, stID, chNum)
  query = self.VVFrM9(mode, self.VVFVTC(), FFTNiH(host), FFTNiH(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVFrM9(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVPuS3(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVFrM9(mode, ph1, host, mac, epNum, epId, FFw8K0(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFKVqd(host)
  mac   = FFKVqd(mac)
  valid = False
  if self.VVrih5(playHost) and self.VVrih5(host) and self.VVrih5(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVc0lf(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCXeC7.VVXH11()
   if self.VVC0Ul:
    headers["Authorization"] = "Bearer %s" % self.VVC0Ul
   if useCookies : cookies = {"mac": self.VVPcbV, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVtmW3(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCXeC7.VVXH11(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVXH11():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVwaVA(self, err, title="Portal Browser"):
  FFrj68(self, str(err), title=title)
 def VV48MQ(self, mode):
  if   mode in ("itv"  , CC1B0Q.VV516e , CC1B0Q.VVxweg)  : return "Live"
  elif mode in ("vod"  , CC1B0Q.VV2CzX , CC1B0Q.VVqv2O)  : return "VOD"
  elif mode in ("series" , CC1B0Q.VVx5gl , CC1B0Q.VV7UCG) : return "Series"
  else                          : return "IPTV"
 def VVp29I(self, mode, searchName):
  return 'Find in %s : %s' % (self.VV48MQ(mode), FF7kJS(searchName, VViSml))
 def VV3FEQ(self, catchup=False):
  VV8kKb = []
  VV8kKb.append(("Live"    , "live"  ))
  VV8kKb.append(("VOD"    , "vod"   ))
  VV8kKb.append(("Series"   , "series"  ))
  if catchup:
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Catch-up TV" , "catchup"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Account Info." , "accountInfo" ))
  return VV8kKb
 @staticmethod
 def VVsyWu(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCXeC7()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(decodedUrl)
  if valid:
   ok = p.VVOAxo(host, mac, ph1, VVSOst=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VV4Iy7(isPhp=False, VVSOst=False)
    streamId = CCXeC7.VVLNjQ(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVLNjQ(decodedUrl):
  p = CCXeC7()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFKVqd(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVnMiS(decodedUrl):
  p = CCXeC7()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(decodedUrl)
  if valid:
   if CCXeC7.VV1H6t(chCm):
    return FFD0Hz(chCm)
   else:
    ok = p.VVOAxo(host, mac, ph1, VVSOst=False)
    if ok:
     try:
      chUrl = p.VVgule(mode, chCm, epNum, epId)
      return FFD0Hz(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VV1H6t(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVEwWd(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCXeC7()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(decodedUrl)
   if valid:
    if not stID:
     stID = CCXeC7.VVLNjQ(decodedUrl)
    if stID:
     if p.VVOAxo(host, mac, ph1, VVSOst=False):
      token, profile, tErr = p.VVdKly(VVSOst=False)
      if token:
       res, err = p.VVc0lf(p.VV0dVQ(stID))
       if res:
        epg, err = CCXeC7.VVaBin(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCXeC7.VVaBin(res.text, retLst=True)
         if pList:
          totEv, totOK = CCS6Mr.VVCij8(refCode, pList)
  return epg, err
 @staticmethod
 def VVaBin(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CC1B0Q.VVrKuD(item, "actor"       )
    category   = CC1B0Q.VVrKuD(item, "category"      )
    descr    = CC1B0Q.VVrKuD(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CC1B0Q.VVrKuD(item, "director"      )
    name    = CC1B0Q.VVrKuD(item, "name"   , is_base64=True)
    start_timestamp  = CC1B0Q.VVrKuD(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CC1B0Q.VVrKuD(item, "start_timestamp"    )
    stop_timestamp  = CC1B0Q.VVrKuD(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CC1B0Q.VVrKuD(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FF7kJS("    (CURRENT EVENT)", VV30Pd)
     except:
      pass
     if not skip:
      epg += FF7kJS("_" * 32 + "\n", VVuopv)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FF7kJS(name, VVSFOM)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FF7kJS(descr , VViSml) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FF7kJS(category, VViSml) if category else ""
      epg += "Actors:\n%s\n"  % FF7kJS(actor , VViSml) if actor else ""
      epg += "Director:\n%s\n" % FF7kJS(director, VViSml) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCbnKw(CCXeC7):
 def __init__(self):
  CCXeC7.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VV15dO(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVPuS3(decodedUrl)
  if valid:
   if self.VVOAxo(host, mac, ph1, VVSOst=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVgpfW(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFKVqd(self.chCm[3:])
  else:
   try:
    chUrl = self.VVgule(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCXeC7.VV1H6t(self.chCm):
   chUrl = FFD0Hz(self.chCm)
   chUrl = FFw8K0(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVQ9ty(chUrl)
  bPath = CCQo5X.VVtXkS()
  if newIptvRef:
   if passedSELF:
    FFHFXk(passedSELF, newIptvRef, VVLARq=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFHFXk(self, newIptvRef, VVLARq=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVtNwM(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVQ9ty(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVtNwM(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FFKcIu(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFczPJ()
class CCiFDq(CCbnKw):
 def __init__(self, passedSession):
  CCbnKw.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVjMHW(VVeMes  )
  Main_Menu.VVjMHW(VVNXZt)
  Main_Menu.VVjMHW(VVXkur  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVPGXd, iPlayableService.evEOF: self.VVy7Tg, iPlayableService.evEnd: self.VVgwo1})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVQoaU)
  except:
   self.timer2.callback.append(self.VVQoaU)
  self.timer2.start(3000, False)
  self.VVQoaU()
 def VVQoaU(self):
  if not CFG.downloadMonitor.getValue():
   self.VV7Gtq()
   return
  lst = CCnvmH.VVJ0jl()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FF7PcS(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCnvmH.VVKaTN(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCajpF.VVhc8i(self.passedSession, txt, 30)
   else    : CCajpF.VVSWmQ(self.dnldWin, txt)
  elif self.dnldWin:
   self.VV7Gtq()
 def VV7Gtq(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVPGXd(self):
  self.startTime = iTime()
 def VVy7Tg(self):
  global VV5ciW
  VV5ciW = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FF4HLW(decodedUrl):
     self.isFromEOF = True
     CCajpF(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVgwo1(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVSzdL)
  except:
   self.timer1.callback.append(self.VVSzdL)
  self.timer1.start(100, True)
 def VVSzdL(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VV15dO(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCLDrN.VVgkJK:
       self.isFromEOF = False
       self.VVgpfW(self.passedSession, isFromSession=True)
class CC87TJ():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F](.+)")
  self.prefixRemoveList = self.VVl0Mv(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVl0Mv(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVl0Mv(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VV8hpn, VVBI3c):
    path += fName
    if fileExists(path):
     for line in FFKcIu(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVYUsJ(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC1B0Q.VVMzzc(name):
   return CC1B0Q.VVJ1nD(name)
  return self.VVTm3O(name)
 def VVTm3O(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVM385(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVTm3O(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVzO98(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVkVvr(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVV9VI(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCVrap(CCXeC7):
 def __init__(self):
  self.curPortalCatId = ""
  CCXeC7.__init__(self)
 def VVypwB(self):
  if CCVrap.VV06qX(self):
   FF0GsP(self, BF(self.VVNqX4, 2), title="Searching ...")
 def VV6bO0(self, winSession, url, mac):
  self.curUrl = url
  if CCVrap.VV06qX(self):
   if self.VVOAxo(url, mac):
    FF0GsP(winSession, self.VVEkyi, title="Checking Server ...")
   else:
    FFrj68(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVda0x(self, item=None):
  if item:
   VVNmGv, txt, path, ndx = item
   enc = CCP2t1.VVhvNn(path, self)
   if enc == -1:
    return
   self.session.open(CCfhQr, barTheme=CCfhQr.VVZYJm
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVVi0c, path, enc)
       , VVVnlJ = BF(self.VVUJPJ, VVNmGv, path))
 def VVVi0c(self, path, enc, VVtEPC):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVtEPC.VVodiL(totLines)
  VVtEPC.VVsc2i = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVtEPC or VVtEPC.isCancelled:
     return
    VVtEPC.VV2Wgw(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVrih5(url)
     mac  = self.VVwLz6(mac)
     if host and mac and VVtEPC:
      VVtEPC.VVsc2i.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVrih5(url)
      mac  = self.VVwLz6(mac)
      if host and mac and not mac.startswith("AC") and VVtEPC:
       VVtEPC.VVsc2i.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVUJPJ(self, VVNmGv, path, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVsc2i:
   VVOFQa  = ("Home Menu"  , FFKSrd            , [])
   VV9CSs = ("Edit File"  , BF(self.VVtLY7, path)       , [])
   VVaq9G = ("M3U Options" , self.VVpeYf         , [])
   VVTO3h = ("Check & Filter" , BF(self.VV4MH9, VVNmGv, path), [])
   VVt6tD  = ("Select"   , self.VVT2fr      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVmBED  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVsc2i, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVuGSD="#0a001122", VVO7CL="#0a001122", VV2ftx="#0a001122", VVgjmd="#00004455", VVZ0ud="#0a333333", VVGQoh="#11331100", VV2v46=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVYFmk:
    FFAM12(VVt27A, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVYFmk:
    FFrj68(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVpeYf(self, VVt27A, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VV8kKb = []
  VV8kKb.append(("Browse as M3U"  , "browse"))
  VV8kKb.append(("Download M3U File" , "downld"))
  FFHAbB(self, BF(self.VV1oqi, VVt27A, host, mac), title=title, VV8kKb=VV8kKb, width=600, VVPYdF=True)
 def VV1oqi(self, VVt27A, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FF0GsP(VVt27A, BF(self.VV7w7Z, VVt27A, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFo32K(self, BF(FF0GsP, VVt27A, BF(self.VV7w7Z, VVt27A, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV7w7Z(self, VVt27A, title, host, mac, item):
  p = CCXeC7()
  m3u_Url = ""
  ok = p.VVOAxo(host, mac, VVSOst=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV4Iy7(VVSOst=False)
  if m3u_Url:
   if   item == "browse": self.VVNsuO(title, m3u_Url)
   elif item == "downld": self.VVSY1F(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFrj68(self, err or "No response from Server !", title=title)
 def VVT2fr(self, VVt27A, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV6bO0(VVt27A, url, mac)
 def VVtLY7(self, path, VVt27A, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCAoYu(self, path, VVVnlJ=BF(self.VVrtHh, VVt27A), curRowNum=rowNum)
  else    : FFiEaB(self, path)
 def VV4MH9(self, VVNmGv, path, VVt27A, title, txt, colList):
  self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVYab4, VVt27A)
      , VVVnlJ = BF(self.VVTVdP, VVNmGv, VVt27A, path))
 def VVYab4(self, VVt27A, VVtEPC):
  VVtEPC.VVsc2i = []
  VVtEPC.VVodiL(VVt27A.VV9aLU())
  for row in VVt27A.VVXwRB():
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VV2Wgw(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVOAxo(host, mac, VVSOst=False):
    token, profile, tErr = self.VVdKly(VVSOst=False)
    if token and VVtEPC and not VVtEPC.isCancelled:
     res, err = self.VVc0lf(self.VV9K6M("itv"))
     if res and VVtEPC and not VVtEPC.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVtEPC.VV2Wgw(0, showFound=True)
       VVtEPC.VVsc2i.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVtEPC:
    return
 def VVTVdP(self, VVNmGv, VVt27A, path, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if VVsc2i:
   VVt27A.close()
   VVNmGv.close()
   newPath = "%s_OK_%s.txt" % (path, FFC2jX())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVsc2i:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF7kJS(str(threadCounter), VVSBcQ)
    skipped = FF7kJS(str(threadTotal - threadCounter), VVSBcQ)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVsc2i)
   txt += "%s\n\n%s"    %  (FF7kJS("Result File:", VVSFOM), newPath)
   FFaIgn(self, txt, title="Accessible Portals")
  elif VVYFmk:
   FFrj68(self, "No portal access found !", title="Accessible Portals")
 def VVuSAt(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFKVqd(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVEkyi(self):
  token, profile, tErr = self.VVdKly()
  if token:
   dots = "." * self.VVUgkP
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVFVTC(), "")
   dots += "*" if not self.VVkL6K == self.curUrl else ""
   VV8kKb  = self.VV3FEQ()
   VVodvg = self.VVEVxR
   VVM6M9 = self.VVuRBk
   VV1zfK = ("Home Menu", FFKSrd)
   VVinPK= ("Add to Menu", BF(CC1B0Q.VVCMHv, self, True, self.VVkL6K + "\t" + self.VVPcbV))
   VVcx0D = ("Bookmark Server", BF(CC1B0Q.VVMH4x, self, True, self.VVkL6K + "\t" + self.VVPcbV))
   VVNmGv = FFHAbB(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVPcbV, dots), VV8kKb=VV8kKb, VVodvg=VVodvg, VVM6M9=VVM6M9, VV1zfK=VV1zfK, VVinPK=VVinPK, VVcx0D=VVcx0D)
   self.VVdifZ(VVNmGv)
 def VVEVxR(self, item=None):
  if item:
   VVNmGv, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF0GsP(VVNmGv, BF(self.VV6sPj, mode), title="Reading Categories ...")
   else : FF0GsP(VVNmGv, BF(self.VVst7i, VVNmGv, title), title="Reading Account ...")
 def VVst7i(self, VVNmGv, title, forceMoreInfo=False):
  rows, totCols = self.VVoaP8(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVPcbV)
  VVOFQa  = ("Home Menu" , FFKSrd           , [])
  VVaq9G  = None
  if VVksGH:
   VVaq9G = ("Get JS"  , BF(self.VVf4b6, self.VVvLwV()) , [])
  if totCols == 2:
   VVTO3h = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVTO3h = ("More Info.", BF(self.VV6LES, VVNmGv)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFyZJ5(self, None, title=title, width=1200, header=header, VVI2kC=rows, VVWFHs=widths, VVC5IT=26, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VVTO3h=VVTO3h, VVuGSD="#0a00292B", VVO7CL="#0a002126", VV2ftx="#0a002126", VVgjmd="#00000000", searchCol=searchCol)
 def VVf4b6(self, url, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVhird, url), title="Getting JS ...")
 def VVhird(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVPcbV)
  ver, err = self.VVOsPv(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVOsPv(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFaIgn(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VV6LES(self, VVNmGv, VVt27A, title, txt, colList):
  VVt27A.cancel()
  FF0GsP(VVNmGv, BF(self.VVst7i, VVNmGv, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV6sPj(self, mode):
  token, profile, tErr = self.VVdKly()
  if not token:
   return
  res, err = self.VVc0lf(self.VV9K6M(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CC1B0Q.VVrKuD(item, "id"       )
      Title  = CC1B0Q.VVrKuD(item, "title"      )
      censored = CC1B0Q.VVrKuD(item, "censored"     )
      Title = self.VVzO98(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVcsO2:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VV48MQ(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ(mode)
   mName = self.VV48MQ(mode)
   VVZApD  = (""     , BF(self.VVapT7, mode), [])
   VVt6tD   = ("Show List"   , BF(self.VVsWMe, mode)   , [])
   VVOFQa  = ("Home Menu"   , FFKSrd        , [])
   if mode in ("vod", "series"):
    VV9CSs = ("Find in %s" % mName , BF(self.VVxcw4, mode, False), [])
    VVTO3h = ("Find in Selected" , BF(self.VVxcw4, mode, True) , [])
   else:
    VV9CSs = None
    VVTO3h = None
   header   = None
   widths   = (100   , 0  )
   FFyZJ5(self, None, title=title, width=1200, header=header, VVI2kC=list, VVWFHs=widths, VVC5IT=30, VVOFQa=VVOFQa, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVZApD=VVZApD, VVt6tD=VVt6tD, VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VV2ftx, VVgjmd=VVgjmd, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVWbTd:
     txt += "\n\n( %s )" % self.VVWbTd
   else:
    txt = "Could not get Categories from server!"
   FFrj68(self, txt, title=title)
 def VVn53J(self, mode, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVaTCx, mode, VVt27A, title, txt, colList), title="Downloading ...")
 def VVaTCx(self, mode, VVt27A, title, txt, colList):
  token, profile, tErr = self.VVdKly()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVc0lf(self.VVAu3R(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CC1B0Q.VVrKuD(item, "id"    )
      actors   = CC1B0Q.VVrKuD(item, "actors"   )
      added   = CC1B0Q.VVrKuD(item, "added"   )
      age    = CC1B0Q.VVrKuD(item, "age"   )
      category_id  = CC1B0Q.VVrKuD(item, "category_id" )
      description  = CC1B0Q.VVrKuD(item, "description" )
      director  = CC1B0Q.VVrKuD(item, "director"  )
      genres_str  = CC1B0Q.VVrKuD(item, "genres_str"  )
      name   = CC1B0Q.VVrKuD(item, "name"   )
      path   = CC1B0Q.VVrKuD(item, "path"   )
      screenshot_uri = CC1B0Q.VVrKuD(item, "screenshot_uri" )
      series   = CC1B0Q.VVrKuD(item, "series"   )
      cmd    = CC1B0Q.VVrKuD(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVZApD = (""     , BF(self.VVdxhh, mode, True)  , [])
   VVt6tD  = ("Play"    , BF(self.VVNSPp, mode)       , [])
   VVk5TH = (""     , BF(self.VVEsMW, mode)     , [])
   VVOFQa = ("Home Menu"   , FFKSrd            , [])
   VVaq9G = ("Download Options" , BF(self.VVPP7a, mode, "sp", seriesName) , [])
   VV9CSs = ("Options"   , BF(self.VV3T1Q, "pEp", mode, seriesName) , [])
   VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVmBED  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFyZJ5(self, None, title=seriesName, width=1200, header=header, VVI2kC=list, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVZApD=VVZApD, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindIptv, VVuGSD="#0a00292B", VVO7CL="#0a002126", VV2ftx="#0a002126", VVgjmd="#00000000")
  else:
   FFrj68(self, "Could not get Episodes from server!", title=seriesName)
 def VVxcw4(self, mode, searchInCat, VVt27A, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VV8kKb = []
  VV8kKb.append(("Keyboard"  , "manualEntry"))
  VV8kKb.append(("From Filter" , "fromFilter"))
  FFHAbB(self, BF(self.VVwSI8, VVt27A, mode, searchCatId), title="Input Type", VV8kKb=VV8kKb, width=400)
 def VVwSI8(self, VVt27A, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFTtos(self, BF(self.VVaOxo, VVt27A, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCkJDN(self)
    filterObj.VVSaNO(BF(self.VVaOxo, VVt27A, mode, searchCatId))
 def VVaOxo(self, VVt27A, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFaoHf(CFG.lastFindIptv, searchName)
   title = self.VVp29I(mode, searchName)
   if "," in searchName : FFrj68(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFrj68(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVkVvr([searchName]):
     FFrj68(self, self.VVV9VI(), title=title)
    else:
     self.VVMzj1(mode, searchName, "", searchName, searchCatId)
 def VVsWMe(self, mode, VVt27A, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVMzj1(mode, bName, catID, "", "")
 def VVMzj1(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCfhQr, barTheme=CCfhQr.VVZYJm
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVLhPJ, mode, bName, catID, searchName, searchCatId)
      , VVVnlJ = BF(self.VVChEq, mode, bName, catID, searchName, searchCatId))
 def VVChEq(self, mode, bName, catID, searchName, searchCatId, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVp29I(mode, searchName)
  else   : title = "%s : %s" % (self.VV48MQ(mode), bName)
  if VVsc2i:
   VVaq9G = None
   VV9CSs = None
   if mode == "series":
    VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ("series2")
    VVt6tD  = ("Episodes"   , BF(self.VVn53J, mode)           , [])
   else:
    VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ("")
    VVt6tD  = ("Play"    , BF(self.VVNSPp, mode)           , [])
    VVaq9G = ("Download Options" , BF(self.VVPP7a, mode, "vp" if mode == "vod" else "", "") , [])
    VV9CSs = ("Options"   , BF(self.VV3T1Q, "pCh", mode, bName)      , [])
   VVZApD = (""      , BF(self.VVdxhh, mode, False)      , [])
   VVk5TH = (""      , BF(self.VVpVAo, mode)         , [])
   VVOFQa = ("Home Menu"    , FFKSrd                , [])
   VVTO3h = ("Posters Mode"   , BF(self.VV1LUN, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVmBED  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVsc2i, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindIptv, VVt6tD=VVt6tD, VVZApD=VVZApD, VVk5TH=VVk5TH, VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VV2ftx, VVgjmd=VVgjmd, VV2v46=True, searchCol=1)
   if not VVYFmk:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVt27A.VVryn7(VVt27A.VVp4FO() + tot)
    if threadErr: FFAM12(VVt27A, "Error while reading !", 2000)
    else  : FFAM12(VVt27A, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFrj68(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFrj68(self, "Could not get list from server !", title=title)
 def VVpVAo(self, mode, VVt27A, title, txt, colList):
  ttl = lambda x, y: "%s\n%s\n\n" % (FF7kJS(x, VVSFOM), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFjcFt(self, fncMode=CCOQON.VVK7oS, portalHost=self.VVkL6K, portalMac=self.VVPcbV, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVpCW8(mode, VVt27A, title, txt, colList)
 def VVEsMW(self, mode, VVt27A, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF7kJS(colList[10], VViSml)
  txt += "Description:\n%s" % FF7kJS(colList[11], VViSml)
  self.VVpCW8(mode, VVt27A, title, txt, colList)
 def VVpCW8(self, mode, VVt27A, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVayQj(mode, colList)
  refCode, chUrl = self.VVGEc1(self.VVkL6K, self.VVPcbV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFjcFt(self, fncMode=CCOQON.VVfNYZ, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVLhPJ(self, mode, bName, catID, searchName, searchCatId, VVtEPC):
  try:
   token, profile, tErr = self.VVdKly()
   if not token:
    return
   if VVtEPC.isCancelled:
    return
   VVtEPC.VVsc2i, total_items, max_page_items, err = self.VV7H0Z(mode, catID, 1, 1, searchName, searchCatId)
   if VVtEPC.isCancelled:
    return
   if VVtEPC.VVsc2i and total_items > -1 and max_page_items > -1:
    VVtEPC.VVodiL(total_items)
    VVtEPC.VV2Wgw(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVtEPC.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VV7H0Z(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVtEPC.VVzEls()
     if VVtEPC.isCancelled:
      return
     if list:
      VVtEPC.VVsc2i += list
      VVtEPC.VV2Wgw(len(list), True)
  except:
   pass
 def VV7H0Z(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVyBPW(mode, searchName, searchCatId, page)
  else   : url = self.VVKQrz(mode, catID, page)
  res, err = self.VVc0lf(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVUddQ(CC1B0Q.VVrKuD(item, "total_items" ))
     max_page_items = self.VVUddQ(CC1B0Q.VVrKuD(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC1B0Q.VVrKuD(item, "id"    )
      name   = CC1B0Q.VVrKuD(item, "name"   )
      o_name   = CC1B0Q.VVrKuD(item, "o_name"   )
      category_id  = CC1B0Q.VVrKuD(item, "category_id" )
      tv_genre_id  = CC1B0Q.VVrKuD(item, "tv_genre_id" )
      number   = CC1B0Q.VVrKuD(item, "number"   ) or str(counter)
      logo   = CC1B0Q.VVrKuD(item, "logo"   )
      screenshot_uri = CC1B0Q.VVrKuD(item, "screenshot_uri" )
      pic    = CC1B0Q.VVrKuD(item, "pic"   )
      cmd    = CC1B0Q.VVrKuD(item, "cmd"   )
      censored  = CC1B0Q.VVrKuD(item, "censored"  )
      genres_str  = CC1B0Q.VVrKuD(item, "genres_str"  )
      curPlay   = CC1B0Q.VVrKuD(item, "cur_playing" )
      actors   = CC1B0Q.VVrKuD(item, "actors"   )
      descr   = CC1B0Q.VVrKuD(item, "description" )
      director  = CC1B0Q.VVrKuD(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFTNiH(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVkL6K + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVYUsJ(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVUddQ(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVNSPp(self, mode, VVt27A, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVayQj(mode, colList)
  refCode, chUrl = self.VVGEc1(self.VVkL6K, self.VVPcbV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVMzzc(chName):
   FFAM12(VVt27A, "This is a marker!", 300)
  else:
   FF0GsP(VVt27A, BF(self.VVFiSR, mode, VVt27A, chUrl), title="Playing ...")
 def VVFiSR(self, mode, VVt27A, chUrl):
  FFHFXk(self, chUrl, VVLARq=False)
  CCLDrN.VVLpPr(self.session, iptvTableParams=(self, VVt27A, mode))
 def VVRO9E(self, mode, VVt27A, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVayQj(mode, colList)
  refCode, chUrl = self.VVGEc1(self.VVkL6K, self.VVPcbV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVayQj(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV06qX(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VV8kKb = []
    VV8kKb.append((title        , "inst" ))
    VV8kKb.append(("Update Packages then %s" % title , "updInst" ))
    FFHAbB(SELF, BF(CCVrap.VVd9Qw, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VV8kKb=VV8kKb)
   return False
 @staticmethod
 def VVd9Qw(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFYQcS(VV1Lhp, "")
   if cmdUpd:
    cmdInst = FFMlY4(VVcIUq, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFSEeb(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVOc3A=cbFnc)
   else:
    FFUrcP(SELF)
 def VVI4iA(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVPuS3(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVdifZ(self, VVNmGv):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVI4iA()
  if all((curMode, curHost, curCat)) and curHost == self.VVkL6K:
   VVNmGv.VVCb6L({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVapT7(self, mode, VVt27A, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVI4iA()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVkL6K:
   VVt27A.VV95eY({1:curCat})
 def VVdxhh(self, mode, isEp, VVt27A, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVI4iA()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVkL6K:
   if mode in ("itv", "vod"):
    VVt27A.VV95eY({2:curStID})
   else: #series
    if isEp:
     VVt27A.VV95eY({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVt27A.VV95eY({2:ser2})
     if not ok: VVt27A.VV95eY({2:ser1})
class CC1B0Q(Screen, CCVrap, CC87TJ, CC6Npm):
 VVxjOW    = 0
 VV5ZA6    = 1
 VVer10    = 2
 VVLKh9    = 3
 VVghSE     = 4
 VVJeXQ     = 5
 VVCpII     = 6
 VVyqWJ     = 7
 VV7EqX     = 8
 VV89ly     = 9
 VV2Uqb      = 10
 VVMFKB     = 11
 VVJaar     = 12
 VVUCr3     = 13
 VV9DoB     = 14
 VVijxo      = 15
 VVvI0o      = 16
 VV4osq      = 17
 VVjDAC      = 18
 VVc4xV      = 19
 VVoHMc    = 0
 VV516e   = 1
 VV2CzX   = 2
 VVx5gl   = 3
 VVAU2I  = 4
 VVeuMU  = 5
 VVxweg   = 6
 VVqv2O   = 7
 VV7UCG  = 8
 VVSV9f  = 9
 VVozSO  = 10
 VVEnEf = 0
 VVaZTM = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFpC8B(VVX871, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVt27A    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVrqFLData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CC1B0Q.VVqr8J(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCVrap.__init__(self)
  CC87TJ.__init__(self)
  VV8kKb = self.VVQ8GC()
  FF74S2(self, title="IPTV", VV8kKb=VV8kKb)
  self["myActionMap"].actions.update({
   "menu" : self.VVi8mO
  })
  self["myMenu"].onSelectionChanged.append(self.VVGfG3)
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
  global VVJGEX
  VVJGEX = True
 def VVHrlo(self):
  self["myMenu"].setList(self.VVQ8GC())
  FF1hGr(self)
  FFgqCi(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFl94Z(self["myMenu"])
   FFEBbG(self)
   if self.m3uOrM3u8File:
    self.VVuqlU(self.m3uOrM3u8File)
   else:
    self.VV5ftf()
 def VV5ftf(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  global VVJGEX
  del VVJGEX
 def VVGfG3(self):
  if self["myMenu"].getCurrent()[1] in ("VVjXAL", "VVJ2DqPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVi8mO(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVJ2DqPortal" : confItem = CFG.favServerPortal
   elif item == "VVjXAL" : confItem = CFG.favServerPlaylist
   else         : return
   FFo32K(self, BF(self.VVPCXz, confItem), 'Remove from menu ?', title=title)
 def VVPCXz(self, confItem):
  FFaoHf(confItem, "")
  self.VVHrlo()
 def VVQ8GC(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VV4d6Z
  VV8kKb = []
  if isFav1: VV8kKb.append((c +  "Favourite Playlist Server"   , "VVjXAL" ))
  if isFav2: VV8kKb.append((c +  "Favourite Portal Server"    , "VVJ2DqPortal" ))
  VV8kKb.append(("IPTV Server Browser (from Playlists)"     , "VVrqFL_fromPlayList" ))
  VV8kKb.append(("IPTV Server Browser (from Portal List)"    , "VVrqFL_fromMac"  ))
  VV8kKb.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVrqFL_fromM3u"  ))
  qUrl, iptvRef = CC1B0Q.VVHLAZ(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VV8kKb.append(FF4UJX("IPTV Server Browser (from Current Channel)", "VVrqFL_fromCurrChan", fromCurCond))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("M3U/M3U8 File Browser"        , "VVSUZ3"   ))
  if self.iptvFileAvailable:
   VV8kKb.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(FF4UJX("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VV8kKb.append(FF4UJX("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VV8kKb.append(VVnK97)
   c1, c2 = VVLAFW, VVSFOM
   t1 = FF7kJS("auto-match names", VV4d6Z)
   t2 = FF7kJS("from xml file"  , VV4d6Z)
   VV8kKb.append((c1 + "Count Available IPTV Channels"    , "VVFe6X"    ))
   VV8kKb.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VV8kKb.append(VVnK97)
   VV8kKb.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VV8kKb.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVeAmw" ))
   VV8kKb.append((VVvkGK + "More Reference Tools ..."  , "VVENIq"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Reload Channels and Bouquets"       , "VV53C5"   ))
  VV8kKb.append(VVnK97)
  if not CCnvmH.VVMkdN():
   VV8kKb.append(("Download Manager"         , "dload_stat"    ))
  else:
   VV8kKb.append(("Download Manager ... No downloads"    ,       ))
  return VV8kKb
 def VVZ0gv(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VV0kyE"   : self.VV0kyE()
   elif item == "VVfm8r" : FFo32K(self, self.VVfm8r, "Change Current List References to Unique Codes ?")
   elif item == "VVA5tX_rows" : FFo32K(self, BF(FF0GsP, self.VVt27A, self.VVA5tX), "Change Current List References to Identical Codes ?")
   elif item == "VVlAfk"   : self.VVlAfk(tTitle)
   elif item == "VVxN98"   : self.VVxN98(tTitle)
   elif item == "VVjXAL" : self.VVJ2Dq(False)
   elif item == "VVJ2DqPortal" : self.VVJ2Dq(True)
   elif item == "VVrqFL_fromPlayList" : FF0GsP(self, BF(self.VVNqX4, 1), title=title)
   elif item == "VVrqFL_fromM3u"  : FF0GsP(self, BF(self.VVjGpm, CC1B0Q.VVEnEf), title=title)
   elif item == "VVrqFL_fromMac"  : self.VVypwB()
   elif item == "VVrqFL_fromCurrChan" : self.VVp1nC()
   elif item == "VVSUZ3"   : self.VVSUZ3()
   elif item == "iptvTable_all"   : FF0GsP(self, BF(self.VVZBrO, self.VVxjOW), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CC1B0Q.VV1D30(self)
   elif item == "refreshIptvPicons"  : self.VVzVBh()
   elif item == "VVFe6X"    : FF0GsP(self, self.VVFe6X)
   elif item == "copyEpgPicons"   : self.VV35ad(False)
   elif item == "renumIptvRef_fromFile" : self.VV35ad(True)
   elif item == "VVeAmw" : FFo32K(self, BF(FF0GsP, self, self.VVeAmw), VVzpP3="Continue ?")
   elif item == "VVENIq"    : self.VVENIq()
   elif item == "VV53C5"   : FF0GsP(self, BF(CCGJtF.VV53C5, self))
   elif item == "dload_stat"    : CCnvmH.VVTfM5(self)
 def VVSUZ3(self):
  if CCVrap.VV06qX(self):
   FF0GsP(self, BF(self.VVjGpm, CC1B0Q.VVaZTM), title="Searching ...")
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVZ0gv(item)
 def VVZBrO(self, mode):
  VVDb2Q = self.VVn0Ve(mode)
  if VVDb2Q:
   VVaq9G = ("Current Service", self.VV0g34 , [])
   VV9CSs = ("Options"  , self.VVTmNF   , [])
   VVTO3h = ("Filter"   , self.VVw0Kd   , [])
   VVt6tD  = ("Play"   , BF(self.VVyH0z)  , [])
   VVk5TH = (""    , self.VVmBQx    , [])
   VVZApD = (""    , self.VVSYqO     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVmBED  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFyZJ5(self, None, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26
     , VVt6tD=VVt6tD, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVk5TH=VVk5TH, VVZApD=VVZApD
     , VVuGSD="#0a00292B", VVO7CL="#0a002126", VV2ftx="#0a002126", VVgjmd="#00000000", VV2v46=True, searchCol=1)
  else:
   if mode == self.VV89ly: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFrj68(self, err)
 def VVSYqO(self, VVt27A, title, txt, colList):
  self.VVt27A = VVt27A
 def VVTmNF(self, VVt27A, title, txt, colList):
  VV8kKb = []
  VV8kKb.append(("Add Current List to a New Bouquet"    , "VV0kyE"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change Current List References to Unique Codes" , "VVfm8r"))
  VV8kKb.append(("Change Current List References to Identical Codes", "VVA5tX_rows" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Share Reference with DVB Service (manual entry)" , "VVlAfk"   ))
  VV8kKb.append(("Share Reference with DVB Service (auto-find)"  , "VVxN98"   ))
  FFHAbB(self, self.VVZ0gv, title="IPTV Tools", VV8kKb=VV8kKb)
 def VVw0Kd(self, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VV1AU7, VVt27A))
 def VV1AU7(self, VVt27A):
  VV8kKb = []
  VV8kKb.append(("All"         , "all"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Prefix of Selected Channel"   , "sameName" ))
  VV8kKb.append(("Suggest Words from Selected Channel" , "partName" ))
  VV8kKb.append(("Names with Non-English Characters" , "nonEnglish" ))
  VV8kKb.append(("Duplicate References"     , "depRef"  ))
  VV8kKb.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VV8kKb.append(("Stream Relay"       , "SRelay"  ))
  VV8kKb.append(FFDGmo("Category"))
  VV8kKb.append(("Live TV"        , "live"  ))
  VV8kKb.append(("VOD"         , "vod"   ))
  VV8kKb.append(("Series"        , "series"  ))
  VV8kKb.append(("Uncategorised"      , "uncat"  ))
  VV8kKb.append(FFDGmo("Media"))
  VV8kKb.append(("Video"        , "video"  ))
  VV8kKb.append(("Audio"        , "audio"  ))
  VV8kKb.append(FFDGmo("File Type"))
  VV8kKb.append(("MKV"         , "MKV"   ))
  VV8kKb.append(("MP4"         , "MP4"   ))
  VV8kKb.append(("MP3"         , "MP3"   ))
  VV8kKb.append(("AVI"         , "AVI"   ))
  VV8kKb.append(("FLV"         , "FLV"   ))
  VV8kKb.extend(CCQo5X.VVgD5I(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VV0EdZ, VVt27A) if VVt27A.VVp4FO().startswith("IPTV Filter ") else None
  filterObj = CCkJDN(self)
  filterObj.VVjxij(VV8kKb, VV8kKb, BF(self.VV0bKE, VVt27A, False), inFilterFnc=inFilterFnc)
 def VV0EdZ(self, VVt27A, VVNmGv, item):
  self.VV0bKE(VVt27A, True, item)
 def VV0bKE(self, VVt27A, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVt27A.VVIciO(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVxjOW , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV5ZA6 , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVer10 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVLKh9 , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVCpII  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVyqWJ  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VV7EqX  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VV89ly  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV2Uqb   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVMFKB  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVJaar  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVUCr3  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV9DoB  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVijxo   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVvI0o   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV4osq   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVjDAC   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVc4xV   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVghSE  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVJeXQ  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVer10:
   VV8kKb = []
   chName = VVt27A.VVIciO(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VV8kKb.append((item, item))
    if not VV8kKb and chName:
     VV8kKb.append((chName, chName))
    FFHAbB(self, BF(self.VVQ3YN, title), title="Words from Current Selection", VV8kKb=VV8kKb)
   else:
    VVt27A.VVq4Rc("Invalid Channel Name")
  else:
   words, asPrefix = CCkJDN.VVN7mE(words)
   if not words and mode in (self.VVghSE, self.VVJeXQ):
    FFAM12(self.VVt27A, "Incorrect filter", 2000)
   else:
    FF0GsP(self.VVt27A, BF(self.VVttAD, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVQ3YN(self, title, word=None):
  if word:
   words = [word.lower()]
   FF0GsP(self.VVt27A, BF(self.VVttAD, self.VVer10, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVJ1nD(txt):
  return "#f#11ffff00#" + txt
 def VVttAD(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVDb2Q = self.VVrVF9(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVDb2Q = self.VVn0Ve(mode=mode, words=words, asPrefix=asPrefix)
  if VVDb2Q : self.VVt27A.VVByC5(VVDb2Q, title)
  else  : self.VVt27A.VVq4Rc("Not found")
 def VVrVF9(self, mode=0, words=None, asPrefix=False):
  VVDb2Q = []
  for row in self.VVt27A.VVXwRB():
   row = list(map(str.strip, row))
   chNum, chName, VVHVrB, chType, refCode, url = row
   if self.VVEA3m(mode, refCode, FFD0Hz(url).lower(), chName, words, VVHVrB.lower(), asPrefix):
    VVDb2Q.append(row)
  VVDb2Q = self.VV65wq(mode, VVDb2Q)
  return VVDb2Q
 def VVn0Ve(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVDb2Q = []
  files = CC1B0Q.VVqr8J()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFQByV(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVHVrB = span.group(1)
    else : VVHVrB = ""
    VVHVrB_lCase = VVHVrB.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVMzzc(chName): chNameMod = self.VVJ1nD(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVHVrB, chType + (" SRel" if FFIkRt(url) else ""), refCode, url)
     if self.VVEA3m(mode, refCode, FFD0Hz(url).lower(), chName, words, VVHVrB_lCase, asPrefix):
      VVDb2Q.append(row)
      chNum += 1
  VVDb2Q = self.VV65wq(mode, VVDb2Q)
  return VVDb2Q
 def VV65wq(self, mode, VVDb2Q):
  newRows = []
  if VVDb2Q and mode == self.VVCpII:
   counted  = iCounter(elem[4] for elem in VVDb2Q)
   for item in VVDb2Q:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVDb2Q
 def VVEA3m(self, mode, refCode, tUrl, chName, words, VVHVrB_lCase, asPrefix):
  if   mode == self.VVxjOW : return True
  elif mode == self.VVCpII : return True
  elif mode == self.VVyqWJ  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VV7EqX : return FFIkRt(tUrl)
  elif mode == self.VVUCr3  : return CC1B0Q.VVIq7x(tUrl, getAudVid=True) == "vid"
  elif mode == self.VV9DoB  : return CC1B0Q.VVIq7x(tUrl, getAudVid=True) == "aud"
  elif mode == self.VV89ly  : return CC1B0Q.VVIq7x(tUrl, compareType="live")
  elif mode == self.VV2Uqb  : return CC1B0Q.VVIq7x(tUrl, compareType="movie")
  elif mode == self.VVMFKB : return CC1B0Q.VVIq7x(tUrl, compareType="series")
  elif mode == self.VVJaar  : return CC1B0Q.VVIq7x(tUrl, compareType="")
  elif mode == self.VVijxo  : return CC1B0Q.VVIq7x(tUrl, compareExt="mkv")
  elif mode == self.VVvI0o  : return CC1B0Q.VVIq7x(tUrl, compareExt="mp4")
  elif mode == self.VV4osq  : return CC1B0Q.VVIq7x(tUrl, compareExt="mp3")
  elif mode == self.VVjDAC  : return CC1B0Q.VVIq7x(tUrl, compareExt="avi")
  elif mode == self.VVc4xV  : return CC1B0Q.VVIq7x(tUrl, compareExt="flv")
  elif mode == self.VV5ZA6: return chName.lower().startswith(words[0])
  elif mode == self.VVer10: return words[0] in chName.lower()
  elif mode == self.VVLKh9: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVghSE : return words[0] == VVHVrB_lCase
  elif mode == self.VVJeXQ :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VV0kyE(self):
  picker = CCQo5X(self, self.VVt27A, "Add to Bouquet", self.VVkRYL)
 def VVkRYL(self):
  chUrlLst = []
  for row in self.VVt27A.VVXwRB():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVENIq(self):
  t1 = FF7kJS("Bouquet" , VVSFOM)
  t2 = FF7kJS("ALL"  , VVvkGK)
  t3 = FF7kJS("Unique"  , VVLAFW)
  t4 = FF7kJS("Identical" , VV4d6Z)
  VV8kKb = []
  VV8kKb.append((VV30Pd + "Check System Acceptable Reference Types", "VVILF4"))
  VV8kKb.append(FF4UJX("Check Reference Codes Format", "VVsgMS", self.iptvFileAvailable, VV30Pd))
  VV8kKb.append(VVnK97)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VV8kKb.append((txt % t1, "VVPVP5" ))
  VV8kKb.append((txt % t2, "VVd44I_all"  ))
  VV8kKb.append(VVnK97)
  txt = "Change %s References to %s Codes .."
  VV8kKb.append((txt % (t1, t3), "VVz9TK" ))
  VV8kKb.append((txt % (t2, t3), "VVgYC7"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change %s References to %s Codes" % (t2, t4) , "VVA5tX_all"))
  VVodvg = self.VV950s
  FFHAbB(self, None, width=1150, title="IPTV Reference Tools", VV8kKb=VV8kKb, VVodvg=VVodvg, VVuGSD="#22002233", VVO7CL="#22001122")
 def VV950s(self, item=None):
  if item:
   ques = "Continue ?"
   VVNmGv, txt, item, ndx = item
   if   item == "VVILF4"    : FF0GsP(VVNmGv, self.VVILF4)
   elif item == "VVsgMS"     : FF0GsP(VVNmGv, self.VVsgMS)
   elif item == "VVPVP5" : self.VVgojm(VVNmGv, self.VV1jaY)
   elif item == "VVd44I_all"  : self.VV1jaY(VVNmGv, None, None)
   elif item == "VVz9TK" : self.VVz9TK(VVNmGv, txt)
   elif item == "VVgYC7"  : FFo32K(self, BF(self.VVgYC7 , VVNmGv, txt), title=txt, VVzpP3=ques)
   elif item == "VVA5tX_all"  : FFo32K(self, BF(FF0GsP, VVNmGv, self.VVA5tX), title=txt, VVzpP3=ques)
 def VV1jaY(self, VVNmGv, bName, bPath):
  VV8kKb = []
  for rt in CC1B0Q.VVS2HJ():
   VV8kKb.append(("%s\t ... %s" % (rt, CC1B0Q.VVcYNm(rt)), rt))
  FFHAbB(self, BF(self.VVFFtf, VVNmGv, bName, bPath), VV8kKb=VV8kKb, width=800, title="Change Reference Types to:")
 def VVFFtf(self, VVNmGv, bName, bPath, rType=None):
  if rType:
   self.VVU3K6(VVNmGv, bName, bPath, rType)
 def VVgojm(self, VVNmGv, fnc):
  VV8kKb = CCQo5X.VVgD5I()
  if VV8kKb:
   FFHAbB(self, BF(self.VVFsIj, VVNmGv, fnc), VV8kKb=VV8kKb, title="IPTV Bouquets", VVPYdF=True)
  else:
   FFAM12(VVNmGv, "No bouquets Found !", 1500)
 def VVFsIj(self, VVNmGv, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVORe1 + span.group(1)
    if fileExists(bPath): fnc(VVNmGv, bName, bPath)
    else    : FFAM12(VVNmGv, "Bouquet file not found!", 2000)
   else:
    FFAM12(VVNmGv, "Cannot process bouquet !", 2000)
 def VVU3K6(self, VVNmGv, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FF7kJS(bName, VV691Y)
  else : title = "Change for %s" % FF7kJS("All IPTV Services", VV691Y)
  FFo32K(self, BF(FF0GsP, VVNmGv, BF(self.VV8Dfw, VVNmGv, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FF7kJS(rType, VV691Y), title=title)
 def VV8Dfw(self, VVNmGv, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CC1B0Q.VVqr8J()
  if files:
   newRType = rType + ":"
   piconPath = CCHnG6.VVYipk()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCFric.VV4nww(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFrj68(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFWnHJ("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFWnHJ(cmd)
  self.VVgX8r(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVFe6X(self):
  totFiles = 0
  files  = CC1B0Q.VVqr8J()
  if files:
   totFiles = len(files)
  totChans = 0
  VVDb2Q = self.VVn0Ve()
  if VVDb2Q:
   totChans = len(VVDb2Q)
  FFaIgn(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVsgMS(self):
  files = CC1B0Q.VVqr8J()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFQByV(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVomgc
   else    : color = VVSBcQ
   totInvalid = FF7kJS(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF7kJS("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFaIgn(self, txt, title="Check IPTV References")
 def VVILF4(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CC1B0Q.VVS2HJ()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCQo5X.VVzV4N(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVy0t4 = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVy0t4:
   VVT6RH = FFxPkx(VVy0t4)
   if VVT6RH:
    for service in VVT6RH:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVORe1 + userBName
  bFile = VVORe1 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFhyjZ("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFhyjZ("rm -f '%s'" % path)
  FFWnHJ(cmd)
  FFczPJ()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVomgc
    else     : res, color = "No" , VVSBcQ
    pl = CC1B0Q.VVcYNm(item)
    txt += "    %s\t: %s%s\n" % (item, FF7kJS(res, color), FF7kJS("\t... %s" % pl, VViSml) if pl else "")
   FFaIgn(self, txt, title=title)
  else:
   txt = FFrj68(self, "Could not complete the test on your system!", title=title)
 def VVeAmw(self):
  VVS5P4, err = CCGJtF.VV2Ohl(self, CCGJtF.VVKV7y)
  if VVS5P4:
   totChannels = 0
   totChange = 0
   for path in CC1B0Q.VVqr8J():
    toSave = False
    txt = FFQByV(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVS5P4.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVgX8r(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFrj68(self, 'No channels in "lamedb" !')
 def VVgYC7(self, VVNmGv, title):
  bFiles = CC1B0Q.VVqr8J()
  if bFiles: self.VV465l(bFiles, title)
  else  : FFAM12(VVNmGv, "No bouquets files !", 1500)
 def VVz9TK(self, VVNmGv, title):
  self.VVgojm(VVNmGv, BF(self.VVaWXA, title))
 def VVaWXA(self, title, VVNmGv, bName, bPath):
  self.VV465l([bPath], title)
 def VV465l(self, bFiles, title):
  self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVpmUF, bFiles)
      , VVVnlJ = BF(self.VVeUCx, title))
 def VVpmUF(self, bFiles, VVtEPC):
  VVtEPC.VVsc2i = ""
  VVtEPC.VVLHBp("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFKcIu(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVtEPC or VVtEPC.isCancelled:
   return
  elif not totLines:
   VVtEPC.VVsc2i = "No IPTV Services !"
   return
  else:
   VVtEPC.VVodiL(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVtEPC or VVtEPC.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFKcIu(path)
    for ndx, line in enumerate(lines):
     if not VVtEPC or VVtEPC.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVtEPC:
       VVtEPC.VVLHBp("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVtEPC:
       VVtEPC.VV2Wgw(1)
      refCode, startId, startNS = CCQo5X.VVuoml(rType, CCQo5X.VVVfI0, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVtEPC:
        VVtEPC.VVsc2i = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVeUCx(self, title, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVsc2i:
   txt += "\n\n%s\n%s" % (FF7kJS("Ended with Error:", VVSBcQ), VVsc2i)
  self.VVgX8r(True, title, txt)
 def VVfm8r(self):
  bFiles = CC1B0Q.VVqr8J()
  if not bFiles:
   FFAM12(self.VVt27A, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVt27A.VVXwRB():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFAM12(self.VVt27A, "Cannot read list", 1500)
   return
  self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVsQma, bFiles, tableRefList)
      , VVVnlJ = BF(self.VVeUCx, "Change Current List References to Unique Codes"))
 def VVsQma(self, bFiles, tableRefList, VVtEPC):
  VVtEPC.VVsc2i = ""
  VVtEPC.VVLHBp("Reading System References ...")
  refLst = CCQo5X.VVGzwx(CCQo5X.VVVfI0, stripRType=True)
  if not VVtEPC or VVtEPC.isCancelled:
   return
  VVtEPC.VVodiL(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVtEPC or VVtEPC.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFQByV(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVtEPC or VVtEPC.isCancelled:
     return
    VVtEPC.VVLHBp("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVtEPC or VVtEPC.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVtEPC.VV2Wgw(1)
      refCode, startId, startNS = CCQo5X.VVuoml(rType, CCQo5X.VVVfI0, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVtEPC:
        VVtEPC.VVsc2i = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVA5tX(self):
  list = None
  if self.VVt27A:
   list = []
   for row in self.VVt27A.VVXwRB():
    list.append(row[4] + row[5])
  files = CC1B0Q.VVqr8J()
  totChange = 0
  if files:
   for path in files:
    lines = FFKcIu(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVgX8r(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVgX8r(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFczPJ()
   if refreshTable and self.VVt27A:
    VVDb2Q = self.VVn0Ve()
    if VVDb2Q and self.VVt27A:
     self.VVt27A.VVByC5(VVDb2Q, self.tableTitle)
     self.VVt27A.VVq4Rc(txt)
   FFaIgn(self, txt, title=title)
  else:
   FF9glI(self, "No changes.")
 @staticmethod
 def VVqr8J(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVORe1 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFQByV(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVmBQx(self, VVt27A, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFD0Hz(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFjcFt(self, fncMode=CCOQON.VVOM7g, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVoJPh(self, VVt27A, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVyH0z(self, VVt27A, title, txt, colList):
  chName, chUrl = self.VVoJPh(VVt27A, colList)
  self.VV6G0u(VVt27A, chName, chUrl, "localIptv")
 def VVCQiA(self, mode, VVt27A, colList):
  chName, chUrl, picUrl, refCode = self.VVgJHK(mode, colList)
  return chName, chUrl
 def VVLNgq(self, mode, VVt27A, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVgJHK(mode, colList)
  self.VV6G0u(VVt27A, chName, chUrl, mode)
 def VV6G0u(self, VVt27A, chName, chUrl, playerFlag):
  chName = FFJYbZ(chName)
  if self.VVMzzc(chName):
   FFAM12(VVt27A, "This is a marker!", 300)
  else:
   FF0GsP(VVt27A, BF(self.VV7sA5, VVt27A, chUrl, playerFlag), title="Playing ...")
 def VV7sA5(self, VVt27A, chUrl, playerFlag):
  FFHFXk(self, chUrl, VVLARq=False)
  CCLDrN.VVLpPr(self.session, iptvTableParams=(self, VVt27A, playerFlag))
 @staticmethod
 def VVMzzc(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VV0g34(self, VVt27A, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  if refCode:
   url1 = FFD0Hz(origUrl.strip())
   for ndx, row in enumerate(VVt27A.VVXwRB()):
    if refCode in row[4]:
     tableRow = FFD0Hz(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVt27A.VVagt1(ndx)
      break
   else:
    FFAM12(VVt27A, "No found", 1000)
 def VVjGpm(self, m3uMode):
  lines = self.VVni8g(3)
  if lines:
   lines.sort()
   VV8kKb = []
   for line in lines:
    VV8kKb.append((line, line))
   if m3uMode == CC1B0Q.VVEnEf:
    title = "Browse Server from M3U URLs"
    VVcx0D = ("All to Playlist", self.VVsyTV)
   else:
    title = "M3U/M3U8 File Browser"
    VVcx0D = None
   VVodvg = BF(self.VV4Ia1, m3uMode, title)
   VVM6M9 = self.VVarmy
   FFHAbB(self, None, title=title, VV8kKb=VV8kKb, width=1200, VVodvg=VVodvg, VVM6M9=VVM6M9, VVj7dk="", VVcx0D=VVcx0D, VVuGSD="#11221122", VVO7CL="#11221122")
 def VV4Ia1(self, m3uMode, title, item=None):
  if item:
   VVNmGv, txt, path, ndx = item
   if m3uMode == CC1B0Q.VVEnEf:
    FF0GsP(VVNmGv, BF(self.VVfXjg, title, path))
   else:
    FF0GsP(VVNmGv, BF(self.VVuqlU, path))
 def VVuqlU(self, path, m3uFilterParam=None, VVt27A=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFQByV(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVN2j4(propLine, "group-title") or "-"
   if not group == "-" and self.VVzO98(group):
    if not chName or self.VVYUsJ(chName):
     if self.VVEA3m(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVDb2Q = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVDb2Q.append((name, str(tot), name))
    totAll += tot
   VVDb2Q.sort(key=lambda x: x[0].lower())
   VVDb2Q.insert(0, ("ALL", str(totAll), ""))
  if VVDb2Q:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVt27A:
    VVt27A.VVByC5(VVDb2Q, newTitle=title, VV78xZMsg=True)
   else:
    VVqFCi = self.VVnVZU
    VVt6tD  = ("Select" , BF(self.VVHmWb, path, m3uFilterParam)  , [])
    VVTO3h = ("Filter" , BF(self.VVnVoF, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVmBED  = (LEFT  , CENTER , LEFT )
    FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, width= 1400, height= 1000, VVC5IT=28, VVt6tD=VVt6tD, VVTO3h=VVTO3h, VVqFCi=VVqFCi, lastFindConfigObj=CFG.lastFindIptv
      , VVuGSD="#11110022", VVO7CL="#11110022", VV2ftx="#11110022", VVgjmd="#00444400")
  elif VVt27A:
   FFIZWt(VVt27A, "Not found !", 1500)
  else:
   self.VV4VUd(FFQByV(path), "", m3uFilterParam)
 def VVHmWb(self, path, m3uFilterParam, VVt27A, title, txt, colList):
  self.VV4VUd(FFQByV(path), colList[2], m3uFilterParam)
 def VVnVoF(self, path, m3uFilterParam, VVt27A, title, txt, colList):
  VV8kKb = []
  VV8kKb.append(("All"      , "all"  ))
  VV8kKb.append(FFDGmo("Category"))
  VV8kKb.append(("Live TV"     , "live" ))
  VV8kKb.append(("VOD"      , "vod"  ))
  VV8kKb.append(("Series"     , "series" ))
  VV8kKb.append(("Uncategorised"   , "uncat" ))
  VV8kKb.append(FFDGmo("Media"))
  VV8kKb.append(("Video"     , "video" ))
  VV8kKb.append(("Audio"     , "audio" ))
  VV8kKb.append(FFDGmo("File Type"))
  VV8kKb.append(("MKV"      , "MKV"  ))
  VV8kKb.append(("MP4"      , "MP4"  ))
  VV8kKb.append(("MP3"      , "MP3"  ))
  VV8kKb.append(("AVI"      , "AVI"  ))
  VV8kKb.append(("FLV"      , "FLV"  ))
  filterObj = CCkJDN(self, VVuGSD="#11332244", VVO7CL="#11222244")
  filterObj.VVjxij(VV8kKb, [], BF(self.VVFd6i, VVt27A, path), inFilterFnc=None)
 def VVFd6i(self, VVt27A, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVxjOW , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VV89ly  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VV2Uqb  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVMFKB  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVJaar  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVUCr3  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VV9DoB  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVijxo  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVvI0o  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VV4osq  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVjDAC  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVc4xV  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVJeXQ  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCkJDN.VVN7mE(words)
   if not mode == self.VVxjOW:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FF7kJS(fTitle, VViSml)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FF0GsP(VVt27A, BF(self.VVuqlU, path, m3uFilterParam, VVt27A), title="Filtering ...")
 def VV4VUd(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCfhQr, barTheme=CCfhQr.VVZYJm
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVKqWI, lst, filterGroup, m3uFilterParam)
       , VVVnlJ = BF(self.VVlYtb, title, bName))
  else:
   self.VVOB9W("No valid lines found !", title)
 def VVKqWI(self, lst, filterGroup, m3uFilterParam, VVtEPC):
  VVtEPC.VVsc2i = []
  VVtEPC.VVodiL(len(lst))
  num = 0
  for cols in lst:
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VV2Wgw(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVN2j4(propLine, "group-title") or "-"
   picon = self.VVN2j4(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVzO98(group) : skip = True
    elif chName and not self.VVYUsJ(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVEA3m(mode, "", FFD0Hz(url).lower(), chName, words, "", asPrefix)
    if not skip and VVtEPC:
     num += 1
     VVtEPC.VVsc2i.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVlYtb(self, title, bName, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if VVsc2i:
   VVqFCi = self.VVnVZU
   VVt6tD  = ("Select"   , BF(self.VVCs6x, title)   , [])
   VVk5TH = (""    , self.VVy3xE        , [])
   VVaq9G = ("Download PIcons", self.VVC4J7       , [])
   VV9CSs = ("Options"  , BF(self.VV3T1Q, "m3Ch", "", bName) , [])
   VVTO3h = ("Posters Mode" , BF(self.VV1LUN, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVmBED  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVsc2i, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, VVt6tD=VVt6tD, VVqFCi=VVqFCi, VVk5TH=VVk5TH, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindIptv, VV2v46=True, searchCol=1
     , VVuGSD="#0a00192B", VVO7CL="#0a00192B", VV2ftx="#0a00192B", VVgjmd="#00000000")
  else:
   self.VVOB9W("Not found !", title)
 def VVC4J7(self, VVt27A, title, txt, colList):
  self.VVBaHf(VVt27A, "m3u/m3u8")
 def VV4rx8(self, rowNum, url, chName):
  refCode = self.VVYgrb(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFw8K0(url), chName)
  return chUrl
 def VVYgrb(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VV2QBX(catID, stID, chNum)
  return refCode
 def VVN2j4(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVCs6x(self, Title, VVt27A, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF0GsP(VVt27A, BF(self.VVVzrQ, Title, VVt27A, colList), title="Checking Server ...")
  else:
   self.VVLsZ8(VVt27A, url, chName)
 def VVVzrQ(self, title, VVt27A, colList):
  if not CCVrap.VV06qX(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCXeC7.VVtmW3(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VV8kKb = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC1B0Q.VVBFii(url, fPath)
     VV8kKb.append((resol, fullUrl))
    if VV8kKb:
     if len(VV8kKb) > 1:
      FFHAbB(self, BF(self.VVFapf, VVt27A, chName), VV8kKb=VV8kKb, title="Resolution", VVPYdF=True, VVWQ3x=True)
     else:
      self.VVLsZ8(VVt27A, VV8kKb[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVLsZ8(VVt27A, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CC1B0Q.VVBFii(url, span.group(1))
       self.VVLsZ8(VVt27A, fullUrl, chName)
      else:
       self.VVwaVA("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV4VUd(txt, filterGroup="")
      return
    self.VVLsZ8(VVt27A, url, chName)
   else:
    self.VVOB9W("Cannot process this channel !", title)
  else:
   self.VVOB9W(err, title)
 def VVFapf(self, VVt27A, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVLsZ8(VVt27A, resolUrl, chName)
 def VVLsZ8(self, VVt27A, url, chName):
  FF0GsP(VVt27A, BF(self.VVnIt8, VVt27A, url, chName), title="Playing ...")
 def VVnIt8(self, VVt27A, url, chName):
  chUrl = self.VV4rx8(VVt27A.VV2fe8(), url, chName)
  FFHFXk(self, chUrl, VVLARq=False)
  CCLDrN.VVLpPr(self.session, iptvTableParams=(self, VVt27A, "m3u/m3u8"))
 def VVxkU8(self, VVt27A, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV4rx8(VVt27A.VV2fe8(), url, chName)
  return chName, chUrl
 def VVy3xE(self, VVt27A, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFjcFt(self, fncMode=CCOQON.VVOM7g, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVOB9W(self, err, title):
  FFrj68(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVnVZU(self, VVt27A):
  if self.m3uOrM3u8File:
   self.close()
  VVt27A.cancel()
 def VVsyTV(self, VV476KObj, item=None):
  FF0GsP(VV476KObj, BF(self.VV2Oec, VV476KObj, item))
 def VV2Oec(self, VV476KObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VV476KObj.VV8kKb):
    path = item[1]
    if fileExists(path):
     enc = CCP2t1.VVhvNn(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CC1B0Q.VVBjTh(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC1B0Q.VVIBms()
    pListF = "%sPlaylist_%s.txt" % (path, FFC2jX())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VV476KObj.VV8kKb)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFaIgn(self, txt, title=title)
   else:
    FFrj68(self, "Could not obtain URLs from this file list !", title=title)
 def VVNqX4(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVD7oy
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVda0x
  lines = self.VVni8g(mode)
  if lines:
   lines.sort()
   VV8kKb = []
   for line in lines:
    VV8kKb.append((FF7kJS(line, VVSFOM) if "Bookmarks" in line else line, line))
   VVM6M9 = self.VVarmy
   FFHAbB(self, None, title=title, VV8kKb=VV8kKb, width=1200, VVodvg=okFnc, VVM6M9=VVM6M9, VVj7dk="")
 def VVarmy(self, VVNmGv, txt, ref, ndx):
  txt = ref
  sz = FF7PcS(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCFric.VVgYti(sz)
  FFaIgn(self, txt, title="File Path")
 def VVD7oy(self, item=None):
  if item:
   VVNmGv, txt, path, ndx = item
   FF0GsP(VVNmGv, BF(self.VVARb1, VVNmGv, path), title="Processing File ...")
 def VVARb1(self, VVBid9, path):
  enc = CCP2t1.VVhvNn(path, self)
  if enc == -1:
   return
  VVDb2Q = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFxiJi(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC1B0Q.VVlkd2(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVDb2Q:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVDb2Q.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVDb2Q:
   title = "Playlist File : %s" % os.path.basename(path)
   VVt6tD  = ("Start"    , BF(self.VVUNxL, "Playlist File")      , [])
   VVOFQa = ("Home Menu"   , FFKSrd             , [])
   VVaq9G = ("Download M3U File" , self.VVaGDB         , [])
   VV9CSs = ("Edit File"   , BF(self.VVb3Ie, path)        , [])
   VVTO3h = ("Check & Filter"  , BF(self.VVvOYe, VVBid9, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVmBED  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVOFQa=VVOFQa, VVTO3h=VVTO3h, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVuGSD="#11001116", VVO7CL="#11001116", VV2ftx="#11001116", VVgjmd="#00003635", VVZ0ud="#0a333333", VVGQoh="#11331100", VV2v46=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFrj68(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVaGDB(self, VVt27A, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFo32K(self, BF(FF0GsP, VVt27A, BF(self.VVSY1F, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVSY1F(self, title, url):
  path, err = FFadHO(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFrj68(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFQByV(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFfIuR(path)
    FFrj68(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFfIuR(path)
    FFrj68(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC1B0Q.VVIBms() + fName
    FFWnHJ("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FF9glI(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFrj68(self, "Could not download the M3U file!", title=errTitle)
 def VVUNxL(self, Title, VVt27A, title, txt, colList):
  url = colList[6]
  FF0GsP(VVt27A, BF(self.VVNsuO, Title, url), title="Checking Server ...")
 def VVb3Ie(self, path, VVt27A, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCAoYu(self, path, VVVnlJ=BF(self.VVrtHh, VVt27A), curRowNum=rowNum)
  else    : FFiEaB(self, path)
 def VVrtHh(self, VVt27A, fileChanged):
  if fileChanged:
   VVt27A.cancel()
 def VVlAfk(self, title):
  curChName = self.VVt27A.VVIciO(1)
  FFTtos(self, BF(self.VV5tog, title), defaultText=curChName, title=title, message="Enter Name:")
 def VV5tog(self, title, name):
  if name:
   VVS5P4, err = CCGJtF.VV2Ohl(self, CCGJtF.VV6Yt8, VVfYV4=False, VV9iqe=False)
   list = []
   if VVS5P4:
    name = self.VVM385(name)
    ratio = "1"
    for item in VVS5P4:
     if name in item[0].lower():
      list.append((item[0], FFhxEM(item[2]), item[3], ratio))
   if list : self.VV491z(list, title)
   else : FFrj68(self, "Not found:\n\n%s" % name, title=title)
 def VVxN98(self, title):
  curChName = self.VVt27A.VVIciO(1)
  self.session.open(CCfhQr, barTheme=CCfhQr.VVZYJm
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVePOz
      , VVVnlJ = BF(self.VVWlj3, title, curChName))
 def VVePOz(self, VVtEPC):
  curChName = self.VVt27A.VVIciO(1)
  VVS5P4, err = CCGJtF.VV2Ohl(self, CCGJtF.VVgToU, VVfYV4=False, VV9iqe=False)
  if not VVS5P4 or not VVtEPC or VVtEPC.isCancelled:
   return
  VVtEPC.VVsc2i = []
  VVtEPC.VVodiL(len(VVS5P4))
  curCh = self.VVM385(curChName)
  for refCode in VVS5P4:
   chName, sat, inDB = VVS5P4.get(refCode, ("", "", 0))
   ratio = CCHnG6.VV6cgu(chName.lower(), curCh)
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VV2Wgw(1, True)
   if VVtEPC and ratio > 50:
    VVtEPC.VVsc2i.append((chName, FFhxEM(sat), refCode.replace("_", ":"), str(ratio)))
 def VVWlj3(self, title, curChName, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if VVsc2i: self.VV491z(VVsc2i, title)
  elif VVYFmk: FFrj68(self, "No similar names found for:\n\n%s" % curChName, title)
 def VV491z(self, VVDb2Q, title):
  curChName = self.VVt27A.VVIciO(1)
  VV1q1B = self.VVt27A.VVIciO(4)
  curUrl  = self.VVt27A.VVIciO(5)
  VVDb2Q.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVt6tD  = ("Share Sat/C/T Ref.", BF(self.VVtLXt, title, curChName, VV1q1B, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVuGSD="#0a00112B", VVO7CL="#0a001126", VV2ftx="#0a001126", VVgjmd="#00000000")
 def VVtLXt(self, newtitle, curChName, VV1q1B, curUrl, VVt27A, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VV1q1B, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFo32K(self.VVt27A, BF(FF0GsP, self.VVt27A, BF(self.VVoreZ, VVt27A, data)), ques, title=newtitle, VVjDSl=True)
 def VVoreZ(self, VVt27A, data):
  VVt27A.cancel()
  title, curChName, VV1q1B, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VV1q1B = VV1q1B.strip()
  newRefCode = newRefCode.strip()
  if not VV1q1B.endswith(":") : VV1q1B += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VV1q1B, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VV1q1B + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CC1B0Q.VVqr8J():
    txt = FFQByV(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFczPJ()
    newRow = []
    for i in range(6):
     newRow.append(self.VVt27A.VVIciO(i))
    newRow[4] = newRefCode
    done = self.VVt27A.VVtG6o(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FF2Wwv(BF(FF9glI , self, resTxt, title=title))
  elif resErr: FF2Wwv(BF(FFrj68, self, resErr, title=title))
 def VVvOYe(self, VVBid9, path, VVt27A, title, txt, colList):
  self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVWprx, VVt27A)
      , VVVnlJ = BF(self.VVGHGp, VVBid9, path, VVt27A))
 def VVWprx(self, VVt27A, VVtEPC):
  VVtEPC.VVodiL(VVt27A.VVXdnH())
  VVtEPC.VVsc2i = []
  for row in VVt27A.VVXwRB():
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VV2Wgw(1, True)
   qUrl = self.VVeTVE(self.VVoHMc, row[6])
   txt, err = self.VVEaWb(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVrKuD(item, "auth") == "0":
       VVtEPC.VVsc2i.append(qUrl)
    except:
     pass
 def VVGHGp(self, VVBid9, path, VVt27A, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if VVYFmk:
   list = VVsc2i
   title = "Authorized Servers"
   if list:
    totChk = VVt27A.VVXdnH()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFC2jX()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVNqX4(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF7kJS(str(totAuth), VVomgc)
     txt += "%s\n\n%s"    %  (FF7kJS("Result File:", VVSFOM), newPath)
     FFaIgn(self, txt, title=title)
     VVt27A.close()
     VVBid9.close()
    else:
     FF9glI(self, "All URLs are authorized.", title=title)
   else:
    FFrj68(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVEaWb(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVlkd2(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVIq7x(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCz7OO.VVFMqt()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVjANq(decodedUrl):
  return CC1B0Q.VVIq7x(decodedUrl, justRetDotExt=True)
 def VVeTVE(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVlkd2(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVoHMc   : return "%s"            % url
  elif mode == self.VV516e   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV2CzX   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVx5gl  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVAU2I  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVeuMU : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVxweg   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVqv2O    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV7UCG  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVozSO : return "%s&action=get_live_streams"      % url
  elif mode == self.VVSV9f  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVrKuD(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFDwGN(int(val))
    elif is_base64 : val = FFKVqd(val)
    elif isToHHMMSS : val = FFjXk8(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVfXjg(self, title, path):
  if fileExists(path):
   enc = CCP2t1.VVhvNn(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CC1B0Q.VVBjTh(line)
     if qUrl:
      break
   if qUrl : self.VVNsuO(title, qUrl)
   else : FFrj68(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFrj68(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVp1nC(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CC1B0Q.VVHLAZ(self)
  if qUrl or "chCode" in iptvRef:
   p = CCXeC7()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVPuS3(iptvRef)
   if valid:
    self.VV6bO0(self, host, mac)
    return
   elif qUrl:
    FF0GsP(self, BF(self.VVNsuO, title, qUrl), title="Checking Server ...")
    return
  FFrj68(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVHLAZ(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF)
  qUrl = CC1B0Q.VVBjTh(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVBjTh(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVNsuO(self, title, url):
  self.curUrl = url
  self.VVrqFLData = {}
  qUrl = self.VVeTVE(self.VVoHMc, url)
  txt, err = self.VVEaWb(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVrqFLData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVrqFLData["username"    ] = self.VVrKuD(item, "username"        )
    self.VVrqFLData["password"    ] = self.VVrKuD(item, "password"        )
    self.VVrqFLData["message"    ] = self.VVrKuD(item, "message"        )
    self.VVrqFLData["auth"     ] = self.VVrKuD(item, "auth"         )
    self.VVrqFLData["status"    ] = self.VVrKuD(item, "status"        )
    self.VVrqFLData["exp_date"    ] = self.VVrKuD(item, "exp_date"    , isDate=True )
    self.VVrqFLData["is_trial"    ] = self.VVrKuD(item, "is_trial"        )
    self.VVrqFLData["active_cons"   ] = self.VVrKuD(item, "active_cons"       )
    self.VVrqFLData["created_at"   ] = self.VVrKuD(item, "created_at"   , isDate=True )
    self.VVrqFLData["max_connections"  ] = self.VVrKuD(item, "max_connections"      )
    self.VVrqFLData["allowed_output_formats"] = self.VVrKuD(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVrqFLData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVrqFLData["url"    ] = self.VVrKuD(item, "url"        )
    self.VVrqFLData["port"    ] = self.VVrKuD(item, "port"        )
    self.VVrqFLData["https_port"  ] = self.VVrKuD(item, "https_port"      )
    self.VVrqFLData["server_protocol" ] = self.VVrKuD(item, "server_protocol"     )
    self.VVrqFLData["rtmp_port"   ] = self.VVrKuD(item, "rtmp_port"       )
    self.VVrqFLData["timezone"   ] = self.VVrKuD(item, "timezone"       )
    self.VVrqFLData["timestamp_now"  ] = self.VVrKuD(item, "timestamp_now"  , isDate=True )
    self.VVrqFLData["time_now"   ] = self.VVrKuD(item, "time_now"       )
    VV8kKb  = self.VV3FEQ(True)
    VVodvg = self.VV6yEB
    VVM6M9 = self.VVuRBk
    VV1zfK = ("Home Menu", FFKSrd)
    VVinPK= ("Add to Menu", BF(CC1B0Q.VVCMHv, self, False, self.VVrqFLData["playListURL"]))
    VVcx0D = ("Bookmark Server", BF(CC1B0Q.VVMH4x, self, False, self.VVrqFLData["playListURL"]))
    FFHAbB(self, None, title="IPTV Server Resources", VV8kKb=VV8kKb, VVodvg=VVodvg, VVM6M9=VVM6M9, VV1zfK=VV1zfK, VVinPK=VVinPK, VVcx0D=VVcx0D)
   else:
    err = "Could not get data from server !"
  if err:
   FFrj68(self, err, title=title)
  FFAM12(self)
 def VV6yEB(self, item=None):
  if item:
   VVNmGv, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF0GsP(VVNmGv, BF(self.VVUqaR, self.VV516e  , title=title), title=wTxt)
   elif ref == "vod"   : FF0GsP(VVNmGv, BF(self.VVUqaR, self.VV2CzX  , title=title), title=wTxt)
   elif ref == "series"  : FF0GsP(VVNmGv, BF(self.VVUqaR, self.VVx5gl , title=title), title=wTxt)
   elif ref == "catchup"  : FF0GsP(VVNmGv, BF(self.VVUqaR, self.VVAU2I , title=title), title=wTxt)
   elif ref == "accountInfo" : FF0GsP(VVNmGv, BF(self.VViSxa           , title=title), title=wTxt)
 def VVuRBk(self, VVNmGv, txt, ref, ndx):
  FF0GsP(VVNmGv, self.VVaZ0g)
 def VVaZ0g(self):
  txt = self.curUrl
  if VVksGH:
   ver, err = self.VVOsPv(self.VVvLwV())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVkL6K
   txt += "PHP\t: %s\n"  % self.VV33VB
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVUgkP, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFaIgn(self, txt, title="Current Server URL")
 def VViSxa(self, title):
  rows = []
  for key, val in self.VVrqFLData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VV6qBY
   else:
    num, part = "1", self.VV0oW8
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVOFQa  = ("Home Menu", FFKSrd, [])
  VVaq9G  = None
  if VVksGH:
   VVaq9G = ("Get JS" , BF(self.VVf4b6, "/".join(self.VVrqFLData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFyZJ5(self, None, title=title, width=1200, header=header, VVI2kC=rows, VVWFHs=widths, VVC5IT=26, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VVuGSD="#0a00292B", VVO7CL="#0a002126", VV2ftx="#0a002126", VVgjmd="#00000000", searchCol=2)
 def VVB5My(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVxweg, self.VVSV9f):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVrKuD(item, "num"         )
      name     = self.VVrKuD(item, "name"        )
      stream_id    = self.VVrKuD(item, "stream_id"       )
      stream_icon    = self.VVrKuD(item, "stream_icon"       )
      epg_channel_id   = self.VVrKuD(item, "epg_channel_id"      )
      added     = self.VVrKuD(item, "added"    , isDate=True )
      is_adult    = self.VVrKuD(item, "is_adult"       )
      category_id    = self.VVrKuD(item, "category_id"       )
      tv_archive    = self.VVrKuD(item, "tv_archive"       )
      direct_source   = self.VVrKuD(item, "direct_source"      )
      tv_archive_duration  = self.VVrKuD(item, "tv_archive_duration"     )
      name = self.VVYUsJ(name, is_adult)
      if name:
       if mode == self.VVxweg or mode == self.VVSV9f and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVqv2O:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVrKuD(item, "num"         )
      name    = self.VVrKuD(item, "name"        )
      stream_id   = self.VVrKuD(item, "stream_id"       )
      stream_icon   = self.VVrKuD(item, "stream_icon"       )
      added    = self.VVrKuD(item, "added"    , isDate=True )
      is_adult   = self.VVrKuD(item, "is_adult"       )
      category_id   = self.VVrKuD(item, "category_id"       )
      container_extension = self.VVrKuD(item, "container_extension"     ) or "mp4"
      name = self.VVYUsJ(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VV7UCG:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVrKuD(item, "num"        )
      name    = self.VVrKuD(item, "name"       )
      series_id   = self.VVrKuD(item, "series_id"      )
      cover    = self.VVrKuD(item, "cover"       )
      genre    = self.VVrKuD(item, "genre"       )
      episode_run_time = self.VVrKuD(item, "episode_run_time"    )
      category_id   = self.VVrKuD(item, "category_id"      )
      container_extension = self.VVrKuD(item, "container_extension"    ) or "mp4"
      name = self.VVYUsJ(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVUqaR(self, mode, title):
  cList, err = self.VVDZXX(mode)
  if cList and mode == self.VVAU2I:
   cList = self.VVDFjE(cList)
  if err:
   FFrj68(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ(mode)
   mName = self.VV48MQ(mode)
   if   mode == self.VV516e  : fMode = self.VVxweg
   elif mode == self.VV2CzX  : fMode = self.VVqv2O
   elif mode == self.VVx5gl : fMode = self.VV7UCG
   elif mode == self.VVAU2I : fMode = self.VVSV9f
   if mode == self.VVAU2I:
    VV9CSs = None
    VVTO3h = None
   else:
    VV9CSs = ("Find in %s" % mName , BF(self.VVzloc, fMode, True) , [])
    VVTO3h = ("Find in Selected" , BF(self.VVzloc, fMode, False) , [])
   VVt6tD   = ("Show List"   , BF(self.VVohJz, mode)  , [])
   VVOFQa  = ("Home Menu"   , FFKSrd         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFyZJ5(self, None, title=title, width=1200, header=header, VVI2kC=cList, VVWFHs=widths, VVC5IT=30, VVOFQa=VVOFQa, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVt6tD=VVt6tD, VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VV2ftx, VVgjmd=VVgjmd, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFrj68(self, "No list from server !", title=title)
  FFAM12(self)
 def VVDZXX(self, mode):
  qUrl  = self.VVeTVE(mode, self.VVrqFLData["playListURL"])
  txt, err = self.VVEaWb(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVrKuD(item, "category_id"  )
     category_name = self.VVrKuD(item, "category_name" )
     parent_id  = self.VVrKuD(item, "parent_id"  )
     category_name = self.VVzO98(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVDFjE(self, catList):
  mode  = self.VVSV9f
  qUrl  = self.VVeTVE(mode, self.VVrqFLData["playListURL"])
  txt, err = self.VVEaWb(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVB5My(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVohJz(self, mode, VVt27A, title, txt, colList):
  title = colList[1]
  FF0GsP(VVt27A, BF(self.VVjq2Y, mode, VVt27A, title, txt, colList), title="Downloading ...")
 def VVjq2Y(self, mode, VVt27A, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VV48MQ(mode) + " : "+ bName
  if   mode == self.VV516e  : mode = self.VVxweg
  elif mode == self.VV2CzX  : mode = self.VVqv2O
  elif mode == self.VVx5gl : mode = self.VV7UCG
  elif mode == self.VVAU2I : mode = self.VVSV9f
  qUrl  = self.VVeTVE(mode, self.VVrqFLData["playListURL"], catID)
  txt, err = self.VVEaWb(qUrl)
  list  = []
  if not err and mode in (self.VVxweg, self.VVqv2O, self.VV7UCG, self.VVSV9f):
   list, err = self.VVB5My(mode, txt)
  if err:
   FFrj68(self, err, title=title)
  elif list:
   VVOFQa  = ("Home Menu"   , FFKSrd            , [])
   if mode in (self.VVxweg, self.VVSV9f):
    VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ(mode)
    VVk5TH = (""     , BF(self.VVKu6Q, mode)      , [])
    VVaq9G = ("Download Options" , BF(self.VVPP7a, mode, "", "")   , [])
    VV9CSs = ("Options"   , BF(self.VV3T1Q, "lv", mode, bName)   , [])
    VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, False)     , [])
    if mode == self.VVxweg:
     VVt6tD = ("Play"    , BF(self.VVLNgq, mode)       , [])
    else:
     VVt6tD = ("Programs"   , BF(self.VVB3Ac, mode, bName) , [])
   elif mode == self.VVqv2O:
    VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ(mode)
    VVt6tD  = ("Play"    , BF(self.VVLNgq, mode)       , [])
    VVk5TH = (""     , BF(self.VVKu6Q, mode)      , [])
    VVaq9G = ("Download Options" , BF(self.VVPP7a, mode, "v", "")   , [])
    VV9CSs = ("Options"   , BF(self.VV3T1Q, "v", mode, bName)   , [])
    VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, False)     , [])
   elif mode == self.VV7UCG:
    VVuGSD, VVO7CL, VV2ftx, VVgjmd = self.VVnNqJ("series2")
    VVt6tD  = ("Show Seasons"  , BF(self.VVtX0u, mode)       , [])
    VVk5TH = (""     , BF(self.VVDKE4, mode)     , [])
    VVaq9G = None
    VV9CSs = None
    VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, True)      , [])
   header, widths, VVmBED = self.VV5Ew1(mode)
   FFyZJ5(self, None, title=title, header=header, VVI2kC=list, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindIptv, VVk5TH=VVk5TH, VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VV2ftx, VVgjmd=VVgjmd, VV2v46=True, searchCol=1)
  else:
   FFrj68(self, "No Channels found !", title=title)
  FFAM12(self)
 def VV5Ew1(self, mode):
  if mode in (self.VVxweg, self.VVSV9f):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVmBED  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVqv2O:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVmBED  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VV7UCG:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVmBED  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVmBED
 def VVB3Ac(self, mode, bName, VVt27A, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVrqFLData["playListURL"]
  ok_fnc  = BF(self.VV7TXC, hostUrl, chName, catId, streamId)
  FF0GsP(VVt27A, BF(CC1B0Q.VVCIl7, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV7TXC(self, chUrl, chName, catId, streamId, VVt27A, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC1B0Q.VVlkd2(chUrl)
   chNum = "333"
   refCode = CC1B0Q.VV2QBX(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFHFXk(self, chUrl, VVLARq=False)
   CCLDrN.VVLpPr(self.session)
  else:
   FFrj68(self, "Incorrect Timestamp", pTitle)
 def VVtX0u(self, mode, VVt27A, title, txt, colList):
  title = colList[1]
  FF0GsP(VVt27A, BF(self.VVsadD, mode, VVt27A, title, txt, colList), title="Downloading ...")
 def VVsadD(self, mode, VVt27A, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVeTVE(self.VVeuMU, self.VVrqFLData["playListURL"], series_id)
  txt, err = self.VVEaWb(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVrKuD(tDict["info"], "name"   )
      category_id = self.VVrKuD(tDict["info"], "category_id" )
      icon  = self.VVrKuD(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVrKuD(EP, "id"     )
        episode_num   = self.VVrKuD(EP, "episode_num"   )
        epTitle    = self.VVrKuD(EP, "title"     )
        container_extension = self.VVrKuD(EP, "container_extension" )
        seasonNum   = self.VVrKuD(EP, "season"    )
        epTitle = self.VVYUsJ(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFrj68(self, err, title=title)
  elif list:
   VVOFQa = ("Home Menu"   , FFKSrd          , [])
   VVaq9G = ("Download Options" , BF(self.VVPP7a, mode, "s", title), [])
   VV9CSs = ("Options"   , BF(self.VV3T1Q, "s", mode, title) , [])
   VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, False)   , [])
   VVk5TH = (""     , BF(self.VVKu6Q, mode)    , [])
   VVt6tD  = ("Play"    , BF(self.VVLNgq, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVmBED  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFyZJ5(self, None, title=title, header=header, VVI2kC=list, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VV9CSs=VV9CSs, VVTO3h=VVTO3h, lastFindConfigObj=CFG.lastFindIptv, VVuGSD="#0a00292B", VVO7CL="#0a002126", VV2ftx="#0a002126", VVgjmd="#00000000")
  else:
   FFrj68(self, "No Channels found !", title=title)
  FFAM12(self)
 def VVzloc(self, mode, isAll, VVt27A, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VV8kKb = []
  VV8kKb.append(("Keyboard"  , "manualEntry"))
  VV8kKb.append(("From Filter" , "fromFilter"))
  FFHAbB(self, BF(self.VV4KIk, VVt27A, mode, onlyCatID), title="Input Type", VV8kKb=VV8kKb, width=400)
 def VV4KIk(self, VVt27A, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFTtos(self, BF(self.VV8hc8, VVt27A, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCkJDN(self)
    filterObj.VVSaNO(BF(self.VV8hc8, VVt27A, mode, onlyCatID))
 def VV8hc8(self, VVt27A, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFaoHf(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCkJDN.VVN7mE(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFrj68(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFrj68(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVkVvr(words):
      FFrj68(self, self.VVV9VI(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCfhQr, barTheme=CCfhQr.VVZYJm
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVzkid, VVt27A, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVVnlJ = BF(self.VVnjbz, mode, toFind, title))
   if not words:
    FFAM12(VVt27A, "Nothing to find !", 1500)
 def VVzkid(self, VVt27A, mode, onlyCatID, title, words, toFind, asPrefix, VVtEPC):
  VVtEPC.VVodiL(VVt27A.VV9aLU() if onlyCatID is None else 1)
  VVtEPC.VVsc2i = []
  for row in VVt27A.VVXwRB():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VV2Wgw(1)
   VVtEPC.VVBeXP(catName)
   qUrl  = self.VVeTVE(mode, self.VVrqFLData["playListURL"], catID)
   txt, err = self.VVEaWb(qUrl)
   if not err:
    tList, err = self.VVB5My(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVYUsJ(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVtEPC or VVtEPC.isCancelled:
        return
       VVtEPC.VVsc2i.append(item)
       VVtEPC.VVBeXP(catName)
 def VVnjbz(self, mode, toFind, title, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if VVsc2i:
   title = self.VVp29I(mode, toFind)
   if mode == self.VVxweg or mode == self.VVqv2O:
    if mode == self.VVqv2O : typ = "v"
    else          : typ = ""
    bName   = CC1B0Q.VVxag1(toFind)
    VVt6tD  = ("Play"     , BF(self.VVLNgq, mode)     , [])
    VVaq9G = ("Download Options" , BF(self.VVPP7a, mode, typ, "") , [])
    VV9CSs = ("Options"   , BF(self.VV3T1Q, "fnd", mode, bName), [])
    VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, False)   , [])
    VVk5TH = (""     , BF(self.VVKu6Q, mode)    , [])
   elif mode == self.VV7UCG:
    VVt6tD  = ("Show Seasons"  , BF(self.VVtX0u, mode)     , [])
    VV9CSs = None
    VVaq9G = None
    VVTO3h = ("Posters Mode"  , BF(self.VV1LUN, mode, True)    , [])
    VVk5TH = (""     , BF(self.VVDKE4, mode)   , [])
   VVOFQa  = ("Home Menu"   , FFKSrd          , [])
   header, widths, VVmBED = self.VV5Ew1(mode)
   VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVsc2i, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVk5TH=VVk5TH, VVuGSD="#0a00292B", VVO7CL="#0a002126", VV2ftx="#0a002126", VVgjmd="#00000000", VV2v46=True, searchCol=1)
   if not VVYFmk:
    FFAM12(VVt27A, "Stopped" , 1000)
  else:
   if VVYFmk:
    FFrj68(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVgJHK(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVxweg, self.VVSV9f):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVqv2O:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFJYbZ(chName)
  url = self.VVrqFLData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVlkd2(url)
  refCode = self.VV2QBX(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVKu6Q(self, mode, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVxXtS, mode, VVt27A, title, txt, colList))
 def VVxXtS(self, mode, VVt27A, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVgJHK(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFjcFt(self, fncMode=CCOQON.VVkTRU, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVDKE4(self, mode, VVt27A, title, txt, colList):
  FF0GsP(VVt27A, BF(self.VVIIL1, mode, VVt27A, title, txt, colList))
 def VVIIL1(self, mode, VVt27A, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFjcFt(self, fncMode=CCOQON.VVMVJq, chName=name, text=txt, picUrl=Cover)
 def VV1LUN(self, mode, isSerNames, VVt27A, title, txt, colList):
  if   mode in ("itv"  , CC1B0Q.VVxweg, CC1B0Q.VVSV9f): category = "live"
  elif mode in ("vod"  , CC1B0Q.VVqv2O )          : category = "vod"
  elif mode in ("series" , CC1B0Q.VV7UCG)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVxweg : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVSV9f : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVqv2O  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV7UCG : picCol, descCol, descTxt = 5, 0, "Season"
  FF0GsP(VVt27A, BF(self.session.open, CCvvCP, VVt27A, category, nameCol, picCol, descCol, descTxt))
 def VVPP7a(self, mode, typ, seriesName, VVt27A, title, txt, colList):
  VV8kKb = []
  isMulti = VVt27A.VVY4gV
  tot  = VVt27A.VVWJ0c()
  if isMulti:
   if tot < 1:
    FFAM12(VVt27A, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VV8kKb.append(("Download %s PIcon%s" % (name, FF7O1V(tot)), "dnldPicons" ))
  if typ:
   VV8kKb.append(VVnK97)
   tName = "Movie" if typ.startswith("v") else "Series"
   VV8kKb.append(("Download Current %s" % tName    , "dnldSel"  ))
   VV8kKb.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VV8kKb.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCnvmH.VVMkdN():
    VV8kKb.append(VVnK97)
    VV8kKb.append(("Download Manager"      , "dload_stat" ))
  FFHAbB(self, BF(self.VVVAkk, VVt27A, mode, typ, seriesName, colList), title="Download Options", VV8kKb=VV8kKb)
 def VVVAkk(self, VVt27A, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVBaHf(VVt27A, mode)
   elif item == "dnldSel"  : self.VVtC5j(VVt27A, mode, typ, colList, True)
   elif item == "addSel"  : self.VVtC5j(VVt27A, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVHIWH(VVt27A, mode, typ, seriesName)
   elif item == "dload_stat" : CCnvmH.VVTfM5(self, VVt27A)
 def VVtC5j(self, VVt27A, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVj0YD(mode, typ, colList)
  if startDnld:
   CCnvmH.VV7fSR(self, decodedUrl)
  else:
   self.VVoleT(VVt27A, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVHIWH(self, VVt27A, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVt27A.VVXwRB():
   chName, decodedUrl = self.VVj0YD(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVoleT(VVt27A, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVoleT(self, VVt27A, title, chName, decodedUrl_list, startDnld):
  FFo32K(self, BF(self.VVhVLp, VVt27A, decodedUrl_list, startDnld), chName, title=title)
 def VVhVLp(self, VVt27A, decodedUrl_list, startDnld):
  added, skipped = CCnvmH.VVjKGj(decodedUrl_list)
  FFAM12(VVt27A, "Added", 1000)
 def VVj0YD(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVgJHK(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVayQj(mode, colList)
   refCode, chUrl = self.VVGEc1(self.VVkL6K, self.VVPcbV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFWeS7(chUrl)
  return chName, decodedUrl
 def VVBaHf(self, VVt27A, mode):
  if FFFS65("ffmpeg"):
   self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VV7lAy, VVt27A, mode)
       , VVVnlJ = self.VV7rYA)
  else:
   FFo32K(self, BF(CC1B0Q.VVAHxs, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV7rYA(self, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVsc2i["proces"], VVsc2i["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVsc2i["ok"], VVsc2i["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVsc2i["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVsc2i["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVsc2i["badURL"]
  txt += "Download Failure\t: %d\n"   % VVsc2i["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVsc2i["path"]
  if not VVYFmk  : color = "#11402000"
  elif VVsc2i["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVsc2i["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVsc2i["err"], txt)
  title = "PIcons Download Result"
  if not VVYFmk:
   title += "  (cancelled)"
  FFaIgn(self, txt, title=title, VV2ftx=color)
 def VV7lAy(self, VVt27A, mode, VVtEPC):
  isMulti = VVt27A.VVY4gV
  if isMulti : totRows = VVt27A.VVWJ0c()
  else  : totRows = VVt27A.VV9aLU()
  VVtEPC.VVodiL(totRows)
  VVtEPC.VVkQ3L(0)
  counter     = VVtEPC.counter
  maxValue    = VVtEPC.maxValue
  pPath     = CCHnG6.VVYipk()
  VVtEPC.VVsc2i = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVt27A.VVXwRB()):
    if VVtEPC.isCancelled:
     break
    if not isMulti or VVt27A.VVMmb2(rowNum):
     VVtEPC.VVsc2i["proces"] += 1
     VVtEPC.VV2Wgw(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVayQj(mode, row)
      refCode = CC1B0Q.VV2QBX(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVYgrb(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVgJHK(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVtEPC.VVsc2i["attempt"] += 1
       path, err = FFadHO(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVtEPC:
         VVtEPC.VVsc2i["ok"] += 1
         VVtEPC.VVkQ3L(VVtEPC.VVsc2i["ok"])
        if FF7PcS(path) > 0:
         cmd = CCOQON.VVTaWN(path)
         cmd += FFhyjZ("mv -f '%s' '%s'" % (path, pPath))
         FFWnHJ(cmd)
        else:
         if VVtEPC:
          VVtEPC.VVsc2i["size0"] += 1
         FFfIuR(path)
       elif err:
        if VVtEPC:
         VVtEPC.VVsc2i["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVtEPC:
          VVtEPC.VVsc2i["err"] = err.title()
         break
      else:
       if VVtEPC:
        VVtEPC.VVsc2i["exist"] += 1
     else:
      if VVtEPC:
       VVtEPC.VVsc2i["badURL"] += 1
  except:
   pass
 def VVzVBh(self):
  title = "Download PIcons for Current Bouquet"
  if FFFS65("ffmpeg"):
   self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
       , titlePrefix = ""
       , fncToRun  = self.VVrHdv
       , VVVnlJ = BF(self.VVZbI3, title))
  else:
   FFo32K(self, BF(CC1B0Q.VVAHxs, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVrHdv(self, VVtEPC):
  bName = CCQo5X.VV0SNX()
  pPath = CCHnG6.VVYipk()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVtEPC.VVsc2i = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCQo5X.VVaPgW()
  if not VVtEPC or VVtEPC.isCancelled:
   return
  if not services or len(services) == 0:
   VVtEPC.VVsc2i = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVtEPC.VVodiL(totCh)
  VVtEPC.VVkQ3L(0)
  for serv in services:
   if not VVtEPC or VVtEPC.isCancelled:
    return
   VVtEPC.VVsc2i = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVtEPC.VV2Wgw(1)
   VVtEPC.VVkQ3L(totPic)
   fullRef  = serv[0]
   if FF8yv3(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFWeS7(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCXeC7.VVsyWu(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CC1B0Q.VVIq7x(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC1B0Q.VVEaWb(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCOQON.VV4Gum(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFadHO(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVtEPC:
     VVtEPC.VVkQ3L(totPic)
    if FF7PcS(path) > 0:
     cmd = CCOQON.VVTaWN(path)
     cmd += FFhyjZ("mv -f '%s' '%s'" % (path, pPath))
     FFWnHJ(cmd)
     totPicOK += 1
    else:
     totSize0
     FFfIuR(path)
  if VVtEPC:
   VVtEPC.VVsc2i = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVZbI3(self, title, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVsc2i
  if err:
   FFrj68(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FF7kJS(str(totExist)  , VVSBcQ)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF7kJS(str(totNotIptv)  , VVSBcQ)
    if totServErr : txt += "Server Errors\t: %s\n" % FF7kJS(str(totServErr) + t1, VVSBcQ)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FF7kJS(str(totParseErr) , VVSBcQ)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FF7kJS(str(totInvServ)  , VVSBcQ)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FF7kJS(str(totInvPicUrl) , VVSBcQ)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FF7kJS(str(totSize0)  , VVSBcQ)
   if not VVYFmk:
    title += "  (stopped)"
   FFaIgn(self, txt, title=title)
 @staticmethod
 def VVAHxs(SELF):
  cmd = FFMlY4(VVcIUq, "ffmpeg")
  if cmd : FFSEeb(SELF, cmd, title="Installing FFmpeg")
  else : FFUrcP(SELF)
 @staticmethod
 def VV1D30(SELF):
  SELF.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs
      , titlePrefix = ""
      , fncToRun  = CC1B0Q.VVRB3q
      , VVVnlJ = BF(CC1B0Q.VVPoYK, SELF))
 @staticmethod
 def VVRB3q(VVtEPC):
  bName = CCQo5X.VV0SNX()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVtEPC.VVsc2i = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCQo5X.VVaPgW()
  if not VVtEPC or VVtEPC.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVtEPC.VVodiL(totCh)
   for serv in services:
    if not VVtEPC or VVtEPC.isCancelled:
     return
    VVtEPC.VV2Wgw(1)
    fullRef = serv[0]
    if FF8yv3(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFWeS7(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCXeC7.VVEwWd(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CC1B0Q.VVIq7x(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CC1B0Q.VVAh05(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVtEPC:
      VVtEPC.VVYhxi(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCS6Mr.VVCij8(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVtEPC:
     VVtEPC.VVsc2i = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVtEPC.VVsc2i = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVPoYK(SELF, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVsc2i
  title = "IPTV EPG Import"
  if err:
   FFrj68(SELF, err, title=title)
  else:
   if VVYFmk and totEpgOK > 0:
    CCS6Mr.VVRnze()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF7kJS(str(totNotIptv), VVSBcQ)
    if totServErr : txt += "Server Errors\t: %s\n" % FF7kJS(str(totServErr) + t1, VVSBcQ)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF7kJS(str(totInv), VVSBcQ)
   if not VVYFmk:
    title += "  (stopped)"
   FFaIgn(SELF, txt, title=title)
 @staticmethod
 def VVAh05(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC1B0Q.VVlkd2(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC1B0Q.VVEaWb(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC1B0Q.VVrKuD(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CC1B0Q.VVrKuD(item, "lang"        ).upper()
    now_playing   = CC1B0Q.VVrKuD(item, "now_playing"      )
    start    = CC1B0Q.VVrKuD(item, "start"        )
    start_timestamp  = CC1B0Q.VVrKuD(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC1B0Q.VVrKuD(item, "start_timestamp"     )
    stop_timestamp  = CC1B0Q.VVrKuD(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC1B0Q.VVrKuD(item, "stop_timestamp"      )
    tTitle    = CC1B0Q.VVrKuD(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV2QBX(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC1B0Q.VVUUTK(catID, MAX_4b)
  TSID = CC1B0Q.VVUUTK(chNum, MAX_4b)
  ONID = CC1B0Q.VVUUTK(chNum, MAX_4b)
  NS  = CC1B0Q.VVUUTK(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVUUTK(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVxag1(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVnNqJ(mode):
  if   mode in ("itv"  , CC1B0Q.VV516e)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC1B0Q.VV2CzX)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC1B0Q.VVx5gl) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC1B0Q.VVAU2I) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC1B0Q.VVSV9f    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVni8g(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VV4mJx:
   excl = FFViIp(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFrj68(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFO8C9('find %s %s %s' % (path, excl, par))
  if files:
   err = CCFric.VVvwlA(files)
   if err : FFrj68(self, err + FF7kJS('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVSFOM))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFrj68(self, err)
  return []
 @staticmethod
 def VVIBms():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFxiJi(path)
  return "/"
 @staticmethod
 def VVCIl7(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CC1B0Q.VVAh05(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFrj68(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVuGSD, VVO7CL, VV2ftx, VVgjmd = CC1B0Q.VVnNqJ("")
   VVOFQa = ("Home Menu" , FFKSrd, [])
   VVt6tD  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVmBED  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFyZJ5(SELF, None, title="Programs for : " + chName, header=header, VVI2kC=pList, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=24, VVt6tD=VVt6tD, VVOFQa=VVOFQa, VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VV2ftx, VVgjmd=VVgjmd)
  else:
   FFrj68(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVBFii(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVCMHv(self, isPortal, line, VV476KObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFo32K(self, BF(self.VV79Ap, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFaoHf(confItem, line)
   FF9glI(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV79Ap(self, title, confItem):
  FFaoHf(confItem, "")
  FF9glI(self, "Removed from IPTV Menu.", title=title)
 def VVJ2Dq(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VV6bO0(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FF0GsP(self, BF(self.VVNsuO, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFrj68(self, "Incorrect server data !")
 @staticmethod
 def VVMH4x(SELF, isPortal, line, VV476KObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC1B0Q.VVIBms()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFrj68(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF9glI(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFrj68(SELF, "Error:\n\n%s" % str(e), title=title)
 def VV3T1Q(self, source, mode, curBName, VVt27A, title, txt, colList):
  isMulti = VVt27A.VVY4gV
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVt27A.VVWJ0c()
   totTxt = "%d Service%s" % (tot, FF7O1V(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FF7kJS(totTxt, VVSFOM)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CC9SG5(self, VVt27A, addSep=False)
  thTxt = "Adding Services ..."
  VV8kKb, cbFncDict = [], None
  VV8kKb.append(VVnK97)
  if itemsOK:
   VV8kKb.append(("Add %s to New Bouquet : %s"    % (totTxt, FF7kJS(curBName , VVomgc)), "addToCur1"))
   if curBName2: VV8kKb.append(("Add %s to New Bouquet : %s" % (totTxt, FF7kJS(curBName2, VVZkFQ)) , "addToCur2"))
   VV8kKb.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FF0GsP, mSel.VVt27A, BF(self.VV5wiC,source, mode, curBName , VVt27A, title), title=thTxt)
      , "addToCur2": BF(FF0GsP, mSel.VVt27A, BF(self.VV5wiC,source, mode, curBName2, VVt27A, title), title=thTxt)
      , "addToNew" : BF(self.VV8z9s, source, mode, curBName, VVt27A, title)
      }
  else:
   VV8kKb.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVV2XD(VV8kKb, cbFncDict, width=1400)
 def VV5wiC(self, source, mode, curBName, VVt27A, Title):
  chUrlLst = self.VVv666(source, mode, VVt27A)
  CCQo5X.VVzV4N(self, Title, curBName, "", chUrlLst)
 def VV8z9s(self, source, mode, curBName, VVt27A, Title):
  picker = CCQo5X(self, VVt27A, Title, BF(self.VVv666, source, mode, VVt27A), defBName=curBName)
 def VVv666(self, source, mode, VVt27A):
  totChange = 0
  isMulti = VVt27A.VVY4gV
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVt27A.VVXwRB()):
   if not isMulti or VVt27A.VVMmb2(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVayQj(mode, row)
     refCode, chUrl = self.VVGEc1(self.VVkL6K, self.VVPcbV, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VV4rx8(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVgJHK(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVdQl0():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVS2HJ():
  return sorted(tuple(CC1B0Q.VVdQl0()))
 @staticmethod
 def VVcYNm(rt):
  return CC1B0Q.VVdQl0().get(str(rt), "")
 @staticmethod
 def VVSzlp(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CC1B0Q.VVcYNm(span.group(1)) if span else ""
 @staticmethod
 def VVOBYe(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVPRvV():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VV8kKb = []
  for ndx, rt in enumerate(CC1B0Q.VVS2HJ()):
   VV8kKb.append(FF4UJX("%s\t... %s" % (CC1B0Q.VVcYNm(rt), rt), rt, CC1B0Q.VVOBYe(rt), VV30Pd if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VV8kKb.append(VVnK97)
  return VV8kKb
class CCflVV(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVEDGF(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFIY0q(self.frm, frmColor)
  FFIY0q(self.bak, bakColor)
  FFIY0q(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVNZw5(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFFgzn(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCacgq(CCflVV):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCflVV.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VViYjz()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VVwG1X   ,
   "down" : self.VVh50n  ,
   "left" : self.VVAwoe  ,
   "right" : self.VVhFYt  ,
   "next" : self.VV5gAv ,
   "last" : self.VVvR0L
  }, -1)
 def VVv8AZ(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVEDGF(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVkNB5()
  self["myPiconPtr"].hide()
 def VVHtGL(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVwG1X(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVTdvq()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVZbHt()
 def VVh50n(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBhNl()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVZbHt()
 def VVAwoe(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVTdvq()
  else:
   self.curCol -= 1
   self.VVZbHt()
 def VVhFYt(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVBhNl()
  else:
   self.curCol += 1
   self.VVZbHt()
 def VVvR0L(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVZbHt(oldPage != self.curPage)
 def VV5gAv(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVZbHt(oldPage != self.curPage)
 def VVBhNl(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVZbHt(force)
 def VVTdvq(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVZbHt(force)
 def VVZbHt(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV9acH = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV9acH: self.curPage = VV9acH
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVxd9A()
  self["myPiconPtr"].hide()
  self.VVNZw5(self.curPage + 1, self.totalPages)
  FF2Wwv(BF(self.VVZIh0, force or not oldPage == self.curPage, VV9acH))
 def VVZIh0(self, force, VV9acH):
  try:
   if force:
    self.VVGJTc()
   if self.curPage == VV9acH:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVxd9A()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVmtwJ(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVZbHt(False if oldPage == self.curPage else True)
  else:
   FFAM12(self, "Not found", 1000)
 def VV0ud4(self):
  self.VVmtwJ(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VViYjz(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VV9jRx(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVfdpW, CCNsZw, defFG=fg, defBG=bg, onlyBG=True)
 def VVfdpW(self, fg, bg):
  if self.colorCfg and bg:
   FFaoHf(self.colorCfg, bg)
   self.VVkNB5()
 def VVkNB5(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFIY0q(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVnBTw(self, lbl, txt, color=""):
  CCacgq.VVI8uK(lbl, txt, color)
 @staticmethod
 def VVI8uK(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVDyT6(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCvvCP(Screen, CCacgq):
 def __init__(self, session, VVt27A, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFpC8B(VVQDxF, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVt27A  = VVt27A
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVI2kC    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FF74S2(self, self.Title)
  CCacgq.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVBI3c, subPath)
  if not pathExists(self.pPath):
   FFWnHJ("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VV0TcE    ,
   "cancel": self.close    ,
   "menu" : self.VVNBEs ,
   "info" : self.VVrLBC  ,
   "0"  : self.VV0ud4
  })
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  FFtJRK(self)
  self.VVv8AZ()
  self.VV6mqe()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVNBEs(self):
  chName, subj, desc, fName, picUrl = self.VVI2kC[self.curIndex]
  VV8kKb = []
  VV8kKb.append(FF4UJX("Show Selected Picture"        , "VV229r"  , fName))
  VV8kKb.append(FF4UJX("Copy Selected Picture to Export-Directory"   , "VVa20b" , fName))
  VV8kKb.append(FF4UJX("Set Selected Picture as a Poster for a Local Media" , "VVg2Xk", fName))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Cache details"       , "VVCwww"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change Poster/Picon Transparency Color" , "VV9jRx" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Help (Keys)"        , "help"     ))
  FFHAbB(self, self.VVaMFM, title=self.Title, VV8kKb=VV8kKb)
 def VVaMFM(self, item=None):
  if item is not None:
   if   item == "VV229r"   : self.VV229r()
   elif item == "VVa20b"   : self.VVa20b()
   elif item == "VVg2Xk"  : self.VVg2Xk()
   elif item == "VVCwww"  : FF0GsP(self, self.VVCwww, title="Calculating ...")
   elif item == "VV9jRx": self.VV9jRx()
   elif item == "help"     : FFZzIv(self, "_help_servBr", "Server Browser (Keys)")
 def VV0TcE(self):
  self.VVt27A.VVagt1(self.curIndex)
  self.VVt27A.VVeotT()
 def VVrLBC(self):
  self.VVt27A.VVagt1(self.curIndex)
  self.VVt27A.VVY9aU()
 def VV6mqe(self):
  for colList in self.VVt27A.VVXwRB():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVI2kC.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVI2kC)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVt27A.VV2fe8()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVZbHt(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVgHGw)
  except:
   self.timer.callback.append(self.VVgHGw)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVLl6d)
  self.myThread.start()
 def VVLl6d(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVI2kC):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFadHO(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFWnHJ("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVI2kC[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVgHGw(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVD6mq + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVI2kC[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVI2kC[ndx] = (chName, subj, desc, fName, "")
     CCacgq.VVDyT6(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVGJTc(self):
  self.VViYjz()
  f1, f2 = self.VVHtGL()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVI2kC[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVnBTw(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VV8hpn + "iptv.png"
   CCacgq.VVDyT6(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVxd9A(self):
  chName, subj, desc, fName, picUrl = self.VVI2kC[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV229r(self):
  chName, subj, desc, fName, picUrl = self.VVI2kC[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCJCdT.VVHj4i(self, self.pPath + fName)
  else          : FFAM12(self, "File not found", 1500)
 def VVa20b(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVI2kC[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFWnHJ("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FF9glI(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFrj68(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFrj68(self, "No Poster/PIcon found", title=title)
 def VVg2Xk(self):
  self.session.openWithCallback(self.VVY1B6, BF(CCFric, patternMode="movies", VVZmiW=CFG.MovieDownloadPath.getValue()))
 def VVY1B6(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVI2kC[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFWnHJ("cp -f '%s' '%s'" % (srcF, dstF)):
     FF9glI(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFrj68(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CC7lgd.VVUavQ(dstF)
   else:
    FFrj68(self, "No Poster/PIcon found", title=title)
 def VVCwww(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVBI3c, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFdVkh("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCFric.VVgYti(size)
   txt += "%s\n    %s\n\n" % (FF7kJS(path, VVSFOM), size)
  mainPath = "%sPosters" % VVBI3c
  totFiles = FFdVkh("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FF7O1V(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FF7kJS("Total space used by Posters/PIcons%s:" % totFTxt, VV691Y), CCFric.VVgYti(totSize))
  mountPath = CCFric.VV37eX(mainPath)
  if pathExists(mountPath):
   totSize  = CCFric.VVcbVM(mountPath)
   freeSize = CCFric.VV5FZe(mountPath)
   usedSize = CCFric.VVgYti(totSize - freeSize)
   totSize  = CCFric.VVgYti(totSize)
   freeSize = CCFric.VVgYti(freeSize)
   txt += "%s\n" % SEP
   txt += FF7kJS("Media Space:\n", VV4d6Z)
   txt += "    Media Path\t: %s\n" % FF7kJS(mountPath, VVLAFW)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFaIgn(self, txt, title="Cache Used Size", height=1000)
class CC7lgd(Screen, CCacgq):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFpC8B(VVLPi8, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVI2kC    = lst
  FF74S2(self, self.Title)
  CCacgq.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VV0TcE    ,
   "cancel": self.close    ,
   "menu" : self.VVkp5i ,
   "info" : self.VVuvXt  ,
   "0"  : self.VV0ud4
  })
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  FFtJRK(self)
  self.VVv8AZ()
  self.totalItems = len(self.VVI2kC)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVZbHt(True)
 def VVGJTc(self):
  self.VViYjz()
  f1, f2 = self.VVHtGL()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVI2kC[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VV8hpn + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVnBTw(lbl, os.path.splitext(os.path.basename(path))[0])
   CCacgq.VVDyT6(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVZE1O(self):
  path, movie, poster = self.VVI2kC[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVxd9A(self):
  path, poster = self.VVZE1O()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVkp5i(self):
  path, poster = self.VVZE1O()
  VV8kKb = []
  VV8kKb.append(("Go to movie ...", "VVbcxe"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(FF4UJX("Show Poster"      , "VV229r" , poster))
  VV8kKb.append(FF4UJX("Copy Poster to Export-Directory" , "VVa20b", poster))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change Poster/Picon Transparency Color"  , "VV9jRx" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change Poster (from current movie path) ..." , "VVj9CD1"  ))
  VV8kKb.append(("Change Poster (locate manually) ..."   , "VVj9CD2"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Help (Keys)"         , "help"     ))
  FFHAbB(self, self.VVsOO0, title=self.Title, VV8kKb=VV8kKb)
 def VVsOO0(self, item=None):
  if item is not None:
   if   item == "VVbcxe"    : self.VVbcxe()
   elif item == "VVa20b"    : self.VVa20b()
   elif item == "VV229r"    : self.VV229r()
   elif item == "VV9jRx" : self.VV9jRx()
   elif item == "VVj9CD1"  : self.VVj9CD()
   elif item == "VVj9CD2"  : self.VVj9CD(True)
   elif item == "help"      : FFZzIv(self, "_help_movBr", "Movies Browser (Keys)")
 def VVbcxe(self):
  VVDb2Q = []
  for ndx, item in enumerate(self.VVI2kC):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVDb2Q.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVDb2Q.sort(key=lambda x: x[0].lower())
  VVt6tD = ("Select" , self.VVE78D, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFyZJ5(self, None, title="Select Movie", width=1800, height=1000, header=header, VVI2kC=VVDb2Q, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, lastFindConfigObj=CFG.lastFindMovie)
 def VVE78D(self, VVt27A, title, txt, colList):
  self.VVmtwJ(int(colList[2].strip()))
  VVt27A.cancel()
 def VV0TcE(self):
  path, poster = self.VVZE1O()
  FF0GsP(self, BF(CCFric.VVDGqS, self, path), title="Playing Media ...")
 def VVuvXt(self):
  path, poster = self.VVZE1O()
  txt = "%s:\n%s\n\n" % (FF7kJS("Path", VVSFOM), path)
  size = FF7PcS(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FF7kJS("File Size", VVSFOM), CCFric.VVgYti(size))
  if poster:
   txt += "%s:\n%s" % (FF7kJS("Poster", VVSFOM), poster)
  FFaIgn(self, txt, title="Media File Information")
 def VV229r(self):
  path, poster = self.VVZE1O()
  if fileExists(poster): CCJCdT.VVHj4i(self, poster)
  else     : FFAM12(self, "No Poster", 1500)
 def VVa20b(self):
  title = "Copy Poster"
  path, poster = self.VVZE1O()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFWnHJ("cp -f '%s' '%s'" % (poster, dstF)):
    FF9glI(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFrj68(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFAM12(self, "No Poster", 1500)
 def VVj9CD(self, isManual=False):
  path, poster = self.VVZE1O()
  sDir = FFxiJi(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVqSdv, sDir, path), BF(CCFric, patternMode="poster", VVZmiW=sDir))
  else:
   VV8kKb = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VV8kKb.append((os.path.basename(item), sDir + item))
   if VV8kKb:
    VV8kKb.sort(key=lambda x: x[0].lower())
    VVM6M9 = self.VVp5b8
    FFHAbB(self, BF(self.VVqSdv, sDir, path), VV8kKb=VV8kKb, title="Posters", VVM6M9=VVM6M9, VVj7dk=sDir)
   else:
    FFAM12(self, "No jpg/png in current dir", 1500)
 def VVp5b8(self, VVNmGv, txt, ref, ndx):
  CCJCdT.VVHj4i(self, VVRuzQ=ref)
 def VVqSdv(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFWnHJ("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVI2kC[self.curIndex] = (self.VVI2kC[self.curIndex][0], self.VVI2kC[self.curIndex][1], os.path.basename(newPath))
    FF0GsP(self, self.VVGJTc)
    CC7lgd.VVUavQ(newPath)
   else:
    FFAM12(self, "Cannot copy file", 1000)
 @staticmethod
 def VVUavQ(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFWnHJ("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VV9ZzQ(SELF):
  eLst = CCz7OO.VVFMqt()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CC7lgd, title, lst)
  else  : FFrj68(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCSBZP(Screen, CCacgq):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFpC8B(VV6mg1, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVI2kC    = lst
  self.pPath    = CCHnG6.VVYipk()
  self.totalItems   = 0
  self.isFirstTime  = True
  FF74S2(self, self.Title)
  FFFQrh(self["keyRed"] , "OK = Zap (Review)")
  FFFQrh(self["keyGreen"] , "Zap & Exit")
  FFFQrh(self["keyYellow"], "Find Current Service")
  CCacgq.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VV2MQX, False),
   "cancel" : self.VVrEeW      ,
   "menu"  : self.VVaPDL   ,
   "red"  : self.VVrEeW      ,
   "green"  : BF(self.VV2MQX, True) ,
   "yellow" : BF(self.VVJShd, True)  ,
   "0"   : self.VV0ud4
  })
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFgqCi(self)
   FFtJRK(self)
   FFIY0q(self["keyRed"], "#0a333333")
   self.VVv8AZ()
  else:
   pName, srvLst = CCSBZP.VVLk4R()
   if srvLst and not srvLst == self.VVI2kC:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVI2kC = srvLst
   else:
    force = False
  self.totalItems = len(self.VVI2kC)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVZbHt(force)
  self.VVJShd()
 def VVaPDL(self):
  VV8kKb = []
  VV8kKb.append(("Find Name (sorted list)" , "findSrt"  ))
  VV8kKb.append(("Find Name (as listed)" , "findNoSrt"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Change Background Color" , "VV9jRx"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Help (Keys)", "help"))
  FFHAbB(self, self.VVHjtM, title="Options", VV8kKb=VV8kKb)
 def VVHjtM(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVxq7T(True)
   elif item == "findNoSrt"   : self.VVxq7T(False)
   elif item == "VV9jRx": self.VV9jRx()
   elif item == "help"     : FFZzIv(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVxq7T(self, isSort):
  VV8kKb = []
  for ndx, item in enumerate(self.VVI2kC):
   VV8kKb.append((item[1], ndx))
  if isSort:
   VV8kKb.sort(key=lambda x: x[0].lower())
  FFHAbB(self, self.VV7Oi8, title="Find Name", VV8kKb=VV8kKb, width=1300)
 def VV7Oi8(self, ndx=None):
  if ndx is not None:
   self.VVmtwJ(ndx)
 def VVrEeW(self):
  if self.shown: self.close()
  else   : self.show()
 def VV2MQX(self, isExit):
  FF0GsP(self, BF(self.VV2wc2, isExit), title="Starting ...")
 def VV2wc2(self, isExit):
  try:
   if self.shown:
    FFHFXk(self, self.VVI2kC[self.curIndex][0], VVLARq=False)
    if isExit: self.close()
    else  : CCLDrN.VVLpPr(self.session)
   else:
    self.show()
  except:
   pass
 def VVJShd(self, VVSOst=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVI2kC):
    if curRef == item[0]:
     self.VVmtwJ(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVSOst and err:
   FFAM12(self, err, 500)
  return -1
 def VVGJTc(self):
  self.VViYjz()
  f1, f2 = self.VVHtGL()
  row = col = 0
  noPos = VV8hpn + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVI2kC[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVnBTw(lbl, name)
   path = CCHnG6.VV0eNP(self.pPath, ref, name) or noPos
   CCacgq.VVDyT6(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVxd9A(self):
  ref, name = self.VVI2kC[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVWAv8():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVWHhY = InfoBar.instance
  if VVWHhY:
   csel = VVWHhY.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFettQ(rootRef)
    refName  = FFettQ(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVLk4R(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCSBZP.VVWAv8()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFxPkx(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCQo5X.VVaPgW()
   pName  = CCQo5X.VV0SNX() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVkE4M(SELF):
  pName, srvLst = CCSBZP.VVLk4R()
  if srvLst: SELF.session.open(CCSBZP, pName, srvLst)
  else  : FFrj68(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCYqAD(Screen, CCacgq):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFpC8B(VVV2FZ, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVI2kC    = CCYqAD.VVdJ7q(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FF74S2(self, self.Title)
  FFFQrh(self["keyRed"] , "OK = Start Plugin")
  FFFQrh(self["keyYellow"], "Package Info.")
  FFFQrh(self["keyBlue"] , "Plugins Group")
  CCacgq.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVYaCG   ,
   "cancel" : self.VVrEeW    ,
   "menu"  : self.VVDtTK ,
   "info"  : self.VVRxaN  ,
   "red"  : self.VVrEeW    ,
   "yellow" : BF(FF0GsP, self, self.VVkQsb),
   "blue"  : self.VVIQo7  ,
   "0"   : self.VV0ud4
  })
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  FFtJRK(self)
  FFIY0q(self["keyRed"], "#0a333333")
  self.VVv8AZ()
  self.totalItems = len(self.VVI2kC)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVZbHt(True)
 def VVrEeW(self):
  self.close()
 def VVYaCG(self):
  name, desc = self.VVOlIn(self.curIndex)
  if name == PLUGIN_NAME:
   FFAM12(self, "Already running.", 500)
  else:
   try:
    p = self.VVI2kC[self.curIndex]
    p(session=self.session)
   except:
    FFrj68(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVRxaN(self):
  def VVPmyh(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVI2kC[self.curIndex]
  txt = ""
  try:
   txt += VVPmyh("Path"  , p.path  )
   txt += VVPmyh("Description" , p.description )
   txt += VVPmyh("Icon"  , p.iconstr  )
   txt += VVPmyh("Wakeup Fnc" , p.wakeupfnc )
   txt += VVPmyh("NeedsRestart", p.needsRestart)
   txt += VVPmyh("Internal" , p.internal )
   txt += VVPmyh("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVOlIn(self.curIndex)
  if txt : FFaIgn(self, txt, title=name)
  else : FFrj68(self, "Could not read plugin info.", title=name)
 def VVkQsb(self):
  p = self.VVI2kC[self.curIndex]
  name, desc = self.VVOlIn(self.curIndex)
  path = p.path
  pkg, err = CChnXU.VVpk3f(path)
  if pkg : CChnXU.VV4gJ4(self, pkg, name)
  else : FFIZWt(self, err, 1000)
 def VVDtTK(self):
  path = self.VVI2kC[self.curIndex].path
  VV8kKb = []
  txt = "Open Plugin Path in File Manager"
  VV8kKb.append(FF4UJX("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Use Original Icon Size", "setOrigSize"))
  FFHAbB(self, self.VVbmcz, title="Plugins Group", VV8kKb=VV8kKb)
 def VVbmcz(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCFric, mode=CCFric.VVs7cM, VVZmiW=self.VVI2kC[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVZbHt(True)
 def VVIQo7(self):
  FFHAbB(self, self.VVeNfS, title="Plugins Group", VV8kKb=CCYqAD.VVIGXm(True, True), width=700, VVPYdF=True)
 def VVeNfS(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCYqAD.VVCVsY(where)
   if lst:
    self.VVI2kC = CCYqAD.VVdJ7q(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVI2kC)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVZbHt(True)
   else:
    FFrj68(self, "Not found !", title=self.Title)
 def VVGJTc(self):
  self.VViYjz()
  f1, f2 = self.VVHtGL()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVOlIn(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVnBTw(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVI2kC[ndx].icon:
    try:
     pngSz = self.VVI2kC[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVI2kC[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVI2kC[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VV8hpn + "plugin.png")
    for path in icons:
     pixMap = CCacgq.VVDyT6(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVOlIn(self, ndx):
  name = str(self.VVI2kC[ndx].name).strip()
  desc = str(self.VVI2kC[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFM4mE(self.VVI2kC[ndx].path)
  return name, desc
 def VVxd9A(self):
  name, desc = self.VVOlIn(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVIGXm(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCYqAD.VVCVsY(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VViSml, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVnK97)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVCVsY(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVdJ7q(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFM4mE(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVThU6(SELF):
  title = "Plugins Browser"
  lst = CCYqAD.VVCVsY(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCYqAD, title, lst)
  else : FFrj68(SELF, "No plugins found !", title=title)
class CCU9He(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFpC8B(VVX871, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VV4Pxq  = 0
  self.VVJdqE = 1
  self.VVSEXs  = 2
  VV8kKb = []
  VV8kKb.append(("Find in All Service (from filter)" , "VVOBJo" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Find in All (Manual Entry)"   , "VV7LmE"    ))
  VV8kKb.append(("Find in TV"       , "VVrE2n"    ))
  VV8kKb.append(("Find in Radio"      , "VVT23N"   ))
  if self.VVwbLL():
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Hide Channel: %s" % self.servName , "VVPu4A"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Zap History"       , "VVQm8e"    ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("IPTV Tools"       , "iptv"      ))
  VV8kKb.append(("PIcons Tools"       , "PIconsTools"     ))
  VV8kKb.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VV8kKb.append(("EPG Tools"       , "epgTools"     ))
  FF74S2(self, VV8kKb=VV8kKb, title=title)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self)
  if self.isFindMode:
   self.VVegCw(self.VV8bhN())
 def VV0TcE(self):
  global VVZiux
  VVZiux = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV7LmE"    : self.VV7LmE()
   elif item == "VVOBJo" : self.VVOBJo()
   elif item == "VVrE2n"    : self.VVrE2n()
   elif item == "VVT23N"   : self.VVT23N()
   elif item == "VVPu4A"   : self.VVPu4A()
   elif item == "VVQm8e"    : self.VVQm8e()
   elif item == "iptv"       : self.session.open(CC1B0Q)
   elif item == "PIconsTools"     : self.session.open(CCHnG6)
   elif item == "ChannelsTools"    : self.session.open(CCGJtF)
   elif item == "epgTools"      : self.session.open(CCS6Mr)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVrE2n(self) : self.VVegCw(self.VV4Pxq)
 def VVT23N(self) : self.VVegCw(self.VVJdqE)
 def VV7LmE(self) : self.VVegCw(self.VVSEXs)
 def VVegCw(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFTtos(self, BF(self.VVCFwv, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVOBJo(self):
  filterObj = CCkJDN(self)
  filterObj.VVSaNO(self.VVg4qT)
 def VVg4qT(self, item):
  self.VVCFwv(self.VVSEXs, item)
 def VVwbLL(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF8yv3(self.refCode)        : return False
  return True
 def VVCFwv(self, mode, VVRVPR):
  FF0GsP(self, BF(self.VVS0lt, mode, VVRVPR), title="Searching ...")
 def VVS0lt(self, mode, VVRVPR):
  if VVRVPR:
   VVRVPR = VVRVPR.strip()
  if VVRVPR:
   self.findTxt = VVRVPR
   CFG.lastFindContextFind.setValue(VVRVPR)
   if   mode == self.VV4Pxq  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVJdqE : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVRVPR)
   if len(title) > 55:
    title = title[:55] + ".."
   VVDb2Q = self.VVR3YG(VVRVPR, servTypes)
   if self.isFindMode or mode == self.VVSEXs:
    VVDb2Q += self.VVGNoE(VVRVPR)
   if VVDb2Q:
    VVDb2Q.sort(key=lambda x: x[0].lower())
    VVqFCi = self.VV3rvq
    VVt6tD  = ("Zap"   , self.VVH6w1    , [])
    VVaq9G = ("Current Service", self.VVWFNh , [])
    VV9CSs = ("Options"  , self.VVR1Pw , [])
    VVk5TH = (""    , self.VVdNTr , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVmBED  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVqFCi=VVqFCi, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVk5TH=VVk5TH, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVegCw(self.VV8bhN())
    FF9glI(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVR3YG(self, VVRVPR, servTypes):
  VVI2kC = CCGJtF.VVB3gd(servTypes)
  VVDb2Q = []
  if VVI2kC:
   VVxlaR, VViowm = FFRmby()
   tp = CC5k8k()
   words, asPrefix = CCkJDN.VVN7mE(VVRVPR)
   colorYellow  = CCTWTN.VV0VOj(VV691Y)
   colorWhite  = CCTWTN.VV0VOj(VVkbX3)
   for s in VVI2kC:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFcVIt(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVxlaR:
        STYPE = VViowm[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVBfDu(refCode)
       if not "-S" in syst:
        sat = syst
       VVDb2Q.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVDb2Q
 def VVGNoE(self, VVRVPR):
  VVRVPR = VVRVPR.lower()
  VVDb2Q = []
  colorYellow  = CCTWTN.VV0VOj(VV691Y)
  colorWhite  = CCTWTN.VV0VOj(VVkbX3)
  for b in CCQo5X.VVePOY():
   VVHVrB  = b[0]
   VVvKgN  = b[1].toString()
   VVy0t4 = eServiceReference(VVvKgN)
   VVT6RH = FFxPkx(VVy0t4)
   for service in VVT6RH:
    refCode  = service[0]
    if FF8yv3(refCode):
     servName = service[1]
     if VVRVPR in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVRVPR), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVDb2Q.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVDb2Q
 def VV8bhN(self):
  VVWHhY = InfoBar.instance
  if VVWHhY:
   VVaBL4 = VVWHhY.servicelist
   if VVaBL4:
    return VVaBL4.mode == 1
  return self.VVSEXs
 def VV3rvq(self, VVt27A):
  self.close()
  VVt27A.cancel()
 def VVH6w1(self, VVt27A, title, txt, colList):
  FFHFXk(VVt27A, colList[2], VVLARq=False, checkParentalControl=True)
 def VVWFNh(self, VVt27A, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(VVt27A)
  if refCode:
   VVt27A.VVEIcu(2, FFnnjU(refCode, iptvRef, chName), True)
 def VVR1Pw(self, VVt27A, title, txt, colList):
  servName = colList[0]
  mSel = CC9SG5(self, VVt27A)
  VV8kKb, cbFncDict = CCGJtF.VVISFP(self, VVt27A, servName, 2)
  mSel.VVV2XD(VV8kKb, cbFncDict)
 def VVdNTr(self, VVt27A, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFjcFt(self, fncMode=CCOQON.VVCG2x, refCode=refCode, chName=chName, text=txt)
 def VVPu4A(self):
  FFo32K(self, self.VVqA6W, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVqA6W(self):
  ret = FFUsLp(self.refCode, True)
  if ret:
   self.VVEuig()
   self.close()
  else:
   FFAM12(self, "Cannot change state" , 1000)
 def VVEuig(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVxwsr()
  except:
   self.VVrCyc()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFewyb(self, serviceRef)
 def VVxwsr(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVWHhY = InfoBar.instance
   if VVWHhY:
    VVaBL4 = VVWHhY.servicelist
    if VVaBL4:
     hList = VVaBL4.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVaBL4.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVaBL4.history  = newList
       VVaBL4.history_pos = pos
 def VVrCyc(self):
  VVWHhY = InfoBar.instance
  if VVWHhY:
   VVaBL4 = VVWHhY.servicelist
   if VVaBL4:
    VVaBL4.history  = []
    VVaBL4.history_pos = 0
 def VVQm8e(self):
  VVWHhY = InfoBar.instance
  VVDb2Q = []
  if VVWHhY:
   VVaBL4 = VVWHhY.servicelist
   if VVaBL4:
    VVxlaR, VViowm = FFRmby()
    for serv in VVaBL4.history:
     refCode = serv[-1].toString()
     chName = FFettQ(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FF8yv3(refCode)
     isSRel = FFIkRt(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFcVIt(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVxlaR:
       STYPE = VViowm[sTypeInt]
     VVDb2Q.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVDb2Q:
   VVt6tD  = ("Zap"   , self.VV7j5g   , [])
   VV9CSs = ("Clear History" , self.VVh94w   , [])
   VVk5TH = (""    , self.VVnWyn , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVmBED  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, VVt6tD=VVt6tD, VV9CSs=VV9CSs, VVk5TH=VVk5TH)
  else:
   FF9glI(self, "History is empty.", title=title)
 def VV7j5g(self, VVt27A, title, txt, colList):
  FFHFXk(VVt27A, colList[3], VVLARq=False, checkParentalControl=True)
 def VVh94w(self, VVt27A, title, txt, colList):
  FFo32K(self, BF(self.VVgn4S, VVt27A), "Clear Zap History ?")
 def VVgn4S(self, VVt27A):
  self.VVrCyc()
  VVt27A.cancel()
 def VVnWyn(self, VVt27A, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFjcFt(self, fncMode=CCOQON.VV4HVt, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVhaju():
  try:
   global VVObca
   if VVObca is None:
    VVObca    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCU9He.VVdWe2
   ChannelContextMenu.VVhVYs = CCU9He.VVhVYs
  except:
   pass
 @staticmethod
 def VVdWe2(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVObca(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   t = ( PLUGIN_NAME + " - Channels Browser"
    , PLUGIN_NAME + " - Find"
    , PLUGIN_NAME + " - Channels Tools"  )
   for i in range(3):
    SELF["menu"].list.insert(i, ChoiceEntryComponent(key=" ", text=(t[i] , BF(SELF.VVhVYs, t[i], csel, mode=i))))
 @staticmethod
 def VVhVYs(self, title, csel, mode):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFettQ(refCode)
  except:
   refCode = refName = ""
  if mode == 0: CCSBZP.VVkE4M(self)
  else  : self.session.open(BF(CCU9He, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False))
  self.close()
class CCHnG6(Screen, CCacgq, CC87TJ):
 VVvqAz   = 0
 VVCsBt  = 1
 VVgaat  = 2
 VV5HcU  = 3
 VVypQ0  = 4
 VVSTh0  = 5
 VVG4kc  = 6
 VVlnyb  = 7
 VVj4Na = 8
 VVThAW = 9
 VVZIUp = 10
 VVx5tX = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VVDE1v, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCHnG6.VVYipk()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVI2kC    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FF74S2(self, self.Title)
  FFFQrh(self["keyRed"] , "OK = Zap")
  FFFQrh(self["keyGreen"] , "Current Service")
  FFFQrh(self["keyYellow"], "Page Options")
  FFFQrh(self["keyBlue"] , "Filter")
  CCacgq.__init__(self, 5, 7, CFG.transpColorPicons)
  CC87TJ.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVCkgK     ,
   "green"  : self.VVEQQb    ,
   "yellow" : self.VVzTCO     ,
   "blue"  : self.VVFPDo     ,
   "menu"  : self.VVh5Vn     ,
   "info"  : self.VVkYIa    ,
   "pageUp" : BF(self.VVgtgj, True) ,
   "chanUp" : BF(self.VVgtgj, True) ,
   "pageDown" : BF(self.VVgtgj, False) ,
   "chanDown" : BF(self.VVgtgj, False) ,
   "0"   : self.VV0ud4  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  FFtJRK(self)
  FFIY0q(self["keyRed"], "#0a333333")
  self.VVv8AZ()
  FF0GsP(self, BF(self.VVcWHI, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVh5Vn(self):
  if not self.isBusy:
   VV8kKb = []
   VV8kKb.append(("Statistics"           , "VViF4X"    ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Suggest PIcons for Current Channel"     , "VVbPgX"   ))
   VV8kKb.append(("Set to Current Channel (copy file)"     , "VVnDzd_file"  ))
   VV8kKb.append(("Set to Current Channel (as SymLink)"     , "VVnDzd_link"  ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Export Current File Names List"      , "VV0jrY" ))
   VV8kKb.append(CCHnG6.VV00tx())
   VV8kKb.append(VVnK97)
   c, cond = VVvkGK, self.filterTitle == "PIcons without Channels"
   VV8kKb.append(FF4UJX("Move Unused PIcons to a Directory", "VV4e5P" , cond, c))
   VV8kKb.append(FF4UJX("DELETE Unused PIcons"    , "VVOzjb" , cond, c))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVoegX"  ))
   VV8kKb.append(VVnK97)
   VV8kKb += CCHnG6.VVdTfr()
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Change Poster/Picon Transparency Color"    , "VV9jRx" ))
   VV8kKb.append(("Keys Help"           , "VVkfS7"    ))
   FFHAbB(self, self.VVZ0gv, width=1100, height=1050, title=self.Title, VV8kKb=VV8kKb)
 def VVZ0gv(self, item=None):
  if item is not None:
   if   item == "VViF4X"    : self.VViF4X()
   elif item == "VVbPgX"   : self.VVbPgX()
   elif item == "VVnDzd_file"  : self.VVnDzd(0)
   elif item == "VVnDzd_link"  : self.VVnDzd(1)
   elif item == "VV0jrY"  : self.VV0jrY()
   elif item == "VV6LB2"  : CCHnG6.VV6LB2(self)
   elif item == "VV4e5P"   : self.VV4e5P()
   elif item == "VVOzjb"  : self.VVOzjb()
   elif item == "VVoegX"  : self.VVoegX()
   elif item == "VVkXbW"  : CCHnG6.VVkXbW(self)
   elif item == "findPiconBrokenSymLinks" : CCHnG6.VVvQTB(self, True)
   elif item == "FindAllBrokenSymLinks" : CCHnG6.VVvQTB(self, False)
   elif item == "VV9jRx" : self.VV9jRx()
   elif item == "VVkfS7"     : FFZzIv(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVzTCO(self):
  if not self.isBusy:
   VV8kKb = []
   VV8kKb.append(("Go to First PIcon"  , "VVBhNl"  ))
   VV8kKb.append(("Go to Last PIcon"   , "VVTdvq"  ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Sort by Channel Name"     , "sortByChan" ))
   VV8kKb.append(("Sort by File Name"  , "sortByFile" ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Find from File List .." , "VVpeVg" ))
   FFHAbB(self, self.VV3iC2, title=self.Title, VV8kKb=VV8kKb)
 def VV3iC2(self, item=None):
  if item is not None:
   if   item == "VVBhNl"   : self.VVBhNl()
   elif item == "VVTdvq"   : self.VVTdvq()
   elif item == "sortByChan"  : self.VVlqlm(2)
   elif item == "sortByFile"  : self.VVlqlm(0)
   elif item == "VVpeVg"  : self.VVpeVg()
 def VVpeVg(self):
  VV8kKb = []
  for item in self.VVI2kC:
   VV8kKb.append((item[0], item[0]))
  FFHAbB(self, self.VVzE7p, title='PIcons ".png" Files', VV8kKb=VV8kKb, VVPYdF=True)
 def VVzE7p(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVmtwJ(ndx)
 def VVCkgK(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVAoTs()
   if refCode:
    FFHFXk(self, refCode)
    self.VVCz48()
    self.VVxd9A()
 def VVgtgj(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVCz48()
   self.VVxd9A()
  except:
   pass
 def VVEQQb(self):
  if self["keyGreen"].getVisible():
   self.VVmtwJ(self.curChanIndex)
 def VVlqlm(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF0GsP(self, BF(self.VVcWHI, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVnDzd(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVAoTs()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VV8kKb = []
     VV8kKb.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VV8kKb.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFHAbB(self, BF(self.VVV3KX, mode, curChF, selPiconF), VV8kKb=VV8kKb, title="Current Channel PIcon (already exists)")
    else:
     self.VVV3KX(mode, curChF, selPiconF, "overwrite")
   else:
    FFrj68(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFrj68(self, "Could not read current channel info. !", title=title)
 def VVV3KX(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFWnHJ(cmd)
   FF0GsP(self, BF(self.VVcWHI, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VV4e5P(self):
  defDir = FFxiJi(CCHnG6.VVYipk() + "picons_backup")
  FFWnHJ("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVCcLN, defDir), BF(CCFric
         , mode=CCFric.VVocwE, VVZmiW=CCHnG6.VVYipk()))
 def VVCcLN(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCHnG6.VVYipk():
    FFrj68(self, "Cannot move to same directory !", title=title)
   else:
    if not FFxiJi(path) == FFxiJi(defDir):
     self.VVUVkn(defDir)
    FFo32K(self, BF(FF0GsP, self, BF(self.VVBNDC, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVI2kC), path), title=title)
  else:
   self.VVUVkn(defDir)
 def VVBNDC(self, title, defDir, toPath):
  if not iMove:
   self.VVUVkn(defDir)
   FFrj68(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFxiJi(toPath)
  pPath = CCHnG6.VVYipk()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVI2kC:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVI2kC)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFaIgn(self, txt, title=title, VV2ftx="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVdL7r("all")
 def VVUVkn(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVOzjb(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVI2kC)
  FFo32K(self, BF(FF0GsP, self, BF(self.VVDnGb, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FF7O1V(tot)), title=title)
 def VVDnGb(self, title):
  pPath = CCHnG6.VVYipk()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVI2kC:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVI2kC)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF7kJS(str(totErr), VVSBcQ)
  FFaIgn(self, txt, title=title)
 def VVoegX(self):
  lines = FFO8C9("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFo32K(self, BF(self.VVgbWi, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FF7O1V(tot)), VVjDSl=True)
  else:
   FF9glI(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVgbWi(self, fList):
  FFWnHJ("find -L '%s' -type l -delete" % self.pPath)
  FF9glI(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVkYIa(self):
  FF0GsP(self, self.VVs2eV)
 def VVs2eV(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVAoTs()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF7kJS("PIcon Directory:\n", VVZkFQ)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFjpIf(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFjpIf(path)
   txt += FF7kJS("PIcon File:\n", VVZkFQ)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FF7kJS("Found %d SymLink%s to this file from:\n" % (tot, FF7O1V(tot)), VVZkFQ)
     for fPath in slLst:
      txt += "  %s\n" % FF7kJS(fPath, VViSml)
     txt += "\n"
   if chName:
    txt += FF7kJS("Channel:\n", VVZkFQ)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF7kJS(chName, VVomgc)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FF7kJS("Remarks:\n", VVZkFQ)
    txt += "  %s\n" % FF7kJS("Unused", VVSBcQ)
  else:
   txt = "No info found"
  FFjcFt(self, fncMode=CCOQON.VVSMmD, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVAoTs(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVI2kC[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFhxEM(sat)
  return fName, refCode, chName, sat, inDB
 def VVCz48(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVI2kC):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVxd9A(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVAoTs()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF7kJS("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVZkFQ))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVAoTs()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFIkRt(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF7kJS(self.curChanName, VV691Y)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVAoTs()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VViF4X(self):
  VVxlaR, VViowm = FFRmby()
  sTypeNameDict = {}
  for key, val in VViowm.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVI2kC:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VViowm: sTypeDict[VViowm[stNum]] = sTypeDict.get(VViowm[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFdVkh("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVDb2Q = []
  c = "#b#11003333#"
  VVDb2Q.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVDb2Q.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVDb2Q.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVDb2Q.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVDb2Q.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVDb2Q.append((c + "Satellites"    , str(len(self.nsList))))
  VVDb2Q.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVDb2Q.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVDb2Q.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVDb2Q.extend(sTypeRows)
  FFyZJ5(self, None, title=self.Title, VVI2kC=VVDb2Q, VVC5IT=28, VVgjmd="#00003333", VVZ0ud="#00222222")
 def VV0jrY(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFxiJi(CFG.exportedTablesPath.getValue()), txt, FFC2jX())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVI2kC:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF9glI(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVFPDo(self):
  if not self.isBusy:
   VV8kKb = []
   VV8kKb.append(("All"        , "all"  ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Used by Channels"     , "used" ))
   VV8kKb.append(("Unused PIcons"     , "unused" ))
   VV8kKb.append(("IPTV PIcons"      , "iptv" ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("PIcons Files"      , "pFiles" ))
   VV8kKb.append(("SymLinks to PIcons"    , "pLinks" ))
   VV8kKb.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VV8kKb.append(("By Files Date ..."    , "pDate" ))
   VV8kKb.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VV8kKb.append(FFDGmo("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFcuvM(val)
      VV8kKb.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCkJDN(self)
   filterObj.VVjxij(VV8kKb, self.nsList, self.VVmtDE)
 def VVmtDE(self, item=None):
  if item is not None:
   self.VVdL7r(item)
 def VVdL7r(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVvqAz   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVCsBt   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVgaat  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVG4kc   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VV5HcU  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVypQ0  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVSTh0  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVZIUp , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVx5tX , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVlnyb   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVj4Na , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVSTh0:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFO8C9("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFM4mE(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFAM12(self, "Not found", 1000)
     return
   elif mode == self.VVZIUp:
    self.VVk5KK(mode)
    return
   elif mode == self.VVx5tX:
    self.VVujOu(mode)
    return
   elif mode == self.VVThAW:
    return
   else:
    words, asPrefix = CCkJDN.VVN7mE(words)
   if not words and mode in (self.VVlnyb, self.VVj4Na):
    FFAM12(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF0GsP(self, BF(self.VVcWHI, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVk5KK(self, mode):
  VV8kKb = []
  VV8kKb.append(("Today"   , "today" ))
  VV8kKb.append(("Since Yesterday" , "yest" ))
  VV8kKb.append(("Since 7 days"  , "week" ))
  FFHAbB(self, BF(self.VVjRza, mode), VV8kKb=VV8kKb, title="Filter by Added/Modified Date")
 def VVjRza(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFVK8S(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFVK8S(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFVK8S(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FF0GsP(self, BF(self.VVcWHI, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVujOu(self, mode):
  VVxlaR, VViowm = FFRmby()
  lst = set()
  for key, val in VViowm.items():
   lst.add(val)
  VV8kKb = []
  for item in lst:
   VV8kKb.append((item, item))
  VV8kKb.sort(key=lambda x: x[0])
  FFHAbB(self, BF(self.VV25DR, mode), VV8kKb=VV8kKb, title="Filter by Service Type")
 def VV25DR(self, mode, item=None):
  if item:
   VVxlaR, VViowm = FFRmby()
   sTypeList = []
   for key, val in VViowm.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FF0GsP(self, BF(self.VVcWHI, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVbPgX(self):
  self.session.open(CCfhQr, barTheme=CCfhQr.VVZYJm
      , titlePrefix = ""
      , fncToRun  = self.VVaC3a
      , VVVnlJ = self.VVuGQb)
 def VVaC3a(self, VVtEPC):
  VVS5P4, err = CCGJtF.VV2Ohl(self, CCGJtF.VVgToU, VVfYV4=False, VV9iqe=False)
  files = []
  words = []
  if not VVtEPC or VVtEPC.isCancelled:
   return
  VVtEPC.VVsc2i = []
  VVtEPC.VVodiL(len(VVS5P4))
  if VVS5P4:
   curCh = self.VVM385(self.curChanName)
   for refCode in VVS5P4:
    if not VVtEPC or VVtEPC.isCancelled:
     return
    VVtEPC.VV2Wgw(1, True)
    chName, sat, inDB = VVS5P4.get(refCode, ("", "", 0))
    ratio = CCHnG6.VV6cgu(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCHnG6.VVb8Me(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFM4mE(f)
       fil = f.replace(".png", "")
       if not fil in VVtEPC.VVsc2i:
        VVtEPC.VVsc2i.append(fil)
 def VVuGQb(self, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  if VVsc2i : FF0GsP(self, BF(self.VVcWHI, mode=self.VVThAW, words=VVsc2i), title="Loading ...")
  else   : FFAM12(self, "Not found", 2000)
 def VVcWHI(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVwHdA(isFirstTime):
   return
  self.isBusy = True
  VV9iqe = True if isFirstTime else False
  VVS5P4, err = CCGJtF.VV2Ohl(self, CCGJtF.VVgToU, VVfYV4=False, VV9iqe=VV9iqe)
  if err:
   self.close()
  iptvRefList = self.VV5yub()
  tList = []
  for fName, fType in CCHnG6.VVgzfz(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVS5P4:
    if fName in VVS5P4:
     chName, sat, inDB = VVS5P4.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVvqAz:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVCsBt  and chName         : isAdd = True
   elif mode == self.VVgaat and not chName        : isAdd = True
   elif mode == self.VV5HcU  and fType == 0        : isAdd = True
   elif mode == self.VVypQ0  and fType == 1        : isAdd = True
   elif mode == self.VVSTh0  and fName in words       : isAdd = True
   elif mode == self.VVThAW and fName in words       : isAdd = True
   elif mode == self.VVG4kc  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVlnyb  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVj4Na:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVZIUp:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVx5tX:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVI2kC   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFAM12(self)
  else:
   self.isBusy = False
   FFAM12(self, "Not found", 1000)
   return
  self.VVI2kC.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVCz48()
  self.totalItems = len(self.VVI2kC)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVZbHt(True)
 def VVwHdA(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCHnG6.VVgzfz(self.pPath):
    if fName:
     return True
   if isFirstTime : FFrj68(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFAM12(self, "Not found", 1000)
  else:
   FFrj68(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV5yub(self):
  VVDb2Q = {}
  files  = CC1B0Q.VVqr8J()
  if files:
   for path in files:
    txt = FFQByV(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVDb2Q[refCode] = item[1]
  return VVDb2Q
 def VVGJTc(self):
  self.VViYjz()
  f1, f2 = self.VVHtGL()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVI2kC[ndx]
   fName = self.VVI2kC[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCacgq.VVDyT6(pic, path) : color = VVomgc if inDB else ""
   elif not chName           : color = ""
   else             : color = VVrexq
   self.VVnBTw(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV6cgu(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV00tx():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VV6LB2")
 @staticmethod
 def VVdTfr():
  VV8kKb = []
  VV8kKb.append(("Find SymLinks (to PIcon Directory)"   , "VVkXbW"  ))
  VV8kKb.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VV8kKb.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VV8kKb
 @staticmethod
 def VV6LB2(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF)
  png, path = CCHnG6.VVp0Sq(refCode)
  if path : CCHnG6.VVwqgp(SELF, png, path)
  else : FFrj68(SELF, "No PIcon found for current channel in:\n\n%s" % CCHnG6.VVYipk())
 @staticmethod
 def VVkXbW(SELF):
  if VV691Y:
   sed1 = FFQQct("->", VV691Y)
   sed2 = FFQQct("picon", VVSBcQ)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVrexq, VVkbX3)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFTJt5(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFViIp(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVvQTB(SELF, isPIcon):
  sed1 = FFQQct("->", VVrexq)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFQQct("picon", VVSBcQ)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFTJt5(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFViIp(), grep, sed1, sed2))
 @staticmethod
 def VVwqgp(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFQQct("%s%s" % (dest, png), VVomgc))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFQQct(errTxt, VVD6mq))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFX3ck(SELF, cmd)
 @staticmethod
 def VVgzfz(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVYipk():
  path = CFG.PIconsPath.getValue()
  return FFxiJi(path)
 @staticmethod
 def VVp0Sq(refCode, chName=None):
  if FF8yv3(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFWeS7(refCode)
  allPath, fName, refCodeFile, pList = CCHnG6.VVb8Me(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VV0eNP(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CC1B0Q.VVS2HJ():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFJYbZ(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVb8Me(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCHnG6.VVYipk()
   pList = []
   lst = FFYaSE(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFJYbZ(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFM4mE(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCR66A():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVPdwD  = None
  self.VVpn4S = ""
  self.VVxEix  = noService
  self.VVaPl2 = 0
  self.VVHxwu  = noService
  self.VVxHpr = 0
  self.VVIBoZ  = "-"
  self.VVuFyS = 0
  self.VVe06m  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVq9Hb(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVPdwD = frontEndStatus
     self.VV9yhd()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV9yhd(self):
  if self.VVPdwD:
   val = self.VVPdwD.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVpn4S = "%3.02f dB" % (val / 100.0)
   else         : self.VVpn4S = ""
   val = self.VVPdwD.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVaPl2 = int(val)
   self.VVxEix  = "%d%%" % val
   val = self.VVPdwD.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVxHpr = int(val)
   self.VVHxwu  = "%d%%" % val
   val = self.VVPdwD.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVIBoZ  = "%d" % val
   val = int(val * 100 / 500)
   self.VVuFyS = min(500, val)
   val = self.VVPdwD.get("tuner_locked", 0)
   if val == 1 : self.VVe06m = "Locked"
   else  : self.VVe06m = "Not locked"
 def VVJeLL(self)   : return self.VVpn4S
 def VV6CFH(self)   : return self.VVxEix
 def VV2LuL(self)  : return self.VVaPl2
 def VV6eR8(self)   : return self.VVHxwu
 def VVxYTK(self)  : return self.VVxHpr
 def VVAywF(self)   : return self.VVIBoZ
 def VVyUE2(self)  : return self.VVuFyS
 def VVhk3b(self)   : return self.VVe06m
 def VVacGq(self) : return self.serviceName
class CC5k8k():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVM4Q0(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FF9nVY(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVky2b(self.ORPOS  , mod=1   )
      self.sat2  = self.VVky2b(self.ORPOS  , mod=2   )
      self.freq  = self.VVky2b(self.FREQ  , mod=3   )
      self.sr   = self.VVky2b(self.SR   , mod=4   )
      self.inv  = self.VVky2b(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVky2b(self.POL  , self.D_POL )
      self.fec  = self.VVky2b(self.FEC  , self.D_FEC )
      self.syst  = self.VVky2b(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVky2b("modulation" , self.D_MOD )
       self.rolof = self.VVky2b("rolloff"  , self.D_ROLOF )
       self.pil = self.VVky2b("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVky2b("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVky2b("pls_code"  )
       self.iStId = self.VVky2b("is_id"   )
       self.t2PlId = self.VVky2b("t2mi_plp_id" )
       self.t2PId = self.VVky2b("t2mi_pid"  )
 def VVky2b(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFcuvM(val)
  elif mod == 2   : return FFVZIv(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVupR4(self, refCode):
  txt = ""
  self.VVM4Q0(refCode)
  if self.data:
   def VVPmyh(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVPmyh("System"   , self.syst)
    txt += VVPmyh("Satellite"  , self.sat2)
    txt += VVPmyh("Frequency"  , self.freq)
    txt += VVPmyh("Inversion"  , self.inv)
    txt += VVPmyh("Symbol Rate"  , self.sr)
    txt += VVPmyh("Polarization" , self.pol)
    txt += VVPmyh("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVPmyh("Modulation" , self.mod)
     txt += VVPmyh("Roll-Off" , self.rolof)
     txt += VVPmyh("Pilot"  , self.pil)
     txt += VVPmyh("Input Stream", self.iStId)
     txt += VVPmyh("T2MI PLP ID" , self.t2PlId)
     txt += VVPmyh("T2MI PID" , self.t2PId)
     txt += VVPmyh("PLS Mode" , self.plsMod)
     txt += VVPmyh("PLS Code" , self.plsCod)
   else:
    txt += VVPmyh("System"   , self.txMedia)
    txt += VVPmyh("Frequency"  , self.freq)
  return txt, self.namespace
 def VVdkYB(self, refCode):
  txt = "Transpoder : ?"
  self.VVM4Q0(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVBfDu(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FF9nVY(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVky2b(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVky2b(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVky2b(self.SYST, self.D_SYS_S)
     freq = self.VVky2b(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVky2b(self.POL , self.D_POL)
      fec = self.VVky2b(self.FEC , self.D_FEC)
      sr = self.VVky2b(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV19v8(self, refCode):
  self.data = None
  self.VVM4Q0(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCAoYu():
 def __init__(self, VVYCBi, path, VVVnlJ=None, curRowNum=-1):
  self.VVYCBi  = VVYCBi
  self.origFile   = path
  self.Title    = "File Editor: " + FFM4mE(path)
  self.VVVnlJ  = VVVnlJ
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  if FFWnHJ("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FF0GsP(self.VVYCBi, BF(self.VVCIOI, curRowNum), title="Loading file ...")
  else:
   FFrj68(self.VVYCBi, "Error while preparing edit!")
 def VVCIOI(self, curRowNum):
  VVDb2Q = self.VV61VO()
  VVaq9G = ("Save Changes" , self.VVOdwy   , [])
  VVt6tD  = ("Edit Line"  , self.VVhiOg    , [])
  VV9CSs = ("Go to Line Num" , self.VV2npA   , [])
  VVTO3h = ("Line Options" , self.VVfTFY   , [])
  VVZApD = (""    , self.VVykhq , [])
  VVqFCi = self.VVQ68J
  VVOY6r  = self.VV65xp
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVmBED  = (CENTER  , LEFT  )
  VVt27A = FFyZJ5(self.VVYCBi, None, title=self.Title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVaq9G=VVaq9G, VVt6tD=VVt6tD, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVqFCi=VVqFCi, VVOY6r=VVOY6r, VVZApD=VVZApD, VV2v46=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVuGSD   = "#11001111"
    , VVO7CL   = "#11001111"
    , VV2ftx   = "#11001111"
    , VVgjmd  = "#05333333"
    , VVZ0ud  = "#00222222"
    , VVGQoh  = "#11331133"
    )
  VVt27A.VVagt1(curRowNum)
 def VV2npA(self, VVt27A, title, txt, colList):
  totRows = VVt27A.VV9aLU()
  lineNum = VVt27A.VV2fe8() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFTtos(self.VVYCBi, BF(self.VVvZqM, VVt27A, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVvZqM(self, VVt27A, lineNum, totRows, VVPnAy):
  if VVPnAy:
   VVPnAy = VVPnAy.strip()
   if VVPnAy.isdigit():
    num = FFB9GB(int(VVPnAy) - 1, 0, totRows)
    VVt27A.VVagt1(num)
    self.lastLineNum = num + 1
   else:
    FFAM12(VVt27A, "Incorrect number", 1500)
 def VVfTFY(self, VVt27A, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVt27A.VVXdnH()
  VV8kKb = []
  VV8kKb.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VV8kKb.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVGCKr"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVvnxr:
   VV8kKb.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(  ("Delete Line"         , "deleteLine"   ))
  FFHAbB(self.VVYCBi, BF(self.VVgdQn, VVt27A, lineNum), VV8kKb=VV8kKb, title="Line Options")
 def VVgdQn(self, VVt27A, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVxYVj("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVt27A)
   elif item == "VVGCKr"  : self.VVGCKr(VVt27A, lineNum)
   elif item == "copyToClipboard"  : self.VV8II7(VVt27A, lineNum)
   elif item == "pasteFromClipboard" : self.VVi8xu(VVt27A, lineNum)
   elif item == "deleteLine"   : self.VVxYVj("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVt27A)
 def VV65xp(self, VVt27A):
  VVt27A.VV7bts()
 def VVykhq(self, VVt27A, title, txt, colList):
  if   self.insertMode == 1: VVt27A.VVdCmE()
  elif self.insertMode == 2: VVt27A.VVgusi()
  self.insertMode = 0
 def VVGCKr(self, VVt27A, lineNum):
  if lineNum == VVt27A.VVXdnH():
   self.insertMode = 1
   self.VVxYVj("echo '' >> '%s'" % self.tmpFile, VVt27A)
  else:
   self.insertMode = 2
   self.VVxYVj("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVt27A)
 def VV8II7(self, VVt27A, lineNum):
  global VVvnxr
  VVvnxr = FFdVkh("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVt27A.VVq4Rc("Copied to clipboard")
 def VVOdwy(self, VVt27A, title, txt, colList):
  if self.fileChanged:
   if FFyRfT(self.origFile):
    if FFWnHJ("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVt27A.VVq4Rc("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVt27A.VV7bts()
    else:
     FFrj68(self.VVYCBi, "Cannot save file!")
   else:
    FFrj68(self.VVYCBi, "Cannot create backup copy of original file!")
 def VVQ68J(self, VVt27A):
  if self.fileChanged:
   FFo32K(self.VVYCBi, BF(self.VVvNt8, VVt27A), "Cancel changes ?")
  else:
   FFWnHJ("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVvNt8(VVt27A)
 def VVvNt8(self, VVt27A):
  VVt27A.cancel()
  FFfIuR(self.tmpFile)
  if self.VVVnlJ:
   self.VVVnlJ(self.fileSaved)
 def VVhiOg(self, VVt27A, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVkbX3 + "ORIGINAL TEXT:\n" + VViSml + lineTxt
  FFTtos(self.VVYCBi, BF(self.VVZrKw, lineNum, VVt27A), title="File Line", defaultText=lineTxt, message=message)
 def VVZrKw(self, lineNum, VVt27A, VVPnAy):
  if not VVPnAy is None:
   if VVt27A.VVXdnH() <= 1:
    self.VVxYVj("echo %s > '%s'" % (VVPnAy, self.tmpFile), VVt27A)
   else:
    self.VVoMF9(VVt27A, lineNum, VVPnAy)
 def VVi8xu(self, VVt27A, lineNum):
  if lineNum == VVt27A.VVXdnH() and VVt27A.VVXdnH() == 1:
   self.VVxYVj("echo %s >> '%s'" % (VVvnxr, self.tmpFile), VVt27A)
  else:
   self.VVoMF9(VVt27A, lineNum, VVvnxr)
 def VVoMF9(self, VVt27A, lineNum, newTxt):
  VVt27A.VVHSZd("Saving ...")
  lines = FFKcIu(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVt27A.VVSavX()
  VVDb2Q = self.VV61VO()
  VVt27A.VVByC5(VVDb2Q)
 def VVxYVj(self, cmd, VVt27A):
  tCons = CClZCM()
  tCons.ePopen(cmd, BF(self.VVFo3t, VVt27A))
  self.fileChanged = True
  VVt27A.VVSavX()
 def VVFo3t(self, VVt27A, result, retval):
  VVDb2Q = self.VV61VO()
  VVt27A.VVByC5(VVDb2Q)
 def VV61VO(self):
  if fileExists(self.tmpFile):
   lines = FFKcIu(self.tmpFile)
   VVDb2Q = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVDb2Q.append((str(ndx), line.strip()))
   if not VVDb2Q:
    VVDb2Q.append((str(1), ""))
   return VVDb2Q
  else:
   FFiEaB(self.VVYCBi, self.tmpFile)
class CCkJDN():
 def __init__(self, callingSELF, VVuGSD="#22003344", VVO7CL="#22002233"):
  self.callingSELF = callingSELF
  self.VV8kKb  = []
  self.satList  = []
  self.VVuGSD  = VVuGSD
  self.VVO7CL   = VVO7CL
 def VVSaNO(self, VVVnlJ):
  self.VV8kKb = []
  VV8kKb, VVABDr = CCkJDN.VVbAkW(self.callingSELF, False, True)
  if VV8kKb:
   self.VV8kKb += VV8kKb
   self.VV0gzU(VVVnlJ, VVABDr)
 def VVOKj4(self, mode, VVt27A, satCol, VVVnlJ, inFilterFnc=None):
  VVt27A.VVHSZd("Loading Filters ...")
  self.VV8kKb = []
  self.VV8kKb.append(("All Services" , "all"))
  if mode == 1:
   self.VV8kKb.append(VVnK97)
   self.VV8kKb.append(("Parental Control", "parentalControl" ))
   self.VV8kKb.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VV8kKb.append(VVnK97)
   self.VV8kKb.append(("Selected Transponder"   , "selectedTP" ))
   self.VV8kKb.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVFtvD(VVt27A, satCol)
  VV8kKb, VVABDr = CCkJDN.VVbAkW(self.callingSELF, True, False)
  if VV8kKb:
   VV8kKb.insert(0, FFDGmo("Custom Words"))
   self.VV8kKb += VV8kKb
  VVt27A.VVtIYK()
  self.VV0gzU(VVVnlJ, VVABDr, inFilterFnc)
 def VVjxij(self, VV8kKb, sats, VVVnlJ, inFilterFnc=None):
  self.VV8kKb = VV8kKb
  VV8kKb, VVABDr = CCkJDN.VVbAkW(self.callingSELF, True, False)
  if VV8kKb:
   self.VV8kKb.append(FFDGmo("Custom Words"))
   self.VV8kKb += VV8kKb
  self.VV0gzU(VVVnlJ, VVABDr, inFilterFnc)
 def VV0gzU(self, VVVnlJ, VVABDr, inFilterFnc=None):
  VV0MQu  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVinPK = ("Edit Filter"  , BF(self.VV5DKB, VVABDr))
  VVcx0D  = ("Filter Help"  , BF(self.VVzD6J, VVABDr))
  FFHAbB(self.callingSELF, BF(self.VVcKBE, VVVnlJ), VV8kKb=self.VV8kKb, title="Select Filter", VV0MQu=VV0MQu, VVinPK=VVinPK, VVcx0D=VVcx0D, VVWQ3x=True, VVuGSD=self.VVuGSD, VVO7CL=self.VVO7CL)
 def VVcKBE(self, VVVnlJ, item):
  if item:
   VVVnlJ(item)
 def VV5DKB(self, VVABDr, VV476KObj, sel):
  if fileExists(VVABDr) : CCAoYu(self.callingSELF, VVABDr, VVVnlJ=None)
  else       : FFiEaB(self.callingSELF, VVABDr)
  VV476KObj.cancel()
 def VVzD6J(self, VVABDr, VV476KObj, sel):
  FFZzIv(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVFtvD(self, VVt27A, satColNum):
  if not self.satList:
   satList = VVt27A.VVsdoi(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFhxEM(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFDGmo("Satellites"))
  if self.VV8kKb:
   self.VV8kKb += self.satList
 @staticmethod
 def VVbAkW(SELF, addTag, VVSOst):
  FFpVsc()
  fileName  = "ajpanel_services_filter"
  VVABDr = VVBI3c + fileName
  VV8kKb  = []
  if not fileExists(VVABDr):
   FFWnHJ("cp -f '%s' '%s'" % (VV8hpn + fileName, VVABDr))
  fileFound = False
  if fileExists(VVABDr):
   fileFound = True
   lines = FFKcIu(VVABDr)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VV8kKb.append((line, "__w__" + line))
       else  : VV8kKb.append((line, line))
  if VVSOst:
   if   not fileFound : FFiEaB(SELF, VVABDr)
   elif not VV8kKb : FFerNJ(SELF, VVABDr)
  return VV8kKb, VVABDr
 @staticmethod
 def VVN7mE(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CC9SG5():
 def __init__(self, callingSELF, VVt27A, addSep=True):
  self.callingSELF = callingSELF
  self.VVt27A = VVt27A
  self.VV8kKb = []
  iMulSel = self.VVt27A.VVMhgy()
  if iMulSel : self.VV8kKb.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VV8kKb.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVt27A.VVWJ0c()
  self.VV8kKb.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VV8kKb.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VV8kKb.append(VVnK97)
 def VVV2XD(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VV8kKb.extend(extraMenu)
  FFHAbB(self.callingSELF, BF(self.VVfF4q, cbFncDict, okFnc), width=width, title="Options", VV8kKb=self.VV8kKb)
 def VVfF4q(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVt27A.VV5XOs(True)
   elif item == "MultSelDisab" : self.VVt27A.VV5XOs(False)
   elif item == "selectAll" : self.VVt27A.VVOqXS()
   elif item == "unselectAll" : self.VVt27A.VVWiLk()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCCO9V(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVZbiC, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF74S2(self)
  FFFQrh(self["keyRed"]  , "Exit")
  FFFQrh(self["keyGreen"]  , "Save")
  FFFQrh(self["keyYellow"] , "Refresh")
  FFFQrh(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVss0c  ,
   "green" : self.VVf08A ,
   "yellow": self.VVWQ9J  ,
   "blue" : self.VVKTwo   ,
   "up" : self.VVwG1X    ,
   "down" : self.VVh50n   ,
   "left" : self.VVAwoe   ,
   "right" : self.VVhFYt   ,
   "cancel": self.VVss0c
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self.VVWQ9J()
  self.VVX0zU()
  FFtJRK(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV3zdK)
  except:
   self.timer.callback.append(self.VV3zdK)
  self.timer.start(1000, False)
  self.VV3zdK()
 def onExit(self):
  self.timer.stop()
 def VVss0c(self) : self.close(True)
 def VV0a82(self) : self.close(False)
 def VVKTwo(self):
  self.session.openWithCallback(self.VV8aUB, BF(CCK8kc))
 def VV8aUB(self, closeAll):
  if closeAll:
   self.close()
 def VV3zdK(self):
  self["curTime"].setText(str(FFDwGN(iTime())))
 def VVwG1X(self):
  self.VVbYFz(1)
 def VVh50n(self):
  self.VVbYFz(-1)
 def VVAwoe(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVX0zU()
 def VVhFYt(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVX0zU()
 def VVbYFz(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVaz1C(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVaz1C(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVaz1C(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV2ZyG(year)):
   days += 1
  return days
 def VV2ZyG(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVX0zU(self):
  for obj in self.list:
   FFIY0q(obj, "#11404040")
  FFIY0q(self.list[self.index], "#11ff8000")
 def VVWQ9J(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVf08A(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CClZCM()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVjScb)
 def VVjScb(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FF9glI(self, "Nothing returned from the system!")
  else    : FF9glI(self, str(result))
class CCK8kc(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VV1QnR, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF74S2(self, addLabel=True)
  FFFQrh(self["keyRed"]  , "Exit")
  FFFQrh(self["keyGreen"]  , "Sync")
  FFFQrh(self["keyYellow"] , "Refresh")
  FFFQrh(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVss0c   ,
   "green" : self.VVXxSQ  ,
   "yellow": self.VVgMBs ,
   "blue" : self.VVVX0u  ,
   "cancel": self.VVss0c
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VV78xZ()
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  FFtJRK(self)
  FF2Wwv(self.VVQl82)
 def VVQl82(self):
  self.VVHQvx()
  self.VVayCB(False)
 def VVss0c(self)  : self.close(True)
 def VVVX0u(self) : self.close(False)
 def VV78xZ(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVHQvx(self):
  self.VV9dPh()
  self.VVfrDC()
  self.VVmThN()
  self.VVOBLt()
 def VVgMBs(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VV78xZ()
   self.VVHQvx()
   FF2Wwv(self.VVQl82)
 def VVXxSQ(self):
  if len(self["keyGreen"].getText()) > 0:
   FFo32K(self, self.VVNQ4k, "Synchronize with Internet Date/Time ?")
 def VVNQ4k(self):
  self.VVHQvx()
  FF2Wwv(BF(self.VVayCB, True))
 def VV9dPh(self)  : self["keyRed"].show()
 def VVVBKn(self)  : self["keyGreen"].show()
 def VVqDbG(self) : self["keyYellow"].show()
 def VV5UV0(self)  : self["keyBlue"].show()
 def VVfrDC(self)  : self["keyGreen"].hide()
 def VVmThN(self) : self["keyYellow"].hide()
 def VVOBLt(self)  : self["keyBlue"].hide()
 def VVayCB(self, sync):
  localTime = FFJMG5()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVBGq9(server)
   if epoch_time is not None:
    ntpTime = FFDwGN(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CClZCM()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVjScb, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVqDbG()
  self.VV5UV0()
  if ok:
   self.VVVBKn()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVjScb(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVayCB(False)
  except:
   pass
 def VVBGq9(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCiKm1.VVQ8ve():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CC0Jqs(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFpC8B(VVnSFr, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FF74S2(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FF2Wwv(self.VVWm0s)
 def VVWm0s(self):
  if CCiKm1.VVQ8ve() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFIY0q(self["myBody"], color)
   FFIY0q(self["myLabel"], color)
  except:
   pass
class CCCY2T(Screen):
 VVXsHw = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFKONN()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFpC8B(VVElI4, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCtUu0(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCtUu0(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCtUu0(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCR66A()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF74S2(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVwG1X       ,
   "down"  : self.VVh50n      ,
   "left"  : self.VVAwoe      ,
   "right"  : self.VVhFYt      ,
   "info"  : self.VVqcZq     ,
   "epg"  : self.VVqcZq     ,
   "menu"  : self.VVkfS7      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVebxy, -1)  ,
   "next"  : BF(self.VVebxy, 1)  ,
   "pageUp" : BF(self.VVWW0y, True) ,
   "chanUp" : BF(self.VVWW0y, True) ,
   "pageDown" : BF(self.VVWW0y, False) ,
   "chanDown" : BF(self.VVWW0y, False) ,
   "0"   : BF(self.VVebxy, 0)  ,
   "1"   : BF(self.VVczwL, pos=1) ,
   "2"   : BF(self.VVczwL, pos=2) ,
   "3"   : BF(self.VVczwL, pos=3) ,
   "4"   : BF(self.VVczwL, pos=4) ,
   "5"   : BF(self.VVczwL, pos=5) ,
   "6"   : BF(self.VVczwL, pos=6) ,
   "7"   : BF(self.VVczwL, pos=7) ,
   "8"   : BF(self.VVczwL, pos=8) ,
   "9"   : BF(self.VVczwL, pos=9) ,
  }, -1)
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  if not CCCY2T.VVXsHw:
   CCCY2T.VVXsHw = self
  self.sliderSNR.VVeVpG()
  self.sliderAGC.VVeVpG()
  self.sliderBER.VVeVpG(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVczwL()
  self.VVmIee()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV4uum)
  except:
   self.timer.callback.append(self.VV4uum)
  self.timer.start(500, False)
 def VVmIee(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVq9Hb(service)
  serviceName = self.tunerInfo.VVacGq()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  tp = CC5k8k()
  tpTxt, satTxt = tp.VVdkYB(refCode)
  if tpTxt == "?" :
   tpTxt = FF7kJS("NO SIGNAL", VVvkGK)
  self["myTPInfo"].setText(tpTxt + "  " + FF7kJS(satTxt, VVSFOM))
 def VV4uum(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVq9Hb(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVJeLL())
   self["mySNR"].setText(self.tunerInfo.VV6CFH())
   self["myAGC"].setText(self.tunerInfo.VV6eR8())
   self["myBER"].setText(self.tunerInfo.VVAywF())
   self.sliderSNR.VVvpNo(self.tunerInfo.VV2LuL())
   self.sliderAGC.VVvpNo(self.tunerInfo.VVxYTK())
   self.sliderBER.VVvpNo(self.tunerInfo.VVyUE2())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVvpNo(0)
   self.sliderAGC.VVvpNo(0)
   self.sliderBER.VVvpNo(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
    if state and not state == "Tuned":
     FFAM12(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVqcZq(self):
  FFjcFt(self, fncMode=CCOQON.VVkrMs)
 def VVkfS7(self):
  FFZzIv(self, "_help_signal", "Signal Monitor (Keys)")
 def VVwG1X(self)  : self.VVczwL(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVh50n(self) : self.VVczwL(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVAwoe(self) : self.VVczwL(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVhFYt(self) : self.VVczwL(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVczwL(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFaoHf(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVebxy(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFB9GB(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFaoHf(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCCY2T.VVXsHw = None
 def VVWW0y(self, isUp):
  FFAM12(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVmIee()
  except:
   pass
class CCtUu0(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVeVpG(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFIY0q(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV8hpn +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFIY0q(self.covObj, self.covColor)
   else:
    FFIY0q(self.covObj, "#00006688")
    self.isColormode = True
  self.VVvpNo(0)
 def VVvpNo(self, val):
  val  = FFB9GB(val, self.minN, self.maxN)
  width = int(FFFgzn(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFB9GB(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCfhQr(Screen):
 VVZYJm    = 0
 VVFWIs = 1
 VV1pfZ = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVVnlJ=None, barTheme=VVZYJm, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVsVjF(barTheme)
  self.skin, self.skinParam = FFpC8B(VVfADj, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVVnlJ = VVVnlJ
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVsc2i = None
  self.timer   = eTimer()
  self.myThread  = None
  FF74S2(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self.VVxgUi()
  self["myProgBarVal"].setText("0%")
  FFIY0q(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VV1F6t()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1F6t)
  except:
   self.timer.callback.append(self.VV1F6t)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVodiL(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVBeXP(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVsc2i), self.counter, self.maxValue, catName)
 def VVYhxi(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVkQ3L(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVXh2n(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVZDPe(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVWnCg(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVLHBp(self, txt):
  self.newTitle = txt
 def VV2Wgw(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVsc2i), self.counter, self.maxValue)
  except:
   pass
 def VVxEAf(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVx6LI(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVzEls(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFAM12(self, "Cancelling ...")
  self.isCancelled = True
  self.VVS0WF(False)
 def VVS0WF(self, isDone):
  FF2Wwv(BF(self.VV5hBu, isDone))
 def VV5hBu(self, isDone):
  if self.VVVnlJ:
   self.VVVnlJ(isDone, self.VVsc2i, self.counter, self.maxValue, self.isError)
  self.close()
 def VV1F6t(self):
  val = FFB9GB(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFFgzn(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVS0WF(True)
 def VVxgUi(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVFWIs, self.VV1pfZ):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVsVjF(self, barTheme):
  if   barTheme == self.VVFWIs : return 0.7
  if   barTheme == self.VV1pfZ : return 0.5
  else             : return 1
class CClZCM(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVVnlJ = {}
  self.commandRunning = False
  self.VVpmZd  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVVnlJ, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVVnlJ[name] = VVVnlJ
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVpmZd:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVj3bI, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVTHt0 , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVj3bI, name))
    self.appContainers[name].appClosed.append(BF(self.VVTHt0 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVTHt0(name, retval)
  return True
 def VVj3bI(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FF7kJS("[UN-DECODED STRING]", VVvkGK))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVTHt0(self, name, retval):
  if not self.VVpmZd:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVVnlJ[name]:
   self.VVVnlJ[name](self.appResults[name], retval)
  del self.VVVnlJ[name]
 def VVGm3h(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCkAox(Screen):
 def __init__(self, session, title="", VVfhG5=None, VVGqay=False, VVjBKV=False, VVWwHQ=False, VVMfsP=False, VVOVrJ=False, VVXnTt=False, VViXLk=VV1E5l, VVOc3A=None, VVwWtd=False, VVuQzu=None, VV3WWe="", checkNetAccess=False, VVC5IT=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFpC8B(VVECKd, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVC5IT, usefixedFont=consFont)
  self.session   = session
  self.VV3WWe = VV3WWe
  FF74S2(self, addScrollLabel=True)
  self.VVGqay   = VVGqay
  self.VVjBKV   = VVjBKV
  self.VVWwHQ   = VVWwHQ
  self.VVMfsP  = VVMfsP
  self.VVOVrJ = VVOVrJ
  self.VVXnTt = VVXnTt
  self.VViXLk   = VViXLk
  self.VVOc3A = VVOc3A
  self.VVwWtd  = VVwWtd
  self.VVuQzu  = VVuQzu
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CClZCM()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFyVZy()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVfhG5, str):
   self.VVfhG5 = [VVfhG5]
  else:
   self.VVfhG5 = VVfhG5
  if self.VVWwHQ or self.VVMfsP:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVfhG5.append("echo -e '\n%s\n' %s" % (restartNote, FFQQct(restartNote, VV691Y)))
   if self.VVWwHQ:
    self.VVfhG5.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVfhG5.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVOVrJ:
   FFAM12(self, "Processing ...")
  self.onLayoutFinish.append(self.VVH0Uh)
  self.onClose.append(self.VVewnP)
 def VVH0Uh(self):
  self["myLabel"].VVnulZ(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VV3WWe or "Processing ..."))
  if self.VVGqay:
   self["myLabel"].VVewHM()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVhick()
  else:
   self.VVePQr()
 def VVhick(self):
  if CCiKm1.VVQ8ve():
   self["myLabel"].setText("Processing ...")
   self.VVePQr()
  else:
   self["myLabel"].setText(FF7kJS("\n   No connection to internet!", VVSBcQ))
 def VVePQr(self):
  allOK = self.container.ePopen(self.VVfhG5[0], self.VVqBu4, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVqBu4("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVXnTt or self.VVWwHQ or self.VVMfsP:
    self["myLabel"].setText(FFXlM7("STARTED", VV691Y) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVuQzu:
   colorWhite = CCTWTN.VV0VOj(VVkbX3)
   color  = CCTWTN.VV0VOj(self.VVuQzu[0])
   words  = self.VVuQzu[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VViXLk=self.VViXLk)
 def VVqBu4(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVfhG5):
   allOK = self.container.ePopen(self.VVfhG5[self.cmdNum], self.VVqBu4, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVqBu4("Cannot connect to Console!", -1)
  else:
   if self.VVOVrJ and FFHGMZ(self):
    FFAM12(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVXnTt:
    self["myLabel"].appendText("\n" + FFXlM7("FINISHED", VV691Y), self.VViXLk)
   if self.VVGqay or self.VVjBKV:
    self["myLabel"].VVewHM()
   if self.VVOc3A is not None:
    self.VVOc3A()
   if not retval and self.VVwWtd:
    self.VVewnP()
 def VVewnP(self):
  if self.container.VVGm3h():
   self.container.killAll()
class CCm5ha(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VVECKd, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVBI3c + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFdVkh("pwd") or "/home/root"
  self.container   = CClZCM()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FF74S2(self, title="Terminal", addScrollLabel=True)
  FFFQrh(self["keyRed"] , self.exitBtnText)
  FFFQrh(self["keyGreen"] , "OK = History")
  FFFQrh(self["keyYellow"], "Menu = Custom Cmds")
  FFFQrh(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVp9HU ,
   "cancel": self.VV3A7z  ,
   "menu" : self.VVIGzm ,
   "last" : self.VVTMyE  ,
   "next" : self.VVTMyE  ,
   "1"  : self.VVTMyE  ,
   "2"  : self.VVTMyE  ,
   "3"  : self.VVTMyE  ,
   "4"  : self.VVTMyE  ,
   "5"  : self.VVTMyE  ,
   "6"  : self.VVTMyE  ,
   "7"  : self.VVTMyE  ,
   "8"  : self.VVTMyE  ,
   "9"  : self.VVTMyE  ,
   "0"  : self.VVTMyE
  })
  self.onLayoutFinish.append(self.VVHrlo)
  self.onClose.append(self.VVSHLk)
 def VVHrlo(self):
  self["myLabel"].VVnulZ(isResizable=False, outputFileToSave="terminal")
  FFIyfV(self["keyRed"]  , "#00ff8000")
  FFIY0q(self["keyRed"]  , self.skinParam["titleColor"])
  FFIY0q(self["keyGreen"]  , self.skinParam["titleColor"])
  FFIY0q(self["keyYellow"] , self.skinParam["titleColor"])
  FFIY0q(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVpqUY(FFdVkh("date"), 5)
  result = FFdVkh("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVCQQ8()
  self.VVMsZO()
 def VVMsZO(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVBI3c + "LinuxCommands.lst"
  templPath = VV8hpn + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFWnHJ("cp -f '%s' '%s'" % (templPath, alterFile)):
    FF9QaZ("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVSHLk(self):
  if self.container.VVGm3h():
   self.container.killAll()
   self.VVpqUY("Process killed\n", 4)
   self.VVCQQ8()
 def VV3A7z(self):
  if self.container.VVGm3h():
   self.VVSHLk()
  else:
   FFo32K(self, self.close, "Exit ?", VVhp5L=False)
 def VVCQQ8(self):
  self.VVpqUY(self.prompt, 1)
  self["keyRed"].hide()
 def VVpqUY(self, txt, mode):
  if   mode == 1 : color = VV691Y
  elif mode == 2 : color = VVZkFQ
  elif mode == 3 : color = VVkbX3
  elif mode == 4 : color = VVSBcQ
  elif mode == 5 : color = VViSml
  elif mode == 6 : color = VVuopv
  else   : color = VVkbX3
  try:
   self["myLabel"].appendText(FF7kJS(txt, color))
  except:
   pass
 def VVp9HU(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VViiwo() == "":
   self.VV4IXg("cd /tmp")
   self.VV4IXg("ls")
  VVDb2Q = []
  if fileExists(self.commandHistoryFile):
   lines  = FFKcIu(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVDb2Q.append((str(c), line, str(lNum)))
   self.VVXXCR(VVDb2Q, title, self.commandHistoryFile, isHistory=True)
  else:
   FFiEaB(self, self.commandHistoryFile, title=title)
 def VViiwo(self):
  lastLine = FFdVkh("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV4IXg(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVIGzm(self, VVt27A=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFKcIu(self.customCommandsFile)
   VVDb2Q = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVDb2Q.append((str(c), line, str(lNum)))
   if VVt27A:
    VVt27A.VVByC5(VVDb2Q)
    VVt27A.VVagt1(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVXXCR(VVDb2Q, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFiEaB(self, self.customCommandsFile, title=title)
 def VVXXCR(self, VVDb2Q, title, filePath=None, isHistory=False):
  if VVDb2Q:
   VVgjmd = "#05333333"
   if isHistory: VVuGSD = VVO7CL = VV2ftx = "#11000020"
   else  : VVuGSD = VVO7CL = VV2ftx = "#06002020"
   VVt6tD   = ("Send"   , BF(self.VVf17A, isHistory)  , [])
   VVaq9G  = ("Modify & Send" , self.VVJYI1     , [])
   if isHistory:
    VV9CSs = ("Clear History" , self.VVnVbF     , [])
    VVTO3h = None
    VVk5TH = None
   elif filePath:
    VV9CSs = ("Options"  , self.VV8JDj      , [])
    VVTO3h = ("Edit File"  , BF(self.VVfjyZ, filePath) , [])
    VVk5TH = (""    , self.VVF9K9     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVmBED = (CENTER , LEFT   , CENTER )
   VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h, VVk5TH=VVk5TH, lastFindConfigObj=CFG.lastFindTerminal, VV2v46=True, searchCol=1
         , VVuGSD=VVuGSD, VVO7CL=VVO7CL, VV2ftx=VV2ftx, VVgjmd=VVgjmd)
   if not isHistory:
    VVt27A.VVagt1(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFo32K(self, BF(self.VVoAZK, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVF9K9(self, VVt27A, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FF7kJS("Command:", VVSFOM), colList[1])
  txt += "%s\n%s\n\n" % (FF7kJS("Line %s in File:" % colList[2], VVSFOM), self.customCommandsFile)
  FFaIgn(self, txt, title=title)
 def VV8JDj(self, VVt27A, title, txt, colList):
  mSel = CC9SG5(self, VVt27A)
  VV8kKb = []
  txt1 = "Change Custom Commands File"
  if VVt27A.VVY4gV:
   VV8kKb.append((txt1, ))
   VV8kKb.append(VVnK97)
   totSel = VVt27A.VVWJ0c()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FF7kJS(totTxt, VV691Y) if totSel else totTxt, FF7O1V(totSel))
   VV8kKb.append((txt2, "send") if totSel else (txt2,))
  else:
   VV8kKb.append((txt1, "newFile"))
   VV8kKb.append(VVnK97)
   txt2 = "Send current line"
   VV8kKb.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVoAZK, VVt27A, txt1)
     , "send" : BF(self.VVf17A, False, VVt27A, title, txt2, colList) }
  mSel.VVV2XD(VV8kKb, cbFncDict, okFnc=BF(self.VVuS5a, VVt27A))
 def VVoAZK(self, VVt27A, title):
  VV8kKb = []
  for fName in os.listdir(VVBI3c):
   path = os.path.join(VVBI3c, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VV8kKb.append((fName, path))
  VV8kKb.sort(key=lambda x: x[0].lower())
  if VV8kKb : FFHAbB(self, BF(self.VV3Dry, VVt27A, title), VV8kKb=VV8kKb, title=title, minRows=3, VVuGSD="#11220000", VVO7CL="#11220000")
  else  : FFrj68(self, "No valid files found in:\n\n%s" % VVBI3c, title=title)
 def VV3Dry(self, VVt27A, title, path=None):
  if path:
   if CCFric.VVaB8q(path):
    FFrj68(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFKcIu(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFaoHf(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFaoHf(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVIGzm(VVt27A)
      break
    else:
     FFrj68(self, "File is empty:\n\n%s" % path, title=title)
 def VVuS5a(self, VVt27A):
  if VVt27A.VVY4gV : VVt27A.VV7bts()
  else        : VVt27A.VVSavX()
 def VVf17A(self, isHistory, VVt27A, title, txt, colList):
  if VVt27A.VVY4gV:
   lst = VVt27A.VVbrJg(1)
   curNdx = VVt27A.VVitdD()
  else:
   lst = [colList[1]]
   curNdx = VVt27A.VV2fe8()
  if not isHistory:
   FFaoHf(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVt27A.cancel()
  FF2Wwv(self.VVedJp)
 def VVedJp(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVpqUY("\n%s\n" % cmd, 6)
    self.VVpqUY(self.prompt, 1)
    self.VVedJp()
   else:
    self.VVlJoC(cmd)
 def VVlJoC(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVpqUY(cmd, 2)
   self.VVpqUY("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVpqUY(ch, 0)
   self.VVpqUY("\nor\n", 4)
   self.VVpqUY("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVCQQ8()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF7kJS(parts[0].strip(), VVZkFQ)
    right = FF7kJS("#" + parts[1].strip(), VVuopv)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVpqUY(txt, 2)
   lastLine = self.VViiwo()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV4IXg(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVqBu4, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFrj68(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVpqUY(data, 3)
 def VVqBu4(self, data, retval):
  if not retval == 0:
   self.VVpqUY("Exit Code : %d\n" % retval, 4)
  self.VVCQQ8()
  if self.commandsList:
   self.VVedJp()
 def VVJYI1(self, VVt27A, title, txt, colList):
  if VVt27A.VVk8Me():
   cmd = colList[1]
   self.VVyekh(VVt27A, cmd)
 def VVnVbF(self, VVt27A, title, txt, colList):
  FFo32K(self, BF(self.VV0rD1, VVt27A), "Reset History File ?", title="Command History")
 def VV0rD1(self, VVt27A):
  FF9QaZ("> '%s'" % self.commandHistoryFile)
  VVt27A.cancel()
 def VVfjyZ(self, filePath, VVt27A, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCAoYu(self, filePath, VVVnlJ=BF(self.VVrLVf, VVt27A), curRowNum=rowNum)
  else     : FFiEaB(self, filePath)
 def VVrLVf(self, VVt27A, fileChanged):
  if fileChanged:
   VVt27A.cancel()
   FF2Wwv(self.VVIGzm)
 def VVTMyE(self):
  self.VVyekh(None, self.lastCommand)
 def VVyekh(self, VVt27A, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFTtos(self, BF(self.VVrsSj, VVt27A), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVrsSj(self, VVt27A, cmd):
  if cmd and len(cmd) > 0:
   self.VVlJoC(cmd)
   if VVt27A:
    VVt27A.cancel()
class CCIJTa(Screen):
 def __init__(self, session, title="", message="", VViXLk=VV1E5l, width=1400, height=900, VV7Pvn=False, titleBg="#22002020", VV2ftx="#22001122", VVC5IT=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFpC8B(VVECKd, width, height, titleFontSize, 30, 20, titleBg, VV2ftx, VVC5IT)
  self.session   = session
  FF74S2(self, title, addScrollLabel=True)
  self.VViXLk   = VViXLk
  self.VV7Pvn   = VV7Pvn
  self.VV2ftx   = VV2ftx
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self["myLabel"].VVnulZ(VV7Pvn=self.VV7Pvn, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VViXLk)
  self["myLabel"].VVewHM()
class CCrLLi(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFpC8B(VVaqWa, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF74S2(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FF0pjL(self["errPic"], "err")
class CCWkLw(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFpC8B(VVD0XK, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FF74S2(self, " ", addCloser=True)
class CCajpF():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCajpF.VVhc8i(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVqrQy)
  except: self.timer.callback.append(self.VVqrQy)
  self.timer.start(timeout, True)
 def VVqrQy(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVhc8i(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCWkLw, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FF4dg8(win["myWinTitle"], shadColor, shadW)
  CCajpF.VVSWmQ(win, txt)
  return win
 @staticmethod
 def VVSWmQ(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCnvmH():
 VVXn25    = 0
 VVyxqu  = 1
 VVzArQ   = ""
 VVfBSd    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVt27A   = None
  self.timer     = eTimer()
  self.VV2Ip3   = 0
  self.VVgYT5  = 1
  self.VV2aJ5  = 2
  self.VVZBEH   = 3
  self.VVCbDE   = 4
  VVDb2Q = self.VVuSZ8()
  if VVDb2Q:
   self.VVt27A = self.VVUCN0(VVDb2Q)
  if not VVDb2Q and mode == self.VVXn25:
   self.VVwaVA("Download list is empty !")
   self.cancel()
  if mode == self.VVyxqu:
   FF0GsP(self.VVt27A or self.SELF, BF(self.VVlRnZ, startDnld, decodedUrl), title="Checking Server ...")
  self.VVTCIa(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTCIa)
  except:
   self.timer.callback.append(self.VVTCIa)
  self.timer.start(1000, False)
 def VVUCN0(self, VVDb2Q):
  VVDb2Q.sort(key=lambda x: int(x[0]))
  VVqFCi = self.VVYow3
  VVt6tD  = ("Play"  , self.VVr551 , [])
  VVk5TH = (""   , self.VVg0Lg  , [])
  VVOFQa = ("Stop"  , self.VV7iJg  , [])
  VVaq9G = ("Resume"  , self.VVSRgU , [])
  VV9CSs = ("Options" , self.VVh5Vn  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVmBED  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFyZJ5(self.SELF, None, title=self.Title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVt6tD=VVt6tD, VVk5TH=VVk5TH, VVqFCi=VVqFCi, VVOFQa=VVOFQa, VVaq9G=VVaq9G, VV9CSs=VV9CSs, lastFindConfigObj=CFG.lastFindIptv, VVuGSD="#11220022", VVO7CL="#11110011", VV2ftx="#11110011", VVgjmd="#00223025", VVZ0ud="#0a333333", VVGQoh="#0a400040", VV2v46=True, searchCol=1)
 def VVuSZ8(self):
  lines = CCnvmH.VVnXAT()
  VVDb2Q = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVDUQZ(decodedUrl)
      if fName:
       if   FFTXJG(decodedUrl) : sType = "Movie"
       elif FFD0w7(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVr2Rb(decodedUrl, fName)
       if size > -1: sizeTxt = CCFric.VVgYti(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVDb2Q.append((str(len(VVDb2Q) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVDb2Q
 def VVitzZ(self):
  VVDb2Q = self.VVuSZ8()
  if VVDb2Q:
   if self.VVt27A : self.VVt27A.VVByC5(VVDb2Q, VV78xZMsg=False)
   else     : self.VVt27A = self.VVUCN0(VVDb2Q)
  else:
   self.cancel()
 def VVTCIa(self, force=False):
  if self.VVt27A:
   thrListUrls = self.VVfbfS()
   VVDb2Q = []
   changed = False
   for ndx, row in enumerate(self.VVt27A.VVXwRB()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV2Ip3
    if m3u8Log:
     percent = CCnvmH.VVKaTN(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVZBEH , "%.2f %%" % percent
      else   : flag, progr = self.VVCbDE , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FF7PcS(mPath)
     if curSize > -1:
      fSize = CCFric.VVgYti(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCFric.VVgYti(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FF7PcS(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVZBEH , "%.2f %%" % percent
       else   : flag, progr = self.VVCbDE , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCFric.VVgYti(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VV2aJ5
     if m3u8Log :
      if not speed and not force : flag = self.VVgYT5
      elif curSize == -1   : self.VVZp8u(False)
    elif flag == self.VV2Ip3  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV2Ip3  : color2 = "#f#00555555#"
    elif flag == self.VVgYT5 : color2 = "#f#0000FFFF#"
    elif flag == self.VV2aJ5 : color2 = "#f#0000FFFF#"
    elif flag == self.VVZBEH  : color2 = "#f#00FF8000#"
    elif flag == self.VVCbDE  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVLbZw(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVDb2Q.append(row)
   if changed or force:
    self.VVt27A.VVByC5(VVDb2Q, VV78xZMsg=False)
 def VVLbZw(self, flag):
  tDict = self.VV3kT8()
  return tDict.get(flag, "?")
 def VVZkMz(self, state):
  for flag, txt in self.VV3kT8().items():
   if txt == state:
    return flag
  return -1
 def VV3kT8(self):
  return { self.VV2Ip3: "Not started", self.VVgYT5: "Connecting", self.VV2aJ5: "Downloading", self.VVZBEH: "Stopped", self.VVCbDE: "Completed" }
 def VVUuns(self, title):
  colList = self.VVt27A.VVM4Gr()
  path = colList[6]
  url  = colList[8]
  if self.VVU5ha() : self.VVwaVA("Cannot delete !\n\nFile is downloading.")
  else      : FFo32K(self.SELF, BF(self.VVy8XQ, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVy8XQ(self, path, url):
  m3u8Log = self.VVt27A.VVM4Gr()[12]
  if m3u8Log : FFWnHJ("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFWnHJ("rm -rf '%s'" % path)
  self.VVyPEw(False)
  self.VVitzZ()
 def VVyPEw(self, VVSOst=True):
  if self.VVU5ha():
   FFAM12(self.VVt27A, self.VVLbZw(self.VV2aJ5), 500)
  else:
   colList  = self.VVt27A.VVM4Gr()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVZkMz(state) in (self.VV2Ip3, self.VVCbDE, self.VVZBEH):
    lines = CCnvmH.VVnXAT()
    newLines = []
    found = False
    for line in lines:
     if CCnvmH.VVhNmD(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVZQQ9(newLines)
     self.VVitzZ()
     FFAM12(self.VVt27A, "Removed.", 1000)
    else:
     FFAM12(self.VVt27A, "Not found.", 1000)
   elif VVSOst:
    self.VVwaVA("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVfUBA(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFo32K(self.SELF, BF(self.VVRDoD, flag), ques, title=title)
 def VVRDoD(self, flag):
  list = []
  for ndx, row in enumerate(self.VVt27A.VVXwRB()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVZkMz(state)
   if   flag == flagVal == self.VVCbDE: list.append(decodedUrl)
   elif flag == flagVal == self.VV2Ip3 : list.append(decodedUrl)
  lines = CCnvmH.VVnXAT()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVZQQ9(newLines)
   self.VVitzZ()
   FFAM12(self.VVt27A, "%d removed." % totRem, 1000)
  else:
   FFAM12(self.VVt27A, "Not found.", 1000)
 def VVDWPY(self):
  colList  = self.VVt27A.VVM4Gr()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFAM12(self.VVt27A, "Poster exists", 1500)
  else    : FF0GsP(self.VVt27A, BF(self.VVXPgJ, decodedUrl, path, png), title="Checking Server ...")
 def VVXPgJ(self, decodedUrl, path, png):
  err = self.VVKkGO(decodedUrl, path, png)
  if err:
   FFrj68(self.SELF, err, title="Poster Download")
 def VVKkGO(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCXeC7.VVnMiS(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC1B0Q.VVIq7x(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC1B0Q.VVEaWb(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC1B0Q.VVrKuD(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFadHO(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFWnHJ("mv -f '%s' '%s'" % (tPath, png))
   CCJCdT.VVHj4i(self.SELF, VVRuzQ=png, showGrnMsg="Downloaded")
   return ""
 def VVg0Lg(self, VVt27A, title, txt, colList):
  def VVrCdg(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVPmyh(key, val) : return "\n%s:\n%s\n" % (FF7kJS(key, VVSFOM), val.strip())
  heads  = self.VVt27A.VVz8N9()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVrCdg(heads[i]  , CCFric.VVgYti(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVrCdg("Downloaded" , CCFric.VVgYti(int(curSize), mode=0))
   else:
    txt += VVrCdg(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVPmyh(heads[i], colList[i])
  FFaIgn(self.SELF, txt, title=title)
 def VVr551(self, VVt27A, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCFric.VVDGqS(self.SELF, path)
  else    : FFAM12(self.VVt27A, "File not found", 1000)
 def VVYow3(self, VVt27A):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVt27A:
   self.VVt27A.cancel()
  del self
 def VVh5Vn(self, VVt27A, title, txt, colList):
  c1, c2, c3 = VV4d6Z, VVSBcQ, VVSFOM
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VV8kKb = []
  VV8kKb.append((c1 + "Remove current row"       , "VVyPEw" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VV8kKb.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Delete the file (and remove from list)"  , "VVUuns"))
  VV8kKb.append(VVnK97)
  VV8kKb.append((resumeTxt + " Auto Resume"       , "VVFX1o" ))
  VV8kKb.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VV8kKb.append(VVnK97)
  cond = FFTXJG(decodedUrl)
  VV8kKb.append(FF4UJX("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVDWPY", cond, c3))
  VV8kKb.append(FF4UJX("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFHAbB(self.SELF, BF(self.VVEcoI, VVt27A), VV8kKb=VV8kKb, title=self.Title, VVPYdF=True, width=800, VVWQ3x=True, VVuGSD="#1a001122", VVO7CL="#1a001122")
 def VVEcoI(self, VVt27A, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVyPEw"  : self.VVyPEw()
   elif ref == "remFinished"   : self.VVfUBA(self.VVCbDE, txt)
   elif ref == "remPending"   : self.VVfUBA(self.VV2Ip3, txt)
   elif ref == "VVUuns" : self.VVUuns(txt)
   elif ref == "VVDWPY"  : self.VVDWPY()
   elif ref == "VVFX1o"  : FFaoHf(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFaoHf(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCFric, mode=CCFric.VV9LS7, jumpToFile=path)
    else    : FFAM12(VVt27A, "Path not found !", 1500)
 def VVlRnZ(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCXeC7.VVnMiS(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVwaVA("Could not get download link !\n\nTry again later.")
     return
  for line in CCnvmH.VVnXAT():
   if CCnvmH.VVhNmD(decodedUrl, line):
    if self.VVt27A:
     self.VVgbpS(decodedUrl)
     FF2Wwv(BF(FFAM12, self.VVt27A, "Already listed !", 2000))
    break
  else:
   params = self.VVtRty(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVwaVA(params[0])
   elif len(params) == 2:
    FFo32K(self.SELF, BF(self.VV982o, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCFric.VVgYti(fSize)
    FFo32K(self.SELF, BF(self.VVUWME, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVUWME(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCnvmH.VVz5FY(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVitzZ()
  if self.VVt27A:
   self.VVt27A.VVgusi()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCnvmH.VVfBSd, path, decodedUrl)
   self.VVK3s5(threadName, url, decodedUrl, path, resp)
 def VVgbpS(self, decodedUrl):
  if self.VVt27A:
   for ndx, row in enumerate(self.VVt27A.VVXwRB()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVt27A:
     self.VVt27A.VVagt1(ndx)
     break
 def VVtRty(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVDUQZ(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVr2Rb(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCXeC7.VVnMiS(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCXeC7.VVXH11()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCnvmH.VVhRbd(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCnvmH.VVWmyE(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VV982o(self, resp, decodedUrl):
  if not FFFS65("ffmpeg"):
   FFo32K(self.SELF, BF(CC1B0Q.VVAHxs, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVDUQZ(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVHqXI(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFo32K(self.SELF, BF(self.VVhjOh, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVhjOh(rTxt, rUrl)
  else:
   self.VVwaVA("Cannot process m3u8 file !")
 def VVHqXI(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VV8kKb = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC1B0Q.VVBFii(rUrl, fPath)
   VV8kKb.append((resol, fullUrl))
  if VV8kKb:
   FFHAbB(self.SELF, self.VVoN45, VV8kKb=VV8kKb, title="Resolution", VVPYdF=True, VVWQ3x=True)
  else:
   self.VVwaVA("Cannot get Resolutions list from server !")
 def VVoN45(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFo32K(self.SELF, BF(FF2Wwv, BF(self.VVP49w, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FF2Wwv(BF(self.VVP49w, resolUrl))
 def VVP49w(self, resolUrl):
  txt, err = CCXeC7.VVtmW3(resolUrl)
  if err : self.VVwaVA(err)
  else : self.VVhjOh(txt, resolUrl)
 def VV4FwR(self, logF, decodedUrl):
  found = False
  lines = CCnvmH.VVnXAT()
  with open(CCnvmH.VVz5FY(), "w") as f:
   for line in lines:
    if CCnvmH.VVhNmD(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCnvmH.VVz5FY(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVitzZ()
  if self.VVt27A:
   self.VVt27A.VVgusi()
 def VVhjOh(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC1B0Q.VVBFii(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVwaVA("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV4FwR(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFhyjZ("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCnvmH.VVfBSd, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVKaTN(dnldLog):
  if fileExists(dnldLog):
   dur = CCnvmH.VVr78C(dnldLog)
   if dur > -1:
    tim = CCnvmH.VV5cMU(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVr78C(dnldLog):
  lines = FFO8C9("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VV5cMU(dnldLog):
  lines = FFO8C9("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVr2Rb(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFD0w7(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFWnHJ("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVK3s5(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVt27A.VVM4Gr()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVblb1, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVblb1(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVzArQ == path:
       break
     else:
      break
  except:
   return
  if CCnvmH.VVzArQ:
   CCnvmH.VVzArQ = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FF7PcS(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVtRty(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVblb1(url, decodedUrl, path, resp, totFileSize, True)
 def VV7iJg(self, VVt27A, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVj4TQ() : FFAM12(self.VVt27A, self.VVLbZw(self.VVCbDE), 500)
  elif not self.VVU5ha() : FFAM12(self.VVt27A, self.VVLbZw(self.VVZBEH), 500)
  elif m3u8Log      : FFo32K(self.SELF, self.VVZp8u, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVfbfS():
    CCnvmH.VVzArQ = colList[6]
    FFAM12(self.VVt27A, "Stopping ...", 1000)
   else:
    FFAM12(self.VVt27A, "Stopped", 500)
 def VVZp8u(self, withMsg=True):
  if withMsg:
   FFAM12(self.VVt27A, "Stopping ...", 1000)
  FFWnHJ("killall -INT ffmpeg")
 def VVSRgU(self, *args):
  if   self.VVj4TQ() : FFAM12(self.VVt27A, self.VVLbZw(self.VVCbDE) , 500)
  elif self.VVU5ha() : FFAM12(self.VVt27A, self.VVLbZw(self.VV2aJ5), 500)
  else:
   resume = False
   m3u8Log = self.VVt27A.VVM4Gr()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFo32K(self.SELF, BF(self.VVqyLh, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVqVki():
    resume = True
   if resume: FF0GsP(self.VVt27A, BF(self.VVCGbY), title="Checking Server ...")
   else  : FFAM12(self.VVt27A, "Cannot resume !", 500)
 def VVqyLh(self, m3u8Log):
  FFWnHJ("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FF0GsP(self.VVt27A, BF(self.VVCGbY), title="Checking Server ...")
 def VVCGbY(self):
  colList  = self.VVt27A.VVM4Gr()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCXeC7.VVnMiS(decodedUrl)
   if url:
    decodedUrl = self.VVJlvx(decodedUrl, url)
   else:
    self.VVwaVA("Could not get download link !\n\nTry again later.")
    return
  curSize = FF7PcS(path)
  params = self.VVtRty(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVwaVA(params[0])
   return
  elif len(params) == 2:
   self.VV982o(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVJlvx(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCnvmH.VVfBSd, path, decodedUrl)
  if resumable: self.VVK3s5(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVwaVA("Cannot resume from server !")
 def VVDUQZ(self, decodedUrl):
  fileExt = CC1B0Q.VVjANq(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF4HLW(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVwaVA(self, txt):
  FFrj68(self.SELF, txt, title=self.Title)
 def VVfbfS(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCnvmH.VVfBSd, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVU5ha(self):
  decodedUrl = self.VVt27A.VVM4Gr()[9]
  return decodedUrl in self.VVfbfS()
 def VVj4TQ(self):
  colList = self.VVt27A.VVM4Gr()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FF7PcS(path)) == size
 def VVqVki(self):
  colList = self.VVt27A.VVM4Gr()
  path = colList[6]
  size = int(colList[7])
  curSize = FF7PcS(path)
  if curSize > -1:
   size -= curSize
  err = CCnvmH.VVWmyE(size)
  if err:
   FFrj68(self.SELF, err, title=self.Title)
   return False
  return True
 def VVZQQ9(self, list):
  with open(CCnvmH.VVz5FY(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVJlvx(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCnvmH.VVnXAT()
  url = decodedUrl
  with open(CCnvmH.VVz5FY(), "w") as f:
   for line in lines:
    if CCnvmH.VVhNmD(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVitzZ()
  return url
 @staticmethod
 def VVnXAT():
  list = []
  if fileExists(CCnvmH.VVz5FY()):
   for line in FFKcIu(CCnvmH.VVz5FY()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVhNmD(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVWmyE(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCFric.VV5FZe(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCFric.VVgYti(size), CCFric.VVgYti(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVUV6g(SELF):
  tot = CCnvmH.VV5SuY()
  if tot:
   FFrj68(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV5SuY():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCnvmH.VVfBSd):
    c += 1
  return c
 @staticmethod
 def VVJ0jl():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCnvmH.VVfBSd, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVMkdN():
  return len(CCnvmH.VVnXAT()) == 0
 @staticmethod
 def VVcitL():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVkWy8():
  mPoints = CCnvmH.VVcitL()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFWnHJ("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVz5FY():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVTfM5(SELF, waitMsgObj=None):
  FF0GsP(waitMsgObj or SELF, BF(CCnvmH.VVz9sf, SELF, CCnvmH.VVXn25))
 @staticmethod
 def VVuLic(SELF):
  CCnvmH.VVz9sf(SELF, CCnvmH.VVyxqu, startDnld=True)
 @staticmethod
 def VV7fSR(SELF, url):
  CCnvmH.VVz9sf(SELF, CCnvmH.VVyxqu, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVBs05(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF)
  added, skipped = CCnvmH.VVjKGj([decodedUrl])
  FFAM12(SELF, "Added", 1000)
 @staticmethod
 def VVjKGj(list):
  added = skipped = 0
  for line in CCnvmH.VVnXAT():
   for ndx, url in enumerate(list):
    if url and CCnvmH.VVhNmD(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCnvmH.VVz5FY(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVz9sf(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCVrap.VV06qX(SELF):
   return
  if mode == CCnvmH.VVXn25 and CCnvmH.VVMkdN():
   FFrj68(SELF, "Download list is empty !", title=title)
  else:
   inst = CCnvmH(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVhRbd(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCLDrN(Screen, CCbnKw):
 VVgkJK = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFpC8B(VVpcXS, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCbnKw.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FF74S2(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVDyqj())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0TcE       ,
   "info"  : self.VVqcZq      ,
   "epg"  : self.VVqcZq      ,
   "menu"  : self.VVXXzQ     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVhAWN   ,
   "green"  : self.VVhDds  ,
   "blue"  : self.VVblTm      ,
   "yellow" : self.VVt3Lr ,
   "left"  : BF(self.VVCW4q, -1)    ,
   "right"  : BF(self.VVCW4q,  1)    ,
   "play"  : self.VVdkZu      ,
   "pause"  : self.VVdkZu      ,
   "playPause" : self.VVdkZu      ,
   "stop"  : self.VVdkZu      ,
   "rewind" : self.VV6oVA      ,
   "forward" : self.VVWsKC      ,
   "rewindDm" : self.VV6oVA      ,
   "forwardDm" : self.VVWsKC      ,
   "last"  : self.VVvcnC      ,
   "next"  : self.VV6q0U      ,
   "pageUp" : BF(self.VVPuuR, True)  ,
   "pageDown" : BF(self.VVPuuR, False)  ,
   "chanUp" : BF(self.VVPuuR, True)  ,
   "chanDown" : BF(self.VVPuuR, False)  ,
   "up"  : BF(self.VVPuuR, True)  ,
   "down"  : BF(self.VVPuuR, False)  ,
   "audio"  : BF(self.VVh1xw, True)  ,
   "subtitle" : BF(self.VVh1xw, False)  ,
   "text"  : self.VVWqMl  ,
   "0"   : BF(self.VVubxj , 10)   ,
   "1"   : BF(self.VVubxj , 1)   ,
   "2"   : BF(self.VVubxj , 2)   ,
   "3"   : BF(self.VVubxj , 3)   ,
   "4"   : BF(self.VVubxj , 4)   ,
   "5"   : BF(self.VVubxj , 5)   ,
   "6"   : BF(self.VVubxj , 6)   ,
   "7"   : BF(self.VVubxj , 7)   ,
   "8"   : BF(self.VVubxj , 8)   ,
   "9"   : BF(self.VVubxj , 9)
  }, -1)
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  if not CCLDrN.VVgkJK:
   CCLDrN.VVgkJK = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FF0pjL(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FF0pjL(self["myPlayRpt"], "rpt")
  self.VVe54d()
  self.instance.move(ePoint(40, 40))
  self.VVEbmu(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVBQvF)
  except:
   self.timer.callback.append(self.VVBQvF)
  self.timer.start(250, False)
  self.VVBQvF("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVu5NX()
 def VVhDds(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  self.lastSubtitle = CCnx0Q.VVKLf0()
  if "chCode" in iptvRef:
   if CCVrap.VV06qX(self):
    self.VVu5NX(True)
  else:
   self.VVBQvF("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVe54d(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVoLRa()
  chName = FFJYbZ(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVvkGK + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFIY0q(self["myTitle"], tColor)
  FFIY0q(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFIY0q(self["myPlay%s" % item], tColor)
  picFile = CCOQON.VVQips(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCOQON.VVD2Qj(self)
  cl = CCCyfp.VVbhHo(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVBQvF(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCnvmH.VV5SuY()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVoLRa()
  if evName:
   evName = "    %s    " % FF7kJS(evName, VViSml)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVcxlW():
   FFIyfV(self["myPlayBlu"], "#00FFFFFF")
   FFIY0q(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFIyfV(self["myPlayBlu"], "#00FFFF88")
   FFIY0q(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CC1B0Q.VVSzlp(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVuopv + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFIY0q(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFB9GB(percVal, 0, 100)
   width = int(FFFgzn(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFIY0q(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFIyfV(self["myPlayMsg"], "#0000ffff")
   else  : FFIyfV(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFIyfV(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFIyfV(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVT5GK()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVAkNR(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCnx0Q.VVSFDS(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVvcnC()
  state = self.VVOrYO()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFIyfV(self["myPlayMsg"], "#0000ff00")
  else     : FFIyfV(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVoLRa(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFN3N8(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCOQON.VVsfU7(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CC5k8k()
   tpTxt, satTxt = tp.VVdkYB(refCode)
   self.satInfo_TP = tpTxt + "  " + FF7kJS(satTxt, VVLAFW)
  evName = evNameNext = ""
  evLst = CCS6Mr.VVV6lv(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFPfNs(info, iServiceInformation.sVideoWidth) or -1
   h = FFPfNs(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFPfNs(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCOQON.VVPKQl(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VV3vMp(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFjXk8(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFjXk8(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFjXk8(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVXXzQ(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVoLRa()
  FFTXJGSeries = FF4HLW(decodedUrl)
  VV8kKb = []
  if not "VVUfcc" in globals() and not "VVJGEX" in globals():
   VV8kKb.append((VVLAFW + "IPTV Menu", "iptv"))
   VV8kKb.append(VVnK97)
  if isIptv and not "&end=" in decodedUrl and not FFTXJGSeries:
   uType, uHost, uUser, uPass, uId, uChName = CC1B0Q.VVIq7x(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VV8kKb.append((VVLAFW + "Catchup Programs", "catchup" ))
    VV8kKb.append(VVnK97)
  if refCode:
   c = VVvkGK
   VV8kKb.append((c + "Stop Current Service"  , "stop"  ))
   VV8kKb.append((c + "Restart Current Service" , "restart"  ))
   VV8kKb.append(FF4UJX("Replay with ..." , "replayWith", not isDvb, c))
   VV8kKb.append(VVnK97)
  if FFTXJGSeries:
   VV8kKb.append((VVLAFW + "File Size (on server)", "fileSize" ))
   VV8kKb.append(VVnK97)
  if self.enableDownloadMenu:
   c = VVLAFW
   addSep = False
   if isIptv and FFTXJGSeries:
    VV8kKb.append((c + "Start Download"  , "dload_cur" ))
    VV8kKb.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCnvmH.VVMkdN():
    VV8kKb.append((VVLAFW + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VV8kKb.append(VVnK97)
  fPath, fDir, fName = CCFric.VVEl1L(self)
  if fPath:
   c = VV30Pd
   if not "VVzCRB" in globals():
    VV8kKb.append((c + "Open path in File Manager", "VVMVfY"))
   VV8kKb.append((c + "Add to Bouquet"             , "VV59MO" ))
   VV8kKb.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVYJBf"  ))
   VV8kKb.append(VVnK97)
  elif isFtp:
   VV8kKb.append((VVSFOM + "Add FTP Media to Bouquet"     , "VVoQPU"))
  if isDvb:
   VV8kKb.append((VVLAFW + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VV8kKb.append((VVSFOM + "Start Subtitle", "VVZ3yI"))
   VV8kKb.append(VVnK97)
  if CFG.playerPos.getValue() : VV8kKb.append(("Move Bar to Bottom" , "botm"))
  else      : VV8kKb.append(("Move Bar to Top" , "top" ))
  VV8kKb.append(("Help", "help"))
  FFHAbB(self, self.VVzkzt, VV8kKb=VV8kKb, width=600, title="Options")
 def VVzkzt(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVt3Lr()
   elif item == "stop"     : self.VV0LQh(0)
   elif item == "restart"    : self.VV0LQh(1)
   elif item == "replayWith"   : self.VVLnNe()
   elif item == "fileSize"    : FF0GsP(self, BF(CCOQON.VVVvik, self), title="Checking Server")
   elif item == "dload_cur"   : CCnvmH.VVuLic(self)
   elif item == "addToDload"   : CCnvmH.VVBs05(self)
   elif item == "dload_stat"   : CCnvmH.VVTfM5(self)
   elif item == "VVMVfY" : self.close("close_openInFileMan")
   elif item == "VV59MO" : self.VV59MO()
   elif item == "VVoQPU" : self.VVoQPU()
   elif item == "VVZ3yI"  : self.VVzsrO()
   elif item == "VVYJBf"  : self.VVYJBf()
   elif item == "botm"     : self.VVEbmu(0)
   elif item == "top"     : self.VVEbmu(1)
   elif item == "sigMon"    : self.VVhAWN()
   elif item == "help"     : FFZzIv(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCLDrN.VVgkJK = None
 def VV0LQh(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVe54d()
   elif typ == 1:
    self.VVBQvF("Restarting Service ...")
    FF2Wwv(BF(self.VVSwCv, serv))
 def VVSwCv(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  if "&end=" in decodedUrl: BF(self.VVu5NX, True)
  else     : self.session.nav.playService(serv)
 def VVLnNe(self):
  FFHAbB(self, self.VVW001, VV8kKb=CC1B0Q.VVPRvV(), width=650, title="Select Player", VVuGSD="#11220000", VVO7CL="#11220000")
 def VVW001(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFewyb(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVBQvF("No active service !")
 def VV59MO(self):
  fPath, fDir, fName = CCFric.VVEl1L(self)
  if fPath: picker = CCQo5X(self, self, "Add Current Movie to a Bouquet", BF(self.VVfSQo, [fPath]))
  else : FFAM12(self, "Path not found !", 1500)
 def VVfSQo(self, pathLst):
  return CCQo5X.VVDnzV(pathLst)
 def VVoQPU(self):
  picker = CCQo5X(self, self, "Add FTP Media to Bouquet", self.VViun2)
 def VViun2(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  return CCQo5X.VVDnzV([origUrl], rType=refCode.split(":", 1)[0])
 def VVYJBf(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVBQvF(txt, highlight=ok)
 def VVEbmu(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFaoHf(CFG.playerPos, pos)
 def VVhAWN(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCOQON.VVsfU7(serv)
   if isDvb: self.close("close_sig")
   else : self.VVBQvF("No Signal for Current Service")
 def VVzsrO(self):
  self.session.openWithCallback(self.VVfAfL, BF(CCnx0Q))
 def VVWqMl(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVoLRa()
   if posTxt and durTxt: self.VVzsrO()
   else    : self.VVBQvF("No duration Info. !")
 def VVfAfL(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVPuuR(True)
  elif reason == "subtZapDn" : self.VVPuuR(False)
  elif reason == "pause"  : self.VVdkZu()
  elif reason == "audio"  : self.VVh1xw(True)
  elif reason == "subtitle" : self.VVh1xw(False)
  elif reason == "rewind"     : self.VV6oVA()
  elif reason == "forward" : self.VVWsKC()
  elif reason == "rewindDm" : self.VV6oVA()
  elif reason == "forwardDm" : self.VVWsKC()
  else      : txt = reason
  if txt:
   FFAM12(self, txt, 2000)
 def VV0TcE(self):
  if self.isManualSeek:
   self.VVpwRs()
   self.VVAkNR(self.manualSeekPts)
  elif self.shown:
   if CCnx0Q.VVxyTe(self): self.VVzsrO()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVpwRs()
  else    : self.close()
 def VVqcZq(self):
  FFjcFt(self, fncMode=CCOQON.VVUFHA)
 def VVdkZu(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVBQvF("Toggling Play/Pause ...")
 def VVpwRs(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVCW4q(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVy6fN()
   else:
    self.manualSeekSec += direc * self.VVy6fN()
    self.manualSeekSec = FFB9GB(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFFgzn(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFjXk8(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVubxj(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVDyqj())
   FFaoHf(CFG.playerJumpMin, self.jumpMinutes)
  self.VVBQvF("Changed Seek Time to : %d%s" % (val, self.VVIJNm()))
 def VVDyqj(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVIJNm())
 def VVIJNm(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVlYTA(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVy6fN(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVT5GK(self):
  if "VV5ciW" in globals():
   global VV5ciW
   if VV5ciW:
    VV5ciW = VV5ciW[1:-1]
    if len(VV5ciW) == 3: VV5ciW = ""
    else     : return VV5ciW
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVblTm(self):
  cList = self.VVcxlW()
  if cList:
   VV8kKb = []
   for pts, what in cList:
    txt = FFjXk8(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VV8kKb.append((txt, pts))
   FFHAbB(self, self.VVhoYQ, VV8kKb=VV8kKb, title="Cut List")
  else:
   self.VVBQvF("No Cut-List for this channel !")
 def VVhoYQ(self, item=None):
  if item:
   self.VVAkNR(item)
 def VVcxlW(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVWsKC(self) : self.VVYetI(1)
 def VV6oVA(self) : self.VVYetI(-1)
 def VVYetI(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVy6fN() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVlYTA())
    self.VVBQvF(txt)
  except:
   self.VVBQvF("Cannot jump")
 def VVAkNR(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVBQvF("Changing Time ...")
 def VVvcnC(self):
  self.VV0LQh(1)
  self.VVBQvF("Replaying ...")
  self.VVpwRs()
 def VV6q0U(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVBQvF("Jumping to end ...")
  except:
   pass
 def VVOrYO(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVPuuR(self, isUp):
  if self.enableZapping:
   self.VVBQvF("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVpwRs()
   if self.iptvTableParams:
    FF2Wwv(BF(self.VV4DkR, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
    if "/timeshift/" in decodedUrl:
     self.VVBQvF("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VV1uv4()
  else:
   self.VVBQvF("Zap Disabled !")
 def VV1uv4(self):
  self.lastPlayPos = 0
  self.VVe54d()
  self.VVu5NX()
 def VV4DkR(self, isUp):
  CC1B0Q_inatance, VVt27A, mode = self.iptvTableParams
  if isUp : VVt27A.VVkx8R()
  else : VVt27A.VVgrUE()
  colList = VVt27A.VVM4Gr()
  if mode == "localIptv":
   chName, chUrl = CC1B0Q_inatance.VVoJPh(VVt27A, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC1B0Q_inatance.VVxkU8(VVt27A, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC1B0Q_inatance.VVCQiA(mode, VVt27A, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC1B0Q_inatance.VVRO9E(mode, VVt27A, colList)
  else:
   self.VVBQvF("Cannot Zap")
   return
  FFHFXk(self, chUrl, VVLARq=False)
  self.VV1uv4()
 def VVu5NX(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
   if not self.VV15dO(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVBQvF("Refreshing Portal")
   FF2Wwv(self.VVAw9V)
  except:
   pass
 def VVAw9V(self):
  self.restoreLastPlayPos = self.VVgpfW()
 def VVt3Lr(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
  if not decodedUrl or FF4HLW(decodedUrl):
   self.VVBQvF("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC1B0Q.VVIq7x(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVBQvF("Reading Program List ...")
   ok_fnc = BF(self.VVK4G1, refCode, chName, streamId, uHost, uUser, uPass)
   FF2Wwv(BF(CC1B0Q.VVCIl7, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVBQvF("Cannot process this channel")
 def VVK4G1(self, refCode, chName, streamId, uHost, uUser, uPass, VVt27A, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVt27A.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVBQvF("Changing Program ...")
   FF2Wwv(BF(self.VV9hHC, chUrl))
  else:
   self.VVBQvF("Incorrect Timestamp !")
 def VV9hHC(self, chUrl):
  FFHFXk(self, chUrl, VVLARq=False)
  self.lastPlayPos = 0
  self.VVe54d()
 def VVh1xw(self, isAudio):
  try:
   VVWHhY = InfoBar.instance
   if VVWHhY:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVWHhY)
    else  : self.session.open(SubtitleSelection, VVWHhY)
  except:
   pass
 @staticmethod
 def VVX8ef(session, mode=None):
  if   mode == "close_sig"   : FFXBRY(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CC1B0Q)
  elif mode == "close_openInFileMan" : session.open(CCFric, gotoMovie=True)
 @staticmethod
 def VVLpPr(session, **kwargs):
  session.openWithCallback(BF(CCLDrN.VVX8ef, session), CCLDrN, **kwargs)
class CCwg6C(Screen):
 def __init__(self, session, title="", VVzpP3="Continue?", VVhp5L=True, VVjDSl=False):
  self.skin, self.skinParam = FFpC8B(VVButu, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVzpP3 = VVzpP3
  self.VVjDSl = VVjDSl
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVhp5L : VV8kKb = [no , yes]
  else   : VV8kKb = [yes, no ]
  FF74S2(self, title, VV8kKb=VV8kKb, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VV0TcE ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVzpP3)
  if self.VVjDSl:
   self["myLabel"].instance.setHAlign(0)
  self.VVO4TE()
  FFl94Z(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFI2s0(self["myMenu"])
  FF66Ab(self, self["myMenu"])
 def VV0TcE(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVO4TE(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCfOtB(Screen):
 def __init__(self, session, title="", VV8kKb=None, width=1000, height=850, VVC5IT=30, barText="", minRows=1, VVodvg=None, VVM6M9=None, VV1zfK=None, VV0MQu=None, VVinPK=None, VVcx0D=None, VVPYdF=False, VVWQ3x=False, VVj7dk=None, VVom0S=True, VVuGSD="#22003344", VVO7CL="#22002233"):
  self.skin, self.skinParam = FFpC8B(VVX871, width, height, 50, 40, 30, VVuGSD, VVO7CL, VVC5IT, barHeight=40, topRightBtns=3 if VVM6M9 else 0)
  self.session   = session
  self.VV8kKb   = VV8kKb
  self.barText   = barText
  self.minRows   = minRows
  self.VVodvg   = VVodvg
  self.VVM6M9   = VVM6M9
  self.VV1zfK   = VV1zfK
  self.VV0MQu  = VV0MQu
  self.VVinPK  = ("Delete File", BF(self.VV5IFX, VVj7dk)) if not VVj7dk is None else VVinPK
  self.VVcx0D   = VVcx0D
  self.VVPYdF  = VVPYdF
  self.VVWQ3x  = VVWQ3x
  self.Title    = title
  FF74S2(self, title, VV8kKb=VV8kKb)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0TcE    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVyRCQ   ,
   "red"  : self.VVRnTs   ,
   "green"  : self.VV01fl   ,
   "yellow" : self.VVE4lo   ,
   "blue"  : self.VVP7Ff   ,
   "pageUp" : self.VV81TQ ,
   "chanUp" : self.VV81TQ ,
   "pageDown" : self.VVnEyx  ,
   "chanDown" : self.VVnEyx  ,
   "0"   : BF(self.VVPjcQ, 0) ,
   "1"   : BF(self.VVPjcQ, 1) ,
   "2"   : BF(self.VVPjcQ, 2) ,
   "3"   : BF(self.VVPjcQ, 3) ,
   "4"   : BF(self.VVPjcQ, 4) ,
   "5"   : BF(self.VVPjcQ, 5) ,
   "6"   : BF(self.VVPjcQ, 6) ,
   "7"   : BF(self.VVPjcQ, 7) ,
   "8"   : BF(self.VVPjcQ, 8) ,
   "9"   : BF(self.VVPjcQ, 9)
  }, -1)
  if VVom0S:
   FFD8ln(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFl94Z(self["myMenu"])
  FF1hGr(self, minRows=self.minRows)
  FFgqCi(self)
  self.VVwdNX(self["keyRed"]  , self.VV1zfK )
  self.VVwdNX(self["keyGreen"] , self.VV0MQu )
  self.VVwdNX(self["keyYellow"] , self.VVinPK )
  self.VVwdNX(self["keyBlue"]  , self.VVcx0D )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFtJRK(self)
 def VVwdNX(self, btnObj, btnFnc):
  if btnFnc:
   FFFQrh(btnObj, btnFnc[0])
 def VVmkQH(self, fnc=None):
  self.VV0MQu = fnc
  if fnc : self.VVwdNX(self["keyGreen"], self.VV0MQu)
  else : self["keyGreen"].hide()
 def VVPjcQ(self, digit):
  digit = str(digit)
  VV8kKb = self["myMenu"].list
  for ndx, item in enumerate(VV8kKb):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFJYbZ(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVCb6L(ndx)
     self.VV0TcE()
     break
 def VV0TcE(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVodvg:
    self.VVodvg((self, txt, ref, ndx))
   else:
    if self.VVPYdF: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVyRCQ(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVM6M9 and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVM6M9(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVRnTs(self)  : self.VVWMgX(self.VV1zfK)
 def VV01fl(self) : self.VVWMgX(self.VV0MQu)
 def VVE4lo(self) : self.VVWMgX(self.VVinPK)
 def VVP7Ff(self) : self.VVWMgX(self.VVcx0D)
 def VVWMgX(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVWQ3x:
    self.cancel()
 def VVmfbm(self):
  ndx = self["myMenu"].getSelectedIndex()
  VV8kKb = self["myMenu"].list
  VV8kKb.pop(ndx)
  if len(VV8kKb) > 0: self["myMenu"].setList(VV8kKb)
  else    : self.close()
 def VV5IFX(self, basePath, menuObj, fName):
  FFo32K(self, BF(self.VVhcuc, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVhcuc(self, path):
  FFfIuR(path)
  if fileExists(path) : FFAM12(self, "Not deleted", 1000)
  else    : self.VVmfbm()
 def VV2YYg(self, VV8kKb):
  if len(VV8kKb) > 0:
   newList = []
   for item in VV8kKb:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FF1hGr(self, minRows=self.minRows)
  else:
   self.close("")
 def VVswqb(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FF1hGr(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVIh0l(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVCb6L(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVNqRQ(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVCb6L(ndx)
    break
 def VVeV8t(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVCb6L(ndx)
    break
 def VV81TQ(self) : self["myMenu"].moveToIndex(0)
 def VVnEyx(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC7zip(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVI2kC=None, VVmBED=None, VVWFHs=None, VVC5IT=26, VV2v46=False, VVGRvn=0, VVt6tD=None, VVk5TH=None, menuButtonFnc=None, VVOFQa=None, VVaq9G=None, VV9CSs=None, VVTO3h=None, VVOY6r=None, VVZApD=None, VVqFCi=None, VVElod=-1, VVLC3P=0, searchCol=0, lastFindConfigObj=None, VVuGSD=None, VVO7CL=None, VVfk4s="#00dddddd", VV2ftx="#11002233", VV0p3X=None, VVgjmd="#11111111", VVZ0ud="#0a555555", VV62pN="#0affffff", VVGQoh="#11552200", VVBl1a="#0055ff55", VVBl1aRev="#0000bbff"):
  self.skin, self.skinParam = FFpC8B(VV7eKu, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF74S2(self, title)
  self.Title     = title
  self.header     = header
  self.VVI2kC     = VVI2kC
  self.totalCols    = len(VVI2kC[0])
  self.VVGRvn   = VVGRvn
  self.lastSortModeIsReverese = False
  self.VV2v46   = VV2v46
  self.VVjzpO   = 0.01
  self.VVmtY0   = 0.02
  self.VV2enu = 0.03
  self.VVWKlY  = 1
  self.VVWFHs = VVWFHs
  self.colWidthPixels   = []
  self.VVt6tD   = VVt6tD
  self.OKButtonObj   = None
  self.VVk5TH   = VVk5TH
  self.VVOFQa   = VVOFQa
  self.VVaq9G   = VVaq9G
  self.VV9CSs  = VV9CSs
  self.VVTO3h   = VVTO3h
  self.VVOY6r    = VVOY6r
  self.VVZApD   = VVZApD
  self.tableRefreshCB   = None
  self.VVqFCi  = VVqFCi
  self.menuButtonFnc   = menuButtonFnc
  self.VVElod    = VVElod
  self.VVLC3P   = VVLC3P
  self.searchCol    = searchCol
  self.VVmBED    = VVmBED
  self.keyPressed    = -1
  self.VVC5IT    = FFaxOr(VVC5IT)
  self.VVS9mk    = FFrSHG(self.VVC5IT, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVuGSD    = VVuGSD
  self.VVO7CL      = VVO7CL
  self.VVfk4s    = FFhX1r(VVfk4s)
  self.VV2ftx    = FFhX1r(VV2ftx)
  self.VV0p3X    = VV0p3X
  self.VVgjmd    = FFhX1r(VVgjmd)
  self.VVZ0ud   = FFhX1r(VVZ0ud)
  self.VV62pN    = FFhX1r(VV62pN)
  self.VVGQoh    = FFhX1r(VVGQoh)
  self.VVBl1a   = FFhX1r(VVBl1a)
  self.VVBl1aRev  = FFhX1r(VVBl1aRev)
  self.VVY4gV  = False
  self.selectedItems   = 0
  self.VVnB25   = FFhX1r("#01fefe01")
  self.VVBloz   = FFhX1r("#11400040")
  self.VVC2M8  = self.VVnB25
  self.VV7eya  = self.VVgjmd
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVLC3P:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVLC3P == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVeotT  ,
   "red"  : self.VVNziF  ,
   "green"  : self.VVgw9U ,
   "yellow" : self.VVg9xh ,
   "blue"  : self.VVly6P  ,
   "menu"  : self.VVYIvv ,
   "info"  : self.VVY9aU  ,
   "cancel" : self.VVJIWN  ,
   "up"  : self.VVgrUE    ,
   "down"  : self.VVkx8R  ,
   "left"  : self.VVvR0L   ,
   "right"  : self.VV5gAv  ,
   "next"  : self.VV9jSV  ,
   "last"  : self.VVjjWV  ,
   "home"  : self.VVSeCP  ,
   "pageUp" : self.VVSeCP  ,
   "chanUp" : self.VVSeCP  ,
   "end"  : self.VVgusi  ,
   "pageDown" : self.VVgusi  ,
   "chanDown" : self.VVgusi
  }, -1)
  FFD8ln(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  try:
   self.VVJWQH()
  except Exception as e:
   FFrj68(self, str(e), title=self.Title)
   self.close(None)
 def VVJWQH(self):
  FFtJRK(self)
  if self.VVuGSD:
   FFIY0q(self["myTitle"], self.VVuGSD)
  if self.VVO7CL:
   FFIY0q(self["myBody"] , self.VVO7CL)
   FFIY0q(self["myTableH"] , self.VVO7CL)
   FFIY0q(self["myTable"] , self.VVO7CL)
   FFIY0q(self["myBar"]  , self.VVO7CL)
  self.VVwdNX(self.VVOFQa  , self["keyRed"])
  self.VVwdNX(self.VVaq9G  , self["keyGreen"])
  self.VVwdNX(self.VV9CSs , self["keyYellow"])
  self.VVwdNX(self.VVTO3h  , self["keyBlue"])
  if self.VVt6tD:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVt6tD[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVt6tD[0])
    FFIY0q(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVS9mk)
  self["myTableH"].l.setFont(0, gFont(VV9whc, self.VVC5IT))
  self["myTable"].l.setItemHeight(self.VVS9mk)
  self["myTable"].l.setFont(0, gFont(VV9whc, self.VVC5IT))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVS9mk)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVS9mk))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVS9mk)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVS9mk
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVS9mk * len(self.VVI2kC) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVWFHs:
   self.VVWFHs = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVWFHs)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVmBED:
   self.VVmBED = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVmBED
   self.VVmBED = []
   for item in tmpList:
    self.VVmBED.append(item | RT_VALIGN_CENTER)
  self.VVNwWI()
  if self.VVOY6r:
   self.VVOY6r(self)
 def VVwdNX(self, btnFnc, btn):
  if btnFnc : FFFQrh(btn, btnFnc[0])
  else  : FFFQrh(btn, "")
 def VVUIMh(self, waitTxt):
  FF0GsP(self, self.VVNwWI, title=waitTxt)
 def VVNwWI(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVBl1aRev if self.lastSortModeIsReverese else self.VVBl1a
    self["myTableH"].setList([self.VV3p4T(0, self.header, self.VV62pN, self.VVGQoh, self.VV62pN, self.VVGQoh, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVI2kC):
    self["myTable"].list.append(self.VV3p4T(c, row, self.VVfk4s, self.VV2ftx, self.VV0p3X, self.VVgjmd, None))
   self.VVI2kC = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVElod > -1:
    self["myTable"].moveToIndex(self.VVElod )
   self.VVh6Zw()
   if self.VVLC3P:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVS9mk * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFSHXD(self, width, newH)
   if self.VVZApD:
    self.VVWMgX(self.VVZApD, None)
   if self.tableRefreshCB:
    self.VVWMgX(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFrj68(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VV3p4T(self, keyIndex, columns, VVfk4s, VV2ftx, VV0p3X, VVgjmd, VVBl1a):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVBl1a and ndx == self.VVGRvn : textColor = VVBl1a
   else           : textColor = VVfk4s
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFhX1r(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VV2ftx = c
    entry = span.group(3)
   if self.VVmBED[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVS9mk)
           , font   = 0
           , flags   = self.VVmBED[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VV2ftx
           , color_sel  = VV0p3X or textColor
           , backcolor_sel = VVgjmd
           , border_width = 1
           , border_color = self.VVZ0ud
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVY9aU(self):
  rowData = self.VVnRFw()
  if rowData:
   title, txt, colList = rowData
   if self.VVk5TH:
    fnc  = self.VVk5TH[1]
    params = self.VVk5TH[2]
    fnc(self, title, txt, colList)
   else:
    FFaIgn(self, txt, title)
 def VVeotT(self):
  if   self.VVY4gV : self.VVTeMN(self.VV2fe8(), mode=2)
  elif self.VVt6tD  : self.VVWMgX(self.VVt6tD, None)
  else      : self.VVY9aU()
 def VVNziF(self) : self.VVWMgX(self.VVOFQa , self["keyRed"])
 def VVgw9U(self) : self.VVWMgX(self.VVaq9G , self["keyGreen"])
 def VVg9xh(self): self.VVWMgX(self.VV9CSs , self["keyYellow"])
 def VVly6P(self) : self.VVWMgX(self.VVTO3h , self["keyBlue"])
 def VVWMgX(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFAM12(self, buttonFnc[3])
    FF2Wwv(BF(self.VVcD2d, buttonFnc))
   else:
    self.VVcD2d(buttonFnc)
 def VVcD2d(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVnRFw()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVTeMN(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVnB25
   newRow = self.VVM4Gr()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV3p4T(ndx, newRow, self.VVfk4s, self.VV2ftx, self.VV0p3X, self.VVgjmd, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV3p4T(ndx, newRow, self.VVnB25, self.VVBloz, self.VVC2M8, self.VV7eya, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VV2fe8() < len(self["myTable"].list) - 1:
    self.VVkx8R()
   else:
    self.VVh6Zw()
 def VVOqXS(self)  : FF0GsP(self, BF(self.VVnbpG, True ), title="Selecting all ..."  )
 def VVWiLk(self) : FF0GsP(self, BF(self.VVnbpG, False), title="Unselecting all ...")
 def VVnbpG(self, isSel=True):
  if isSel:
   fg, bg = self.VVnB25, self.VVBloz
   self.selectedItems = len(self["myTable"].list)
   self.VV5XOs(True)
  else:
   fg, bg = self.VVfk4s, self.VV2ftx
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVnB25
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVnRFw(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVWFHs[i] > 1 or self.VVWFHs[i] == self.VVjzpO or self.VVWFHs[i] == self.VV2enu:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVJIWN(self):
  if self.VVqFCi : self.VVqFCi(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVp4FO(self):
  return self["myTitle"].getText().strip()
 def VVz8N9(self):
  return self.header
 def VVryn7(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVvyJU(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFIyfV(self["myBar"], color)
 def VVHSZd(self, txt):
  FFAM12(self, txt)
 def VVq4Rc(self, txt, Time=1000):
  FFAM12(self, txt, Time)
 def VVSavX(self): self["keyGreen"].show()
 def VV7bts(self): self["keyGreen"].hide()
 def VVk8Me(self): return self["keyGreen"].visible
 def VVtIYK(self):
  FFAM12(self)
 def VVFoTM(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVXdnH(self):
  return len(self["myTable"].list)
 def VV2fe8(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV9aLU(self):
  return len(self["myTable"].list)
 def VV5XOs(self, isOn):
  self.VVY4gV = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVTO3h: self["keyBlue"].hide()
   if self.VVt6tD and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVTO3h: self["keyBlue"].show()
   if self.VVt6tD and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVt6tD[0])
   self.VVWiLk()
  FFIY0q(self["myTitle"], color)
  FFIY0q(self["myBar"]  , color)
 def VVMhgy(self):
  return self.VVY4gV
 def VVWJ0c(self):
  return self.selectedItems
 def VVdCmE(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVh6Zw()
 def VVImVy(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVarag(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVXdnH()
  txt += FFXlM7("Total Unique Items", VVSBcQ)
  for i in range(self.totalCols):
   if self.VVWFHs[i - 1] > 1 or self.VVWFHs[i - 1] == self.VVjzpO or self.VVWFHs[i - 1] == self.VV2enu:
    name, tot = self.VVImVy(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFaIgn(self, txt)
 def VVIciO(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVM4Gr(self):
  return self.VV4w1S(self["myTable"].l.getCurrentSelectionIndex())
 def VV4w1S(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVByC5(self, newList, newTitle="", VV78xZMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVryn7(newTitle)
  if newList:
   self.VVI2kC = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VV2v46 and self.VVGRvn == 0:
    isNum = True
   else:
    for cols in self.VVI2kC:
     if not FFcx6Z(cols[self.VVGRvn]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVI2kC.sort(key=lambda x: int(x[self.VVGRvn])  , reverse=self.lastSortModeIsReverese)
    else : self.VVI2kC.sort(key=lambda x: x[self.VVGRvn].lower() , reverse=self.lastSortModeIsReverese)
   if VV78xZMsg : self.VVUIMh("Refreshing ...")
   else   : self.VVNwWI()
  else:
   FFrj68(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVuGVo(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VV3p4T(self.VV9aLU(), row, self.VVfk4s, self.VV2ftx, self.VV0p3X, self.VVgjmd, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVgusi()
 def VVRabD(self):
  self["myTable"].list.pop(self.VV2fe8())
  self["myTable"].l.setList(self["myTable"].list)
 def VVtG6o(self, data):
  ndx = self.VV2fe8()
  newRow = self.VV3p4T(ndx, data, self.VVfk4s, self.VV2ftx, self.VV0p3X, self.VVgjmd, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVh6Zw()
   return True
  else:
   return False
 def VVwR5j(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VV3p4T(ndx, data, self.VVfk4s, self.VV2ftx, self.VV0p3X, self.VVgjmd, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVxifL()
 def VVxifL(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVN2Hw(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVEIcu(self, colNum, textToFind, VVSOst=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVh6Zw()
    break
  else:
   if VVSOst:
    FFAM12(self, "Not found", 1000)
 def VV95eY(self, colDict, VVSOst=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVh6Zw()
    return
  if VVSOst:
   FFAM12(self, "Not found", 1000)
  return False
 def VVsdoi(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVPdS6(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFcx6Z(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVbrJg(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVnB25:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVitdD(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVnB25:
     return ndx
  return -1
 def VVzrJF(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVnB25:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVMmb2(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVnB25: return True
  else        : return False
 def VVXwRB(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVYIvv(self):
  if self.menuButtonFnc:
   self.VVcD2d(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVLC3P:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VV2fe8()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VV8kKb1, VVABDr = CCkJDN.VVbAkW(self, False, False)
  VV8kKb = []
  VV8kKb.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VV8kKb.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VV8kKb.append(("Find ...\t\t%s" % (FF7kJS(txt, VVZkFQ) if txt else ""), "findNew"   ))
  VV8kKb.append(itemOf(bool(VV8kKb1)    , "Find (from Filter) ..."   , "filter"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Table Statistcis"             , "tableStat"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((FF7kJS("Export Table to .html"     , VVSBcQ) , "VVhIJW" ))
  VV8kKb.append((FF7kJS("Export Table to .csv"     , VVSBcQ) , "VVVCTy" ))
  VV8kKb.append((FF7kJS("Export Table to .txt (Tab Separated)", VVSBcQ) , "VVIHeG" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVWFHs[i] > 1 or self.VVWFHs[i] == self.VVmtY0:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VV8kKb.append(VVnK97)
   if tot == 1 : VV8kKb.append(("Sort", sList[0][1]))
   else  : VV8kKb += sList
  VVcx0D = ("Keys Help", self.FFyZJ5Help)
  FFHAbB(self, self.VVTaKA, VV8kKb=VV8kKb, title=self.VVp4FO(), VVcx0D=VVcx0D)
 def VVTaKA(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVuZmp()
   elif item == "findPrev"  : self.VVuZmp(isPrev=True)
   elif item == "findNew"  : self.VVbL1h()
   elif item == "filter"  : self.VVone4()
   elif item == "tableStat" : self.VVarag()
   elif item == "VVhIJW": FF0GsP(self, self.VVhIJW, title=title)
   elif item == "VVVCTy" : FF0GsP(self, self.VVVCTy , title=title)
   elif item == "VVIHeG" : FF0GsP(self, self.VVIHeG , title=title)
   else:
    if self.VVGRvn == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVGRvn, self.lastSortModeIsReverese = item, False
    if self.VV2v46 and self.VVGRvn == 0 or self.VVPdS6(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVNwWI(onlyHeader=True)
 def FFyZJ5Help(self, VVNmGv, path):
  FFZzIv(self, "_help_table", "Table (Keys Help)")
 def VVgrUE(self):
  self["myTable"].up()
  self.VVh6Zw()
 def VVkx8R(self):
  self["myTable"].down()
  self.VVh6Zw()
 def VVvR0L(self):
  self["myTable"].pageUp()
  self.VVh6Zw()
 def VV5gAv(self):
  self["myTable"].pageDown()
  self.VVh6Zw()
 def VVSeCP(self):
  self["myTable"].moveToIndex(0)
  self.VVh6Zw()
 def VVgusi(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVh6Zw()
 def VVagt1(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVh6Zw()
 def VV9jSV(self):
  if self.lastFindConfigObj.getValue():
   if self.VV2fe8() == len(self["myTable"].list) - 1 : FFAM12(self, "End reached", 1000)
   else              : self.VVuZmp()
  else:
   FFAM12(self, 'Set "Find" in Menu', 1500)
 def VVjjWV(self):
  if self.lastFindConfigObj.getValue():
   if self.VV2fe8() == 0 : FFAM12(self, "Top reached", 1000)
   else       : self.VVuZmp(isPrev=True)
  else:
   FFAM12(self, 'Set "Find" in Menu', 1500)
 def VVFYbb(self, txt):
  FFaoHf(self.lastFindConfigObj, txt)
 def VVbL1h(self):
  FFTtos(self, self.VVxoxm, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVxoxm(self, VVPnAy):
  if not VVPnAy is None:
   txt = VVPnAy.strip()
   self.VVFYbb(txt)
   if VVPnAy: self.VVuZmp(reset=True)
   else  : FFAM12(self, "Nothing to find !", 1500)
 def VVone4(self):
  VV8kKb, VVABDr = CCkJDN.VVbAkW(self, False, False)
  VVinPK = ("Edit Filter", BF(self.VVp87m, VVABDr))
  if VV8kKb : FFHAbB(self, self.VVTSBa, VV8kKb=VV8kKb, VVinPK=VVinPK, title="Find from Filter")
  else  : FFAM12(self, "Filter Error !", 1500)
 def VVTSBa(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVFYbb(txt)
    self.VVuZmp(reset=True)
   else:
    FFAM12(self, "No entry !", 1500)
 def VVp87m(self, VVABDr, VV476KObj, sel):
  if fileExists(VVABDr) : CCAoYu(self, VVABDr, VVVnlJ=None)
  else       : FFiEaB(self, VVABDr)
  VV476KObj.cancel()
 def VVuZmp(self, reset=False, isPrev=False):
  curRow = self.VV2fe8()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCkJDN.VVN7mE(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVagt1(i)
      break
    elif any(x in line for x in tupl):
     self.VVagt1(i)
     break
   else:
    FFAM12(self, "Not found", 1000)
  else:
   FFAM12(self, "Check your query", 1500)
 def VVIHeG(self):
  expFile = self.VVK49K() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVe9xl()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VV4w1S(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVWFHs[ndx] > self.VVWKlY or self.VVWFHs[ndx] == self.VV2enu:
      col = self.VVwJks(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VV8Hzt(expFile)
 def VVVCTy(self):
  expFile = self.VVK49K() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVe9xl()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VV4w1S(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVWFHs[ndx] > self.VVWKlY or self.VVWFHs[ndx] == self.VV2enu:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVwJks(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VV8Hzt(expFile)
 def VVhIJW(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVp4FO(), PLUGIN_NAME, VVoSRl)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVp4FO()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVe9xl()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVWFHs:
   colgroup += '   <colgroup>'
   for w in self.VVWFHs:
    if w > self.VVWKlY or w == self.VV2enu:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVK49K() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VV4w1S(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVWFHs[ndx] > self.VVWKlY or self.VVWFHs[ndx] == self.VV2enu:
      col = self.VVwJks(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VV8Hzt(expFile)
 def VVe9xl(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVWFHs[ndx] > self.VVWKlY or self.VVWFHs[ndx] == self.VV2enu:
     newRow.append(col.strip())
  return newRow
 def VVwJks(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFJYbZ(col)
 def VVK49K(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVp4FO())
  fileName = fileName.replace("__", "_")
  path  = FFxiJi(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFC2jX()
  return expFile
 def VV8Hzt(self, expFile):
  FF9glI(self, "File exported to:\n\n%s" % expFile, title=self.VVp4FO())
 def VVh6Zw(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCCyfp():
 def __init__(self, pixmapObj, picPath, VV2ftx=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VV2ftx  = VV2ftx or "#2200002a"
 def VVUGl9(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVHRVw)
    except:
     self.picLoad.PictureData.get().append(self.VVHRVw)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VV2ftx])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVHRVw(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVRE9x(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVbhHo(pixmapObj, path, VV2ftx=None):
  cl = CCCyfp(pixmapObj, path, VV2ftx)
  ok = cl.VVUGl9()
  if ok: return cl
  else : return None
class CCJCdT(Screen):
 def __init__(self, session, VVRuzQ, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFKONN()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFpC8B(VVkFYy, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVRuzQ = VVRuzQ
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FF74S2(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVcyg1  ,
   "up" : BF(self.VVg5IS, -1),
   "down" : BF(self.VVg5IS,  1),
   "left" : BF(self.VVg5IS, -1),
   "right" : BF(self.VVg5IS,  1)
  }, -1)
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  self.VVX2Rk()
  self.picViewer = CCCyfp.VVbhHo(self["myPic"], self.VVRuzQ)
  if self.picViewer:
   if self.showGrnMsg:
    FFAM12(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFrj68(self, "Cannot view picture file:\n\n%s" % self.VVRuzQ)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVRE9x()
  if self.cbFnc  : self.cbFnc(self.VVRuzQ)
 def VVg5IS(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVRuzQ = FFxiJi(os.path.dirname(self.VVRuzQ)) + fName
    self.picViewer.picPath = self.VVRuzQ
    self.picViewer.VVUGl9()
    self.VVX2Rk()
 def VVcyg1(self):
  txt = "%s:\n  %s" % (FF7kJS("Path", VVSFOM), self.fakePath or self.VVRuzQ)
  size, sizeTxt, resTxt, form, mode = CC0IN8.VVfLtI(self.VVRuzQ)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FF7kJS("Properties", VVSFOM)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFaIgn(self, txt, title="File Information")
 def VVX2Rk(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVRuzQ)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVHj4i(SELF, VVRuzQ, **kwargs):
  SELF.session.open(CCJCdT, VVRuzQ, **kwargs)
class CCFWUe(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFpC8B(VVQoWM, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FF74S2(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.onExit)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFWnHJ("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VV5PQ2(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCFWUe.VVIadP, SELF), CCFWUe, mviFile)
 @staticmethod
 def VVIadP(SELF, reason=None):
  if reason == -1: FFrj68(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CC8YBo(Screen, ConfigListScreen):
 VVROHc = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VVQ1ff, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF74S2(self, title=self.Title)
  FFFQrh(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVrSon()
  self.onShown.append(self.VVHrlo)
 def VVrSon(self):
  kList = {
    "ok" : self.VV0TcE   ,
    "green" : self.VVkeSQ ,
    "menu" : self.VVFUHU ,
    "cancel": self.VVx4gB ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVGRmu, 0)
     kList["chanDown"] = BF(self["config"].VVGRmu, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFgqCi(self)
  FFl94Z(self["config"])
  FF1hGr(self, self["config"])
  FFtJRK(self)
  self["config"].onSelectionChanged.append(self.VVUh39)
  FFIY0q(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VVUh39()
 def VVUh39(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VV0TcE(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVfOlM()
   elif item == CFG.MovieDownloadPath   : self.VVAD8p(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VV95i6()
   elif isinstance(item, ConfigDirectory) : self.VV9LrH(item)
   else         : CC8YBo.VVZpf5(self, item, title)
 @staticmethod
 def VVZpf5(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VV8kKb = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVZkFQ + txt
    elif val == confItem.default: defNdx, txt = ndx, VV691Y + txt
   VV8kKb.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVcx0D  = ("Current", BF(CC8YBo.VVnj51, curNdx))
  VVinPK = ("Default", BF(CC8YBo.VVnj51, defNdx))
  VVNmGv = FFHAbB(SELF, BF(CC8YBo.VVDNXl, confItem, cbFnc, isSave), VV8kKb=VV8kKb, width=1200, VVinPK=VVinPK, VVcx0D=VVcx0D, title=title, VVuGSD="#33221111", VVO7CL="#33110011")
  VVNmGv.VVCb6L(curNdx)
 @staticmethod
 def VVDNXl(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFaoHf(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVnj51(ndx, VV476KObj, item):
  VV476KObj.VVCb6L(ndx)
 @staticmethod
 def VVcaQl(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVAD8p(self, item, title):
  tot = CCnvmH.VV5SuY()
  if tot : FFrj68(self, "Cannot change while downloading.", title=title)
  else : self.VV9LrH(item)
 def VV95i6(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCP2t1.VV2clf(self, "", curEnc)
  if lst:
   VVinPK = ("Default", self.VVU5c4)
   VVcx0D  = ("Current", self.VVAZjk)
   VVNmGv = FFHAbB(self, self.VVPtqm, title="Select Priority Encoding", VV8kKb=lst, width=1000, height=1000, VVcx0D=VVcx0D, VVinPK=VVinPK, VVuGSD="#22220000", VVO7CL="#22220000", VVPYdF=True)
   VVNmGv.VVNqRQ(curEnc)
 def VVPtqm(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVU5c4(self, VVNmGv, item): VVNmGv.VVNqRQ(VVEYMF)
 def VVAZjk(self, VVNmGv, item): VVNmGv.VVNqRQ(CFG.subtDefaultEnc.getValue())
 def VVfOlM(self):
  VV8kKb = []
  VV8kKb.append(("Auto Find" , "auto"))
  VV8kKb.append(("Custom Path" , "cust"))
  FFHAbB(self, self.VV9qyH, VV8kKb=VV8kKb, title="IPTV Hosts Files Path")
 def VV9qyH(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VV4mJx)
   elif item == "cust":
    VVDb2Q = self.VVWK35()
    if VVDb2Q : self.VVyWT9(VVDb2Q)
    else  : self.session.openWithCallback(self.VV5zDx, BF(CCFric, mode=CCFric.VVocwE, VVZmiW="/"))
 def VVyWT9(self, VVDb2Q):
  VVqFCi = self.VVoPbn
  VVOFQa = ("Remove"  , self.VVBw8B , [])
  VV9CSs = ("Add "  , self.VVFKnx, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVmBED  = (LEFT   , LEFT  )
  FFyZJ5(self, None, title="IPTV Hosts Search Paths", header=header, VVI2kC=VVDb2Q, width=1200, height=700, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=26, VVqFCi=VVqFCi, VVOFQa=VVOFQa, VV9CSs=VV9CSs
    , VVuGSD="#22220000", VVO7CL="#22110000", VV2ftx="#22110011", VVgjmd="#11223025", VVZ0ud="#0a333333", VVGQoh="#11400040")
 def VVoPbn(self, VVt27A):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVBZu4)
  VVt27A.cancel()
 def VV5zDx(self, path):
  if path:
   FFaoHf(CFG.iptvHostsDirs, FFxiJi(path.strip()))
   VVDb2Q = self.VVWK35()
   if VVDb2Q : self.VVyWT9(VVDb2Q)
   else  : FFAM12(self, "Cannot add dir", 1500)
 def VVSeeV(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VV4mJx:
   return []
  return lst
 def VVWK35(self):
  lst = self.VVSeeV()
  if lst:
   VVDb2Q = []
   for Dir in lst:
    VVDb2Q.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVDb2Q.sort(key=lambda x: x[0].lower())
   return VVDb2Q
  else:
   return []
 def VVFKnx(self, VVt27A, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VV6Iwt, VVt27A)
         , BF(CCFric, mode=CCFric.VVocwE, VVZmiW=sDir))
 def VV6Iwt(self, VVt27A, path):
  if path:
   path = FFxiJi(path.strip())
   if self.VVPI7G(VVt27A, path):
    FFAM12(VVt27A, "Already added", 1500)
   else:
    lst = self.VVSeeV()
    lst.append(path)
    FFaoHf(CFG.iptvHostsDirs, ",".join(lst))
    VVDb2Q = self.VVWK35()
    VVt27A.VVByC5(VVDb2Q, tableRefreshCB=BF(self.VVtTKW, path))
 def VVtTKW(self, path, VVt27A, title, txt, colList):
  self.VVPI7G(VVt27A, path)
 def VVPI7G(self, VVt27A, path):
  for ndx, row in enumerate(VVt27A.VVXwRB()):
   if row[0].strip() == path.strip():
    VVt27A.VVagt1(ndx)
    return True
  return False
 def VVBw8B(self, VVt27A, title, txt, colList):
  path = colList[0]
  FFo32K(self, BF(self.VVOKYx, VVt27A), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVOKYx(self, VVt27A):
  row = VVt27A.VVM4Gr()
  path, rem = row[0], row[1]
  VVDb2Q = []
  lst = []
  for ndx, row in enumerate(VVt27A.VVXwRB()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVDb2Q.append((tPath, tRem))
  if len(VVDb2Q) > 0:
   FFaoHf(CFG.iptvHostsDirs, ",".join(lst))
   VVt27A.VVByC5(VVDb2Q)
   FFAM12(VVt27A, "Deleted", 1500)
  else:
   FFaoHf(CFG.iptvHostsMode, VV4mJx)
   FFaoHf(CFG.iptvHostsDirs, "")
   VVt27A.cancel()
   FF2Wwv(BF(FFAM12, self, "Changed to Auto-Find", 1500))
 def VV9LrH(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVq8d9, configObj)
         , BF(CCFric, mode=CCFric.VVocwE, VVZmiW=sDir))
 def VVq8d9(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVx4gB(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFo32K(self, self.VVkeSQ, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVkeSQ(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVkXAT()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVFUHU(self):
  VV8kKb = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VV8kKb.append((txt    , "VVCLXL"   ))
  else        : VV8kKb.append((txt    ,       ))
  VV8kKb.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Reset %s Settings" % PLUGIN_NAME      , "VVwxeD"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Backup %s Settings" % PLUGIN_NAME      , "VVhhhI"  ))
  VV8kKb.append(("Restore %s Settings" % PLUGIN_NAME     , "VV7tr0"  ))
  if fileExists(VVBI3c + CC8YBo.VVROHc):
   VV8kKb.append(VVnK97)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VV8kKb.append(('%s Checking for Update' % txt1     , txt2     ))
   VV8kKb.append(("Reinstall %s" % PLUGIN_NAME      , "VVpBDO"  ))
   VV8kKb.append(("Update %s" % PLUGIN_NAME      , "VVvnXQ"   ))
  FFHAbB(self, self.VV8E6H, VV8kKb=VV8kKb, title="Config. Options")
 def VV8E6H(self, item=None):
  if item:
   if   item == "VVCLXL"  : FFo32K(self, self.VVCLXL , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCTWTN)
   elif item == "VVwxeD"  : FFo32K(self, BF(self.VVwxeD, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVhhhI" : self.VVhhhI()
   elif item == "VV7tr0" : FF0GsP(self, self.VV7tr0, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFaoHf(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFaoHf(CFG.checkForUpdateAtStartup, False)
   elif item == "VVpBDO" : FF0GsP(self, BF(self.VVqXuR, True ), "Checking Server ...")
   elif item == "VVvnXQ"  : FF0GsP(self, BF(self.VVqXuR, False), "Checking Server ...")
 def VVhhhI(self):
  path = "%sajpanel_settings_%s" % (VVBI3c, FFC2jX())
  FF9QaZ("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVORe1, path))
  FF9glI(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV7tr0(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFO8C9("find / %s -iname '%s*' | grep %s" % (FFViIp(1), name, name))
  if files:
   err = CCFric.VVvwlA(files)
   if err:
    FFo32K(self, BF(self.VVh1ub, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VV8kKb = []
    for line in files:
     VV8kKb.append((line, line))
    FFHAbB(self, BF(self.VV1S5P, title), title=title, VV8kKb=VV8kKb, width=1200, VVj7dk="")
  else:
   FFrj68(self, "No settings files found !", title=title)
 def VVh1ub(self, title, path=None):
  sDir = "/"
  for path in (VVBI3c, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VV1S5P, title), BF(CCFric, patternMode="ajpSet", VVZmiW=sDir))
 def VV1S5P(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFKcIu(path)
    self.VVwxeD()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVkXAT()
    FFpVsc()
    FFAM12(self, "Apllied", 1500, isGrn=True)
   else:
    FFiEaB(self, path, title=title)
 def VVCLXL(self):
  newPath = FFxiJi(VVBI3c)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVkXAT()
 @staticmethod
 def VVtxg4():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVwxeD(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVkXAT()
  if exit:
   self.close()
 def VVkXAT(self):
  configfile.save()
  global VVBI3c
  VVBI3c = CFG.backupPath.getValue()
  FFH03V()
 def VVqXuR(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CC8YBo.VVfamk()
  if   err    : FFrj68(self, err, title)
  elif isHigher or force : FFo32K(self, BF(FF0GsP, self, BF(self.VVRAI1, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FF9glI(self, FF7kJS("No update required.", VVomgc) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVRAI1(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFiXBo() == "dpkg" else "ipk")
  path, err = FFadHO(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFMlY4(VVpHks, path)
   else : cmd = FFMlY4(VV7Fa0, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFSEeb(self, cmd, title=title)
   else:
    FFUrcP(self, title=title)
  else:
   FFrj68(self, err, title=title)
 @staticmethod
 def VVfamk():
  span = iSearch(r"v*(\d.\d.\d)", VVoSRl, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVBI3c + CC8YBo.VVROHc
  if fileExists(path):
   span = iSearch(r"(http.+)", FFQByV(path), IGNORECASE)
   if span : url = FFxiJi(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFadHO(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFQByV(path).strip().replace(" ", "")
   FFfIuR(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCTWTN(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VVbInz, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVE6Dq
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF74S2(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVbVFz("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVbVFz("\c00888888", i) + sp + "GREY\n"
   txt += self.VVbVFz("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVbVFz("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVbVFz("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVbVFz("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVbVFz("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVbVFz("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVbVFz("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVbVFz("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVbVFz("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVbVFz("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VV0TcE ,
   "green" : self.VV0TcE ,
   "left" : self.VVAwoe ,
   "right" : self.VVhFYt ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  self.VVOKUZ()
 def VV0TcE(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFo32K(self, self.VVxHWx, "Change to : %s" % txt, title=self.Title)
 def VVxHWx(self):
  FFaoHf(CFG.mixedColorScheme, self.cursorPos)
  global VVE6Dq
  VVE6Dq = self.cursorPos
  self.VVd3bG()
  self.close()
 def VVAwoe(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVOKUZ()
 def VVhFYt(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVOKUZ()
 def VVOKUZ(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVbVFz(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV0VOj(color):
  if VV691Y: return "\\" + color
  else    : return ""
 @staticmethod
 def VVd3bG():
  global VVuopv, VViSml, VVD6mq, VVvkGK, VVSBcQ, VV4d6Z, VVM17H, VVD1jS, VVomgc, VV30Pd, VV691Y, VVSFOM, VVZkFQ, VVLAFW, VVrexq, VVkbX3
  VVkbX3   = CCTWTN.VVbVFz("\c00FFFFFF", VVE6Dq)
  VViSml    = CCTWTN.VVbVFz("\c00888888", VVE6Dq)
  VVuopv  = CCTWTN.VVbVFz("\c005A5A5A", VVE6Dq)
  VVD1jS    = CCTWTN.VVbVFz("\c00FF0000", VVE6Dq)
  VVD6mq   = CCTWTN.VVbVFz("\c00FF5000", VVE6Dq)
  VVvkGK   = CCTWTN.VVbVFz("\c00FFBB66", VVE6Dq)
  VV691Y   = CCTWTN.VVbVFz("\c00FFFF00", VVE6Dq)
  VVSFOM = CCTWTN.VVbVFz("\c00FFFFAA", VVE6Dq)
  VVomgc   = CCTWTN.VVbVFz("\c0000FF00", VVE6Dq)
  VV30Pd  = CCTWTN.VVbVFz("\c00AAFFAA", VVE6Dq)
  VVM17H    = CCTWTN.VVbVFz("\c000066FF", VVE6Dq)
  VVZkFQ    = CCTWTN.VVbVFz("\c0000FFFF", VVE6Dq)
  VVLAFW  = CCTWTN.VVbVFz("\c00AAFFFF", VVE6Dq)  #
  VVrexq   = CCTWTN.VVbVFz("\c00FA55E7", VVE6Dq)
  VVSBcQ    = CCTWTN.VVbVFz("\c00FF8F5F", VVE6Dq)
  VV4d6Z  = CCTWTN.VVbVFz("\c00FFC0C0", VVE6Dq)
CCTWTN.VVd3bG()
class CCrfCS(Screen):
 def __init__(self, session, path, VVpmZd):
  self.skin, self.skinParam = FFpC8B(VV1QnR, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVs4Bz   = path
  self.VV7f6v   = ""
  self.VVvkmr   = ""
  self.VVpmZd    = VVpmZd
  self.VVOCSe    = ""
  self.VVBU1L  = ""
  self.VVgqXe    = False
  self.VVTRfQ  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VV7KPu  = "enigma2-plugin-extensions-"
  self.VVhZ8o  = "enigma2-plugin-systemplugins-"
  self.VVlRgk = "enigma2-"
  self.VVLP2n  = 0
  self.VV0zWT  = 1
  self.VVB9Lu  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVr2P9 = "DEBIAN"
  else        : self.VVr2P9 = "CONTROL"
  self.controlPath = self.Path + self.VVr2P9
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVpmZd:
   self.packageExt  = ".deb"
   self.VV2ftx  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VV2ftx  = "#11001020"
  FF74S2(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFFQrh(self["keyRed"] , "Create")
  FFFQrh(self["keyGreen"] , "Post Install")
  FFFQrh(self["keyYellow"], "Installation Path")
  FFFQrh(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVlxvt  ,
   "green"   : self.VVT9C8 ,
   "yellow"  : self.VVTLPW  ,
   "blue"   : self.VVdRg4  ,
   "cancel"  : self.VVss0c
  }, -1)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFtJRK(self)
  if self.VV2ftx:
   FFIY0q(self["myBody"], self.VV2ftx)
   FFIY0q(self["myLabel"], self.VV2ftx)
  self.VVr8DQ(True)
  self.VVINHn(True)
 def VVINHn(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVCs1n()
  if isFirstTime:
   if   package.startswith(self.VV7KPu) : self.VVs4Bz = VVgk0E + self.VVOCSe + "/"
   elif package.startswith(self.VVhZ8o) : self.VVs4Bz = VVJdOR + self.VVOCSe + "/"
   else            : self.VVs4Bz = self.Path
  if self.VVgqXe : myColor = VVSBcQ
  else    : myColor = VVkbX3
  txt  = ""
  txt += "Source Path\t: %s\n" % FF7kJS(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF7kJS(self.VVs4Bz, VV691Y)
  if self.VVvkmr : txt += "Package File\t: %s\n" % FF7kJS(self.VVvkmr, VViSml)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF7kJS("Check Control File fields : %s" % errTxt, VVD6mq)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF7kJS("Restart GUI", VVSBcQ)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF7kJS("Reboot Device", VVSBcQ)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FF7kJS("Post Install", VVomgc), act)
  if not errTxt and VVD6mq in controlInfo:
   txt += "Warning\t: %s\n" % FF7kJS("Errors in control file may affect the result package.", VVD6mq)
  txt += "\nControl File\t: %s\n" % FF7kJS(self.controlFile, VViSml)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVT9C8(self):
  if self["keyGreen"].getVisible():
   VV8kKb = []
   VV8kKb.append(("No Action"    , "noAction"  ))
   VV8kKb.append(("Restart GUI"    , "VVWwHQ"  ))
   VV8kKb.append(("Reboot Device"   , "rebootDev"  ))
   FFHAbB(self, self.VVkGwh, title="Package Installation Option (after completing installation)", VV8kKb=VV8kKb)
 def VVkGwh(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVWwHQ"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVr8DQ(False)
   self.VVINHn()
 def VVTLPW(self):
  rootPath = FF7kJS("/%s/" % self.VVOCSe, VVSFOM)
  VV8kKb = []
  VV8kKb.append(("Current Path"        , "toCurrent"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Extension Path"       , "toExtensions" ))
  VV8kKb.append(("System Plugins Path"      , "toSystemPlugins" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VV8kKb.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFHAbB(self, self.VVg49k, title="Installation Path", VV8kKb=VV8kKb)
 def VVg49k(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVyKqA(FFoVse(self.Path, True))
   elif item == "toExtensions"  : self.VVyKqA(VVgk0E)
   elif item == "toSystemPlugins" : self.VVyKqA(VVJdOR)
   elif item == "toRootPath"  : self.VVyKqA("/")
   elif item == "toRoot"   : self.VVyKqA("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVLGmz, BF(CCFric, mode=CCFric.VVocwE, VVZmiW=VVBI3c))
 def VVLGmz(self, path):
  if len(path) > 0:
   self.VVyKqA(path)
 def VVyKqA(self, parent, withPackageName=True):
  if withPackageName : self.VVs4Bz = parent + self.VVOCSe + "/"
  else    : self.VVs4Bz = "/"
  mode = self.VVoY3C()
  FFWnHJ("sed -i '/Package/c\Package: %s' %s" % (self.VV0wTs(mode), self.controlFile))
  self.VVINHn()
 def VVdRg4(self):
  if fileExists(self.controlFile):
   lines = FFKcIu(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFTtos(self, self.VVZrzy, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFrj68(self, "Version not found or incorrectly set !")
  else:
   FFiEaB(self, self.controlFile)
 def VVZrzy(self, VVPnAy):
  if VVPnAy:
   version, color = self.VVoREB(VVPnAy, False)
   if color == VVZkFQ:
    FFWnHJ("sed -i '/Version:/c\Version: %s' %s" % (VVPnAy, self.controlFile))
    self.VVINHn()
   else:
    FFrj68(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVss0c(self):
  if self.newControlPath:
   if self.VVgqXe:
    self.VVUT8v()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF7kJS(self.newControlPath, VViSml)
    txt += FF7kJS("Do you want to keep these files ?", VV691Y)
    FFo32K(self, self.close, txt, callBack_No=self.VVUT8v, title="Create Package", VVjDSl=True)
  else:
   self.close()
 def VVUT8v(self):
  FFWnHJ("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VV0wTs(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVBU1L
  if package.startswith(self.VVlRgk):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVlRgk, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VV0zWT : prefix = self.VV7KPu
  elif mode == self.VVB9Lu : prefix = self.VVhZ8o
  return (prefix + name).lower()
 def VVoY3C(self):
  if   self.VVs4Bz.startswith(VVgk0E) : return self.VV0zWT
  elif self.VVs4Bz.startswith(VVJdOR) : return self.VVB9Lu
  else            : return self.VVLP2n
 def VVr8DQ(self, isFirstTime):
  self.VVOCSe   = FFM4mE(self.Path)
  self.VVOCSe   = "_".join(self.VVOCSe.split())
  self.VVBU1L = self.VVOCSe.lower()
  self.VVgqXe = self.VVBU1L == VVupPm.lower()
  if self.VVgqXe and self.VVBU1L.endswith(VVupPm.lower()):
   self.VVBU1L += "el"
  if self.VVgqXe : self.VV7f6v = VVBI3c
  else    : self.VV7f6v = CFG.packageOutputPath.getValue()
  self.VV7f6v = FFxiJi(self.VV7f6v)
  if not pathExists(self.controlPath):
   FFWnHJ("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVoY3C()
  if fileExists(self.controlFile):
   lines = FFKcIu(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVgqXe : version, descripton, maintainer = VVoSRl , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVOCSe , self.VVOCSe
   txt = ""
   txt += "Package: %s\n"  % self.VV0wTs(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVgqXe : t = PLUGIN_NAME
  else    : t = self.VVOCSe
  self.VV2vE7(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VV2vE7(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVgqXe : self.VV2vE7(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVoSRl))
  else    : self.VV2vE7(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVOCSe)
  if isFirstTime and not mode == self.VVLP2n:
   self.postInstAcion = 1
  txt = self.VVFMIi(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFQByV(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVFMIi(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFWnHJ("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VV2vE7(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVFMIi(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVCs1n(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFKcIu(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF7kJS(line, VVD6mq)
     elif not line.startswith(" ")    : line = FF7kJS(line, VVD6mq)
     else          : line = FF7kJS(line, VVZkFQ)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVZkFQ
   else   : color = VVD6mq
   descr = FF7kJS(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVD6mq
     elif line.startswith((" ", "\t")) : color = VVD6mq
     elif line.startswith("#")   : color = VViSml
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVoREB(val, True)
      elif key == "Version"  : version, color = self.VVoREB(val, False)
      elif key == "Maintainer" : maint  , color = val, VVZkFQ
      elif key == "Architecture" : arch  , color = val, VVZkFQ
      else:
       color = VVZkFQ
      if not key == "OE" and not key.istitle():
       color = VVD6mq
     else:
      color = VVSBcQ
     txt += FF7kJS(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVvkmr = self.VV7f6v + packageName
   self.VVTRfQ = True
   errTxt = ""
  else:
   self.VVvkmr  = ""
   self.VVTRfQ = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVoREB(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVZkFQ
  else          : return val, VVD6mq
 def VVlxvt(self):
  if not self.VVTRfQ:
   FFrj68(self, "Please fix Control File errors first.")
   return
  if self.VVpmZd: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFoVse(self.VVs4Bz, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVOCSe
  symlinkTo  = FFz551(self.Path)
  dataDir   = self.VVs4Bz.rstrip("/")
  removePorjDir = FFhyjZ("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFhyjZ("rm -f '%s'" % self.VVvkmr)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFEDUQ()
  if self.VVpmZd:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFLwTR("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVgqXe:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVs4Bz == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVr2P9)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVvkmr, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVvkmr
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVvkmr, FFQQct(result  , VVomgc))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVs4Bz, FFQQct(instPath, VVZkFQ))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFQQct(failed, VVD6mq))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFSEeb(self, cmd)
class CCQo5X():
 VVIg0E  = "666"
 VVVfI0   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVNmGv   = None
  self.VV5oQB()
 def VV5oQB(self):
  VV8kKb = CCQo5X.VVgD5I()
  if VV8kKb:
   VVinPK = ("Create New", self.VV0UtB)
   self.VVNmGv = FFHAbB(self.SELF, self.VVm288, VV8kKb=VV8kKb, title=self.Title, VVinPK=VVinPK, VVPYdF=True, VVuGSD="#22222233", VVO7CL="#22222233")
  else:
   self.VV0UtB()
 def VVm288(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVK8ur(bName, bRef)
  else:
   CCQo5X.VV5596(self)
 def VV0UtB(self, VV476KObj=None, item=None):
  FFTtos(self.SELF, BF(self.VVqTml), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVqTml(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVNmGv:
     self.VVNmGv.cancel()
    self.VVK8ur(bName, "")
   else:
    FFAM12(self.VVNmGv, "Incorrect Bouquet Name !", 2000)
    CCQo5X.VV5596(self)
 def VVK8ur(self, bName, bRef):
  FF0GsP(self.waitMsgSELF, BF(self.VV5mal, bName, bRef), title="Adding Services ...")
 def VV5mal(self, bName, bRef):
  CCQo5X.VVzV4N(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VV5596(classObj):
  del classObj
 @staticmethod
 def VVzV4N(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFrj68(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVORe1 + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFiEaB(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCQo5X.VVXFOT(bRef)
   bPath = VVORe1 + bFile
  else:
   fName = CC1B0Q.VVxag1(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVORe1 + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVORe1 + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFTYOF(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFTYOF(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCHnG6.VVYipk()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFWnHJ("cp -f '%s' '%s'" % (poster, picon))
       FFWnHJ(CCOQON.VVTaWN(picon))
       break
  FFczPJ()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFaIgn(SELF, txt, title=title)
 @staticmethod
 def VVgD5I(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VV8kKb = []
  if mode in (0, 2): VV8kKb.extend(CCQo5X.VVaWqd(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VV8kKb.extend(CCQo5X.VVaWqd(1, showTitle, prefix, onlyIptv))
  return VV8kKb
 @staticmethod
 def VVaWqd(mode, showTitle, prefix, onlyIptv):
  VV8kKb = []
  lst = CCQo5X.VVsABQ(mode)
  if onlyIptv:
   lst = CCQo5X.VVJUJd(lst)
  if lst:
   if showTitle:
    VV8kKb.append(FFDGmo("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VV8kKb.append((item[0], prefix + item[0]))
   else:
    for item in lst : VV8kKb.append((item[0], item[1].toString()))
  return VV8kKb
 @staticmethod
 def VVJUJd(lst):
  fLst = CC1B0Q.VVqr8J(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVePOY():
  bLise = CCQo5X.VVsABQ(0)
  bLise.extend(CCQo5X.VVsABQ(1))
  return bLise
 @staticmethod
 def VVsABQ(mode=0):
  bList = []
  VVWHhY = InfoBar.instance
  VVaBL4 = VVWHhY and VVWHhY.servicelist
  if VVaBL4:
   curMode = VVaBL4.mode
   CCQo5X.VVuSNh(VVaBL4, mode)
   bList.extend(VVaBL4.getBouquetList() or [])
   CCQo5X.VVuSNh(VVaBL4, curMode)
  return bList
 @staticmethod
 def VVuSNh(VVaBL4, mode):
  if not mode == VVaBL4.mode:
   if   mode == 0: VVaBL4.setModeTv()
   elif mode == 1: VVaBL4.setModeRadio()
 @staticmethod
 def VVXFOT(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVtXkS():
  try:
   fName = CCQo5X.VVXFOT(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVORe1, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VV0SNX():
  path = CCQo5X.VVtXkS()
  if path:
   txt = FFQByV(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVaPgW():
  return FFxPkx(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVcKgQ():
  lst = []
  for b in CCQo5X.VVePOY():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVORe1 + CCQo5X.VVXFOT(bRef)
   if fileExists(path):
    lines = FFKcIu(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVMXxo(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVGzwx(SID="", stripRType=False):
  if SID : patt = CCQo5X.VVMXxo(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCQo5X.VVePOY():
   for service in FFxPkx(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVhDrb():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCQo5X.VVePOY():
   for service in FFxPkx(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVuoml(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVDnzV(pathLst, rType=""):
  refLst = CCQo5X.VVGzwx(CCQo5X.VVIg0E, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCQo5X.VVuoml(rType, CCQo5X.VVIg0E, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCFric(Screen):
 VV9LS7   = 0
 VVs7cM  = 1
 VVocwE  = 2
 VVbeik = 3
 VVXxla    = 20
 VVhK3C   = 0
 VVR5ma   = 1
 VVWJho   = 2
 def __init__(self, session, VVZmiW="/", mode=VV9LS7, VV9ghp="Select", width=1400, height=920, VVC5IT=30, VVuGSD="#22001111", VVO7CL="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFpC8B(VVX871, width, height, 30, 40, 20, VVuGSD, VVO7CL, VVC5IT, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVuGSD   = VVuGSD
  self.VVO7CL    = VVO7CL
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FF74S2(self)
  FFFQrh(self["keyRed"] , "Exit")
  FFFQrh(self["keyYellow"], "More Options")
  FFFQrh(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV9ghp = VV9ghp
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVSWXD = None
  if patternMode:
   self.mode = self.VVbeik
   if   patternMode == "srt"  : VVSWXD = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVSWXD = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVSWXD = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVSWXD = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVSWXD = ("^.*\.(%s)$" % "|".join(CCz7OO.VVFMqt()["mov"]), IGNORECASE)
   else       : VVSWXD = None
  if self.mode in (self.VVocwE, self.VVbeik):
   FFFQrh(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVLcsf, self.VVZmiW = True , FFoVse(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVLcsf, self.VVZmiW = True , CCFric.VVEl1L(self)[1] or "/"
  elif self.mode == self.VV9LS7  : VVLcsf, self.VVZmiW = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVocwE : VVLcsf, self.VVZmiW = False, VVZmiW
  elif self.mode == self.VVbeik : VVLcsf, self.VVZmiW = True , VVZmiW
  else           : VVLcsf, self.VVZmiW = True , VVZmiW
  self.VVZmiW = FFxiJi(self.VVZmiW)
  self["myMenu"] = CCz7OO(  directory   = None
         , VVSWXD = VVSWXD
         , VVLcsf   = VVLcsf
         , VVyNJU = True
         , VVPHvp = True
         , VVcI5n   = self.skinParam["width"]
         , VVC5IT   = self.skinParam["bodyFontSize"]
         , VVS9mk  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VV0TcE    ,
   "red" : self.VV1iOi   ,
   "green" : self.VVzk8a,
   "yellow": self.VVPwTs  ,
   "blue" : self.VVsnYR ,
   "menu" : self.VVaWsP  ,
   "info" : self.VVFC6S  ,
   "cancel": self.VV2cMB    ,
   "pageUp": self.VVSZMW   ,
   "chanUp": self.VVSZMW
  }, -1)
  FFD8ln(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVX0zU)
  global VVzCRB
  VVzCRB = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VV9LS7:
   global VVzCRB
   del VVzCRB
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVX0zU)
  FFgqCi(self)
  FFl94Z(self["myMenu"], bg=self.cursorBG)
  FFtJRK(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVocwE, self.VVbeik):
   FFFQrh(self["keyGreen"], self.VV9ghp)
   self.VVUp4U(self.VVR5ma)
  self.VVX0zU()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVEbTd(self.VVZmiW) > self.bigDirSize: FF0GsP(self, self.VVA6Wl, title="Changing directory...")
  else              : self.VVA6Wl()
 def VVA6Wl(self):
  if self.jumpToFile : self.VVpGHQ(self.jumpToFile)
  elif self.gotoMovie : self.VVWYSe(chDir=False)
  else    : self["myMenu"].VVfLjF(self.VVZmiW)
 def VVagt1(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVnChI(self):
  FF0GsP(self, self.VV6X4r, title="Refreshing list ...")
 def VV6X4r(self):
  isSel = self["myMenu"].VV66tj()
  if not isSel:
   self.VVjbD3(False)
  FFzWhD()
 def VVuMap(self, saved):
  if saved: self.VVnChI()
 def VVEbTd(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VV0TcE(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVTXKU()
   if ok : self["keyBlue"].setText(self.VVh2v6())
   else : FFAM12(self, "Cannot select item", 500)
  elif self["myMenu"].VVowQb(): self.VVpWEj()
  else       : self.VVpv5f()
 def VVSZMW(self):
  if self.multiSelectState:
   FFAM12(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVtPfU():
    self.VVpWEj()
 def VVpWEj(self, isDirUp=False):
  if self["myMenu"].VVowQb():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVGGU0(self.VV476K())
   if self.VVEbTd(path) > self.bigDirSize : FF0GsP(self, self.VVAyo1, title="Changing directory...")
   else           : self.VVAyo1()
 def VVAyo1(self):
  self["myMenu"].descent()
  self.VVX0zU()
 def VV2cMB(self):
  if   self.multiSelectState     : self.VVjbD3(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VV1iOi()
  else          : self.VVSZMW()
 def VV1iOi(self):
  if not FFHGMZ(self):
   self.close("")
 def VVzk8a(self):
  path = self.VVGGU0(self.VV476K())
  if self.mode == self.VVocwE:
   self.close(path)
  elif self.mode == self.VVbeik:
   if os.path.isfile(path) : self.close(path)
   else     : FFAM12(self, "Cannot access this file", 1000)
 def VVFC6S(self):
  FF0GsP(self, self.VVKdir, title="Calculating size ...")
 def VVKdir(self):
  path = self.VVGGU0(self.VV476K())
  param = self.VVwe0z(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFdVkh("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCFric.VVcbVM(path)
     freeSize = CCFric.VV5FZe(path)
     size = totSize - freeSize
     totSize  = CCFric.VVgYti(totSize)
     freeSize = CCFric.VVgYti(freeSize)
    else:
     size = FFCcy5(path)
   usedSize = CCFric.VVgYti(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF7kJS(pathTxt, VVSBcQ) + "\n"
   if slBroken : fileTime = self.VV7pCa(path)
   else  : fileTime = self.VVed5K(path)
   def VVrCdg(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVrCdg("Path"    , pathTxt)
   txt += VVrCdg("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVrCdg("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVrCdg("Total Size"   , "%s" % totSize)
    txt += VVrCdg("Used Size"   , "%s" % usedSize)
    txt += VVrCdg("Free Size"   , "%s" % freeSize)
   else:
    txt += VVrCdg("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVrCdg("Owner"    , owner)
   txt += VVrCdg("Group"    , group)
   txt += VVrCdg("Perm. (User)"  , permUser)
   txt += VVrCdg("Perm. (Group)"  , permGroup)
   txt += VVrCdg("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVrCdg("Perm. (Ext.)" , permExtra)
   txt += VVrCdg("iNode"    , iNode)
   txt += VVrCdg("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVOJFH(path)
  else:
   FFrj68(self, "Cannot access information !")
  if len(txt) > 0:
   FFaIgn(self, txt)
 def VVwe0z(self, path):
  path = path.strip()
  path = FFz551(path)
  result = FFdVkh("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVnC8i(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVnC8i(perm, 1, 4)
   permGroup = VVnC8i(perm, 4, 7)
   permOther = VVnC8i(perm, 7, 10)
   permExtra = VVnC8i(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFv0e0("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVOJFH(self, path):
  txt  = ""
  res  = FFdVkh("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF7kJS("File Attributes:", VVrexq), txt)
  return txt
 def VVed5K(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFDwGN(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFDwGN(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFDwGN(os.path.getctime(path))
  return txt
 def VV7pCa(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFdVkh("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFdVkh("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFdVkh("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVGGU0(self, currentSel):
  currentDir  = self["myMenu"].VVKt0x()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVowQb():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VV476K(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVX0zU(self):
  path = self.VVGGU0(self.VV476K())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVEDzy()
  if self.mode == self.VV9LS7:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVbeik:
   path = self.VVGGU0(self.VV476K())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVaWsP(self):
  color1 = VV4d6Z
  color2 = VVSFOM
  color3 = VVLAFW
  totSel = 0
  menuW = 1000
  title = "Options"
  VV8kKb= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVXaZS()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FF7O1V(totSel))
     VV8kKb.append((color1 + txt1     , "VVmLLq1" ))
     VV8kKb.append((color1 + txt1 + txt2   , "VVmLLq2" ))
     VV8kKb.append(VVnK97)
    VV8kKb.append(("[6] Copy"       , "copyBulk" ))
    VV8kKb.append(("[7] Move"       , "moveBulk" ))
    VV8kKb.append(("[8] %sDELETE" % VVSBcQ , "VVZtft" ))
   else:
    FFAM12(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVocwE, self.VVbeik):
   VV8kKb.append(("Properties"           , "properties" ))
   VV8kKb.append(VVnK97)
   VV8kKb.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVGGU0(self.VV476K())
   isEditable = self["myMenu"].VVOqd6()
   VV8kKb.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VV8kKb.append(VVnK97)
     VV8kKb.append((color1 + "Archiving / Packaging", "VVYnAC_dir"))
   elif os.path.isfile(path):
    selFile = self.VV476K()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VV8kKb.append((color1 + "Archive ...", "VVYnAC_file"))
    isText = False
    txt = ""
    if   isArch            : VV8kKb.extend(self.VVssd8(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VV8kKb.extend(self.VVdS39(True))
    elif selFile.endswith(".sh"):
     VV8kKb.extend(self.VVyJIv(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCFric.VVaB8q(path):
     VV8kKb.append(VVnK97)
     VV8kKb.append((color2 + "View"     , "textView_def"))
     VV8kKb.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VV8kKb.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVPfmF(path) == "pic":
     VV8kKb.append(VVnK97)
     VV8kKb.append((color2 + "Set as PIcon for current channel" , "VVJw9K" ))
     if FFFS65("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VV8kKb.append(VVnK97)
      VV8kKb.append((color2 + "Convert to MVI (1280 x 720 )" , "VVUKS8Hd"   ))
      VV8kKb.append((color2 + "Convert to MVI (1920 x 1080)" , "VVUKS8Fhd"   ))
    elif selFile.endswith(CCFric.VVbILY()):
     if selFile.endswith(".mvi"):
      if FFFS65("showiframe"):
       VV8kKb.append(VVnK97)
       VV8kKb.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VV8kKb.append(VVnK97)
      VV8kKb.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VV8kKb.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VV8kKb.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VV8kKb.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VV8kKb.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VV8kKb.append((color1 + "Convert Line-Breaks to Unix Format..." , "VV5MOg" ))
    if len(txt) > 0:
     VV8kKb.append(VVnK97)
     VV8kKb.append((color1 + txt, "VVpv5f"))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("[4] Create SymLink", "VVE2t6"))
   if isEditable:
    VV8kKb.append(("[5] Rename"      , "VVy0Mv" ))
    VV8kKb.append(("[6] Copy"       , "copyFileOrDir" ))
    VV8kKb.append(("[7] Move"       , "moveFileOrDir" ))
    VV8kKb.append(("[8] %sDELETE" % VVSBcQ , "VVB6P3" ))
    if fileExists(path):
     VV8kKb.append(VVnK97)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VV8kKb.append((chmodTxt + "644)", "chmod644"))
     if show755 : VV8kKb.append((chmodTxt + "755)", "chmod755"))
     if show777 : VV8kKb.append((chmodTxt + "777)", "chmod777"))
   VV8kKb.append(VVnK97)
   VV8kKb.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VV8kKb.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCFric.VVEl1L(self)
   if fPath:
    VV8kKb.append(VVnK97)
    VV8kKb.append((color2 + "Go to Current Movie Dir", "VVWYSe"))
  FFHAbB(self, self.VVrLFx, width=menuW, height=1050, title=title, VV8kKb=VV8kKb, VVom0S=False, VVuGSD="#00101020", VVO7CL="#00101A2A")
 def VVrLFx(self, item=None):
  if item is not None:
   path = self.VVGGU0(self.VV476K())
   selFile = self.VV476K()
   if   item == "VVmLLq1"    : self.VVmLLq(False)
   if   item == "VVmLLq2"    : self.VVmLLq(True)
   elif item == "copyBulk"     : self.VVvHsV(False)
   elif item == "moveBulk"     : self.VVvHsV(True)
   elif item == "VVZtft"    : self.VVZtft()
   elif item == "properties"    : self.VVFC6S()
   elif item == "VVYnAC_dir" : self.VVYnAC(path, True)
   elif item == "VVYnAC_file" : self.VVYnAC(path, False)
   elif item == "VVACF7"  : self.VVACF7(path)
   elif item == "VVkVnn"  : self.VVkVnn(path)
   elif item.startswith("extract_")  : self.VVdOee(path, selFile, item)
   elif item.startswith("script_")   : self.VVMfM1(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVefjA(path, selFile, item)
   elif item.startswith("textView_def") : FFRB7k(self, path)
   elif item.startswith("textView_enc") : self.VVBXrK(path)
   elif item.startswith("text_Edit")  : FF0GsP(self, BF(CCAoYu, self, path, VVVnlJ=self.VVuMap), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VV3KY8(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VV3KY8(path, "Save as Other Encoding", False)
   elif item.startswith("VV5MOg") : self.VV5MOg(path)
   elif item == "viewAsBootlogo"   : self.VVaHJK(path, True)
   elif item == "addMovieToBouquet"  : self.VV9MqU(path, False)
   elif item == "addAllMoviesToBouquet" : self.VV9MqU(path, True)
   elif item == "playWith"     : self.VVLiqf(path)
   elif item == "VVJw9K" : self.VVJw9K(path)
   elif item == "VVUKS8Hd"   : FF0GsP(self, BF(self.VVUKS8, path, False))
   elif item == "VVUKS8Fhd"   : FF0GsP(self, BF(self.VVUKS8, path, True))
   elif item == "VVE2t6"   : self.VVE2t6(path, selFile)
   elif item == "VVy0Mv"   : self.VVy0Mv(path, selFile)
   elif item == "copyFileOrDir"   : self.VV3ueL(path, False)
   elif item == "moveFileOrDir"   : self.VV3ueL(path, True)
   elif item == "VVB6P3"   : self.VVB6P3(path, selFile)
   elif item == "chmod644"     : self.VVU3zg(path, selFile, "644")
   elif item == "chmod755"     : self.VVU3zg(path, selFile, "755")
   elif item == "chmod777"     : self.VVU3zg(path, selFile, "777")
   elif item == "createNewFile"   : self.VVRBJ3(path, True)
   elif item == "createNewDir"    : self.VVRBJ3(path, False)
   elif item == "VVWYSe"   : self.VVWYSe()
   elif item == "VVpv5f"    : self.VVpv5f()
 def VVpv5f(self):
  if self.mode == self.VVbeik and not self.patternMode == "poster":
   return
  selFile = self.VV476K()
  path  = self.VVGGU0(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVPfmF(path)
   if   cat == "pic"       : self.VVERUU(path)
   elif cat == "txt"       : FFRB7k(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVoZK5(path, selFile)
   elif cat == "scr"       : self.VVYaaK(path, selFile)
   elif cat == "m3u"       : self.VVv0o7(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVoZgL(path, selFile)
   elif cat in ("mov", "mus")     : self.VVaHJK(path)
   elif not CCFric.VVaB8q(path) : FFRB7k(self, path)
 def VVERUU(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVPfmF(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCJCdT.VVHj4i(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVraSd)
 def VVraSd(self, path):
  self.VVpGHQ(path)
 def VVaHJK(self, path, asLogo=False):
  if asLogo : CCFWUe.VV5PQ2(self, path)
  else  : FF0GsP(self, BF(self.VVDGqS, self, path), title="Playing Media ...")
 def VVsnYR(self):
  if self["keyBlue"].getVisible():
   VVI2kC = self.VVKkWI()
   if VVI2kC:
    path = self.VVGGU0(self.VV476K())
    enableGreenBtn = False if path in self.VVKkWI() else True
    newList = []
    for line in VVI2kC:
     newList.append((line, line))
    VV1zfK  = ("Delete"    , self.VVjzsh    )
    VV0MQu  = ("Add Current Dir"   , BF(self.VVDCPB, path) ) if enableGreenBtn else None
    VVinPK = ("Move Up"     , self.VVmmVU    )
    VVcx0D  = ("Move Down"   , self.VVIeTe    )
    self.bookmarkMenu = FFHAbB(self, self.VVKIeV, width=1200, title="Bookmarks", VV8kKb=newList, minRows=10 ,VV1zfK=VV1zfK, VV0MQu=VV0MQu, VVinPK=VVinPK, VVcx0D=VVcx0D, VVuGSD="#00000022", VVO7CL="#00000022")
 def VVjzsh(self, VVNmGv=None, path=None):
  VVI2kC = self.VVKkWI()
  if VVI2kC:
   while path in VVI2kC:
    VVI2kC.remove(path)
   self.VVxofe(VVI2kC)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV2YYg(VVI2kC)
   self.bookmarkMenu.VVmkQH(("Add Current Dir", BF(self.VVDCPB, path)))
  else:
   FFAM12(self, "Removed", 800)
  self.VVEDzy()
 def VVDCPB(self, path, VVNmGv=None, item=None):
  VVI2kC = self.VVKkWI()
  if len(VVI2kC) >= self.VVXxla:
   FFrj68(SELF, "Max bookmarks reached (max=%d)." % self.VVXxla)
  elif not path in VVI2kC:
   if not os.path.isdir(path):
    path = FFoVse(path, True)
   newList = [path] + VVI2kC
   self.VVxofe(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV2YYg(newList)
    self.bookmarkMenu.VVmkQH()
   else:
    FFAM12(self, "Added", 800)
  self.VVEDzy()
 def VVmmVU(self, VV476KObj, path):
  if self.bookmarkMenu:
   VVI2kC = self.bookmarkMenu.VVIh0l(True)
   if VVI2kC:
    self.VVxofe(VVI2kC)
 def VVIeTe(self, VV476KObj, path):
  if self.bookmarkMenu:
   VVI2kC = self.bookmarkMenu.VVIh0l(False)
   if VVI2kC:
    self.VVxofe(VVI2kC)
 def VVKIeV(self, folder=None):
  if folder:
   folder = FFxiJi(folder)
   self["myMenu"].VVfLjF(folder)
   self["myMenu"].moveToIndex(0)
  self.VVX0zU()
 def VVKkWI(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVoo4c(self):
  return True if VVKkWI() else False
 def VVxofe(self, VVI2kC):
  line = ",".join(VVI2kC)
  FFaoHf(CFG.browserBookmarks, line)
 def VVpGHQ(self, path):
  if fileExists(path):
   fDir  = FFxiJi(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVfLjF(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFAM12(self, "Not found", 1000)
 def VVWYSe(self, chDir=True):
  fPath, fDir, fName = CCFric.VVEl1L(self)
  self.VVpGHQ(fPath)
 def VVPwTs(self):
  path = self.VVGGU0(self.VV476K())
  isAdd = False if path in self.VVKkWI() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVZkFQ, VV30Pd, VVSFOM
  VV8kKb = []
  VV8kKb.append(("Find Files ..." , "find"))
  VV8kKb.append(("Sort ..."   , "sort"))
  VV8kKb.append(VVnK97)
  if isAdd: VV8kKb.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VV8kKb.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VV9LS7:
   VV8kKb.append(VVnK97)
   if self.multiSelectState: VV8kKb.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VV8kKb.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VV8kKb.append(       (c3 + "Select all"    , "selAll"  ))
  FFHAbB(self, BF(self.VVoAbK, path), width=750, title="More Options", VV8kKb=VV8kKb, VVuGSD="#00221111", VVO7CL="#00221111")
 def VVoAbK(self, path, item):
  if item:
   if   item == "find"  : self.VVUkU7(path)
   elif item == "sort"  : self.VVfn0S()
   elif item == "addBM" : self.VVDCPB(path)
   elif item == "remBM" : self.VVjzsh(None, path)
   elif item == "start" : self.VVdNYh(path)
   elif item == "multiOn" : self.VVjbD3(True)
   elif item == "multiOff" : self.VVjbD3(False)
   elif item == "selAll" : self.VVjbD3(True, True)
 def VVjbD3(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FF0GsP(self, BF(self["myMenu"].VV5u6F, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVUp4U(self.VVWJho if isOn else self.VVhK3C)
 def VVUp4U(self, mode=0):
  if   mode == self.VVR5ma : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVWJho: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVuGSD, self.VVO7CL
  FFIY0q(self["myTitle"], titBg)
  FFIY0q(self["myBar"], titBg)
  FFIY0q(self["myBody"], bodBg)
  FFIY0q(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVh2v6()
  else     : bg, txt = VVlQE0[3], "Bookmarks"
  FFFQrh(self["keyBlue"], txt)
  FFIY0q(self["keyBlue"], bg)
  self.VVEDzy()
 def VVh2v6(self):
  return "Selected Items = %d" % self["myMenu"].VVXaZS()
 def VVEDzy(self):
  if self.VVKkWI() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVUkU7(self, path):
  VV8kKb = []
  VV8kKb.append(("Find in Current Directory"    , "findCur"  ))
  VV8kKb.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VV8kKb.append(("Find in all Storage Systems"    , "findAll"  ))
  FFHAbB(self, BF(self.VVPb7n, path), width=700, title="Find File/Pattern", VV8kKb=VV8kKb, VVPYdF=True, VVWQ3x=True, VVuGSD="#00221111", VVO7CL="#00221111")
 def VVPb7n(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVbeXL(0, path, title)
   elif item == "findCurR" : self.VVbeXL(1, path, title)
   elif item == "findAll" : self.VVbeXL(2, path, title)
 def VVbeXL(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFTtos(self, BF(self.VVXnyZ, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVXnyZ(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFaoHf(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFAM12(self, "No entery", 1500)
   elif badLst  : FFAM12(self, "Too many file !", 1500)
   else   : FF0GsP(self, BF(self.VVu3fV, mode, path, title, filePatt), title="Searching ...")
 def VVu3fV(self, mode, path, title, filePatt):
  lst = FFO8C9(FFREuT("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCFric.VVvwlA(lst)
   if err:
    FFrj68(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVk5TH = (""     , self.VVnWlA , [])
    VVaq9G = ("Go to File Location", self.VVpmFE  , [])
    FFyZJ5(self, None, title="%s : %s" % (title, filePatt), header=header, VVI2kC=lst, VVWFHs=widths, VVC5IT=26, VVk5TH=VVk5TH, VVaq9G=VVaq9G)
  else:
   FFIZWt(self, "Not found !", 2000)
 def VVpmFE(self, VVt27A, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVt27A.cancel()
   self.VVpGHQ(path)
  else:
   FFAM12(VVt27A, "Path not found !", 1000)
 def VVnWlA(self, VVt27A, title, txt, colList):
  txt = "%s\n%s\n\n" % (FF7kJS("File:"  , VVSFOM), colList[0])
  txt += "%s\n%s"  % (FF7kJS("Directory:", VVSFOM), FFxiJi(colList[1]))
  FFaIgn(VVt27A, txt, title=title)
 def VVfn0S(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV0ign()
  VV8kKb = []
  VV8kKb.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VV8kKb.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VV8kKb.append(("Date\t%s" % dateTxt, "dateAlp"))
  VV8kKb.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVcx0D = ("Mix", BF(self.VVbsTL, True))
  FFHAbB(self, BF(self.VVM4Kg, False), barText=txt, width=650, title="Sort Options", VV8kKb=VV8kKb, VVcx0D=VVcx0D, VVWQ3x=True, VVuGSD="#00221111", VVO7CL="#00221111")
 def VVbsTL(self, isMix, VVNmGv, item):
  self.VVM4Kg(True, item)
 def VVM4Kg(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV0ign()
   title = "Sorting ... "
   if   item == "nameAlp": FF0GsP(self, BF(self["myMenu"].VVdwE4, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FF0GsP(self, BF(self["myMenu"].VVdwE4, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FF0GsP(self, BF(self["myMenu"].VVdwE4, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FF0GsP(self, BF(self["myMenu"].VVdwE4, typeMode , isMix, False), title=title)
 def VVdNYh(self, path):
  if not os.path.isdir(path):
   path = FFoVse(path, True)
  FFaoHf(CFG.browserStartPath, path)
  FFAM12(self, "Done", 500)
 def VVJmhv(self, selFile, VVzpP3, command):
  FFo32K(self, BF(FFSEeb, self, command, consFont=True, VVOc3A=self.VVnChI), "%s\n\n%s" % (VVzpP3, selFile))
 def VVssd8(self, path, calledFromMenu):
  destPath = self.VVbJSV(path)
  lastPart = FFM4mE(destPath)
  color = VVSFOM if calledFromMenu else ""
  VV8kKb = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VV8kKb.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VV8kKb.append(VVnK97)
   VV8kKb.append((color + "List Archived Files"          , "extract_listFiles" ))
   VV8kKb.append(VVnK97)
   VV8kKb.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VV8kKb.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VV8kKb.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VV8kKb.append(VVnK97)
     VV8kKb.append((color + "Convert .zip to .tar.gz"       , "VVACF7" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VV8kKb.append(VVnK97)
     VV8kKb.append((color + "Convert .tar.gz to .zip"       , "VVkVnn" ))
  return VV8kKb
 def VVoZK5(self, path, selFile):
  FFHAbB(self, BF(self.VVdOee, path, selFile), title="Compressed File Options", VV8kKb=self.VVssd8(path, False))
 def VVdOee(self, path, selFile, item=None):
  if item is not None:
   parent  = FFoVse(path, False)
   destPath = self.VVbJSV(path)
   lastPart = FFM4mE(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFLwTR("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFLwTR("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFTJt5(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVACF7" : self.VVACF7(path)
    else       : self.VVfIFa(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVkVnn" and path.endswith(".tar.gz"):
    self.VVkVnn(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFdVkh("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FF9glI(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVnChI()
    else:
     FFrj68(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVc74Q(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFhyjZ("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVJmhv(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVJmhv(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFoVse(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVJmhv(selFile, "Extract Here ?"      , cmd)
 def VVbJSV(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVfIFa(self, item, path, parent, destPath, VVzpP3):
  FFo32K(self, BF(self.VV6Iv1, item, path, parent, destPath), VVzpP3)
 def VV6Iv1(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFLwTR("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFQQct(destPath, VVomgc))
  cmd +=   sep
  cmd += "fi;"
  FF07Rj(self, cmd, VVOc3A=self.VVnChI)
 def VVc74Q(self, item, path, parent, destPath, VVzpP3):
  FFo32K(self, BF(self.VVetrb, item, path, parent, destPath), VVzpP3)
 def VVetrb(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFxiJi(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFLwTR("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFQQct(destPath, VVomgc))
  cmd +=   sep
  cmd += "fi;"
  FF07Rj(self, cmd, VVOc3A=self.VVnChI)
 def VVyJIv(self, addSep=False):
  VV8kKb = []
  if addSep:
   VV8kKb.append(VVnK97)
  VV8kKb.append((VVSFOM + "View Script File"  , "script_View"  ))
  VV8kKb.append((VVSFOM + "Execute Script File" , "script_Execute" ))
  VV8kKb.append((VVSFOM + "Edit"     , "script_Edit"  ))
  return VV8kKb
 def VVYaaK(self, path, selFile):
  FFHAbB(self, BF(self.VVMfM1, path, selFile), title="Script File Options", VV8kKb=self.VVyJIv())
 def VVMfM1(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFRB7k(self, path)
   elif item == "script_Execute" : self.VVJmhv(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCAoYu(self, path, VVVnlJ=self.VVuMap)
 def VVdS39(self, addSep=False):
  VV8kKb = []
  if addSep:
   VV8kKb.append(VVnK97)
  VV8kKb.append((VVSFOM + "Browse IPTV Channels" , "m3u_Browse" ))
  VV8kKb.append((VVSFOM + "Edit"     , "m3u_Edit" ))
  VV8kKb.append((VVSFOM + "View"     , "m3u_View" ))
  return VV8kKb
 def VVv0o7(self, path, selFile):
  FFHAbB(self, BF(self.VVefjA, path, selFile), title="M3U/M3U8 File Options", VV8kKb=self.VVdS39())
 def VVefjA(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF0GsP(self, BF(self.session.open, CC1B0Q, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCAoYu(self, path, VVVnlJ=self.VVuMap)
   elif item == "m3u_View"  : FFRB7k(self, path)
 def VVBXrK(self, path):
  if fileExists(path) : FF0GsP(self, BF(CCP2t1.VVDX2J, self, path, BF(self.VVcTkF, path)), title="Loading Codecs ...")
  else    : FFiEaB(self, path)
 def VVcTkF(self, path, item=None):
  if item:
   FFRB7k(self, path, encLst=item)
 def VV3KY8(self, path, title, asUtf8):
  if fileExists(path) : FF0GsP(self, BF(CCP2t1.VVDX2J, self, path, BF(self.VVVcDa, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFiEaB(self, path)
 def VVVcDa(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVRnuf(path, title, fromEnc, "UTF-8")
   else  : CCP2t1.VVZ9IC(self, BF(self.VVRnuf, path, title, fromEnc), title="Convert to Encoding")
 def VVRnuf(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FF7kJS("Successful\n\n", VVomgc)
      txt += FF7kJS("From Encoding (%s):\n" % fromEnc, VV691Y)
      txt += "%s\n\n" % path
      txt += FF7kJS("To Encoding (%s):\n" % toEnc, VV691Y)
      txt += "%s\n\n" % outFile
      FFaIgn(self, txt, title=title)
    except:
     FFrj68(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFAM12(self, "Cannot open file", 2000)
   self.VVnChI()
 def VV5MOg(self, path):
  title = "File Line-Break Conversion"
  FFo32K(self, BF(self.VVQvss, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVQvss(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FF7kJS("File converted:", VVomgc), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF9glI(self, txt, title=title)
  else:
   FFiEaB(self, path, title=title)
 def VVU3zg(self, path, selFile, newChmod):
  FFo32K(self, BF(self.VVhn2q, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVhn2q(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVfKPQ)
  result = FFdVkh(cmd)
  if result == "Successful" : FF9glI(self, result)
  else      : FFrj68(self, result)
 def VVE2t6(self, path, selFile):
  parent = FFoVse(path, False)
  self.session.openWithCallback(self.VVxTou, BF(CCFric, mode=CCFric.VVocwE, VVZmiW=parent, VV9ghp="Create Symlink here"))
 def VVxTou(self, newPath):
  if len(newPath) > 0:
   target = self.VVGGU0(self.VV476K())
   target = FFz551(target)
   linkName = FFM4mE(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFxiJi(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFrj68(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFo32K(self, BF(self.VVcxUL, target, link), "Create Soft Link ?\n\n%s" % txt, VVjDSl=True)
 def VVcxUL(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVfKPQ)
  result = FFdVkh(cmd)
  if result == "Successful" : FF9glI(self, result)
  else      : FFrj68(self, result)
 def VVy0Mv(self, path, selFile):
  lastPart = FFM4mE(path)
  FFTtos(self, BF(self.VVgrD7, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVgrD7(self, path, selFile, VVPnAy):
  if VVPnAy:
   parent = FFoVse(path, True)
   if os.path.isdir(path):
    path = FFz551(path)
   newName = parent + VVPnAy
   cmd = "mv '%s' '%s' %s" % (path, newName, VVfKPQ)
   if VVPnAy:
    if selFile != VVPnAy:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFo32K(self, BF(self.VVPsjA, cmd), message, title="Rename file?")
    else:
     FFrj68(self, "Cannot use same name!", title="Rename")
 def VVPsjA(self, cmd):
  result = FFdVkh(cmd)
  if "Fail" in result:
   FFrj68(self, result)
  self.VVnChI()
 def VVmLLq(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVqQZx, title, preserve)
      , VVVnlJ = BF(self.VVdB4p, title))
 def VVqQZx(self, title, preserve, VVtEPC):
  totSel = self["myMenu"].VVXaZS()
  totOk = totFail = 0
  VVtEPC.VVodiL(totSel)
  VVtEPC.VVsc2i = ["", totSel, totOk, totFail, ""]
  VVtEPC.VVLHBp("Prepareing targz file")
  curDir = self["myMenu"].VVKt0x()
  lastPart = FFM4mE(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVtEPC or VVtEPC.isCancelled:
      return
     if row[2][6]:
      VVtEPC.VV2Wgw(1)
      name  = FFz551(row[0][0])
      lastPath = FFM4mE(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVtEPC:
       VVtEPC.VVsc2i = [outF, totSel, totOk, totFail, path]
       VVtEPC.VVWnCg(totOk, lastPath)
  except:
   totFail += 1
   if VVtEPC:
    VVtEPC.VVsc2i = [outF, totSel, totOk, totFail, path]
 def VVdB4p(self, title, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVsc2i
  txt  = "%s:\n%s\n\n"   % (FF7kJS("Output File", VVomgc), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FF7kJS("Failed\t: %d\n" % totFail, VVSBcQ)
  if not VVYFmk: txt += "%s\n%s" % (FF7kJS("\nCancelled while copying:", VVSBcQ), path)
  FFaIgn(self, txt, title=title)
  self.VVnChI()
 def VVvHsV(self, isMove):
  self.session.openWithCallback(BF(self.VV4OHO, isMove), BF(CCFric, mode=CCFric.VVocwE, VVZmiW=self["myMenu"].VVKt0x(), VV9ghp="Move to here" if isMove else "Paste here"))
 def VV4OHO(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVHvZK, title, action, isMove, newPath)
       , VVVnlJ = BF(self.VVHiPz, title, action, isMove, newPath))
 def VVHvZK(self, title, action, isMove, newPath, VVtEPC):
  curDir = self["myMenu"].VVKt0x()
  totOk = totFail = 0
  totSel = self["myMenu"].VVXaZS()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVtEPC.VVodiL(totSel)
  VVtEPC.VVsc2i = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVtEPC or VVtEPC.isCancelled:
    return
   if row[2][6]:
    VVtEPC.VV2Wgw(1)
    VVtEPC.VVZDPe(action, totOk, FFM4mE(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFM4mE(path)
    if os.path.isdir(path): path = FFz551(path)
    dest = os.path.join(newPath, lastPart)
    if FFWnHJ("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVtEPC:
     VVtEPC.VVsc2i = [totSel, totOk, totFail, path]
     VVtEPC.VVZDPe(action, totOk, FFM4mE(row[0][0]))
 def VVHiPz(self, title, action, isMove, newPath, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVsc2i
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FF7kJS("Failed\t: %d\n" % totFail, VVSBcQ)
  if not VVYFmk: txt += "%s\n%s" % (FF7kJS("\nCancelled while copying:", VVSBcQ), path)
  FFaIgn(self, txt, title=title)
  self.VVnChI()
 def VVZtft(self):
  tot = self["myMenu"].VVXaZS()
  FFo32K(self, BF(FF0GsP, self, self.VVjptr, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FF7O1V(tot)), title="Delete Selection")
 def VVjptr(self):
  path = self["myMenu"].VVKt0x()
  for row in self["myMenu"].list:
   if row[2][6]:
    FF37bK(os.path.join(path, row[0][0]))
  FFAM12(self)
  self.VVnChI()
 def VV3ueL(self, path, isMove):
  self.session.openWithCallback(BF(self.VV2r3b, isMove, path), BF(CCFric, mode=CCFric.VVocwE, VVZmiW=FFoVse(path, False), VV9ghp="Move to here" if isMove else "Paste here"))
 def VV2r3b(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFz551(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFz551(src)
  dst = os.path.join(dst, FFM4mE(src))
  if src == dst:
   FFrj68(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFo32K(self, BF(self.VVwzh4, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFo32K(self, BF(self.VVwzh4, prams), "Overwrite Destination Files", title=title)
  else         : self.VVwzh4(prams)
 def VVwzh4(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCFric.VV37eX(src) == CCFric.VV37eX(dst):
   FF0GsP(self, BF(self.VVYrd8, prams), title="Moving %s ..." % srcSubj)
  else:
   FF0GsP(self, BF(self.VVOlpC, prams), title="Calculating Size ...")
 def VVYrd8(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFdVkh("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVnChI()
  else:
   FFrj68(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVOlpC(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FF7PcS(src)
  else  : size = FFCcy5(src)
  if size > -1:
   self.session.open(CCfhQr, barTheme=CCfhQr.VVFWIs, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVcpcZ, prams, size)
       , VVVnlJ = BF(self.VVvU7L, prams))
  else:
   FFrj68(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVcpcZ(self, prams, size, VVtEPC):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVtEPC.VVodiL(size)
  VVtEPC.VVsc2i = ("", "", False)
  def VVNZrq(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFfIuR(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVtEPC or VVtEPC.isCancelled:
        VVtEPC.VVsc2i = (srcFile, "", True)
        FFfIuR(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVtEPC.VV2Wgw(len(data))
       except Exception as e:
        VVtEPC.VVsc2i = (srcFile, str(e), False)
        FFfIuR(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFfIuR(srcFile)
   return True
  if isFile:
   tot = 1
   VVNZrq(src, dst)
  else:
   VVtEPC.VVLHBp("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFFrYw(src)
   if not VVtEPC or VVtEPC.isCancelled:
    VVtEPC.VVsc2i = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVtEPC.VVsc2i = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVtEPC.VVLHBp("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVNZrq(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFWnHJ("rm -fr '%s'" % Dir)
   if isMove:
    FFWnHJ("rm -fr '%s'" % src)
 def VVvU7L(self, prams, VVYFmk, VVsc2i, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVsc2i
  if err:
   FFrj68(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFAM12(self, "Canelled", 1000)
   else  : FFrj68(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFAM12(self, "Done", 1500, isGrn=True)
  if VVYFmk and isMove:
   self.VVnChI()
 def VVB6P3(self, path, fileName):
  path = FFz551(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFo32K(self, BF(FF0GsP, self, BF(self.VVpP6T, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVpP6T(self, path):
  FF37bK(path)
  FFAM12(self)
  self.VVnChI()
 def VVRBJ3(self, path, isFile):
  dirName = FFxiJi(os.path.dirname(path))
  if isFile : objName, VVPnAy = "File"  , self.edited_newFile
  else  : objName, VVPnAy = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFTtos(self, BF(self.VVsHhP, dirName, isFile, title), title=title, defaultText=VVPnAy, message="Enter %s Name:" % objName)
 def VVsHhP(self, dirName, isFile, title, VVPnAy):
  if VVPnAy:
   if isFile : self.edited_newFile = VVPnAy
   else  : self.edited_newDir  = VVPnAy
   path = dirName + VVPnAy
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVfKPQ)
    else  : cmd = "mkdir '%s' %s" % (path, VVfKPQ)
    result = FFdVkh(cmd)
    if "Fail" in result:
     FFrj68(self, result)
    self.VVnChI()
   else:
    FFrj68(self, "Name already exists !\n\n%s" % path, title)
 def VVoZgL(self, path, selFile):
  c1, c2, c3 = VV30Pd, VVSFOM, VV4d6Z
  VV8kKb = []
  VV8kKb.append((c1 + "List Package Files"         , "VVFM76"     ))
  VV8kKb.append((c1 + "Package Information"         , "VVfO4d"     ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Install Package"          , "VVdEtO_CheckVersion" ))
  VV8kKb.append((c2 + "Install Package (force reinstall)"     , "VVdEtO_ForceReinstall" ))
  VV8kKb.append((c2 + "Install Package (force overwrite)"     , "VVdEtO_ForceOverwrite" ))
  VV8kKb.append((c2 + "Install Package (force downgrade)"     , "VVdEtO_ForceDowngrade" ))
  VV8kKb.append((c2 + "Install Package (ignore failed dependencies)"  , "VVdEtO_IgnoreDepends" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c3 + "Remove Related Package"        , "VVrPDu_ExistingPackage" ))
  VV8kKb.append((c3 + "Remove Related Package (force remove)"    , "VVrPDu_ForceRemove"  ))
  VV8kKb.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVrPDu_IgnoreDepends" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Extract Files"           , "VVZ7mI"     ))
  VV8kKb.append(("Unbuild Package"           , "VVmcX4"     ))
  FFHAbB(self, BF(self.VVXI48, path, selFile), VV8kKb=VV8kKb)
 def VVXI48(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVFM76"      : self.VVFM76(path, selFile)
   elif item == "VVfO4d"      : self.VVfO4d(path)
   elif item == "VVdEtO_CheckVersion"  : self.VVdEtO(path, selFile, VVcIUq     )
   elif item == "VVdEtO_ForceReinstall" : self.VVdEtO(path, selFile, VVpHks )
   elif item == "VVdEtO_ForceOverwrite" : self.VVdEtO(path, selFile, VV7Fa0 )
   elif item == "VVdEtO_ForceDowngrade" : self.VVdEtO(path, selFile, VV3fQ1 )
   elif item == "VVdEtO_IgnoreDepends" : self.VVdEtO(path, selFile, VVyCx7 )
   elif item == "VVrPDu_ExistingPackage" : self.VVrPDu(path, selFile, VV45S3     )
   elif item == "VVrPDu_ForceRemove"  : self.VVrPDu(path, selFile, VVe6LU  )
   elif item == "VVrPDu_IgnoreDepends"  : self.VVrPDu(path, selFile, VVA0No )
   elif item == "VVZ7mI"     : self.VVZ7mI(path, selFile)
   elif item == "VVmcX4"     : self.VVmcX4(path, selFile)
   else           : self.close()
 def VVFM76(self, path, selFile):
  if FFFS65("ar") : cmd = "allOK='1';"
  else    : cmd  = FFEDUQ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFYk4h(self, cmd, VVOc3A=self.VVnChI)
 def VVZ7mI(self, path, selFile):
  lastPart = FFM4mE(path)
  dest  = FFoVse(path, True) + selFile[:-4]
  cmd  =  FFEDUQ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFhyjZ("mkdir '%s'" % dest)
  cmd +=    FFhyjZ("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFQQct(dest, VVomgc))
  cmd += "fi;"
  FFSEeb(self, cmd, VVOc3A=self.VVnChI)
 def VVmcX4(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVtBn6 = os.path.splitext(path)[0]
  else        : VVtBn6 = path + "_"
  if path.endswith(".deb")   : VVr2P9 = "DEBIAN"
  else        : VVr2P9 = "CONTROL"
  cmd  = FFEDUQ()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVtBn6
  cmd += "  mkdir '%s';"      % VVtBn6
  cmd += "  CONTPATH='%s/%s';"    % (VVtBn6, VVr2P9)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVtBn6
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVtBn6, VVtBn6)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVtBn6
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVtBn6, VVtBn6)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVtBn6
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVtBn6
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVtBn6, FFQQct(VVtBn6, VVomgc))
  cmd += "fi;"
  FFSEeb(self, cmd, VVOc3A=self.VVnChI)
 def VVfO4d(self, path):
  listCmd  = FFYQcS(VV4Vav, "")
  infoCmd  = FFMlY4(VVfpYt , "")
  filesCmd = FFMlY4(VVHjnx, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF0dSC(VV691Y)
   notInst = "Package not installed."
   cmd  = FFDeRs("File Info", VV691Y)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFDeRs("System Info", VV691Y)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFQQct(notInst, VVSBcQ))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFDeRs("Related Files", VV691Y)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFTJt5(self, cmd)
  else:
   FFUrcP(self)
 def VVdEtO(self, path, selFile, cmdOpt):
  cmd = FFMlY4(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFo32K(self, BF(FFSEeb, self, cmd, VVOc3A=FFzWhD), "Install Package ?\n\n%s" % selFile)
  else:
   FFUrcP(self)
 def VVrPDu(self, path, selFile, cmdOpt):
  listCmd  = FFYQcS(VV4Vav, "")
  infoCmd  = FFMlY4(VVfpYt, "")
  instRemCmd = FFMlY4(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFQQct(errTxt, VVSBcQ))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFQQct(cannotTxt, VVSBcQ))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFQQct(tryTxt, VVSBcQ))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFo32K(self, BF(FFSEeb, self, cmd, VVOc3A=FFzWhD), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFUrcP(self)
 def VV1oXc(self, path):
  hostName = FFdVkh("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVYnAC(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VV8kKb = []
  VV8kKb.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VV8kKb.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VV8kKb.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VV8kKb.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VV8kKb.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VV8kKb.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VV8kKb.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VV8kKb.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VV8kKb.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VV8kKb.append(VVnK97)
   VV8kKb.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VV8kKb.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFHAbB(self, BF(self.VV5K7h, path, isDir, title), VV8kKb=VV8kKb, title=title, VVuGSD=c1, VVO7CL=c2)
 def VV5K7h(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVaCcT(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVaCcT(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVaCcT(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVaCcT(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVaCcT(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVaCcT(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVaCcT(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVaCcT(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVaCcT(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVaCcT(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVJUDA(path, False)
   elif item == "convertDirToDeb" : self.VVJUDA(path, True)
 def VVJUDA(self, path, VVpmZd):
  self.session.openWithCallback(self.VVnChI, BF(CCrfCS, path=path, VVpmZd=VVpmZd))
 def VVaCcT(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFoVse(path, True)
  lastPart = FFM4mE(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFLwTR("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFLwTR("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFLwTR("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFhyjZ("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFQQct(failed, VVvkGK))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFQQct(srcTxt, VVZkFQ))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFQQct("Output", VVomgc))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFQQct(failed, VVD6mq))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFYk4h(self, cmd, VVOc3A=self.VVnChI, title=title)
 def VV9MqU(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCFric.VVCvuJ(FFoVse(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCQo5X(self, self, title, BF(self.VVfSQo, pathLst))
 def VVfSQo(self, pathLst):
  return CCQo5X.VVDnzV(pathLst)
 def VVACF7(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VV73zj, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFo32K(self, BF(FF0GsP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF0GsP(self, fnc, title=txt)
  else:
   FFrj68(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VV73zj(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFaIgn(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVnChI()
  else:
   FFfIuR(tarPath)
   FFrj68(self, "Error while converting.", title=title)
 def VVkVnn(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVFex2, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFo32K(self, BF(FF0GsP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF0GsP(self, fnc, title=txt)
  else:
   FFrj68(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVFex2(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFaIgn(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVnChI()
  else:
   FFfIuR(zipPath)
   FFrj68(self, "Error while converting.", title=title)
 def VVUKS8(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFxiJi(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFWnHJ("rm -f '%s' '%s'" % (m1v, mvi))
  if FFWnHJ("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFWnHJ("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVnChI()
   FF9glI(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFrj68(self, "Cannot convert this file !", title=title)
 def VVJw9K(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCHnG6.VVYipk()
  if pathExists(pPath):
   if CC0IN8.VVUVhe(self, title, False, cbFnc=BF(self.VVJw9K, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VV8kKb = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VV8kKb.append(("%d x %d" % (item), item))
    VVM6M9 = self.VV7L22
    VVcx0D = ("Stretch", BF(self.VV8ASE, title, path, picon))
    VVNmGv = FFHAbB(self, BF(self.VVGV6F, title, path, picon, False), VV8kKb=VV8kKb, width=700, title='PIcon Max. Size', VVM6M9=VVM6M9, VVcx0D=VVcx0D, barText="OK = Fit within size")
    VVNmGv.VVCb6L(3)
  else:
   FFrj68(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VV8ASE(self, title, path, picon, VV476KObj, item):
  self.VVGV6F(title, path, picon, True, item)
  VV476KObj.cancel()
 def VVGV6F(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFjcFt(self, fncMode=CCOQON.VVbCqZ)
   except Exception as e:
    FFrj68(self, "Image Processing error:\n\n%s" % e)
 def VV7L22(self, VVNmGv, txt, ref, ndx):
  FFZzIv(self, "_help_resize", "Picture File Resizing")
 def VVLiqf(self, path):
  FFHAbB(self, BF(self.VV5XCR, path), VV8kKb=CC1B0Q.VVPRvV(), width=650, title="Select Player", VVuGSD="#11220000", VVO7CL="#11220000")
 def VV5XCR(self, path, rType=None):
  if rType:
   FF0GsP(self, BF(self.VVDGqS, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVDGqS(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCLDrN.VVLpPr(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVEl1L(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFxiJi(fDir), fName
  return "", "", ""
 @staticmethod
 def VVcbVM(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV5FZe(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVgYti(size, mode=0):
  txt = CCFric.VV0bIu(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VV0bIu(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVaB8q(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VV4nww(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFrj68(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVbILY():
  tDict = CCz7OO.VVFMqt()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVCvuJ(path):
  lst = []
  for ext in CCFric.VVbILY():
   lst.extend(FFYaSE(path, "*.%s" % ext))
  return sorted(lst, key=FFMEBl(FFY2X3))
 @staticmethod
 def VVcxWV(path):
  return FFWnHJ("tar -tzf '%s'" % path)
 @staticmethod
 def VV37eX(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVvwlA(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVQkUw:
   return VVQkUw
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCz7OO(MenuList):
 VVB3n8   = 0
 VVxLL4   = 1
 VVqGdd   = 2
 VV382K   = 3
 VVRSb9   = 4
 VVVZpW   = 5
 VV0nLp   = 6
 VVJs4f   = 7
 VVLuEF   = "<List of Storage Devices>"
 VVOIhw  = "<Parent Directory>"
 VVCmt2   = 0
 VVRvxs   = 1
 VVHOL9 = 2
 VV6y4R  = 3
 VVQk7O   = 4
 VVvhM1   = 5
 FILE_TYPE_LINK   = 6
 VVvYm5  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVPHvp=False, directory="/", VVfwge=True, VVLcsf=True, VVyNJU=True, VVSWXD=None, VVcbBI=False, VVX5UZ=False, VVazht=False, isTop=False, VVEqCo=None, VVcI5n=1000, VVC5IT=30, VVS9mk=30):
  MenuList.__init__(self, list, VVPHvp, eListboxPythonMultiContent)
  self.VVfwge  = VVfwge
  self.VVLcsf    = VVLcsf
  self.VVyNJU  = VVyNJU
  self.VVSWXD  = VVSWXD
  self.VVcbBI   = VVcbBI
  self.VVX5UZ   = VVX5UZ or []
  self.VVazht   = VVazht or []
  self.isTop     = isTop
  self.additional_extensions = VVEqCo
  self.VVcI5n    = VVcI5n
  self.VVC5IT    = VVC5IT
  self.VVS9mk    = VVS9mk
  self.EXTENSIONS    = CCz7OO.VVFMqt()
  self.VVZ15i   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFhX1r("#11ff4444")
  self.l.setFont(0, gFont(VV9whc, self.VVC5IT))
  self.l.setItemHeight(self.VVS9mk)
  self.png_mem   = CCz7OO.VVzoFM("mem")
  self.png_usb   = CCz7OO.VVzoFM("usb")
  self.png_fil   = CCz7OO.VVzoFM("fil")
  self.png_dir   = CCz7OO.VVzoFM("dir")
  self.png_dirup   = CCz7OO.VVzoFM("dirup")
  self.png_srv   = CCz7OO.VVzoFM("srv")
  self.png_slwfil   = CCz7OO.VVzoFM("slwfil")
  self.png_slbfil   = CCz7OO.VVzoFM("slbfil")
  self.png_slwdir   = CCz7OO.VVzoFM("slwdir")
  self.VVgp8e()
  self.VVfLjF(directory)
 @staticmethod
 def VVzoFM(category):
  return LoadPixmap("%s%s.png" % (VV8hpn, category), getDesktop(0))
 @staticmethod
 def VVFMqt():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVXSBh(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFz551(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF7kJS(" -> " , VV691Y) + FF7kJS(os.readlink(path), VVomgc)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVS9mk + 10, 0, self.VVcI5n, self.VVS9mk, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVcP0F: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVS9mk-4, self.VVS9mk-4, png, None, None, VVcP0F))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVS9mk-4, self.VVS9mk-4, png, None, None))
  return tableRow
 def VVPfmF(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVgp8e(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVzpv4(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVlIp6(self, file):
  if os.path.realpath(file) == file:
   return self.VVzpv4(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVzpv4(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVzpv4(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVTXKU(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVVexO(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VV5u6F(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVVexO(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVVexO(self, row, bg):
  if self.VVdK1S(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVdK1S(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVvhM1, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVQk7O:
    if   VVcsO2           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVOqd6(self):
  return self.VVdK1S(self.list[self.l.getCurrentSelectionIndex()])
 def VVXaZS(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVZwBu(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVfLjF(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVyNJU:
    self.current_mountpoint = self.VVlIp6(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVyNJU:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVazht and not self.VVZwBu(path, self.VVX5UZ):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVXSBh(name=p.description, absolute=path, isDir=True, typ=self.VVCmt2, png=png))
    path = "/"
    if path not in self.VVazht and not self.VVZwBu(path, self.VVX5UZ):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVXSBh(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVRvxs, png=self.png_mem))
  elif self.VVcbBI:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVZ15i = eServiceCenter.getInstance()
   list = VVZ15i.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVfwge and not self.isTop:
   if directory == self.current_mountpoint and self.VVyNJU:
    self.list.append(self.VVXSBh(name=self.VVLuEF, absolute=None, isDir=True, typ=self.VVHOL9, png=self.png_dirup))
   elif (directory != "/") and not (self.VVazht and self.VVzpv4(directory) in self.VVazht):
    self.list.append(self.VVXSBh(name=self.VVOIhw, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VV6y4R, png=self.png_dirup))
  if self.VVfwge:
   for x in directories:
    if not (self.VVazht and self.VVzpv4(x) in self.VVazht) and not self.VVZwBu(x, self.VVX5UZ):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVXSBh(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFz551(x)) else self.VVQk7O, png=png))
  if self.VVLcsf:
   for x in files:
    if self.VVcbBI:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FF7kJS(" -> " , VV691Y) + FF7kJS(target, VVomgc)
       else:
        png = self.png_slbfil
        name += FF7kJS(" -> " , VV691Y) + FF7kJS(target, VVD6mq)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVPfmF(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV8hpn, category))
    if (self.VVSWXD is None) or iCompile(self.VVSWXD[0], flags=self.VVSWXD[1]).search(path):
     self.list.append(self.VVXSBh(name=name, absolute=x , isDir=False, typ=self.VVvhM1, png=png))
  if self.VVyNJU and len(self.list) == 0:
   self.list.append(self.VVXSBh(name=FF7kJS("No USB connected", VViSml), absolute=None, isDir=False, typ=self.VVvYm5, png=self.png_usb))
  self.l.setList(self.list)
  self.VVdwE4()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVKt0x(self):
  return self.current_directory
 def VVowQb(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVtPfU(self):
  return self.VVUEhQ() and self.VVKt0x()
 def VVUEhQ(self):
  return self.list[0][1][7] in (self.VVLuEF, self.VVOIhw)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVfLjF(self.getSelection()[0], self.current_directory)
 def VV0g9u(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVh0pu)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVh0pu)
 def VVh0pu(self, action, device):
  self.VVgp8e()
  if self.current_directory is None:
   self.VV66tj()
 def VV66tj(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVfLjF(self.current_directory, self.VV0g9u())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VV0ign(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVB3n8 : nameAlpMode, nameAlpTxt = self.VVxLL4, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVB3n8, sAZ
  if mode == self.VVqGdd : nameNumMode, nameNumTxt = self.VV382K, s90
  else       : nameNumMode, nameNumTxt = self.VVqGdd, s09
  if mode == self.VVRSb9 : dateMode, dateTxt = self.VVVZpW, sON
  else       : dateMode, dateTxt = self.VVRSb9, sNO
  if mode == self.VV0nLp : typeMode, typeTxt = self.VVJs4f, sZA
  else       : typeMode, typeTxt = self.VV0nLp, sAZ
  if   mode in (self.VVB3n8, self.VVxLL4): txt = "Name (%s)" % (sAZ if mode == self.VVB3n8 else sZA)
  elif mode in (self.VVqGdd, self.VV382K): txt = "Name (%s)" % (s09 if mode == self.VVB3n8 else s90)
  elif mode in (self.VVRSb9, self.VVVZpW): txt = "Date (%s)" % (sNO if mode == self.VVRSb9 else sON)
  elif mode in (self.VV0nLp, self.VVJs4f): txt = "Type (%s)" % (sAZ if mode == self.VV0nLp else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVdwE4(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFaoHf(CFG.browserSortMode, mode)
   FFaoHf(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVUEhQ() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVB3n8, self.VVxLL4):
    rev = True if mode == self.VVxLL4 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVqGdd, self.VV382K):
    rev = True if mode == self.VV382K else False
    self.list = sorted(self.list[item0:], key=FFMEBl(BF(self.VVmAz0, isMix, rev)), reverse=rev)
   elif mode in (self.VVRSb9, self.VVVZpW):
    rev = True if mode == self.VVVZpW else False
    self.list = sorted(self.list[item0:], key=FFMEBl(BF(self.VV7m4i, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVJs4f else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVmAz0(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFY2X3(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FF62TB(dir2, dir1) or FFY2X3(name1, name2)
 def VV7m4i(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FF62TB(stat2.st_ctime, stat1.st_ctime)
    else : return FF62TB(dir2, dir1) or FF62TB(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCNsZw(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFpC8B(VVy20n, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVI2kC   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVsY0m(defFG, "#00FFFFFF")
  self.defBG   = self.VVsY0m(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF74S2(self, self.Title)
  self["keyRed"].show()
  FFFQrh(self["keyGreen"] , "< > Transp.")
  FFFQrh(self["keyYellow"], "Foreground")
  FFFQrh(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVetD2     ,
   "green"   : self.VVetD2     ,
   "yellow"  : BF(self.VVdT9C, False)  ,
   "blue"   : BF(self.VVdT9C, True)  ,
   "up"   : self.VVwG1X       ,
   "down"   : self.VVh50n      ,
   "left"   : self.VVAwoe      ,
   "right"   : self.VVhFYt      ,
   "last"   : BF(self.VVsdFH, -5) ,
   "next"   : BF(self.VVsdFH, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVHrlo)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFIY0q(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFIY0q(self["keyRed"] , c)
  FFIY0q(self["keyGreen"] , c)
  self.VVjhhD()
  self.VVcgP2()
  FFIyfV(self["myColorTst"], self.defFG)
  FFIY0q(self["myColorTst"], self.defBG)
 def VVsY0m(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVcgP2(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV3y80(0, 0)
     return
 def VVetD2(self):
  self.close(self.defFG, self.defBG)
 def VVwG1X(self): self.VV3y80(-1, 0)
 def VVh50n(self): self.VV3y80(1, 0)
 def VVAwoe(self): self.VV3y80(0, -1)
 def VVhFYt(self): self.VV3y80(0, 1)
 def VV3y80(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVLNWV()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVbB6o()
 def VVjhhD(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVbB6o(self):
  color = self.VVLNWV()
  if self.isBgMode: FFIY0q(self["myColorTst"], color)
  else   : FFIyfV(self["myColorTst"], color)
 def VVdT9C(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVjhhD()
   self.VVcgP2()
 def VVsdFH(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV3y80(0, 0)
 def VVExNs(self):
  return hex(self.transp)[2:].zfill(2)
 def VVLNWV(self):
  return ("#%s%s" % (self.VVExNs(), self.colors[self.curRow][self.curCol])).upper()
class CCnx0Q(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFpC8B(VV73Mc, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FF74S2(self, title="%s%s%s" % (self.Title, " " * 10, FF7kJS("Change values with Up , Down, < , 0 , >", VViSml)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV0TcE      ,
   "cancel" : self.VVrEeW      ,
   "info"  : self.VVgZi4    ,
   "red"  : self.VVl86J  ,
   "green"  : self.VVeFOc   ,
   "yellow" : BF(self.VVqvvT, 0)  ,
   "blue"  : self.VVW9h9    ,
   "menu"  : self.VVJKET      ,
   "left"  : self.VVAwoe      ,
   "right"  : self.VVhFYt      ,
   "last"  : self.VVYXZc     ,
   "next"  : self.VVoasD     ,
   "0"   : self.VVLDUe    ,
   "up"  : self.VVwG1X       ,
   "down"  : self.VVh50n      ,
   "pageUp" : BF(self.VVIZ5J, True) ,
   "pageDown" : BF(self.VVIZ5J, False) ,
   "chanUp" : BF(self.VVIZ5J, True) ,
   "chanDown" : BF(self.VVIZ5J, False) ,
   "play"  : BF(self.VVWNfx, "pause")  ,
   "pause"  : BF(self.VVWNfx, "pause")  ,
   "playPause" : BF(self.VVWNfx, "pause")  ,
   "stop"  : BF(self.VVWNfx, "pause")  ,
   "audio"  : BF(self.VVWNfx, "audio")  ,
   "subtitle" : BF(self.VVWNfx, "subtitle") ,
   "rewind" : BF(self.VVWNfx, "rewind" ) ,
   "forward" : BF(self.VVWNfx, "forward" ) ,
   "rewindDm" : BF(self.VVWNfx, "rewindDm") ,
   "forwardDm" : BF(self.VVWNfx, "forwardDm")
  }, -1)
  self.VVGvPg()
  self.onShown.append(self.VVHrlo)
  self.onClose.append(self.VVhl2s)
 def VVGvPg(self):
  lst = []
  for fil in FFYaSE(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVOZAa:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVHrlo(self):
  self.onShown.remove(self.VVHrlo)
  FFtJRK(self)
  FFgqCi(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVzNv3()
  self.VVFQgl()
  self.VVZ3yI()
 def VVhl2s(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VV83fH(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFIY0q(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VV71GT()
 def VVzNv3(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFIY0q(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VV0TcE(self):
  if self.settingShown:
   confItem = self.VVWOS2()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VV8kKb = []
   if isinstance(lst[0], tuple):
    for item in lst: VV8kKb.append((item[1], item[0]))
   else:
    for item in lst: VV8kKb.append((item, item))
   VVNmGv = FFHAbB(self, self.VVJUE2, VV8kKb=VV8kKb, width=700, title=title, VVuGSD="#33221111", VVO7CL="#33110011")
   VVNmGv.VVeV8t(confItem.getText())
  else:
   self.close("subtExit")
 def VVJUE2(self, item=None):
  if item:
   self.VVWOS2()[self.CursorPos].setValue(item)
   self.VV71GT()
   self.VVFQgl()
   self.VV8ZNI(True)
 def VVrEeW(self):
  for confItem in self.VVWOS2():
   if confItem.isChanged():
    FFo32K(self, BF(self.VVu7jW, cbFnc=self.VVxb45), "Save Changes ?", callBack_No=self.VVpBR0, title=self.Title)
    break
  else:
   self.VVxb45()
 def VVxb45(self):
   if self.settingShown: self.VVzNv3()
   else    : self.close("subtExit")
 def VVJKET(self):
  if self.settingShown: self.VVlp0o()
  else    : self.VV83fH()
 def VVAwoe(self): self.VV5uCw(-1)
 def VVhFYt(self): self.VV5uCw(1)
 def VV5uCw(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVaDu2()
   if pos == -1: ndx = self.VVlSFQ(posVal)
   else  : ndx = self.VVTn7M(posVal)
   if   ndx < 0      : FFAM12(self, "Not found" , 500)
   elif ndx == 0      : FFAM12(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFAM12(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVzao5(frmSec)
    if allow:
     self.VVqvvT(delay, True)
     self.VV8ZNI(force=True)
     CCajpF(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFAM12(self, "Delay out of range", 800)
 def VVIZ5J(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVWNfx(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVYXZc(self) : self.VVlZWM(5)
 def VVoasD(self) : self.VVlZWM(6)
 def VVLDUe(self) : self.VVlZWM(-1)
 def VVwG1X(self):
  if self.settingShown: self.VVlZWM(1)
  else    : self.VVIZ5J(True)
 def VVh50n(self):
  if self.settingShown: self.VVlZWM(0)
  else    : self.VVIZ5J(False)
 def VVlZWM(self, direction):
  if self.settingShown:
   confItem = self.VVWOS2()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VV71GT()
   self.VVFQgl()
   self.VV8ZNI(True)
 def VVWOS2(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVpBR0(self):
  for confItem in self.VVWOS2(): confItem.cancel()
  self.VV71GT()
  self.VVFQgl()
  self.VVzNv3()
 def VVl86J(self):
  if self.settingShown:
   FFo32K(self, self.VVKhwP, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVKhwP(self):
  for confItem in self.VVWOS2(): confItem.setValue(confItem.default)
  self.VVu7jW()
  self.VV71GT()
  self.VVFQgl()
 def VVqvvT(self, delay, force=False):
  if self.settingShown or force:
   FFaoHf(CFG.subtDelaySec, delay)
   self.VVkmW2()
   self.VV71GT()
   self.VVFQgl()
   if self.settingShown:
    FFAM12(self, 'Reset to "0"', 800, isGrn=True)
 def VVeFOc(self):
  if self.settingShown:
   self.VVu7jW()
   self.VVzNv3()
 def VVu7jW(self, cbFnc=None):
  for confItem in self.VVWOS2(): confItem.save()
  configfile.save()
  self.VVkmW2()
  FFAM12(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VV71GT(self):
  cfgLst = self.VVWOS2()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVFQgl(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FF2UGB(path, fnt, isRepl=1)
  else:
   fnt = VV9whc
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFFgzn(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFIyfV(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFIY0q(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFrSHG(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFFgzn(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFKONN()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFSHXD(self, winW, winH)
 def VVgZi4(self):
  sp = "    "
  txt  = "%s\n"   % FF7kJS("Subtitle File:", VVSFOM)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FF7kJS("Subtitle Settings:", VVSFOM)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVaDu2()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFjXk8(frmSec1)
   time2 = FFjXk8(toSec2)
   txt += "\n"
   txt += "%s\n"       % FF7kJS("Timing:", VVSFOM)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFjXk8(durVal)
   txt += sp + "Progress\t: %s\n" % FFjXk8(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FF7kJS("Subtitle end reached.", VVvkGK)
  FFaIgn(self, txt, title="Current Subtitle")
 def VVZ3yI(self, path="", delay=0, enc=""):
  FF0GsP(self, BF(self.VVbOck, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVbOck(self, path="", delay=0, enc=""):
  FFAM12(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VViAhX(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VV71GT()
     self.VVnfjT()
   else:
    path, delay, enc = CCnx0Q.VVxuaC(self)
    if path:
     self.VVZ3yI(path=path, delay=delay, enc=enc)
    else:
     self.VVlp0o()
  except:
   pass
 def VVnfjT(self):
  posVal, durVal = self.VVaDu2()
  if self.VVCNv4(posVal):
   return
  CCnx0Q.VVSFDS(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VV8ZNI)
  except:
   self.timerUpdate.callback.append(self.VV8ZNI)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVQy5d)
  except:
   self.timerEndText.callback.append(self.VVQy5d)
  FFAM12(self, "Subtitle started", 700, isGrn=True)
 def VVCNv4(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCnx0Q.VVU3U7(self)
   FFfIuR(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVlp0o(self):
  c1, c2, c3, c4, c5 = "", VVSFOM, VVLAFW, VV4d6Z, VVvkGK
  VV8kKb = []
  VV8kKb.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VV8kKb.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VV8kKb.append(VVnK97)
  VV8kKb.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VV8kKb.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VV8kKb.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VV8kKb.append(VVnK97)
   VV8kKb.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VV8kKb.append(VVnK97)
   VV8kKb.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VV8kKb.append(VVnK97)
   VV8kKb.append(("Help (Keys)"        , "help"  ))
  FFHAbB(self, self.VV6Bk2, VV8kKb=VV8kKb, width=700, title='Find Subtitle ".srt" File', VVuGSD="#33221111", VVO7CL="#33110011")
 def VV6Bk2(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVzY9S(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVzY9S(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVkID6, BF(CCFric, patternMode="srt", VVZmiW=sDir))
   elif item.startswith("sugSrt") : self.VVzY9S(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FF0GsP(self, BF(CCP2t1.VVDX2J, self, self.lastSubtFile, self.VVaHO6, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFAM12(self, "SRT File error", 1000)
   elif item == "disab":
    FFfIuR(CCnx0Q.VVU3U7(self))
    self.close("subtExit")
   elif item == "help"    : FFZzIv(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVaHO6(self, item=None):
  if item:
   FF0GsP(self, BF(self.VVZ3yI, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVkID6(self, path):
  if path:
   FFaoHf(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVZ3yI(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVzY9S(self, defSrt="", mode=0, coeff=0.25):
  FF0GsP(self, BF(self.VV5yan, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VV5yan(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCnx0Q.VVXoaG(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFO8C9('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFViIp(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVvHjK(srtList, coeff)
     if err:
      if self.settingShown: FFIZWt(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVDb2Q = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFxiJi(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVDb2Q.append((fName, Dir))
   VVt6tD  = ("Select"    , self.VVClwF     , [])
   VVqFCi = self.VVfmlB
   VVk5TH = (""     , self.VV661q       , [])
   VVZApD = (""     , BF(self.VVVVUN, defSrt, False) , [])
   VVaq9G = ("Find Current File" , BF(self.VVVVUN, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVWFHs=widths, VVC5IT=28, VVt6tD=VVt6tD, VVqFCi=VVqFCi, VVk5TH=VVk5TH, VVZApD=VVZApD, VVaq9G=VVaq9G, lastFindConfigObj=CFG.lastFindSubtitle
     , VVuGSD="#11002222", VVO7CL="#33001111", VV2ftx="#33001111", VV0p3X="#11ffff00", VVgjmd="#11445544", VVZ0ud="#22222222", VVGQoh="#11002233")
  elif self.settingShown : FFIZWt(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVfmlB(self, VVt27A):
  VVt27A.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VV661q(self, VVt27A, title, txt, colList):
  fName, Dir = colList
  FFaIgn(VVt27A, "%s\n\n%s%s" % (FF7kJS("Path:", VVSFOM), Dir, fName), title=title)
 def VVVVUN(self, path, VVSOst, VVt27A, title, txt, colList):
  for ndx, row in enumerate(VVt27A.VVXwRB()):
   if path == row[1].strip() + row[0].strip():
    VVt27A.VVagt1(ndx)
    break
  else:
   if VVSOst:
    FFAM12(VVt27A, "Not in list !", 1000)
 def VVClwF(self, VVt27A, title, txt, colList):
  VVt27A.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVZ3yI(path=path)
 def VVvHjK(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCS6Mr.VVp9jG(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCS6Mr.VVyB0w(evName, "en")[0] or evName
   lst, err = CCnx0Q.VVhlm0(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VViAhX(self, path, enc=None):
  if enc and CCP2t1.VV1idm(path, enc)      : enc = enc
  elif CCP2t1.VV1idm(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FF7PcS(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFKcIu(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VV0XV4(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVzCpj(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVkmW2()
  return subtList, ""
 def VVzCpj(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VV0XV4(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVkmW2(self):
  path = CCnx0Q.VVU3U7(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VV8ZNI(self, force=False):
  posVal, durVal = self.VVaDu2()
  if self.VVCNv4(posVal):
   return
  curIndex = self.VVxwPg(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVQy5d()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFIyfV(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVaDu2(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCLDrN.VV3vMp(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCS6Mr.VVp9jG(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVxwPg(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVlSFQ(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVTn7M(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVQy5d(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFIyfV(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVW9h9(self):
  FF0GsP(self, self.VVCvuX, title="Loading Lines ...")
 def VVCvuX(self):
  VVDb2Q = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVDb2Q.append((cap, FFjXk8(frm), str(frm), firstLine))
  if VVDb2Q:
   title = "Select Current Subtitle Line"
   VVOY6r  = self.VVkVAX
   VVqFCi = self.VVAl3v
   VVt6tD  = ("Select"   , self.VVgyCU , [title])
   VVaq9G = ("Current Line" , self.VVWHcd , [True])
   VV9CSs = ("Reset Delay" , self.VVnHRM , [])
   VVTO3h = ("New Delay"  , self.VVjVkp   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVmBED  = (CENTER , CENTER, CENTER , LEFT    )
   VVt27A = FFyZJ5(self, None, title=title, header=header, VVI2kC=VVDb2Q, VVmBED=VVmBED, VVWFHs=widths, VVC5IT=28, VVOY6r=VVOY6r, VVqFCi=VVqFCi, VVt6tD=VVt6tD, VVaq9G=VVaq9G, VV9CSs=VV9CSs, VVTO3h=VVTO3h
          , VVuGSD="#33002222", VVO7CL="#33001111", VV2ftx="#33110011", VV0p3X="#11ffff00", VVgjmd="#0a334455", VVZ0ud="#22222222", VVGQoh="#33002233")
  else:
   FFIZWt(self, "Cannot read lines !", 2000)
 def VVkVAX(self, VVt27A):
  self.subtLinesTable = VVt27A
  if CFG.subtDelaySec.getValue():
   VVt27A["keyYellow"].show()
   VVt27A["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVt27A["keyYellow"].hide()
  VVt27A["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFIY0q(VVt27A["keyBlue"], "#22222222")
  VVt27A.VVFoTM(BF(self.VVqKIA, VVt27A))
  self.VVWHcd(VVt27A, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVrEed)
  except:
   self.timerSubtLines.callback.append(self.VVrEed)
  self.timerSubtLines.start(1000, False)
 def VVAl3v(self, VVt27A):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVt27A.cancel()
 def VVrEed(self):
  if self.subtLinesTable:
   VVt27A = self.subtLinesTable
   posVal, durVal = self.VVaDu2()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVxwPg(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVt27A.VV4w1S(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVt27A.VVwR5j(self.subtLinesTableNdx, row)
     row = VVt27A.VV4w1S(curIndex)
     row[0] = color + row[0]
     VVt27A.VVwR5j(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVgyCU(self, VVt27A, Title):
  delay, color, allow = self.VVqHsO(VVt27A)
  if allow:
   self.VVAl3v(VVt27A)
   self.VVqvvT(delay, True)
  else:
   FFAM12(VVt27A, "Delay out of range", 1500)
 def VVWHcd(self, VVt27A, VVSOst, onlyColor=False):
  if VVt27A:
   posVal, durVal = self.VVaDu2()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVxwPg(posVal)
    if curIndex > -1:
     VVt27A.VVagt1(curIndex)
    else:
     ndx = self.VVlSFQ(posVal)
     if ndx > -1:
      VVt27A.VVagt1(ndx)
 def VVnHRM(self, VVt27A, title, txt, colList):
  if VVt27A["keyYellow"].getVisible():
   self.VVqvvT(0, True)
   VVt27A["keyYellow"].hide()
   self.VVWHcd(VVt27A, False)
 def VVqKIA(self, VVt27A):
  delay, color, allow = self.VVqHsO(VVt27A)
  VVt27A["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVqHsO(self, VVt27A):
  lineTime = float(VVt27A.VVM4Gr()[2].strip())
  return self.VVzao5(lineTime)
 def VVzao5(self, lineTime):
  posVal, durVal = self.VVaDu2()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VV30Pd
   else     : allow, color = False, VVvkGK
   delay = FFB9GB(val, -600, 600)
  return delay, color, allow
 def VVjVkp(self, VVt27A, title, txt, colList):
  pass
 @staticmethod
 def VVxyTe(SELF):
  path, delay, enc = CCnx0Q.VVxuaC(SELF)
  return True if path else False
 @staticmethod
 def VVxuaC(SELF):
  path, delay, enc = CCnx0Q.VVnGlc(SELF)
  if not path:
   path = CCnx0Q.VVUMUO(SELF)
  return path, delay, enc
 @staticmethod
 def VVnGlc(SELF):
  srtCfgPath = CCnx0Q.VVU3U7(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFKcIu(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVU3U7(SELF):
  fPath, fDir, fName = CCFric.VVEl1L(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCS6Mr.VVp9jG(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFN3N8(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVUMUO(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCFric.VVEl1L(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCnx0Q.VVXoaG(SELF)
    bLst, err = CCnx0Q.VVhlm0(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVXoaG(SELF):
  fPath, fDir, fName = CCFric.VVEl1L(SELF)
  if pathExists(fDir):
   files = FFYaSE(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVhlm0(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVKLf0():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVSFDS(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCnx0Q.VVPktw()
 @staticmethod
 def VVPktw():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCAZUu(ScrollLabel):
 def __init__(self, parentSELF, text="", VVaBtr=True):
  ScrollLabel.__init__(self, text)
  self.VVaBtr   = VVaBtr
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVhIDk  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVC5IT    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVmEtD ,
   "green"   : self.VVlpyc ,
   "yellow"  : self.VVgun3 ,
   "blue"   : self.VVgrCN ,
   "up"   : self.VVvR0L   ,
   "down"   : self.VV5gAv  ,
   "left"   : self.VVvR0L   ,
   "right"   : self.VV5gAv  ,
   "last"   : BF(self.VV8vL7, 0) ,
   "0"    : BF(self.VV8vL7, 1) ,
   "next"   : BF(self.VV8vL7, 2) ,
   "pageUp"  : self.VV7QPa   ,
   "chanUp"  : self.VV7QPa   ,
   "pageDown"  : self.VV9acH   ,
   "chanDown"  : self.VV9acH
  }, -1)
 def VVnulZ(self, isResizable=True, VV7Pvn=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFIyfV(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFIY0q(self.parentSELF["keyRedTop"], "#113A5365")
  FFtJRK(self.parentSELF, True)
  self.isResizable = isResizable
  if VV7Pvn:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVC5IT  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFIY0q(self, color)
 def VV5oNy(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVS9mk  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVS9mk)
  margin   = int(VVS9mk / 6)
  self.pageHeight = int(self.pageLines * VVS9mk)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVhIDk - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVSGVJ()
 def VVvR0L(self):
  if self.VVhIDk > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VV5gAv(self):
  if self.VVhIDk > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV7QPa(self):
  self.setPos(0)
 def VV9acH(self):
  self.setPos(self.VVhIDk-self.pageHeight)
 def VVxi06(self):
  return self.VVhIDk <= self.pageHeight or self.curPos == self.VVhIDk - self.pageHeight
 def getText(self):
  return self.message
 def VVSGVJ(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVhIDk, 3))
   start = int((100 - vis) * self.curPos / (self.VVhIDk - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VViXLk=VV1E5l):
  old_VVxi06 = self.VVxi06()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVhIDk = self.long_text.calculateSize().height()
   if self.VVaBtr and self.VVhIDk > self.pageHeight:
    self.scrollbar.show()
    self.VVSGVJ()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVhIDk))
    self.VVhIDk = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVhIDk))
   else:
    self.scrollbar.hide()
   if   VViXLk == VVBeVn: self.setPos(0)
   elif VViXLk == VVFkyJ : self.VV9acH()
   elif old_VVxi06    : self.VV9acH()
 def appendText(self, text, VViXLk=VVFkyJ):
  self.setText(self.message + str(text), VViXLk=VViXLk)
 def VVgun3(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV2PZO(size)
 def VVgrCN(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV2PZO(size)
 def VVlpyc(self):
  self.VV2PZO(self.VVC5IT)
 def VV2PZO(self, VVC5IT):
  self.long_text.setFont(gFont(self.fontFamily, VVC5IT))
  self.setText(self.message, VViXLk=VV1E5l)
  self.VVewHM()
 def VV8vL7(self, align):
  self.long_text.setHAlign(align)
 def VVmEtD(self):
  VV8kKb = []
  VV8kKb.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Align Left" , "left" ))
  VV8kKb.append(("Align Center" , "center" ))
  VV8kKb.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VV8kKb.append(VVnK97)
   VV8kKb.append((FF7kJS("Save to File", VVSFOM), "save"))
  VV8kKb.append(VVnK97)
  VV8kKb.append(("Keys (Shortcuts)", "help"))
  FFHAbB(self.parentSELF, self.VVqQZI, VV8kKb=VV8kKb, title="Text Option", width=500)
 def VVqQZI(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VV8vL7(0)
   elif item == "center" : self.VV8vL7(1)
   elif item == "right" : self.VV8vL7(2)
   elif item == "save"  : self.VVbjQf()
   elif item == "help"  : FFZzIv(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVbjQf(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFxiJi(expPath), self.outputFileToSave, FFC2jX())
   with open(outF, "w") as f:
    f.write(FFJYbZ(self.message))
   FF9glI(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFrj68(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVewHM(self, minHeight=0):
  if self.isResizable:
   VVS9mk = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVS9mk * (len(self.message.splitlines()) + 1))
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
