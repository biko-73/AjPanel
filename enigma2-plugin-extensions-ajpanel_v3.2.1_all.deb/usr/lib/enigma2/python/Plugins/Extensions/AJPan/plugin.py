import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, sleep as iSleep
from time      import time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVcmc0   = "v3.2.1"
VVS77d    = "18-11-2021"
EASY_MODE    = 0
VVyMRU   = 0
VVGIJX   = 0
VVsNEX  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVu6LP  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVic63    = "/media/usb/"
VVYZ3v    = "/usr/share/enigma2/picon/"
VVPZfu   = "/etc/enigma2/"
VV77GZ  = "ajpanel_update_url"
VVSIK4   = "AJPan"
VVkULC    = ""
VVgk1L    = "Regular"
VVFR4v      = "-" * 80;
VV6Efe    = (VVFR4v, )
VVVIjd    = ""
VVvjJi   = " && echo 'Successful' || echo 'Failed!'"
VVoI13    = []
VVvTQP     = 0
VVu49L    = ""
VVNqXw  = False
VVHke5  = False
VVLE1I     = 0
VVi7ZF    = 1
VVGf9D    = 2
VV1gxD   = 3
VVKKAP    = 4
VVgLgu    = 5
VVHoLH = 6
VVqdo1 = 7
VVPwBt  = 8
VVHEzh   = 9
VVinsn   = 10
VV5VmV   = 11
VVKwao  = 12
VVWGyt  = 13
VVvrt0    = 14
VVmvSf   = 15
VVbYEN   = 16
VVNGcB    = 17
VVkSsZ    = 18
VVNWfO  = 15
VV3npe   = 0
VVKIxe   = 1
VV1ZNL   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.PIconsPath     = ConfigDirectory(default=VVYZ3v, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVic63, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFgatD():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV1K88  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVcXT9 = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV1K88  : return 0
  elif VVcXT9 : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVKW1w = FFgatD()
VVNkuN = VVRhh2 = VVl05N = VVQy4t = VVSda0 = VVi0qf = VVDoEn = VVIuu8 = COLOR_CONS_BRIGHT_YELLOW = VVVNGK = VVlE7m = VVkCrP = ""
def FFaIxL(FFaIxLText="", addSep=True):
 if VVyMRU:
  FFaIxLText = str(FFaIxLText)
  if "\n" in FFaIxLText: FFaIxLText = "\n" + FFaIxLText
  txt = VVFR4v + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFaIxLText))
  os.system("cat << '_EOF' \n" + txt + "\n_EOF")
def FF0ArZ(txt, isAppend=True, ignoreErr=False):
 if VVyMRU:
  tm = FFPgIK()
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFaIxL(err)
  FFaIxL("Output Log File : %s" % fileName)
VVoI13 = []
def FF3Ivr(win):
 global VVoI13
 if not win in VVoI13:
  VVoI13.append(win)
def FFz3mf(*args):
 global VVoI13
 for win in VVoI13:
  try:
   win.close()
  except:
   pass
 VVoI13 = []
def FFzBD9():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV7mfb = FFzBD9()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFo2sM()      : return getDescriptor(FFaiKO   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFFR9Q()   : return getDescriptor(FFaiKO   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFYxCs()   : return getDescriptor(FF54vL , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager")
def FFPbC0()  : return getDescriptor(FFc0Ce , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Live Log (OSCam/NCam)")
def FFOB98(): return getDescriptor(FFvG5T , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player")
def FFKGn1()  : return getDescriptor(FFQE7i  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV")
def FFWrH3()       : return getDescriptor(FFdhAM  , [ PluginDescriptor.WHERE_MENU    ] )
def FFauC3()     : return PluginDescriptor(fnc=FFvqUU, where=[PluginDescriptor.WHERE_SESSIONSTART])
def Plugins(**kwargs):
 result = [ FFo2sM() , FFWrH3() , FFauC3() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFFR9Q())
  result.append(FFYxCs())
  result.append(FFPbC0())
  result.append(FFOB98())
  result.append(FFKGn1())
 return result
def FFvqUU(reason, **kwargs):
 if reason == 0:
  FF7FOY()
  if "session" in kwargs:
   session = kwargs["session"]
   FFZHLK(session)
   CCOJSM(session)
def FFdhAM(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFaiKO, PLUGIN_NAME, 45)]
 else:
  return []
def FFaiKO(session, **kwargs):
 session.open(Main_Menu)
def FF54vL(session, **kwargs):
 session.open(CC2SNv)
def FFc0Ce(session, **kwargs):
 FFO4RI(session, CCDAiB.VVPju6)
def FFvG5T(session, **kwargs):
 FFOlVP(session, isFromSession=True)
def FFQE7i(session, **kwargs):
 session.open(CCaJkM)
def FFPg79():
 pluginList   = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel   = FFFR9Q()
 descrFileMan  = FFYxCs()
 descrCamLog   = FFPbC0()
 descrSignalPlayer = FFOB98()
 descrIptvMenu  = FFKGn1()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel in pluginList   : iPlugins.addPlugin(descrPanel)
   if not descrFileMan in pluginList  : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList  : iPlugins.addPlugin(descrCamLog)
   if not descrSignalPlayer in pluginList : iPlugins.addPlugin(descrSignalPlayer)
   if not descrIptvMenu in pluginList  : iPlugins.addPlugin(descrIptvMenu)
  else:
   if descrPanel in pluginList    : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList   : iPlugins.removePlugin(descrFileMan)
   if descrCamLog in pluginList   : iPlugins.removePlugin(descrCamLog)
   if descrSignalPlayer in pluginList  : iPlugins.removePlugin(descrSignalPlayer)
   if descrIptvMenu in pluginList   : iPlugins.removePlugin(descrIptvMenu)
 except:
  pass
VVGFNm = None
def FF7FOY():
 try:
  global VVGFNm
  if VVGFNm is None:
   VVGFNm    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFZtjP
  ChannelContextMenu.FFi8iC = FFi8iC
 except:
  pass
def FFZtjP(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVGFNm(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFi8iC, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFi8iC, title1, csel, isFind=True))))
def FFi8iC(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFLYCF(refCode)
 except:
  pass
 self.session.open(boundFunction(CCJsiF, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFZHLK(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFgwr0, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFgwr0, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFgwr0, session, "lred")
def FFgwr0(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFOlVP(session, isFromSession=True)
def FF7MWH(SELF, title="", addLabel=False, addScrollLabel=False, VVtP1e=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFqA9R()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCFzsY(SELF)
 if VVtP1e:
  SELF["myMenu"] = MenuList(VVtP1e)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VV8nYP        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFg0z1(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFESEH, SELF, "0") ,
  "1"    : boundFunction(FFESEH, SELF, "1") ,
  "2"    : boundFunction(FFESEH, SELF, "2") ,
  "3"    : boundFunction(FFESEH, SELF, "3") ,
  "4"    : boundFunction(FFESEH, SELF, "4") ,
  "5"    : boundFunction(FFESEH, SELF, "5") ,
  "6"    : boundFunction(FFESEH, SELF, "6") ,
  "7"    : boundFunction(FFESEH, SELF, "7") ,
  "8"    : boundFunction(FFESEH, SELF, "8") ,
  "9"    : boundFunction(FFESEH, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFECeC, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFESEH(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVkCrP:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVkCrP + SELF.keyPressed + VVRhh2)
    txt = VVRhh2 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFt82g(SELF, txt)
def FFECeC(SELF, tableObj, colNum):
 FFt82g(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VV3MTz()
     break
 except:
  pass
def FF1WPP(SELF, setMenuAction=True):
 if setMenuAction:
  global VVVIjd
  VVVIjd = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFqA9R():
 return ("  %s" % VVVIjd)
def FFGkKQ(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFTcL7(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFahGT(color):
 return parseColor(color).argb()
def FFFxI3(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFlSQr(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFOtun(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFuvWX(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVkCrP)
 else:
  return ""
def FFi1ok(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVFR4v, word, VVFR4v, VVkCrP)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVFR4v, word, VVFR4v)
def FFMi1p(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVkCrP
def FFoPGL(color):
 if color: return "echo -e '%s' %s;" % (VVFR4v, FFuvWX(VVFR4v, VVIuu8))
 else : return "echo -e '%s';" % VVFR4v
def FF5WAx(title, color):
 title = "%s\n%s\n%s\n" % (VVFR4v, title, VVFR4v)
 return FFMi1p(title, color)
def FFjk8P(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF3xtA(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFTTch(callBackFunction):
 tCons = CCww76()
 tCons.ePopen("echo", boundFunction(FFNp2f, callBackFunction))
def FFNp2f(callBackFunction, result, retval):
 callBackFunction()
def FFCkhd(SELF, fnc, title="Processing ...", clearMsg=True):
 FFt82g(SELF, title)
 tCons = CCww76()
 tCons.ePopen("echo", boundFunction(FF8oI9, SELF, fnc, clearMsg))
def FF8oI9(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFt82g(SELF)
def FF0S1I(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFhQrI(cmd):
 txt = FF0S1I(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFgaUh(cmd):
 lines = FFhQrI(cmd)
 if lines: return lines[0]
 else : return ""
def FF2OEY(SELF, cmd):
 lines = FFhQrI(cmd)
 VVvFiF = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVvFiF.append((key, val))
  elif line:
   VVvFiF.append((line, ""))
 if VVvFiF:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFaufo(SELF, None, header=header, VV7oZO=VVvFiF, VVAF36=widths, VVpwbP=22)
 else:
  FFtERc(SELF, cmd)
def FFtERc(    SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, VVJNPv=True, VVNQut=VVKIxe, **kwargs)
def FFO99q(  SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, **kwargs)
def FFPyAy(   SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, VVEkCr=True, VVF8iA=True, VVNQut=VVKIxe, **kwargs)
def FFsbrK(  SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, VVEkCr=True, VVF8iA=True, VVNQut=VV1ZNL, **kwargs)
def FFxQD8(  SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, VVfuH0=True , **kwargs)
def FFjzVR( SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, VVszuj=True   , **kwargs)
def FF3Nmm( SELF, cmd, **kwargs): SELF.session.open(CC8OYy, VV4uLj=cmd, VVLukp=True  , **kwargs)
def FFARGV(cmd):
 return cmd + " > /dev/null 2>&1"
def FF86rl():
 return " > /dev/null 2>&1"
def FF0XMr(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFgUhe(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFh9Bt():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFgaUh(cmd)
VVz50d     = 0
VVfdyF      = 1
VV8Sak   = 2
VVCSXC      = 3
VVFCPa      = 4
VV5qEA     = 5
VVOWgY     = 6
VVc7ue  = 7
VVla2Z = 8
VVvnCM  = 9
VVBnTk     = 10
VVd6n8  = 11
VVkxGy  = 12
def FFlm1I(parmNum, grepTxt):
 if   parmNum == VVz50d  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVfdyF   : param = ["list"   , "apt list" ]
 elif parmNum == VV8Sak: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFh9Bt()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFzJLp(parmNum, package):
 if   parmNum == VVCSXC      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVFCPa      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VV5qEA     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVOWgY     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVc7ue  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVla2Z : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVvnCM  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVBnTk     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVd6n8  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVkxGy  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFh9Bt()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFfoTU():
 result = FFgaUh("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFzJLp(VVOWgY , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFARGV("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFARGV("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFuvWX(failed1, VVIuu8))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFuvWX(failed2, VVIuu8))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFuvWX(failed3, VVl05N))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFvuDj(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFzJLp(VVOWgY , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFARGV("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFuvWX(failed1, VVIuu8))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFuvWX(failed2, VVl05N))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFLVNL(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFARGV('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFARGV("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FF0FCE(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFOmkW(path, keepends=False, maxSize=-1):
 lines = FF0FCE(path, maxSize)
 return lines.splitlines(keepends)
def FFYaEL(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFOmkW(path, maxSize=maxSize)
  if lines: FFuPDq(SELF, lines, title=title, VVNQut=VVKIxe)
  else : FF50vC(SELF, path, title=title)
 else:
  FFtist(SELF, path, title)
def FFpvi6(SELF, path, title):
 if fileExists(path):
  txt = FF0FCE(path)
  txt = txt.replace("#W#", VVkCrP)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVRhh2)
  txt = txt.replace("#C#", VVVNGK)
  txt = txt.replace("#P#", VVQy4t)
  FFuPDq(SELF, txt, title=title)
 else:
  FFtist(SELF, path, title)
def FFDVOM(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFZkan(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFiowP(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFExru(parent)
 else    : return FFaJVe(parent)
def FFufc8(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFExru(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFaJVe(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFc8XJ():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVsNEX)
 paths.append(VVsNEX.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFZkan(ba)
 for p in list:
  p = ba + p + VVsNEX
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVSIK4, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVsNEX, VVSIK4 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVi2AZ, VVsT5j = FFc8XJ()
def FFnxpp():
 def VVy62j(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVWacB  = VVy62j(CFG.backupPath, CCWTU2.VVzzIQ())
 VVArXZ  = VVy62j(CFG.downloadedPackagesPath, t)
 VVu0DY = VVy62j(CFG.exportedTablesPath, t)
 VVKq9z = VVy62j(CFG.exportedPIconsPath, t)
 VV2p1K  = VVy62j(CFG.packageOutputPath, t)
 global VVic63
 VVic63 = FFExru(CFG.backupPath.getValue())
 if VVWacB or VV2p1K or VVArXZ or VVu0DY or VVKq9z:
  configfile.save()
 return VVWacB, VV2p1K, VVArXZ, VVu0DY, VVKq9z
def FF0uQ2(path):
 path = FFaJVe(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFeLWZ(SELF, pathList, tarFileName, addTimeStamp=True):
 VV7oZO = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV7oZO.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV7oZO.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV7oZO.append(path)
 if not VV7oZO:
  FFKFol(SELF, "Files not found!")
 elif not pathExists(VVic63):
  FFKFol(SELF, "Path not found!\n\n%s" % VVic63)
 else:
  VVnLkc = FFExru(VVic63)
  tarFileName = "%s%s" % (VVnLkc, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFtTMB())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV7oZO:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVFR4v
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFuvWX(tarFileName, VVDoEn))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFuvWX(failed, VVDoEn))
  cmd += "fi;"
  cmd +=  sep
  FFO99q(SELF, cmd)
def FFWECZ(SELF, title, VV8Utd):
 SELF.session.open(boundFunction(CCJ4aS, Title=title, VV8Utd=VV8Utd))
def FFr0aO(labelObj, VV8Utd):
 if VV8Utd and fileExists(VV8Utd):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVJvd9(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVJvd9)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VV8Utd)
   return True
  except:
   pass
 return False
def FFFLQ6(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFwz1x(satNum)
  return satName
def FFwz1x(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFZ41o(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFFLQ6(val)
  else  : sat = FFwz1x(val)
 return sat
def FF1zZi(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFFLQ6(num)
 except:
  pass
 return sat
def FFvHm9(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFLV7o(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFT7wI(info, iServiceInformation.sServiceref)
   prov = FFT7wI(info, iServiceInformation.sProvider)
   state = str(FFT7wI(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFMSfm(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFg14Y(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFT7wI(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFSFL7(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFLYCF(refCode):
 info = FFZ3eu(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFjr2x(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FF9N2F(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFZ3eu(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVxNcv = eServiceCenter.getInstance()
  if VVxNcv:
   info = VVxNcv.info(service)
 return info
def FFKzCJ(SELF, refCode, VVDaMP=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFzIxv(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVDaMP:
   FFOlVP(SELF, isFromSession)
 try:
  VVgvOe = InfoBar.instance
  if VVgvOe:
   VVwOzf = VVgvOe.servicelist
   if VVwOzf:
    servRef = eServiceReference(refCode)
    VVwOzf.saveChannel(servRef)
 except:
  pass
def FFzIxv(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCw9XP()
    if pr.VVWmtx(refCode, chName, decodedUrl, iptvRef):
     pr.VVtq8R(SELF, isFromSession)
def FFMSfm(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFg14Y(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFsqcp(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFE3xM(userBfile):
 txt = ""
 bFile = VVPZfu + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVPZfu + userBfile):
  fTxt = FF0FCE(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFgaUh('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFsqcp(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFSDkN(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFlwHB(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFNh3o(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFUF1Y(txt):
 try:
  return FFlwHB(FFNh3o(txt)) == txt
 except:
  return False
def FFOlVP(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCD9VV, isFromExternal=isFromSession)
 else      : FF4095(session, reopen=True)
def FF4095(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FF4095, session), CCM2yD)
  except:
   try:
    FF6QVr(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFohJ3(refCode):
 tp = CCfC6J()
 if tp.VVYhot(refCode) : return True
 else        : return False
def FF0QjM(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFspal():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFmPDO():
 VVgvOe = InfoBar.instance
 if VVgvOe:
  VVwOzf = VVgvOe.servicelist
  if VVwOzf:
   return VVwOzf.getBouquetList()
 return None
def FFElwQ():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFmxjr():
 path = FFElwQ()
 if path:
  txt = FF0FCE(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFnJtl(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVxNcv = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVxNcv.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFzIwD():
 VVv0kN = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVv6KF = list(VVv0kN)
 return VVv6KF, VVv0kN
def FFhwKI():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFO4RI(session, VVK81n):
 VVSwrc, VVEFvo, VVksqK, camCommand = FFpp39()
 if VVEFvo:
  runLog = False
  if   VVK81n == CCDAiB.VVdeoR : runLog = True
  elif VVK81n == CCDAiB.VV5OTB : runLog = True
  elif not VVksqK          : FF6QVr(session, message="SoftCam not started yet!")
  elif fileExists(VVksqK)        : runLog = True
  else             : FF6QVr(session, message="File not found !\n\n%s" % VVksqK)
  if runLog:
   session.open(boundFunction(CCDAiB, VVSwrc=VVSwrc, VVEFvo=VVEFvo, VVksqK=VVksqK, VVK81n=VVK81n))
 else:
  FF6QVr(session, message="No active OSCam/NCam found !", title="Live Log")
def FFpp39():
 VVSwrc = "/etc/tuxbox/config/"
 VVEFvo = None
 VVksqK  = None
 camCommand = FFgaUh("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVEFvo = "oscam"
 elif "ncam"  in camCommand : VVEFvo = "ncam"
 if VVEFvo:
  path = FFgaUh(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFExru(path)
  if pathExists(path):
   VVSwrc = path
  tFile = VVSwrc + VVEFvo + ".conf"
  tFile = FFgaUh("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVksqK = tFile
 return VVSwrc, VVEFvo, VVksqK, camCommand
def FFMoES(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFDiuF():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFtTMB():
 return FFDiuF().replace(" ", "_").replace("-", "").replace(":", "")
def FFUeKr(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFPgIK():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFUMM6(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCaJkM.VVzpN1(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCaJkM.VVwlum(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFARGV("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFtNnM(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFAEVv(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FF7g02():
 return int(FF0S1I("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFWGD4():
 global VVvTQP_TIME, VVu49L
 VVu49L  = int(FF7g02())
 VVvTQP_TIME = iTime()
def FFTk1l():
 elapsed = iTime() - VVvTQP_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FF7g02() - VVu49L
 FFaIxL(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFo08k(SELF, message, title=""):
 SELF.session.open(boundFunction(CC0lGJ, title=title, message=message, VVGF0H=True))
def FFuPDq(SELF, message, title="", VVNQut=VVKIxe, **kwargs):
 SELF.session.open(boundFunction(CC0lGJ, title=title, message=message, VVNQut=VVNQut, **kwargs))
def FFKFol(SELF, message, title="")  : FF6QVr(SELF.session, message, title)
def FFtist(SELF, path, title="") : FF6QVr(SELF.session, "File not found !\n\n%s" % path, title)
def FF50vC(SELF, path, title="") : FF6QVr(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFk6P3(SELF, title="")  : FF6QVr(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF6QVr(session, message, title="") : session.open(boundFunction(CCmHuw, title=title, message=message))
def FFXtIF(SELF, VVfbK6, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVfbK6, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVfbK6, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVfbK6, boundFunction(CCePpO, title=title, message=message, VVjNXP=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFKFol(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FF7adK(SELF, callBack_Yes, VVeMZz, callBack_No=None, title="", VVkpWv=False, VVWh6t=True):
 SELF.session.openWithCallback(boundFunction(FFOUmT, callBack_Yes, callBack_No)
        , boundFunction(CCRM51, title=title, VVeMZz=VVeMZz, VVWh6t=VVWh6t, VVkpWv=VVkpWv))
def FFOUmT(callBack_Yes, callBack_No, FF7adKed):
 if FF7adKed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFt82g(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFWczZ(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FF3By6(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVEquV = eTimer()
def FFWczZ(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFvfj3, SELF))
 fnc = boundFunction(FFvfj3, SELF)
 try:
  t = VVEquV.timeout.connect(fnc)
 except:
  VVEquV.callback.append(fnc)
 VVEquV.start(milliSeconds, 1)
def FFvfj3(SELF):
 VVEquV.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFaufo(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCjMsN, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCjMsN, **kwargs))
  FF3Ivr(win)
  return win
 except:
  return None
def FF0g9p(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CChu1f, **kwargs))
 FF3Ivr(win)
 return win
def FFLiV2(SELF, **kwargs):
 SELF.session.open(CCe5Io, **kwargs)
def FFHNI7(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFXr2J(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVgk1L, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FF9hWs(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFXr2J(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFhgHB():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFabqX(VVpwbP):
 screenSize  = FFhgHB()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVpwbP)
 return bodyFontSize
def FFycft(VVpwbP, extraSpace):
 font = gFont(VVgk1L, VVpwbP)
 VVCfMB = fontRenderClass.getInstance().getLineHeight(font) or (VVpwbP * 1.25)
 return int(VVCfMB + VVCfMB * extraSpace)
def FFAYOU(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVgk1L
def FFHZVI(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFhgHB()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVNWfO)
 bodyFontStr  = 'font="%s;%d"' % (VVgk1L, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFycft(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVgk1L, titleFontSize, alignLeftCenter)
 if winType == VVLE1I or winType == VVi7ZF:
  if winType == VVi7ZF : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVkSsZ:
  pass
 elif winType == VVvrt0:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFo08kL = b2Left2 + timeW + marginLeft
  FFo08kW = b2Left3 - marginLeft - FFo08kL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFo08kL  , b2Top, FFo08kW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00aa7777", "#00aa7777", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
 elif winType == VVmvSf:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVKKAP:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVGf9D:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VV1gxD:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVgk1L, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVgk1L, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVinsn:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFo08kH = int(bodyH * 0.5)
  inpTop = bodyTop + FFo08kH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFo08kH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVgk1L, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVgk1L, mapF, alignCenter)
 elif winType == VV5VmV:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVKwao:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVgk1L, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVbYEN:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVgk1L, fontH, alignCenter)
 elif winType == VVWGyt:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVgk1L, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVgk1L, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVgk1L, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVNGcB:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVqdo1 : align = alignLeftCenter
  elif winType == VVHoLH : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVHEzh:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVgLgu:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVHoLH:
    fontStr = 'font="%s;%d"' % (FFAYOU("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVpwbP = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVgk1L, VVpwbP, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVgk1L, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVgk1L, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVpeGc = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVgk1L, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVpeGc[i], VVgk1L, barFont, alignCenter)
   left += btnW + gap
 if winType == VVHoLH:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVpeGc = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVpeGc[i], VVgk1L, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVtP1e = []
  if VVGIJX:
   VVtP1e.append(("-- MY TEST --"    , "myTest"   ))
  VVtP1e.append(("  File Manager"     , "FileManager"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("  Services/Channels"    , "ChannelsTools" ))
  VVtP1e.append(("  IPTV"       , "IptvTools"  ))
  VVtP1e.append(("  PIcons"       , "PIconsTools"  ))
  VVtP1e.append(("  SoftCam"      , "SoftCam"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("  Plugins"      , "PluginsTools" ))
  VVtP1e.append(("  Terminal"      , "Terminal"  ))
  VVtP1e.append(("  Backup & Restore"    , "BackupRestore" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("  Date/Time"      , "Date_Time"  ))
  VVtP1e.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVtP1e)
  FF7MWH(self, VVtP1e=VVtP1e)
  FFGkKQ(self["keyRed"] , "Exit")
  FFGkKQ(self["keyGreen"] , "Settings")
  FFGkKQ(self["keyYellow"], "Dev. Info.")
  FFGkKQ(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VV9yoe       ,
   "yellow"  : self.VVoigf       ,
   "blue"   : self.VVcl7E       ,
   "info"   : self.VVcl7E       ,
   "next"   : self.VVCmO6       ,
   "menu"   : self.VVJxMm     ,
   "0"    : boundFunction(self.VVdVbn, 0) ,
   "1"    : boundFunction(self.VVLBbS, 1)   ,
   "2"    : boundFunction(self.VVLBbS, 2)   ,
   "3"    : boundFunction(self.VVLBbS, 3)   ,
   "4"    : boundFunction(self.VVLBbS, 4)   ,
   "5"    : boundFunction(self.VVLBbS, 5)   ,
   "6"    : boundFunction(self.VVLBbS, 6)   ,
   "7"    : boundFunction(self.VVLBbS, 7)   ,
   "8"    : boundFunction(self.VVLBbS, 8)   ,
   "9"    : boundFunction(self.VVLBbS, 9)
  })
  self.onShown.append(self.VVyQ2h)
  self.onClose.append(self.onExit)
  global VVNqXw, VVHke5
  VVNqXw = VVHke5 = False
 def VV8nYP(self):
  item = FF1WPP(self)
  self.VVLBbS(item)
 def VVLBbS(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVGHuP()
   elif item in ("FileManager"  , 1) : self.session.open(CC2SNv)
   elif item in ("ChannelsTools" , 2) : self.session.open(CC6jYr)
   elif item in ("IptvTools"  , 3) : self.session.open(CCaJkM)
   elif item in ("PIconsTools"  , 4) : self.VVdXA5()
   elif item in ("SoftCam"   , 5) : self.session.open(CC7JtZ)
   elif item in ("PluginsTools" , 6) : self.session.open(CC0daN)
   elif item in ("Terminal"  , 7) : self.session.open(CCw4xs)
   elif item in ("BackupRestore" , 8) : self.session.open(CCKlLt)
   elif item in ("Date_Time"  , 9) : self.session.open(CC4IMT)
   elif item in ("CheckInternet" , 10) : self.session.open(CCk1d5)
   else         : self.close()
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
  FFHNI7(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVcmc0)
  self["myTitle"].setText(title)
  VVWacB, VV2p1K, VVArXZ, VVu0DY, VVKq9z = FFnxpp()
  self.VVRqgW()
  if VVWacB or VV2p1K or VVArXZ or VVu0DY or VVKq9z:
   VVcFSN = lambda path, subj: "%s:\n%s\n\n" % (subj, FFMi1p(path, VVl05N)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVcFSN(VVWacB   , "Backup/Restore Path"    )
   txt += VVcFSN(VV2p1K  , "Created Package Files (IPK/DEB)" )
   txt += VVcFSN(VVArXZ  , "Download Packages (from feeds)" )
   txt += VVcFSN(VVu0DY , "Exported Tables"     )
   txt += VVcFSN(VVKq9z , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFuPDq(self, txt, title="Settings Paths")
  if (EASY_MODE or VVyMRU or VVGIJX):
   FFlSQr(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFt82g(self, "Welcome", 300)
  FFTTch(boundFunction(self.VVKg3J, title))
 def VVKg3J(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCWTU2.VVDPt6()
   if url:
    newWebVer = CCWTU2.VVw80Q(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFARGV("rm /tmp/ajpanel*"))
 def VVdVbn(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVNqXw
    VVNqXw = True
    FFlSQr(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVCmO6(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VVHke5
   VVHke5 = True
   FFlSQr(self["myTitle"], "#dd5588")
 def VVdXA5(self):
  found = False
  pPath = CCc7kl.VVGkn8()
  if pathExists(pPath):
   for fName, fType in CCc7kl.VV7nyP(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCc7kl)
  else:
   VVtP1e = []
   VVtP1e.append(("PIcons Manager" , "CCc7kl" ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(CCc7kl.VVLjez())
   VVtP1e.append(VV6Efe)
   VVtP1e += CCc7kl.VV2qmD()
   FF0g9p(self, self.VVaMNP, VVtP1e=VVtP1e)
 def VVaMNP(self, item=None):
  if item:
   if   item == "CCc7kl"   : self.session.open(CCc7kl)
   elif item == "VVs4Cg"  : CCc7kl.VVs4Cg(self)
   elif item == "VVrjEF"  : CCc7kl.VVrjEF(self)
   elif item == "findPiconBrokenSymLinks" : CCc7kl.VVvuEs(self, True)
   elif item == "FindAllBrokenSymLinks" : CCc7kl.VVvuEs(self, False)
 def VV9yoe(self):
  self.session.open(CCWTU2)
 def VVoigf(self):
  self.session.open(CCVKwG)
 def VVcl7E(self):
  changeLogFile = VVsT5j + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFOmkW(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFMi1p("\n%s\n%s\n%s" % (VVFR4v, line, VVFR4v), VVQy4t, VVkCrP)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFMi1p(line, VVRhh2, VVkCrP)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFuPDq(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVcmc0), VVpwbP=26)
 def VVJxMm(self):
  VVtP1e = []
  VVtP1e.append(("Title Colors"   , "title" ))
  VVtP1e.append(("Menu Area Colors"  , "body" ))
  VVtP1e.append(("Menu Pointer Colors" , "cursor" ))
  VVtP1e.append(("Bottom Bar Colors" , "bar"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Reset"    , "reset" ))
  FF0g9p(self, self.VVXtDE, VVtP1e=VVtP1e, width=500, title="Main Menu Colors")
 def VVXtDE(self, item=None):
  if item:
   if item == "reset":
    os.system(FFARGV("rm %s" % self.VVXu83()))
    self.close()
   else:
    tDict = self.VVnmtE()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVviKM, tDict, item), CCFJbF, defFG=fg, defBG=bg)
 def VVXu83(self):
  return VVic63 + "ajpanel_colors"
 def VVnmtE(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVXu83()
  if fileExists(p):
   txt = FF0FCE(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVviKM(self, tDict, item, fg, bg):
  if fg:
   self.VV1qud(item, fg)
   self.VVouw3(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVF0iQ(tDict)
 def VVF0iQ(self, tDict):
   p = self.VVXu83()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV1qud(self, item, fg):
  if   item == "title" : FFFxI3(self["myTitle"], fg)
  elif item == "body"  :
   FFFxI3(self["myMenu"], fg)
   FFFxI3(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFlSQr(self["myBar"], fg)
   FFFxI3(self["keyRed"], fg)
   FFFxI3(self["keyGreen"], fg)
   FFFxI3(self["keyYellow"], fg)
   FFFxI3(self["keyBlue"], fg)
 def VVouw3(self, item, bg):
  if   item == "title" : FFlSQr(self["myTitle"], bg)
  elif item == "body"  :
   FFlSQr(self["myMenu"], bg)
   FFlSQr(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFlSQr(self["myBar"], bg)
 def VVRqgW(self):
  tDict = self.VVnmtE()
  self.VVGTBI(tDict, "title")
  self.VVGTBI(tDict, "body")
  self.VVGTBI(tDict, "cursor")
  self.VVGTBI(tDict, "bar")
 def VVGTBI(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV1qud(name, fg)
  if bg: self.VVouw3(name, bg)
 def VVGHuP(self):
  pass
class CCVKwG(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVtP1e = []
  VVtP1e.append(("Settings File"        , "SettingsFile"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Box Info"          , "VVqhyD"    ))
  VVtP1e.append(("Tuners Info"         , "VVMoRv"   ))
  VVtP1e.append(("Python Version"        , "VVX13D"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Screen Size"         , "ScreenSize"    ))
  VVtP1e.append(("Locale"          , "Locale"     ))
  VVtP1e.append(("Processor"         , "Processor"    ))
  VVtP1e.append(("Operating System"        , "OperatingSystem"   ))
  VVtP1e.append(("Drivers"          , "drivers"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("System Users"         , "SystemUsers"    ))
  VVtP1e.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVtP1e.append(("Uptime"          , "Uptime"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Host Name"         , "HostName"    ))
  VVtP1e.append(("MAC Address"         , "MACAddress"    ))
  VVtP1e.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVtP1e.append(("Network Status"        , "NetworkStatus"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Disk Usage"         , "VVYE9j"    ))
  VVtP1e.append(("Mount Points"         , "MountPoints"    ))
  VVtP1e.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVtP1e.append(("USB Devices"         , "USB_Devices"    ))
  VVtP1e.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVtP1e.append(("Directory Size"        , "DirectorySize"   ))
  VVtP1e.append(("Memory"          , "Memory"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVtP1e.append(("Running Processes"       , "RunningProcesses"  ))
  VVtP1e.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF7MWH(self, VVtP1e=VVtP1e, title="Device Information")
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCOLoZ)
   elif item == "VVqhyD"    : self.VVqhyD()
   elif item == "VVMoRv"   : self.VVMoRv()
   elif item == "VVX13D"   : self.VVX13D()
   elif item == "ScreenSize"    : FFuPDq(self, "Width\t: %s\nHeight\t: %s" % (FFhgHB()[0], FFhgHB()[1]))
   elif item == "Locale"     : self.VVlO9A()
   elif item == "Processor"    : self.VVnwPA()
   elif item == "OperatingSystem"   : FFtERc(self, "uname -a"        )
   elif item == "drivers"     : self.VVP2SJ()
   elif item == "SystemUsers"    : FFtERc(self, "id"          )
   elif item == "LoggedInUsers"   : FFtERc(self, "who -a"         )
   elif item == "Uptime"     : FFtERc(self, "uptime"         )
   elif item == "HostName"     : FFtERc(self, "hostname"        )
   elif item == "MACAddress"    : self.VV5O5c()
   elif item == "NetworkConfiguration"  : FFtERc(self, "ifconfig %s %s" % (FFuvWX("HWaddr", VVlE7m), FFuvWX("addr:", VVIuu8)))
   elif item == "NetworkStatus"   : FFtERc(self, "netstat -tulpn"       )
   elif item == "VVYE9j"    : self.VVYE9j()
   elif item == "MountPoints"    : FFtERc(self, "mount %s" % (FFuvWX(" on ", VVIuu8)))
   elif item == "FileSystemTable"   : FFtERc(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFtERc(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFtERc(self, "blkid"         )
   elif item == "DirectorySize"   : FFtERc(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVm1JT="Reading size ...")
   elif item == "Memory"     : FFtERc(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVmVhn()
   elif item == "RunningProcesses"   : FFtERc(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFtERc(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVfeCf()
   else         : self.close()
 def VV5O5c(self):
  res = FF0S1I("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFuPDq(self, txt)
  else:
   FFtERc(self, "ip link")
 def VVEgCh(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFhQrI(cmd)
  return lines
 def VVoWcU(self, lines, headerRepl, widths, VVpYfQ):
  VVvFiF = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVvFiF.append(parts)
  if VVvFiF and len(header) == len(widths):
   VVvFiF.sort(key=lambda x: x[0].lower())
   FFaufo(self, None, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22, VVqI0Q=True)
   return True
  else:
   return False
 def VVYE9j(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVEgCh(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVpYfQ = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVoWcU(lines, headerRepl, widths, VVpYfQ)
  if not allOK:
   lines = FFhQrI(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFaJVe(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVDoEn:
     note = "\n%s" % FFMi1p("Green = Mounted Partitions", VVDoEn)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVIuu8
     elif line.endswith(mountList) : color = VVDoEn
     else       : color = VVRhh2
     txt += FFMi1p(line, color) + "\n"
    FFuPDq(self, txt + note)
   else:
    FFKFol(self, "Not data from system !")
 def VVmVhn(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVEgCh(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVpYfQ = (LEFT , CENTER, LEFT )
  allOK = self.VVoWcU(lines, headerRepl, widths, VVpYfQ)
  if not allOK:
   FFtERc(self, cmd)
 def VVlO9A(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFuPDq(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVP2SJ(self):
  cmd = FFlm1I(VV8Sak, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFtERc(self, cmd)
  else : FFk6P3(self)
 def VVnwPA(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFtERc(self, cmd)
 def VVfeCf(self):
  cmd = FFlm1I(VVfdyF, "| grep secondstage")
  if cmd : FFtERc(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFk6P3(self)
 def VVqhyD(self):
  c = VVDoEn
  VV7oZO = []
  VV7oZO.append((FFMi1p("Box Type"  , c), FFMi1p(self.VVQzEj("boxtype").upper(), c)))
  VV7oZO.append((FFMi1p("Board Version", c), FFMi1p(self.VVQzEj("board_revision") , c)))
  VV7oZO.append((FFMi1p("Chipset"  , c), FFMi1p(self.VVQzEj("chipset")  , c)))
  VV7oZO.append((FFMi1p("S/N"   , c), FFMi1p(self.VVQzEj("sn")    , c)))
  VV7oZO.append((FFMi1p("Version"  , c), FFMi1p(self.VVQzEj("version")  , c)))
  VVUzP6   = []
  VVWC8O = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVWC8O = SystemInfo[key]
     else:
      VVUzP6.append((FFMi1p(str(key), VVVNGK), FFMi1p(str(SystemInfo[key]), VVVNGK)))
  except:
   pass
  if VVWC8O:
   VVTiU2 = self.VVlHHq(VVWC8O)
   if VVTiU2:
    VVTiU2.sort(key=lambda x: x[0].lower())
    VV7oZO += VVTiU2
  if VVUzP6:
   VVUzP6.sort(key=lambda x: x[0].lower())
   VV7oZO += VVUzP6
  if VV7oZO:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFaufo(self, None, header=header, VV7oZO=VV7oZO, VVAF36=widths, VVpwbP=22, VVqI0Q=True)
  else:
   FFuPDq(self, "Could not read info!")
 def VVQzEj(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFOmkW(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVlHHq(self, mbDict):
  try:
   mbList = list(mbDict)
   VV7oZO = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV7oZO.append((FFMi1p(subject, VVIuu8), FFMi1p(value, VVIuu8)))
  except:
   pass
  return VV7oZO
 def VVMoRv(self):
  txt = self.VVQzIt("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVQzIt("/proc/bus/nim_sockets")
  if not txt: txt = self.VVhA3x()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFuPDq(self, txt)
 def VVhA3x(self):
  txt = ""
  VVcFSN = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVcFSN("Slot Name" , slot.getSlotName())
     txt += FFMi1p(slotName, VVIuu8)
     txt += VVcFSN("Description"  , slot.getFullDescription())
     txt += VVcFSN("Frontend ID"  , slot.frontend_id)
     txt += VVcFSN("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVQzIt(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFOmkW(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFMi1p(line, VVIuu8)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVX13D(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFuPDq(self, txt)
class CCOLoZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVtP1e = []
  VVtP1e.append(("Settings (All)"   , "Settings_All"   ))
  VVtP1e.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVtP1e.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVtP1e.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVtP1e.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVtP1e.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVtP1e.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVtP1e.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FF7MWH(self, VVtP1e=VVtP1e)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFtERc(self, cmd                )
   elif item == "Settings_HotKeys"   : FFtERc(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFtERc(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFtERc(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFtERc(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFtERc(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFtERc(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFtERc(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC7JtZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVSwrc, VVEFvo, VVksqK, camCommand = FFpp39()
  self.VVEFvo = VVEFvo
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVtP1e = []
  VVtP1e.append(("OSCam Files"        , "OSCamFiles"  ))
  VVtP1e.append(("NCam Files"        , "NCamFiles"  ))
  VVtP1e.append(("CCcam Files"        , "CCcamFiles"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVtP1e.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVtP1e.append(VV6Efe)
  if VVEFvo:
   if   "oscam" in VVEFvo : camName = "OSCam"
   elif "ncam"  in VVEFvo : camName = "NCam"
   VVtP1e.append((camName + " Info."      , "camInfo"   ))
   VVtP1e.append((camName + " Live Status"    , "camLiveStatus" ))
   VVtP1e.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVtP1e.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVtP1e.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FF7MWH(self, VVtP1e=VVtP1e)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCHA4o, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCHA4o, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCHA4o, "cccam"))
   elif item == "OSCamReaders"  : self.VVR1IJ("os")
   elif item == "NSCamReaders"  : self.VVR1IJ("n")
   elif item == "camInfo"   : FF2OEY(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFO4RI(self.session, CCDAiB.VVdeoR)
   elif item == "camLiveReaders" : FFO4RI(self.session, CCDAiB.VV5OTB)
   elif item == "camLiveLog"  : FFO4RI(self.session, CCDAiB.VVPju6)
   else       : self.close()
 def VVR1IJ(self, camPrefix):
  VVvFiF = self.VVBHBb(camPrefix)
  if VVvFiF:
   VVvFiF.sort(key=lambda x: int(x[0]))
   if self.VVEFvo and self.VVEFvo.startswith(camPrefix):
    VVredj = ("Toggle State", self.VVY3V7, [camPrefix], "Changing State ...")
   else:
    VVredj = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVpYfQ  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFaufo(self, None, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22, VVredj=VVredj, VV34E6=True)
 def VVBHBb(self, camPrefix):
  readersFile = self.VVSwrc + camPrefix + "cam.server"
  VVvFiF = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFOmkW(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVvFiF.append((str(len(VVvFiF) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVvFiF:
    FFKFol(self, "No readers found !")
  else:
   FFtist(self, readersFile)
  return VVvFiF
 def VVY3V7(self, VVrVVi, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVSwrc, camPrefix)
  readerState  = VVrVVi.VVa9s4(1)
  readerLabel  = VVrVVi.VVa9s4(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC7JtZ.VVmpVN(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVrVVi.VViXU5()
    FFKFol(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVvFiF = self.VVBHBb(camPrefix)
   if VVvFiF:
    VVrVVi.VV8dsB(VVvFiF)
 @staticmethod
 def VVmpVN(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFOmkW(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFKFol(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFKFol(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFtist(SELF, confFile)
   return None
  if not iRequest:
   FFKFol(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFKFol(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFKFol(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCHA4o(Screen):
 def __init__(self, VVVeV1, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVSwrc, VVEFvo, VVksqK, camCommand = FFpp39()
  if   VVVeV1 == "ncam" : self.prefix = "n"
  elif VVVeV1 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVtP1e = []
  if self.prefix == "":
   VVtP1e.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVtP1e.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVtP1e.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVtP1e.append(("constant.cw"         , "x_constant_cw" ))
   VVtP1e.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVtP1e.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVtP1e.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVtP1e.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVtP1e.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVtP1e.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVtP1e.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVtP1e.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVtP1e.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVtP1e.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVtP1e.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF7MWH(self, VVtP1e=VVtP1e)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFYaEL(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFYaEL(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFYaEL(self, self.VVSwrc + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFYaEL(self, self.VVSwrc + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVVi01("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVVi01("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVVi01("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVVi01("cam.provid"        )
   elif item == "x_cam_server"  : self.VVVi01("cam.server"        )
   elif item == "x_cam_services" : self.VVVi01("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVVi01("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVVi01("cam.user"        )
   elif item == "x_VVFR4v"   : pass
   elif item == "x_SoftCam_Key" : FFYaEL(self, self.VVSwrc + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFYaEL(self, self.VVSwrc + "CCcam.cfg"    )
   elif item == "x_VVFR4v"   : pass
   elif item == "x_cam_log"  : FFYaEL(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFYaEL(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFYaEL(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVVi01(self, fileName):
  FFYaEL(self, self.VVSwrc + self.prefix + fileName)
class CCDAiB(Screen):
 VVdeoR  = 0
 VV5OTB = 1
 VVPju6 = 2
 def __init__(self, session, VVSwrc="", VVEFvo="", VVksqK="", VVK81n=VVdeoR):
  self.skin, self.skinParam = FFHZVI(VVHoLH, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVksqK   = VVksqK
  self.VVK81n  = VVK81n
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVSwrc + VVEFvo + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVEFvo : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVSwrc, self.camPrefix)
  if self.VVK81n == self.VVdeoR:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVK81n == self.VV5OTB:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF7MWH(self, self.Title, addScrollLabel=True)
  FFGkKQ(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV2RT1
  self.onShown.append(self.VVyQ2h)
  self.onClose.append(self.onExit)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self["myLabel"].VVVSbd(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFHNI7(self)
  self.VV2RT1()
 def onExit(self):
  self.timer.stop()
 def VVd5B0(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCzcC)
  except:
   self.timer.callback.append(self.VVCzcC)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFt82g(self, "Started", 1000)
 def VV04Dx(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVCzcC)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFt82g(self, "Stopped", 1000)
 def VV2RT1(self):
  if self.timerRunning:
   self.VV04Dx()
  else:
   self.VVd5B0()
   if self.VVK81n == self.VVdeoR or self.VVK81n == self.VV5OTB:
    if self.VVK81n == self.VVdeoR : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC7JtZ.VVmpVN(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFTTch(self.VVCCur)
    else:
     self.close()
   else:
    self.VVvdu9()
 def VVCzcC(self):
  if self.timerRunning:
   if   self.VVK81n == self.VVdeoR : self.VVMlhj()
   elif self.VVK81n == self.VV5OTB : self.VVMlhj()
   else            : self.VVvdu9()
 def VVvdu9(self):
  if fileExists(self.VVksqK):
   fTime = FFMoES(os.path.getmtime(self.VVksqK))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV6ruh(), VVNQut=VV1ZNL)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVksqK)
 def VVCCur(self):
  self.VVMlhj()
 def VVMlhj(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFMi1p("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVQy4t))
   self.camWebIfErrorFound = True
   self.VV04Dx()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVK81n == self.VVdeoR : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFMi1p("Error while parsing data elements !\n\nError = %s" % str(e), VVl05N)
   self.camWebIfErrorFound = True
   self.VV04Dx()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVjxlb(root)
  self["myLabel"].setText(txt, VVNQut=VV1ZNL)
  self["myBar"].setText("Last Update : %s" % FFDiuF())
 def VVjxlb(self, rootElement):
  def VVcFSN(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVK81n == self.VVdeoR:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFMi1p(status, VVDoEn)
    else          : status = FFMi1p(status, VVl05N)
    txt += VVFR4v + "\n"
    txt += VVcFSN("Name"  , name)
    txt += VVcFSN("Description" , desc)
    txt += VVcFSN("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVcFSN("Protocol" , protocol)
    txt += VVcFSN("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFMi1p("Yes", VVDoEn)
    else    : enabTxt = FFMi1p("No", VVl05N)
    txt += VVFR4v + "\n"
    txt += VVcFSN("Label"  , label)
    txt += VVcFSN("Protocol" , protocol)
    txt += VVcFSN("Enabled" , enabTxt)
  return txt
 def VV6ruh(self):
  wordsDict = self.VVssKo()
  color = [ VVIuu8, VVlE7m, VVDoEn, VVl05N, VVVNGK, VVSda0]
  lines = FFhQrI("tail -n %d %s" % (100, self.VVksqK))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVQy4t + line[:19] + VVRhh2 + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVkCrP + line[ndx + 3:] + VVRhh2
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVIuu8 + line[ndx + 8 : ndx1 + 4] + VVRhh2 + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVRhh2)
   elif line.startswith("----") or ">>" in line:
    line = FFMi1p(line, VVIuu8)
   txt += line + "\n"
  return txt
 def VVssKo(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFOmkW(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCKlLt(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVtP1e = []
  VVtP1e.append(("Backup Channels"        , "VVehBr"   ))
  VVtP1e.append(("Restore Channels"        , "Restore_Channels"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Backup SoftCAM Files"       , "VVy3Eb" ))
  VVtP1e.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVtP1e.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVtP1e.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Backup Network Settings"      , "VV4mDS"   ))
  VVtP1e.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVHke5:
   VVtP1e.append(VV6Efe)
   VVtP1e.append((VVQy4t + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVjD8q"   ))
   VVtP1e.append((VVDoEn + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVtP1e.append((VVDoEn + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVtP1e.append((VVVNGK + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVtP1e.append((VVVNGK + "Decode %s Crash Report"   % PLUGIN_NAME , "VVNI86" ))
  FF7MWH(self, VVtP1e=VVtP1e)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVehBr"    : self.VVehBr()
   elif item == "Restore_Channels"    : self.VVlqkg("channels_backup*.tar.gz", self.VVKchj)
   elif item == "VVy3Eb"   : self.VVy3Eb()
   elif item == "Restore_SoftCAM_Files"  : self.VVlqkg("softcam_backup*.tar.gz", self.VVusfk)
   elif item == "Backup_TunerDiSEqC"   : self.VVUgEr("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVlqkg("tuner_backup*.backup", boundFunction(self.VVZFMx, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVUgEr("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVlqkg("hotkey_fhdg17_backup*.backup", boundFunction(self.VVZFMx, "misc"))
   elif item == "VV4mDS"    : self.VV4mDS()
   elif item == "Restore_Network"    : self.VVlqkg("network_backup*.tar.gz", self.VV3Vn4)
   elif item == "VVjD8q"     : FF7adK(self, boundFunction(FFCkhd, self, boundFunction(CCKlLt.VVjD8q, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVwk33(False)
   elif item == "createMyDeb"     : self.VVwk33(True)
   elif item == "createMyTar"     : self.VVLHm6()
   elif item == "VVNI86"   : self.VVNI86()
 @staticmethod
 def VVjD8q(SELF):
  OBF_Path = VVi2AZ + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVi2AZ, VVcmc0, VVS77d)
   if err : FFKFol(SELF, err)
   else : FFuPDq(SELF, txt)
  else:
   FFtist(SELF, OBF_Path)
 def VVwk33(self, VVRtV7):
  OBF_Path = VVi2AZ + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFKFol(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVi2AZ)
  os.system("mv -f %s %s" % (VVi2AZ + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVi2AZ + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVi2AZ + "plugin.py"))
  self.session.openWithCallback(self.VVwk331, boundFunction(CCRfrs, path=VVi2AZ, VVRtV7=VVRtV7))
 def VVwk331(self):
  os.system("mv -f %s %s" % (VVi2AZ + "OBF/main.py"  , VVi2AZ))
  os.system("mv -f %s %s" % (VVi2AZ + "OBF/plugin.py" , VVi2AZ))
 def VVNI86(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFKFol(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFKFol(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVoQxy("%s*.list" % path)
  if err:
   FFtist(self, path + "*.list")
   return
  srcF, err = self.VVoQxy("%s*main_final.py" % path)
  if err:
   FFtist(self, path + "*.final.py")
   return
  VV7oZO = []
  for f in files:
   f = os.path.basename(f)
   VV7oZO.append((f, f))
  FF0g9p(self, boundFunction(self.VV0zoo, path, codF, srcF), VVtP1e=VV7oZO)
 def VV0zoo(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFtist(self, logF)
   else     : FFCkhd(self, boundFunction(self.VVUMhV, logF, codF, srcF))
 def VVUMhV(self, logF, codF, srcF):
  lst  = []
  lines = FFOmkW(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFKFol(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVBJrk(lst, logF, newLogF)
  totSrc  = self.VVBJrk(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFuPDq(self, txt)
 def VVoQxy(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVBJrk(self, lst, f1, f2):
  txt = FF0FCE(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVLHm6(self):
  VV7oZO = []
  VV7oZO.append("%s%s" % (VVi2AZ, "*.py"))
  VV7oZO.append("%s%s" % (VVi2AZ, "*.png"))
  VV7oZO.append("%s%s" % (VVi2AZ, "*.xml"))
  VV7oZO.append("%s"  % (VVsT5j))
  FFeLWZ(self, VV7oZO, "%s_%s" % (PLUGIN_NAME, VVcmc0), addTimeStamp=False)
 def VVehBr(self):
  path1 = VVPZfu
  path2 = "/etc/tuxbox/"
  VV7oZO = []
  VV7oZO.append("%s%s" % (path1, "*.tv"))
  VV7oZO.append("%s%s" % (path1, "*.radio"))
  VV7oZO.append("%s%s" % (path1, "*list"))
  VV7oZO.append("%s%s" % (path1, "lamedb*"))
  VV7oZO.append("%s%s" % (path2, "*.xml"))
  FFeLWZ(self, VV7oZO, "channels_backup", addTimeStamp=True)
 def VVy3Eb(self):
  VV7oZO = []
  VV7oZO.append("/etc/tuxbox/config/")
  VV7oZO.append("/usr/keys/")
  VV7oZO.append("/usr/scam/")
  VV7oZO.append("/etc/CCcam.cfg")
  FFeLWZ(self, VV7oZO, "softcam_backup", addTimeStamp=True)
 def VV4mDS(self):
  VV7oZO = []
  VV7oZO.append("/etc/hostname")
  VV7oZO.append("/etc/default_gw")
  VV7oZO.append("/etc/resolv.conf")
  VV7oZO.append("/etc/wpa_supplicant*.conf")
  VV7oZO.append("/etc/network/interfaces")
  VV7oZO.append("/etc/enigma2/nameserversdns.conf")
  FFeLWZ(self, VV7oZO, "network_backup", addTimeStamp=True)
 def VVKchj(self, fileName):
  if fileName:
   FF7adK(self, boundFunction(self.VVHgnG, fileName), "Overwrite current channels ?")
 def VVHgnG(self, fileName):
  path = "%s%s" % (VVic63, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CC6jYr.VVtY5p()
   lamedb5File, diabled5File = CC6jYr.VVfToQ()
   cmd = ""
   cmd += FFARGV("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFARGV("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFspal()
   if res == 0 : FFo08k(self, "Channels Restored.")
   else  : FFKFol(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFtist(self, path)
 def VVusfk(self, fileName):
  if fileName:
   FF7adK(self, boundFunction(self.VVYDlS, fileName), "Overwrite SoftCAM files ?")
 def VVYDlS(self, fileName):
  fileName = "%s%s" % (VVic63, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVFR4v
   note = "You may need to restart your SoftCAM."
   FFsbrK(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFuvWX(note, VVIuu8), sep))
  else:
   FFtist(self, fileName)
 def VV3Vn4(self, fileName):
  if fileName:
   FF7adK(self, boundFunction(self.VVGXhm, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVGXhm(self, fileName):
  fileName = "%s%s" % (VVic63, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFxQD8(self,  cmd)
  else:
   FFtist(self, fileName)
 def VVlqkg(self, pattern, callBackFunction, isTuner=False):
  title = FFqA9R()
  if pathExists(VVic63):
   myFiles = iGlob("%s%s" % (VVic63, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV7oZO = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV7oZO.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VV0Jrh = ("Sat. List", self.VVKp7T)
    else  : VV0Jrh = None
    FF0g9p(self, callBackFunction, title=title, VVtP1e=VV7oZO, VV0Jrh=VV0Jrh)
   else:
    FFKFol(self, "No files found in:\n\n%s" % VVic63, title)
  else:
   FFKFol(self, "Path not found:\n\n%s" % VVic63, title)
 def VVUgEr(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCww76()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVF9q0, filePrefix))
 def VVF9q0(self, filePrefix, result, retval):
  title = FFqA9R()
  if pathExists(VVic63):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFKFol(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVic63, filePrefix, FFtTMB())
    try:
     VV7oZO = str(result.strip()).split()
     if VV7oZO:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV7oZO:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVFR4v, FFMi1p(fName, VVIuu8), VVFR4v)
       FFuPDq(self, txt, title=title, VVNQut=VV1ZNL)
      else:
       FFKFol(self, "File creation failed!", title)
     else:
      FFKFol(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFARGV("rm %s" % fName))
     FFKFol(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFARGV("rm %s" % fName))
     FFKFol(self, "Error while writing file.")
  else:
   FFKFol(self, "Path not found:\n\n%s" % VVic63, title)
 def VVZFMx(self, mode, path):
  if path:
   path = "%s%s" % (VVic63, path)
   if fileExists(path):
    lines = FFOmkW(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FF7adK(self, boundFunction(self.VVxeeL, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF50vC(self, path, title=FFqA9R())
   else:
    FFtist(self, path)
 def VVxeeL(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VV4uLj = []
  VV4uLj.append("echo -e 'Reading current settings ...'")
  VV4uLj.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VV4uLj.append("echo -e 'Preparing new settings ...'")
  VV4uLj.append(settingsLines)
  VV4uLj.append("echo -e 'Applying new settings ...'")
  VV4uLj.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FF3Nmm(self, VV4uLj)
 def VVKp7T(self, VVgdWRObj, path):
  if not path:
   return
  path = VVic63 + path
  if not fileExists(path):
   FFtist(self, path)
   return
  txt = FF0FCE(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV7oZO  = []
   for item in satList:
    VV7oZO.append("%s\t%s" % (item[0], FFFLQ6(item[1])))
   FFuPDq(self, VV7oZO, title="  Satellites List")
  else:
   FFKFol(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC0daN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVtP1e = []
  VVtP1e.append(("Plugins Browser List"       , "VVwmP4"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVtP1e.append(("Remove Packages (show all)"     , "VVSRWtsAll"   ))
  VVtP1e.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Update List of Available Packages"   , "VVC3NS"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Packaging Tool"        , "VVrwSa"    ))
  VVtP1e.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF7MWH(self, VVtP1e=VVtP1e)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVwmP4"   : self.VVwmP4()
   elif item == "pluginsDirList"    : self.VVkxII()
   elif item == "downloadInstallPackages"  : FFCkhd(self, boundFunction(self.VVgu8x, 0, ""))
   elif item == "VVSRWtsAll"   : FFCkhd(self, boundFunction(self.VVgu8x, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFCkhd(self, boundFunction(self.VVgu8x, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVC3NS"   : self.VVC3NS()
   elif item == "VVrwSa"    : self.VVrwSa()
   elif item == "packagesFeeds"    : self.VVLPmU()
   else          : self.close()
 def VVkxII(self):
  extDirs  = FFZkan(VVsNEX)
  sysDirs  = FFZkan(VVu6LP)
  VV7oZO  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV7oZO.append((item, VVsNEX + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV7oZO.append((item, VVu6LP + item))
  if VV7oZO:
   VV7oZO = sorted(VV7oZO, key=lambda x: x[0].lower())
   VVB4oX = ("Package Info.", self.VVTtrg, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFaufo(self, None, header=header, VV7oZO=VV7oZO, VVAF36=widths, VVpwbP=28, VVB4oX=VVB4oX)
  else:
   FFKFol(self, "Nothing found!")
 def VVTtrg(self, VVrVVi, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVsNEX) : loc = "extensions"
  elif path.startswith(VVu6LP) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV040l(package)
  else:
   FFKFol(self, "No info!")
 def VVLPmU(self):
  pkg = FFh9Bt()
  if pkg : FFtERc(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFk6P3(self)
 def VVwmP4(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVcFSN(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVFR4v + "\n"
    txt += VVcFSN("Number"   , str(c))
    txt += VVcFSN("Name"   , FFMi1p(str(p.name), VVIuu8))
    txt += VVcFSN("Path"  , p.path  )
    txt += VVcFSN("Description" , p.description )
    txt += VVcFSN("Icon"  , p.iconstr  )
    txt += VVcFSN("Wakeup Fnc" , p.wakeupfnc )
    txt += VVcFSN("NeedsRestart", p.needsRestart)
    txt += VVcFSN("Internal" , p.internal )
    txt += VVcFSN("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFuPDq(self, txt)
 def VVC3NS(self):
  cmd = FFlm1I(VVz50d, "")
  if cmd : FFxQD8(self, cmd, checkNetAccess=True)
  else : FFk6P3(self)
 def VVrwSa(self):
  pkg = FFh9Bt()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFo08k(self, txt)
 def VVgu8x(self, mode, grep, VVrVVi=None, title=""):
  if   mode == 0: cmd = FFlm1I(VVfdyF    , grep)
  elif mode == 1: cmd = FFlm1I(VV8Sak , grep)
  elif mode == 2: cmd = FFlm1I(VV8Sak , grep)
  if not cmd:
   FFk6P3(self)
   return
  VVvFiF = FFhQrI(cmd)
  if not VVvFiF:
   if VVrVVi: VVrVVi.VViXU5()
   FFKFol(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV7oZO  = []
  for item in VVvFiF:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV7oZO.append((name, package, version))
  if mode > 0:
   extensions = FFhQrI("ls %s -l | grep '^d' | awk '{print $9}'" % VVsNEX)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV7oZO:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV7oZO.append((name, VVsNEX + item, "-"))
   systemPlugins = FFhQrI("ls %s -l | grep '^d' | awk '{print $9}'" % VVu6LP)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV7oZO:
      if item.lower() == row[0].lower():
       break
     else:
      VV7oZO.append((item, VVu6LP + item, "-"))
  if not VV7oZO:
   FFKFol(self, "No packages found!")
   return
  if VVrVVi:
   VV7oZO.sort(key=lambda x: x[0].lower())
   VVrVVi.VV8dsB(VV7oZO, title)
  else:
   widths = (20, 50, 30)
   VVredj = None
   VV0bqY = None
   if mode == 0:
    VVzi3l = ("Install" , self.VV5jl5   , [])
    VVredj = ("Download" , self.VVWKkV   , [])
    VV0bqY = ("Filter"  , self.VVxH44 , [])
   elif mode == 1:
    VVzi3l = ("Uninstall", self.VVSRWt, [])
   elif mode == 2:
    VVzi3l = ("Uninstall", self.VVSRWt, [])
    widths= (18, 57, 25)
   VV7oZO = sorted(VV7oZO, key=lambda x: x[0].lower())
   VVB4oX = ("Package Info.", self.VV898N, [])
   header   = ("Name" ,"Package" , "Version" )
   FFaufo(self, None, header=header, VV7oZO=VV7oZO, VVAF36=widths, VVpwbP=24, VVzi3l=VVzi3l, VVredj=VVredj, VVB4oX=VVB4oX, VV0bqY=VV0bqY, VVi9D1=self.lastSelectedRow
     , VVOM9K="#22110011", VVpOBz="#22191111", VVpeGc="#22191111", VVrGdv="#00003030", VVmKuh="#00333333")
 def VV898N(self, VVrVVi, title, txt, colList):
  package = colList[1]
  self.VV040l(package)
 def VVxH44(self, VVrVVi, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVtP1e = []
  VVtP1e.append(("All Packages", "all"))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVtP1e.append(VV6Efe)
  for word in words:
   VVtP1e.append((word, word))
  FF0g9p(self, boundFunction(self.VVotkc, VVrVVi), VVtP1e=VVtP1e, title="Select Filter")
 def VVotkc(self, VVrVVi, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFCkhd(VVrVVi, boundFunction(self.VVgu8x, 0, grep, VVrVVi, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVSRWt(self, VVrVVi, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVsNEX, VVu6LP)):
   FF7adK(self, boundFunction(self.VVHO7Z, VVrVVi, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVtP1e = []
   VVtP1e.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVtP1e.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVtP1e.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF0g9p(self, boundFunction(self.VVhvMQ, VVrVVi, package), VVtP1e=VVtP1e)
 def VVHO7Z(self, VVrVVi, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVvjJi)
  FFxQD8(self, cmd, VVGvDX=boundFunction(self.VVyLiz, VVrVVi))
 def VVhvMQ(self, VVrVVi, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVBnTk
   elif item == "remove_ForceRemove"  : cmdOpt = VVd6n8
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVkxGy
   FF7adK(self, boundFunction(self.VV5ZPl, VVrVVi, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV5ZPl(self, VVrVVi, package, cmdOpt):
  self.lastSelectedRow = VVrVVi.VVMLzp()
  cmd = FFzJLp(cmdOpt, package)
  if cmd : FFxQD8(self, cmd, VVGvDX=boundFunction(self.VVyLiz, VVrVVi))
  else : FFk6P3(self)
 def VVyLiz(self, VVrVVi):
  VVrVVi.cancel()
  FFhwKI()
 def VV5jl5(self, VVrVVi, title, txt, colList):
  package  = colList[1]
  VVtP1e = []
  VVtP1e.append(("Install Package"         , "install_CheckVersion" ))
  VVtP1e.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVtP1e.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVtP1e.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF0g9p(self, boundFunction(self.VVTMHi, package), VVtP1e=VVtP1e)
 def VVTMHi(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVOWgY
   elif item == "install_ForceReinstall" : cmdOpt = VVc7ue
   elif item == "install_ForceDowngrade" : cmdOpt = VVla2Z
   elif item == "install_IgnoreDepends" : cmdOpt = VVvnCM
   FF7adK(self, boundFunction(self.VV4zGe, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV4zGe(self, package, cmdOpt):
  cmd = FFzJLp(cmdOpt, package)
  if cmd : FFxQD8(self, cmd, VVGvDX=FFhwKI, checkNetAccess=True)
  else : FFk6P3(self)
 def VVWKkV(self, VVrVVi, title, txt, colList):
  package  = colList[1]
  FF7adK(self, boundFunction(self.VVr1OG, package), "Download Package ?\n\n%s" % package)
 def VVr1OG(self, package):
  if FFLVNL():
   cmd = FFzJLp(VV5qEA, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFuvWX(success, VVDoEn))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFuvWX(fail, VVl05N))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFxQD8(self, cmd, VVjXYr=[VVl05N, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFk6P3(self)
  else:
   FFKFol(self, "No internet connection !")
 def VV040l(self, package):
  infoCmd  = FFzJLp(VVCSXC, package)
  filesCmd = FFzJLp(VVFCPa, package)
  listInstCmd = FFlm1I(VV8Sak, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFoPGL(VVIuu8)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFuvWX(notInst, VVQy4t))
   cmd += "else "
   cmd +=   FFi1ok("System Info", VVIuu8)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFi1ok("Related Files", VVIuu8)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFPyAy(self, cmd)
  else:
   FFk6P3(self)
class CC6jYr(Screen):
 VVMMWs  = 0
 VVYjrM = 1
 VVEaHj  = 2
 VVqO9A  = 3
 VVFrLC = 4
 VVByhd = 5
 VVQvFr = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV6rgC = None
  self.lastfilterUsed  = None
  VVtP1e = self.VVahLd()
  FF7MWH(self, VVtP1e=VVtP1e, title="Services/Channels")
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self["myMenu"].setList(self.VVahLd())
  FFjk8P(self["myMenu"])
  FF9hWs(self)
 def VVahLd(self):
  VVtP1e = []
  VVtP1e.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVtP1e.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVtP1e.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVtP1e.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVtP1e.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVtP1e.append(("Services with PIcons for the System"  , "VV4IUi"     ))
  VVtP1e.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVtP1e.append(VV6Efe)
  lamedbFile, disabledFile = CC6jYr.VVtY5p()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVtP1e.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVtP1e.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVtP1e.append(("Reset Parental Control Settings"   , "VVYHRZ"    ))
  VVtP1e.append(("Delete Channels with no names"   , "VVx3dd"    ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Reload Channels and Bouquets"    , "VV4Fie"      ))
  return VVtP1e
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFOlVP(self)
   elif item == "currentServiceInfo"     : FFLiV2(self, fncMode=CCe5Io.VVv4jH)
   elif item == "TranspondersStats"     : FFCkhd(self, self.VVMJ5a     )
   elif item == "lameDB_allChannels_with_refCode"  : FFCkhd(self, self.VVLpsa )
   elif item == "lameDB_allChannels_with_tranaponder" : FFCkhd(self, self.VVWolw)
   elif item == "lameDB_allChannels_with_details"  : FFCkhd(self, self.VV4DKU )
   elif item == "parentalControlChannels"    : FFCkhd(self, self.VVEYfb   )
   elif item == "showHiddenChannels"     : FFCkhd(self, self.VVDnm9     )
   elif item == "VV4IUi"     : FFCkhd(self, self.VV3x0i     )
   elif item == "servicesWithMissingPIcons"   : FFCkhd(self, self.VV0Lod   )
   elif item == "enableHiddenChannels"     : self.VVURYO(True)
   elif item == "disableHiddenChannels"    : self.VVURYO(False)
   elif item == "VVYHRZ"    : FF7adK(self, self.VVYHRZ, "Reset and Restart ?" )
   elif item == "VVx3dd"    : FFCkhd(self, self.VVx3dd)
   elif item == "VV4Fie"      : FFCkhd(self, boundFunction(CC6jYr.VV4Fie, self))
   else            : self.close()
 @staticmethod
 def VV4Fie(SELF):
  FFspal()
  FFo08k(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVLpsa(self):
  self.VV6rgC = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZqjv(self)
  VVvFiF = CC6jYr.VVaFY4(self, self.VVMMWs)
  if VVvFiF:
   VVvFiF.sort(key=lambda x: x[0].lower())
   VVWoa9  = ("Zap"   , self.VVzYJE     , [])
   VVRzGo = (""    , self.VVPbtb   , [])
   VVB4oX = ("Options"  , self.VVyT4x , [])
   VVredj = ("Current Service", self.VVenLa , [])
   VV0bqY = ("Filter"   , self.VVR86A  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVpYfQ  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFaufo(self, None, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVredj=VVredj, VVB4oX=VVB4oX, VV0bqY=VV0bqY)
 def VVWolw(self):
  self.VV6rgC = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZqjv(self)
  VVvFiF = CC6jYr.VVaFY4(self, self.VVYjrM)
  if VVvFiF:
   VVvFiF.sort(key=lambda x: x[0].lower())
   VVWoa9  = ("Zap"   , self.VVzYJE      , [])
   VVRzGo = (""    , self.VVPbtb    , [])
   VVredj = ("Current Service", self.VVenLa  , [])
   VVB4oX = ("Options"  , self.VV6UHV , [])
   VV0bqY = ("Filter"   , self.VVPXjc  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVpYfQ  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFaufo(self, None, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVredj=VVredj, VVB4oX=VVB4oX, VV0bqY=VV0bqY)
 def VVyT4x(self, VVrVVi, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CChZFz(self, VVrVVi, 3)
  mSel.VVrQwK(servName, refCode, pcState, hidState)
 def VV6UHV(self, VVrVVi, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CChZFz(self, VVrVVi, 3)
  mSel.VVzCqc(servName, refCode)
 def VVWBQ4(self, VVrVVi, refCode, isAddToBlackList):
  self.VV6rgC = None
  self.lastfilterUsed  = None
  VVrVVi.VV0lPI("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFCkhd(self, boundFunction(self.VV2RmA, VVrVVi, refCode))
  else:
   FFtist(self, path)
 def VVy7mj(self, VVrVVi, refCode, isHide):
  self.VV6rgC = None
  self.lastfilterUsed  = None
  VVrVVi.VV0lPI("Changing state ...")
  if FFohJ3(refCode):
   ret = FF0QjM(refCode, isHide)
   if ret : FFCkhd(self, boundFunction(self.VV2RmA, VVrVVi, refCode))
   else : FFKFol(self, "Cannot Hide/Unhide this channel.")
  else:
   FFKFol(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VV2RmA(self, VVrVVi, refCode):
  VVvFiF = CC6jYr.VVaFY4(self, self.VVMMWs, VV49RU=[3, [refCode], False])
  done = False
  if VVvFiF:
   data = VVvFiF[0]
   if data[3] == refCode:
    done = VVrVVi.VVfBGF(data)
  if not done:
   self.VVCJUg(VVrVVi, VVrVVi.VVtpWC(), self.VVMMWs)
  VVrVVi.VViXU5()
 def VVR86A(self, VVrVVi, title, txt, colList):
  self.filterObj.VVDBI6(1, VVrVVi, 2, boundFunction(self.VVKN4U, VVrVVi))
 def VVKN4U(self, VVrVVi, item):
  self.VV7AJy(VVrVVi, item, 2, self.VVMMWs)
 def VVPXjc(self, VVrVVi, title, txt, colList):
  self.filterObj.VVDBI6(2, VVrVVi, 4, boundFunction(self.VVdpwP, VVrVVi))
 def VVdpwP(self, VVrVVi, item):
  self.VV7AJy(VVrVVi, item, 4, self.VVYjrM)
 def VVMUsl(self, VVrVVi, title, txt, colList):
  self.filterObj.VVDBI6(0, VVrVVi, 4, boundFunction(self.VV01rX, VVrVVi))
 def VV01rX(self, VVrVVi, item):
  self.VV7AJy(VVrVVi, item, 4, self.VVEaHj)
 def VV7AJy(self, VVrVVi, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVrVVi.VVa9s4(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV6rgC = None
  else:
   words, asPrefix = CCZqjv.VVl9PV(words)
   self.VV6rgC = [col, words, asPrefix]
  if words: FFCkhd(self, boundFunction(self.VVCJUg, VVrVVi, title, mode), title="Reading Services ...")
  else : FFt82g(VVrVVi, "Incorrect filter", 2000)
 def VVCJUg(self, VVrVVi, title, mode):
  VVvFiF = CC6jYr.VVaFY4(self, mode, VV49RU=self.VV6rgC, VV2fu3=False)
  if VVvFiF:
   VVvFiF.sort(key=lambda x: x[0].lower())
   VVrVVi.VV8dsB(VVvFiF, title)
  else:
   VVrVVi.VViXU5()
   FFt82g(VVrVVi, "Not found!", 1500)
 def VVkiuu(self, VV7oZO, VVWoa9=None, VVRzGo=None, VVzi3l=None, VVredj=None, VVB4oX=None, VV0bqY=None):
  VVredj = ("Current Service", self.VVenLa, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVpYfQ = (LEFT  , LEFT  , CENTER, LEFT    )
  FFaufo(self, None, header=header, VV7oZO=VV7oZO, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=24, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVzi3l=VVzi3l, VVredj=VVredj, VVB4oX=VVB4oX, VV0bqY=VV0bqY)
 def VVenLa(self, VVrVVi, title, txt, colList):
  self.VVeMYL(VVrVVi)
 def VVgWXs(self, VVrVVi, title, txt, colList):
  self.VVeMYL(VVrVVi, True)
 def VVeMYL(self, VVrVVi, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVrVVi.VVGhyU(colDict, VVebv7=True)
   else:
    VVrVVi.VVA9bS(3, refCode, True)
   return
  FFKFol(self, "Colud not read current Reference Code !")
 def VV4DKU(self):
  self.VV6rgC = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZqjv(self)
  VVvFiF = CC6jYr.VVaFY4(self, self.VVEaHj)
  if VVvFiF:
   VVvFiF.sort(key=lambda x: x[0].lower())
   VVRzGo = (""    , self.VVlqbD , []      )
   VVredj = ("Current Service", self.VVgWXs  , []      )
   VV0bqY = ("Filter"   , self.VVMUsl   , [], "Loading Filters ..." )
   VVWoa9  = ("Zap"   , self.VVwZoh      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVpYfQ  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFaufo(self, None, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=24, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVredj=VVredj, VV0bqY=VV0bqY)
 def VVlqbD(self, VVrVVi, title, txt, colList):
  refCode  = self.VVgwAD(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFLiV2(self, fncMode=CCe5Io.VV1ZE3, refCode=refCode, chName=chName, text=txt)
 def VVwZoh(self, VVrVVi, title, txt, colList):
  refCode = self.VVgwAD(colList)
  FFKzCJ(self, refCode)
 def VVzYJE(self, VVrVVi, title, txt, colList):
  FFKzCJ(self, colList[3])
 def VVgwAD(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVaFY4(SELF, mode, VV49RU=None, VV2fu3=True, VVr6p9=True):
  lamedbFile, disabledFile = CC6jYr.VVtY5p()
  if fileExists(lamedbFile):
   asPrefix = False
   if VV49RU:
    filterCol = VV49RU[0]
    filterWords = VV49RU[1]
    asPrefix = VV49RU[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CC6jYr.VVMMWs:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFOmkW(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CC6jYr.VVYjrM:
    tp = CCfC6J()
   VVv6KF, VVv0kN = FFzIwD()
   tagFound  = False
   if mode in (CC6jYr.VVByhd, CC6jYr.VVQvFr):
    VVvFiF = {}
   else:
    VVvFiF = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFwz1x(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CC6jYr.VVEaHj:
        if sTypeInt in VVv6KF:
         STYPE = VVv0kN[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVvFiF.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVvFiF.append(tRow)
        else:
         VVvFiF.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CC6jYr.VVByhd:
         VVvFiF[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CC6jYr.VVQvFr:
         VVvFiF[chName] = refCode
        elif mode == CC6jYr.VVMMWs:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVvFiF.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVvFiF.append(tRow)
         else:
          VVvFiF.append(tRow)
        elif mode == CC6jYr.VVYjrM:
         if sTypeInt in VVv6KF:
          STYPE = VVv0kN[sTypeInt]
         freq, pol, fec, sr, syst = tp.VV9ftU(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVvFiF.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVvFiF.append(tRow)
         else:
          VVvFiF.append(tRow)
        elif mode == CC6jYr.VVqO9A:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVvFiF.append((chName, chProv, sat, refCode))
        elif mode == CC6jYr.VVFrLC:
         VVvFiF.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVvFiF and VV2fu3:
    FFKFol(SELF, "No services found!")
   return VVvFiF
  else:
   if VVr6p9:
    FFtist(SELF, lamedbFile)
   return None
 def VVEYfb(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFOmkW(path)
   if lines:
    newRows  = []
    VVvFiF = CC6jYr.VVaFY4(self, self.VVFrLC)
    if VVvFiF:
     lines = set(lines)
     for item in VVvFiF:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVvFiF = newRows
      VVvFiF.sort(key=lambda x: x[0].lower())
      VVRzGo = ("", self.VVPbtb, [])
      VVWoa9 = ("Zap", self.VVzYJE, [])
      self.VVkiuu(VV7oZO=VVvFiF, VVWoa9=VVWoa9, VVRzGo=VVRzGo)
     else:
      FFuPDq(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVvFiF)))
   else:
    FFo08k(self, "No active Parental Control services.", FFqA9R())
  else:
   FFtist(self, path)
 def VVDnm9(self):
  VVvFiF = CC6jYr.VVaFY4(self, self.VVqO9A)
  if VVvFiF:
   VVvFiF.sort(key=lambda x: x[0].lower())
   VVRzGo = ("" , self.VVPbtb, [])
   VVWoa9  = ("Zap", self.VVzYJE, [])
   self.VVkiuu(VV7oZO=VVvFiF, VVWoa9=VVWoa9, VVRzGo=VVRzGo)
  else:
   FFo08k(self, "No hidden services.", FFqA9R())
 def VVMJ5a(self):
  totT, totC, totA, totS, totS2, satList = self.VVODCY()
  txt = FFMi1p("Total Transponders:\n\n", VVVNGK)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFMi1p("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVVNGK)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFvHm9(item), satList.count(item))
  FFuPDq(self, txt)
 def VVODCY(self):
  lamedbFile, disabledFile = CC6jYr.VVtY5p()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFtist(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV3x0i(self)   : self.VV4IUi(True)
 def VV0Lod(self) : self.VV4IUi(False)
 def VV4IUi(self, isWithPIcons):
  piconsPath = CCc7kl.VVGkn8()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCc7kl.VV7nyP(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVvFiF = CC6jYr.VVaFY4(self, self.VVFrLC)
    if VVvFiF:
     channels = []
     for (chName, chProv, sat, refCode) in VVvFiF:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF9N2F(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVvFiF)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVcFSN(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVcFSN("PIcons Path"  , piconsPath)
     txt += VVcFSN("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVcFSN("Total services" , totalServices)
     txt += VVcFSN("With PIcons"  , totalWithPIcons)
     txt += VVcFSN("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFuPDq(self, txt)
     else:
      VVRzGo     = (""      , self.VVPbtb , [])
      if isWithPIcons : VV0bqY = ("Export Current PIcon", self.VVAYMP  , [])
      else   : VV0bqY = None
      VVB4oX     = ("Statistics", FFuPDq, [txt])
      VVWoa9      = ("Zap", self.VVzYJE, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVkiuu(VV7oZO=channels, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVB4oX=VVB4oX, VV0bqY=VV0bqY)
   else:
    FFKFol(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFKFol(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVPbtb(self, VVrVVi, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFLiV2(self, fncMode=CCe5Io.VV1ZE3, refCode=refCode, chName=chName, text=txt)
 def VVAYMP(self, VVrVVi, title, txt, colList):
  png, path = CCc7kl.VV0fgc(colList[3], colList[0])
  if path:
   CCc7kl.VVxy0d(self, png, path)
 @staticmethod
 def VVtY5p():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVfToQ():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVURYO(self, isEnable):
  lamedbFile, disabledFile = CC6jYr.VVtY5p()
  if isEnable and not fileExists(disabledFile):
   FFo08k(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFKFol(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FF7adK(self, boundFunction(self.VVS0sP, isEnable), "%s Hidden Channels ?" % word)
 def VVS0sP(self, isEnable):
  lamedbFile , disabledFile = CC6jYr.VVtY5p()
  lamedb5File, diabled5File = CC6jYr.VVfToQ()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFspal()
  if res == 0 : FFo08k(self, "Hidden List %s" % word)
  else  : FFKFol(self, "Error while restoring:\n\n%s" % fileName)
 def VVYHRZ(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FF3Nmm(self, cmd)
 def VVx3dd(self):
  lamedbFile, disabledFile = CC6jYr.VVtY5p()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFARGV("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFOmkW(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFARGV("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFspal()
   FFuPDq(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFtist(self, lamedbFile)
class CCe5Io(Screen):
 VVv4jH  = 0
 VVlDRu   = 1
 VVMAp4   = 2
 VV1ZE3    = 3
 VVEgpt    = 4
 VVxvhV   = 5
 VVOKOc   = 6
 VVLLZc    = 7
 VVhaRq   = 8
 VV4Tdt   = 9
 VVLqIV   = 10
 VVzaAJ   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFHZVI(VVHoLH, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVv4jH)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFMi1p("%s\n", VVNkuN) % VVFR4v
  FF7MWH(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self["myLabel"].VVVSbd(textOutFile="chann_info")
  if   self.fncMode == self.VVv4jH : fnc = self.VVN3ih_VVv4jH
  elif self.fncMode == self.VVlDRu  : fnc = self.VVN3ih_VVv4jH
  elif self.fncMode == self.VVMAp4  : fnc = self.VVN3ih_VVv4jH
  elif self.fncMode == self.VV1ZE3  : fnc = self.VVN3ih_VV1ZE3
  elif self.fncMode == self.VVEgpt  : fnc = self.VVN3ih_VVEgpt
  elif self.fncMode == self.VVxvhV  : fnc = self.VVN3ih_VVxvhV
  elif self.fncMode == self.VVOKOc  : fnc = self.VVN3ih_VVOKOc
  elif self.fncMode == self.VVLLZc  : fnc = self.VVN3ih_VVLLZc
  elif self.fncMode == self.VVhaRq  : fnc = self.VVN3ih_VVhaRq
  elif self.fncMode == self.VV4Tdt : fnc = self.VVN3ih_VV4Tdt
  elif self.fncMode == self.VVLqIV  : fnc = self.VVN3ih_VVLqIV
  elif self.fncMode == self.VVzaAJ : fnc = self.VVN3ih_VVzaAJ
  self["myLabel"].setText("\n   Reading Info ...")
  FFTTch(fnc)
 def VVqxe3(self, err):
  self["myLabel"].setText(err)
  FFlSQr(self["myTitle"], "#22200000")
  FFlSQr(self["myBody"], "#22200000")
  self["myLabel"].FFlSQrColor("#22200000")
  self["myLabel"].VV0TCs()
 def VVN3ih_VVv4jH(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  self.refCode = refCode
  self.VV3YbT(chName)
 def VVN3ih_VV1ZE3(self):
  self.VV3YbT(self.chName)
 def VVN3ih_VVEgpt(self):
  self.VV3YbT(self.chName)
 def VVN3ih_VVxvhV(self):
  self.VV3YbT(self.chName)
 def VVN3ih_VVOKOc(self):
  self.VV3YbT("Picon Info")
 def VVN3ih_VVLLZc(self):
  self.VV3YbT(self.chName)
 def VVN3ih_VVhaRq(self):
  self.VV3YbT(self.chName)
 def VVN3ih_VV4Tdt(self):
  self.VV3YbT(self.chName)
 def VVN3ih_VVLqIV(self):
  self.chUrl = self.refCode + self.callingSELF.VVnSIS(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VV3YbT(self.chName)
 def VVN3ih_VVzaAJ(self):
  self.VV3YbT(self.chName)
 def VV3YbT(self, title):
  self.VVzuE0(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVdQzb(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFMi1p(self.VVx1D2(tUrl), VVRhh2)
  if not self.epg:
   epg = self.VVBwHl(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVeyhH(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCc7kl.VV0fgc(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVeyhH(path)
  self.VVhIZe()
  self.VV9nuh()
  self["myLabel"].setText(self.text, VVNQut=VVKIxe)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV0TCs(minHeight=minH)
 def VV9nuh(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFMSfm(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VV2x2h(FFsqcp(url))
  if epg:
   self.text += "\n" + FF5WAx("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVhIZe()
 def VVhIZe(self):
  if not self.piconShown and self.picUrl:
   path, err = FFUMM6(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VVeyhH(path)
    if self.piconShown and self.refCode:
     self.VVuiu0(path, self.refCode)
 def VVuiu0(self, path, refCode):
  if path and fileExists(path) and os.system(FFARGV("which ffmpeg")) == 0:
   pPath = CCc7kl.VVGkn8()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFARGV("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVeyhH(self, path):
  if path and fileExists(path):
   err, w, h = self.VVLw7V(path)
   if not err:
    if h > w:
     self.VVNmpU(self["myPicF"], w, h, True)
     self.VVNmpU(self["myPic"] , w, h, False)
   allOK = FFr0aO(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVNmpU(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVLw7V(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFgaUh(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVzuE0(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VVdQzb(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFMi1p(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVcFSN(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFMi1p(state, VVQy4t)
   txt += "State\t: %s\n" % state
  w = FFT7wI(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFT7wI(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVJoTV(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVcFSN(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVcFSN(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVcFSN(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFMi1p("IPTV", VVVNGK)
   txt += self.VVMqcN(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVJq7w(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCfC6J()
    tpTxt, namespace = tp.VVm7RS(refCode)
    del tp
    if tpTxt:
     txt += FFMi1p("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFMi1p("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVcFSN(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVcFSN(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVcFSN(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVcFSN(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVcFSN(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVcFSN(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVcFSN(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVcFSN(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVcFSN(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVJoTV(info):
  if info:
   aspect = FFT7wI(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVcFSN(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFT7wI(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVtK5s(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVtK5s(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVJq7w(self, refCode, iptvRef, chName):
  refCode = FFSFL7(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FF0FCE(VVPZfu + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FF0FCE(VVPZfu + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV7oZO = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVPZfu + item
   if fileExists(path):
    txt = FF0FCE(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV7oZO.append(bName)
  txt = self.Sep
  if VV7oZO:
   if len(VV7oZO) == 1:
    txt += "%s\t: %s\n" % (FFMi1p("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV7oZO[0])
   else:
    txt += FFMi1p("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV7oZO):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVBwHl(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVSFOl(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVSFOl(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVSFOl(event, 0)
     except:
      pass
  return epg
 def VVSFOl(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FFMi1p(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FFMoES(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFMoES(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFUeKr(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFUeKr(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFUeKr(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FFMi1p(evShort, VVRhh2)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFMi1p(evDesc , VVRhh2)
    if txt:
     txt = FFMi1p("\n%s\n%s Event:\n%s\n" % (VVFR4v, ("Current", "Next")[evNum], VVFR4v), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVMqcN(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFg14Y(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCAwBk()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVucMv(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFMi1p("URL:", VVVNGK) + "\n%s\n" % self.VVx1D2(decodedUrl)
  else:
   txt = "\n"
   txt += FFMi1p("Reference:", VVVNGK) + "\n%s\n" % refCode
  return txt
 def VVx1D2(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVNqXw:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VV2x2h(self, decodedUrl):
  if not FFLVNL():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCaJkM.VVzpN1(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCaJkM.VVprsV(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVQCll(tDict)
   elif uType == "movie" : epg, picUrl = self.VVhyXY(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVQCll(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCaJkM.VVNnYa(item, "title"    , is_base64=True )
     lang    = CCaJkM.VVNnYa(item, "lang"         ).upper()
     description   = CCaJkM.VVNnYa(item, "description"  , is_base64=True )
     start_timestamp  = CCaJkM.VVNnYa(item, "start_timestamp" , isDate=True  )
     stop_timestamp  = CCaJkM.VVNnYa(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCaJkM.VVNnYa(item, "stop_timestamp"       )
     now_playing   = CCaJkM.VVNnYa(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVkCrP, ""
      else     : color, txt = VVQy4t , "    (CURRENT EVENT)"
      epg += FFMi1p("_" * 32 + "\n", VVNkuN)
      epg += FFMi1p("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FFMi1p(description, VVRhh2)
      evNum += 1
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVhyXY(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCaJkM.VVNnYa(item, "movie_image" )
    genre  = CCaJkM.VVNnYa(item, "genre"   ) or "-"
    plot  = CCaJkM.VVNnYa(item, "plot"   ) or "-"
    cast  = CCaJkM.VVNnYa(item, "cast"   ) or "-"
    rating  = CCaJkM.VVNnYa(item, "rating"   ) or "-"
    director = CCaJkM.VVNnYa(item, "director"  ) or "-"
    releasedate = CCaJkM.VVNnYa(item, "releasedate" ) or "-"
    duration = CCaJkM.VVNnYa(item, "duration"  ) or "-"
    try:
     lang = CCaJkM.VVNnYa(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFMi1p(cast, VVRhh2)
    epg += "Plot:\n%s"    % FFMi1p(plot, VVRhh2)
   except:
    pass
  return epg, movie_image
class CCAwBk():
 def __init__(self):
  self.VVk0YJ  = ""
  self.VVtjQM   = ""
  self.VVxwnb  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV2VcU(self, url, mac, VVebv7=True):
  self.VVk0YJ = ""
  self.VVtjQM  = ""
  self.VVxwnb = ""
  host = self.VVAwMP(url)
  if not host:
   if VVebv7:
    self.VVebv7or("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVzlqt(mac)
  if not host:
   if VVebv7:
    self.VVebv7or("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVk0YJ = host
  self.VVtjQM  = mac
  self.VVxwnb = ""
  return True
 def VVrTvn(self):
  res, err = self.VVK4eR(self.VVk0YJ, useCookies=False)
  if err:
   self.VVebv7or(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVK4eR(newUrl, res.cookies)
   if err:
    self.VVebv7or(err, "URL Redirection")
    return False
   else:
    host = self.VVAwMP(newUrl)
    if not host:
     self.VVebv7or("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVk0YJ = host
  token, profile = self.VVObXE()
  if not token:
   return False
  return True
 def VVAwMP(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VVzlqt(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVObXE(self, VVebv7=True):
  try:
   token = self.VVuryw()
   if token:
    self.VVxwnb = token
   else:
    if VVebv7:
     self.VVebv7or("Could not get Token from server !")
    return "", ""
   return token, self.VVKAVp()
  except:
   return "", ""
 def VVuryw(self):
  token  = ""
  res, err = self.VVK4eR(self.VV0Cqc())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCaJkM.VVNnYa(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVKAVp(self):
  res, err = self.VVK4eR(self.VVXPAq())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVxlYI(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV53en()
  if len(rows) < 10:
   rows = self.VV8iKr()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVk0YJ ))
   rows.append(("MAC (from URL)" , self.VVtjQM ))
   rows.append(("Token"   , self.VVxwnb ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVtjQM ))
   rows.append(("2", self.colored_server, "Host" , self.VVk0YJ ))
   rows.append(("2", self.colored_server, "Token" , self.VVxwnb ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVJLKg(self):
  token, profile = self.VVObXE()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVeR5n()
  res, err = self.VVK4eR(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCaJkM.VVNnYa(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VV53en(self):
  m3u_Url = self.VVJLKg()
  rows = []
  if m3u_Url:
   res, err = self.VVK4eR(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFMoES(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFMoES(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV8iKr(self):
  token, profile = self.VVObXE()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFUF1Y(val): val = FFNh3o(val.decode("UTF-8"))
     else     : val = self.VVtjQM
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFMoES(int(parts[1]))
      if parts[2] : ends = FFMoES(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFMoES(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVnSIS(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VV6Eoj(mode, chCm, epNum, epId)
  token, profile = self.VVObXE(VVebv7=False)
  if not token:
   return ""
  res, err = self.VVK4eR(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCaJkM.VVNnYa(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVqSyd(self):
  return self.VVk0YJ + "/server/load.php?"
 def VV0Cqc(self):
  return self.VVqSyd() + "type=stb&action=handshake&token=&mac=%s" % self.VVtjQM
 def VVXPAq(self):
  return self.VVqSyd() + "type=stb&action=get_profile"
 def VVUoGz(self, mode):
  url = self.VVqSyd() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVVm49(self, catID):
  return self.VVqSyd() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV1VJH(self, mode, catID, page):
  url = self.VVqSyd() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VV7L2v(self, mode, searchName, page):
  return self.VVqSyd() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVqUR6(self, mode, catID):
  return self.VVqSyd() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VV6Eoj(self, mode, chCm, serCode, serId):
  url = self.VVqSyd() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVeR5n(self):
  return self.VVqSyd() + "type=itv&action=create_link"
 def VVUfUI(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVNzIw(catID, stID, chNum)
  query = self.VVZsbk(mode, FFlwHB(host), FFlwHB(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVZsbk(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVucMv(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVZsbk(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFNh3o(host)
  mac   = FFNh3o(mac)
  valid = False
  if self.VVAwMP(playHost) and self.VVAwMP(host) and self.VVAwMP(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVK4eR(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVtjQM, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVxwnb:
    headers["Authorization"] = "Bearer %s" % self.VVxwnb
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVZACb(host, mac, tType, action, keysList=[]):
  myPortal = CCAwBk()
  ok = myPortal.VV2VcU(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VVObXE()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVK4eR(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV2vdg(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV2vdg(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVebv7or(self, err, title="Portal Browser"):
  FFKFol(self, str(err), title=title)
 def VV0TEI(self, mode):
  if   mode in ("itv"  , CCaJkM.VV6DkX) : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCaJkM.VVQRgb) : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCaJkM.VVQXlB): return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode == "series2"           : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else               : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVZe91(self, mode):
  if   mode in ("itv"  , CCaJkM.VV6DkX , CCaJkM.VVXca4)  : return "Live"
  elif mode in ("vod"  , CCaJkM.VVQRgb , CCaJkM.VVvJIy)  : return "VOD"
  elif mode in ("series" , CCaJkM.VVQXlB , CCaJkM.VVvGos) : return "Series"
  else                          : return "IPTV"
 def VV8ZQu(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVZe91(mode), searchName)
 def VVoCIC(self):
  VVtP1e = []
  VVtP1e.append(("Live"    , "live"  ))
  VVtP1e.append(("VOD"    , "vod"   ))
  VVtP1e.append(("Series "   , "series"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Account Info." , "accountInfo" ))
  return VVtP1e
class CCw9XP(CCAwBk):
 def __init__(self):
  CCAwBk.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVWmtx(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVucMv(decodedUrl)
  if valid:
   if self.VV2VcU(host, mac, VVebv7=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVtq8R(self, passedSELF=None, isFromSession=False):
  chUrl = self.VVnSIS(self.mode, self.chCm, self.epNum, self.epId)
  if not chUrl:
   return
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVxAoh(self.iptvRef, newIptvRef)
   if passedSELF:
    FFKzCJ(passedSELF, newIptvRef, VVDaMP=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFKzCJ(self, newIptvRef, VVDaMP=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVxAoh(self, oldCode, newCode):
  bPath = FFElwQ()
  if bPath:
   txt = FF0FCE(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFspal()
    return True
  return False
class CCiRSs(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFHZVI(VVkSsZ, 10, 10, 50, 30, 20, "#22002020", "#22001122", 30)
  self.session = session
  FF7MWH(self, "")
  self.close()
class CCOJSM(CCw9XP):
 def __init__(self, passedSession):
  CCw9XP.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={ iPlayableService.evEnd: self.VVSRjC})
  except:
   pass
 def VVSRjC(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVYoou)
  except:
   self.timer1.callback.append(self.VVYoou)
  self.timer1.start(100, True)
 def VVYoou(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVWmtx(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCD9VV.PLAYER_INSTANCE:
       self.VVtq8R(self.passedSession, isFromSession=True)
class CCf9q3():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex" , "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
 def VV9sZh(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(r"(b[-]*e[-]*I[-]*N)", r"beIN", name, flags=IGNORECASE).strip()
  if CCaJkM.VV4hUg(name):
   return CCaJkM.VVpbLa(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVtcuI(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVurlX(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVXAhR(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CC7SY3(CCAwBk):
 def __init__(self):
  CCAwBk.__init__(self)
 def VVxp1f(self):
  try:
   import requests
   FFCkhd(self, self.VVPlq8, title="Searching ...")
  except:
   FF7adK(self, self.VVGBqr, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VV3FAM(self, winSession, url, mac):
  if self.VV2VcU(url, mac):
   FFCkhd(winSession, self.VVeLL1, title="Checking Server ...")
  else:
   FFKFol(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVGBqr(self):
  from sys import version_info
  cmdUpd = FFlm1I(VVz50d, "")
  if cmdUpd:
   cmdInst = FFzJLp(VVOWgY, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFxQD8(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFk6P3(self)
 def VVPlq8(self):
  lines = FFhQrI('find / %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % FFgUhe(1))
  if lines:
   lines.sort()
   VVtP1e = []
   for line in lines:
    VVtP1e.append((line, line))
   OKBtnFnc = self.VVKZGm
   FF0g9p(self, None, title="Select Portals File", VVtP1e=VVtP1e, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFKFol(self, "No portal files found\n\nFile example : portalxx.txt \n(separate URL and MAC with space/tab/comma)")
 def VVKZGm(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CC1gln, barTheme=CC1gln.VVgiaG
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVgJp2, path)
       , VVfbK6 = boundFunction(self.VVAkoP, menuInstance, path))
 def VVgJp2(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  lines  = FFOmkW(path)
  progBarObj.VVQxG2(len(lines))
  progBarObj.VVof9j = []
  import time
  for lineNum, line in enumerate(lines, start=1):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVd70M(1, True)
   iSleep(0.0001)
   line = line.strip()
   if not line or "password" in line:
    continue
   span = iSearch(urlMacPatt, line, IGNORECASE)
   if span:
    c  += 1
    subj = span.group(1).strip() or "-"
    url  = span.group(2).strip()
    mac  = span.group(3).strip().replace(" ", "").upper()
    info = span.group(4).strip() or "-"
    host = self.VVAwMP(url)
    mac  = self.VVzlqt(mac)
    if host and mac and progBarObj:
     progBarObj.VVof9j.append((str(c), str(lineNum), subj, host, mac, info))
    url  = ""
    continue
   if not url:
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if not span:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
   else:
    span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     mac  = span.group(2).strip().replace(" ", "").upper()
     info = span.group(3).strip() or "-"
     host = self.VVAwMP(url)
     mac  = self.VVzlqt(mac)
     if host and mac and not mac.startswith("AC") and progBarObj:
      progBarObj.VVof9j.append((str(c), str(lineNum), "-", host, mac, info))
    else:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
 def VVAkoP(self, menuInstance, path, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVof9j:
   VVzi3l  = ("Home Menu", FFz3mf, [])
   VV0bqY  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVB4oX = ("Edit File" , boundFunction(self.VV4LZe, path) , [])
   VVWoa9  = ("Select"  , self.VV3FAM_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVpYfQ  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVrVVi = FFaufo(self, None, title=title, header=header, VV7oZO=VVof9j, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22, VVWoa9=VVWoa9, VVzi3l=VVzi3l, VVB4oX=VVB4oX, VV0bqY=VV0bqY, VVOM9K="#0a001111", VVpOBz="#0a001122", VVpeGc="#0a001122", VVrGdv="#00000000", VV34E6=True, searchCol=1)
   if not VVcfNz:
    FFt82g(VVrVVi, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVcfNz:
    FFKFol(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV3FAM_fromMacFiles(self, VVrVVi, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV3FAM(VVrVVi, url, mac)
 def VV4LZe(self, path, VVrVVi, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCsBZy(self, path, VVfbK6=boundFunction(self.VViClB, VVrVVi), curRowNum=rowNum)
  else    : FFtist(self, path)
 def VViClB(self, VVrVVi, fileChanged):
  if fileChanged:
   VVrVVi.cancel()
 def VVgFiN(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFNh3o(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVeLL1(self):
  if self.VVrTvn():
   VVtP1e  = self.VVoCIC()
   OKBtnFnc = self.VV8jVO
   VVxdDY = ("Home Menu", FFz3mf)
   FF0g9p(self, None, title="Portal Resources (MAC=%s)" % self.VVtjQM, VVtP1e=VVtP1e, OKBtnFnc=OKBtnFnc, VVxdDY=VVxdDY)
 def VV8jVO(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFCkhd(menuInstance, boundFunction(self.VVoXnq, mode), title="Reading Categories ...")
   else : FFCkhd(menuInstance, boundFunction(self.VV1R7w, menuInstance, title), title="Reading Account ...")
 def VV1R7w(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVxlYI(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVtjQM)
  VVzi3l  = ("Home Menu" , FFz3mf, [])
  if totCols == 2:
   VV0bqY = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VV0bqY = ("More Info.", boundFunction(self.VV2vlr, menuInstance) , [])
  FFaufo(self, None, title=title, header=header, VV7oZO=rows, VVAF36=widths, VVpwbP=26, VVzi3l=VVzi3l, VV0bqY=VV0bqY, VVOM9K="#0a00292B", VVpOBz="#0a002126", VVpeGc="#0a002126", VVrGdv="#00000000", searchCol=searchCol)
 def VV2vlr(self, menuInstance, VVrVVi, title, txt, colList):
  VVrVVi.cancel()
  FFCkhd(menuInstance, boundFunction(self.VV1R7w, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVoXnq(self, mode):
  token, profile = self.VVObXE()
  if not token:
   return
  res, err = self.VVK4eR(self.VVUoGz(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCf9q3()
     chList = tDict["js"]
     for item in chList:
      Id   = CCaJkM.VVNnYa(item, "id"       )
      Title  = CCaJkM.VVNnYa(item, "title"      )
      censored = CCaJkM.VVNnYa(item, "censored"     )
      Title = processChanName.VVtcuI(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVNqXw:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVZe91(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI(mode)
   mName = self.VVZe91(mode)
   VVWoa9   = ("Show Channels"  , boundFunction(self.VVOZcm, mode) , [])
   VVzi3l  = ("Home Menu"   , FFz3mf         , [])
   if mode in ("vod", "series"):
    VVB4oX = ("Find in %s" % mName , boundFunction(self.VVt27Z, mode), [])
   else:
    VVB4oX = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFaufo(self, None, title=title, header=header, VV7oZO=list, VVAF36=widths, VVpwbP=30, VVzi3l=VVzi3l, VVB4oX=VVB4oX, VVWoa9=VVWoa9, VVOM9K=VVOM9K, VVpOBz=VVpOBz, VVpeGc=VVpeGc, VVrGdv=VVrGdv)
  else:
   FFKFol(self, "Could not get Categories from server!", title=title)
 def VVJuh8(self, mode, VVrVVi, title, txt, colList):
  FFCkhd(VVrVVi, boundFunction(self.VVu9gz, mode, VVrVVi, title, txt, colList), title="Downloading ...")
 def VVu9gz(self, mode, VVrVVi, title, txt, colList):
  token, profile = self.VVObXE()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVK4eR(self.VVVm49(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCaJkM.VVNnYa(item, "id"    )
      actors   = CCaJkM.VVNnYa(item, "actors"   )
      added   = CCaJkM.VVNnYa(item, "added"   )
      age    = CCaJkM.VVNnYa(item, "age"   )
      category_id  = CCaJkM.VVNnYa(item, "category_id" )
      description  = CCaJkM.VVNnYa(item, "description" )
      director  = CCaJkM.VVNnYa(item, "director"  )
      genres_str  = CCaJkM.VVNnYa(item, "genres_str"  )
      name   = CCaJkM.VVNnYa(item, "name"   )
      path   = CCaJkM.VVNnYa(item, "path"   )
      screenshot_uri = CCaJkM.VVNnYa(item, "screenshot_uri" )
      series   = CCaJkM.VVNnYa(item, "series"   )
      cmd    = CCaJkM.VVNnYa(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVWoa9  = ("Play"  , boundFunction(self.VVhJ0Q, mode, False)      , [])
   VVRzGo = (""   , boundFunction(self.VVZ4zk, mode)      , [])
   VVzi3l = ("Home Menu" , FFz3mf                , [])
   VVredj = ("Download PIcons" , boundFunction(self.VVPRc4, mode)      , [])
   VVB4oX = ("Add ALL to Bouquet" , boundFunction(self.VVUpe1, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVpYfQ  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFaufo(self, None, title=seriesName, header=header, VV7oZO=list, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=26, VVzi3l=VVzi3l, VVredj=VVredj, VVB4oX=VVB4oX, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVOM9K="#0a00292B", VVpOBz="#0a002126", VVpeGc="#0a002126", VVrGdv="#00000000")
  else:
   FFKFol(self, "Could not get Episodes from server!", title=seriesName)
 def VVt27Z(self, mode, VVrVVi, title, txt, colList):
  VVtP1e = []
  VVtP1e.append(("Keyboard"  , "manualEntry"))
  VVtP1e.append(("From Filter" , "fromFilter"))
  FF0g9p(self, boundFunction(self.VV2Bii, VVrVVi, mode), title="Input Type", VVtP1e=VVtP1e, width=400)
 def VV2Bii(self, VVrVVi, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFXtIF(self, boundFunction(self.VVsBPQ, VVrVVi, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCZqjv(self)
    filterObj.VVka1I(boundFunction(self.VVsBPQ, VVrVVi, mode))
 def VVsBPQ(self, VVrVVi, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VV8ZQu(mode, searchName)
   if len(searchName) < 3:
    FFKFol(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCf9q3()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVurlX([searchName]):
     FFKFol(self, processChanName.VVXAhR(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVTKA4(mode, searchName, "", searchName)
 def VVOZcm(self, mode, VVrVVi, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVTKA4(mode, bName, catID, "")
 def VVTKA4(self, mode, bName, catID, searchName):
  self.session.open(CC1gln, barTheme=CC1gln.VV6tHG
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVgk1K, mode, bName, catID, searchName)
      , VVfbK6 = boundFunction(self.VVQRT4, mode, bName, catID, searchName))
 def VVQRT4(self, mode, bName, catID, searchName, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VV8ZQu(mode, searchName)
  else   : title = "%s : %s" % (self.VVZe91(mode), bName)
  if VVof9j:
   if mode == "series":
    VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI("series2")
    VVWoa9  = ("Episodes", boundFunction(self.VVJuh8, mode) , [])
    VVredj = None
    VVB4oX = None
   else:
    VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI("")
    VVWoa9  = ("Play"    , boundFunction(self.VVhJ0Q, mode, False)   , [])
    VVredj = ("Download PIcons" , boundFunction(self.VVPRc4, mode)     , [])
    VVB4oX = ("Add ALL to Bouquet" , boundFunction(self.VVUpe1, mode, bName) , [])
   VVRzGo = (""      , boundFunction(self.VVxbvY, mode)    , [])
   VVzi3l = ("Home Menu"    , FFz3mf             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVpYfQ  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVrVVi = FFaufo(self, None, title=title, header=header, VV7oZO=VVof9j, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=26, VVzi3l=VVzi3l, VVredj=VVredj, VVB4oX=VVB4oX, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVOM9K=VVOM9K, VVpOBz=VVpOBz, VVpeGc=VVpeGc, VVrGdv=VVrGdv, VV34E6=True, searchCol=1)
   if not VVcfNz:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVrVVi.VV8r5D(VVrVVi.VVtpWC() + tot)
    if threadErr: FFt82g(VVrVVi, "Error while reading !", 2000)
    else  : FFt82g(VVrVVi, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFKFol(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFKFol(self, "Could not get list from server !", title=title)
 def VVxbvY(self, mode, VVrVVi, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFLiV2(self, fncMode=CCe5Io.VVzaAJ, portalHost=self.VVk0YJ, portalMac=self.VVtjQM, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVDZYl(mode, VVrVVi, title, txt, colList)
 def VVZ4zk(self, mode, VVrVVi, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFMi1p(colList[10], VVRhh2)
  txt += "Description:\n%s" % FFMi1p(colList[11], VVRhh2)
  self.VVDZYl(mode, VVrVVi, title, txt, colList)
 def VVDZYl(self, mode, VVrVVi, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVqhif(mode, colList)
  refCode, chUrl = self.VVUfUI(self.VVk0YJ, self.VVtjQM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFLiV2(self, fncMode=CCe5Io.VVLqIV, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVgk1K(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VVObXE()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVof9j, total_items, max_page_items, err = self.VVp9XF(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVof9j and total_items > -1 and max_page_items > -1:
    progBarObj.VVQxG2(total_items)
    progBarObj.VVd70M(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVp9XF(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVWQJ8()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVof9j += list
      progBarObj.VVd70M(len(list), True)
  except:
   pass
 def VVp9XF(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url =self.VV7L2v(mode, searchName, page)
  else   : url =self.VV1VJH(mode, catID, page)
  res, err = self.VVK4eR(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVJu6a(CCaJkM.VVNnYa(item, "total_items" ))
     max_page_items = self.VVJu6a(CCaJkM.VVNnYa(item, "max_page_items" ))
     processChanName = CCf9q3()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCaJkM.VVNnYa(item, "id"    )
      name   = CCaJkM.VVNnYa(item, "name"   )
      tv_genre_id  = CCaJkM.VVNnYa(item, "tv_genre_id" )
      number   = CCaJkM.VVNnYa(item, "number"   ) or str(counter)
      logo   = CCaJkM.VVNnYa(item, "logo"   )
      screenshot_uri = CCaJkM.VVNnYa(item, "screenshot_uri" )
      cmd    = CCaJkM.VVNnYa(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VV9sZh(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVUpe1(self, mode, bName, VVrVVi, title, txt, colList):
  FFCkhd(VVrVVi, boundFunction(self.VV53zn, mode, bName, VVrVVi, title, txt, colList), title="Adding Channels ...")
 def VV53zn(self, mode, bName, VVrVVi, title, txt, colList):
  bNameFile = CCaJkM.VVwlum(bName)
  num  = 0
  path = VVPZfu + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVPZfu + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVrVVi.VVi8Qm():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVqhif(mode, row)
    refCode, chUrl = self.VVUfUI(self.VVk0YJ, self.VVtjQM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFE3xM(os.path.basename(path))
  self.VV8l0m(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVJu6a(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVhJ0Q(self, mode, fromPlayer, VVrVVi, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVqhif(mode, colList)
  refCode, chUrl = self.VVUfUI(self.VVk0YJ, self.VVtjQM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VVSw5F(mode, VVrVVi, chUrl)
  elif self.VV4hUg(chName):
   FFt82g(VVrVVi, "This is a marker!", 300)
  else:
   FFCkhd(VVrVVi, boundFunction(self.VVSw5F, mode, VVrVVi, chUrl), title="Playing ...")
 def VVSw5F(self, mode, VVrVVi, chUrl):
  FFKzCJ(self, chUrl, VVDaMP=False)
  self.session.open(CCD9VV, portalTableParam=(self, VVrVVi, mode))
 def VVqhif(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCaJkM(Screen, CC7SY3):
 VVbowJ = 0
 VVjdDv = 1
 VV7jl2 = 2
 VVtQc9 = 3
 VVDacW  = 4
 VVPelD  = 5
 VV6RFt  = 6
 VV0brI  = 7
 VVvBq7   = 8
 VVpJCu  = 9
 VVraIU  = 10
 VVWXPN  = 11
 VVHZsz  = 12
 VVLy5W   = 13
 VVXTpv   = 14
 VVuL7w   = 15
 VVEZlP   = 16
 VVjKv7   = 17
 VVi32w    = 0
 VV6DkX   = 1
 VVQRgb   = 2
 VVQXlB   = 3
 VVTAkE  = 4
 VVXca4   = 5
 VVvJIy   = 6
 VVvGos  = 7
 VVg0Ir  = 8
 VVLsDI   = 9
 VV1hHp = 10
 VV125S   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 1100, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVrVVi  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVRMpbData  = {}
  self.lastFindIptvName = ""
  CC7SY3.__init__(self)
  VVtP1e= self.VV1ITl()
  FF7MWH(self, title="IPTV", VVtP1e=VVtP1e)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
  FF3Ivr(self)
 def VV1ITl(self):
  files = self.VVdTLj()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVRMpb_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVRMpb_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVRMpb_fromM3u"  ))
  qUrl, iptvRef = self.VVrTHl()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVRMpb_fromCurrChan" ))
  VVtP1e = []
  if files:
   if self.VVrVVi:
    VVtP1e.append(("Add Current List to a New Bouquet"      , "VVjoiC"  ))
    VVtP1e.append(VV6Efe)
    VVtP1e.append(("Change Current List References to Unique Codes"   , "VVbNXz"))
    VVtP1e.append(("Change Current List References to Identical Codes"  , "VVJRee_rows" ))
    VVtP1e.append(VV6Efe)
    VVtP1e.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVdELz"   ))
    VVtP1e.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VV80Wg"   ))
   else:
    VVtP1e += tList
    VVtP1e.append(VV6Efe)
    VVtP1e.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    VVtP1e.append(VV6Efe)
    VVtP1e.append(("Count Available IPTV Channels"       , "VVZEOS"    ))
    VVtP1e.append(("Check Reference Codes Format"        , "VVSCXu"   ))
    VVtP1e.append(("Check System Acceptable Reference Types"     , "VVq48U"   ))
    VVtP1e.append(VV6Efe)
    VVtP1e.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVzqxA"  ))
    VVtP1e.append(("Change ALL References to match existing Sat/C/T Channels" , "VVeqMF" ))
    VVtP1e.append(("Change ALL References to Unique Codes"     , "VV4U41" ))
    VVtP1e.append(("Change ALL References to Identical Codes"     , "VVJRee_all" ))
  if not self.VVrVVi:
   if not files:
    VVtP1e += tList
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Analyse m3u File"            , "VVMtJV"   ))
   VVtP1e.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVrTXs" ))
   VVtP1e.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVIldJ" ))
   VVtP1e.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVr85k" ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Reload Channels and Bouquets"         , "VV4Fie"   ))
  return VVtP1e
 def VVLBbS(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   if   item == "VVjoiC"   : FFXtIF(self, self.VVjoiC, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVbNXz" : FF7adK(self, boundFunction(FFCkhd, self.VVrVVi, self.VVbNXz ), "Change Current List References to Unique Codes ?")
   elif item == "VVJRee_rows" : FF7adK(self, boundFunction(FFCkhd, self.VVrVVi, self.VVJRee   ), "Change Current List References to Identical Codes ?")
   elif item == "VVdELz"   : self.VVdELz(tTitle)
   elif item == "VV80Wg"   : self.VV80Wg(tTitle)
   elif item == "VVRMpb_fromPlayList" : FFCkhd(self, boundFunction(self.VVKdCw, True), title="Searching ...")
   elif item == "VVRMpb_fromM3u"  : FFCkhd(self, boundFunction(self.VVtZOW, 0), title="Searching ...")
   elif item == "VVRMpb_fromMac"  : self.VVxp1f()
   elif item == "VVRMpb_fromCurrChan" : self.VV3FAM_fromCurrChan()
   elif item == "iptvTable_live"   : FFCkhd(self, boundFunction(self.VVQXaV, self.VV0brI ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFCkhd(self, boundFunction(self.VVQXaV, self.VVbowJ) , title="Loading Channels ...")
   elif item == "VVZEOS"    : FFCkhd(self, self.VVZEOS)
   elif item == "VVSCXu"    : FFCkhd(self, self.VVSCXu)
   elif item == "VVq48U"   : FFCkhd(self, self.VVq48U)
   elif item == "VVzqxA"  : self.VVzqxA()
   elif item == "VVeqMF"  : FF7adK(self, boundFunction(FFCkhd, self, self.VVeqMF ), "Copy from existing Sat. Channel" )
   elif item == "VV4U41" : FF7adK(self, boundFunction(FFCkhd, self, self.VV4U41 ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVJRee_all" : FF7adK(self, boundFunction(FFCkhd, self, self.VVJRee  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVMtJV"   : FFCkhd(self, boundFunction(self.VVtZOW, 1), title="Searching ...")
   elif item == "VVrTXs" : self.VVrTXs()
   elif item == "VVIldJ" : FFCkhd(self, boundFunction(self.VVtZOW, 2), title="Searching ...")
   elif item == "VVr85k" : FFCkhd(self, boundFunction(self.VVKdCw, False), title="Searching ...")
   elif item == "VV4Fie"   : FFCkhd(self, boundFunction(CC6jYr.VV4Fie, self))
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVLBbS(item)
 def VVQXaV(self, mode):
  VVvFiF = self.VVwCZB(mode)
  if VVvFiF:
   VVredj = ("Current Service", self.VVMw7a    , [])
   VVB4oX = ("Options"  , self.VVMq7Q      , [])
   VV0bqY = ("Filter"   , self.VVhO8F       , [])
   VVWoa9  = ("Play"   , boundFunction(self.VVw8hT, False) , [])
   VVRzGo = (""    , self.VVqwt5       , [])
   VVsaB3 = (""    , self.VVkk7j        , [])
   VVYpBL = (""    , self.VVu238       , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVpYfQ  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFaufo(self, None, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22
     , VVWoa9=VVWoa9, VVredj=VVredj, VVB4oX=VVB4oX, VV0bqY=VV0bqY, VVRzGo=VVRzGo, VVsaB3=VVsaB3
     , VVOM9K="#0a00292B", VVpOBz="#0a002126", VVpeGc="#0a002126", VVrGdv="#00000000", VV34E6=True, searchCol=1)
  else:
   if mode == self.VV0brI: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFKFol(self, err)
 def VVkk7j(self, VVrVVi, title, txt, colList):
  self.VVrVVi = VVrVVi
 def VVu238(self, VVrVVi):
  self.VVrVVi = None
 def VVMq7Q(self, VVrVVi, title, txt, colList):
  VVtP1e= self.VV1ITl()
  FF0g9p(self, self.VVLBbS, title="IPTV Tools", VVtP1e=VVtP1e)
 def VVhO8F(self, VVrVVi, title, txt, colList):
  VVtP1e = []
  VVtP1e.append(("All"         , "all"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Prefix of Selected Channel"   , "sameName" ))
  VVtP1e.append(("Suggest Words from Selected Channel" , "partName" ))
  VVtP1e.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Live TV"        , "live"  ))
  VVtP1e.append(("VOD"         , "vod"   ))
  VVtP1e.append(("Series"        , "series"  ))
  VVtP1e.append(("Uncategorised"      , "uncat"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Video"        , "video"  ))
  VVtP1e.append(("Audio"        , "audio"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("MKV"         , "MKV"   ))
  VVtP1e.append(("MP4"         , "MP4"   ))
  VVtP1e.append(("MP3"         , "MP3"   ))
  VVtP1e.append(("AVI"         , "AVI"   ))
  VVtP1e.append(("FLV"         , "FLV"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVttGc()
  if bNames:
   bNames.sort()
   VVtP1e.append(VV6Efe)
   for item in bNames:
    VVtP1e.append((item, "__b__" + item))
  filterObj = CCZqjv(self)
  filterObj.VVHJK1(VVtP1e, VVtP1e, boundFunction(self.VVDzjm, VVrVVi))
 def VVDzjm(self, VVrVVi, item=None):
  prefix = VVrVVi.VVa9s4(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVbowJ, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVjdDv , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV7jl2 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVtQc9 , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VV0brI  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVvBq7   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVpJCu  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVraIU  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVWXPN  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVHZsz  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVLy5W   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVXTpv   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVuL7w   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVEZlP   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVjKv7   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VV6RFt  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVDacW  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVPelD  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV7jl2:
   VVtP1e = []
   chName = VVrVVi.VVa9s4(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVtP1e.append((item, item))
    if not VVtP1e and chName:
     VVtP1e.append((chName, chName))
    FF0g9p(self, boundFunction(self.VVNSXK_partOfName, title), title="Words from Current Selection", VVtP1e=VVtP1e)
   else:
    VVrVVi.VVfWYs("Invalid Channel Name")
  else:
   words, asPrefix = CCZqjv.VVl9PV(words)
   if not words and mode in (self.VVDacW, self.VVPelD):
    FFt82g(self.VVrVVi, "Incorrect filter", 2000)
   else:
    FFCkhd(self.VVrVVi, boundFunction(self.VVixTE, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVNSXK_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFCkhd(self.VVrVVi, boundFunction(self.VVixTE, self.VV7jl2, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVpbLa(txt):
  return "#f#11ffff00#" + txt
 def VVixTE(self, mode, words, asPrefix, title):
  VVvFiF = self.VVwCZB(mode=mode, words=words, asPrefix=asPrefix)
  if VVvFiF : self.VVrVVi.VV8dsB(VVvFiF, title)
  else  : self.VVrVVi.VVfWYs("Not found")
 def VVwCZB(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVvFiF = []
  files  = self.VVdTLj()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FF0FCE(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVQwvF = span.group(1)
    else : VVQwvF = ""
    VVQwvF_lCase = VVQwvF.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV4hUg(chName): chNameMod = self.VVpbLa(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVQwvF, chType, refCode, url)
     ok = False
     tUrl = FFsqcp(url).lower()
     if mode == self.VVbowJ       : ok = True
     elif mode == self.VV6RFt       : ok = True
     elif mode == self.VVWXPN:
      if CCaJkM.VVzpN1(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVHZsz:
      if CCaJkM.VVzpN1(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VV0brI:
      if CCaJkM.VVzpN1(tUrl, compareType="live")  : ok = True
     elif mode == self.VVvBq7:
      if CCaJkM.VVzpN1(tUrl, compareType="movie") : ok = True
     elif mode == self.VVpJCu:
      if CCaJkM.VVzpN1(tUrl, compareType="series") : ok = True
     elif mode == self.VVraIU:
      if CCaJkM.VVzpN1(tUrl, compareType="")   : ok = True
     elif mode == self.VVLy5W:
      if CCaJkM.VVzpN1(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVXTpv:
      if CCaJkM.VVzpN1(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVuL7w:
      if CCaJkM.VVzpN1(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVEZlP:
      if CCaJkM.VVzpN1(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVjKv7:
      if CCaJkM.VVzpN1(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVjdDv:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VV7jl2:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVtQc9:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVDacW:
      if words[0] == VVQwvF_lCase:
       ok = True
     elif mode == self.VVPelD:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVvFiF.append(row)
      chNum += 1
  if VVvFiF and mode == self.VV6RFt:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVvFiF)
   for item in VVvFiF:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVvFiF = newRows
  return VVvFiF
 def VVjoiC(self, bName):
  if bName:
   FFCkhd(self.VVrVVi, boundFunction(self.VVAWWh, bName), title="Adding Channels ...")
 def VVAWWh(self, bName):
  num = 0
  path = VVPZfu + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVPZfu + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVrVVi.VVi8Qm():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFTcL7(row[1]))
    totChange += 1
  FFE3xM(os.path.basename(path))
  self.VV8l0m(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVzqxA(self):
  txt = "Stream Type "
  VVtP1e = []
  VVtP1e.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVtP1e.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVtP1e.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVtP1e.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVtP1e.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVtP1e.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF0g9p(self, self.VVXys3, title="Change Reference Types to:", VVtP1e=VVtP1e)
 def VVXys3(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVKg3W("1"   )
   elif item == "RT_4097" : self.VVKg3W("4097")
   elif item == "RT_5001" : self.VVKg3W("5001")
   elif item == "RT_5002" : self.VVKg3W("5002")
   elif item == "RT_8192" : self.VVKg3W("8192")
   elif item == "RT_8193" : self.VVKg3W("8193")
 def VVKg3W(self, rType):
  FF7adK(self, boundFunction(FFCkhd, self, boundFunction(self.VVnbuG, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVnbuG(self, refType):
  totChange = 0
  files  = self.VVdTLj()
  if files:
   for path in files:
    txt = FF0FCE(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFE3xM(os.path.basename(path))
  self.VV8l0m(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVZEOS(self):
  totFiles = 0
  files  = self.VVdTLj()
  if files:
   totFiles = len(files)
  totChans = 0
  VVvFiF = self.VVwCZB()
  if VVvFiF:
   totChans = len(VVvFiF)
  FFuPDq(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVSCXu(self):
  files  = self.VVdTLj()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FF0FCE(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVDoEn
   else    : color = VVQy4t
   totInvalid = FFMi1p(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFMi1p("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFuPDq(self, txt, title="Check IPTV References")
 def VVq48U(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVPZfu + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFE3xM(os.path.basename(path))
  FFspal()
  acceptedList = []
  VVb5IS = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVb5IS:
   VV4PPn = FFnJtl(VVb5IS)
   if VV4PPn:
    for service in VV4PPn:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVPZfu + userBName
  bFile = VVPZfu + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFARGV("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFARGV("rm -f '%s'" % path)
  os.system(cmd)
  FFspal()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVDoEn
    else     : res, color = "No" , VVQy4t
    txt += "    %s\t: %s\n" % (item, FFMi1p(res, color))
   FFuPDq(self, txt, title=title)
  else:
   txt = FFKFol(self, "Could not complete the test on your system!", title=title)
 def VVeqMF(self):
  lameDbChans = CC6jYr.VVaFY4(self, CC6jYr.VVQvFr)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVdTLj():
    toSave = False
    txt = FF0FCE(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV8l0m(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFKFol(self, 'No channels in "lamedb" !')
 def VV4U41(self):
  files  = self.VVdTLj()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFOmkW(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVAiHo(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV8l0m(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVbNXz(self):
  iptvRefList = []
  files  = self.VVdTLj()
  if files:
   for path in files:
    txt = FF0FCE(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVrVVi.VVEDiH(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVAiHo(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVdTLj()
  if files:
   for path in files:
    lines = FFOmkW(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VV8l0m(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVAiHo(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVJRee(self):
  list = None
  if self.VVrVVi:
   list = []
   for row in self.VVrVVi.VVi8Qm():
    list.append(row[4] + row[5])
  files  = self.VVdTLj()
  totChange = 0
  if files:
   for path in files:
    lines = FFOmkW(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV8l0m(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV8l0m(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFspal()
   if refreshTable and self.VVrVVi:
    VVvFiF = self.VVwCZB()
    if VVvFiF and self.VVrVVi:
     self.VVrVVi.VV8dsB(VVvFiF, self.tableTitle)
     self.VVrVVi.VVfWYs(txt)
   FFuPDq(self, txt, title=title)
  else:
   FFo08k(self, "No changes.")
 def VVttGc(self):
  files = self.VVdTLj()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVa1mu = FFmPDO()
    if VVa1mu:
     for b in VVa1mu:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVdTLj(self):
  return CCaJkM.VVZtqb(self)
 @staticmethod
 def VVZtqb(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVPZfu + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FF0FCE(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVqwt5(self, VVrVVi, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFsqcp(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFLiV2(self, fncMode=CCe5Io.VVLLZc, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVw8hT(self, fromPlayer, VVrVVi, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVelxU(fromPlayer, VVrVVi, chName, chUrl, "localIptv")
 def VVXbur(self, mode, fromPlayer, VVrVVi, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVirxj(mode, colList)
  self.VVelxU(fromPlayer, VVrVVi, chName, chUrl, mode)
 def VVelxU(self, fromPlayer, VVrVVi, chName, chUrl, playerFlag):
  chName = FFTcL7(chName)
  if fromPlayer:
   self.VVXZwO(VVrVVi, chUrl, playerFlag)
  elif self.VV4hUg(chName):
   FFt82g(VVrVVi, "This is a marker!", 300)
  else:
   FFCkhd(VVrVVi, boundFunction(self.VVXZwO, VVrVVi, chUrl, playerFlag), title="Playing ...")
 def VVXZwO(self, VVrVVi, chUrl, playerFlag):
  FFKzCJ(self, chUrl, VVDaMP=False)
  self.session.open(CCD9VV, portalTableParam=(self, VVrVVi, playerFlag))
 @staticmethod
 def VV4hUg(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVMw7a(self, VVrVVi, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  if refCode:
   bName = FFmxjr()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFSFL7(refCode, origUrl, chName) }
   VVrVVi.VVGhyU_partial(colDict, VVebv7=True)
 def VVrTXs(self):
  self.session.open(CC2SNv)
  self.close()
 def VVtZOW(self, m3uMode):
  lines = FFhQrI("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFgUhe(1))
  if lines:
   lines.sort()
   VVtP1e = []
   for line in lines:
    VVtP1e.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVhCvA = ("All to Playlist", self.VVOmVP)
   else    : VVhCvA = None
   OKBtnFnc = boundFunction(self.VVEAe6, m3uMode, title)
   VV0Jrh = ("Show Full Path", self.VVoUSS)
   FF0g9p(self, None, title=title, VVtP1e=VVtP1e, OKBtnFnc=OKBtnFnc, VV0Jrh=VV0Jrh, VVhCvA=VVhCvA)
  else:
   FFKFol(self, 'No "m3u" files found.')
 def VVoUSS(self, VVgdWRObj, url):
  FFuPDq(self, url, title="Full Path")
 def VVEAe6(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFCkhd(menuInstance, boundFunction(self.VVxIVD, title, path))
   elif m3uMode == 1 : self.VVMtJV(title, path)
   else    : self.VViWBp(menuInstance, path)
 def VVOmVP(self, VVgdWRObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVgdWRObj.VVtP1e):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVatt9(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    pListF = "%sPlaylist_%s.txt" % (FFExru(CFG.exportedTablesPath.getValue()), FFtTMB())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVgdWRObj.VVtP1e)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFuPDq(self, txt, title=title)
   else:
    FFKFol(self, "Could not obtain URLs from this file list !", title=title)
 def VVMtJV(self, title, path):
  if fileExists(path):
   self.session.open(CC1gln, barTheme=CC1gln.VVgiaG
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVNce8, path)
       , VVfbK6 = boundFunction(self.VVxr01, title, path))
  else:
   FFKFol(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVxr01(self, title, path, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  if VVcfNz:
   FFuPDq(self, VVof9j, title=title)
 def VVNce8(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FF0FCE(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVof9j = ""
  progBarObj.VVQxG2(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVd70M(1, True)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FFsqcp(tUrl).lower()
   chType, host, username, password, streamId, chName = CCaJkM.VVzpN1(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCaJkM.VVzpN1(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FFMi1p("File:\n", VVVNGK)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FFMi1p("Channels:\n", VVVNGK)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFMi1p("Category:\n", VVVNGK)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFMi1p("Content:\n", VVVNGK)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    No channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VVof9j = txt
 def VVKdCw(self, isBrowseServer):
  lines = FFhQrI('find / %s -iname "*playlist*" | grep -i ".txt"' % FFgUhe(1))
  if lines:
   lines.sort()
   VVtP1e = []
   for line in lines:
    VVtP1e.append((line, line))
   OKBtnFnc = boundFunction(self.VV9CFC, isBrowseServer)
   FF0g9p(self, None, title="Select Playlist File", VVtP1e=VVtP1e, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFtist(self, "( playlist.txt  or  playlists.txt )")
 def VV9CFC(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFCkhd(menuInstance, boundFunction(self.VV6B4j, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VV6B4j(self, fileMenuInstance, path, isBrowseServer):
  VVtP1e = []
  lines = FFOmkW(path)
  for line in lines:
   line = line.strip()
   span = iSearch(r"(http.+php.+username=.+password=.+)(?:[&]+)*", line, IGNORECASE)
   if span:
    VVtP1e.append((span.group(1), span.group(1)))
   else:
    span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
    if span:
     host = FFExru(span.group(1).strip())
     user1 = span.group(2).strip()
     pass1 = span.group(3).strip()
     line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
     VVtP1e.append((line, line))
  if VVtP1e:
   if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVtP1e)
   else    : title = "Convert to Bouquet"
   OKBtnFnc  = boundFunction(self.VVswEc, isBrowseServer, title)
   VVxdDY  = ("Home Menu"  , FFz3mf)
   VV0Jrh  = ("Show URL"  , self.VVltBQ)
   VVhCvA   = ("Check & Filter" , boundFunction(self.VVTuCg, fileMenuInstance, path, isBrowseServer))
   FF0g9p(self, None, title=title, VVtP1e=VVtP1e, width=1200, OKBtnFnc=OKBtnFnc, VVxdDY=VVxdDY, VV0Jrh=VV0Jrh, VVhCvA=VVhCvA)
  else:
   FFKFol(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVltBQ(self, VVgdWRObj, url):
  FFuPDq(self, url, title="URL")
 def VVswEc(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFCkhd(menuInstance, boundFunction(self.VVddrD, title, url), title="Checking Server ...")
   else:
    FF7adK(self, boundFunction(FFCkhd, menuInstance, boundFunction(self.VVGx1e, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVGx1e(self, menuInstance, url):
  path, err = FFUMM6(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFKFol(self, err, title=title)
  else:
   if fileExists(path):
    txt = FF0FCE(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFKFol(self, "Unauthorized", title=title)
     os.system(FFARGV("rm -f '%s'" % path))
     return
   self.VViWBp(menuInstance, path)
 def VVdELz(self, title):
  curChName = self.VVrVVi.VVa9s4(1)
  FFXtIF(self, boundFunction(self.VV5L6N, title), defaultText=curChName, title=title, message="Enter Name:")
 def VV5L6N(self, title, name):
  if name:
   lameDbChans = CC6jYr.VVaFY4(self, CC6jYr.VVFrLC, VV2fu3=False, VVr6p9=False)
   list = []
   if lameDbChans:
    for item in lameDbChans:
     if name in item[0]:
      list.append((item[0], item[2], item[3]))
   if list : self.VVClhc(list, title)
   else : FFKFol(self, "Not found:\n\n%s" % name, title=title)
 def VV80Wg(self, title):
  curChName = self.VVrVVi.VVa9s4(1)
  self.session.open(CC1gln, barTheme=CC1gln.VVgiaG
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVnJwQ
      , VVfbK6 = boundFunction(self.VVsp5K, title, curChName))
 def VVnJwQ(self, progBarObj):
  curChName = self.VVrVVi.VVa9s4(1)
  lameDbChans = CC6jYr.VVaFY4(self, CC6jYr.VVByhd, VV2fu3=False, VVr6p9=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVof9j = []
  progBarObj.VVQxG2(len(lameDbChans))
  curCh = curChName.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").strip()
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCc7kl.VVrXub(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVd70M(1, True)
   if ratio > 50:
    progBarObj.VVof9j.append((chName, FF1zZi(sat), refCode.replace("_", ":")))
 def VVsp5K(self, title, curChName, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  if VVcfNz:
   if VVof9j : self.VVClhc(VVof9j, title)
   else   : FFKFol(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVClhc(self, VVvFiF, title):
  curChName = self.VVrVVi.VVa9s4(1)
  curRefCode = self.VVrVVi.VVa9s4(4)
  curUrl  = self.VVrVVi.VVa9s4(5)
  VVvFiF.sort(key=lambda x: x[0].lower())
  VVWoa9  = ("Share Sat/C/T Ref.", boundFunction(self.VVm7x0, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" )
  widths   = (34  , 33  , 33   )
  FFaufo(self, None, title=title, header=header, VV7oZO=VVvFiF, VVAF36=widths, VVpwbP=24, VVWoa9=VVWoa9, VVOM9K="#0a00112B", VVpOBz="#0a001126", VVpeGc="#0a001126", VVrGdv="#00000000")
 def VVm7x0(self, newtitle, curChName, curRefCode, curUrl, VVrVVi, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FF7adK(self.VVrVVi, boundFunction(FFCkhd, self.VVrVVi, boundFunction(self.VVqXNo, VVrVVi, data)), ques, title=newtitle, VVkpWv=True)
 def VVqXNo(self, VVrVVi, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVdTLj():
    txt = FF0FCE(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFspal()
    newRow = []
    for i in range(6):
     newRow.append(self.VVrVVi.VVa9s4(i))
    newRow[4] = newRefCode
    done = self.VVrVVi.VVfBGF(newRow)
    FFo08k(self, "Done", title=title)
   else:
    FFKFol(self, "Not found in IPTV files !", title=title)
  else:
   FFKFol(self, "Could not read channel info !", title=title)
  VVrVVi.cancel()
 def VVTuCg(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, item):
  self.session.open(CC1gln, barTheme=CC1gln.VVgiaG
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVMu1N, urlMenuInstance)
      , VVfbK6 = boundFunction(self.VVCU6u, fileMenuInstance, path, isBrowseServer, urlMenuInstance))
 def VVMu1N(self, urlMenuInstance, progBarObj):
  progBarObj.VVQxG2(len(urlMenuInstance.VVtP1e))
  progBarObj.VVof9j = []
  for ndx, item in enumerate(urlMenuInstance.VVtP1e):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVd70M(1, True)
   qUrl = self.VVrp61(self.VVi32w, item[0])
   txt, err = self.VVprsV(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVNnYa(item, "auth") == "0":
       progBarObj.VVof9j.append(qUrl)
    except:
     pass
 def VVCU6u(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  if VVcfNz:
   list = VVof9j
   title = "Authorized Servers"
   if list:
    totChk = len(urlMenuInstance.VVtP1e)
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFtTMB()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVKdCw(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFMi1p(str(totAuth), VVDoEn)
     txt += "%s\n\n%s"     %  (FFMi1p("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFuPDq(self, txt, title=title)
     urlMenuInstance.close()
     fileMenuInstance.close()
    else:
     FFo08k(self, "All URLs are authorized.", title=title)
   else:
    FFKFol(self, "No authorized URL found !", title=title)
 def VViWBp(self, parentInstant, path):
  files = CCaJkM.VVZtqb(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCaJkM.VVlDm7(parentInstant, path, exitCurWin)
 @staticmethod
 def VVlDm7(SELF, path, exitCurWin):
  FF7adK(SELF, boundFunction(FFCkhd, SELF, boundFunction(CCaJkM.VVeuKn, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVeuKn(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFKFol(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCaJkM.VVwlum(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVPZfu + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVPZfu + bFileName):
     bName = tmpBName
     break
  txt = FF0FCE(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVPZfu + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFSDkN(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFE3xM(bFileName)
   FFspal()
   FFo08k(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFKFol(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVprsV(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVVuNO(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVzpN1(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVrp61(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVVuNO(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVi32w   : return "%s"            % url
  elif mode == self.VV6DkX   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVQRgb   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVQXlB  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVTAkE : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVXca4   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVvJIy    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVvGos  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVg0Ir  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVLsDI  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VV1hHp : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VV125S   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVNnYa(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFMoES(int(val))
    elif is_base64 : val = FFNh3o(val)
    elif isToHHMMSS : val = FFUeKr(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVxIVD(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVatt9(line)
     if qUrl:
      break
   if qUrl : self.VVddrD(title, qUrl)
   else : FFKFol(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFKFol(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV3FAM_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVrTHl()
  if qUrl:
   host, mac, isPortalUrl = self.VVgFiN(iptvRef)
   if isPortalUrl:
    if host and mac : self.VV3FAM(self, host, mac)
    else   : FFKFol(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFCkhd(self, boundFunction(self.VVddrD, title, qUrl), title="Checking Server ...")
  else:
   FFKFol(self, "Error in current channel URL !", title=title)
 def VVrTHl(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  qUrl = self.VVatt9(decodedUrl)
  return qUrl, iptvRef
 def VVatt9(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVddrD(self, title, url):
  self.VVRMpbData = {}
  qUrl = self.VVrp61(self.VVi32w, url)
  txt, err = self.VVprsV(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVRMpbData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVRMpbData["username"    ] = self.VVNnYa(item, "username"        )
    self.VVRMpbData["password"    ] = self.VVNnYa(item, "password"        )
    self.VVRMpbData["message"    ] = self.VVNnYa(item, "message"        )
    self.VVRMpbData["auth"     ] = self.VVNnYa(item, "auth"         )
    self.VVRMpbData["status"    ] = self.VVNnYa(item, "status"        )
    self.VVRMpbData["exp_date"    ] = self.VVNnYa(item, "exp_date"    , isDate=True )
    self.VVRMpbData["is_trial"    ] = self.VVNnYa(item, "is_trial"        )
    self.VVRMpbData["active_cons"   ] = self.VVNnYa(item, "active_cons"       )
    self.VVRMpbData["created_at"   ] = self.VVNnYa(item, "created_at"   , isDate=True )
    self.VVRMpbData["max_connections"  ] = self.VVNnYa(item, "max_connections"      )
    self.VVRMpbData["allowed_output_formats"] = self.VVNnYa(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVRMpbData[key] = lst
    item = tDict["server_info"]
    self.VVRMpbData["url"    ] = self.VVNnYa(item, "url"        )
    self.VVRMpbData["port"    ] = self.VVNnYa(item, "port"        )
    self.VVRMpbData["https_port"  ] = self.VVNnYa(item, "https_port"      )
    self.VVRMpbData["server_protocol" ] = self.VVNnYa(item, "server_protocol"     )
    self.VVRMpbData["rtmp_port"   ] = self.VVNnYa(item, "rtmp_port"       )
    self.VVRMpbData["timezone"   ] = self.VVNnYa(item, "timezone"       )
    self.VVRMpbData["timestamp_now"  ] = self.VVNnYa(item, "timestamp_now"  , isDate=True )
    self.VVRMpbData["time_now"   ] = self.VVNnYa(item, "time_now"       )
    VVtP1e  = self.VVoCIC()
    OKBtnFnc = self.VVRMpbOptions
    VVxdDY = ("Home Menu", FFz3mf)
    FF0g9p(self, None, title="IPTV Server Resources", VVtP1e=VVtP1e, OKBtnFnc=OKBtnFnc, VVxdDY=VVxdDY)
   else:
    err = "Could not get data from server !"
  if err:
   FFKFol(self, err, title=title)
  FFt82g(self)
 def VVRMpbOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFCkhd(menuInstance, boundFunction(self.VVtvrx, self.VV6DkX , title=title), title=wTxt)
   elif ref == "vod"   : FFCkhd(menuInstance, boundFunction(self.VVtvrx, self.VVQRgb , title=title), title=wTxt)
   elif ref == "series"  : FFCkhd(menuInstance, boundFunction(self.VVtvrx, self.VVQXlB, title=title), title=wTxt)
   elif ref == "accountInfo" : FFCkhd(menuInstance, boundFunction(self.VVXqP2          , title=title), title=wTxt)
 def VVXqP2(self, title):
  rows = []
  for key, val in self.VVRMpbData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVzi3l = ("Home Menu", FFz3mf, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFaufo(self, None, title=title, header=header, VV7oZO=rows, VVAF36=widths, VVpwbP=26, VVzi3l=VVzi3l, VVOM9K="#0a00292B", VVpOBz="#0a002126", VVpeGc="#0a002126", VVrGdv="#00000000", searchCol=2)
 def VVgZ0D(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCf9q3()
    if mode == self.VVXca4:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVNnYa(item, "num"         )
      name     = self.VVNnYa(item, "name"        )
      stream_id    = self.VVNnYa(item, "stream_id"       )
      stream_icon    = self.VVNnYa(item, "stream_icon"       )
      epg_channel_id   = self.VVNnYa(item, "epg_channel_id"      )
      added     = self.VVNnYa(item, "added"    , isDate=True )
      is_adult    = self.VVNnYa(item, "is_adult"       )
      category_id    = self.VVNnYa(item, "category_id"       )
      name = processChanName.VV9sZh(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVvJIy:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVNnYa(item, "num"         )
      name    = self.VVNnYa(item, "name"        )
      stream_id   = self.VVNnYa(item, "stream_id"       )
      stream_icon   = self.VVNnYa(item, "stream_icon"       )
      added    = self.VVNnYa(item, "added"    , isDate=True )
      is_adult   = self.VVNnYa(item, "is_adult"       )
      category_id   = self.VVNnYa(item, "category_id"       )
      container_extension = self.VVNnYa(item, "container_extension"     ) or "mp4"
      name = processChanName.VV9sZh(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVvGos:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVNnYa(item, "num"        )
      name    = self.VVNnYa(item, "name"       )
      series_id   = self.VVNnYa(item, "series_id"      )
      cover    = self.VVNnYa(item, "cover"       )
      genre    = self.VVNnYa(item, "genre"       )
      episode_run_time = self.VVNnYa(item, "episode_run_time"    )
      category_id   = self.VVNnYa(item, "category_id"      )
      container_extension = self.VVNnYa(item, "container_extension"    ) or "mp4"
      name = processChanName.VV9sZh(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVtvrx(self, mode, title):
  qUrl = self.VVrp61(mode, self.VVRMpbData["playListURL"])
  txt, err = self.VVprsV(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    hideAdult = CFG.hideIptvServerAdultWords.getValue()
    tDict = jLoads(txt)
    if tDict:
     processChanName = CCf9q3()
     for item in tDict:
      category_id  = self.VVNnYa(item, "category_id"  )
      category_name = self.VVNnYa(item, "category_name" )
      parent_id  = self.VVNnYa(item, "parent_id"  )
      category_name = processChanName.VVtcuI(category_name)
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   err = "Server Error:\n\n" + err
  if err:
   FFKFol(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI(mode)
   mName = self.VVZe91(mode)
   if   mode == self.VV6DkX  : fMode, okTitle = self.VVXca4 , "Show Channels"
   elif mode == self.VVQRgb  : fMode, okTitle = self.VVvJIy , "Show Channels"
   elif mode == self.VVQXlB : fMode, okTitle = self.VVvGos, "Show List"
   VVB4oX = ("Find in %s" % mName , boundFunction(self.VVH7NN, fMode) , [])
   VVWoa9  = (okTitle    , boundFunction(self.VVIIPm, mode) , [])
   VVzi3l = ("Home Menu"   , FFz3mf          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFaufo(self, None, title=title, header=header, VV7oZO=list, VVAF36=widths, VVpwbP=30, VVzi3l=VVzi3l, VVB4oX=VVB4oX, VVWoa9=VVWoa9, VVOM9K=VVOM9K, VVpOBz=VVpOBz, VVpeGc=VVpeGc, VVrGdv=VVrGdv)
  else:
   FFKFol(self, "No list from server !", title=title)
  FFt82g(self)
 def VVIIPm(self, mode, VVrVVi, title, txt, colList):
  title = colList[1]
  FFCkhd(VVrVVi, boundFunction(self.VVXpEO, mode, VVrVVi, title, txt, colList), title="Downloading ...")
 def VVXpEO(self, mode, VVrVVi, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVZe91(mode) + " : "+ bName
  if   mode == self.VV6DkX  : mode = self.VVXca4
  elif mode == self.VVQRgb  : mode = self.VVvJIy
  elif mode == self.VVQXlB : mode = self.VVvGos
  qUrl  = self.VVrp61(mode, self.VVRMpbData["playListURL"], catID)
  txt, err = self.VVprsV(qUrl)
  list  = []
  if not err and mode in (self.VVXca4, self.VVvJIy, self.VVvGos):
   list, err = self.VVgZ0D(mode, txt)
  if err:
   FFKFol(self, err, title=title)
  elif list:
   VVzi3l  = ("Home Menu"   , FFz3mf            , [])
   if mode == self.VVXca4:
    VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI(mode)
    VVWoa9  = ("Play"    , boundFunction(self.VVXbur, mode, False)  , [])
    VVRzGo = (""     , boundFunction(self.VVyAa6, mode)    , [])
    VVredj = ("Download PIcons" , boundFunction(self.VVPRc4, mode)    , [])
    VVB4oX = ("Add ALL to Bouquet" , boundFunction(self.VV0xCc, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVpYfQ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVvJIy:
    VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI(mode)
    VVWoa9  = ("Play"    , boundFunction(self.VVXbur, mode, False)  , [])
    VVRzGo = (""     , boundFunction(self.VVyAa6, mode)    , [])
    VVredj = ("Download PIcons" , boundFunction(self.VVPRc4, mode)    , [])
    VVB4oX = ("Add ALL to Bouquet" , boundFunction(self.VV0xCc, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVpYfQ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVvGos:
    VVOM9K, VVpOBz, VVpeGc, VVrGdv = self.VV0TEI("series2")
    VVWoa9  = ("Show Seasons", boundFunction(self.VVJ68H, mode) , [])
    VVRzGo = ("", boundFunction(self.VVeB5k, mode)  , [])
    VVredj = None
    VVB4oX = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVpYfQ  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFaufo(self, None, title=title, header=header, VV7oZO=list, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=26, VVWoa9=VVWoa9, VVzi3l=VVzi3l, VVredj=VVredj, VVB4oX=VVB4oX, VVRzGo=VVRzGo, VVOM9K=VVOM9K, VVpOBz=VVpOBz, VVpeGc=VVpeGc, VVrGdv=VVrGdv, VV34E6=True, searchCol=1)
  else:
   FFKFol(self, "No Channels found !", title=title)
  FFt82g(self)
 def VVJ68H(self, mode, VVrVVi, title, txt, colList):
  title = colList[1]
  FFCkhd(VVrVVi, boundFunction(self.VVJTjj, mode, VVrVVi, title, txt, colList), title="Downloading ...")
 def VVJTjj(self, mode, VVrVVi, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVrp61(self.VVTAkE, self.VVRMpbData["playListURL"], series_id)
  txt, err = self.VVprsV(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVNnYa(tDict["info"], "name"   )
      category_id = self.VVNnYa(tDict["info"], "category_id" )
      icon  = self.VVNnYa(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVNnYa(EP, "id"     )
        episode_num   = self.VVNnYa(EP, "episode_num"   )
        epTitle    = self.VVNnYa(EP, "title"     )
        container_extension = self.VVNnYa(EP, "container_extension" )
        seasonNum   = self.VVNnYa(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFKFol(self, err, title=title)
  elif list:
   VVzi3l = ("Home Menu"   , FFz3mf            , [])
   VVredj = ("Download PIcons" , boundFunction(self.VVPRc4 , mode)   , [])
   VVB4oX = ("Add ALL to Bouquet" , boundFunction(self.VV0xCc, mode, title) , [])
   VVRzGo = (""     , boundFunction(self.VVyAa6, mode)    , [])
   VVWoa9  = ("Play"    , boundFunction(self.VVXbur, mode, False)  , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVpYfQ  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFaufo(self, None, title=title, header=header, VV7oZO=list, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=26, VVzi3l=VVzi3l, VVredj=VVredj, VVWoa9=VVWoa9, VVRzGo=VVRzGo, VVB4oX=VVB4oX, VVOM9K="#0a00292B", VVpOBz="#0a002126", VVpeGc="#0a002126", VVrGdv="#00000000")
  else:
   FFKFol(self, "No Channels found !", title=title)
  FFt82g(self)
 def VVH7NN(self, mode, VVrVVi, title, txt, colList):
  VVtP1e = []
  VVtP1e.append(("Keyboard"  , "manualEntry"))
  VVtP1e.append(("From Filter" , "fromFilter"))
  FF0g9p(self, boundFunction(self.VVFcnA, VVrVVi, mode), title="Input Type", VVtP1e=VVtP1e, width=400)
 def VVFcnA(self, VVrVVi, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFXtIF(self, boundFunction(self.VVDHTn, VVrVVi, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCZqjv(self)
    filterObj.VVka1I(boundFunction(self.VVDHTn, VVrVVi, mode))
 def VVDHTn(self, VVrVVi, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCf9q3()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVurlX(words):
     FFKFol(self, processChanName.VVXAhR(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CC1gln, barTheme=CC1gln.VVgiaG
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVd7WC, VVrVVi, mode, title, words, toFind, asPrefix, processChanName)
         , VVfbK6 = boundFunction(self.VVeMbc, mode, toFind, title))
   else:
    FFKFol(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVd7WC(self, VVrVVi, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVQxG2(VVrVVi.VV2xMj())
  progBarObj.VVof9j = []
  for row in VVrVVi.VVi8Qm():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVd70M(1)
   progBarObj.VVHEqD_fromIptvFind(catName)
   qUrl  = self.VVrp61(mode, self.VVRMpbData["playListURL"], catID)
   txt, err = self.VVprsV(qUrl)
   if not err:
    tList, err = self.VVgZ0D(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VV9sZh(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVXca4:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVof9j.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVvJIy:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVof9j.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVvGos:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVof9j.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVeMbc(self, mode, toFind, title, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  if VVof9j:
   title = self.VV8ZQu(mode, toFind)
   if mode == self.VVXca4 or mode == self.VVvJIy:
    bName   = CCaJkM.VVwlum(toFind)
    VVWoa9  = ("Play"     , boundFunction(self.VVXbur, mode, False)  , [])
    VVB4oX = ("Add ALL to Bouquet" , boundFunction(self.VV0xCc, mode, bName) , [])
    VVredj = ("Download PIcons" , boundFunction(self.VVPRc4, mode)    , [])
   elif mode == self.VVvGos:
    VVWoa9  = ("Show Seasons"  , boundFunction(self.VVJ68H, mode)    , [])
    VVB4oX = None
    VVredj = None
   VVRzGo = (""   , boundFunction(self.VVyAa6, mode) , [])
   VVzi3l = ("Home Menu" , FFz3mf         , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVpYfQ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVrVVi = FFaufo(self, None, title=title, header=header, VV7oZO=VVof9j, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=26, VVWoa9=VVWoa9, VVzi3l=VVzi3l, VVredj=VVredj, VVB4oX=VVB4oX, VVRzGo=VVRzGo, VVOM9K="#0a00292B", VVpOBz="#0a002126", VVpeGc="#0a002126", VVrGdv="#00000000", VV34E6=True, searchCol=1)
   if not VVcfNz:
    FFt82g(VVrVVi, "Stopped" , 1000)
  else:
   if VVcfNz:
    FFKFol(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVirxj(self, mode, colList):
  if mode == self.VVXca4:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVvJIy:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFTcL7(chName)
  url = self.VVRMpbData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVVuNO(url)
  refCode = self.VVNzIw(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVyAa6(self, mode, VVrVVi, title, txt, colList):
  FFCkhd(VVrVVi, boundFunction(self.VVUh6V, mode, VVrVVi, title, txt, colList))
 def VVUh6V(self, mode, VVrVVi, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVirxj(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFLiV2(self, fncMode=CCe5Io.VVhaRq, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVeB5k(self, mode, VVrVVi, title, txt, colList):
  FFCkhd(VVrVVi, boundFunction(self.VVhXV7, mode, VVrVVi, title, txt, colList))
 def VVhXV7(self, mode, VVrVVi, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFLiV2(self, fncMode=CCe5Io.VV4Tdt, chName=name, text=txt, picUrl=Cover)
 def VV0xCc(self, mode, bName, VVrVVi, title, txt, colList):
  FFCkhd(VVrVVi, boundFunction(self.VVfEEc, mode, bName, VVrVVi, title, txt, colList), title="Adding Channels ...")
 def VVfEEc(self, mode, bName, VVrVVi, title, txt, colList):
  url = self.VVRMpbData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVVuNO(url)
  bNameFile = CCaJkM.VVwlum(bName)
  num  = 0
  path = VVPZfu + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVPZfu + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVrVVi.VVi8Qm():
    chName, chUrl, picUrl, refCode = self.VVirxj(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFE3xM(os.path.basename(path))
  self.VV8l0m(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVPRc4(self, mode, VVrVVi, title, txt, colList):
  if os.system(FFARGV("which ffmpeg")) == 0:
   self.session.open(CC1gln, barTheme=CC1gln.VVFy9w
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVxwLA, VVrVVi, mode)
       , VVfbK6 = self.VV6nQM)
  else:
   FF7adK(self, self.VVX2FH, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VV6nQM(self, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVof9j["proces"], VVof9j["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVof9j["ok"], VVof9j["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVof9j["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVof9j["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVof9j["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVof9j["path"]
  if not VVcfNz  : color = "#11402000"
  elif VVof9j["err"]: color = "#11201000"
  else     : color = None
  if VVof9j["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVof9j["err"], txt)
  title = "PIcons Download Result"
  if not VVcfNz:
   title += "  (cancelled)"
  FFuPDq(self, txt, title=title, VVpeGc=color)
 def VVxwLA(self, VVrVVi, mode, progBarObj):
  totRows = VVrVVi.VV2xMj()
  progBarObj.VVQxG2(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCc7kl.VVGkn8()
  progBarObj.VVof9j = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVrVVi.VVi8Qm():
    if progBarObj.isCancelled:
     break
    progBarObj.VVof9j["proces"] += 1
    progBarObj.VVd70M(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVqhif(mode, row)
     refCode = CCaJkM.VVNzIw(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVirxj(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVof9j["attempt"] += 1
      path, err = FFUMM6(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVof9j["ok"] += 1
       if FFufc8(path) > 0:
        cmd = ""
        if not mode == CCaJkM.VVXca4:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFARGV("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVof9j["size0"] += 1
        os.system(FFARGV("rm -f '%s'" % path))
      elif err:
       progBarObj.VVof9j["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVof9j["err"] = err.title()
        break
     else:
      progBarObj.VVof9j["exist"] += 1
    else:
     progBarObj.VVof9j["badURL"] += 1
  except:
   pass
 def VVX2FH(self):
  cmd = FFzJLp(VVOWgY, "ffmpeg")
  if cmd : FFxQD8(self, cmd, title="Installing FFmpeg")
  else : FFk6P3(self)
 @staticmethod
 def VVNzIw(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCaJkM.VVNyuQ(catID, MAX_4b)
  TSID = CCaJkM.VVNyuQ(chNum, MAX_4b)
  ONID = CCaJkM.VVNyuQ(chNum, MAX_4b)
  NS  = CCaJkM.VVNyuQ(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVNyuQ(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVwlum(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CCJsiF(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VV1L0x  = 0
  self.VV52e4 = 1
  self.VV7ZqB  = 2
  VVtP1e = []
  VVtP1e.append(("Find All (from filter)"    , "VVU1RA" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Find All"        , "VVMkhM"    ))
  VVtP1e.append(("Find TV"        , "VVLlc9"    ))
  VVtP1e.append(("Find Radio"       , "VVQzz7"   ))
  if self.VV8xKJ():
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Hide Channel: %s" % self.servName , "VVbq3C"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Zap History"       , "VVkAP1"    ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("PIcons Tools"       , "PIconsTools"     ))
  VVtP1e.append(("Channels Tools"      , "ChannelsTools"    ))
  FF7MWH(self, VVtP1e=VVtP1e, title=title)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
  if self.isFindMode:
   self.VV1lM4(self.VVtPGf())
 def VV8nYP(self):
  global VVVIjd
  VVVIjd = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVMkhM"    : self.VVMkhM()
   elif item == "VVU1RA" : self.VVU1RA()
   elif item == "VVLlc9"    : self.VVLlc9()
   elif item == "VVQzz7"   : self.VVQzz7()
   elif item == "VVbq3C"   : self.VVbq3C()
   elif item == "VVkAP1"    : self.VVkAP1()
   elif item == "PIconsTools"     : self.session.open(CCc7kl)
   elif item == "ChannelsTools"    : self.session.open(CC6jYr)
 def VVLlc9(self) : self.VV1lM4(self.VV1L0x)
 def VVQzz7(self) : self.VV1lM4(self.VV52e4)
 def VVMkhM(self) : self.VV1lM4(self.VV7ZqB)
 def VV1lM4(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFXtIF(self, boundFunction(self.VVpoD5, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVU1RA(self):
  filterObj = CCZqjv(self)
  filterObj.VVka1I(self.VVkXDB)
 def VVkXDB(self, item):
  self.VVpoD5(self.VV7ZqB, item)
 def VV8xKJ(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFMSfm(self.refCode)        : return False
  return True
 def VVpoD5(self, mode, VVeqK8):
  FFCkhd(self, boundFunction(self.VVdkdi, mode, VVeqK8), title="Searching ...")
 def VVdkdi(self, mode, VVeqK8):
  if VVeqK8:
   self.findTxt = VVeqK8
   if   mode == self.VV1L0x  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV52e4 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVeqK8)
   if len(title) > 55:
    title = title[:55] + ".."
   VVvFiF = self.VVYT5r(VVeqK8, servTypes)
   if self.isFindMode or mode == self.VV7ZqB:
    VVvFiF += self.VVpl4E(VVeqK8)
   if VVvFiF:
    VVvFiF.sort(key=lambda x: x[0].lower())
    VVYpBL = self.VVC24W
    VVWoa9  = ("Zap"   , self.VVIJln    , [])
    VVredj = ("Current Service", self.VV3Nfl , [])
    VVB4oX = ("Options"  , self.VVQmcC , [])
    VVRzGo = (""    , self.VVsQAE , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVpYfQ  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFaufo(self, None, title=title, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=25, VVWoa9=VVWoa9, VVYpBL=VVYpBL, VVredj=VVredj, VVB4oX=VVB4oX, VVRzGo=VVRzGo)
   else:
    self.VV1lM4(self.VVtPGf())
    FFo08k(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVYT5r(self, VVeqK8, servTypes):
  VVxNcv  = eServiceCenter.getInstance()
  VV92rI   = '%s ORDER BY name' % servTypes
  VVVKlL   = eServiceReference(VV92rI)
  VVHpma = VVxNcv.list(VVVKlL)
  if VVHpma: VV7oZO = VVHpma.getContent("CN", False)
  else     : VV7oZO = None
  VVvFiF = []
  if VV7oZO:
   VVv6KF, VVv0kN = FFzIwD()
   tp   = CCfC6J()
   words, asPrefix = CCZqjv.VVl9PV(VVeqK8)
   colorYellow  = CCecW4.VVXMXe(VVIuu8)
   colorWhite  = CCecW4.VVXMXe(VVkCrP)
   for s in VV7oZO:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFZ41o(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVv6KF:
        STYPE = VVv0kN[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV9ftU(refCode)
       if not "-S" in syst:
        sat = syst
       VVvFiF.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVvFiF
 def VVpl4E(self, VVeqK8):
  VVeqK8 = VVeqK8.lower()
  VVa1mu = FFmPDO()
  VVvFiF = []
  colorYellow  = CCecW4.VVXMXe(VVIuu8)
  colorWhite  = CCecW4.VVXMXe(VVkCrP)
  if VVa1mu:
   for b in VVa1mu:
    VVQwvF  = b[0]
    VVcRaw  = b[1].toString()
    VVb5IS = eServiceReference(VVcRaw)
    VV4PPn = FFnJtl(VVb5IS)
    for service in VV4PPn:
     refCode  = service[0]
     if FFMSfm(refCode):
      servName = service[1]
      if VVeqK8 in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVeqK8), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVvFiF.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVvFiF
 def VVtPGf(self):
  VVgvOe = InfoBar.instance
  if VVgvOe:
   VVwOzf = VVgvOe.servicelist
   if VVwOzf:
    return VVwOzf.mode == 1
  return self.VV7ZqB
 def VVC24W(self, VVrVVi):
  self.close()
  VVrVVi.cancel()
 def VVIJln(self, VVrVVi, title, txt, colList):
  FFKzCJ(VVrVVi, colList[2], VVDaMP=False, checkParentalControl=True)
 def VV3Nfl(self, VVrVVi, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(VVrVVi)
  if refCode:
   VVrVVi.VVA9bS(2, FFSFL7(refCode, iptvRef, chName), True)
 def VVQmcC(self, VVrVVi, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CChZFz(self, VVrVVi, 2)
  mSel.VVzCqc(servName, refCode)
 def VVsQAE(self, VVrVVi, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFLiV2(self, fncMode=CCe5Io.VVEgpt, refCode=refCode, chName=chName, text=txt)
 def VVbq3C(self):
  FF7adK(self, self.VVvXP4, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVvXP4(self):
  ret = FF0QjM(self.refCode, True)
  if ret:
   self.VVkoIL()
   self.close()
  else:
   FFt82g(self, "Cannot change state" , 1000)
 def VVkoIL(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVMVxL()
  except:
   self.VV6SDc()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFzIxv(self, serviceRef)
 def VVTRmy(self):
  VVgvOe = InfoBar.instance
  if VVgvOe:
   VVwOzf = VVgvOe.servicelist
   if VVwOzf:
    VVwOzf.setMode()
 def VVMVxL(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVgvOe = InfoBar.instance
   if VVgvOe:
    VVwOzf = VVgvOe.servicelist
    if VVwOzf:
     hList = VVwOzf.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVwOzf.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVwOzf.history  = newList
       VVwOzf.history_pos = pos
 def VV6SDc(self):
  VVgvOe = InfoBar.instance
  if VVgvOe:
   VVwOzf = VVgvOe.servicelist
   if VVwOzf:
    VVwOzf.history  = []
    VVwOzf.history_pos = 0
 def VVkAP1(self):
  VVgvOe = InfoBar.instance
  VVvFiF = []
  if VVgvOe:
   VVwOzf = VVgvOe.servicelist
   if VVwOzf:
    VVv6KF, VVv0kN = FFzIwD()
    for chParams in VVwOzf.history:
     refCode = chParams[-1].toString()
     chName = FFLYCF(refCode)
     isIptv = FFMSfm(refCode)
     if isIptv: sat = "-"
     else  : sat = FFZ41o(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVv6KF:
       STYPE = VVv0kN[sTypeInt]
     VVvFiF.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVvFiF:
   VVWoa9  = ("Zap"   , self.VVXFud   , [])
   VVB4oX = ("Clear History" , self.VVRxbh   , [])
   VVRzGo = (""    , self.VVN3ihFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVpYfQ  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFaufo(self, None, title=title, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=23, VVWoa9=VVWoa9, VVB4oX=VVB4oX, VVRzGo=VVRzGo)
  else:
   FFo08k(self, "Not found", title=title)
 def VVXFud(self, VVrVVi, title, txt, colList):
  FFKzCJ(VVrVVi, colList[3], VVDaMP=False, checkParentalControl=True)
 def VVRxbh(self, VVrVVi, title, txt, colList):
  FF7adK(self, boundFunction(self.VV9ENS, VVrVVi), "Clear Zap History ?")
 def VV9ENS(self, VVrVVi):
  self.VV6SDc()
  VVrVVi.cancel()
 def VVN3ihFromZapHistory(self, VVrVVi, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFLiV2(self, fncMode=CCe5Io.VVxvhV, refCode=refCode, chName=chName, text=txt)
class CCc7kl(Screen):
 VVQGIS   = 0
 VV0zEZ  = 1
 VVqZLQ  = 2
 VVEuBe  = 3
 VV9UdT  = 4
 VVVpZs  = 5
 VV4oV9  = 6
 VVFvEV  = 7
 VVnfuv = 8
 VVW7V3 = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFHZVI(VVWGyt, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF7MWH(self, self.Title)
  FFGkKQ(self["keyRed"] , "OK = Zap")
  FFGkKQ(self["keyGreen"] , "Current Service")
  FFGkKQ(self["keyYellow"], "Page Options")
  FFGkKQ(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCc7kl.VVGkn8()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV7oZO    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVwhft        ,
   "green"   : self.VVfDdO       ,
   "yellow"  : self.VVl34z        ,
   "blue"   : self.VVXMGh        ,
   "menu"   : self.VV0RMx        ,
   "info"   : self.VVN3ih         ,
   "up"   : self.VVslN2          ,
   "down"   : self.VVYyfx         ,
   "left"   : self.VVUv3T         ,
   "right"   : self.VVIBH1         ,
   "pageUp"  : boundFunction(self.VVQFfU, True) ,
   "chanUp"  : boundFunction(self.VVQFfU, True) ,
   "pageDown"  : boundFunction(self.VVQFfU, False) ,
   "chanDown"  : boundFunction(self.VVQFfU, False) ,
   "next"   : self.VVyngC        ,
   "last"   : self.VVmcQZ         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFHNI7(self)
  FFlSQr(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFCkhd(self, boundFunction(self.VVN9gz, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV0RMx(self):
  if not self.isBusy:
   VVtP1e = []
   VVtP1e.append(("Statistics"           , "VVWeTL"    ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Suggest PIcons for Current Channel"     , "VVj5Qm"   ))
   VVtP1e.append(("Set to Current Channel (copy file)"     , "VV0vzd_file"  ))
   VVtP1e.append(("Set to Current Channel (as SymLink)"     , "VV0vzd_link"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(CCc7kl.VVLjez())
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVhFJh"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e += CCc7kl.VV2qmD()
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("RCU Keys Help"          , "VVMx5k"    ))
   FF0g9p(self, self.VVLBbS, title=self.Title, VVtP1e=VVtP1e)
 def VVLBbS(self, item=None):
  if item is not None:
   if   item == "VVWeTL"     : self.VVWeTL()
   elif item == "VVj5Qm"    : self.VVj5Qm()
   elif item == "VV0vzd_file"   : self.VV0vzd(0)
   elif item == "VV0vzd_link"   : self.VV0vzd(1)
   elif item == "VVKG1k_file"  : self.VVKG1k(0)
   elif item == "VVKG1k_link"  : self.VVKG1k(1)
   elif item == "VVWPBN"   : self.VVWPBN()
   elif item == "VVZ1wk"  : self.VVZ1wk()
   elif item == "VV6wW5"   : self.VV6wW5()
   elif item == "VVhFJh"   : self.VVhFJh()
   elif item == "VVs4Cg"   : CCc7kl.VVs4Cg(self)
   elif item == "VVrjEF"   : CCc7kl.VVrjEF(self)
   elif item == "findPiconBrokenSymLinks"  : CCc7kl.VVvuEs(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCc7kl.VVvuEs(self, False)
   elif item == "VVMx5k"      : self.VVMx5k()
 def VVl34z(self):
  if not self.isBusy:
   VVtP1e = []
   VVtP1e.append(("Go to First PIcon"  , "VVSyOc"  ))
   VVtP1e.append(("Go to Last PIcon"   , "VVgtVz"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Sort by Channel Name"     , "sortByChan" ))
   VVtP1e.append(("Sort by File Name"  , "sortByFile" ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Find from File List .." , "VVOef9" ))
   FF0g9p(self, self.VVUjkU, title=self.Title, VVtP1e=VVtP1e)
 def VVUjkU(self, item=None):
  if item is not None:
   if   item == "VVSyOc"   : self.VVSyOc()
   elif item == "VVgtVz"   : self.VVgtVz()
   elif item == "sortByChan"  : self.VVqK8E(2)
   elif item == "sortByFile"  : self.VVqK8E(0)
   elif item == "VVOef9"  : self.VVOef9()
 def VVMx5k(self):
  FFpvi6(self, VVsT5j + "_help_picons", "PIcons Manager (Keys Help)")
 def VVslN2(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVgtVz()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVTdUw()
 def VVYyfx(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVSyOc()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVTdUw()
 def VVUv3T(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVgtVz()
  else:
   self.curCol -= 1
   self.VVTdUw()
 def VVIBH1(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVSyOc()
  else:
   self.curCol += 1
   self.VVTdUw()
 def VVmcQZ(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVTdUw(True)
 def VVyngC(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVTdUw(True)
 def VVSyOc(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVTdUw(True)
 def VVgtVz(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVTdUw(True)
 def VVOef9(self):
  VVtP1e = []
  for item in self.VV7oZO:
   VVtP1e.append((item[0], item[0]))
  FF0g9p(self, self.VVLOcN, title='PIcons ".png" Files', VVtP1e=VVtP1e, VVkS2T=True)
 def VVLOcN(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVcKvN(ndx)
 def VVwhft(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVd42q()
   if refCode:
    FFKzCJ(self, refCode)
    self.VVHE7J()
    self.VV8zlt()
 def VVQFfU(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVHE7J()
   self.VV8zlt()
  except:
   pass
 def VVfDdO(self):
  if self["keyGreen"].getVisible():
   self.VVcKvN(self.curChanIndex)
 def VVcKvN(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVTdUw(True)
  else:
   FFt82g(self, "Not found", 1000)
 def VVqK8E(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFCkhd(self, boundFunction(self.VVN9gz, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV0vzd(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVd42q()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVtP1e = []
     VVtP1e.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVtP1e.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF0g9p(self, boundFunction(self.VVcAVt, mode, curChF, selPiconF), VVtP1e=VVtP1e, title="Current Channel PIcon (already exists)")
    else:
     self.VVcAVt(mode, curChF, selPiconF, "overwrite")
   else:
    FFKFol(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFKFol(self, "Could not read current channel info. !", title=title)
 def VVcAVt(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFCkhd(self, boundFunction(self.VVN9gz, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVKG1k(self, mode):
  pass
 def VVWPBN(self):
  pass
 def VVZ1wk(self):
  pass
 def VV6wW5(self):
  pass
 def VVhFJh(self):
  lines = FFhQrI("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FF7adK(self, boundFunction(self.VV7FcK, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVkpWv=True)
  else:
   FFo08k(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV7FcK(self, fList):
  os.system(FFARGV("find -L '%s' -type l -delete" % self.pPath))
  FFo08k(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVN3ih(self):
  FFCkhd(self, self.VVCMuU)
 def VVCMuU(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVd42q()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFMi1p("PIcon Directory:\n", VVVNGK)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF0uQ2(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF0uQ2(path)
   txt += FFMi1p("PIcon File:\n", VVVNGK)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFhQrI(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFMi1p("Found %d SymLink%s to this file from:\n" % (tot, s), VVVNGK)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFLYCF(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFMi1p(tChName, VVDoEn)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFMi1p(line, VVRhh2), tChName)
    txt += "\n"
   if chName:
    txt += FFMi1p("Channel:\n", VVVNGK)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFMi1p(chName, VVDoEn)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFMi1p("Remarks:\n", VVVNGK)
    txt += "  %s\n" % FFMi1p("Unused", VVQy4t)
  else:
   txt = "No info found"
  FFLiV2(self, fncMode=CCe5Io.VVOKOc, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVd42q(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV7oZO[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF1zZi(sat)
  return fName, refCode, chName, sat, inDB
 def VVHE7J(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV7oZO):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV8zlt(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVd42q()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFMi1p("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVVNGK))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVd42q()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFMi1p(self.curChanName, VVIuu8)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVWeTL(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV7oZO:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFgaUh("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFuPDq(self, txt, title=self.Title)
 def VVXMGh(self):
  if not self.isBusy:
   VVtP1e = []
   VVtP1e.append(("All"         , "all"   ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("Used by Channels"      , "used"  ))
   VVtP1e.append(("Unused PIcons"      , "unused"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("PIcons Files"       , "pFiles"  ))
   VVtP1e.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVtP1e.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVtP1e.append(VV6Efe)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFwz1x(val)
      VVtP1e.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCZqjv(self)
   filterObj.VVY2in(VVtP1e, self.nsList, self.VVwBbu)
 def VVwBbu(self, item=None):
  if item is not None:
   self.VVNSXK(item)
 def VVNSXK(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVQGIS   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV0zEZ   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVqZLQ  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVEuBe  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VV9UdT  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVVpZs  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV4oV9   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVFvEV   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVnfuv , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVVpZs:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFhQrI("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFt82g(self, "Not found", 1000)
     return
   elif mode == self.VVW7V3:
    return
   else:
    words, asPrefix = CCZqjv.VVl9PV(words)
   if not words and mode in (self.VVFvEV, self.VVnfuv):
    FFt82g(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFCkhd(self, boundFunction(self.VVN9gz, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVj5Qm(self):
  self.session.open(CC1gln, barTheme=CC1gln.VVgiaG
      , titlePrefix = ""
      , fncToRun  = self.VVil7g
      , VVfbK6 = self.VVBp0t)
 def VVil7g(self, progBarObj):
  lameDbChans = CC6jYr.VVaFY4(self, CC6jYr.VVByhd, VV2fu3=False, VVr6p9=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVof9j = []
  progBarObj.VVQxG2(len(lameDbChans))
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").strip()
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVd70M(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCc7kl.VVrXub(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCc7kl.VVpkOc(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVof9j.append(f.replace(".png", ""))
 def VVBp0t(self, VVcfNz, VVof9j, threadCounter, threadTotal, threadErr):
  if VVof9j:
   self.timer = eTimer()
   fnc = boundFunction(FFCkhd, self, boundFunction(self.VVN9gz, mode=self.VVW7V3, words=VVof9j), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFt82g(self, "Not found", 2000)
 def VVN9gz(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVmvTv(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CC6jYr.VVaFY4(self, CC6jYr.VVByhd, VV2fu3=False, VVr6p9=False)
  iptvRefList = self.VVMHmp()
  tList = []
  for fName, fType in CCc7kl.VV7nyP(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVQGIS:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV0zEZ  and chName         : isAdd = True
   elif mode == self.VVqZLQ and not chName        : isAdd = True
   elif mode == self.VVEuBe  and fType == 0        : isAdd = True
   elif mode == self.VV9UdT  and fType == 1        : isAdd = True
   elif mode == self.VVVpZs  and fName in words       : isAdd = True
   elif mode == self.VVW7V3 and fName in words       : isAdd = True
   elif mode == self.VV4oV9  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVFvEV  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVnfuv:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV7oZO   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFt82g(self)
  else:
   self.isBusy = False
   FFt82g(self, "Not found", 1000)
   return
  self.VV7oZO.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVHE7J()
  self.totalPIcons = len(self.VV7oZO)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVTdUw(True)
 def VVmvTv(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCc7kl.VV7nyP(self.pPath):
    if fName:
     return True
   if isFirstTime : FFKFol(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFt82g(self, "Not found", 1000)
  else:
   FFKFol(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVMHmp(self):
  VVvFiF = {}
  files  = CCaJkM.VVZtqb(self)
  if files:
   for path in files:
    txt = FF0FCE(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVvFiF[refCode] = item[1]
  return VVvFiF
 def VVTdUw(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVTiUQ = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVTiUQ: self.curPage = VVTiUQ
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVaiu5()
  if self.curPage == VVTiUQ:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VV8zlt()
  filName, refCode, chName, sat, inDB = self.VVd42q()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVaiu5(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV7oZO[ndx]
   fName = self.VV7oZO[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFMi1p(chName, VVDoEn))
    else : lbl.setText("-")
   except:
    lbl.setText(FFMi1p(chName, VVlE7m))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVrXub(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVLjez():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVs4Cg"   )
 @staticmethod
 def VV2qmD():
  VVtP1e = []
  VVtP1e.append(("Find SymLinks (to PIcon Directory)"   , "VVrjEF"   ))
  VVtP1e.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVtP1e.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVtP1e
 @staticmethod
 def VVs4Cg(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(SELF)
  png, path = CCc7kl.VV0fgc(refCode)
  if path : CCc7kl.VVxy0d(SELF, png, path)
  else : FFKFol(SELF, "No PIcon found for current channel in:\n\n%s" % CCc7kl.VVGkn8())
 @staticmethod
 def VVrjEF(SELF):
  if VVIuu8:
   sed1 = FFuvWX("->", VVIuu8)
   sed2 = FFuvWX("picon", VVQy4t)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVlE7m, VVkCrP)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFPyAy(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFgUhe(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVvuEs(SELF, isPIcon):
  sed1 = FFuvWX("->", VVlE7m)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFuvWX("picon", VVQy4t)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFPyAy(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFgUhe(), grep, sed1, sed2))
 @staticmethod
 def VV7nyP(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVGkn8():
  path = CFG.PIconsPath.getValue()
  return FFExru(path)
 @staticmethod
 def VV0fgc(refCode, chName=None):
  if FFMSfm(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFg14Y(refCode)
  allPath, fName, refCodeFile, pList = CCc7kl.VVpkOc(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVxy0d(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFuvWX("%s%s" % (dest, png), VVDoEn))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFuvWX(errTxt, VVl05N))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFtERc(SELF, cmd)
 @staticmethod
 def VVpkOc(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCc7kl.VVGkn8()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFTcL7(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC9W7f():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVDDuZ  = None
  self.VVVRXX = ""
  self.VVS4nv  = noService
  self.VVZaL0 = 0
  self.VVKYfU  = noService
  self.VVj0ya = 0
  self.VVb0tq  = "-"
  self.VVIVjL = 0
  self.VVU7To  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVLABi(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVDDuZ = frontEndStatus
     self.VVm4vb()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVm4vb(self):
  if self.VVDDuZ:
   val = self.VVDDuZ.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVVRXX = "%3.02f dB" % (val / 100.0)
   else         : self.VVVRXX = ""
   val = self.VVDDuZ.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVZaL0 = int(val)
   self.VVS4nv  = "%d%%" % val
   val = self.VVDDuZ.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVj0ya = int(val)
   self.VVKYfU  = "%d%%" % val
   val = self.VVDDuZ.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVb0tq  = "%d" % val
   val = int(val * 100 / 500)
   self.VVIVjL = min(500, val)
   val = self.VVDDuZ.get("tuner_locked", 0)
   if val == 1 : self.VVU7To = "Locked"
   else  : self.VVU7To = "Not locked"
 def VVlnE7(self)   : return self.VVVRXX
 def VVTavs(self)   : return self.VVS4nv
 def VVxI9W(self)  : return self.VVZaL0
 def VVeyqF(self)   : return self.VVKYfU
 def VV5Ity(self)  : return self.VVj0ya
 def VVKcxJ(self)   : return self.VVb0tq
 def VV6UOG(self)  : return self.VVIVjL
 def VVdTPz(self)   : return self.VVU7To
 def VVjJE2(self) : return self.serviceName
class CCfC6J():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVlPcJ(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFjr2x(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVb1ji(self.ORPOS  , mod=1   )
      self.sat2  = self.VVb1ji(self.ORPOS  , mod=2   )
      self.freq  = self.VVb1ji(self.FREQ  , mod=3   )
      self.sr   = self.VVb1ji(self.SR   , mod=4   )
      self.inv  = self.VVb1ji(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVb1ji(self.POL  , self.D_POL )
      self.fec  = self.VVb1ji(self.FEC  , self.D_FEC )
      self.syst  = self.VVb1ji(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVb1ji("modulation" , self.D_MOD )
       self.rolof = self.VVb1ji("rolloff"  , self.D_ROLOF )
       self.pil = self.VVb1ji("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVb1ji("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVb1ji("pls_code"  )
       self.iStId = self.VVb1ji("is_id"   )
       self.t2PlId = self.VVb1ji("t2mi_plp_id" )
       self.t2PId = self.VVb1ji("t2mi_pid"  )
 def VVb1ji(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFwz1x(val)
  elif mod == 2   : return FFFLQ6(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVm7RS(self, refCode):
  txt = ""
  self.VVlPcJ(refCode)
  if self.data:
   def VVcFSN(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVcFSN("System"   , self.syst)
    txt += VVcFSN("Satellite"  , self.sat2)
    txt += VVcFSN("Frequency"  , self.freq)
    txt += VVcFSN("Inversion"  , self.inv)
    txt += VVcFSN("Symbol Rate"  , self.sr)
    txt += VVcFSN("Polarization" , self.pol)
    txt += VVcFSN("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVcFSN("Modulation" , self.mod)
     txt += VVcFSN("Roll-Off" , self.rolof)
     txt += VVcFSN("Pilot"  , self.pil)
     txt += VVcFSN("Input Stream", self.iStId)
     txt += VVcFSN("T2MI PLP ID" , self.t2PlId)
     txt += VVcFSN("T2MI PID" , self.t2PId)
     txt += VVcFSN("PLS Mode" , self.plsMod)
     txt += VVcFSN("PLS Code" , self.plsCod)
   else:
    txt += VVcFSN("System"   , self.txMedia)
    txt += VVcFSN("Frequency"  , self.freq)
  return txt, self.namespace
 def VVgAzq(self, refCode):
  txt = "Transpoder : ?"
  self.VVlPcJ(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVVNGK + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VV9ftU(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFjr2x(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVb1ji(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVb1ji(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVb1ji(self.SYST, self.D_SYS_S)
     freq = self.VVb1ji(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVb1ji(self.POL , self.D_POL)
      fec = self.VVb1ji(self.FEC , self.D_FEC)
      sr = self.VVb1ji(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVYhot(self, refCode):
  self.data = None
  self.VVlPcJ(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCsBZy():
 def __init__(self, VVNz4X, path, VVfbK6=None, curRowNum=-1):
  self.VVNz4X  = VVNz4X
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVfbK6  = VVfbK6
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFARGV("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VV5ZPn(curRowNum)
  else:
   FFKFol(self.VVNz4X, "Error while preparing edit!")
 def VV5ZPn(self, curRowNum):
  VVvFiF = self.VVJdMk()
  VVzi3l = None #("Delete Line" , self.deleteLine  , [])
  VVredj = ("Save Changes" , self.VV3Swg   , [])
  VVWoa9  = ("Edit Line"  , self.VVP3Go    , [])
  VV0bqY = ("Line Options" , self.VVJtir   , [])
  VVsaB3 = (""    , self.VVVPX7 , [])
  VVYpBL = self.VVkoue
  VVTREU  = self.VVbp9l
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVpYfQ  = (CENTER  , LEFT  )
  VVrVVi = FFaufo(self.VVNz4X, None, title=self.Title, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=24, VVzi3l=VVzi3l, VVredj=VVredj, VVWoa9=VVWoa9, VV0bqY=VV0bqY, VVYpBL=VVYpBL, VVTREU=VVTREU, VVsaB3=VVsaB3, VV34E6=True
    , VVOM9K   = "#11001111"
    , VVpOBz   = "#11001111"
    , VVpeGc   = "#11001111"
    , VVrGdv  = "#05333333"
    , VVmKuh  = "#00222222"
    , VVyj4g  = "#11331133"
    )
  VVrVVi.VVylm8(curRowNum)
 def VVJtir(self, VVrVVi, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVrVVi.VVR2xp()
  VVtP1e = []
  VVtP1e.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVtP1e.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVOrU1"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVkULC:
   VVtP1e.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(  ("Delete Line"         , "deleteLine"   ))
  FF0g9p(self.VVNz4X, boundFunction(self.VVUGUq, VVrVVi, lineNum), VVtP1e=VVtP1e, title="Line Options")
 def VVUGUq(self, VVrVVi, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVtrIL("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVrVVi)
   elif item == "VVOrU1"  : self.VVOrU1(VVrVVi, lineNum)
   elif item == "copyToClipboard"  : self.VVnpR3(VVrVVi, lineNum)
   elif item == "pasteFromClipboard" : self.VVvh8p(VVrVVi, lineNum)
   elif item == "deleteLine"   : self.VVtrIL("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVrVVi)
 def VVbp9l(self, VVrVVi):
  VVrVVi.VVIc3e()
 def VVVPX7(self, VVrVVi, title, txt, colList):
  if   self.insertMode == 1: VVrVVi.VVDx6l()
  elif self.insertMode == 2: VVrVVi.VVFxgz()
  self.insertMode = 0
 def VVOrU1(self, VVrVVi, lineNum):
  if lineNum == VVrVVi.VVR2xp():
   self.insertMode = 1
   self.VVtrIL("echo '' >> '%s'" % self.tmpFile, VVrVVi)
  else:
   self.insertMode = 2
   self.VVtrIL("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVrVVi)
 def VVnpR3(self, VVrVVi, lineNum):
  global VVkULC
  VVkULC = FFgaUh("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVrVVi.VVfWYs("Copied to clipboard")
 def VV3Swg(self, VVrVVi, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFARGV("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFARGV("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVrVVi.VVfWYs("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVrVVi.VVIc3e()
    else:
     FFKFol(self.VVNz4X, "Cannot save file!")
   else:
    FFKFol(self.VVNz4X, "Cannot create backup copy of original file!")
 def VVkoue(self, VVrVVi):
  if self.fileChanged:
   FF7adK(self.VVNz4X, boundFunction(self.VVXeUq, VVrVVi), "Cancel changes ?")
  else:
   finalOK = os.system(FFARGV("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVXeUq(VVrVVi)
 def VVXeUq(self, VVrVVi):
  VVrVVi.cancel()
  os.system(FFARGV("rm -f '%s'" % self.tmpFile))
  if self.VVfbK6:
   self.VVfbK6(self.fileSaved)
 def VVP3Go(self, VVrVVi, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVkCrP + "ORIGINAL TEXT:\n" + VVRhh2 + lineTxt
  FFXtIF(self.VVNz4X, boundFunction(self.VVUhKb, lineNum, VVrVVi), title="File Line", defaultText=lineTxt, message=message)
 def VVUhKb(self, lineNum, VVrVVi, VVjNXP):
  if not VVjNXP is None:
   if VVrVVi.VVR2xp() <= 1:
    self.VVtrIL("echo %s > '%s'" % (VVjNXP, self.tmpFile), VVrVVi)
   else:
    self.VVpiYD(VVrVVi, lineNum, VVjNXP)
 def VVvh8p(self, VVrVVi, lineNum):
  if lineNum == VVrVVi.VVR2xp() and VVrVVi.VVR2xp() == 1:
   self.VVtrIL("echo %s >> '%s'" % (VVkULC, self.tmpFile), VVrVVi)
  else:
   self.VVpiYD(VVrVVi, lineNum, VVkULC)
 def VVpiYD(self, VVrVVi, lineNum, newTxt):
  VVrVVi.VV0lPI("Saving ...")
  lines = FFOmkW(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVrVVi.VViuRm()
  VVvFiF = self.VVJdMk()
  VVrVVi.VV8dsB(VVvFiF)
 def VVtrIL(self, cmd, VVrVVi):
  tCons = CCww76()
  tCons.ePopen(cmd, boundFunction(self.VVE4ft, VVrVVi))
  self.fileChanged = True
  VVrVVi.VViuRm()
 def VVE4ft(self, VVrVVi, result, retval):
  VVvFiF = self.VVJdMk()
  VVrVVi.VV8dsB(VVvFiF)
 def VVJdMk(self):
  if fileExists(self.tmpFile):
   lines = FFOmkW(self.tmpFile)
   VVvFiF = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVvFiF.append((str(ndx), line.strip()))
   if not VVvFiF:
    VVvFiF.append((str(1), ""))
   return VVvFiF
  else:
   FFtist(self.VVNz4X, self.tmpFile)
class CCZqjv():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVtP1e   = []
  self.satList   = []
 def VVka1I(self, VVfbK6):
  self.VVtP1e = []
  VVtP1e, VVYora = self.VVJvD3(False, True)
  if VVtP1e:
   self.VVtP1e += VVtP1e
   self.VV4Waw(VVfbK6, VVYora)
 def VVDBI6(self, mode, VVrVVi, satCol, VVfbK6):
  VVrVVi.VV0lPI("Loading Filters ...")
  self.VVtP1e = []
  self.VVtP1e.append(("All Services" , "all"))
  if mode == 1:
   self.VVtP1e.append(VV6Efe)
   self.VVtP1e.append(("Parental Control", "parentalControl"))
   self.VVtP1e.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVtP1e.append(VV6Efe)
   self.VVtP1e.append(("Selected Transponder"   , "selectedTP" ))
   self.VVtP1e.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVRolu(VVrVVi, satCol)
  VVtP1e, VVYora = self.VVJvD3(True, False)
  if VVtP1e:
   VVtP1e.insert(0, VV6Efe)
   self.VVtP1e += VVtP1e
  VVrVVi.VViXU5()
  self.VV4Waw(VVfbK6, VVYora)
 def VVY2in(self, VVtP1e, sats, VVfbK6):
  self.VVtP1e = VVtP1e
  VVtP1e, VVYora = self.VVJvD3(True, False)
  if VVtP1e:
   self.VVtP1e.append(VV6Efe)
   self.VVtP1e += VVtP1e
  self.VV4Waw(VVfbK6, VVYora)
 def VVHJK1(self, VVtP1e, sats, VVfbK6):
  self.VVtP1e = VVtP1e
  VVtP1e, VVYora = self.VVJvD3(True, False)
  if VVtP1e:
   self.VVtP1e.append(VV6Efe)
   self.VVtP1e += VVtP1e
  self.VV4Waw(VVfbK6, VVYora)
 def VV4Waw(self, VVfbK6, VVYora):
  VV0Jrh = ("Edit Filter", boundFunction(self.VVj918, VVYora))
  VVhCvA  = ("Filter Help", boundFunction(self.VVpC8G, VVYora))
  FF0g9p(self.callingSELF, boundFunction(self.VVszVM, VVfbK6), VVtP1e=self.VVtP1e, title="Select Filter", VV0Jrh=VV0Jrh, VVhCvA=VVhCvA)
 def VVszVM(self, VVfbK6, item):
  if item:
   VVfbK6(item)
 def VVj918(self, VVYora, VVgdWRObj, sel):
  if fileExists(VVYora) : CCsBZy(self.callingSELF, VVYora, VVfbK6=None)
  else       : FFtist(self.callingSELF, VVYora)
  VVgdWRObj.cancel()
 def VVpC8G(self, VVYora, VVgdWRObj, sel):
  FFpvi6(self.callingSELF, VVsT5j + "_help_service_filter", "Service Filter")
 def VVRolu(self, VVrVVi, satColNum):
  if not self.satList:
   satList = VVrVVi.VVEDiH(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF1zZi(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV6Efe)
  if self.VVtP1e:
   self.VVtP1e += self.satList
 def VVJvD3(self, addTag, VVebv7):
  FFnxpp()
  fileName  = "ajpanel_services_filter"
  VVYora = VVic63 + fileName
  VVtP1e  = []
  if not fileExists(VVYora):
   os.system(FFARGV("cp -f '%s' '%s'" % (VVsT5j + fileName, VVYora)))
  fileFound = False
  if fileExists(VVYora):
   fileFound = True
   lines = FFOmkW(VVYora)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVtP1e.append((line, "__w__" + line))
       else  : VVtP1e.append((line, line))
  if VVebv7:
   if   not fileFound : FFtist(self.callingSELF , VVYora)
   elif not VVtP1e : FF50vC(self.callingSELF , VVYora)
  return VVtP1e, VVYora
 @staticmethod
 def VVl9PV(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CChZFz():
 def __init__(self, callingSELF, VVrVVi, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVrVVi = VVrVVi
  self.refCodeColNum = refCodeColNum
  self.VVtP1e = []
  iMulSel = self.VVrVVi.VVU4N6()
  if iMulSel : self.VVtP1e.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVtP1e.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVrVVi.VVhDV3()
  self.VVtP1e.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVtP1e.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVtP1e.append(VV6Efe)
 def VVzCqc(self, servName, refCode):
  tot = self.VVrVVi.VVhDV3()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVtP1e.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVmAUF_multi" ))
  else    : self.VVtP1e.append( ("Add to Bouquet : %s"      % servName , "VVmAUF_one" ))
  self.VVt8Kz(servName, refCode)
 def VVrQwK(self, servName, refCode, pcState, hidState):
  self.VVtP1e = []
  if pcState == "No" : self.VVtP1e.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVtP1e.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVtP1e.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVtP1e.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVt8Kz(servName, refCode)
 def VVt8Kz(self, servName, refCode):
  FF0g9p(self.callingSELF, boundFunction(self.VVliZN, servName, refCode), title="Options", VVtP1e=self.VVtP1e)
 def VVliZN(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVrVVi.VVBRww(True)
   elif item == "MultSelDisab"    : self.VVrVVi.VVBRww(False)
   elif item == "selectAll"    : self.VVrVVi.VVLTOL()
   elif item == "unselectAll"    : self.VVrVVi.VVWR6b()
   elif item == "parentalControl_add"  : self.callingSELF.VVWBQ4(self.VVrVVi, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVWBQ4(self.VVrVVi, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVy7mj(self.VVrVVi, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVy7mj(self.VVrVVi, refCode, False)
   elif item == "VVmAUF_multi" : self.VVmAUF(refCode, True)
   elif item == "VVmAUF_one" : self.VVmAUF(refCode, False)
 def VVmAUF(self, refCode, isMulti):
  bouquets = FFmPDO()
  if bouquets:
   VVtP1e = []
   for item in bouquets:
    VVtP1e.append((item[0], item[1].toString()))
   VV0Jrh = ("Create New", boundFunction(self.VV17Xp, refCode, isMulti))
   FF0g9p(self.callingSELF, boundFunction(self.VV4Lgy, refCode, isMulti), VVtP1e=VVtP1e, title="Add to Bouquet", VV0Jrh=VV0Jrh, VVkS2T=True, VVUPlu=True)
  else:
   FF7adK(self.callingSELF, boundFunction(self.VV2jJ8, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VV4Lgy(self, refCode, isMulti, bName=None):
  if bName:
   FFCkhd(self.VVrVVi, boundFunction(self.VVeqPZ, refCode, isMulti, bName), title="Adding Channels ...")
 def VVeqPZ(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVu8kw(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVgvOe = InfoBar.instance
    if VVgvOe:
     VVwOzf = VVgvOe.servicelist
     if VVwOzf:
      mutableList = VVwOzf.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVrVVi.VViXU5()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFo08k(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFKFol(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVu8kw(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVrVVi.VVvz0y(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VV17Xp(self, refCode, isMulti, VVgdWRObj, path):
  self.VV2jJ8(refCode, isMulti)
 def VV2jJ8(self, refCode, isMulti):
  FFXtIF(self.callingSELF, boundFunction(self.VV04bu, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV04bu(self, refCode, isMulti, name):
  if name:
   FFCkhd(self.VVrVVi, boundFunction(self.VV5sGh, refCode, isMulti, name), title="Adding Channels ...")
 def VV5sGh(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVu8kw(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVgvOe = InfoBar.instance
    if VVgvOe:
     VVwOzf = VVgvOe.servicelist
     if VVwOzf:
      try:
       VVwOzf.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVwOzf.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVrVVi.VViXU5()
   title = "Add to Bouquet"
   if allOK: FFo08k(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFKFol(self.callingSELF, "Nothing added!", title=title)
class CC4IMT(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VV1gxD, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF7MWH(self)
  FFGkKQ(self["keyRed"]  , "Exit")
  FFGkKQ(self["keyGreen"]  , "Save")
  FFGkKQ(self["keyYellow"] , "Refresh")
  FFGkKQ(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV8hlv  ,
   "green"   : self.VVYg1D ,
   "yellow"  : self.VVT888  ,
   "blue"   : self.VVLfo8   ,
   "up"   : self.VVslN2    ,
   "down"   : self.VVYyfx   ,
   "left"   : self.VVUv3T   ,
   "right"   : self.VVIBH1   ,
   "cancel"  : self.VV8hlv
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVT888()
  self.VVnMA0()
  FFHNI7(self)
 def VV8hlv(self) : self.close(True)
 def VVALqd(self) : self.close(False)
 def VVLfo8(self):
  self.session.openWithCallback(self.VVql0P, boundFunction(CCXMHY))
 def VVql0P(self, closeAll):
  if closeAll:
   self.close()
 def VVslN2(self):
  self.VVmRlC(1)
 def VVYyfx(self):
  self.VVmRlC(-1)
 def VVUv3T(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVnMA0()
 def VVIBH1(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVnMA0()
 def VVmRlC(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVUUUs(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVUUUs(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVUUUs(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVtzJs(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVtzJs(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVnMA0(self):
  for obj in self.list:
   FFlSQr(obj, "#11404040")
  FFlSQr(self.list[self.index], "#11ff8000")
 def VVT888(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVYg1D(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCww76()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVc7wz)
 def VVc7wz(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFo08k(self, "Nothing returned from the system!")
  else:
   FFo08k(self, str(result))
class CCXMHY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVqdo1, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF7MWH(self, addLabel=True)
  FFGkKQ(self["keyRed"]  , "Exit")
  FFGkKQ(self["keyGreen"]  , "Sync")
  FFGkKQ(self["keyYellow"] , "Refresh")
  FFGkKQ(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV8hlv   ,
   "green"   : self.VVi3xF  ,
   "yellow"  : self.VVkTy8 ,
   "blue"   : self.VVJ1nl  ,
   "cancel"  : self.VV8hlv
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVm3Fs()
  self.onShow.append(self.start)
 def start(self):
  FFTTch(self.refresh)
  FFHNI7(self)
 def refresh(self):
  self.VVPZyE()
  self.VV9spp(False)
 def VV8hlv(self)  : self.close(True)
 def VVJ1nl(self) : self.close(False)
 def VVm3Fs(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVPZyE(self):
  self.VViP2o()
  self.VVx5SL()
  self.VV1SGr()
  self.VVORlu()
 def VVkTy8(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVm3Fs()
   self.VVPZyE()
   FFTTch(self.refresh)
 def VVi3xF(self):
  if len(self["keyGreen"].getText()) > 0:
   FF7adK(self, self.VVRrF4, "Synchronize with Internet Date/Time ?")
 def VVRrF4(self):
  self.VVPZyE()
  FFTTch(boundFunction(self.VV9spp, True))
 def VViP2o(self)  : self["keyRed"].show()
 def VVfiXW(self)  : self["keyGreen"].show()
 def VVr5IA(self) : self["keyYellow"].show()
 def VVFJhL(self)  : self["keyBlue"].show()
 def VVx5SL(self)  : self["keyGreen"].hide()
 def VV1SGr(self) : self["keyYellow"].hide()
 def VVORlu(self)  : self["keyBlue"].hide()
 def VV9spp(self, sync):
  localTime = FFDiuF()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV9jVq(server)
   if epoch_time is not None:
    ntpTime = FFMoES(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCww76()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVc7wz, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVr5IA()
  self.VVFJhL()
  if ok:
   self.VVfiXW()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVc7wz(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV9spp(False)
  except:
   pass
 def VV9jVq(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFLVNL():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCk1d5(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFHZVI(VVPwBt, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FF7MWH(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFTTch(self.VVKMDu)
 def VVKMDu(self):
  if FFLVNL(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFlSQr(self["myBody"], color)
   FFlSQr(self["myLabel"], color)
  except:
   pass
class CCM2yD(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFhgHB()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFHZVI(VVKwao, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCeVML(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCeVML(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCeVML(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC9W7f()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF7MWH(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVslN2          ,
   "down"  : self.VVYyfx         ,
   "left"  : self.VVUv3T         ,
   "right"  : self.VVIBH1         ,
   "info"  : self.VV1iai        ,
   "epg"  : self.VV1iai        ,
   "menu"  : self.VVMx5k         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVqYpn, -1)  ,
   "next"  : boundFunction(self.VVqYpn, 1)  ,
   "pageUp" : boundFunction(self.VVRFlR, True) ,
   "chanUp" : boundFunction(self.VVRFlR, True) ,
   "pageDown" : boundFunction(self.VVRFlR, False) ,
   "chanDown" : boundFunction(self.VVRFlR, False) ,
   "0"   : boundFunction(self.VVqYpn, 0)  ,
   "1"   : boundFunction(self.VVrznh, pos=1) ,
   "2"   : boundFunction(self.VVrznh, pos=2) ,
   "3"   : boundFunction(self.VVrznh, pos=3) ,
   "4"   : boundFunction(self.VVrznh, pos=4) ,
   "5"   : boundFunction(self.VVrznh, pos=5) ,
   "6"   : boundFunction(self.VVrznh, pos=6) ,
   "7"   : boundFunction(self.VVrznh, pos=7) ,
   "8"   : boundFunction(self.VVrznh, pos=8) ,
   "9"   : boundFunction(self.VVrznh, pos=9) ,
  }, -1)
  self.onShown.append(self.VVyQ2h)
  self.onClose.append(self.onExit)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self.sliderSNR.VVlCkp()
  self.sliderAGC.VVlCkp()
  self.sliderBER.VVlCkp(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVrznh()
  self.VVYlH7Info()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVYlH7)
  except:
   self.timer.callback.append(self.VVYlH7)
  self.timer.start(500, False)
 def VVYlH7Info(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVLABi(service)
  serviceName = self.tunerInfo.VVjJE2()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  tp = CCfC6J()
  txt = tp.VVgAzq(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVYlH7(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVLABi(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVlnE7())
   self["mySNR"].setText(self.tunerInfo.VVTavs())
   self["myAGC"].setText(self.tunerInfo.VVeyqF())
   self["myBER"].setText(self.tunerInfo.VVKcxJ())
   self.sliderSNR.VVZeZz(self.tunerInfo.VVxI9W())
   self.sliderAGC.VVZeZz(self.tunerInfo.VV5Ity())
   self.sliderBER.VVZeZz(self.tunerInfo.VV6UOG())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVZeZz(0)
   self.sliderAGC.VVZeZz(0)
   self.sliderBER.VVZeZz(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
    if state and not state == "Tuned":
     FFt82g(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VV1iai(self):
  FFLiV2(self, fncMode=CCe5Io.VVlDRu)
 def VVMx5k(self):
  FFpvi6(self, VVsT5j + "_help_signal", "Signal Monitor (Keys)")
 def VVslN2(self)  : self.VVrznh(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVYyfx(self) : self.VVrznh(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVUv3T(self) : self.VVrznh(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVIBH1(self) : self.VVrznh(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVrznh(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVqYpn(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFtNnM(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVRFlR(self, isUp):
  FFt82g(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVYlH7Info()
  except:
   pass
class CCeVML(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVlCkp(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFlSQr(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVsT5j +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFlSQr(self.covObj, self.covColor)
   else:
    FFlSQr(self.covObj, "#00006688")
    self.isColormode = True
  self.VVZeZz(0)
 def VVZeZz(self, val):
  val  = FFtNnM(val, self.minN, self.maxN)
  width = int(FFAEVv(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFtNnM(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC1gln(Screen):
 VVgiaG    = 0
 VVFy9w = 1
 VV6tHG = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVfbK6=None, barTheme=VVgiaG):
  ratio = self.VVIcJu(barTheme)
  self.skin, self.skinParam = FFHZVI(VVbYEN, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVfbK6 = VVfbK6
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVof9j = None
  self.timer   = eTimer()
  self.myThread  = None
  FF7MWH(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVyQ2h)
  self.onClose.append(self.onExit)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self.VV97i6()
  self["myProgBarVal"].setText("0%")
  FFlSQr(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVZM3j()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZM3j)
  except:
   self.timer.callback.append(self.VVZM3j)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="threadFnc", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVQxG2(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVHEqD_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVof9j), self.counter, self.maxValue, catName)
 def VVd70M(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVof9j), self.counter, self.maxValue)
  except:
   pass
 def VVWQJ8(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFt82g(self, "Cancelling ...")
  self.isCancelled = True
  if self.VVfbK6:
   self.VVfbK6(False, self.VVof9j, self.counter, self.maxValue, self.isError)
  self.close()
 def VVZM3j(self):
  val = FFtNnM(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFAEVv(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VVfbK6 and not self.isCancelled:
    self.VVfbK6(True, self.VVof9j, self.counter, self.maxValue, self.isError)
   self.close()
 def VV97i6(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme == self.VVFy9w:
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VV6tHG:
   pass
 def VVIcJu(self, barTheme):
  if   barTheme == self.VVFy9w : return 0.8
  elif barTheme == self.VV6tHG : return 1
  else              : return 1
class CCww76(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVfbK6 = {}
  self.commandRunning = False
  self.VVRtV7  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVfbK6, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVfbK6[name] = VVfbK6
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVRtV7:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVd4th, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVusuI , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVd4th, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVusuI , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVusuI(name, retval)
  return True
 def VVd4th(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVusuI(self, name, retval):
  if not self.VVRtV7:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVfbK6[name]:
   self.VVfbK6[name](self.appResults[name], retval)
  del self.VVfbK6[name]
 def VVRhZy(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CC8OYy(Screen):
 def __init__(self, session, title="", VV4uLj=None, VVJNPv=False, VVF8iA=False, VVszuj=False, VVLukp=False, VVEkCr=False, VVfuH0=False, VVNQut=VV3npe, VVGvDX=None, VVatGc=False, VVjXYr=None, VVm1JT="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFHZVI(VVHoLH, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF7MWH(self, addScrollLabel=True)
  if not VVm1JT:
   VVm1JT = "Processing ..."
  self["myLabel"].setText("   %s" % VVm1JT)
  self.VVJNPv   = VVJNPv
  self.VVF8iA   = VVF8iA
  self.VVszuj   = VVszuj
  self.VVLukp  = VVLukp
  self.VVEkCr = VVEkCr
  self.VVfuH0 = VVfuH0
  self.VVNQut   = VVNQut
  self.VVGvDX = VVGvDX
  self.VVatGc  = VVatGc
  self.VVjXYr  = VVjXYr
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCww76()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFqA9R()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV4uLj, str):
   self.VV4uLj = [VV4uLj]
  else:
   self.VV4uLj = VV4uLj
  if self.VVszuj or self.VVLukp:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVFR4v, VVFR4v)
   self.VV4uLj.append("echo -e '\n%s\n' %s" % (restartNote, FFuvWX(restartNote, VVIuu8)))
   if self.VVszuj:
    self.VV4uLj.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV4uLj.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVEkCr:
   FFt82g(self, "Processing ...")
  self.onLayoutFinish.append(self.VVZEvQ)
  self.onClose.append(self.VVVWNL)
 def VVZEvQ(self):
  self["myLabel"].VVVSbd(textOutFile="console" if self.enableSaveRes else "")
  if self.VVJNPv:
   self["myLabel"].VV0TCs()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVpAMS()
  else:
   self.VVvDs2()
 def VVpAMS(self):
  if FFLVNL():
   self["myLabel"].setText("Processing ...")
   self.VVvDs2()
  else:
   self["myLabel"].setText(FFMi1p("\n   No connection to internet!", VVQy4t))
 def VVvDs2(self):
  allOK = self.container.ePopen(self.VV4uLj[0], self.VVFsDt, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVFsDt("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVfuH0 or self.VVszuj or self.VVLukp:
    self["myLabel"].setText(FF5WAx("STARTED", VVIuu8) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVjXYr:
   colorWhite = CCecW4.VVXMXe(VVkCrP)
   color  = CCecW4.VVXMXe(self.VVjXYr[0])
   words  = self.VVjXYr[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVNQut=self.VVNQut)
 def VVFsDt(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV4uLj):
   allOK = self.container.ePopen(self.VV4uLj[self.cmdNum], self.VVFsDt, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVFsDt("Cannot connect to Console!", -1)
  else:
   if self.VVEkCr and FF3By6(self):
    FFt82g(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVfuH0:
    self["myLabel"].appendText("\n" + FF5WAx("FINISHED", VVIuu8), self.VVNQut)
   if self.VVJNPv or self.VVF8iA:
    self["myLabel"].VV0TCs()
   if self.VVGvDX is not None:
    self.VVGvDX()
   if not retval and self.VVatGc:
    self.VVVWNL()
 def VVVWNL(self):
  if self.container.VVRhZy():
   self.container.killAll()
class CCw4xs(Screen):
 def __init__(self, session, VV4uLj=None, VVEkCr=False):
  self.skin, self.skinParam = FFHZVI(VVHoLH, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVic63 + "ajpanel_terminal.history"
  self.customCommandsFile = VVic63 + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFgaUh("pwd") or "/home/root"
  self.container   = CCww76()
  FF7MWH(self, addScrollLabel=True)
  FFGkKQ(self["keyRed"] , "Exit = Stop Command")
  FFGkKQ(self["keyGreen"] , "OK = History")
  FFGkKQ(self["keyYellow"], "Menu = Custom Cmds")
  FFGkKQ(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVx5sw ,
   "cancel" : self.VVNoTQ  ,
   "menu"  : self.VVSt3U ,
   "last"  : self.VVevDL  ,
   "next"  : self.VVevDL  ,
   "1"   : self.VVevDL  ,
   "2"   : self.VVevDL  ,
   "3"   : self.VVevDL  ,
   "4"   : self.VVevDL  ,
   "5"   : self.VVevDL  ,
   "6"   : self.VVevDL  ,
   "7"   : self.VVevDL  ,
   "8"   : self.VVevDL  ,
   "9"   : self.VVevDL  ,
   "0"   : self.VVevDL
  })
  self.onLayoutFinish.append(self.VVyQ2h)
  self.onClose.append(self.VVF1VV)
 def VVyQ2h(self):
  self["myLabel"].VVVSbd(isResizable=False, textOutFile="terminal")
  FFFxI3(self["keyRed"]  , "#00ff8000")
  FFlSQr(self["keyRed"]  , self.skinParam["titleColor"])
  FFlSQr(self["keyGreen"]  , self.skinParam["titleColor"])
  FFlSQr(self["keyYellow"] , self.skinParam["titleColor"])
  FFlSQr(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVquuk(FFgaUh("date"), 5)
  result = FFgaUh("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVOmyf()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVsT5j + "LinuxCommands.lst"
   newTemplate = VVsT5j + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFARGV("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFARGV("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVF1VV(self):
  if self.container.VVRhZy():
   self.container.killAll()
   self.VVquuk("Process killed\n", 4)
   self.VVOmyf()
 def VVNoTQ(self):
  if self.container.VVRhZy():
   self.VVF1VV()
  else:
   FF7adK(self, self.close, "Exit ?", VVWh6t=False)
 def VVOmyf(self):
  self.VVquuk(self.prompt, 1)
  self["keyRed"].hide()
 def VVquuk(self, txt, mode):
  if   mode == 1 : color = VVIuu8
  elif mode == 2 : color = VVVNGK
  elif mode == 3 : color = VVkCrP
  elif mode == 4 : color = VVQy4t
  elif mode == 5 : color = VVRhh2
  elif mode == 6 : color = VVNkuN
  else   : color = VVkCrP
  try:
   self["myLabel"].appendText(FFMi1p(txt, color))
  except:
   pass
 def VVmRMC(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFMi1p(parts[0].strip(), VVVNGK)
   right = FFMi1p("#" + parts[1].strip(), VVNkuN)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVquuk(txt, 2)
  lastLine = self.VVRxW6()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVA8u3(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVFsDt, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FFKFol(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVquuk(data, 3)
 def VVFsDt(self, data, retval):
  if not retval == 0:
   self.VVquuk("Exit Code : %d\n" % retval, 4)
  self.VVOmyf()
 def VVx5sw(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVRxW6() == "":
   self.VVA8u3("cd /tmp")
   self.VVA8u3("ls")
  VVvFiF = []
  if fileExists(self.commandHistoryFile):
   lines  = FFOmkW(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVvFiF.append((str(c), line, str(lNum)))
   self.VVQwC3(VVvFiF, title, self.commandHistoryFile, isHistory=True)
  else:
   FFtist(self, self.commandHistoryFile, title=title)
 def VVRxW6(self):
  lastLine = FFgaUh("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVA8u3(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVSt3U(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFOmkW(self.customCommandsFile)
   lastLineIsSep = False
   VVvFiF = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVvFiF.append((str(c), line, str(lNum)))
   self.VVQwC3(VVvFiF, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFtist(self, self.customCommandsFile, title=title)
 def VVQwC3(self, VVvFiF, title, filePath=None, isHistory=False):
  if VVvFiF:
   VVrGdv = "#05333333"
   if isHistory: VVOM9K = VVpOBz = VVpeGc = "#11000020"
   else  : VVOM9K = VVpOBz = VVpeGc = "#06002020"
   VVB4oX = VV0bqY = None
   VVWoa9   = ("Send"   , self.VV0AL7        , [])
   VVredj  = ("Modify & Send" , self.VVa7t3        , [])
   if isHistory:
    VVB4oX = ("Clear History" , self.VVRx3I        , [])
   elif filePath:
    VV0bqY = ("Edit File"  , boundFunction(self.VV2hzB, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVpYfQ     = (CENTER  , LEFT   , CENTER )
   FFaufo(self, None, title=title, header=header, VV7oZO=VVvFiF, VVpYfQ=VVpYfQ, VVAF36=widths, VVpwbP=22, VVWoa9=VVWoa9, VVredj=VVredj, VVB4oX=VVB4oX, VV0bqY=VV0bqY, VV34E6=True
     , VVOM9K   = VVOM9K
     , VVpOBz   = VVpOBz
     , VVpeGc   = VVpeGc
     , VVhcvR  = "#05ffff00"
     , VVrGdv  = VVrGdv
    )
  else:
   FF50vC(self, filePath, title=title)
 def VV0AL7(self, VVrVVi, title, txt, colList):
  cmd = colList[1].strip()
  VVrVVi.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVquuk("\n%s\n" % cmd, 6)
   self.VVquuk(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVquuk(cmd, 2)
    self.VVquuk("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVquuk(ch, 0)
    self.VVquuk("\nor\n", 4)
    self.VVquuk("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVOmyf()
   else:
    self.VVmRMC(cmd)
 def VVa7t3(self, VVrVVi, title, txt, colList):
  cmd = colList[1]
  self.VV6KKh(VVrVVi, cmd)
 def VVRx3I(self, VVrVVi, title, txt, colList):
  FF7adK(self, boundFunction(self.VVGJ87, VVrVVi), "Reset History File ?", title="Command History")
 def VVGJ87(self, VVrVVi):
  os.system(FFARGV("echo '' > %s" % self.commandHistoryFile))
  VVrVVi.cancel()
 def VV2hzB(self, filePath, VVrVVi, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCsBZy(self, filePath, VVfbK6=boundFunction(self.VVlI7Q, VVrVVi), curRowNum=rowNum)
  else     : FFtist(self, filePath)
 def VVlI7Q(self, VVrVVi, fileChanged):
  if fileChanged:
   VVrVVi.cancel()
   FFTTch(self.VVSt3U)
 def VVevDL(self):
  self.VV6KKh(None, self.lastCommand)
 def VV6KKh(self, VVrVVi, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFXtIF(self, boundFunction(self.VVYPdA, VVrVVi), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVYPdA(self, VVrVVi, cmd):
  if cmd and len(cmd) > 0:
   self.VVmRMC(cmd)
   if VVrVVi:
    VVrVVi.cancel()
class CCePpO(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVjNXP="", VVnjhk=False, VVmzzl=False, isTrimEnds=True):
  self.skin, self.skinParam = FFHZVI(VVinsn, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FF7MWH(self, title, addLabel=True)
  FFGkKQ(self["keyRed"] , "Up/Down = Change")
  FFGkKQ(self["keyGreen"] , "Overwrite")
  FFGkKQ(self["keyYellow"], "Pick Key Map")
  FFGkKQ(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVmzzl   = VVmzzl
  self.VVnjhk  = VVnjhk
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVjNXP, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVgnJp      ,
   "green"    : self.VVoLqx    ,
   "yellow"   : self.VVTv2m      ,
   "blue"    : self.VVjZw4     ,
   "menu"    : self.VVA6Q5     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVI8qZ, True) ,
   "down"    : boundFunction(self.VVI8qZ, False) ,
   "left"    : self.VVlj14       ,
   "right"    : self.VVhXyz       ,
   "home"    : self.VVdxDw       ,
   "end"    : self.VVb04F       ,
   "next"    : self.VV0Ylw      ,
   "last"    : self.VV7hR1      ,
   "deleteForward"  : self.VV0Ylw      ,
   "deleteBackward" : self.VV7hR1      ,
   "tab"    : self.VVUav3       ,
   "toggleOverwrite" : self.VVoLqx    ,
   "0"     : self.VVF74u     ,
   "1"     : self.VVF74u     ,
   "2"     : self.VVF74u     ,
   "3"     : self.VVF74u     ,
   "4"     : self.VVF74u     ,
   "5"     : self.VVF74u     ,
   "6"     : self.VVF74u     ,
   "7"     : self.VVF74u     ,
   "8"     : self.VVF74u     ,
   "9"     : self.VVF74u
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVAvn6()
  self.onShown.append(self.VVyQ2h)
  self.onClose.append(self.onExit)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self["myLabel"].setText(self.message)
  self.VVDQI9()
  if self.VVnjhk : self.VVoLqx()
  else    : self.VVqjiJ()
  FFHNI7(self)
  FFlSQr(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTonE)
  except:
   self.timer.callback.append(self.VVTonE)
 def onExit(self):
  self.timer.stop()
 def VVgnJp(self):
  self.VVUr85()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVUr85()
  self.close(None)
 def VVA6Q5(self):
  VVtP1e = []
  VVtP1e.append(("Home"         , "home"    ))
  VVtP1e.append(("End"         , "end"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Clear All"       , "clearAll"   ))
  VVtP1e.append(("Clear To Home"      , "clearToHome"   ))
  VVtP1e.append(("Clear To End"       , "clearToEnd"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVkULC:
   VVtP1e.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("To Capital Letters"     , "toCapital"   ))
  VVtP1e.append(("To Small Letters"      , "toSmall"    ))
  FF0g9p(self, self.VVussw, title="Edit Options", VVtP1e=VVtP1e)
 def VVussw(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVdxDw()
   elif item == "end"     : self.VVb04F()
   elif item == "clearAll"    : self.VVtPXw()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVdxDw()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVkULC
    VVkULC = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVkULC)
    self.VVdxDw()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVTonE(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVoLqx(self):
  self["myInput"].toggleOverwrite()
  self.VVqjiJ()
 def VVTv2m(self):
  self.session.openWithCallback(self.VVHWin, boundFunction(CCnt1W, mode=self.charMode, VVmzzl=self.VVmzzl))
 def VVHWin(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVDQI9()
 def VVqjiJ(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVAvn6(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVUr85(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVlw8z(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVlj14(self)     : self.VV5heg(self["myInput"].left)
 def VVhXyz(self)     : self.VV5heg(self["myInput"].right)
 def VV0Ylw(self)     : self.VV5heg(self["myInput"].delete)
 def VVdxDw(self)     : self.VV5heg(self["myInput"].home)
 def VVb04F(self)     : self.VV5heg(self["myInput"].end)
 def VV7hR1(self)    : self.VV5heg(self["myInput"].deleteBackward)
 def VVUav3(self)     : self.VV5heg(self["myInput"].tab)
 def VVtPXw(self)     : self["myInput"].setText("")
 def VV5heg(self, fnc):
  fnc()
  self.VVTonE()
 def VVF74u(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVlw8z(newChar, overwrite)
   self.VVRPb0(newChar, self["myInput"].mapping[number])
 def VVI8qZ(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCnt1W.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCnt1W.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVlw8z(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVRPb0(newChar, group)
     break
 def VVRPb0(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVkCrP:
    group = VVRhh2 + group.replace(newChar, FFMi1p(newChar, VVkCrP, VVRhh2))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVjZw4(self):
  if self.VVmzzl : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVDQI9()
 def VVDQI9(self):
  self["myInput"].mapping = CCnt1W.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCnt1W.RCU_MAP_TITLES[self.charMode])
class CCnt1W(Screen):
 VVVqkc  = 0
 VV2CdQ  = 1
 VVtWgX  = 2
 VVvTsO  = 3
 VV3DGu = 4
 VVNo1W = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVVqkc, VVmzzl=False):
  self.skin, self.skinParam = FFHZVI(VV5VmV, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVmzzl  = VVmzzl
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FF7MWH(self, title=self.Title)
  FFGkKQ(self["keyRed"] ,"OK = Select")
  FFGkKQ(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV6Ire     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVgTMh, -1) ,
   "next"  : boundFunction(self.VVgTMh, +1) ,
   "left"  : boundFunction(self.VVgTMh, -1) ,
   "right"  : boundFunction(self.VVgTMh, +1) ,
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFlSQr(self["keyRed"], "#11222222")
  FFlSQr(self["keyGreen"], "#11222222")
  self.VV1ZMY()
 def VV1ZMY(self):
  self.VVY5pi()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVY5pi(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVgTMh(self, direction):
  if self.VVmzzl : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VV1ZMY()
 def VV6Ire(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CC0lGJ(Screen):
 def __init__(self, session, title="", message="", VVNQut=VV3npe, VVGF0H=False, VVpeGc=None, VVpwbP=30):
  self.skin, self.skinParam = FFHZVI(VVHoLH, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVpwbP)
  self.session   = session
  FF7MWH(self, title, addScrollLabel=True)
  self.VVNQut   = VVNQut
  self.VVGF0H   = VVGF0H
  self.VVpeGc   = VVpeGc
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self["myLabel"].VVVSbd(VVGF0H=self.VVGF0H)
  self["myLabel"].setText(self.message, self.VVNQut)
  if self.VVpeGc:
   FFlSQr(self["myBody"], self.VVpeGc)
   FFlSQr(self["myLabel"], self.VVpeGc)
   FFOtun(self["myLabel"], self.VVpeGc)
  self["myLabel"].VV0TCs()
class CCmHuw(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFHZVI(VVHEzh, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF7MWH(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  path = VVsT5j + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCD9VV(Screen, CCw9XP):
 PLAYER_INSTANCE = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False):
  self.skin, self.skinParam = FFHZVI(VVvrt0, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCw9XP.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FF7MWH(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVNJQV())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV8nYP         ,
   "info"  : self.VV1iai        ,
   "epg"  : self.VV1iai        ,
   "menu"  : self.FF0g9p         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVBTL1        ,
   "green"  : boundFunction(self.VVmCjk, True),
   "play"  : self.VVGUir        ,
   "pause"  : self.VVGUir        ,
   "stop"  : self.VVGUir        ,
   "left"  : boundFunction(self.VV83fW, -1)   ,
   "right"  : boundFunction(self.VV83fW,  1)   ,
   "rewind" : self.VVOiWg        ,
   "forward" : self.VVX4FK        ,
   "last"  : boundFunction(self.VVwalQ, 0)    ,
   "next"  : self.VVxpqO        ,
   "pageUp" : boundFunction(self.VVN6cr, True) ,
   "pageDown" : boundFunction(self.VVN6cr, False) ,
   "chanUp" : boundFunction(self.VVN6cr, True) ,
   "chanDown" : boundFunction(self.VVN6cr, False) ,
   "up"  : boundFunction(self.VVN6cr, True) ,
   "down"  : boundFunction(self.VVN6cr, False) ,
   "0"   : boundFunction(self.VVLYYD , 10)  ,
   "1"   : boundFunction(self.VVLYYD , 1)  ,
   "2"   : boundFunction(self.VVLYYD , 2)  ,
   "3"   : boundFunction(self.VVLYYD , 3)  ,
   "4"   : boundFunction(self.VVLYYD , 4)  ,
   "5"   : boundFunction(self.VVLYYD , 5)  ,
   "6"   : boundFunction(self.VVLYYD , 6)  ,
   "7"   : boundFunction(self.VVLYYD , 7)  ,
   "8"   : boundFunction(self.VVLYYD , 8)  ,
   "9"   : boundFunction(self.VVLYYD , 9)
  }, -1)
  self.onShown.append(self.VVyQ2h)
  self.onClose.append(self.onExit)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  if not CCD9VV.PLAYER_INSTANCE or self.portalTableParam:
   CCD9VV.PLAYER_INSTANCE = self
  else:
   self.close()
  self.VVBKGh()
  self.instance.move(ePoint(40, 40))
  self.VVUdnL(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVtJFE)
  except:
   self.timer.callback.append(self.VVtJFE)
  self.timer.start(250, False)
  self.VVtJFE("Checking ...")
  self.VVmCjk()
 def onExit(self):
  self.timer.stop()
  CCD9VV.PLAYER_INSTANCE = None
 def VVBKGh(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFlSQr(self["myTitle"], color)
 def FF0g9p(self):
  VVtP1e = []
  if self.isFromExternal:
   VVtP1e.append(("IPTV Menu" , "iptv" ))
   VVtP1e.append(VV6Efe)
  VVtP1e.append(("Move to Top"  , "top"  ))
  VVtP1e.append(("Move to Bottom" , "botm" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Help"    , "help" ))
  FF0g9p(self, self.VVpsMj, VVtP1e=VVtP1e, width=500, title="Options")
 def VVpsMj(self, item=None):
  if item:
   if item == "iptv"  :
    self.session.open(CCaJkM)
    self.close()
   elif item == "botm"  : self.VVUdnL(0)
   elif item == "top"  : self.VVUdnL(1)
   elif item == "help"  : FFpvi6(self, VVsT5j + "_help_player", "Player Controller (Keys)")
 def VVUdnL(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VV8nYP(self):
  if self.isManualSeek:
   self.VVdj4c()
   self.VVwalQ(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVdj4c()
  else:
   self.close()
 def VV1iai(self):
  FFLiV2(self, fncMode=CCe5Io.VVMAp4)
 def VVGUir(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVtJFE("Toggling Play/Pause ...")
 def VVdj4c(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV83fW(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwmX5()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFtNnM(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFAEVv(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFUeKr(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVLYYD(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFGkKQ(self["myPlayJmp"], self.VVNJQV())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVtJFE("Changed Jump Minutes to : %d" % val)
 def VVNJQV(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVtJFE(self, stateTxt=""):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
  fr = res = ""
  if info:
   w = FFT7wI(info, iServiceInformation.sVideoWidth) or -1
   h = FFT7wI(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFT7wI(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCe5Io.VVJoTV(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwmX5()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFtNnM(percVal, 0, 100)
    width = int(FFAEVv(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   FFFxI3(self["myPlayMsg"], "#00ff8066")
   self["myPlayMsg"].setText("-" if decodedUrl else FFZ41o(refCode, True))
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not durTxt:
   self["myPlayVal"].setText(">>>>>")
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText(prov)
  if not posTxt:
   self["myPlayPos"].setText("")
  if not remTxt:
   self["myPlayRem"].setText("")
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVlgNK() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   FFFxI3(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVOeOe()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVwalQ(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVEOU2()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFFxI3(self["myPlayMsg"], "#0000ff00")
  else     : FFFxI3(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVwmX5(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFUeKr(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFUeKr(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFUeKr(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVBTL1(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVlgNK()
   if cList:
    VVtP1e = []
    for pts, what in cList:
     txt = FFUeKr(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVtP1e.append((txt, pts))
    FF0g9p(self, self.VVf7BC, VVtP1e=VVtP1e, title="Cut List")
   else:
    self.VVtJFE("No Cut-List for this channel !")
 def VVf7BC(self, item=None):
  if item:
   self.VVwalQ(item)
 def VVlgNK(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVX4FK(self) : self.VVbRg1(self.jumpMinutes)
 def VVOiWg(self) : self.VVbRg1(-self.jumpMinutes)
 def VVbRg1(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVtJFE("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVtJFE("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVtJFE("Cannot jump")
 def VVvrvE(self):
  InfoBar.instance.VVvrvE()
 def VVwalQ(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVtJFE("Changing Time ...")
 def VVxpqO(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwmX5()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVtJFE("Jumping to end ...")
  except:
   pass
 def VVOeOe(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVEOU2(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVN6cr(self, isUp):
  if self.enableZapping:
   self.VVtJFE("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVdj4c()
   if self.portalTableParam:
    self.VVascu(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VVBKGh()
    self.VVmCjk()
 def VVascu(self, isUp):
  CCaJkM_inatance, VVrVVi, mode = self.portalTableParam
  if isUp : VVrVVi.VVpdyW()
  else : VVrVVi.VVQOfZ()
  FFCkhd(VVrVVi, boundFunction(self.VVPGh0, mode, VVrVVi, CCaJkM_inatance), title="Playing ...")
 def VVPGh0(self, mode, VVrVVi, CCaJkM_inatance):
  colList = VVrVVi.VVtIhD()
  if mode == "localIptv":
   CCaJkM_inatance.VVw8hT(True, VVrVVi, "", "", colList)
  elif isinstance(mode, int):
   CCaJkM_inatance.VVXbur(mode, True, VVrVVi, "", "", colList)
  else:
   CCaJkM_inatance.VVhJ0Q(mode, True, VVrVVi, "", "", colList)
  self.close()
 def VVmCjk(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVwmX5()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFLV7o(self)
   if not self.VVWmtx(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVtJFE("Refreshing Portal")
   FFTTch(self.VVwMqg)
  except:
   pass
 def VVwMqg(self):
  self.restoreLastPlayPos = self.VVtq8R()
class CCRM51(Screen):
 def __init__(self, session, title="", VVeMZz="Continue?", VVWh6t=True, VVkpWv=False):
  self.skin, self.skinParam = FFHZVI(VVKKAP, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVeMZz = VVeMZz
  self.VVkpWv = VVkpWv
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVWh6t : VVtP1e = [no , yes]
  else   : VVtP1e = [yes, no ]
  FF7MWH(self, title, VVtP1e=VVtP1e, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV8nYP ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVeMZz)
  if self.VVkpWv:
   self["myLabel"].instance.setHAlign(0)
  self.VV832N()
  FFjk8P(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF3xtA(self["myMenu"])
  FFXr2J(self, self["myMenu"])
 def VV8nYP(self):
  item = FF1WPP(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV832N(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CChu1f(Screen):
 def __init__(self, session, title="", VVtP1e=None, width=1000, OKBtnFnc=None, VVxdDY=None, VV13uN=None, VV0Jrh=None, VVhCvA=None, VVkS2T=False, VVUPlu=False):
  self.skin, self.skinParam = FFHZVI(VVLE1I, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVtP1e   = VVtP1e
  self.OKBtnFnc   = OKBtnFnc
  self.VVxdDY   = VVxdDY
  self.VV13uN  = VV13uN
  self.VV0Jrh  = VV0Jrh
  self.VVhCvA   = VVhCvA
  self.VVkS2T  = VVkS2T
  self.VVUPlu  = VVUPlu
  FF7MWH(self, title, VVtP1e=VVtP1e)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV8nYP          ,
   "cancel" : self.cancel          ,
   "red"  : self.VV5ft4         ,
   "green"  : self.VVYxdO         ,
   "yellow" : self.VVQYT5         ,
   "blue"  : self.VVKdad         ,
   "pageUp" : self.VVO8QG       ,
   "chanUp" : self.VVO8QG       ,
   "pageDown" : self.VVS6sZ        ,
   "chanDown" : self.VVS6sZ
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["myMenu"])
  FF9hWs(self)
  self.VVkS3k(self["keyRed"]  , self.VVxdDY )
  self.VVkS3k(self["keyGreen"] , self.VV13uN )
  self.VVkS3k(self["keyYellow"] , self.VV0Jrh )
  self.VVkS3k(self["keyBlue"]  , self.VVhCvA )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFHNI7(self)
 def VVkS3k(self, btnObj, btnFnc):
  if btnFnc:
   FFGkKQ(btnObj, btnFnc[0])
 def VV8nYP(self):
  item = FF1WPP(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVkS2T: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VV5ft4(self)  : self.VV5heg(self.VVxdDY)
 def VVYxdO(self) : self.VV5heg(self.VV13uN)
 def VVQYT5(self) : self.VV5heg(self.VV0Jrh)
 def VVKdad(self) : self.VV5heg(self.VVhCvA)
 def VV5heg(self, btnFnc):
  if btnFnc:
   item = FF1WPP(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVUPlu:
    self.cancel()
 def VVoNi4(self, VVtP1e):
  if len(VVtP1e) > 0:
   newList = []
   for item in VVtP1e:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VV0Rqc(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVO8QG(self):
  self["myMenu"].moveToIndex(0)
 def VVS6sZ(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCjMsN(Screen):
 def __init__(self, session, title="", header=None, VV7oZO=None, VVpYfQ=None, VVAF36=None, VVpwbP=24, VV34E6=False, VVWoa9=None, VVRzGo=None, VVzi3l=None, VVredj=None, VVB4oX=None, VV0bqY=None, VVTREU=None, VVsaB3=None, VVYpBL=None, VVi9D1=-1, VVqI0Q=False, searchCol=0, VVOM9K=None, VVpOBz=None, VVkevo="#00dddddd", VVpeGc="#11002233", VVhcvR="#00ff8833", VVrGdv="#11111111", VVmKuh="#0a555555", VV7yCI="#0affffff", VVyj4g="#11552200", VVib3u="#0055ff55"):
  self.skin, self.skinParam = FFHZVI(VVGf9D, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF7MWH(self, title)
  self.header     = header
  self.VV7oZO     = VV7oZO
  self.totalCols    = len(VV7oZO[0])
  self.VVKKBi   = 0
  self.lastSortModeIsReverese = False
  self.VV34E6   = VV34E6
  self.VVSfcm   = 0.01
  self.VVEEE5   = 0.02
  self.VVt0hp  = 1
  self.VVAF36 = VVAF36
  self.colWidthPixels   = []
  self.VVWoa9   = VVWoa9
  self.OKButtonObj   = None
  self.VVRzGo   = VVRzGo
  self.VVzi3l   = VVzi3l
  self.VVredj   = VVredj
  self.VVB4oX  = VVB4oX
  self.VV0bqY   = VV0bqY
  self.VVTREU    = VVTREU
  self.VVsaB3   = VVsaB3
  self.VVYpBL  = VVYpBL
  self.VVi9D1    = VVi9D1
  self.VVqI0Q   = VVqI0Q
  self.searchCol    = searchCol
  self.VVpYfQ    = VVpYfQ
  self.keyPressed    = -1
  self.VVpwbP    = FFabqX(VVpwbP)
  self.VVCfMB    = FFycft(self.VVpwbP, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVOM9K    = VVOM9K
  self.VVpOBz      = VVpOBz
  self.VVkevo    = FFahGT(VVkevo)
  self.VVpeGc    = FFahGT(VVpeGc)
  self.VVhcvR    = FFahGT(VVhcvR)
  self.VVrGdv    = FFahGT(VVrGdv)
  self.VVmKuh   = FFahGT(VVmKuh)
  self.VV7yCI    = FFahGT(VV7yCI)
  self.VVyj4g    = FFahGT(VVyj4g)
  self.VVib3u   = FFahGT(VVib3u)
  self.VVudJl  = False
  self.selectedItems   = 0
  self.VV6fU4   = FFahGT("#01fefe01")
  self.VVKigj   = FFahGT("#11400040")
  self.VVQEWH  = self.VV6fU4
  self.VVn6PU  = self.VVrGdv
  if self.VVqI0Q:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVTbxU  ,
   "red"   : self.VVG3W7  ,
   "green"   : self.VVt31V ,
   "yellow"  : self.VVqDaF ,
   "blue"   : self.VVCHRG  ,
   "menu"   : self.VVWBoV ,
   "info"   : self.VVbIsj  ,
   "cancel"  : self.VVolRr  ,
   "up"   : self.VVQOfZ    ,
   "down"   : self.VVpdyW  ,
   "left"   : self.VVmcQZ   ,
   "right"   : self.VVyngC  ,
   "pageUp"  : self.VVNfnJ  ,
   "chanUp"  : self.VVNfnJ  ,
   "pageDown"  : self.VVFxgz  ,
   "chanDown"  : self.VVFxgz
  }, -1)
  FFg0z1(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  try:
   self.VVpSkZ()
  except Exception as err:
   FFKFol(self, str(err))
   self.close(None)
 def VVpSkZ(self):
  FFHNI7(self)
  if self.VVOM9K:
   FFlSQr(self["myTitle"], self.VVOM9K)
  if self.VVpOBz:
   FFlSQr(self["myBody"] , self.VVpOBz)
   FFlSQr(self["myTableH"] , self.VVpOBz)
   FFlSQr(self["myTable"] , self.VVpOBz)
   FFlSQr(self["myBar"]  , self.VVpOBz)
  self.VVkS3k(self.VVzi3l  , self["keyRed"])
  self.VVkS3k(self.VVredj  , self["keyGreen"])
  self.VVkS3k(self.VVB4oX , self["keyYellow"])
  self.VVkS3k(self.VV0bqY  , self["keyBlue"])
  if self.VVWoa9:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVWoa9[0])
    FFlSQr(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVCfMB)
  self["myTableH"].l.setFont(0, gFont(VVgk1L, self.VVpwbP))
  self["myTable"].l.setItemHeight(self.VVCfMB)
  self["myTable"].l.setFont(0, gFont(VVgk1L, self.VVpwbP))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVCfMB)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVCfMB))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVCfMB)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVCfMB
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVCfMB * len(self.VV7oZO) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVAF36:
   self.VVAF36 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVAF36)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVpYfQ:
   self.VVpYfQ = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVpYfQ
   self.VVpYfQ = []
   for item in tmpList:
    self.VVpYfQ.append(item | RT_VALIGN_CENTER)
  self.VVmc28()
  if self.VVTREU:
   self.VVTREU(self)
 def VVkS3k(self, btnFnc, btn):
  if btnFnc : FFGkKQ(btn, btnFnc[0])
  else  : FFGkKQ(btn, "")
 def VVrbML(self, waitTxt):
  FFCkhd(self, self.VVmc28, title=waitTxt)
 def VVmc28(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VV05yw(0, self.header, self.VV7yCI, self.VVyj4g, self.VV7yCI, self.VVyj4g, self.VVib3u)])
   rows = []
   for c, row in enumerate(self.VV7oZO):
    rows.append(self.VV05yw(c, row, self.VVkevo, self.VVpeGc, self.VVhcvR, self.VVrGdv, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVi9D1 > -1:
    self["myTable"].moveToIndex(self.VVi9D1 )
   self.VV3MTz()
   if self.VVqI0Q:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVCfMB * len(self.VV7oZO)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVsaB3:
    self.VV5heg(self.VVsaB3, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFKFol(self, str(err))
    self.close()
   except:
    pass
 def VV05yw(self, keyIndex, columns, VVkevo, VVpeGc, VVhcvR, VVrGdv, VVib3u):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVib3u and ndx == self.VVKKBi : textColor = VVib3u
   else           : textColor = VVkevo
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.+)", entry, IGNORECASE)
   if span:
    c = FFahGT(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVpeGc = c
    entry = span.group(3)
   if self.VVpYfQ[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVCfMB)
           , font   = 0
           , flags   = self.VVpYfQ[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVpeGc
           , color_sel  = VVhcvR
           , backcolor_sel = VVrGdv
           , border_width = 1
           , border_color = self.VVmKuh
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVbIsj(self):
  rowData = self.VViVrx()
  if rowData:
   title, txt, colList = rowData
   if self.VVRzGo:
    fnc  = self.VVRzGo[1]
    params = self.VVRzGo[2]
    fnc(self, title, txt, colList)
   else:
    FFuPDq(self, txt, title)
 def VVTbxU(self):
  if   self.VVudJl : self.VVeizN(self.VVMLzp(), mode=2)
  elif self.VVWoa9  : self.VV5heg(self.VVWoa9, None)
  else      : self.VVbIsj()
 def VVG3W7(self) : self.VV5heg(self.VVzi3l , self["keyRed"])
 def VVt31V(self) : self.VV5heg(self.VVredj , self["keyGreen"])
 def VVqDaF(self): self.VV5heg(self.VVB4oX , self["keyYellow"])
 def VVCHRG(self) : self.VV5heg(self.VV0bqY , self["keyBlue"])
 def VV5heg(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFt82g(self, buttonFnc[3])
    FFTTch(boundFunction(self.VV2Jao, buttonFnc))
   else:
    self.VV2Jao(buttonFnc)
 def VV2Jao(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VViVrx()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVeizN(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV7oZO[ndx]
   isSelected = row[1][9] == self.VV6fU4
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV05yw(ndx, item, self.VVkevo, self.VVpeGc, self.VVhcvR, self.VVrGdv, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV05yw(ndx, item, self.VV6fU4, self.VVKigj, self.VVQEWH, self.VVn6PU, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV3MTz()
 def VVLTOL(self):
  FFCkhd(self, self.VVbEtz, title="Selecting all ...")
 def VVbEtz(self):
  self.VVBRww(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VV6fU4
   if not isSelected:
    item = self.VV7oZO[ndx]
    newRow = self.VV05yw(ndx, item, self.VV6fU4, self.VVKigj, self.VVQEWH, self.VVn6PU, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VV3MTz()
  self.VVKlHr()
 def VVWR6b(self):
  FFCkhd(self, self.VVvJ4x, title="Unselecting all ...")
 def VVvJ4x(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV6fU4:
    item = self.VV7oZO[ndx]
    newRow = self.VV05yw(ndx, item, self.VVkevo, self.VVpeGc, self.VVhcvR, self.VVrGdv, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VV3MTz()
  self.VVKlHr()
 def VVKlHr(self):
  self.hide()
  self.show()
 def VViVrx(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVAF36[i] > 1 or self.VVAF36[i] == self.VVSfcm:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VV7oZO))
   return rowNum, txt, colList
  else:
   return None
 def VVolRr(self):
  if self.VVYpBL : self.VVYpBL(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVtpWC(self):
  return self["myTitle"].getText().strip()
 def VV8r5D(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV0lPI(self, txt):
  FFt82g(self, txt)
 def VVfWYs(self, txt):
  FFt82g(self, txt, 1000)
 def VViXU5(self):
  FFt82g(self)
 def VVR2xp(self):
  return len(self.VV7oZO)
 def VViuRm(self): self["keyGreen"].show()
 def VVIc3e(self): self["keyGreen"].hide()
 def VVMLzp(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV2xMj(self):
  return len(self["myTable"].list)
 def VVBRww(self, isOn):
  self.VVudJl = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VV0bqY: self["keyBlue"].hide()
   if self.VVWoa9 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VV0bqY: self["keyBlue"].show()
   if self.VVWoa9 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVWoa9[0])
   self.VVWR6b()
  FFlSQr(self["myTitle"], color)
  FFlSQr(self["myBar"]  , color)
 def VVU4N6(self):
  return self.VVudJl
 def VVhDV3(self):
  return self.selectedItems
 def VVylm8(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VV3MTz()
 def VVDx6l(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VV3MTz()
 def VV8f3V(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV7oZO:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVpwxR(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVR2xp()
  txt += FF5WAx("Total Unique Items", VVQy4t)
  for i in range(self.totalCols):
   if self.VVAF36[i - 1] > 1 or self.VVAF36[i - 1] == self.VVSfcm:
    name, tot = self.VV8f3V(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFuPDq(self, txt)
 def VVa9s4(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVtIhD(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV8dsB(self, newList, newTitle=""):
  if newList:
   self.VV7oZO = newList
   if self.VV34E6 and self.VVKKBi == 0:
    self.VV7oZO = sorted(self.VV7oZO, key=lambda x: int(x[self.VVKKBi])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV7oZO = sorted(self.VV7oZO, key=lambda x: x[self.VVKKBi].lower(), reverse=self.lastSortModeIsReverese)
   self.VVrbML("Refreshing ...")
   if newTitle:
    self.VV8r5D(newTitle)
  else:
   FFKFol(self, "Cannot refresh list")
   self.cancel()
 def VVfBGF(self, data):
  ndx = self.VVMLzp()
  newRow = self.VV05yw(ndx, data, self.VVkevo, self.VVpeGc, self.VVhcvR, self.VVrGdv, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV3MTz()
   return True
  else:
   return False
 def VVA9bS(self, colNum, textToFind, VVebv7=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VV3MTz()
    break
  else:
   if VVebv7:
    FFt82g(self, "Not found", 1000)
 def VVGhyU(self, colDict, VVebv7=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV3MTz()
    return
  if VVebv7:
   FFt82g(self, "Not found", 1000)
 def VVGhyU_partial(self, colDict, VVebv7=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV3MTz()
    return
  if VVebv7:
   FFt82g(self, "Not found", 1000)
 def VVEDiH(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVvz0y(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV6fU4:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVi8Qm(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVWBoV(self):
  if not self["keyMenu2F"].getVisible() or self.VVqI0Q:
   return
  VVtP1e = []
  VVtP1e.append(("Table Statistcis"             , "tableStat"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append((FFMi1p("Export Table to .html"     , VVQy4t) , "VVXn12" ))
  VVtP1e.append((FFMi1p("Export Table to .csv"     , VVQy4t) , "VVCp83" ))
  VVtP1e.append((FFMi1p("Export Table to .txt (Tab Separated)", VVQy4t) , "VVgBiR" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVAF36[i] > 1 or self.VVAF36[i] == self.VVEEE5:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVtP1e.append(VV6Efe)
   if tot == 1 : VVtP1e.append(("Sort", sList[0][1]))
   else  : VVtP1e += sList
  FF0g9p(self, self.VV0N4K, VVtP1e=VVtP1e, title=self.VVtpWC())
 def VV0N4K(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVpwxR()
   elif item == "VVXn12": FFCkhd(self, self.VVXn12, title=title)
   elif item == "VVCp83" : FFCkhd(self, self.VVCp83 , title=title)
   elif item == "VVgBiR" : FFCkhd(self, self.VVgBiR , title=title)
   else:
    isReversed = False
    if self.VVKKBi == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VV34E6 and item == 0:
     self.VV7oZO = sorted(self.VV7oZO, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV7oZO = sorted(self.VV7oZO, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVKKBi = item
    self.VVrbML("Sorting ...")
 def VVQOfZ(self):
  self["myTable"].up()
  self.VV3MTz()
 def VVpdyW(self):
  self["myTable"].down()
  self.VV3MTz()
 def VVmcQZ(self):
  self["myTable"].pageUp()
  self.VV3MTz()
 def VVyngC(self):
  self["myTable"].pageDown()
  self.VV3MTz()
 def VVNfnJ(self):
  self["myTable"].moveToIndex(0)
  self.VV3MTz()
 def VVFxgz(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VV3MTz()
 def VVgBiR(self):
  expFile = self.VVkLKG() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVkkv1()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV7oZO:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVAF36[ndx] > self.VVt0hp:
      col = self.VVswsg(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVFc7R(expFile)
 def VVCp83(self):
  expFile = self.VVkLKG() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVkkv1()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV7oZO:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVAF36[ndx] > self.VVt0hp:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVswsg(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVFc7R(expFile)
 def VVXn12(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVtpWC(), PLUGIN_NAME, VVcmc0)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVtpWC()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVkkv1()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVAF36:
   colgroup += '   <colgroup>'
   for w in self.VVAF36:
    if w > self.VVt0hp:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVkLKG() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV7oZO:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVAF36[ndx] > self.VVt0hp:
      col = self.VVswsg(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVFc7R(expFile)
 def VVkkv1(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVAF36[ndx] > self.VVt0hp:
     newRow.append(col.strip())
  return newRow
 def VVswsg(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFTcL7(col)
 def VVkLKG(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVtpWC())
  fileName = fileName.replace("__", "_")
  path  = FFExru(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFtTMB()
  return expFile
 def VVFc7R(self, expFile):
  FFo08k(self, "File exported to:\n\n%s" % expFile, title=self.VVtpWC())
 def VV3MTz(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCJ4aS(Screen):
 def __init__(self, session, Title="", VV8Utd=None):
  self.skin, self.skinParam = FFHZVI(VVgLgu, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FF7MWH(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VV8Utd = VV8Utd
  if len(Title) == 0 : Title = FFqA9R()
  else    : Title = "File : %s" % VV8Utd
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  allOK = FFr0aO(self["myLabel"], self.VV8Utd)
  if not allOK:
   FFKFol(self, "Could not view this picture file")
   self.close()
class CCWTU2(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFHZVI(VVi7ZF, 1400, 950, 50, 40, 40, "#11201010", "#11101010", 30, barHeight=40, topRightBtns=1)
  self.session  = session
  FF7MWH(self)
  FFGkKQ(self["keyGreen"], "Save")
  self.VV7oZO = []
  self.VV7oZO.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VV7oZO.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VV7oZO.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VV7oZO.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VV7oZO.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  self.VV7oZO.append(getConfigListEntry(VVFR4v *2            ,         ))
  self.VV7oZO.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VV7oZO.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VV7oZO.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VV7oZO.append(getConfigListEntry(VVFR4v *2            ,         ))
  self.VV7oZO.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VV7oZO.append(getConfigListEntry(VVFR4v *2            ,         ))
  self.VV7oZO.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VV7oZO.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VV7oZO.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VV7oZO.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VV7oZO.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VV7oZO, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VV8nYP   ,
   "OK"  : self.VV8nYP   ,
   "green"  : self.VVSFwM  ,
   "menu"  : self.VVfAmW ,
   "cancel" : self.VVY3hI
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFjk8P(self["config"])
  FF9hWs(self,  self["config"])
  FFHNI7(self)
 def VV8nYP(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VV6GRs(item)
   elif item == CFG.backupPath    : self.VV6GRs(item)
   elif item == CFG.packageOutputPath  : self.VV6GRs(item)
   elif item == CFG.downloadedPackagesPath : self.VV6GRs(item)
   elif item == CFG.exportedTablesPath  : self.VV6GRs(item)
   elif item == CFG.exportedPIconsPath  : self.VV6GRs(item)
 def VV6GRs(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VVy09s, configObj)
         , boundFunction(CC2SNv, mode=CC2SNv.VVD6iE, VViFLr=sDir))
 def VVy09s(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVY3hI(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FF7adK(self, self.VVSFwM, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVSFwM(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVAXu3()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVfAmW(self):
  VVtP1e = []
  VVtP1e.append(("Use Backup directory in all other paths"      , "VVBskT"   ))
  VVtP1e.append(("Reset all to default (including File Manager bookmarks)"  , "VVbORx"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Backup %s Settings" % PLUGIN_NAME        , "VVXLWQ"  ))
  VVtP1e.append(("Restore %s Settings" % PLUGIN_NAME       , "VV13nF"  ))
  if fileExists(VVic63 + VV77GZ):
   VVtP1e.append(VV6Efe)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVtP1e.append(('%s Checking for Update' % txt1       , txt2     ))
   VVtP1e.append(("Reinstall %s" % PLUGIN_NAME        , "VVl4FT"  ))
   VVtP1e.append(("Update %s" % PLUGIN_NAME        , "VVH8iI"   ))
  FF0g9p(self, self.VV6ram, VVtP1e=VVtP1e, title="Config. Options")
 def VV6ram(self, item=None):
  if item:
   if   item == "VVBskT"  : FF7adK(self, self.VVBskT , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVbORx"  : FF7adK(self, self.VVbORx, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCecW4)
   elif item == "VVXLWQ" : self.VVXLWQ()
   elif item == "VV13nF" : FFCkhd(self, self.VV13nF, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVDH5R(True)
   elif item == "disableChkUpdate" : self.VVDH5R(False)
   elif item == "VVl4FT" : FFCkhd(self, self.VVl4FT , "Checking Server ...")
   elif item == "VVH8iI"  : FFCkhd(self, self.VVH8iI  , "Checking Server ...")
 def VVXLWQ(self):
  path = "%sajpanel_settings_%s" % (VVic63, FFtTMB())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFo08k(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV13nF(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFhQrI("find / %s -iname '%s*' | grep %s" % (FFgUhe(1), name, name))
  if lines:
   lines.sort()
   VVtP1e = []
   for line in lines:
    VVtP1e.append((line, line))
   FF0g9p(self, boundFunction(self.VVjAKr, title), title=title, VVtP1e=VVtP1e, width=1200)
  else:
   FFKFol(self, "No settings files found !", title=title)
 def VVjAKr(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFOmkW(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVAXu3()
    FFnxpp()
   else:
    FFtist(SELF, path, title=title)
 def VVDH5R(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVBskT(self):
  newPath = FFExru(VVic63)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVAXu3()
 @staticmethod
 def VVzzIQ():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVbORx(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.PIconsPath.setValue(VVYZ3v)
  CFG.backupPath.setValue(CCWTU2.VVzzIQ())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVAXu3()
  self.close()
 def VVAXu3(self):
  configfile.save()
  global VVic63
  VVic63 = CFG.backupPath.getValue()
  FFPg79()
 def VVH8iI(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VV3OAl(title)
  if webVer:
   FF7adK(self, boundFunction(FFCkhd, self, boundFunction(self.VVgwuC, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVl4FT(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VV3OAl(title, True)
  if webVer:
   FF7adK(self, boundFunction(FFCkhd, self, boundFunction(self.VVgwuC, webVer, title)), "Install and Restart ?", title=title)
 def VVgwuC(self, webVer, title):
  url = self.VVDPt6(self, title)
  if url:
   VVRtV7 = FFh9Bt() == "dpkg"
   if VVRtV7 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVRtV7 else "ipk")
   path, err = FFUMM6(url + fName, fName, timeout=2)
   if path:
    cmd = FFzJLp(VVc7ue, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFxQD8(self, cmd)
    else:
     FFk6P3(self, title=title)
   else:
    FFKFol(self, err, title=title)
 def VV3OAl(self, title, anyVer=False):
  url = self.VVDPt6(self, title)
  if not url:
   return ""
  path, err = FFUMM6(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFKFol(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FF0FCE(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFKFol(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVcmc0.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFhQrI(cmd)
   if list and curVer == list[0]:
    return webVer
  FFo08k(self, FFMi1p("No update required.", VVDoEn) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVDPt6(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVic63 + VV77GZ
  if fileExists(path):
   span = iSearch(r"(http.+)", FF0FCE(path), IGNORECASE)
   if span : url = FFExru(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFKFol(SELF, err, title)
  return url
 @staticmethod
 def VVw80Q(url):
  path, err = FFUMM6(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FF0FCE(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVcmc0.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFhQrI(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCecW4(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFHZVI(VVmvSf, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVKW1w
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF7MWH(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VV9dQk("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VV9dQk("\c00888888", i) + sp + "GREY\n"
   txt += self.VV9dQk("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VV9dQk("\c00FF0000", i) + sp + "RED\n"
   txt += self.VV9dQk("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VV9dQk("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VV9dQk("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VV9dQk("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VV9dQk("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VV9dQk("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VV9dQk("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VV9dQk("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV8nYP ,
   "green"   : self.VV8nYP ,
   "left"   : self.VVUv3T ,
   "right"   : self.VVIBH1 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  self.VV8Cbg()
 def VV8nYP(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FF7adK(self, self.VVKIQM, "Change to : %s" % txt, title=self.Title)
 def VVKIQM(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVKW1w
  VVKW1w = self.cursorPos
  self.VVpeFe()
  self.close()
 def VVUv3T(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV8Cbg()
 def VVIBH1(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV8Cbg()
 def VV8Cbg(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VV9dQk(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVXMXe(color):
  if VVIuu8: return "\\" + color
  else    : return ""
 @staticmethod
 def VVpeFe():
  global VVNkuN, VVRhh2, VVl05N, VVQy4t, VVSda0, VVi0qf, VVDoEn, VVIuu8, COLOR_CONS_BRIGHT_YELLOW, VVVNGK, VVlE7m, VVkCrP
  VVkCrP   = CCecW4.VV9dQk("\c00FFFFFF", VVKW1w)
  VVRhh2    = CCecW4.VV9dQk("\c00888888", VVKW1w)
  VVNkuN  = CCecW4.VV9dQk("\c005A5A5A", VVKW1w)
  VVi0qf    = CCecW4.VV9dQk("\c00FF0000", VVKW1w)
  VVl05N   = CCecW4.VV9dQk("\c00FF5000", VVKW1w)
  VVIuu8   = CCecW4.VV9dQk("\c00FFFF00", VVKW1w)
  COLOR_CONS_BRIGHT_YELLOW = CCecW4.VV9dQk("\c00FFFFAA", VVKW1w)
  VVDoEn   = CCecW4.VV9dQk("\c0000FF00", VVKW1w)
  VVSda0    = CCecW4.VV9dQk("\c000066FF", VVKW1w)
  VVVNGK    = CCecW4.VV9dQk("\c0000FFFF", VVKW1w)
  VVlE7m   = CCecW4.VV9dQk("\c00FA55E7", VVKW1w)
  VVQy4t    = CCecW4.VV9dQk("\c00FF8F5F", VVKW1w)
CCecW4.VVpeFe()
class CCRfrs(Screen):
 def __init__(self, session, path, VVRtV7):
  self.skin, self.skinParam = FFHZVI(VVqdo1, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVT1AC   = path
  self.VVkITT   = ""
  self.VVbUyP   = ""
  self.VVRtV7    = VVRtV7
  self.VVe2Wk    = ""
  self.VVlZFX  = ""
  self.VVoCMM    = False
  self.VVgAew  = False
  self.postInstAcion   = 0
  self.VVpRCe  = "enigma2-plugin-extensions"
  self.VVk4RF  = "enigma2-plugin-systemplugins"
  self.VVktTg = "enigma2"
  self.VVcJhz  = 0
  self.VVYC7m  = 1
  self.VVD4UW  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVfiaN = "DEBIAN"
  else        : self.VVfiaN = "CONTROL"
  self.controlPath = self.Path + self.VVfiaN
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVRtV7:
   self.packageExt  = ".deb"
   self.VVpeGc  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVpeGc  = "#11001020"
  FF7MWH(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFGkKQ(self["keyRed"] , "Create")
  FFGkKQ(self["keyGreen"] , "Post Install")
  FFGkKQ(self["keyYellow"], "Installation Path")
  FFGkKQ(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVdfaD  ,
   "green"   : self.VVbXzO ,
   "yellow"  : self.VVegq3  ,
   "blue"   : self.VVxrM2  ,
   "cancel"  : self.VV8hlv
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  FFHNI7(self)
  if self.VVpeGc:
   FFlSQr(self["myBody"], self.VVpeGc)
   FFlSQr(self["myLabel"], self.VVpeGc)
  self.VV74W2(True)
  self.VVN3ih(True)
 def VVN3ih(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVj1zr()
  if isFirstTime:
   if   package.startswith(self.VVpRCe) : self.VVT1AC = VVsNEX + self.VVe2Wk + "/"
   elif package.startswith(self.VVk4RF) : self.VVT1AC = VVu6LP + self.VVe2Wk + "/"
   else            : self.VVT1AC = self.Path
  if self.VVoCMM : myColor = VVQy4t
  else    : myColor = VVkCrP
  txt  = ""
  txt += "Source Path\t: %s\n" % FFMi1p(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFMi1p(self.VVT1AC, VVIuu8)
  if self.VVbUyP : txt += "Package File\t: %s\n" % FFMi1p(self.VVbUyP, VVRhh2)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFMi1p("Check Control File fields : %s" % errTxt, VVl05N)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFMi1p("Restart GUI", VVQy4t)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFMi1p("Reboot Device", VVQy4t)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFMi1p("Post Install", VVDoEn), act)
  if not errTxt and VVl05N in controlInfo:
   txt += "Warning\t: %s\n" % FFMi1p("Errors in control file may affect the result package.", VVl05N)
  txt += "\nControl File\t: %s\n" % FFMi1p(self.controlFile, VVRhh2)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVbXzO(self):
  VVtP1e = []
  VVtP1e.append(("No Action"    , "noAction"  ))
  VVtP1e.append(("Restart GUI"    , "VVszuj"  ))
  VVtP1e.append(("Reboot Device"   , "rebootDev"  ))
  FF0g9p(self, self.VVkfyX, title="Package Installation Option (after completing installation)", VVtP1e=VVtP1e)
 def VVkfyX(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVszuj"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV74W2(False)
   self.VVN3ih()
 def VVegq3(self):
  rootPath = FFMi1p("/%s/" % self.VVe2Wk, VVNkuN)
  VVtP1e = []
  VVtP1e.append(("Current Path"        , "toCurrent"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Extension Path"       , "toExtensions" ))
  VVtP1e.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVtP1e.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF0g9p(self, self.VVZGiF, title="Installation Path", VVtP1e=VVtP1e)
 def VVZGiF(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVH5HT(FFiowP(self.Path, True))
   elif item == "toExtensions"  : self.VVH5HT(VVsNEX)
   elif item == "toSystemPlugins" : self.VVH5HT(VVu6LP)
   elif item == "toRootPath"  : self.VVH5HT("/")
   elif item == "toRoot"   : self.VVH5HT("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVVYEf, boundFunction(CC2SNv, mode=CC2SNv.VVD6iE, VViFLr=VVic63))
 def VVVYEf(self, path):
  if len(path) > 0:
   self.VVH5HT(path)
 def VVH5HT(self, parent, withPackageName=True):
  if withPackageName : self.VVT1AC = parent + self.VVe2Wk + "/"
  else    : self.VVT1AC = "/"
  mode = self.VVRo4o()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVBaQW(mode), self.controlFile))
  self.VVN3ih()
 def VVxrM2(self):
  if fileExists(self.controlFile):
   lines = FFOmkW(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFXtIF(self, self.VVzCOP, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFKFol(self, "Version not found or incorrectly set !")
  else:
   FFtist(self, self.controlFile)
 def VVzCOP(self, VVjNXP):
  if VVjNXP:
   version, color = self.VV9CcS(VVjNXP, False)
   if color == VVVNGK:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVjNXP, self.controlFile))
    self.VVN3ih()
   else:
    FFKFol(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV8hlv(self):
  if self.newControlPath:
   if self.VVoCMM:
    self.VVz4ev()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFMi1p(self.newControlPath, VVRhh2)
    txt += FFMi1p("Do you want to keep these files ?", VVIuu8)
    FF7adK(self, self.close, txt, callBack_No=self.VVz4ev, title="Create Package", VVkpWv=True)
  else:
   self.close()
 def VVz4ev(self):
  os.system(FFARGV("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVBaQW(self, mode):
  if   mode == self.VVYC7m : prefix = self.VVpRCe
  elif mode == self.VVD4UW : prefix = self.VVk4RF
  else        : prefix = self.VVktTg
  return prefix + "-" + self.VVlZFX
 def VVRo4o(self):
  if   self.VVT1AC.startswith(VVsNEX) : return self.VVYC7m
  elif self.VVT1AC.startswith(VVu6LP) : return self.VVD4UW
  else            : return self.VVcJhz
 def VV74W2(self, isFirstTime):
  self.VVe2Wk   = os.path.basename(os.path.normpath(self.Path))
  self.VVe2Wk   = "_".join(self.VVe2Wk.split())
  self.VVlZFX = self.VVe2Wk.lower()
  self.VVoCMM = self.VVlZFX == VVSIK4.lower()
  if self.VVoCMM and self.VVlZFX.endswith("ajpan"):
   self.VVlZFX += "el"
  if self.VVoCMM : self.VVkITT = VVic63
  else    : self.VVkITT = CFG.packageOutputPath.getValue()
  self.VVkITT = FFExru(self.VVkITT)
  if not pathExists(self.controlPath):
   os.system(FFARGV("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVoCMM : t = PLUGIN_NAME
  else    : t = self.VVe2Wk
  self.VV2nrG(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVi2AZ.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVoCMM : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VV2nrG(self.postrmFile, txt)
  if self.VVoCMM:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVcmc0)
   self.VV2nrG(self.preinstFile, txt)
  else:
   self.VV2nrG(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVe2Wk)
  mode = self.VVRo4o()
  if isFirstTime and not mode == self.VVcJhz:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVFR4v
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VV2nrG(self.postinstFile, txt, VVnjhk=True)
  os.system(FFARGV("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVoCMM : version, descripton, maintainer = VVcmc0 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVe2Wk , self.VVe2Wk
   txt = ""
   txt += "Package: %s\n"  % self.VVBaQW(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VV2nrG(self, path, lines, VVnjhk=False):
  if not fileExists(path) or VVnjhk:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVj1zr(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFOmkW(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFMi1p(line, VVl05N)
     elif not line.startswith(" ")    : line = FFMi1p(line, VVl05N)
     else          : line = FFMi1p(line, VVVNGK)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVVNGK
   else   : color = VVl05N
   descr = FFMi1p(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVl05N
     elif line.startswith((" ", "\t")) : color = VVl05N
     elif line.startswith("#")   : color = VVRhh2
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VV9CcS(val, True)
      elif key == "Version"  : version, color = self.VV9CcS(val, False)
      elif key == "Maintainer" : maint  , color = val, VVVNGK
      elif key == "Architecture" : arch  , color = val, VVVNGK
      else:
       color = VVVNGK
      if not key == "OE" and not key.istitle():
       color = VVl05N
     else:
      color = VVQy4t
     txt += FFMi1p(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVbUyP = self.VVkITT + packageName
   self.VVgAew = True
   errTxt = ""
  else:
   self.VVbUyP  = ""
   self.VVgAew = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VV9CcS(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVVNGK
  else          : return val, VVl05N
 def VVdfaD(self):
  if not self.VVgAew:
   FFKFol(self, "Please fix Control File errors first.")
   return
  if self.VVRtV7: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFiowP(self.VVT1AC, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVe2Wk
  symlinkTo  = FFaJVe(self.Path)
  dataDir   = self.VVT1AC.rstrip("/")
  removePorjDir = FFARGV("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFARGV("rm -f '%s'" % self.VVbUyP) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFfoTU()
  if self.VVRtV7:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFvuDj("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVoCMM:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVT1AC == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVfiaN)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVbUyP, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVbUyP
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVbUyP, FFuvWX(result  , VVDoEn))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVT1AC, FFuvWX(instPath, VVVNGK))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFuvWX(failed, VVl05N))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFxQD8(self, cmd)
class CC2SNv(Screen):
 VVJ5pY   = 0
 VVD6iE  = 1
 VVSr20 = 20
 def __init__(self, session, VViFLr="/", mode=VVJ5pY, VV9T0q="Select", VVpwbP=30):
  self.skin, self.skinParam = FFHZVI(VVLE1I, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF7MWH(self)
  FFGkKQ(self["keyRed"] , "Exit")
  FFGkKQ(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV9T0q = VV9T0q
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVJ5pY  : VVEb2L, self.VViFLr = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVD6iE : VVEb2L, self.VViFLr = False, VViFLr
  else           : VVEb2L, self.VViFLr = True , VViFLr
  VViFLr = FFExru(VViFLr)
  self["myMenu"] = CCsGa5(  directory   = "/"
         , VVEb2L   = VVEb2L
         , VVVwbr = True
         , VVmDmW   = self.skinParam["width"]
         , VVpwbP   = self.skinParam["bodyFontSize"]
         , VVCfMB  = self.skinParam["bodyLineH"]
         , VV4bS2  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV8nYP      ,
   "red"    : self.cancel      ,
   "green"    : self.VVmiwU    ,
   "yellow"   : self.VVy9Et   ,
   "blue"    : self.VVexqu   ,
   "menu"    : self.VVzzz4    ,
   "info"    : self.VVpC48    ,
   "cancel"   : self.VV3830     ,
   "pageUp"   : self.VV3830     ,
   "chanUp"   : self.VV3830
  }, -1)
  FFg0z1(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVnMA0)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVnMA0)
  FFjk8P(self["myMenu"], bg="#06003333")
  FFHNI7(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VVD6iE:
   FFGkKQ(self["keyGreen"], self.VV9T0q)
   color = "#22000022"
   FFlSQr(self["myBody"], color)
   FFlSQr(self["myMenu"], color)
   color = "#22220000"
   FFlSQr(self["myTitle"], color)
   FFlSQr(self["myBar"], color)
  self.VVnMA0()
  if self.VV8dZU(self.VViFLr) > self.bigDirSize:
   FFt82g(self, "Changing directory...")
   FFTTch(self.VVU1Pm)
  else:
   self.VVU1Pm()
 def VVU1Pm(self):
  self["myMenu"].VVSMqW(self.VViFLr)
 def VVbPRY(self):
  self["myMenu"].refresh()
  FFhwKI()
 def VV8dZU(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VV8nYP(self):
  if self["myMenu"].VVDgFD():
   path = self.VVAiwW(self.VVgdWR())
   if self.VV8dZU(path) > self.bigDirSize:
    FFt82g(self, "Changing directory...")
    FFTTch(self.VVkywf)
   else:
    self.VVkywf()
  else:
   self.VV6kMP()
 def VVkywf(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVnMA0()
 def VV3830(self):
  if self["myMenu"].VV4DSR():
   self["myMenu"].moveToIndex(0)
   self.VVkywf()
 def cancel(self):
  if not FF3By6(self):
   self.close("")
 def VVmiwU(self):
  if self.mode == self.VVD6iE:
   path = self.VVAiwW(self.VVgdWR())
   self.close(path)
 def VVpC48(self):
  FFCkhd(self, self.VVB8UT, title="Calculating size ...")
 def VVB8UT(self):
  path = self.VVAiwW(self.VVgdWR())
  param = self.VVhtEO(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFgaUh("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFgaUh("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVx6fM(size), format(size, ',d'))
   else   : size = "%s" % self.VVx6fM(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFMi1p(pathTxt, VVQy4t) + "\n"
   if slBroken : fileTime = self.VVQ0zi(path)
   else  : fileTime = self.VVe2Il(path)
   def VVhxKH(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVhxKH("Path"    , pathTxt)
   txt += VVhxKH("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVhxKH("Target"   , slTarget)
   txt += VVhxKH("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVhxKH("Owner"    , owner)
   txt += VVhxKH("Group"    , group)
   txt += VVhxKH("Perm. (User)"  , permUser)
   txt += VVhxKH("Perm. (Group)"  , permGroup)
   txt += VVhxKH("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVhxKH("Perm. (Ext.)" , permExtra)
   txt += VVhxKH("iNode"    , iNode)
   txt += VVhxKH("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVFR4v, VVFR4v)
    txt += hLinkedFiles
  else:
   FFKFol(self, "Cannot access information !")
  if len(txt) > 0:
   FFuPDq(self, txt)
 def VVhtEO(self, path):
  path = path.strip()
  path = FFaJVe(path)
  result = FFgaUh("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVgxVV(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVgxVV(perm, 1, 4)
   permGroup = VVgxVV(perm, 4, 7)
   permOther = VVgxVV(perm, 7, 10)
   permExtra = VVgxVV(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FF0S1I("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVe2Il(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFMoES(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFMoES(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFMoES(os.path.getctime(path))
  return txt
 def VVQ0zi(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFgaUh("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFgaUh("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFgaUh("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVx6fM(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVAiwW(self, currentSel):
  currentDir  = self["myMenu"].VV4DSR()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVDgFD():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVgdWR(self):
  return self["myMenu"].getSelection()[0]
 def VVnMA0(self):
  FFt82g(self)
  path = self.VVAiwW(self.VVgdWR())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV7oZO = self.VVitvk()
  if VV7oZO and len(VV7oZO) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVO5LP(path)
  if self.mode == self.VVJ5pY and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVO5LP(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVX39C(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVzzz4(self):
  if self.mode == self.VVJ5pY:
   path  = self.VVAiwW(self.VVgdWR())
   isDir  = os.path.isdir(path)
   VVtP1e = []
   VVtP1e.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VV9MDN(path):
     sepShown = True
     VVtP1e.append(VV6Efe)
     VVtP1e.append( (VVQy4t + "Archiving / Packaging"      , "VVujaR"  ))
    if self.VVJG8o(path):
     if not sepShown:
      VVtP1e.append(VV6Efe)
     VVtP1e.append( (VVQy4t + "Read Backup information"     , "VVHp8Y"  ))
     VVtP1e.append( (VVQy4t + "Compress Octagon Image (to zip File)"  , "VVNtZe" ))
   elif os.path.isfile(path):
    selFile = self.VVgdWR()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVtP1e.extend(self.VVGeu4(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVtP1e.extend(self.VVVnRK(True))
    elif selFile.endswith(".m3u")              : VVtP1e.extend(self.VVUYga(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFDVOM(path):
     VVtP1e.append(VV6Efe)
     VVtP1e.append((VVQy4t + "View" , "text_View" ))
     VVtP1e.append((VVQy4t + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVtP1e.append(VV6Efe)
     VVtP1e.append(   (VVQy4t + txt      , "VV6kMP"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(     ("Create SymLink"       , "VVH93x" ))
   if not self.VV9MDN(path):
    VVtP1e.append(   ("Rename"          , "VVT5B8" ))
    VVtP1e.append(   ("Copy"           , "copyFileOrDir" ))
    VVtP1e.append(   ("Move"           , "moveFileOrDir" ))
    VVtP1e.append(   ("DELETE"          , "VVYJdN" ))
    if fileExists(path):
     VVtP1e.append(VV6Efe)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVtP1e.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVtP1e.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVtP1e.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVtP1e.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVtP1e.append(VV6Efe)
   VVtP1e.append(    ("Set current directory as \"Startup Path\"" , "VVU37h" ))
   FF0g9p(self, self.VVTSAB, title="Options", VVtP1e=VVtP1e)
 def VVTSAB(self, item=None):
  if self.mode == self.VVJ5pY:
   if item is not None:
    path = self.VVAiwW(self.VVgdWR())
    selFile = self.VVgdWR()
    if   item == "properties"    : self.VVpC48()
    elif item == "VVujaR"  : self.VVujaR(path)
    elif item == "VVHp8Y"  : self.VVHp8Y(path)
    elif item == "VVNtZe" : self.VVNtZe(path)
    elif item.startswith("extract_")  : self.VVdEyi(path, selFile, item)
    elif item.startswith("script_")   : self.VVQgvT(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVLBbSItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFYaEL(self, path)
    elif item.startswith("text_Edit")  : CCsBZy(self, path)
    elif item == "chmod644"     : self.VVCp4d(path, selFile, "644")
    elif item == "chmod755"     : self.VVCp4d(path, selFile, "755")
    elif item == "chmod777"     : self.VVCp4d(path, selFile, "777")
    elif item == "VVH93x"   : self.VVH93x(path, selFile)
    elif item == "VVT5B8"   : self.VVT5B8(path, selFile)
    elif item == "copyFileOrDir"   : self.VVRAoJ(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVRAoJ(path, selFile, True)
    elif item == "VVYJdN"   : self.VVYJdN(path, selFile)
    elif item == "createNewFile"   : self.VV58Tn(path, True)
    elif item == "createNewDir"    : self.VV58Tn(path, False)
    elif item == "VVU37h"   : self.VVU37h(path)
    elif item == "VV6kMP"    : self.VV6kMP()
    else         : self.close()
 def VV6kMP(self):
  selFile = self.VVgdWR()
  path  = self.VVAiwW(selFile)
  if os.path.isfile(path):
   VV4uLj = []
   category = self["myMenu"].VVnRrJ(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVUozR(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFWECZ(self, selFile, path)
   elif category == "txt"         : FFYaEL(self, path)
   elif category in ("tar", "zip")       : self.VV4jfq(path, selFile)
   elif category == "scr"         : self.VVPE0e(path, selFile)
   elif category == "m3u"         : self.VV8Tfx(path, selFile)
   elif category in ("ipk", "deb")       : self.VVV7Qi(path, selFile)
   elif category == "mus"         : self.VV77vx(path)
   elif category == "mov"         : self.VV77vx(path)
   elif not FFDVOM(path)        : FFYaEL(self, path)
 def VV77vx(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFKzCJ(self, refCode)
  except:
   pass
 def VVy9Et(self):
  path = self.VVAiwW(self.VVgdWR())
  action = self.VVO5LP(path)
  if action == 1:
   self.VVJJwC(path)
   FFt82g(self, "Added", 500)
  elif action == -1:
   self.VVnRUv(path)
   FFt82g(self, "Removed", 500)
  self.VVO5LP(path)
 def VVJJwC(self, path):
  VV7oZO = self.VVitvk()
  if not VV7oZO:
   VV7oZO = []
  if len(VV7oZO) >= self.VVSr20:
   FFKFol(SELF, "Max bookmarks reached (max=%d)." % self.VVSr20)
  elif not path in VV7oZO:
   VV7oZO = [path] + VV7oZO
   self.VVfxcx(VV7oZO)
 def VVexqu(self):
  VV7oZO = self.VVitvk()
  if VV7oZO:
   newList = []
   for line in VV7oZO:
    newList.append((line, line))
   VVxdDY  = ("Delete"  , self.VV5Zmz )
   VV0Jrh = ("Move Up"   , self.VVI8DU )
   VVhCvA  = ("Move Down" , self.VV9msy )
   self.bookmarkMenu = FF0g9p(self, self.VVfobn, title="Bookmarks", VVtP1e=newList, VVxdDY=VVxdDY, VV0Jrh=VV0Jrh, VVhCvA=VVhCvA)
 def VV5Zmz(self, VVgdWRObj, path):
  if self.bookmarkMenu:
   VV7oZO = self.VVnRUv(path)
   self.bookmarkMenu.VVoNi4(VV7oZO)
 def VVI8DU(self, VVgdWRObj, path):
  if self.bookmarkMenu:
   VV7oZO = self.bookmarkMenu.VV0Rqc(True)
   if VV7oZO:
    self.VVfxcx(VV7oZO)
 def VV9msy(self, VVgdWRObj, path):
  if self.bookmarkMenu:
   VV7oZO = self.bookmarkMenu.VV0Rqc(False)
   if VV7oZO:
    self.VVfxcx(VV7oZO)
 def VVfobn(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVSMqW(folder)
   self["myMenu"].moveToIndex(0)
  self.VVnMA0()
 def VVitvk(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVX39C(self, path):
  VV7oZO = self.VVitvk()
  if VV7oZO and path in VV7oZO:
   return True
  else:
   return False
 def VV7jbW(self):
  if VVitvk():
   return True
  else:
   return False
 def VVfxcx(self, VV7oZO):
  line = ",".join(VV7oZO)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVnRUv(self, path):
  VV7oZO = self.VVitvk()
  if VV7oZO:
   while path in VV7oZO:
    VV7oZO.remove(path)
   self.VVfxcx(VV7oZO)
   return VV7oZO
 def VVU37h(self, path):
  if not os.path.isdir(path):
   path = FFiowP(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVUozR(self, selFile, VVeMZz, command):
  FF7adK(self, boundFunction(FFxQD8, self, command, VVGvDX=self.VVbPRY), "%s\n\n%s" % (VVeMZz, selFile))
 def VVGeu4(self, path, calledFromMenu):
  destPath = self.VVr5dx(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVtP1e = []
  if calledFromMenu:
   VVtP1e.append(VV6Efe)
   color = VVQy4t
  else:
   color = ""
  VVtP1e.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVtP1e.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVtP1e.append((color + "Extract Here"            , "extract_here"  ))
  if VVHke5 and path.endswith(".tar.gz"):
   VVtP1e.append(VV6Efe)
   VVtP1e.append((color + 'Convert to ".ipk" Package' , "VVxuHN"  ))
   VVtP1e.append((color + 'Convert to ".deb" Package' , "VVLeig"  ))
  return VVtP1e
 def VV4jfq(self, path, selFile):
  FF0g9p(self, boundFunction(self.VVdEyi, path, selFile), title="Tar File Options", VVtP1e=self.VVGeu4(path, False))
 def VVdEyi(self, path, selFile, item=None):
  if item is not None:
   parent  = FFiowP(path, False)
   destPath = self.VVr5dx(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVFR4v
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVFR4v, VVFR4v)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFPyAy(self, cmd)
   elif path.endswith(".zip"):
    self.VVQlfA(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFARGV("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVUozR(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVUozR(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFiowP(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVUozR(selFile, "Extract Here ?"      , cmd)
   elif item == "VVxuHN" : self.VVxuHN(path)
   elif item == "VVLeig" : self.VVLeig(path)
 def VVr5dx(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVQlfA(self, item, path, parent, destPath, VVeMZz):
  FF7adK(self, boundFunction(self.VVjbF8, item, path, parent, destPath), VVeMZz)
 def VVjbF8(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVFR4v
  cmd  = FFvuDj("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFuvWX(destPath, VVDoEn))
  cmd +=   sep
  cmd += "fi;"
  FFsbrK(self, cmd, VVGvDX=self.VVbPRY)
 def VVVnRK(self, addSep=False):
  VVtP1e = []
  if addSep:
   VVtP1e.append(VV6Efe)
  VVtP1e.append((VVQy4t + "View Script File"  , "script_View"  ))
  VVtP1e.append((VVQy4t + "Execute Script File" , "script_Execute" ))
  VVtP1e.append((VVQy4t + "Edit"     , "script_Edit" ))
  return VVtP1e
 def VVPE0e(self, path, selFile):
  FF0g9p(self, boundFunction(self.VVQgvT, path, selFile), title="Script File Options", VVtP1e=self.VVVnRK())
 def VVQgvT(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFYaEL(self, path)
   elif item == "script_Execute" : self.VVUozR(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCsBZy(self, path)
 def VVUYga(self, addSep=False):
  VVtP1e = []
  if addSep:
   VVtP1e.append(VV6Efe)
  VVtP1e.append((VVQy4t + "View"      , "m3u_View" ))
  VVtP1e.append((VVQy4t + "Edit"      , "m3u_Edit" ))
  VVtP1e.append((VVQy4t + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVtP1e
 def VV8Tfx(self, path, selFile):
  FF0g9p(self, boundFunction(self.VVLBbSItem_m3u, path, selFile), title="M3U File Options", VVtP1e=self.VVUYga())
 def VVLBbSItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFYaEL(self, path)
   elif item == "m3u_Edit"  : CCsBZy(self, path)
   elif item == "m3u_Convert" : CCaJkM.VVlDm7(self, path, False)
 def VVCp4d(self, path, selFile, newChmod):
  FF7adK(self, boundFunction(self.VVgaPw, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVgaPw(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVvjJi)
  result = FFgaUh(cmd)
  if result == "Successful" : FFo08k(self, result)
  else      : FFKFol(self, result)
 def VVH93x(self, path, selFile):
  parent = FFiowP(path, False)
  self.session.openWithCallback(self.VV38FI, boundFunction(CC2SNv, mode=CC2SNv.VVD6iE, VViFLr=parent, VV9T0q="Create Symlink here"))
 def VV38FI(self, newPath):
  if len(newPath) > 0:
   target = self.VVAiwW(self.VVgdWR())
   target = FFaJVe(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFExru(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFKFol(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FF7adK(self, boundFunction(self.VVTymy, target, link), "Create Soft Link ?\n\n%s" % txt, VVkpWv=True)
 def VVTymy(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVvjJi)
  result = FFgaUh(cmd)
  if result == "Successful" : FFo08k(self, result)
  else      : FFKFol(self, result)
 def VVT5B8(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFXtIF(self, boundFunction(self.VVwvO8, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVwvO8(self, path, selFile, VVjNXP):
  if VVjNXP:
   parent = FFiowP(path, True)
   if os.path.isdir(path):
    path = FFaJVe(path)
   newName = parent + VVjNXP
   cmd = "mv '%s' '%s' %s" % (path, newName, VVvjJi)
   if VVjNXP:
    if selFile != VVjNXP:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FF7adK(self, boundFunction(self.VVcCSL, cmd), message, title="Rename file?")
    else:
     FFKFol(self, "Cannot use same name!", title="Rename")
 def VVcCSL(self, cmd):
  result = FFgaUh(cmd)
  if "Fail" in result:
   FFKFol(self, result)
  self.VVbPRY()
 def VVRAoJ(self, path, selFile, isMove):
  if isMove : VV9T0q = "Move to here"
  else  : VV9T0q = "Copy to here"
  parent = FFiowP(path, False)
  self.session.openWithCallback(boundFunction(self.VVga5E, isMove, path, selFile)
         , boundFunction(CC2SNv, mode=CC2SNv.VVD6iE, VViFLr=parent, VV9T0q=VV9T0q))
 def VVga5E(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFaJVe(path)
   newPath = FFExru(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FF7adK(self, boundFunction(FFtERc, self, cmd, VVGvDX=self.VVbPRY), txt, VVkpWv=True)
   else:
    FFKFol(self, "Cannot %s to same directory !" % action.lower())
 def VVYJdN(self, path, fileName):
  path = FFaJVe(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FF7adK(self, boundFunction(self.VVRAYq, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVRAYq(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVbPRY()
 def VV9MDN(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVNqXw and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV58Tn(self, path, isFile):
  dirName = FFExru(os.path.dirname(path))
  if isFile : objName, VVjNXP = "File"  , self.edited_newFile
  else  : objName, VVjNXP = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFXtIF(self, boundFunction(self.VVyh8B, dirName, isFile, title), title=title, defaultText=VVjNXP, message="Enter %s Name:" % objName)
 def VVyh8B(self, dirName, isFile, title, VVjNXP):
  if VVjNXP:
   if isFile : self.edited_newFile = VVjNXP
   else  : self.edited_newDir  = VVjNXP
   path = dirName + VVjNXP
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVvjJi)
    else  : cmd = "mkdir '%s' %s" % (path, VVvjJi)
    result = FFgaUh(cmd)
    if "Fail" in result:
     FFKFol(self, result)
    self.VVbPRY()
   else:
    FFKFol(self, "Name already exists !\n\n%s" % path, title)
 def VVV7Qi(self, path, selFile):
  VVtP1e = []
  VVtP1e.append(("List Package Files"          , "VVeCv7"     ))
  VVtP1e.append(("Package Information"          , "VVN36O"     ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Install Package"           , "VVh9pz_CheckVersion" ))
  VVtP1e.append(("Install Package (force reinstall)"      , "VVh9pz_ForceReinstall" ))
  VVtP1e.append(("Install Package (force downgrade)"      , "VVh9pz_ForceDowngrade" ))
  VVtP1e.append(("Install Package (ignore failed dependencies)"    , "VVh9pz_IgnoreDepends" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Remove Related Package"         , "VVOq7V_ExistingPackage" ))
  VVtP1e.append(("Remove Related Package (force remove)"     , "VVOq7V_ForceRemove"  ))
  VVtP1e.append(("Remove Related Package (ignore failed dependencies)"  , "VVOq7V_IgnoreDepends" ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("Extract Files"           , "VVgDOe"     ))
  VVtP1e.append(("Unbuild Package"           , "VVqHym"     ))
  FF0g9p(self, boundFunction(self.VVc2FE, path, selFile), VVtP1e=VVtP1e)
 def VVc2FE(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVeCv7"      : self.VVeCv7(path, selFile)
   elif item == "VVN36O"      : self.VVN36O(path)
   elif item == "VVh9pz_CheckVersion"  : self.VVh9pz(path, selFile, VVOWgY     )
   elif item == "VVh9pz_ForceReinstall" : self.VVh9pz(path, selFile, VVc7ue )
   elif item == "VVh9pz_ForceDowngrade" : self.VVh9pz(path, selFile, VVla2Z )
   elif item == "VVh9pz_IgnoreDepends" : self.VVh9pz(path, selFile, VVvnCM )
   elif item == "VVOq7V_ExistingPackage" : self.VVOq7V(path, selFile, VVBnTk     )
   elif item == "VVOq7V_ForceRemove"  : self.VVOq7V(path, selFile, VVd6n8  )
   elif item == "VVOq7V_IgnoreDepends"  : self.VVOq7V(path, selFile, VVkxGy )
   elif item == "VVgDOe"     : self.VVgDOe(path, selFile)
   elif item == "VVqHym"     : self.VVqHym(path, selFile)
   else           : self.close()
 def VVeCv7(self, path, selFile):
  if FF0XMr("ar") : cmd = "allOK='1';"
  else    : cmd  = FFfoTU()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVFR4v, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVFR4v, VVFR4v)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFO99q(self, cmd, VVGvDX=self.VVbPRY)
 def VVgDOe(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFiowP(path, True) + selFile[:-4]
  cmd  =  FFfoTU()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFARGV("mkdir '%s'" % dest) + ";"
  cmd +=    FFARGV("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFuvWX(dest, VVDoEn))
  cmd += "fi;"
  FFxQD8(self, cmd, VVGvDX=self.VVbPRY)
 def VVqHym(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVnLkc = os.path.splitext(path)[0]
  else        : VVnLkc = path + "_"
  if path.endswith(".deb")   : VVfiaN = "DEBIAN"
  else        : VVfiaN = "CONTROL"
  cmd  = FFfoTU()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVnLkc, FF86rl())
  cmd += "  mkdir '%s';"    % VVnLkc
  cmd += "  CONTPATH='%s/%s';"  % (VVnLkc, VVfiaN)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVnLkc
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVnLkc, VVnLkc)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVnLkc
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVnLkc, VVnLkc)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVnLkc
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVnLkc
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVnLkc, FFuvWX(VVnLkc, VVDoEn))
  cmd += "fi;"
  FFxQD8(self, cmd, VVGvDX=self.VVbPRY)
 def VVN36O(self, path):
  listCmd  = FFlm1I(VV8Sak, "")
  infoCmd  = FFzJLp(VVCSXC , "")
  filesCmd = FFzJLp(VVFCPa, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFoPGL(VVIuu8)
   notInst = "Package not installed."
   cmd  = FFi1ok("File Info", VVIuu8)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFi1ok("System Info", VVIuu8)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFuvWX(notInst, VVQy4t))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFi1ok("Related Files", VVIuu8)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFPyAy(self, cmd)
  else:
   FFk6P3(self)
 def VVh9pz(self, path, selFile, cmdOpt):
  cmd = FFzJLp(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FF7adK(self, boundFunction(FFxQD8, self, cmd, VVGvDX=FFhwKI), "Install Package ?\n\n%s" % selFile)
  else:
   FFk6P3(self)
 def VVOq7V(self, path, selFile, cmdOpt):
  listCmd  = FFlm1I(VV8Sak, "")
  infoCmd  = FFzJLp(VVCSXC, "")
  instRemCmd = FFzJLp(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFuvWX(errTxt, VVQy4t))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFuvWX(cannotTxt, VVQy4t))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFuvWX(tryTxt, VVQy4t))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FF7adK(self, boundFunction(FFxQD8, self, cmd, VVGvDX=FFhwKI), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFk6P3(self)
 def VVqxoy(self, path):
  hostName = FFgaUh("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVJG8o(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVqxoy(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVujaR(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVtP1e = []
  VVtP1e.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVtP1e.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVtP1e.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVtP1e.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVtP1e.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVtP1e.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVtP1e.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVtP1e.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVtP1e.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVtP1e.append(VV6Efe)
  VVtP1e.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVtP1e.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF0g9p(self, boundFunction(self.VVrxnI, path), VVtP1e=VVtP1e)
 def VVrxnI(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVrAUt(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVrAUt(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVrAUt(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVrAUt(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVrAUt(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVrAUt(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVrAUt(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVrAUt(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVrAUt(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVrAUt(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVmaBD(path, False)
   elif item == "convertDirToDeb"   : self.VVmaBD(path, True)
   else         : self.close()
 def VVmaBD(self, path, VVRtV7):
  self.session.openWithCallback(self.VVbPRY, boundFunction(CCRfrs, path=path, VVRtV7=VVRtV7))
 def VVrAUt(self, path, fileExt, preserveDirStruct):
  parent  = FFiowP(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFvuDj("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFvuDj("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFvuDj("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVFR4v
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFARGV("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFuvWX(resultFile, VVDoEn))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFuvWX(failed, VVl05N))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFO99q(self, cmd, VVGvDX=self.VVbPRY)
 def VVHp8Y(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFYaEL(self, versionFile)
 def VVNtZe(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVqxoy(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFKFol(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFOmkW(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFiowP(path, False)
  VVnLkc = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFuvWX(errCmd, VVl05N))
  installCmd = FFzJLp(VVOWgY , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVnLkc, VVnLkc)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVnLkc
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVnLkc
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVnLkc, VVnLkc)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFxQD8(self, cmd, VVGvDX=self.VVbPRY)
 def VVxuHN(self, path):
  FFKFol(self, "Under Construction.")
 def VVLeig(self, path):
  FFKFol(self, "Under Construction.")
class CCsGa5(MenuList):
 def __init__(self, VVVwbr=False, directory="/", VVDAU8=True, VVEb2L=True, VVXD6D=True, VVj1NM=None, VVESVS=False, VVal21=False, VVltXR=False, isTop=False, VVm985=None, VVmDmW=1000, VVpwbP=30, VVCfMB=30, VV4bS2="#00000000"):
  MenuList.__init__(self, list, VVVwbr, eListboxPythonMultiContent)
  self.VVDAU8  = VVDAU8
  self.VVEb2L    = VVEb2L
  self.VVXD6D  = VVXD6D
  self.VVj1NM  = VVj1NM
  self.VVESVS   = VVESVS
  self.VVal21   = VVal21 or []
  self.VVltXR   = VVltXR or []
  self.isTop     = isTop
  self.additional_extensions = VVm985
  self.VVmDmW    = VVmDmW
  self.VVpwbP    = VVpwbP
  self.VVCfMB    = VVCfMB
  self.pngBGColor    = FFahGT(VV4bS2)
  self.EXTENSIONS    = self.VVZcOJ()
  self.VVxNcv   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVgk1L, self.VVpwbP))
  self.l.setItemHeight(self.VVCfMB)
  self.png_mem   = self.VVPqb7("mem")
  self.png_usb   = self.VVPqb7("usb")
  self.png_fil   = self.VVPqb7("fil")
  self.png_dir   = self.VVPqb7("dir")
  self.png_dirup   = self.VVPqb7("dirup")
  self.png_srv   = self.VVPqb7("srv")
  self.png_slwfil   = self.VVPqb7("slwfil")
  self.png_slbfil   = self.VVPqb7("slbfil")
  self.png_slwdir   = self.VVPqb7("slwdir")
  self.VV9S2X()
  self.VVSMqW(directory)
 def VVPqb7(self, category):
  return LoadPixmap("%s%s.png" % (VVsT5j, category), getDesktop(0))
 def VVZcOJ(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVAGVZ(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFaJVe(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFMi1p(" -> " , VVIuu8) + FFMi1p(os.readlink(path), VVDoEn)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVCfMB + 10, 0, self.VVmDmW, self.VVCfMB, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV7mfb: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVCfMB-4, self.VVCfMB-4, png, self.pngBGColor, self.pngBGColor, VV7mfb))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVCfMB-4, self.VVCfMB-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVnRrJ(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VV9S2X(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVmCNe(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV4Fql(self, file):
  if os.path.realpath(file) == file:
   return self.VVmCNe(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVmCNe(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVmCNe(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVIzDJ(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVxNcv.info(l[0][0]).getEvent(l[0][0])
 def VVqC0H(self):
  return self.list
 def VVN7td(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVSMqW(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVXD6D:
    self.current_mountpoint = self.VV4Fql(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVXD6D:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVltXR and not self.VVN7td(path, self.VVal21):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVAGVZ(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVESVS:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVxNcv = eServiceCenter.getInstance()
   list = VVxNcv.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVDAU8 and not self.isTop:
   if directory == self.current_mountpoint and self.VVXD6D:
    self.list.append(self.VVAGVZ(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVltXR and self.VVmCNe(directory) in self.VVltXR):
    self.list.append(self.VVAGVZ(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVDAU8:
   for x in directories:
    if not (self.VVltXR and self.VVmCNe(x) in self.VVltXR) and not self.VVN7td(x, self.VVal21):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVAGVZ(name = name, absolute = x, isDir = True, png = png))
  if self.VVEb2L:
   for x in files:
    if self.VVESVS:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFMi1p(" -> " , VVIuu8) + FFMi1p(target, VVDoEn)
       else:
        png = self.png_slbfil
        name += FFMi1p(" -> " , VVIuu8) + FFMi1p(target, VVl05N)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVnRrJ(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVsT5j, category))
    if (self.VVj1NM is None) or iCompile(self.VVj1NM).search(path):
     self.list.append(self.VVAGVZ(name = name, absolute = x , isDir = False, png = png))
  if self.VVXD6D and len(self.list) == 0:
   self.list.append(self.VVAGVZ(name = FFMi1p("No USB connected", VVRhh2), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VV4DSR(self):
  return self.current_directory
 def VVDgFD(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVSMqW(self.getSelection()[0], select = self.current_directory)
 def VV6nkk(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVwmnU(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVeC53)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVeC53)
 def refresh(self):
  self.VVSMqW(self.current_directory, self.VV6nkk())
 def VVeC53(self, action, device):
  self.VV9S2X()
  if self.current_directory is None:
   self.refresh()
class CCFJbF(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFHZVI(VVNGcB, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV7oZO   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVadrn(defFG, "#00FFFFFF")
  self.defBG   = self.VVadrn(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF7MWH(self, self.Title)
  self["keyRed"].show()
  FFGkKQ(self["keyGreen"] , "< > Transp.")
  FFGkKQ(self["keyYellow"], "Foreground")
  FFGkKQ(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVWWDE        ,
   "yellow"   : boundFunction(self.VVGlRN, False)  ,
   "blue"   : boundFunction(self.VVGlRN, True)  ,
   "up"   : self.VVslN2          ,
   "down"   : self.VVYyfx         ,
   "left"   : self.VVUv3T         ,
   "right"   : self.VVIBH1         ,
   "last"   : boundFunction(self.VVSU5h, -5) ,
   "next"   : boundFunction(self.VVSU5h, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVyQ2h)
 def VVyQ2h(self):
  self.onShown.remove(self.VVyQ2h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFlSQr(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFlSQr(self["keyRed"] , c)
  FFlSQr(self["keyGreen"] , c)
  self.VVkNGI()
  self.VVy5xQ()
  FFFxI3(self["myColorTst"], self.defFG)
  FFlSQr(self["myColorTst"], self.defBG)
 def VVadrn(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVy5xQ(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVUswU(0, 0)
     return
 def VVWWDE(self):
  self.close(self.defFG, self.defBG)
 def VVslN2(self): self.VVUswU(-1, 0)
 def VVYyfx(self): self.VVUswU(1, 0)
 def VVUv3T(self): self.VVUswU(0, -1)
 def VVIBH1(self): self.VVUswU(0, 1)
 def VVUswU(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVCWKM()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVMwvK()
 def VVkNGI(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVMwvK(self):
  color = self.VVCWKM()
  if self.isBgMode: FFlSQr(self["myColorTst"], color)
  else   : FFFxI3(self["myColorTst"], color)
 def VVGlRN(self, isBg):
  self.isBgMode = isBg
  self.VVkNGI()
  self.VVy5xQ()
 def VVSU5h(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVUswU(0, 0)
 def VVpjbU(self):
  return hex(self.transp)[2:].zfill(2)
 def VVCWKM(self):
  return ("#%s%s" % (self.VVpjbU(), self.colors[self.curRow][self.curCol])).upper()
class CCFzsY(ScrollLabel):
 def __init__(self, parentSELF, text="", VVQTkT=True):
  ScrollLabel.__init__(self, text)
  self.VVQTkT=VVQTkT
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVntDP  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVpwbP    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVGwZo   ,
   "green"   : self.VVtb9z  ,
   "yellow"  : self.VVrwXz  ,
   "blue"   : self.VVabIn  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VV4Qd7    ,
   "chanUp"  : self.VV4Qd7    ,
   "pageDown"  : self.VVTiUQ    ,
   "chanDown"  : self.VVTiUQ
  }, -1)
 def VVVSbd(self, isResizable=True, VVGF0H=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFHNI7(self.parentSELF, True)
  self.isResizable = isResizable
  if VVGF0H:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVpwbP  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFlSQr(self, color)
 def FFlSQrColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVntDP - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVGWXz()
 def pageUp(self):
  if self.VVntDP > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVntDP > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV4Qd7(self):
  self.setPos(0)
 def VVTiUQ(self):
  self.setPos(self.VVntDP-self.pageHeight)
 def VV9Vso(self):
  return self.VVntDP <= self.pageHeight or self.curPos == self.VVntDP - self.pageHeight
 def VVGWXz(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVntDP, 3))
   start = int((100 - vis) * self.curPos / (self.VVntDP - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVNQut=VV3npe):
  old_VV9Vso = self.VV9Vso()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVntDP = self.long_text.calculateSize().height()
   if self.VVQTkT and self.VVntDP > self.pageHeight:
    self.scrollbar.show()
    self.VVGWXz()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVntDP))
   if   VVNQut == VVKIxe: self.setPos(0)
   elif VVNQut == VV1ZNL : self.VVTiUQ()
   elif old_VV9Vso    : self.VVTiUQ()
 def appendText(self, text, VVNQut=VV1ZNL):
  self.setText(self.message + str(text), VVNQut)
 def VVrwXz(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVrPY3(size)
 def VVabIn(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVrPY3(size)
 def VVtb9z(self):
  self.VVrPY3(self.VVpwbP)
 def VVrPY3(self, VVpwbP):
  self.long_text.setFont(gFont(self.fontFamily, VVpwbP))
  self.setText(self.message, VVNQut=VV3npe)
  self.VV0TCs(calledFromFontSizer=True)
 def VVGwZo(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFExru(expPath), self.textOutFile, FFtTMB())
    with open(outF, "w") as f:
     f.write(FFTcL7(self.message))
    FFo08k(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFKFol(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV0TCs(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVntDP > 0 and self.pageHeight > 0:
   if self.VVntDP < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVntDP
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
