import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVkRol   = "v8.6.1"
VVUOLu    = "27-02-2023"
EASY_MODE    = 0
VVf3wI   = 0
VVjnfj   = 0
VV3ket  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VV35QH  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVn5zG    = "/media/usb/"
VVOVBa    = "/usr/share/enigma2/picon/"
VVXFf1 = "/etc/enigma2/blacklist"
VVKSHN   = "/etc/enigma2/"
VVpToT   = "AJPan"
VVNY3V  = "AUTO FIND"
VV69rC  = "Custom"
VVvZeW  = None
VVr97O    = ""
VVN3E9 = "Regular"
VVGmMn = "Fixed"
VV641B  = "AJP_Main"
VVoFWh = "AJP_Terminal"
VV66Jh = "AJP_System"
VVoHbv  = VVN3E9
VV6yYU    = ""
VVso67   = " && echo 'Successful' || echo 'Failed!'"
VV2Pt1  = "Cannot continue (No Enough Memory) !"
VVZ4OB  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVA5PC  = "utf8"
VVzHzv    = ("-" * 100, )
SEP      = "-" * 80
VVQrwB  = False
VVmTYx  = False
VVAfZq     = 0
VVvBiK    = 1
VV7DNj    = 2
VVDOlP   = 3
VVLyZo    = 4
VVBqoq    = 5
VVCmnq = 6
VVmJx6 = 7
VVGr3W  = 8
VVvs8q   = 9
VVnYzd  = 10
VVOOPZ  = 11
VVw4no = 12
VVlPyO = 13
VVVBB0 = 14
VV122f  = 15
VVmKq8    = 16
VVlSRC   = 17
VVkwlJ   = 18
VVWDEH    = 19
VVfxqt    = 20
VVWpcL  = 21
VVHFSz    = 22
VVnE8x   = 0
VVJKXb   = 1
VVVykt   = 2
def FFQN3h():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVoHbv
  if VV641B in lst and CFG.fontPathMain.getValue(): VVoHbv = VV641B
  else               : VVoHbv = VVN3E9
  return lst
 else:
  return [VVN3E9]
def FFy505(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVA5PC)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVNY3V, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelection(default=2, choices=[(x, str(x)) for x in range(1, 6, 1)])
CFG.PIconsPath     = ConfigDirectory(default=VVOVBa, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVn5zG, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVoHbv, choices=[(x,  x) for x in FFQN3h()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFelxB():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVvNzJ  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVZH9W = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVvNzJ  : return 0
  elif VVZH9W : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVoSGn = FFelxB()
VVPwgj = VVrVS3 = VVHEBa = VVgmAg = VVL6GV = VVAQIK = VVjK42 = VVXhzj = VVd7n9 = VVL7a3 = VVMdMA = VVhb13 = VViC5D = VVVJaM = VVuURa = VVWK7B = ""
def FFsEOn()  : FF8Uxk(FFnvTI())
def FF9H3Z()  : FF8Uxk(FFgdro())
def FFNQ72(tDict): FF8Uxk(iDumps(tDict, indent=4, sort_keys=True))
def FFTjIV(*args): FFsB86(True, True, *args)
def FF8Uxk(*args) : FFsB86(True , False , *args)
def FFsAUL(*args): FFsB86(False, False, *args)
def FFsB86(addSep=True, isArray=True, *args):
 if VVf3wI:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFMrEe(fnc):
 def VViUlf(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FF8Uxk(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VViUlf
def FF9XzO(*args):
 if VVf3wI:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFsAUL("Added to : %s" % path)
def FFqtyN(txt, isAppend=True, ignoreErr=False):
 if VVf3wI:
  tm = FF7pn9()
  err = ""
  if not ignoreErr:
   err = FFgdro()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF8Uxk(err)
  FF8Uxk("Output Log File : %s" % fileName)
def FFgdro():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF7pn9()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFnvTI():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVTCWW = 0
def FFlCeJ():
 global VVTCWW
 VVTCWW = iTime()
def FFvrv4(txt=""):
 FF8Uxk(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVTCWW)).rstrip("0"), txt))
VVOuIa = []
def FFcTnD(win):
 global VVOuIa
 if not win in VVOuIa:
  VVOuIa.append(win)
def FF90Z9(*args):
 global VVOuIa
 for win in VVOuIa:
  try:
   win.close()
  except:
   pass
 VVOuIa = []
def FFLDb5():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVmpKX = FFLDb5()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFXUDH()    : return PluginDescriptor(fnc=FFxXuq, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFaED4()      : return getDescriptor(FF9JEZ , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFLZoM()     : return getDescriptor(FFspep  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFgm32()  : return getDescriptor(FFSDv7, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF9hpe() : return getDescriptor(FFBGGO , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFQVLp()  : return getDescriptor(FFnMiO , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFekwB()  : return getDescriptor(FFweRD  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFrFcA()      : return getDescriptor(FFhHPq, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFLZoM() , FFaED4() , FFXUDH() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFgm32())
  result.append(FF9hpe())
  result.append(FFQVLp())
  result.append(FFekwB())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFrFcA())
 return result
def FFxXuq(reason, **kwargs):
 if reason == 0:
  CCkk2Z.VVs7p7()
  if "session" in kwargs:
   session = kwargs["session"]
   FFDnQ6(session)
   CC39mE(session)
def FF9JEZ(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFspep, PLUGIN_NAME, 45)]
 else:
  return []
def FFspep(session, **kwargs):
 session.open(Main_Menu)
def FFSDv7(session, **kwargs):
 session.open(CCxFIK)
def FFBGGO(session, **kwargs):
 session.open(CCA7uK)
def FFnMiO(session, **kwargs):
 CCC5bX.VVBgB6(session)
def FFweRD(session, **kwargs):
 FFTXqQ(session, reopen=True)
def FFhHPq(session, **kwargs):
 session.open(CCTzTd, fncMode=CCTzTd.VVfwSM)
def FFnwfK():
 FF7cCM(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFgm32(), FF9hpe(), FFQVLp(), FFekwB() ])
 FF7cCM(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFrFcA() ])
def FF7cCM(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFDnQ6(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FF1JLJ, session, "lok")
 hk.actions["longCancel"]= BF(FF1JLJ, session, "lesc")
 hk.actions["longRed"] = BF(FF1JLJ, session, "lred")
 for k in (CCYT65.VVOYsO, CCYT65.VVPaeb, CCYT65.VV64df):
  hk.actions[k] = BF(CCYT65.VVBn8h, session, k)
def FF1JLJ(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCGivv.VVJIlu:
    CCGivv.VVJIlu.close()
   if not CCC5bX.VVbPxU:
    CCC5bX.VVBgB6(session)
  except:
   pass
def FFH7ga(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFNG7m(SELF, title="", addLabel=False, addScrollLabel=False, VVgsyy=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FF3Vxe()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVk9ff = eTimer()
 try: SELF.VVxxQP = SELF.VVk9ff.timeout.connect(BF(FFbVos, SELF))
 except: SELF.VVk9ff.callback.append(BF(FFbVos, SELF))
 SELF.onClose.append(SELF.VVk9ff.stop)
 FFbVos(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC3EMw(SELF)
 if VVgsyy:
  SELF["myMenu"] = MenuList(VVgsyy)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVMcMd ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFFTn6(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFm7OD, SELF, "0"),
  "1" : BF(FFm7OD, SELF, "1"),
  "2" : BF(FFm7OD, SELF, "2"),
  "3" : BF(FFm7OD, SELF, "3"),
  "4" : BF(FFm7OD, SELF, "4"),
  "5" : BF(FFm7OD, SELF, "5"),
  "6" : BF(FFm7OD, SELF, "6"),
  "7" : BF(FFm7OD, SELF, "7"),
  "8" : BF(FFm7OD, SELF, "8"),
  "9" : BF(FFm7OD, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFV5rH, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFm7OD(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVWK7B:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVWK7B + SELF.keyPressed + VVrVS3)
    txt = VVrVS3 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFRB11(SELF, txt)
def FFV5rH(SELF, tableObj, colNum, isMenu):
 FFRB11(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFkgYM(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVCNsC(i)
     else  : SELF.VVICdA(i)
     break
 except:
  pass
def FF3Vxe():
 return ("  %s" % VV6yYU)
def FFTBJT(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFkgYM(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFy2pz(color):
 return parseColor(color).argb()
def FFtB5m(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFvobF(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFtZ0E(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFmPm4(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVWK7B)
 else:
  return ""
def FFouUN(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVWK7B)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFivHt(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVWK7B
def FFHble(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFmPm4(SEP, VVMdMA))
 else : return "echo -e '%s';" % SEP
def FFExgP(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFivHt(title, color)
def FFyZo3(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFm4TZ(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFnB9O(fncCB):
 tCons = CCu0fe()
 tCons.ePopen(":", BF(FFKEsI, fncCB))
def FFKEsI(fncCB, result, retval):
 fncCB()
def FF3LD6(SELF, fnc, title="Processing ...", clearMsg=True):
 FFRB11(SELF, title)
 tCons = CCu0fe()
 tCons.ePopen(":", BF(FFAVy7, SELF, fnc, clearMsg))
def FFAVy7(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFRB11(SELF)
def FFEEr4(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VV2Pt1
  else       : return ""
def FFIeeK(cmd):
 txt = FFEEr4(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFU8jM(cmd):
 lines = FFIeeK(cmd)
 if lines: return lines[0]
 else : return ""
def FFPOtz(SELF, cmd):
 lines = FFIeeK(cmd)
 VVX2QD = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVX2QD.append((key, val))
  elif line:
   VVX2QD.append((line, ""))
 if VVX2QD:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFyrIU(SELF, None, header=header, VVX3UR=VVX2QD, VVBL0l=widths, VVJA7R=28)
 else:
  FFeWAm(SELF, cmd)
def FFlh8N(cmd):
 return os.system(FFT1jM(cmd)) == 0
def FFdy80(cmd):
 return os.system(FFh3QW(cmd)) == 0
def FFT1jM(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFh3QW(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFeWAm(    SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, VVV183=True, VVFq7T=VVJKXb, **kwargs)
def FF9J6v(  SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, **kwargs)
def FFy48B(   SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, VVj8De=True, VVrY2s=True, VVFq7T=VVJKXb, **kwargs)
def FF0Zhf(  SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, VVj8De=True, VVrY2s=True, VVFq7T=VVVykt, **kwargs)
def FFyAzl(  SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, VVT2So=True , **kwargs)
def FF3Asy(  session, cmd, **kwargs):      session.open(CCeuXy, VVZU3B=cmd, VVT2So=True , **kwargs)
def FFwEM4( SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, VV2SjC=True   , **kwargs)
def FFszeA( SELF, cmd, **kwargs): SELF.session.open(CCeuXy, VVZU3B=cmd, VV5D0x=True  , **kwargs)
def FFwmhG(cmd):
 return FFlh8N("which %s" % cmd)
def FF9djL():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFU8jM(cmd)
def FFcVVX(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VV0BJl     = 0
VVSJRW      = 1
VVC4fX   = 2
VVdCZV   = 3
VVpgtv      = 4
VVRD1w      = 5
VVEPaI     = 6
VVHjiX     = 7
VV58Rq     = 8
VVG7vb = 9
VVexTQ = 10
VVwHSw = 11
VVuIYv  = 12
VV4aqy     = 13
VV50Yb  = 14
VVUGjK  = 15
def FFYO4M(parmNum, grepTxt):
 if   parmNum == VV0BJl  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVSJRW   : param = ["list"   , "apt list"    ]
 elif parmNum == VVC4fX: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVdCZV: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FF9djL()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFcDAv(parmNum, package):
 if   parmNum == VVpgtv      : param = ["info"      , "apt show"         ]
 elif parmNum == VVRD1w      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVEPaI     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVHjiX     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VV58Rq     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVG7vb : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVexTQ : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVwHSw : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVuIYv  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV4aqy     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV50Yb  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVUGjK  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF9djL()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFiCnc():
 result = FFU8jM("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFcDAv(VV58Rq, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFT1jM("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFT1jM("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFmPm4(failed1, VVMdMA))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFmPm4(failed2, VVMdMA))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFmPm4(failed3, VVHEBa))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFWSuq(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFcDAv(VV58Rq , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFT1jM("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFmPm4(failed1, VVMdMA))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFmPm4(failed2, VVHEBa))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFU2DB(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCCXVP.VVlmLu()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFHq6Y(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFU2DB(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFpcNr(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFQfFR(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFU2DB(path, maxSize=maxSize, encLst=encLst)
  if lines: FFucjH(SELF, lines, title=title, VVFq7T=VVJKXb, width=1600, height=1000, titleFontSize=30)
  else : FFKQXu(SELF, path, title=title)
 else:
  FFdxlA(SELF, path, title)
def FF6duf(SELF, fName, title):
 path = VVV9bl + fName
 if fileExists(path):
  txt = FFU2DB(path)
  txt = txt.replace("#W#", VVWK7B)
  txt = txt.replace("#Y#", VVhb13)
  txt = txt.replace("#G#", VVrVS3)
  txt = txt.replace("#C#", VViC5D)
  txt = txt.replace("#P#", VVL6GV)
  FFucjH(SELF, txt, title=title)
 else:
  FFdxlA(SELF, path, title)
def FFRDFw(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFCdvu(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFZsCH(parent)
 else    : return FFjJ1n(parent)
def FFSHhe(path):
 return os.path.basename(os.path.normpath(path))
def FF4Zzy(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFQfFR(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFWV37(path):
 path = FFjJ1n(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFngsO(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFXtMv(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFAFdq(path):
 try: os.remove(path)
 except: pass
def FFZs4V(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFVlAt(path):
 return FFlh8N("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FF5lNb(path):
 return FFlh8N("cp -f '%s' '%s.bak'" % (path, path))
def FFZsCH(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFjJ1n(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF0Qwi():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VV3ket)
 paths.append(VV3ket.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFRDFw(ba)
 for p in list:
  p = ba + p + VV3ket
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVpToT, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VV3ket, VVpToT , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV0oWI, VVV9bl = FF0Qwi()
def FFlWSy():
 def VVe8bb(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVyLis   = VVe8bb(CFG.backupPath, CCYiJJ.VVeX0r())
 VVMbLL   = VVe8bb(CFG.downloadedPackagesPath, t)
 VVoi2x  = VVe8bb(CFG.exportedTablesPath, t)
 VVoqh3  = VVe8bb(CFG.exportedPIconsPath, t)
 VVBo6B   = VVe8bb(CFG.packageOutputPath, t)
 global VVn5zG
 VVn5zG = FFZsCH(CFG.backupPath.getValue())
 if VVyLis or VVBo6B or VVMbLL or VVoi2x or VVoqh3 or oldMovieDownloadPath:
  configfile.save()
 return VVyLis, VVBo6B, VVMbLL, VVoi2x, VVoqh3, oldMovieDownloadPath
def FF0Ck9(path):
 path = FFjJ1n(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFwmPJ(SELF, pathList, tarFileName, addTimeStamp=True):
 VVX3UR = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVX3UR.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVX3UR.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVX3UR.append(path)
 if not VVX3UR:
  FF2zEl(SELF, "Files not found!")
 elif not pathExists(VVn5zG):
  FF2zEl(SELF, "Path not found!\n\n%s" % VVn5zG)
 else:
  VVwmxb = FFZsCH(VVn5zG)
  tarFileName = "%s%s" % (VVwmxb, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFvXEJ())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVX3UR:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFmPm4(tarFileName, VVd7n9))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFmPm4(failed, VVd7n9))
  cmd += "fi;"
  cmd +=  sep
  FF9J6v(SELF, cmd)
def FFfavv(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFo9Jy(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFo9Jy(SELF["keyInfo"], "info")
def FFo9Jy(barObj, fName):
 path = "%s%s%s" % (VVV9bl, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFrc8H(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFDMS5(satNum)
  return satName
def FFDMS5(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FF5v7R(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFrc8H(val)
  else  : sat = FFDMS5(val)
 return sat
def FFyyjf(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFrc8H(num)
 except:
  pass
 return sat
def FFuXdz(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFiRis(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFR7wS(info, iServiceInformation.sServiceref)
   prov = FFR7wS(info, iServiceInformation.sProvider)
   state = str(FFR7wS(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFH7Or(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFzxaC(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFR7wS(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF49Rh(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFz86a(refCode):
 info = FF7Y14(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFvqGJ(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFzBf3(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF7Y14(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVTjE0 = eServiceCenter.getInstance()
  if VVTjE0:
   info = VVTjE0.info(service)
 return info
def FFQhSW(SELF, refCode, VVehU2=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFzxaC(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCW2rl()
  if pr.VVJjy0(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVckUe(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFlfXr(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVehU2:
   FFl32o(SELF, isFromSession)
 try:
  VV15Ea = InfoBar.instance
  if VV15Ea:
   VVziWT = VV15Ea.servicelist
   if VVziWT:
    servRef = eServiceReference(refCode)
    VVziWT.saveChannel(servRef)
 except:
  pass
def FFlfXr(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCW2rl()
    if pr.VVJjy0(refCode, chName, decodedUrl, iptvRef):
     pr.VVckUe(SELF, isFromSession)
def FFH7Or(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFTEln(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FF8SD1(url): return FFGkXb(url) or FF6H6X(url)
def FFGkXb(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FF6H6X(url): return any(x in url for x in ("/series/", "mode=series"))
def FFzxaC(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFBuNh(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFBuNh(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FF4f8i(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFqA3T(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFElMG(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFN7zT(txt):
 try:
  return FFqA3T(FFElMG(txt)) == txt
 except:
  return False
def FFPCH3(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFZsCH(newPath), patt))
def FFl32o(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCC5bX.VVBgB6(session)
 else      : FFTXqQ(session, reopen=True)
def FFTXqQ(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFTXqQ, session), CCGivv)
  except:
   try:
    FFMstn(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFdpOF(refCode):
 tp = CCgl59()
 if tp.VV8AtE(refCode) : return True
 else        : return False
def FFMjJK(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFjhC8(True)
     return True
 return False
def FFjhC8(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FF2O6N()
def FF2O6N():
 VV15Ea = InfoBar.instance
 if VV15Ea:
  VVziWT = VV15Ea.servicelist
  if VVziWT:
   VVziWT.setMode()
def FFlVIk(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVTjE0 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVTjE0.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFcYq0():
 VVu9HV = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVdPgX = list(VVu9HV)
 return VVdPgX, VVu9HV
def FFSoy0():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFPlYZ(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFwVZA(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFUEda():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFvXEJ():
 return FFUEda().replace(" ", "_").replace("-", "").replace(":", "")
def FFz41A(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF7pn9():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFZXhR(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCA7uK.VVhDYU(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCA7uK.VV84lT(fName)
     phpFile = tmpDir + fName + ext
     FFlh8N("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFAETn(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFZevi(num):
 return "s" if num > 1 else ""
def FFVUcd(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFGgcy(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFYrpL(a, b):
 return (a > b) - (a < b)
def FFDjgW(a, b):
 def VVT0wt(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVT0wt(a)
 b = VVT0wt(b)
 return (a > b) - (a < b)
def FFbRsK(mycmp):
 class CCn6cB(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCn6cB
def FF5kkM(SELF, message, title="", VVRlGe=None):
 SELF.session.openWithCallback(VVRlGe, CC0B12, title=title, message=message, VVMeLm=True)
def FFucjH(SELF, message, title="", VVFq7T=VVJKXb, VVRlGe=None, **kwargs):
 SELF.session.openWithCallback(VVRlGe, CC0B12, title=title, message=message, VVFq7T=VVFq7T, **kwargs)
def FF2zEl(SELF, message, title="")  : FFMstn(SELF.session, message, title)
def FFdxlA(SELF, path, title="") : FFMstn(SELF.session, "File not found !\n\n%s" % path, title)
def FFKQXu(SELF, path, title="") : FFMstn(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFjIcG(SELF, title="")  : FFMstn(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFMstn(session, message, title="") : session.open(BF(CCUVEU, title=title, message=message))
def FF7lc9(SELF, VVRlGe, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVRlGe, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVRlGe, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF2zEl(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFZnVu(SELF, callBack_Yes, VVWZXE, callBack_No=None, title="", VVOuLx=False, VVCEKd=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFX3sM, callBack_Yes, callBack_No)
         , BF(CCR2bg, title=title, VVWZXE=VVWZXE, VVCEKd=VVCEKd, VVOuLx=VVOuLx))
def FFX3sM(callBack_Yes, callBack_No, FFZnVued):
 if FFZnVued : callBack_Yes()
 elif callBack_No: callBack_No()
def FFRB11(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFvobF(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVk9ff.start(timeout, True)
  except: pass
 else: FFbVos(SELF)
def FFKCVv(*kargs, **kwargs):
 FFnB9O(BF(FFRB11, *kargs, **kwargs))
def FFbVos(SELF):
 try:
  SELF.VVk9ff.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFsY7N(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFyrIU(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCFKe9, **kwargs))
  else   : win = SELF.session.open(BF(CCFKe9, **kwargs))
  FFcTnD(win)
  return win
 except:
  return None
def FFCO3u(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCJFTB, **kwargs))
 FFcTnD(win)
 return win
def FFJi5u(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFDNao(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFBxYU(SELF, **kwargs):
 SELF.session.open(CCTzTd, **kwargs)
def FFzs4L(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FF6C1b(SELF[name], "#000000", 3)
  except:
   pass
def FF6C1b(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFYdpp(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVoHbv, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFhtaK(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFYdpp(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFsH5e(SELF, winSize.width(), winSize.height())
def FFsH5e(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFTuEm():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFpjhu(VVJA7R):
 screenSize  = FFTuEm()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVJA7R)
 return bodyFontSize
def FFGBnA(VVJA7R, extraSpace):
 font = gFont(VVoHbv, VVJA7R)
 VV4xuv = fontRenderClass.getInstance().getLineHeight(font) or (VVJA7R * 1.25)
 return int(VV4xuv + VV4xuv * extraSpace)
def FFAm4L(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFTuEm()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVoHbv, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFGBnA(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVoHbv, titleFontSize, alignLeftCenter)
 if winType in (VVAfZq, VVvBiK):
  if winType == VVvBiK : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVWpcL:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVfxqt:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVoHbv, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVmKq8:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF5kkML = b2Left2 + timeW + marginLeft
  FF5kkMW = b2Left3 - marginLeft - FF5kkML
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF5kkML , b2Top, FF5kkMW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVlSRC:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVLyZo:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV7DNj:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVDOlP:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVoHbv, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVoHbv, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVnYzd:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVoHbv, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVkwlJ:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVoHbv, fontH, alignCenter)
 elif winType in (VVOOPZ, VVw4no, VVlPyO, VVVBB0, VV122f):
  if   winType == VVOOPZ  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVw4no : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVlPyO : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVVBB0 : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVOOPZ:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVoHbv, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVoHbv, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVoHbv, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVoHbv, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVoHbv, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVoHbv, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVoHbv, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVWDEH:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVBqoq:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVmJx6 : align = alignLeftCenter
  elif winType == VVCmnq : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVvs8q:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVoHbv
  if usefixedFont and winType == VVCmnq:
   fLst = FFQN3h()
   if   VVoFWh in fLst and CFG.fontPathTerm.getValue(): fontName = VVoFWh
   elif VVGmMn in fLst         : fontName = VVGmMn
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVJA7R = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVoHbv, VVJA7R, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVoHbv, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVZ4OB[i], VVoHbv, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVCmnq:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVZ4OB[i], VVoHbv, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVOnHU = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVkRol)
  VVgsyy = []
  if VVjnfj:
   VVgsyy.append(("-- MY TEST --", "myTest" ))
  VVgsyy.append(("File Manager"  , "fMan" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("IPTV"    , "iptv" ))
  VVgsyy.append(("Movies Browser" , "movie" ))
  VVgsyy.append(("Services/Channels", "chan" ))
  VVgsyy.append(("PIcons"   , "picon" ))
  VVgsyy.append(("EPG"    , "epg"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Terminal"   , "term" ))
  VVgsyy.append(("SoftCam"   , "soft" ))
  VVgsyy.append(("Plugins"   , "plug" ))
  VVgsyy.append(("Backup & Restore" , "bakup" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Date/Time"  , "date" ))
  VVgsyy.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVgsyy):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVgsyy[ndx] = tuple(item)
  FFNG7m(self, title=self.Title, VVgsyy=VVgsyy)
  FFTBJT(self["keyRed"] , "Exit")
  FFTBJT(self["keyGreen"] , "Settings")
  FFTBJT(self["keyYellow"], "Dev. Info.")
  FFTBJT(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVyBpu      ,
   "yellow": self.VVOT7B      ,
   "blue" : self.VV9L8O     ,
   "info" : BF(FF3LD6, self, self.VVfKK1) ,
   "text" : self.VV8jhX      ,
   "menu" : self.VVIR6a    ,
   "0"  : BF(self.VV0xQS, 0)   ,
   "1"  : BF(self.VVTAf8, "fMan")   ,
   "2"  : BF(self.VVTAf8, "iptv")   ,
   "3"  : BF(self.VVTAf8, "movie")   ,
   "4"  : BF(self.VVTAf8, "chan")   ,
   "5"  : BF(self.VVTAf8, "picon")   ,
   "6"  : BF(self.VVTAf8, "epg")   ,
   "7"  : BF(self.VVTAf8, "term")   ,
   "8"  : BF(self.VVTAf8, "soft")   ,
   "9"  : BF(self.VVTAf8, "plug")   ,
   "last" : BF(self.VVTAf8, "bakup")   ,
   "next" : BF(self.VVTAf8, "date")
  })
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
  global VVQrwB, VVmTYx, VVRBe7
  VVQrwB = VVmTYx = False
  VVRBe7 = True
 def VVMcMd(self):
  self.VVTAf8(self["myMenu"].l.getCurrentSelection()[1])
 def VVTAf8(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VV6yYU
   VV6yYU = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVefxe()
   elif item == "fMan"  : self.session.open(CCxFIK)
   elif item == "iptv"  : self.session.open(CCA7uK)
   elif item == "movie" : FF3LD6(self, BF(CC0Ist.VVvMMZ, self))
   elif item == "chan"  : self.session.open(CCuZg4)
   elif item == "picon" : self.VVWxXm()
   elif item == "epg"  : self.session.open(CCje5B)
   elif item == "term"  : self.session.open(CCID7J)
   elif item == "soft"  : self.session.open(CC5i9A)
   elif item == "plug"  : self.session.open(CC3nMC)
   elif item == "bakup" : self.session.open(CCBdOt)
   elif item == "date"  : self.session.open(CCPhYN)
   elif item == "net"  : self.session.open(CCNlgS)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
  FFzs4L(self)
  FFfavv(self)
  VVyLis, VVBo6B, VVMbLL, VVoi2x, VVoqh3, oldMovieDownloadPath = FFlWSy()
  if VVyLis or VVBo6B or VVMbLL or VVoi2x or VVoqh3 or oldMovieDownloadPath:
   VVBMvF = lambda path, subj: "%s:\n%s\n\n" % (subj, FFivHt(path, VVgmAg)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVBMvF(VVyLis   , "Backup/Restore Path"    )
   txt += VVBMvF(VVBo6B  , "Created Package Files (IPK/DEB)" )
   txt += VVBMvF(VVMbLL  , "Download Packages (from feeds)" )
   txt += VVBMvF(VVoi2x , "Exported Tables"     )
   txt += VVBMvF(VVoqh3 , "Exported PIcons"     )
   txt += VVBMvF(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFucjH(self, txt, title="Settings Paths")
  self.VVW2rn()
  if (EASY_MODE or VVf3wI or VVjnfj):
   FFvobF(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFRB11(self, "Welcome", 300)
  FFnB9O(self.VVstFS)
 def VVstFS(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCYiJJ.VV83tv()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFlh8N("rm -f /tmp/ajp_*")
  global VVQrwB, VVmTYx, VVRBe7
  VVQrwB = VVmTYx = False
  del VVRBe7
 def VV0xQS(self, digit):
  self.VVOnHU += str(digit)
  ln = len(self.VVOnHU)
  global VVQrwB
  if ln == 4:
   if self.VVOnHU == "0" * ln:
    VVQrwB = True
    FFvobF(self["myTitle"], "#11805040")
   else:
    self.VVOnHU = "x"
 def VV8jhX(self):
  self.VVOnHU += "t"
  if self.VVOnHU == "0" * 4 + "t" * 2:
   global VVmTYx
   VVmTYx = True
   FFvobF(self["myTitle"], "#dd5588")
 def VVWxXm(self):
  found = False
  pPath = CC0NDf.VVqbLc()
  if pathExists(pPath):
   for fName, fType in CC0NDf.VVOwGR(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC0NDf)
  else:
   VVgsyy = []
   VVgsyy.append(("PIcons Tools" , "CC0NDf" ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(CC0NDf.VVTrBv())
   VVgsyy.append(VVzHzv)
   VVgsyy += CC0NDf.VVcjzm()
   FFCO3u(self, self.VV7YH9, VVgsyy=VVgsyy)
 def VV7YH9(self, item=None):
  if item:
   if   item == "CC0NDf"   : self.session.open(CC0NDf)
   elif item == "VVzkki"  : CC0NDf.VVzkki(self)
   elif item == "VVFNew"  : CC0NDf.VVFNew(self)
   elif item == "findPiconBrokenSymLinks" : CC0NDf.VVFU7A(self, True)
   elif item == "FindAllBrokenSymLinks" : CC0NDf.VVFU7A(self, False)
 def VVfKK1(self):
  changeLogFile = VVV9bl + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFHq6Y(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFivHt("\n%s\n%s\n%s" % (SEP, line, SEP), VVMdMA, VVWK7B)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFivHt(line, VVrVS3, VVWK7B)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFucjH(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVkRol, PLUGIN_DESCRIPTION), VVJA7R=28, width=1600, height=1000, VVaOdk="#11000011")
 def VVIR6a(self):
  VVgsyy = []
  VVgsyy.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Keys Help"     , "hlp" ))
  FFCO3u(self, self.VVVsB3, VVgsyy=VVgsyy, width=650, title="Options")
 def VVVsB3(self, item=None):
  if item:
   if   item == "libr" : FF3LD6(self, BF(self.VVn6cZ))
   elif item == "hlp" : FF6duf(self, "_help_main", "Main Page (Keys Help)")
 def VVyBpu(self) : self.session.open(CCYiJJ)
 def VVOT7B(self) : self.session.open(CCXeIv)
 def VV9L8O(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVL7a3, VVgmAg, VVhb13, VVAQIK
  VVgsyy = []
  VVgsyy.append((c1 + "Change Title Colors"   , "title"  ))
  VVgsyy.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVgsyy.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVgsyy.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVgsyy.append((c2 + "Reset Colors"    , "resetColor" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVgsyy.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c4 + "Change System Font"    , "sysFont"  ))
  FFCO3u(self, BF(self.VVjh4c, title), VVgsyy=VVgsyy, width=600, title=title)
 def VVjh4c(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVLdBk()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVTLFu, tDict, item), CCNJZ7, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFZnVu(self, self.VVx1Ka, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVgQSO(VV641B  )
   elif item == "termFont"  : self.VVgQSO(VVoFWh)
   elif item == "sysFont"  : self.VVgQSO(VV66Jh  )
 def VVn6cZ(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVX2QD, pkgs = self.VVuFOA()
  VV6LI6 = ("Install", BF(self.VVgFXU, title, pkgs)  , [])
  VVmhJa  = ("Update Sys. Packages", self.VVLSum , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VV8zKo = (LEFT  , CENTER , LEFT  )
  VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, width=1350, VV6LI6=VV6LI6, VVmhJa=VVmhJa, VVXZ9d="#00ffffaa", VVREBJ=1)
 def VVgFXU(self, Title, pkgs, VVgl66, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVc6gH, VVgl66)
   item = colList[0]
   if   item == "requests" : CCD0Wo.VVzlRk(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCYT65.VVvGIJ(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFyAzl(self, FFiCnc(), VV5SfP=cbFnc)
   elif item in pkgs  : FFyAzl(self, FFWSuq(item, item, item.capitalize()), VV5SfP=cbFnc)
  else:
   FFRB11(VVgl66, "Already installed.", 700, isGrn=True)
 def VVLSum(self, VVgl66, title, txt, colList):
  CC3nMC.VV2d5a(self)
 def VVc6gH(self, VVgl66):
  VVX2QD, pkgs = self.VVuFOA()
  VVgl66.VVhT9b(VVX2QD[VVgl66.VVKltF()])
 def VVuFOA(self):
  tDict = {}
  path = VVV9bl + "_sup_lib"
  if fileExists(path):
   for line in FFHq6Y(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVBMvF(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFivHt("Installed", VVd7n9), txt)
   else : return (lib, FFivHt("Not installed", VVHEBa), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVX2QD = []
  VVX2QD.append(VVBMvF("requests", CCD0Wo.VVzlRk(self, install=False)))
  VVX2QD.append(VVBMvF("Imaging" , CCYT65.VVvGIJ(self, "", False, install=False)))
  VVX2QD.append(VVBMvF("ar"   , FFlh8N("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVX2QD.append(VVBMvF(item, FFwmhG(item)))
  VVX2QD.sort(key=lambda x: x[0].lower())
  return VVX2QD, pkgs
 def VVmDk8(self):
  return VVn5zG + "ajpanel_colors"
 def VVLdBk(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVmDk8()
  if fileExists(p):
   txt = FFU2DB(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVTLFu(self, tDict, item, fg, bg):
  if fg:
   self.VVTewk(item, fg)
   self.VVdFz9(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVBtT9(tDict)
 def VVBtT9(self, tDict):
   p = self.VVmDk8()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVTewk(self, item, fg):
  if   item == "title" : FFtB5m(self["myTitle"], fg)
  elif item == "body"  :
   FFtB5m(self["myMenu"], fg)
   FFtB5m(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFtB5m(self[item], fg)
 def VVdFz9(self, item, bg):
  if   item == "title" : FFvobF(self["myTitle"], bg)
  elif item == "body"  :
   FFvobF(self["myMenu"], bg)
   FFvobF(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFvobF(self["myBar"], bg)
 def VVx1Ka(self):
  FFlh8N("rm '%s'" % self.VVmDk8())
  self.close()
 def VVW2rn(self):
  tDict = self.VVLdBk()
  for item in ("title", "body", "cursor", "bar"):
   self.VVClV7(tDict, item)
 def VVClV7(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVTewk(name, fg)
  if bg: self.VVdFz9(name, bg)
 def VVgQSO(self, which):
  if   which == VV641B  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVoFWh : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VV66Jh  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCeJZk.VV84Ib(self, "Change %s Font" % title, defFnt, rest, BF(self.VVDyVL, which))
 def VVDyVL(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VV641B  : FFH7ga(CFG.fontPathMain, path)
   elif which == VVoFWh: FFH7ga(CFG.fontPathTerm, path)
   elif which == VV66Jh  : FFH7ga(CFG.fontPathSys , path)
   err = Main_Menu.VV8Bbd(which)
   if err          : FF2zEl(self, err, title=title)
   elif which == VV641B   : self.close()
   elif which == VVoFWh  : FFRB11(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VV66Jh and path: FFRB11(self, "System font applied", 1500, isGrn=True)
   elif which == VV66Jh   : FFZnVu(self, BF(Main_Menu.VV2SjC, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VV2SjC(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VV8Bbd(name):
  if   name == VV641B : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVoFWh: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VV66Jh : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFQN3h()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VV66Jh:
   nameLst = []
   for nm in FFQN3h():
    if not nm in (VV641B, VVoFWh):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFy505(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFQN3h()
  else    : return "Could not add font"
 def VVefxe(self):
  CCC5bX.VVBgB6(self.session)
class CCNlgS(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVn5zG, "ajpanel_network")
  c1, c2 = VVhb13, VVL7a3
  VVgsyy = []
  VVgsyy.append((c1 + "Network Devices"     , "dev" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Network Scanner (ping)"    , "ping"))
  VVgsyy.append(("Port Scanner (scan for famous ports)" , "port"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Check Internet Connection"  , "intr"))
  FFNG7m(self, title="Network Tools", VVgsyy=VVgsyy)
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FF3LD6(self, self.VVl9uB, title="REading Devices ...")
  elif item == "ping" : FF3LD6(self, self.VV7B3c, title="Scanning ...")
  elif item == "port" : CCQZYn.VV0x0x(self, self.VV4dqd, title="Select host to scan")
  elif item == "intr" : self.session.open(CCo5Xr)
 def VVl9uB(self, canCencel=False):
  title = "Network Devices"
  VVX2QD = self.VV7sIu()
  if VVX2QD:
   bg = "#0a223333"
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVZAcA = BF(self.VV3Zzl, canCencel)
   VVkkpG  = ("Start FTP"   , self.VVvs5k    , [])
   VVH4Z8 = ("Entry Options"  , self.VVZwko  , [])
   VVmhJa = ("Scan for Devices" , self.VV1KQW , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VV8zKo = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, width=1500, height=900, VVBL0l=widths, VVJA7R=28, VVkkpG=VVkkpG, VVZAcA=VVZAcA, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa
       , VVBBM8=bg, VVa80e=bg, VVaOdk=bg, VVXZ9d="#11ffff00", VVlVSy="#11220000", VV3FyM="#00333333", VVf4Ym="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVgl66.VVICdA(ndx)
  else:
   FFZnVu(self, BF(FF3LD6, self, BF(self.VVc3vo, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VV3Zzl, canCencel), title=title)
 def VVZwko(self, VVgl66, title, txt, colList):
  VVgsyy = []
  VVgsyy.append(("Change Username"   , "user"))
  VVgsyy.append(("Change Password"   , "pass"))
  VVgsyy.append(("Change Remarks"   , "rem"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Remove Selected Server" , "del"))
  FFCO3u(self, BF(self.VVmjFy, VVgl66), VVgsyy=VVgsyy, title="Entry Options")
 def VVmjFy(self, VVgl66, item=None):
  if item:
   if   item == "user" : self.VVzbEo("u", VVgl66)
   elif item == "pass" : self.VVzbEo("p", VVgl66)
   elif item == "rem" : self.VVzbEo("r", VVgl66)
   elif item == "del" : FFZnVu(self, BF(FF3LD6, self, BF(self.VVUXqs, VVgl66), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VV3Zzl(self, canCencel, VVgl66=None):
  if VVgl66: VVgl66.cancel()
  if canCencel : self.close()
 def VVvs5k(self, VVgl66, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFH7ga(CFG.lastNetworkDevice, VVgl66.VVKltF())
  self.session.openWithCallback(BF(self.VVHmnL, entry, VVgl66), CCZLAE, entry)
 def VVHmnL(self, entry, VVgl66, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVaXrN("d", newPath, ip, u, p, path, rem)
    self.VVaggO(VVgl66)
 def VV1KQW(self, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVc3vo, mainTableInst=VVgl66), title="Scanning Network ...")
 def VVc3vo(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCQZYn.VVmp6O(CCQZYn.VVxOfd)
  if err:
   FF2zEl(self, err, title=title)
   return
  telLst, err = CCQZYn.VVmp6O(CCQZYn.VVN2DS)
  if err:
   FF2zEl(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVlYog(p1, p2): return FFDjgW(p1[0], p2[0])
   lst.sort(key=FFbRsK(VVlYog))
   bg = "#0a202020"
   VVZAcA = BF(self.VV3Zzl, canCencel)
   VVkkpG  = ("Add to Devices" , BF(self.VVrDMU, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VV8zKo = (LEFT   , CENTER   , CENTER  )
   FFyrIU(self, None, title=title, header=header, VVX3UR=lst, VV8zKo=VV8zKo, VVBL0l=widths, width=1200, VVJA7R=30, VVkkpG=VVkkpG, VVZAcA=VVZAcA, VVREBJ=2
     , VVBBM8=bg, VVa80e=bg, VVaOdk=bg, VVlVSy="#0a225555", VVf4Ym="#11403040")
  else:
   FF2zEl(self, "No devices found !", title=title)
 def VV7B3c(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCQZYn.VVmp6O(-1)
  if err:
   FF2zEl(self, err, title=title)
  elif lst:
   def VVlYog(p1, p2): return FFDjgW(p1[0], p2[0])
   lst.sort(key=FFbRsK(VVlYog))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VV8zKo = (LEFT   , LEFT   )
   FFyrIU(self, None, title=title, header=header, VVX3UR=lst, VV8zKo=VV8zKo, VVBL0l=widths, width=1000, height=700, VVJA7R=30
     , VVBBM8=bg, VVa80e=bg, VVaOdk=bg, VVlVSy="#0a225555", VVf4Ym="#11403040")
  else:
   FF2zEl(self, "Network scanning failed !", title=title)
 def VV4dqd(self, ip=None):
  if ip:
   FF3LD6(self, BF(self.VV2lls, ip), title="Scanning %s" % ip)
 def VV2lls(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCQZYn.VVWm0n(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCQZYn.VVAIfL(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFucjH(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VV7sIu(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFU2DB(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVlYog(p1, p2): return FFDjgW(p1[0], p2[0])
  tLst.sort(key=FFbRsK(VVlYog))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VV7sIu(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFU2DB(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVlYog(p1, p2): return FFDjgW(p1[0], p2[0])
  tLst.sort(key=FFbRsK(VVlYog))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVrDMU(self, mainTableInst, canCencel, VVgl66, title, txt, colList):
  ip, mac, typ = VVgl66.VVdCEN(VVgl66.VVKltF())
  if "Own" in ip:
   FFRB11(VVgl66, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VV7sIu():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFZs4V(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VViGK0(ip, u, p, path, rem))
   if mainTableInst: self.VVaggO(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVl9uB(canCencel)
   VVgl66.cancel()
 def VViGK0(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVUXqs(self, VVgl66):
  num, ip, u, p, path, rem = VVgl66.VVdCEN(VVgl66.VVKltF())
  lst = self.VV7sIu()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VViGK0(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVaggO(VVgl66)
  else:
   VVgl66.cancel()
 def VVzbEo(self, col, VVgl66):
  num, ip, u, p, path, rem = VVgl66.VVdCEN(VVgl66.VVKltF())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FF7lc9(self, BF(self.VVM3S5, col, orig, VVgl66, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVM3S5(self, col, orig, VVgl66, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFRB11(VVgl66, "No change", 1500)
   elif not newTxt and col == "u":
    FFRB11(VVgl66, "No user !", 2000)
   else:
    self.VVaXrN(col, newTxt, ip, u, p, path, rem)
    self.VVaggO(VVgl66)
 def VVaXrN(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VV7sIu()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VViGK0(ip1, u1, p1, path1, rem1))
 def VVaggO(self, VVgl66, newEntry=None):
  VVX2QD = self.VV7sIu()
  if VVX2QD : VVgl66.VVrEsw(VVX2QD, tableRefreshCB=BF(self.VVQbru, newEntry))
  else  : VVgl66.cancel()
 def VVQbru(self, newEntry, VVgl66, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVgl66.VV3eCu()):
    if row[1:] == newEntry:
     VVgl66.VVICdA(ndx)
 def VV3Zzl(self, canCencel, VVgl66=None):
  if VVgl66: VVgl66.cancel()
  if canCencel : self.close()
class CCQZYn():
 VVxOfd = 21
 VVN2DS = 23
 def __init__(self):
  self.VVRYB2()
 def VVRYB2(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVmMYM(self, ip, User, Pass, timeout=5):
  myIp = CCQZYn.VVymuA()
  if ip != myIp:
   if CCQZYn.VVAIfL(ip, CCQZYn.VVxOfd):
    self.VVRYB2()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVUigU(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVTkJ3(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVQHPU(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVTkJ3()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVZjJP(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVNv3R(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVv45K(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVvy7b(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVYNHf(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVvy7b()
   if self.VVv45K(path) : typ = "d"
   else      : typ = "b"
   self.VVv45K(curDir)
   return typ
 def VVlByc(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVv45K(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VV950z(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVqIyF(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVZulD(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVYoVn(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVlByc(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFAFdq(locFile)
   return "", sz, str(e)
 def VVJ51a(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVRYB2()
 @staticmethod
 def VVC9tq():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVymuA():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VV0KGR():
  myIp = CCQZYn.VVymuA()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVJKyH():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFU8jM("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVwX6k(port=-1):
  lst = []
  def VVaiQL(ip):
   if port > -1: ok = CCQZYn.VVAIfL(ip, port)
   else  : ok = CCQZYn.VVWm0n(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCQZYn.VV0KGR()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVaiQL, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVmp6O(port):
  myIp = CCQZYn.VVymuA()
  myGw = CCQZYn.VVJKyH()
  tDict = { myIp: CCQZYn.VVC9tq() }
  devLst, err = CCQZYn.VVwX6k(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFEEr4("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVhb13
    elif key == myGw: txt = " %s Gateway" % VVhb13
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVWm0n(ip):
  return FFlh8N("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVAIfL(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVY3BC(ip="1.1.1.1", timeout=1):
  if CCQZYn.VVAIfL(ip, 53, timeout):
   return True
  if CCQZYn.VVWm0n(ip):
   return True
  return FFlh8N("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VV0x0x(SELF, okFnc, title):
  baseIp = CCQZYn.VV0KGR()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFCO3u(SELF, okFnc, VVgsyy=lst, width=600, title=title, VVBBM8="#222222", VVa80e="#222222")
class CCZLAE(Screen, CCQZYn):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVJA7R  = self.skinParam["bodyFontSize"]
  self.VV4xuv  = self.skinParam["bodyLineH"]
  self.VVY0fV  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCuwo1.VVr2ko("fil")
  self.png_dir  = CCuwo1.VVr2ko("dir")
  self.png_dirup  = CCuwo1.VVr2ko("dirup")
  self.png_slwfil  = CCuwo1.VVr2ko("slwfil")
  self.png_slbfil  = CCuwo1.VVr2ko("slbfil")
  self.png_slwdir  = CCuwo1.VVr2ko("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCQZYn.__init__(self)
  VVgsyy = [("Item-%d" % x,) for x in range(50)]
  FFNG7m(self, title=self.Title, VVgsyy=VVgsyy)
  FFTBJT(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVgsyy, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVoHbv, self.VVJA7R))
  self["myMenu"].l.setItemHeight(self.VV4xuv)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : BF(self.VVIvk9, True) ,
   "ok" : self.VVMcMd    ,
   "cancel": self.VVIvk9    ,
   "menu" : self.VVOoT2   ,
   "info" : self.VVz42H  ,
   "pageUp": self.VVTaFO    ,
   "chanUp": self.VVTaFO
  })
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVGNX6)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
  FFzs4L(self)
  FFfavv(self)
  FFvobF(self["keyBlue"], "#11333333")
  FF3LD6(self, self.VVDzHh, title="Connecting ...")
 def VVDzHh(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVmMYM(ip, u, p)
  if err:
   FF2zEl(self, err, title=self.Title)
   FFTBJT(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFTBJT(self["keyBlue"], self.ftpIp)
   if not self.VVv45K(path):
    path = "/"
   self.VVezG2(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVTkJ3():
   self.VVJ51a()
 def VVMcMd(self):
  if self.VVO6FK():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVezG2(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVTaFO()
    else         : self.VVEmuS(os.path.join(self.curDir, name))
 def VVIvk9(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVTaFO()
 def VVO6FK(self):
  if self.VVTkJ3():
   return True
  else:
   FF2zEl(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVEmuS(self, path):
  cat = self.VVG9jt(path)
  if cat in ("pic"):
   FF3LD6(self, BF(self.VV5JnQ, path))
  elif cat in ("mov", "mus"):
   if CCA7uK.VVHyGP("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FF3LD6(self, BF(CCxFIK.VVB4hc, self, url, rType=rType), title="Playing Media ...")
 def VV5JnQ(self, path):
  locFile, size, err = self.VVYoVn(path)
  if err: FF2zEl(self, err, title="View Picture File")
  else  : CCslfl.VVIg0A(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFAFdq))
 def VVGNX6(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCuwo1.VVYIiH else sel[0][0])
  else  : title=  VVHEBa + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVTaFO(self):
  if self.VVO6FK():
   lastPart = FFSHhe(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVezG2(parentDir, lastPart, "d")
 def VVezG2(self, Dir, moveTo="", moveToType=""):
  FF3LD6(self, BF(self.VV0k4f, Dir, moveTo, moveToType))
 def VV0k4f(self, Dir, moveTo, moveToType):
  files, err = self.VVNv3R(Dir, isLong=True)
  self.curDir = self.VVvy7b() or "/"
  self.VVLWWD(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVLWWD(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VV3nup(CCuwo1.VVYIiH, CCuwo1.VVYIiH, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVYNHf(target)
    color = VVHEBa if targetState == "b" else VVd7n9
    origName = name + VVMdMA + linkSep + color + " "+ target
   self.list.append(self.VV3nup(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VV3nup(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVG9jt(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVV9bl, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCuwo1.VVYIiH: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV4xuv + 10, 0, self.VVY0fV, self.VV4xuv, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VVmpKX: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV4xuv-4, self.VV4xuv-4, png, None, None, VVmpKX))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV4xuv-4, self.VV4xuv-4, png, None, None))
  return tableRow
 def VVG9jt(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCuwo1.VVTrvd().items():
    if ext in lst:
     return cat
  return ""
 def VVOoT2(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCuwo1.VVYIiH
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVhRJs(titl, ref, chk, color=""):
   if chk: return VVgsyy.append((color + titl, ref))
   else  : return VVgsyy.append((titl, ))
  VVgsyy = []
  VVhRJs("Properties", "VVz42H", not isTop)
  c = VVhb13
  VVgsyy.append(VVzHzv)
  VVhRJs("Download Selected File ..."    , "FFZXhRFromServer", isFile, c)
  VVhRJs("Upload a Local File to Remote Server ...", "VVflID" , True  , c)
  VVgsyy.append(VVzHzv)
  VVhRJs("Create new directory", "VVlxYF", True)
  VVhRJs("Rename", "VVTMd8", not isTop)
  VVhRJs("DELETE", "VVCxgz", not isTop, VVL6GV)
  VVgsyy.append(VVzHzv)
  VVhRJs("FTP Server Information", "VVpfh3", True)
  VVgsyy.append(VVzHzv)
  VVhRJs("Refresh File List", "refresh", True)
  FFCO3u(self, self.VVlkcy, VVgsyy=VVgsyy, title="Options")
 def VVlkcy(self, item=None):
  if item:
   if   item == "VVz42H"     : self.VVz42H()
   elif item == "FFZXhRFromServer"   : self.FFZXhRFromServer()
   elif item == "VVflID"   : self.VVflID()
   elif item == "VVlxYF"   : self.VVlxYF()
   elif item == "VVTMd8"   : self.VVTMd8()
   elif item == "VVCxgz"   : self.VVCxgz()
   elif item == "VVpfh3"    : self.VVpfh3()
   elif item == "refresh"and self.VVO6FK() : self.VVezG2(self.curDir)
 def VVz42H(self):
  if self.VVO6FK():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFivHt("Path", VVhb13), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVlByc(path)
    if sz > -1: txt += "Size\t: %s" % CCxFIK.VVe4Bo(sz)
   else:
    txt = "Nothing selected"
   FFucjH(self, txt, title="Properties")
 def VVpfh3(self):
  if self.VVO6FK():
   Sys  = self.VVUigU() or " -"
   txt = "%s\n  %s\n\n" % (FFivHt("System:", VVhb13), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVZjJP() or " -"
   txt += "%s\n" % (FFivHt("Status:", VVhb13))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFucjH(self, txt, title="FTP Server Information")
 def VVlxYF(self, name=""):
  if self.VVO6FK():
   title = "Add New Directory"
   FF7lc9(self, BF(self.VVZ1EB, title), defaultText=name, title=title, message="Enter Directory name")
 def VVZ1EB(self, title, name):
  if name and name.strip():
   if self.VV950z(name) : self.VVezG2(self.curDir, name, "d")
   else     : FF2zEl(self, "Failed to create : %s" % name, title)
 def VVTMd8(self):
  if self.VVO6FK():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FF7lc9(self, BF(self.VVCZ34, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVCZ34(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVZulD(name, newName.strip()) : self.VVezG2(self.curDir, newName, flag)
   else          : FF2zEl(self, "Failed to rename to : %s" % newName, title)
 def VVCxgz(self):
  if self.VVO6FK():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFZnVu(self, BF(FF3LD6, self, BF(self.VVRhrr, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVRhrr(self, name, flag):
  if self.VVqIyF(name, flag) : self.VVezG2(self.curDir)
  else         : FF2zEl(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFZXhRFromServer(self):
  if self.VVO6FK():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVlByc(remFile)
    if size == -1:
     FF2zEl(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVn5zG
     self.session.openWithCallback(BF(self.VVJad2, title, remFile, name, size), BF(CCxFIK, mode=CCxFIK.VVU9xO, VVCX5f="Download here", VVn9uf=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVJad2(self, title, remFile, name, size, locPath):
  if locPath:
   FFH7ga(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVVdSg, remFile, size, locFile)
       , VVRlGe = BF(self.VVbJDC, remFile, size, locFile))
 def VVVdSg(self, remFile, size, locFile, VVxeRf):
  VVxeRf.VVPZSN(size)
  VVxeRf.VVxy84 = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVLgJ4(data):
     if not VVxeRf or VVxeRf.isCancelled:
      return
     locFileObj.write(data)
     VVxeRf.VVnoYr(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVLgJ4)
   except Exception as e:
    VVxeRf.VVxy84 = str(e)
 def VVbJDC(self, remFile, size, locFile, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVxy84:
   FF2zEl(self, "%s\n\nftp:/%s" % (VVxy84, remFile), title="Download Error")
   delF = True
  elif not VV1FXh:
   FF2zEl(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFQfFR(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FF5kkM(self, txt, title=title)
   else:
    FF2zEl(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFAFdq(locFile)
 def VVflID(self):
  if self.VVO6FK():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVn5zG
   self.session.openWithCallback(self.VVyW5d, BF(CCxFIK, VVCX5f="Upload selected file", VVn9uf=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVyW5d(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFH7ga(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFQfFR(locFile)
   if size == -1:
    FF2zEl(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVPQws, locFile, size, remFile)
        , VVRlGe = BF(self.VVZgrn, locFile, size, remFile))
 def VVPQws(self, locFile, size, remFile, VVxeRf):
  VVxeRf.VVPZSN(size)
  VVxeRf.VVxy84 = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVIJ3M(data):
     if not VVxeRf or VVxeRf.isCancelled:
      VVxeRf.VVxy84 = "Upload cancelled"
      locFileObj.close()
      return
     VVxeRf.VVnoYr(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVIJ3M)
   except Exception as e:
    VVxeRf.VVxy84 = VVxeRf.VVxy84 or str(e)
 def VVZgrn(self, locFile, size, remFile, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VV1FXh:
   if size == FFQfFR(locFile) : FF5kkM(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVxy84 : err = "%s\n\n%s" % (VVxy84, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FF2zEl(self, err, title=title)
   self.VVQHPU()
   self.VVqIyF(remFile, "")
  self.VVezG2(self.curDir)
class CCYT65():
 VVOYsO  = "all"
 VVPaeb = "vid"
 VV64df  = "osd"
 @staticmethod
 def VVBn8h(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFwmhG("grab"):
    winShown = session.current_dialog.shown
    if k == CCYT65.VVPaeb and winShown: session.current_dialog.hide()
    FFnB9O(BF(CCYT65.VVi29p, title, session, k, winShown))
   else:
    FFMstn(session, "No Grab command !", title=title)
 @staticmethod
 def VVi29p(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCYT65.VV64df:
   if not winShown:
    FFMstn(session, "No Window to capture !", title=title)
    return
   if not CCYT65.VVvGIJ(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCYT65.VVghON(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFMstn(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFZsCH(CFG.exportedPIconsPath.getValue()), fTitle, FFvXEJ(), ext)
  ok = FFdy80("grab -q -s %s > '%s'" % (typ, path))
  if k == CCYT65.VVPaeb and winShown:
   session.current_dialog.show()
  elif k == CCYT65.VV64df:
   ok = CCYT65.VV47sY(path, x, y, w, h)
   if not ok:
    FFAFdq(path)
    FFMstn(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCslfl, title=path, VVBK02=path))
  else      : FFMstn(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVvGIJ(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFZnVu(SELF, BF(CCYT65.VVkfhX, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVkfhX(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FF3Asy, VV5SfP=cbFnc)
  else    : fnc = BF(FFyAzl , VV5SfP=cbFnc)
  fnc(SELF, FFcDAv(VV58Rq, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVghON(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VV47sY(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFTuEm()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFGgcy(x , 0, scrW, 0, w)
     y  = FFGgcy(y , 0, scrH, 0, h)
     x1 = FFGgcy(x1, 0, scrW, 0, w)
     y1 = FFGgcy(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVX5tb(path):
  size = FFQfFR(path)
  sizeTxt = CCxFIK.VVe4Bo(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCeJZk(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFivHt(" (Requires GUI Restart)", VVAQIK) if withRestart else ""
  VVgsyy = []
  for path in self.fontsList:
   VVgsyy.append((os.path.splitext(os.path.basename(path))[0], path))
  VVgsyy.sort(key=lambda x: x[0].lower())
  VVgsyy.insert(0, VVzHzv)
  VVgsyy.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVgsyy):
    if len(item) == 2 and item[1] == self.defFnt:
     VVgsyy[ndx] = (VVd7n9 + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVgsyy[curIndex] = (VVd7n9 + VVgsyy[curIndex][0], VVgsyy[curIndex][1])
  FFNG7m(self, VVgsyy=VVgsyy, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
  self["myMenu"].onSelectionChanged.append(self.VVbcBz)
  self["myBar"].setText(self.VVJKoN())
  self["myBar"].instance.setHAlign(1)
  self.VVbcBz()
 def VVMcMd(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVbcBz(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFy505(path, fnt, isRepl=1)
  else:
   fnt = VVN3E9
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVJKoN(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VV84Ib(SELF, title, defFnt, rest, VVRlGe):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFPCH3(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVRlGe, CCeJZk, title, fontsList, defFnt, rest)
  else  : FF2zEl(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCTTCo(Screen):
 def __init__(self, session, path, VVgsyy, title):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFNG7m(self, VVgsyy=VVgsyy, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVMcMd   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVKtFP,
   "chanUp" : self.VVKtFP,
   "pageDown" : self.VVBDL8 ,
   "chanDown" : self.VVBDL8 ,
  }, -1)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
  FFvobF(self["myLabelFrm"], "#11110000")
  FFvobF(self["myLabelTit"], "#11663322")
  FFvobF(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVINKq)
  self.VVINKq()
 def VVINKq(self):
  if fileExists(self.path): txt = FFU2DB(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVMcMd(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVKtFP(self) : self["myMenu"].moveToIndex(0)
 def VVBDL8(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCCXVP():
 @staticmethod
 def VVlmLu():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVxgoO(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFyrIU(SELF, None, VVX3UR=lst, VVJA7R=30, VVREBJ=1)
 @staticmethod
 def VVwlwm(path, SELF=None):
  for enc in CCCXVP.VVlmLu():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF2zEl(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVjy6G(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VV3NXk(SELF, path, cbFnc, curEnc=VVA5PC, title="Select Encoding"):
  lst = CCCXVP.VV3xYk(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCTTCo, path, lst, title)
 @staticmethod
 def VV9I3o(SELF, cbFnc, curEnc=VVA5PC, title="Select Encoding"):
  lst = CCCXVP.VV3xYk(SELF, "", "")
  if lst:
   FFCO3u(SELF, cbFnc, title=title, VVgsyy=lst, width=1000, height=1000, VVBBM8="#22220000", VVa80e="#22220000", VVf67P=True)
 @staticmethod
 def VV3xYk(SELF, path, curEnc):
  lst = CCCXVP.VVsE5R(path)
  if lst:
   VVgsyy = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVd7n9
    elif enc == VVA5PC: c = VVMdMA
    else      : c = ""
    VVgsyy.append((c + txt, enc))
   return VVgsyy
  else:
   FFKCVv(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVsE5R(path=""):
  encLst = []
  cPath = VVV9bl + "_sup_codecs"
  if fileExists(cPath):
   lines = FFHq6Y(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCCXVP.VVlmLu())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCXeIv(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVgsyy = []
  VVgsyy.append(("Settings File"   , "SettingsFile"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Box Info"     , "VVs8sC"   ))
  VVgsyy.append(("Tuners Info"    , "VV2VYT"  ))
  VVgsyy.append(("Python Version"   , "VVKQXr"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Screen Size"    , "ScreenSize"   ))
  VVgsyy.append(("Language/Locale"   , "Locale"    ))
  VVgsyy.append(("Processor"    , "Processor"   ))
  VVgsyy.append(("Operating System"   , "OperatingSystem"  ))
  VVgsyy.append(("Drivers"     , "drivers"    ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("System Users"    , "SystemUsers"   ))
  VVgsyy.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVgsyy.append(("Uptime"     , "Uptime"    ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Host Name"    , "HostName"   ))
  VVgsyy.append(("MAC Address"    , "MACAddress"   ))
  VVgsyy.append(("Network Configuration" , "NetworkConfiguration"))
  VVgsyy.append(("Network Status"   , "NetworkStatus"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Disk Usage"    , "VVDcJO"   ))
  VVgsyy.append(("Mount Points"    , "MountPoints"   ))
  VVgsyy.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVgsyy.append(("USB Devices"    , "USB_Devices"   ))
  VVgsyy.append(("List Block-Devices"  , "listBlockDevices" ))
  VVgsyy.append(("Directory Size"   , "DirectorySize"  ))
  VVgsyy.append(("Memory"     , "Memory"    ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVgsyy.append(("Running Processes"  , "RunningProcesses" ))
  VVgsyy.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFNG7m(self, VVgsyy=VVgsyy, title="Device Information")
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCEfgU)
   elif item == "VVs8sC"   : self.VVs8sC()
   elif item == "VV2VYT"  : self.VV2VYT()
   elif item == "VVKQXr"  : self.VVKQXr()
   elif item == "ScreenSize"   : FFucjH(self, "Width\t: %s\nHeight\t: %s" % (FFTuEm()[0], FFTuEm()[1]))
   elif item == "Locale"    : CCCXVP.VVxgoO(self)
   elif item == "Processor"   : self.VVjbG5()
   elif item == "OperatingSystem"  : FFeWAm(self, "uname -a")
   elif item == "drivers"    : self.VVtnYL()
   elif item == "SystemUsers"   : FFeWAm(self, "id")
   elif item == "LoggedInUsers"  : FFeWAm(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFeWAm(self, "uptime")
   elif item == "HostName"    : FFeWAm(self, "hostname")
   elif item == "MACAddress"   : self.VVzQPj()
   elif item == "NetworkConfiguration" : FFeWAm(self, "ifconfig %s %s" % (FFmPm4("HWaddr", VVuURa), FFmPm4("addr:", VVMdMA)))
   elif item == "NetworkStatus"  : FFeWAm(self, "netstat -tulpn", VVJA7R=24, consFont=True)
   elif item == "VVDcJO"   : self.VVDcJO()
   elif item == "MountPoints"   : FFeWAm(self, "mount %s" % (FFmPm4(" on ", VVMdMA)))
   elif item == "FileSystemTable"  : FFeWAm(self, "cat /etc/fstab", VVJA7R=24, consFont=True)
   elif item == "USB_Devices"   : FFeWAm(self, "lsusb")
   elif item == "listBlockDevices"  : FFeWAm(self, "blkid")
   elif item == "DirectorySize"  : FFeWAm(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVeYT2="Reading size ...")
   elif item == "Memory"    : FFeWAm(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVV9cb()
   elif item == "RunningProcesses"  : FFeWAm(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFeWAm(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVnX1e()
   else        : self.close()
 def VVzQPj(self):
  res = FFEEr4("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFucjH(self, txt)
  else:
   FFeWAm(self, "ip link")
 def VVyxe3(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFIeeK(cmd)
  return lines
 def VVi35p(self, lines, headerRepl, widths, VV8zKo):
  VVX2QD = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVX2QD.append(parts)
  if VVX2QD and len(header) == len(widths):
   VVX2QD.sort(key=lambda x: x[0].lower())
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, VVREBJ=1)
   return True
  else:
   return False
 def VVDcJO(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFEEr4(cmd)
  if not "invalid option" in txt:
   lines  = self.VVyxe3(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV8zKo = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVi35p(lines, headerRepl, widths, VV8zKo)
  else:
   cmd = "df -h"
   lines  = self.VVyxe3(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV8zKo = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVi35p(lines, headerRepl, widths, VV8zKo)
  if not allOK:
   lines = FFIeeK(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFjJ1n(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVd7n9:
     note = "\n%s" % FFivHt("Green = Mounted Partitions", VVd7n9)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVMdMA
     elif line.endswith(mountList) : color = VVd7n9
     else       : color = VVrVS3
     txt += FFivHt(line, color) + "\n"
    FFucjH(self, txt + note)
   else:
    FF2zEl(self, "Not data from system !")
 def VVV9cb(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVyxe3(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV8zKo = (LEFT , CENTER, LEFT )
  allOK = self.VVi35p(lines, headerRepl, widths, VV8zKo)
  if not allOK:
   FFeWAm(self, cmd)
 def VVtnYL(self):
  cmd = FFYO4M(VVC4fX, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFeWAm(self, cmd)
  else : FFjIcG(self)
 def VVjbG5(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFeWAm(self, cmd)
 def VVnX1e(self):
  cmd = FFYO4M(VVSJRW, "| grep secondstage")
  if cmd : FFeWAm(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFjIcG(self)
 def VVs8sC(self):
  c = VVd7n9
  VVX3UR = []
  VVX3UR.append((FFivHt("Box Type"  , c), FFivHt(self.VVyOMM("boxtype").upper(), c)))
  VVX3UR.append((FFivHt("Board Version", c), FFivHt(self.VVyOMM("board_revision") , c)))
  VVX3UR.append((FFivHt("Chipset"  , c), FFivHt(self.VVyOMM("chipset")  , c)))
  VVX3UR.append((FFivHt("S/N"   , c), FFivHt(self.VVyOMM("sn")    , c)))
  VVX3UR.append((FFivHt("Version"  , c), FFivHt(self.VVyOMM("version")  , c)))
  VV9Ltj   = []
  VVqwcU = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVqwcU = SystemInfo[key]
     else:
      VV9Ltj.append((FFivHt(str(key), VViC5D), FFivHt(str(SystemInfo[key]), VViC5D)))
  except:
   pass
  if VVqwcU:
   VVJBTI = self.VVUDEz(VVqwcU)
   if VVJBTI:
    VVJBTI.sort(key=lambda x: x[0].lower())
    VVX3UR += VVJBTI
  if VV9Ltj:
   VV9Ltj.sort(key=lambda x: x[0].lower())
   VVX3UR += VV9Ltj
  if VVX3UR:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFyrIU(self, None, header=header, VVX3UR=VVX3UR, VVBL0l=widths, VVJA7R=28, VVREBJ=1)
  else:
   FFucjH(self, "Could not read info!")
 def VVyOMM(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFHq6Y(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVUDEz(self, mbDict):
  try:
   mbList = list(mbDict)
   VVX3UR = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVX3UR.append((FFivHt(subject, VVMdMA), FFivHt(value, VVMdMA)))
  except:
   pass
  return VVX3UR
 def VV2VYT(self):
  txt = self.VVv9yT("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVv9yT("/proc/bus/nim_sockets")
  if not txt: txt = self.VVPtg8()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFucjH(self, txt)
 def VVPtg8(self):
  txt = ""
  VVBMvF = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVBMvF("Slot Name" , slot.getSlotName())
     txt += FFivHt(slotName, VVMdMA)
     txt += VVBMvF("Description"  , slot.getFullDescription())
     txt += VVBMvF("Frontend ID"  , slot.frontend_id)
     txt += VVBMvF("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVv9yT(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFHq6Y(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFivHt(line, VVMdMA)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVKQXr(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFucjH(self, txt)
 @staticmethod
 def VVOygR():
  def VVBMvF(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVBMvF(v,0), "/etc/issue.net": VVBMvF(v,1), "/etc/image-version": VVBMvF(v,2)}
  for p1, d in v.items():
   img = CCXeIv.VV8Emt(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVBMvF(v,0), p + "Plugins/": VVBMvF(v,1), VV35QH: VVBMvF(v,2), VV3ket: VVBMvF(v,3)}
  for p1, d in v.items():
   img = CCXeIv.VVtYWO(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VV8Emt(path, d):
  if fileExists(path):
   txt = FFU2DB(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVtYWO(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCEfgU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVgsyy = []
  VVgsyy.append(("Settings (All)"   , "Settings_All"   ))
  VVgsyy.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVgsyy.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVgsyy.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVgsyy.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVgsyy.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVgsyy.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVmTYx:
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVgsyy.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVKSHN
   grep = " | grep "
   if   item == "Settings_All"   : FFeWAm(self, cmd)
   elif item == "Settings_HotKeys"  : FFeWAm(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFeWAm(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFeWAm(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFeWAm(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFeWAm(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFeWAm(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFeWAm(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFeWAm(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CC5i9A(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVBdcx, VV9CSo, VVgCLy, camCommand = CC5i9A.VVqECB()
  self.VV9CSo = VV9CSo
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VV9CSo:
   c = VVL7a3 if VVgCLy else VVVJaM
   if   "oscam" in VV9CSo : camName, oC = "OSCam", c
   elif "ncam"  in VV9CSo : camName, nC = "NCam" , c
  VVgsyy = []
  VVgsyy.append(("OSCam Files" , "OSCamFiles" ))
  VVgsyy.append(("NCam Files" , "NCamFiles" ))
  VVgsyy.append(("CCcam Files" , "CCcamFiles" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((VVhb13 + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VV4J08" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVgsyy.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVgsyy.append(VVzHzv)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVgsyy.append(FFDNao(txt, "camInfo", VV9CSo, c))
  VVgsyy.append(VVzHzv)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VV9CSo:
   for item in camLst: VVgsyy.append(item)
  else:
   for item in camLst: VVgsyy.append((item[0], ))
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCwugC, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCwugC, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCwugC, "cccam"))
   elif item == "VV4J08" : self.VV4J08()
   elif item == "OSCamReaders"  : self.VVIxvj("os")
   elif item == "NSCamReaders"  : self.VVIxvj("n")
   elif item == "camInfo"   : FFPOtz(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CC5i9A.VVb6PX(self.session, CCmcw0.VVKyQp)
   elif item == "camLiveReaders" : CC5i9A.VVb6PX(self.session, CCmcw0.VVxlJp)
   elif item == "camLiveLog"  : CC5i9A.VVb6PX(self.session, CCmcw0.VVZfTH)
   else       : self.close()
 def VV4J08(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVn5zG, FFvXEJ())
  if fileExists(path):
   lines = FFHq6Y("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVBMvF = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVBMvF("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVBMvF("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVBMvF("protocol"   , "cccam"))
      f.write(VVBMvF("device"    , "%s,%s" % (host, port)))
      f.write(VVBMvF("user"    , User))
      f.write(VVBMvF("password"   , Pass))
      f.write(VVBMvF("fallback"   , "1"))
      f.write(VVBMvF("group"    , "64"))
      f.write(VVBMvF("cccversion"   , "2.3.2"))
      f.write(VVBMvF("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF5kkM(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFZevi(tot), outFile))
   else:
    FFRB11(self, "No valid CCcam lines", 1500)
  else:
   FFRB11(self, "%s not found" % path, 1500)
 def VVIxvj(self, camPrefix):
  VVX2QD = self.VVtrD2(camPrefix)
  if VVX2QD:
   VVX2QD.sort(key=lambda x: int(x[0]))
   if self.VV9CSo and self.VV9CSo.startswith(camPrefix):
    VV6LI6 = ("Toggle State", self.VVbb0R, [camPrefix], "Changing State ...")
   else:
    VV6LI6 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV8zKo  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VV6LI6=VV6LI6, VVMXk9=True)
 def VVtrD2(self, camPrefix):
  readersFile = self.VVBdcx + camPrefix + "cam.server"
  VVX2QD = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFHq6Y(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVX2QD.append((str(len(VVX2QD) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVX2QD:
    FF2zEl(self, "No readers found !")
  else:
   FFdxlA(self, readersFile)
  return VVX2QD
 def VVbb0R(self, VVgl66, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVBdcx, camPrefix)
  readerState  = VVgl66.VVJJCV(1)
  readerLabel  = VVgl66.VVJJCV(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC5i9A.VVdHNN(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVgl66.VV3asq()
    FF2zEl(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVX2QD = self.VVtrD2(camPrefix)
   if VVX2QD:
    VVgl66.VVrEsw(VVX2QD)
  else:
   VVgl66.VV3asq()
 @staticmethod
 def VVdHNN(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFHq6Y(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF2zEl(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF2zEl(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFdxlA(SELF, confFile)
   return None
  if not iRequest:
   FF2zEl(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CC5i9A.VVvyUl(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FF2zEl(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVvyUl(SELF):
  if iElem:
   return True
  else:
   FF2zEl(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVb6PX(session, VVyggl):
  VVBdcx, VV9CSo, VVgCLy, camCommand = CC5i9A.VVqECB()
  if VV9CSo:
   runLog = False
   if   VVyggl == CCmcw0.VVKyQp : runLog = True
   elif VVyggl == CCmcw0.VVxlJp : runLog = True
   elif not VVgCLy          : FFMstn(session, message="SoftCam not started yet!")
   elif fileExists(VVgCLy)        : runLog = True
   else             : FFMstn(session, message="File not found !\n\n%s" % VVgCLy)
   if runLog:
    session.open(BF(CCmcw0, VVBdcx=VVBdcx, VV9CSo=VV9CSo, VVgCLy=VVgCLy, VVyggl=VVyggl))
  else:
   FFMstn(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVqECB():
  VVBdcx = "/etc/tuxbox/config/"
  VV9CSo = None
  VVgCLy  = None
  camCommand = FFU8jM("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VV9CSo = "oscam"
   elif camCmd.startswith("ncam") : VV9CSo = "ncam"
  if VV9CSo:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFU2DB(path), IGNORECASE)
     if span:
      VVBdcx = FFZsCH(span.group(1))
      break
   else:
    path = FFU8jM(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFZsCH(path)
    if pathExists(path):
     VVBdcx = path
   tFile = FFZsCH(VVBdcx) + VV9CSo + ".conf"
   tFile = FFU8jM("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVgCLy = tFile
  return VVBdcx, VV9CSo, VVgCLy, camCommand
class CCwugC(Screen):
 def __init__(self, VVlCk3, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVBdcx, VV9CSo, VVgCLy, camCommand = CC5i9A.VVqECB()
  if   VVlCk3 == "ncam" : self.prefix = "n"
  elif VVlCk3 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVgsyy = []
  if self.prefix == "":
   VVgsyy.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVgsyy.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVgsyy.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVgsyy.append(("constant.cw"         , "x_constant_cw" ))
   VVgsyy.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVgsyy.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVgsyy.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVgsyy.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVgsyy.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVgsyy.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVgsyy.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVgsyy.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVgsyy.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVgsyy.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVgsyy.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFpcNr(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFpcNr(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFpcNr(self, self.VVBdcx + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFpcNr(self, self.VVBdcx + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVia8Y("cam.ccache")
   elif item == "x_cam_conf"  : self.VVia8Y("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVia8Y("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVia8Y("cam.provid")
   elif item == "x_cam_server"  : self.VVia8Y("cam.server")
   elif item == "x_cam_services" : self.VVia8Y("cam.services")
   elif item == "x_cam_srvid2"  : self.VVia8Y("cam.srvid2")
   elif item == "x_cam_user"  : self.VVia8Y("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVLxOh()
   elif item == "x_CCcam_cfg"  : FFpcNr(self, self.VVBdcx + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFpcNr(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFpcNr(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFpcNr(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVia8Y(self, fileName):
  FFpcNr(self, self.VVBdcx + self.prefix + fileName)
 def VVLxOh(self):
  path = self.VVBdcx + "SoftCam.Key"
  if fileExists(path) : FFpcNr(self, path)
  else    : FFpcNr(self, path.replace(".Key", ".key"))
class CCmcw0(Screen):
 VVKyQp  = 0
 VVxlJp = 1
 VVZfTH = 2
 def __init__(self, session, VVBdcx="", VV9CSo="", VVgCLy="", VVyggl=VVKyQp):
  self.skin, self.skinParam = FFAm4L(VVCmnq, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVgCLy   = VVgCLy
  self.VVyggl  = VVyggl
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVBdcx + VV9CSo + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV9CSo : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVBdcx, self.camPrefix)
  if self.VVyggl == self.VVKyQp:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVyggl == self.VVxlJp:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFNG7m(self, self.Title, addScrollLabel=True)
  FFTBJT(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVHpMk
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self["myLabel"].VVZ8z1(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFzs4L(self)
  self.VVHpMk()
 def onExit(self):
  self.timer.stop()
 def VVGtVP(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVkbe7)
  except:
   self.timer.callback.append(self.VVkbe7)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFRB11(self, "Started", 1000)
 def VVr7pV(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVkbe7)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFRB11(self, "Stopped", 1000)
 def VVHpMk(self):
  if self.timerRunning:
   self.VVr7pV()
  else:
   self.VVGtVP()
   if self.VVyggl == self.VVKyQp or self.VVyggl == self.VVxlJp:
    if self.VVyggl == self.VVKyQp : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC5i9A.VVdHNN(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFnB9O(self.VVEQ6j)
    else:
     self.close()
   else:
    self.VVnec3()
 def VVkbe7(self):
  if self.timerRunning:
   if   self.VVyggl == self.VVKyQp : self.VVtUo8()
   elif self.VVyggl == self.VVxlJp : self.VVtUo8()
   else            : self.VVnec3()
 def VVnec3(self):
  if fileExists(self.VVgCLy):
   fTime = FFwVZA(os.path.getmtime(self.VVgCLy))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVxStF(), VVFq7T=VVVykt)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVgCLy)
 def VVEQ6j(self):
  self.VVtUo8()
 def VVtUo8(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFivHt("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVL6GV))
   self.camWebIfErrorFound = True
   self.VVr7pV()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVyggl == self.VVKyQp : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFivHt("Error while parsing data elements !\n\nError = %s" % str(e), VVHEBa)
   self.camWebIfErrorFound = True
   self.VVr7pV()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVaaRe(root)
  self["myLabel"].setText(txt, VVFq7T=VVVykt)
  self["myBar"].setText("Last Update : %s" % FFUEda())
 def VVaaRe(self, rootElement):
  def VVBMvF(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVyggl == self.VVKyQp:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFivHt(status, VVd7n9)
    else          : status = FFivHt(status, VVHEBa)
    txt += SEP + "\n"
    txt += VVBMvF("Name"  , name)
    txt += VVBMvF("Description" , desc)
    txt += VVBMvF("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVBMvF("Protocol" , protocol)
    txt += VVBMvF("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFivHt("Yes", VVd7n9)
    else    : enabTxt = FFivHt("No", VVHEBa)
    txt += SEP + "\n"
    txt += VVBMvF("Label"  , label)
    txt += VVBMvF("Protocol" , protocol)
    txt += VVBMvF("Enabled" , enabTxt)
  return txt
 def VVxStF(self):
  lines = FFIeeK("tail -n %d %s" % (100, self.VVgCLy))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVAQIK + line[:19] + VVrVS3 + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVjK42 + "WebIf" + VVrVS3)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VViC5D + h1 + h2 + VVrVS3 + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVd7n9 + span.group(2) + VVhb13 + span.group(3) + VVrVS3 + span.group(4)
    line = self.VV7UvE(line, VVhb13, ("(webif)", ))
    line = self.VV7UvE(line, VVhb13, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VV7UvE(line, VVd7n9, ("OSCam", "NCam", "log switched"))
    line = self.VV7UvE(line, VVgmAg, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVMdMA + line[ndx + 3:] + VVrVS3
   elif line.startswith("----") or ">>" in line:
    line = FFivHt(line, VVWK7B)
   txt += line + "\n"
  return txt
 def VV7UvE(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVrVS3 + t3
  return line
class CCBdOt(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVgsyy = []
  VVgsyy.append(("Backup Channels"    , "VVLGRN"   ))
  VVgsyy.append(("Restore Channels"    , "Restore_Channels"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Backup SoftCAM Files"   , "VV6xlV" ))
  VVgsyy.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVgsyy.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVgsyy.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Backup Network Settings"  , "VV39iP"   ))
  VVgsyy.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVmTYx:
   VVgsyy.append(VVzHzv)
   VVgsyy.append((VVL6GV + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVUcz6"   ))
   VVgsyy.append((VVd7n9 + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVUOLu), "createMyIpk"   ))
   VVgsyy.append((VVd7n9 + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVUOLu), "createMyDeb"   ))
   VVgsyy.append((VViC5D + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVgsyy.append((VViC5D + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVVs44" ))
   VVgsyy.append((VViC5D + "Show Windows Stats"           , "VVk87L" ))
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVLGRN"    : self.VVLGRN()
   elif item == "Restore_Channels"    : self.VV7lip("channels_backup*.tar.gz", self.VVxItI, isChan=True)
   elif item == "VV6xlV"   : self.VV6xlV()
   elif item == "Restore_SoftCAM_Files"  : self.VV7lip("softcam_backup*.tar.gz", self.VVeVG8)
   elif item == "Backup_TunerDiSEqC"   : self.VVafxz("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV7lip("tuner_backup*.backup", BF(self.VVpcn3, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVafxz("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV7lip("hotkey_*backup*.backup", BF(self.VVpcn3, "misc"))
   elif item == "VV39iP"    : self.VV39iP()
   elif item == "Restore_Network"    : self.VV7lip("network_backup*.tar.gz", self.VVV4m5)
   elif item == "VVUcz6"     : FFZnVu(self, BF(FF3LD6, self, BF(CCBdOt.VVUcz6, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVJwab(False)
   elif item == "createMyDeb"     : self.VVJwab(True)
   elif item == "createMyTar"     : self.VVuQtV()
   elif item == "VVVs44"   : self.VVVs44()
   elif item == "VVk87L"    : CCBdOt.VVk87L(self)
 @staticmethod
 def VV2YNj(SELF):
  OBF_Path = VV0oWI + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFdxlA(SELF, OBF_Path)
   return None
 @staticmethod
 def VVk87L(SELF):
  obf = CCBdOt.VV2YNj(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFucjH(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVUcz6(SELF):
  obf = CCBdOt.VV2YNj(SELF)
  if obf:
   txt, err = obf.fixCode(VV0oWI, VVkRol, VVUOLu)
   if err : FF2zEl(SELF, err)
   else : FFucjH(SELF, txt)
 def VVJwab(self, VVi6yH):
  OBF_Path = VV0oWI + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF2zEl(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFlh8N("rm -f %s__pycache__/" % VV0oWI)
  FFlh8N("mv -f '%smain.py' '%s'" % (VV0oWI, OBF_Path))
  FFlh8N("mv -f '%splugin.py' '%s'" % (VV0oWI, OBF_Path))
  FFlh8N("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VV0oWI))
  self.session.openWithCallback(self.VV4Yin, BF(CCItJq, path=VV0oWI, VVi6yH=VVi6yH))
 def VV4Yin(self):
  FFlh8N("mv -f %s %s" % (VV0oWI + "OBF/main.py" , VV0oWI))
  FFlh8N("mv -f %s %s" % (VV0oWI + "OBF/plugin.py", VV0oWI))
 def VVVs44(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF2zEl(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF2zEl(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVZYA2("%s*.list" % path)
  if err:
   FFdxlA(self, path + "*.list")
   return
  srcF, err = self.VVZYA2("%s*main_final.py" % path)
  if err:
   FFdxlA(self, path + "*.final.py")
   return
  VVX3UR = []
  for f in files:
   f = os.path.basename(f)
   VVX3UR.append((f, f))
  FFCO3u(self, BF(self.VVp8ob, path, codF, srcF), VVgsyy=VVX3UR)
 def VVp8ob(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFdxlA(self, logF)
   else     : FF3LD6(self, BF(self.VV8rrB, logF, codF, srcF))
 def VV8rrB(self, logF, codF, srcF):
  lst  = []
  lines = FFHq6Y(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF2zEl(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVYxOx(lst, logF, newLogF)
  totSrc  = self.VVYxOx(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFucjH(self, txt)
 def VVZYA2(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVYxOx(self, lst, f1, f2):
  txt = FFU2DB(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVuQtV(self):
  VVX3UR = []
  VVX3UR.append("%s%s" % (VV0oWI, "*.py"))
  VVX3UR.append("%s%s" % (VV0oWI, "*.png"))
  VVX3UR.append("%s%s" % (VV0oWI, "*.xml"))
  VVX3UR.append("%s"  % (VVV9bl))
  FFwmPJ(self, VVX3UR, "%s_%s" % (PLUGIN_NAME, VVkRol), addTimeStamp=False)
 def VVLGRN(self):
  path1 = VVKSHN
  path2 = "/etc/tuxbox/"
  VVX3UR = []
  VVX3UR.append("%s%s" % (path1, "*.tv"))
  VVX3UR.append("%s%s" % (path1, "*.radio"))
  VVX3UR.append("%s%s" % (path1, "*list"))
  VVX3UR.append("%s%s" % (path1, "lamedb*"))
  VVX3UR.append("%s%s" % (path2, "*.xml"))
  FFwmPJ(self, VVX3UR, self.VVSkVk("channels_backup"), addTimeStamp=True)
 def VV6xlV(self):
  VVX3UR = []
  VVX3UR.append("/etc/tuxbox/config/")
  VVX3UR.append("/usr/keys/")
  VVX3UR.append("/usr/scam/")
  VVX3UR.append("/etc/CCcam.cfg")
  FFwmPJ(self, VVX3UR, self.VVSkVk("softcam_backup"), addTimeStamp=True)
 def VV39iP(self):
  VVX3UR = []
  VVX3UR.append("/etc/hostname")
  VVX3UR.append("/etc/default_gw")
  VVX3UR.append("/etc/resolv.conf")
  VVX3UR.append("/etc/wpa_supplicant*.conf")
  VVX3UR.append("/etc/network/interfaces")
  VVX3UR.append("%snameserversdns.conf" % VVKSHN)
  FFwmPJ(self, VVX3UR, self.VVSkVk("network_backup"), addTimeStamp=True)
 def VVSkVk(self, fName):
  img = CCXeIv.VVOygR()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVxItI(self, fileName=None):
  if fileName:
   FFZnVu(self, BF(FF3LD6, self, BF(self.VVtvjy, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVtvjy(self, fileName):
  path = "%s%s" % (VVn5zG, fileName)
  if fileExists(path):
   if CCxFIK.VVsGUQ(path):
    VViNJC , VVLDFX = CCuZg4.VVUxBE()
    VVY0qL, VV6pvs = CCuZg4.VV0V93()
    cmd  = FFT1jM("cd %s" % VVKSHN)
    cmd += FFT1jM("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVLDFX, VV6pvs))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFlh8N(cmd)
    FFjhC8()
    if ok: FF5kkM(self, "Channels Restored.")
    else : FF2zEl(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FF2zEl(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFdxlA(self, path)
 def VVeVG8(self, fileName=None):
  if fileName:
   FFZnVu(self, BF(self.VV0Qbo, fileName), "Overwrite SoftCAM files ?")
 def VV0Qbo(self, fileName):
  fileName = "%s%s" % (VVn5zG, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF0Zhf(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFmPm4(note, VVMdMA), sep))
  else:
   FFdxlA(self, fileName)
 def VVV4m5(self, fileName=None):
  if fileName:
   FFZnVu(self, BF(self.VVw8hh, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVw8hh(self, fileName):
  fileName = "%s%s" % (VVn5zG, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFyAzl(self,  cmd)
  else:
   FFdxlA(self, fileName)
 def VV7lip(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FF3Vxe()
  if pathExists(VVn5zG):
   myFiles = FFPCH3(VVn5zG, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVX3UR = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVX3UR.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV2u6t = ("Sat. List", self.VVW3dD)
    elif isChan and iTar: VV2u6t = ("Bouquets Importer", CCMQGS.VVGw8p)
    else    : VV2u6t = None
    FFCO3u(self, callBackFunction, title=title, width=1200, VVgsyy=VVX3UR, VV2u6t=VV2u6t, VVGamv=VVn5zG)
   else:
    FF2zEl(self, "No files found in:\n\n%s" % VVn5zG, title)
  else:
   FF2zEl(self, "Path not found:\n\n%s" % VVn5zG, title)
 def VVafxz(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVKSHN
  tCons = CCu0fe()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVttvs, filePrefix))
 def VVttvs(self, filePrefix, result, retval):
  title = FF3Vxe()
  if pathExists(VVn5zG):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF2zEl(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVn5zG, filePrefix, self.VVSkVk(""), FFvXEJ())
    try:
     VVX3UR = str(result.strip()).split()
     if VVX3UR:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVX3UR:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFivHt(fName, VVMdMA), SEP)
       FFucjH(self, txt, title=title, VVFq7T=VVVykt)
      else:
       FF2zEl(self, "File creation failed!", title)
     else:
      FF2zEl(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFlh8N("rm %s" % fName)
     FF2zEl(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFlh8N("rm %s" % fName)
     FF2zEl(self, "Error while writing file.")
  else:
   FF2zEl(self, "Path not found:\n\n%s" % VVn5zG, title)
 def VVpcn3(self, mode, path=None):
  if path:
   path = "%s%s" % (VVn5zG, path)
   if fileExists(path):
    lines = FFHq6Y(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFZnVu(self, BF(self.VVLwtt, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFKQXu(self, path, title=FF3Vxe())
   else:
    FFdxlA(self, path)
 def VVLwtt(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVZU3B = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVZU3B.append("echo -e 'Reading current settings ...'")
  VVZU3B.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVZU3B.append("echo -e 'Preparing new settings ...'")
  VVZU3B.append(settingsLines)
  VVZU3B.append("echo -e 'Applying new settings ...'")
  VVZU3B.append("mv -f %s %s" % (tFile, sFile))
  FFszeA(self, VVZU3B)
 def VVW3dD(self, VV7Q6fObj, path):
  if not path:
   return
  path = VVn5zG + path
  if not fileExists(path):
   FFdxlA(self, path)
   return
  txt = FFU2DB(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFrc8H(item[1]))
   FFucjH(self, txt, title="Satellites List")
  else:
   FF2zEl(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCMQGS():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVGw8p(SELF, fName):
  bi = CCMQGS(SELF)
  bi.instance = bi
  bi.VVIc1n(SELF, fName)
 @staticmethod
 def VVMFNY(SELF):
  bi = CCMQGS(SELF)
  bi.instance = bi
  bi.VV2Xeo()
 def VVIc1n(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVn5zG + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FF3LD6(waitObg, self.VV5mTm, title="Reading bouquets ...")
  else      : self.VVoabU(self.filePath)
 def VV3xCD(self, txt) : FF2zEl(self.SELF, txt, title=self.Title)
 def VVnkcm(self, txt)  : FFRB11(self, txt, 1500)
 def VVoabU(self, path) : FFdxlA(self.SELF, path, title=self.Title)
 def VV2Xeo(self):
  if pathExists(VVn5zG):
   lst = FFPCH3(VVn5zG, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVx1dx())
   if len(lst) > 0:
    VVgsyy = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFivHt(item, VVhb13) if item.endswith(".zip") else item
     VVgsyy.append((txt, item))
    VVgsyy.sort(key=lambda x: x[1].lower())
    VVwWMp = self.VVyl9P
    FFCO3u(self.SELF, self.VVffEF, minRows=3, title=self.Title, width=1200, VVgsyy=VVgsyy, VVwWMp=VVwWMp, VVGamv=VVn5zG, VVBBM8="#22111111", VVa80e="#22111111")
   else:
    self.VV3xCD("No valid backup files found in:\n\n%s" % VVn5zG)
  else:
   self.VV3xCD("Backup Directory not found:\n\n%s" % VVn5zG)
 def VVyl9P(self, item=None):
  if item:
   VVyxPv, txt, fName, ndx = item
   self.VVIc1n(VVyxPv, fName)
 def VVffEF(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVx1dx(self):
  files = FFPCH3(VVn5zG, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VV5mTm(self):
  lines, err = CCMQGS.VVROkD(self.filePath, "bouquets.tv")
  if err:
   self.VV3xCD(err)
   return
  bTvSortLst  = self.VVZ5HF(lines)
  lines, err = CCMQGS.VVROkD(self.filePath, "bouquets.radio")
  if err:
   self.VV3xCD(err)
   return
  bRadSortLst = self.VVZ5HF(lines)
  VVX2QD = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVe0Kc(f, mode, len(VVX2QD), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVX2QD.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVe0Kc(f, mode, len(VVX2QD), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVe0Kc(f, mode, len(VVX2QD), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVX2QD.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVe0Kc(f, mode, len(VVX2QD), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVX2QD:
   VVX2QD.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVX2QD): VVX2QD[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVX2QD):
     if key == os.path.basename(row[9]):
      VVX2QD = VVX2QD[:ndx+1] + lst + VVX2QD[ndx+1:]
      break
   for ndx, item in enumerate(VVX2QD): VVX2QD[ndx][0] = str(ndx + 1)
   VVaOdk = "#11000600"
   VVkkpG  = ("Show Services" , self.VVgEWw  , [], "Reading ..." )
   VVPn7Q = (""    , self.VVXIw4, [])
   VVH4Z8 = ("Options"  , self.VVJdKD, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VV8zKo  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFyrIU(self.SELF, None, title=self.Title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=24, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVH4Z8=VVH4Z8, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVBBM8=VVaOdk, VVa80e=VVaOdk, VVaOdk=VVaOdk, VVlVSy="#00004455", VV3FyM="#0a282828")
  else:
   self.VV3xCD("No valid bouquets in:\n\n%s" % self.filePath)
 def VVZ5HF(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVXIw4(self, VVgl66, title, txt, colList):
  FFucjH(self.SELF, FFkgYM(txt), title=title)
 def VVJdKD(self, VVgl66, title, txt, colList):
  mSel = CCXfgt(self.SELF, VVgl66)
  if VVgl66.VVIa5A:
   totSel = VVgl66.VVGnLM()
   if totSel: VVgsyy = [("Import %s Bouquet%s" % (FFivHt(str(totSel), VVd7n9), FFZevi(totSel)), "imp")]
   else  : VVgsyy = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFivHt(bName, VVd7n9)
   VVgsyy = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FF3LD6, VVgl66, BF(CCMQGS.VVGMbb, self.SELF, VVgl66, self.filePath))}
  mSel.VVnFMb(VVgsyy, cbFncDict)
 def VVgEWw(self, VVgl66, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCMQGS.VVROkD(self.filePath, "lamedb")
   if err:
    self.VV3xCD(err)
    return
   dbServLst = CCuZg4.VVc3Tr(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVgl66.VVErbL()
   lines, err = CCMQGS.VVROkD(self.filePath, os.path.basename(fName))
   if err:
    self.VV3xCD(err)
    return
   VVX2QD = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVX2QD.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVX2QD.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVX2QD.append((span.group(1).strip() or "-", "Stream Relay" if FFTEln(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVX2QD.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVX2QD.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCuZg4.VVOGMg(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVX2QD.append((name.strip() or "-", FF5v7R(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVX2QD):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCMQGS.VVROkD(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVX2QD[ndx] = (bName, descr)
   if VVX2QD:
    VVaOdk = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VV8zKo = (LEFT  , CENTER)
    FFyrIU(self.SELF, None, title="Services in : %s" % bName, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, VVBBM8=VVaOdk, VVa80e=VVaOdk, VVaOdk=VVaOdk, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFRB11(VVgl66, err, 1500)
  else : VVgl66.VV3asq()
 def VVe0Kc(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VV3xCD("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFTEln(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV65di(var):
   return str(var) if var else VVPwgj + str(var)
  totItem = VVMdMA + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVL6GV   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVhb13, "Sub-B."
  else  : bColor, totBnb = ""      , VV65di(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV65di(totDVB), VV65di(totIptv), VV65di(totSRelay), VV65di(totLoc), VV65di(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVGMbb(SELF, VVgl66, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVKSHN + "bouquets.tv"
  radBouquetFile = VVKSHN + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFdxlA(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFdxlA(SELF, radBouquetFile, title=title)
   return
  isMulti = VVgl66.VVIa5A
  if isMulti : rows = VVgl66.VVXysw()
  else  : rows = [VVgl66.VVErbL()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FF2zEl(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFkgYM(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFkgYM(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVKSHN + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVKSHN + newFile
    CCMQGS.VVN9H6(archPath, fName, VVKSHN, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFZs4V(tvBouquetFile)
   FFZs4V(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCMQGS.VVHfqu(SELF, archPath, bList)
   FFjhC8()
  txt  = FFivHt("Added:\n", VVhb13)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFivHt("Imported to lamedab:\n", VVhb13)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFivHt("Missing from archived lamedb:\n", VVL6GV)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFucjH(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVHfqu(SELF, archPath, bList):
  VViNJC, err = CCuZg4.VVSslP(SELF, VVQNH9=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCuZg4.VVN4rR(VViNJC, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFHq6Y(VVKSHN + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCuZg4.VVOGMg(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCuZg4.VVjz7g(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCMQGS.VVrygB(archPath, dbName)
   CCMQGS.VVN9H6(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCuZg4.VVN4rR(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCuZg4.VVN4rR(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCuZg4.VVN4rR(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCuZg4.VVN4rR(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFAFdq(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VViNJC + ".tmp"
   lines   = FFHq6Y(VViNJC)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFlh8N("mv -f '%s' '%s'" % (tmpDbFile, VViNJC))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VV2PUn(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVrygB(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVN9H6(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVROkD(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCWqu8():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVHShx()
 def VVHShx(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVfSRh(self):
  FF3LD6(self, self.VVZEj7)
 def VVZEj7(self):
  if pathExists(self.projMainPath):
   lst = FFRDFw(self.projMainPath)
   VVgsyy = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVgsyy.append((prName, prName))
   if VVgsyy:
    VVgsyy.sort(key=lambda x: x[1].lower())
    VVwWMp = self.VVRKIQ
    VV2u6t = ("Add new project", self.VVCbRh)
    VVOmbd= ("Delete Project" , self.VVQJmk)
    self.projMenu = FFCO3u(self, None, VVgsyy=VVgsyy, width=1100, VVwWMp=VVwWMp, VV2u6t=VV2u6t, VVOmbd=VVOmbd, minRows=5, VVBBM8="#22111133", VVa80e="#22111133")
   else:
    FFZnVu(self, self.VVGpvu, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVIX13("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVGpvu(self)    : FF3LD6(self, BF(self.VV3oe0))
 def VVCbRh(self, VVyxPv, item) : FF3LD6(self.projMenu, BF(self.VV3oe0))
 def VV3oe0(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVtEfp(name)
 def VVtEfp(self, name, cbFnc=None):
  FF7lc9(self, cbFnc or self.VVj6HE, defaultText=name, title="New Project Name", message="Enter project name")
 def VVj6HE(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFZnVu(self, BF(self.VVtEfp, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FF4Zzy(path)
    if err:
     self.VVIX13("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVbEsC((item, item), isSort=True)
     else   : self.VVfSRh()
 def VVQJmk(self, VVyxPv, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFXtMv(path)
    FFZnVu(self, BF(self.VVbVnv, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VVbVnv(self, path):
  if FFlh8N("rm -rf '%s'" % path):
   self.projMenu.VVJBkC()
 def VVRKIQ(self, item=None):
  if item:
   VVyxPv, txt, Dir, ndx = item
   self.VVHShx()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVV9bl
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FFHq6Y(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFUEda()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVGygj()
   else      : self.VVIX13("Cannot create project file:\n\n%s" % self.projFile)
 def VVGygj(self, VVyxPv=None, jmpDict=None):
  FF3LD6(VVyxPv or self.projTable or self, BF(self.VVHGai, jmpDict))
 def VVHGai(self, jmpDict):
  self.VVHShx()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FFHq6Y(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVpAAm(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVIX13('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFQfFR(path)
    if sz > -1: size = CCxFIK.VVe4Bo(sz, mode=4)
    else   : size = FFivHt("Size error", VVL6GV)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FFHq6Y(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVgKRR(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVaA0D(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFivHt("Unknown value", VVL6GV), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFivHt(rem, VVL6GV), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVX2QD = pkgRows
  VVX2QD.extend(actnRows)
  VVX2QD.extend(ctrlRows)
  VVX2QD.extend(fileRows)
  VVX2QD.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVX2QD):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFivHt("Valid", VVd7n9), " ... " + Remarks if Remarks else "")
    VVX2QD[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVrEsw(VVX2QD, tableRefreshCB=BF(self.VVf7BA, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVPn7Q = (""     , self.VVIp1N   , [])
   menuButtonFnc = (""     , self.VVhPPe   , [])
   VVTaaj = ("Create Package"  , self.VVWXfT , [])
   VVH4Z8 = ("Post Install Action", self.VVRTsZ, [])
   VVmhJa = ("Edit File"   , self.VVPxZQ  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VV8zKo = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, width=1850, height=1040, VVJA7R=26, VVPn7Q=VVPn7Q, menuButtonFnc=menuButtonFnc, VVTaaj=VVTaaj, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, searchCol=2
         , VVBBM8=bg, VVa80e=bg, VVaOdk=bg, VVlVSy="#00664411", VV3FyM="#00444444", VVf4Ym="#08442211")
   self.projTable.VVz6sq(self.VV0smh)
   self.VV0smh()
 def VVf7BA(self, jmpDict, VVgl66, title, txt, colList):
  self.projTable.VVWYsy(jmpDict)
 def VV0smh(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVErbL()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVpAAm(self, line):
  def VVaiQL(patt, val, Len):
   if len(val) < Len   : return FFivHt("Length error" , VVL6GV)
   elif not iMatch(patt, val) : return FFivHt("Invalid format" , VVL6GV)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVaiQL(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVaiQL(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVgKRR(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFWV37(path)
  path = FFjJ1n(path)
  c = VVL6GV
  if   typ == "Mount" : rem = FFivHt("Not allowed", c)
  elif not typ  : rem = FFivHt("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFivHt("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFngsO(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFWV37(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFivHt("Not allowed", c)
     elif targetType == "Directory" : sz = FFngsO(targetPath)
     elif targetType == "File"  : sz = FFQfFR(targetPath)
     else       : sz, rem = FFQfFR(path), FFivHt("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFQfFR(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCxFIK.VVe4Bo(sz, mode=4)
     else:
      size = FFivHt("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVaA0D(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVPxZQ(self, VVgl66, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCDQxK(self, path, VVRlGe=self.VV8Utg, curRowNum=lineNdx)
  else    : FFdxlA(self, path)
 def VV8Utg(self, fileChanged):
  if fileChanged:
   self.VVGygj()
 def VVIX13(self, txt):
  FF2zEl(self, txt, title=self.projTitle)
 def VVIp1N(self, VVgl66, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVhb13
  s  = FFExgP("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFExgP("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCxFIK.VVe4Bo(self.projFilesSize))
  FFucjH(self, s, title="Project Info", width=1600)
 def VVhPPe(self, VVgl66, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVL7a3, VVVJaM, VVhb13
  VVgsyy = []
  VVgsyy.append((c1 + "Add Resource File"  , "addFile" ))
  VVgsyy.append((c1 + "Add Resource Directory" , "addDir" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change Package Name"   , "pkgNam" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Add Dependency"   , "addDep" ))
  VVgsyy.append((c2 + "Remove Dependency"  , "delDep" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVgsyy.append(FFDNao('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(FFDNao("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVL6GV))
  FFCO3u(self, self.VVVROo, VVgsyy=VVgsyy, width=1050, title="Options", VVBBM8="#11001122", VVa80e="#11001122")
 def VVVROo(self, item=None):
  if item:
   if   item == "addFile" : self.VVVUY9(False)
   elif item == "addDir" : self.VVVUY9(True)
   elif item == "pkgNam" : self.VVvKVE()
   elif item == "addDep" : FF3LD6(self.projTable, self.VVMkG5)
   elif item == "delDep" : self.VVJPaw()
   elif item == "ctrlFMan" : self.VV3wDa()
   elif item == "ctrlImprt": FF3LD6(self.projTable, self.VVQOAP)
   elif item == "ctrlUndo" : self.VVX2ty()
   elif item == "delRow" : self.VVQjzo()
 def VVVUY9(self, isDir):
  Dir = FFCdvu(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VV7r1t, BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=Dir))
  else : self.session.openWithCallback(self.VV7r1t, BF(CCxFIK, patternMode="all", VVn9uf=Dir))
 def VV7r1t(self, path):
  if path:
   FFH7ga(CFG.lastPkgProjDir, path)
   self.VV1W9K(path, 2)
 def VV3wDa(self):
  Dir = FFCdvu(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVenOH, BF(CCxFIK, patternMode="pkgCtrl", VVn9uf=Dir))
 def VVenOH(self, path):
  if path:
   FFH7ga(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFlh8N("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVGygj()
    self.projTable.VVWYsy({1:"Script", 2:fName})
 def VVQOAP(self):
  cmd = FFYO4M(VVC4fX, "")
  if not cmd:
   FFjIcG(self)
   return
  lst = FFIeeK(cmd)
  if lst:
   err = CCxFIK.VVjWm9(lst, fromFind=False)
   if err:
    self.VVIX13(err)
    return
   lst.sort()
   VVX2QD = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVX2QD.append(("", span.group(1), span.group(2)))
   if VVX2QD:
    VV6LI6 = ("Import 'control' data", self.VVG33b, [])
    VVH4Z8 = ("Package Info.", self.VVd5u6     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VVBL0l=widths, VVJA7R=30, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVhwQH=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVBBM8="#22110011", VVa80e="#22191111", VVaOdk="#22191111", VVlVSy="#00003030", VV3FyM="#00333333")
   else:
    self.VVIX13("Cannot process installed packages !")
  else:
   self.VVIX13("Cannot read installed packages !")
 def VVX2ty(self):
  if FFlh8N("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVGygj(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVIX13("Process Failed !")
 def VVG33b(self, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVrZ0f, VVgl66, colList[1]))
 def VVrZ0f(self, VVgl66, pkg):
  lines = []
  for line in FFIeeK(FFcDAv(VVpgtv, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFZnVu(self, BF(self.VV8zEc, VVgl66, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVIX13("Cannot import from this package:\n\n%s" % pkg)
 def VV8zEc(self, VVgl66, lines):
  VVgl66.cancel()
  FF5lNb(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVGygj(jmpDict={1:"Control", 2:"Package"})
 def VVQjzo(self):
  lineNum = int(self.projTable.VVErbL()[0]) + 1
  FFlh8N("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVGygj()
 def VV1W9K(self, line, jmp):
  if fileExists(self.projFile):
   FF5lNb(self.projFile)
   FFZs4V(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVGygj(jmpDict=jmpDict)
  else:
   FFdxlA(self, self.projFile, title=self.projTitle)
 def VVRTsZ(self, VVgl66, title, txt, colList):
  VVgsyy = []
  VVgsyy.append(FFDNao("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVgsyy.append(FFDNao("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVgsyy.append(FFDNao("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(FFDNao("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVgsyy.append(FFDNao("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVgsyy.append(FFDNao("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFCO3u(self, self.VV4eaE, VVgsyy=VVgsyy, title="Action (after the package is installed/removed)")
 def VV4eaE(self, item=None):
  if item:
   if   item == "instNon" : self.VV1aF6("postinst", 0)
   elif item == "instRes" : self.VV1aF6("postinst", 1)
   elif item == "instReb" : self.VV1aF6("postinst", 2)
   elif item == "rmNon" : self.VV1aF6("postrm", 0)
   elif item == "rmRes" : self.VV1aF6("postrm", 1)
   elif item == "rmReb" : self.VV1aF6("postrm", 2)
 def VV1aF6(self, subj, val):
  if fileExists(self.projFile):
   lines = FFHq6Y(self.projFile)
   FF5lNb(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VV1W9K("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVGygj()
 def VVvKVE(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVgsyy = []
  VVgsyy.append((pkg, pkg))
  VVgsyy.append(VVzHzv)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVhb13 if name == self.projPkg else ""
    VVgsyy.append((c + name, name))
   else:
    VVgsyy.append(VVzHzv)
  FFCO3u(self, self.VVIvdx, VVgsyy=VVgsyy, title="Package Name")
 def VVIvdx(self, item=None):
  if item:
   self.VVxefP("Package", item)
 def VVMkG5(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVgsyy = []
   for item in lst: VVgsyy.append((item, item))
   VVgsyy.sort(key=lambda x: x[0].lower())
   VVyxPv = FFCO3u(self, self.VVDWIT, VVgsyy=VVgsyy, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVyxPv.VVSIKM(self.projLastDepends)
  else:
   self.VVIX13("Cannot read dependencies list !")
 def VVDWIT(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FFHq6Y(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVxefP("Depends", ", ".join(lst))
   else:
    FFRB11(self.projTable, "Already added", 1500)
    self.projTable.VVWYsy({1:"Control", 2:"Depends"})
 def VVJPaw(self):
  lst = []
  for row in self.projTable.VV3eCu():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVgsyy = []
   for item in lst: VVgsyy.append((item, item))
   FFCO3u(self, BF(self.VVTmJg, lst), VVgsyy=VVgsyy, title="Remove Dependency")
  else:
   self.VVIX13("No dependencies to remove !")
 def VVTmJg(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVxefP("Depends", ", ".join(lst))
   else:
    FFlh8N("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVGygj()
 def VVxefP(self, subj, val):
  lines = FFHq6Y(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVGygj(jmpDict={1:"Control", 2:subj})
 def VVWXfT(self, VVgl66, title, txt, colList):
  VVgsyy = []
  VVgsyy.append(("Create .ipk"  , "ipk"))
  VVgsyy.append(("Create .deb"  , "deb"))
  VVgsyy.append(("Create .tar.gz" , "tar"))
  FFCO3u(self, self.VVI9O8, VVgsyy=VVgsyy, width=500, title=self.projTitle)
 def VVI9O8(self, item=None):
  if item:
   FF3LD6(self.projTable, BF(self.VV2Cj5, item))
 def VV2Cj5(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVIX13("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVi6yH, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVi6yH, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVIX13(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFT1jM("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFmPm4(result  , VVd7n9))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFmPm4(failed, VVHEBa))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFT1jM("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VV3eCu()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFyAzl(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFlh8N(cmd) or not pathExists(ctrlDir):
   VVIX13(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVaiQL(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFlh8N("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVaiQL(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFZs4V(dstF)
   FFlh8N("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFiCnc()
  if VVi6yH:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFWSuq("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFyAzl(self, cmd)
class CC3nMC(Screen, CCWqu8):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCWqu8.__init__(self)
  c1, c2, c3, c4 = VVL7a3, VVVJaM, VVAQIK, VVhb13
  VVgsyy = []
  VVgsyy.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c3 + "Remove Packages (show all)"     , "VV74GPsAll"  ))
  VVgsyy.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Update Packages List from Feed"    , "VV2d5a"  ))
  VVgsyy.append((c2 + "Upgradable Packages"       , "VVxgOR" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Packaging Tool"         , "VV7eRD"   ))
  VVgsyy.append(("Active Feeds"          , "VVXfk5"   ))
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCBTkh.VVsrrs(self)
   elif item == "downloadInstallPackages"  : FF3LD6(self, BF(self.VVJkJ2, 0, ""))
   elif item == "VV74GPsAll"   : FF3LD6(self, BF(self.VVJkJ2, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF3LD6(self, BF(self.VVJkJ2, 2, "| grep -e skin -e enigma2-"))
   elif item == "VV2d5a"   : CC3nMC.VV2d5a(self)
   elif item == "VVxgOR"  : FF3LD6(self, self.VVxgOR)
   elif item == "packageCreator"    : self.VVfSRh()
   elif item == "VV7eRD"    : self.VV7eRD()
   elif item == "VVXfk5"    : FF3LD6(self, self.VVXfk5)
   else          : self.close()
 def VVXfk5(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVX2QD = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVX2QD.append((os.path.basename(path), str(tot)))
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VV8zKo = (LEFT  , CENTER )
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, width=1000, VVJA7R=26, VVREBJ=2)
  else:
   self.VVIX13("Cannot read packages list !")
 def VVxgOR(self, VVgl66=None):
  lst = FFIeeK(FFYO4M(VVdCZV, ""))
  VVX2QD = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVX2QD.append((str(len(VVX2QD) + 1), pkg, curV, newVer))
   if VVX2QD:
    if VVgl66:
     VVgl66.VVrEsw(VVX2QD, VVYHEIMsg=True)
    else:
     bg = "#00221111"
     VV6LI6 = ("Upgrade", self.VVON2H   , [])
     VVH4Z8 = ("Package Info.", self.VVd5u6 , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VV8zKo = (CENTER , LEFT  , LEFT  , LEFT   )
     FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, width=1700, VVJA7R=26, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVMXk9=True, VVqPV4=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVBBM8=bg, VVa80e=bg, VVaOdk=bg, VVXZ9d="#00ffff55", VVlVSy="#00003040")
  if not VVX2QD:
   FFKCVv(self, "Nothing to upgrade", 1500)
   if VVgl66: VVgl66.cancel()
 def VVON2H(self, VVgl66, title, txt, colList):
  pkg = colList[1]
  cmd = FFcDAv(VV58Rq, pkg)
  if cmd : FFyAzl(self, cmd, title="Installing : %s" % pkg, VV5SfP=BF(self.VVxgOR, VVgl66))
  else : FFjIcG(SELF)
 def VV7eRD(self):
  pkg = FF9djL()
  aptT = "apt - Advanced Package Tool" if FFwmhG("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FF5kkM(self, txt or "No packaging tools found!")
 def VVJkJ2(self, mode, grep, VVgl66=None, title=""):
  if   mode == 0: cmd = FFYO4M(VVSJRW    , grep)
  elif mode == 1: cmd = FFYO4M(VVC4fX , grep)
  elif mode == 2: cmd = FFYO4M(VVC4fX , grep)
  if not cmd:
   FFjIcG(self)
   return
  VVX2QD = FFIeeK(cmd)
  if VVX2QD:
   err = CCxFIK.VVjWm9(VVX2QD, fromFind=False)
   if err:
    FF2zEl(self, err)
    return
  else:
   if VVgl66: VVgl66.VV3asq()
   FF2zEl(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVX3UR  = []
  for item in VVX2QD:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVX3UR.append((name, package, version))
  if mode > 0:
   extensions = FFIeeK("ls %s -l | grep '^d' | awk '{print $9}'" % VV3ket)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVX3UR:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVpToT: name += "el"
      VVX3UR.append((name, VV3ket + item, "-"))
   systemPlugins = FFIeeK("ls %s -l | grep '^d' | awk '{print $9}'" % VV35QH)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVX3UR:
      if item.lower() == row[0].lower():
       break
     else:
      VVX3UR.append((item, VV35QH + item, "-"))
  if not VVX3UR:
   FF2zEl(self, "No packages found!")
   return
  if VVgl66:
   VVX3UR.sort(key=lambda x: x[0].lower())
   VVgl66.VVrEsw(VVX3UR, title)
  else:
   widths = (20, 50, 30)
   VV6LI6 = None
   VVmhJa = None
   if mode == 0:
    VVTaaj = ("Install" , self.VV6p6D   , [])
    VV6LI6 = ("Download" , self.VVxsfm   , [])
    VVmhJa = ("Filter"  , self.VVZR5o , [])
   elif mode == 1:
    VVTaaj = ("Uninstall", self.VV74GP, [])
   elif mode == 2:
    VVTaaj = ("Uninstall", self.VV74GP, [])
    widths= (18, 57, 25)
   VVX3UR.sort(key=lambda x: x[0].lower())
   VVH4Z8 = ("Package Info.", self.VVd5u6, [])
   header   = ("Name" ,"Package" , "Version" )
   FFyrIU(self, None, header=header, VVX3UR=VVX3UR, VVBL0l=widths, VVJA7R=28, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVhwQH=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVBBM8="#22110011", VVa80e="#22191111", VVaOdk="#22191111", VVlVSy="#00003030", VV3FyM="#00333333")
 def VVd5u6(self, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVsJRq, VVgl66, colList[1]))
 def VVsJRq(self, VVgl66, pkg):
  if pathExists(pkg):
   pkg, err = CC3nMC.VVwbHP(pkg)
   if err:
    FFKCVv(VVgl66, err, 1000)
    return
  CC3nMC.VV1q0o(self, pkg)
 def VVZR5o(self, VVgl66, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVgsyy = []
  VVgsyy.append(("All Packages", "all"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVgsyy.append(VVzHzv)
  for word in words:
   VVgsyy.append((word, word))
  FFCO3u(self, BF(self.VVSae7, VVgl66), VVgsyy=VVgsyy, title="Select Filter")
 def VVSae7(self, VVgl66, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF3LD6(VVgl66, BF(self.VVJkJ2, 0, grep, VVgl66, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VV74GP(self, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VV4UYs, VVgl66, colList[1]))
 def VV4UYs(self, VVgl66, package):
  if pathExists(package):
   pkg, err = CC3nMC.VVwbHP(package)
   if pkg:
    package = pkg
  if package.startswith((VV3ket, VV35QH)):
   FFZnVu(self, BF(self.VVv0qx, VVgl66, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVgsyy = []
   VVgsyy.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVgsyy.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVgsyy.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFCO3u(self, BF(self.VVIAan, VVgl66, package), VVgsyy=VVgsyy)
 def VVv0qx(self, VVgl66, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VVso67)
  FFyAzl(self, cmd, VV5SfP=BF(self.VVk6ww, VVgl66))
 def VVIAan(self, VVgl66, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV4aqy
   elif item == "remove_ForceRemove"  : cmdOpt = VV50Yb
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVUGjK
   FFZnVu(self, BF(self.VVTRPY, VVgl66, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVTRPY(self, VVgl66, package, cmdOpt):
  self.lastSelectedRow = VVgl66.VVKltF()
  cmd = FFcDAv(cmdOpt, package)
  if cmd : FFyAzl(self, cmd, VV5SfP=BF(self.VVk6ww, VVgl66))
  else : FFjIcG(self)
 def VVk6ww(self, VVgl66):
  VVgl66.cancel()
  FFSoy0()
 def VV6p6D(self, VVgl66, title, txt, colList):
  package  = colList[1]
  VVgsyy = []
  VVgsyy.append(("Install Package"        , "install_CheckVersion" ))
  VVgsyy.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVgsyy.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVgsyy.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVgsyy.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFCO3u(self, BF(self.VV3kFt, package), VVgsyy=VVgsyy)
 def VV3kFt(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VV58Rq
   elif item == "install_ForceReinstall" : cmdOpt = VVG7vb
   elif item == "install_ForceOverwrite" : cmdOpt = VVexTQ
   elif item == "install_ForceDowngrade" : cmdOpt = VVwHSw
   elif item == "install_IgnoreDepends" : cmdOpt = VVuIYv
   FFZnVu(self, BF(self.VVw3Jg, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVw3Jg(self, package, cmdOpt):
  cmd = FFcDAv(cmdOpt, package)
  if cmd : FFyAzl(self, cmd, VV5SfP=FFSoy0, checkNetAccess=True)
  else : FFjIcG(self)
 def VVxsfm(self, VVgl66, title, txt, colList):
  package  = colList[1]
  FFZnVu(self, BF(self.VViRT5, package), "Download Package ?\n\n%s" % package)
 def VViRT5(self, package):
  if CCQZYn.VVY3BC():
   cmd = FFcDAv(VVHjiX, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFmPm4(success, VVd7n9))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFmPm4(fail, VVHEBa))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFyAzl(self, cmd, VVpjHk=[VVHEBa, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFjIcG(self)
  else:
   FF2zEl(self, "No internet connection !")
 @staticmethod
 def VV2d5a(SELF):
  cmd = FFYO4M(VV0BJl, "")
  if cmd : FFyAzl(SELF, cmd, checkNetAccess=True)
  else : FFjIcG(SELF)
 @staticmethod
 def VVwbHP(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFIeeK(FFcDAv(VVEPaI, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VV1q0o(SELF, package, title=""):
  title = title or package
  infoCmd  = FFcDAv(VVpgtv, package)
  filesCmd = FFcDAv(VVRD1w, package)
  listInstCmd = FFYO4M(VVC4fX, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFHble(VVMdMA)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFmPm4(notInst, VVL6GV))
   cmd += "else "
   cmd +=   FFouUN("System Info", VVMdMA)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFouUN("Related Files", VVMdMA)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFy48B(SELF, cmd, title=title)
  else:
   FFjIcG(SELF, title=title)
class CCzIkW():
 def VVv8I1(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVoYlq()
 def VVoYlq(self):
  files = FFPCH3(VVn5zG, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVgsyy = []
   for fil in files:
    VVgsyy.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVBBM8, VVa80e = "#22221133", "#22221133"
   else    : VVBBM8, VVa80e = "#22003344", "#22002233"
   VV2u6t  = ("Add new File", self.VVQsmU)
   FFCO3u(self, self.VV9tem, VVgsyy=VVgsyy, width=1100, VV2u6t=VV2u6t, VVGamv="", minRows=4, VVBBM8=VVBBM8, VVa80e=VVa80e)
  else:
   FFZnVu(self, self.VVkKoE, "No files found.\n\nCreate a new file ?")
 def VVkKoE(self):
  path = self.VVQhfc()
  if fileExists(path) : self.VVoYlq()
  else    : FFRB11(self, "Cannot create file", 1500)
 def VVQsmU(self, VVyxPv, path):
  path = self.VVQhfc()
  VVyxPv.VVbEsC((os.path.basename(path), path), isSort=True)
 def VVQhfc(self):
  path = "%s%s%s.xml" % (VVn5zG, self.shareFilePrefix, FFvXEJ())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VV9tem(self, path=None):
  if path:
   FF3LD6(self, BF(self.VVUgdV, path))
 def VVUgdV(self, path):
  if not fileExists(path):
   FFdxlA(self, path)
   return
  elif not CCxFIK.VVeJOe(self, path, FF3Vxe()):
   return
  else:
   self.shareFilePath = path
  if not CC5i9A.VVvyUl(self):
   return
  tree = CCuZg4.VVbwHw(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCqHUu.VVQW9t()
  def VVBMvF(refCode):
   if   FFdpOF(refCode): return FFivHt("DVB", VVL7a3)
   elif refCode in refLst     : return FFivHt("IPTV", VVL7a3)
   else         : return ""
  VVX2QD= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVXWCJ(ch)
   if ok:
    srcTxt = VVBMvF(srcRef)
    dstTxt = VVBMvF(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVX2QD:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVX2QD.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVX2QD:
   if self.shareIsRef : VVBBM8, VVa80e, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVBBM8, VVa80e, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VV1Zg1 = (""    , BF(self.VV0I0G, dupl), [])
   VVPn7Q = (""    , self.VVKu0F    , [])
   VVTaaj = ("Delete Entry" , self.VVw1SC   , [])
   VV6LI6 = ("Add Entry"  , self.VVjuH0   , [])
   VVH4Z8 = (optTxt   , self.VVKTHD  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VV8zKo = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVgl66 = FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=24, VV1Zg1=VV1Zg1, VVPn7Q=VVPn7Q, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVMXk9=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVa80e, VVlVSy="#0a000000")
  else:
   FF2zEl(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VV0I0G(self, dupl, VVgl66, title, txt, colList):
  if dupl:
   VVgl66.VVD950("Skipped %d duplicate%s" % (dupl, FFZevi(dupl)), 2000)
 def VVKu0F(self, VVgl66, title, txt, colList):
  def VVBMvF(key, val): return "%s\t: %s\n" % (key, val or FFivHt("?", VVgmAg))
  Keys = VVgl66.VVCwRO()
  Vals = VVgl66.VVErbL()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVBMvF(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVd7n9, VVgmAg
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFucjH(self, txt + txt1, title=title)
 def VVXWCJ(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVw1SC(self, VVgl66, title, txt, colList):
  if VVgl66.VVKltF() == 0 and VVgl66.VVpibS() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFZnVu(self, BF(self.VVGwfb, isLast, VVgl66), ques)
 def VVGwfb(self, isLast, VVgl66):
  if isLast:
   FFAFdq(self.shareFilePath)
   VVgl66.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVgl66.VVErbL()
   if self.VVMebF(srcName, srcRef, dstName, dstRef):
    VVgl66.VVaBD0()
    VVgl66.VV0LFL()
    FFRB11(VVgl66, "Deleted", 500, isGrn=True)
   else:
    FFRB11(VVgl66, "Cannot delete from file", 2000)
 def VVjuH0(self, VVgl66, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVbQJ3(VVgl66, isDvb=True)
  else    : self.VV2VJR(VVgl66, "Source Channel", "#22003344", "#22002233")
 def VV2VJR(self, mainTableInst, title, VVBBM8, VVa80e):
  FFCO3u(self, BF(self.VVhkBk, mainTableInst, title), VVgsyy=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVBBM8=VVBBM8, VVa80e=VVa80e)
 def VVhkBk(self, mainTableInst, title, item=None):
  if item:
   FF3LD6(mainTableInst, BF(self.VVCIkI, mainTableInst, title, item), clearMsg=False)
 def VVCIkI(self, mainTableInst, title, item):
  FFRB11(mainTableInst)
  if item == "DVB": self.VVbQJ3(mainTableInst, isDvb=True)
  else   : self.VVbQJ3(mainTableInst, isDvb=False)
 def VVsFCL(self, mainTableInst, chType, VVgl66, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVgl66.VVKltF()
  if   chType == "DVB" : FFH7ga(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFH7ga(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VV3eCu()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FF2zEl(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVRekY(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVoBKf((str(mainTableInst.VVpibS() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFRB11(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFRB11(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFRB11(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVbQJ3(mainTableInst, isDvb=False)
   else    : FFnB9O(BF(self.VV2VJR, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVgl66.cancel()
 def VVwVgr(self, item, VVgl66, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVgl66.VVICdA(ndx)
 def VVbQJ3(self, VVgl66, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVsFCL, VVgl66, typ)
  doneFnc = BF(self.VVwVgr, typ)
  if isDvb: CCzIkW.VVkhok(VVgl66 , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCzIkW.VV2yDr(VVgl66, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVkhok(SELF, title, okFnc, doneFnc=None):
  FF3LD6(SELF, BF(CCzIkW.VVAlUs, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVAlUs(SELF, title, okFnc, doneFnc=None):
  VVX2QD, err = CCuZg4.VVyoTY(SELF, CCuZg4.VVD8kg)
  if VVX2QD:
   color = "#0a000022"
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVkkpG = ("Select" , okFnc, [])
   VV1Zg1= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VV8zKo = (LEFT  , LEFT  , CENTER, LEFT    )
   FFyrIU(SELF, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVBBM8=color, VVa80e=color, VVaOdk=color, VVkkpG=VVkkpG, VV1Zg1=VV1Zg1, lastFindConfigObj=CFG.lastFindServices)
  else:
   FF2zEl(SELF, "No DVB Services !")
 @staticmethod
 def VV2yDr(SELF, title, okFnc, doneFnc=None):
  FF3LD6(SELF, BF(CCzIkW.VVPAif, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVPAif(SELF, title, okFnc, doneFnc=None):
  VVX2QD = CCzIkW.VVK2Ht()
  if VVX2QD:
   color = "#0a112211"
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVkkpG = ("Select" , okFnc, [])
   VV1Zg1= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFyrIU(SELF, None, title=title, header=header, VVX3UR=VVX2QD, VVBL0l=widths, VVJA7R=26, VVBBM8=color, VVa80e=color, VVaOdk=color, VVkkpG=VVkkpG, VV1Zg1=VV1Zg1, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF2zEl(SELF, "No IPTV Services !")
 @staticmethod
 def VVK2Ht():
  VVX2QD = []
  files  = CCA7uK.VVILbD()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFU2DB(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVaDL0 = span.group(1)
    else : VVaDL0 = ""
    VVaDL0_lCase = VVaDL0.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVX2QD.append((chName, VVaDL0, url, refCode))
  return VVX2QD
 def VVRekY(self, srcName, srcRef, dstName, dstRef):
  tree = CCuZg4.VVbwHw(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVnwJw(tree, root)
  return True
 def VVMebF(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCuZg4.VVbwHw(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVXWCJ(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVnwJw(tree, root)
  return found
 def VVnwJw(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCuZg4.VVQwfY(xmlTxt)
  parser = CCuZg4.CC2N34()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVKTHD(self, VVgl66, title, txt, colList):
  if self.onlyEpg:
   self.VVlGpZ(VVgl66, "epg")
  else:
   if self.shareIsRef:
    FFZnVu(self, BF(FF3LD6, VVgl66, BF(self.VVNnSr, VVgl66)), "Copy all References from Source to Destination ?")
   else:
    VVgsyy = []
    VVgsyy.append(("Copy EPG\t (All List)" , "epg"  ))
    VVgsyy.append(("Copy Picons\t (All List)" , "picon" ))
    FFCO3u(self, BF(self.VVlGpZ, VVgl66), VVgsyy=VVgsyy, width=1000)
 def VVlGpZ(self, VVgl66, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVObvn  , "EPG"
   elif item == "picon": fnc, txt = self.VVVOlq , "PIcons"
   title = "Copy %s" % txt
   tot   = VVgl66.VVpibS()
   FFZnVu(self, BF(FF3LD6, VVgl66, BF(fnc, VVgl66, title)), "Overwrite %s for %d Service%s ?" % (FFivHt(txt, VVMdMA), tot, FFZevi(tot)), title=title)
 def VVNnSr(self, VVgl66):
  files = CCA7uK.VVILbD()
  totChange = 0
  if files:
   for path in files:
    txt = FFU2DB(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVgl66.VV3eCu():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFjhC8()
  tot = VVgl66.VVpibS()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFucjH(self, txt)
 def VVVOlq(self, VVgl66, title):
  if not iCopyfile:
   FF2zEl(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CC0NDf.VVqbLc()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVgl66.VV3eCu():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVgl66.VVpibS()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFucjH(self, txt, title=title)
 def VVObvn(self, VVgl66, title):
  txt, err = CCje5B.VVFchT(VVgl66, title)
  if err : FF2zEl(self, err, title=title)
  else : FFucjH(self, txt, title=title)
 class CC2N34(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVbwHw(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCuZg4.CC2N34())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFivHt("XML Parse Error in:", VVgmAg), path)
   txt += "%s\n%s\n\n" % (FFivHt("Error:", VVgmAg), str(e))
   FFucjH(SELF, txt, VVaOdk="#11220000", title=title)
   return None
 @staticmethod
 def VVQwfY(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCje5B(Screen, CCzIkW):
 VV1VPJ  = "BDTSE"
 VVLCxa   = "save"
 VVpk5y   = "load"
 VVGTwn  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCje5B.VVAssH()
  qUrl, iptvRef = CCA7uK.VV2C8j(self)
  VVgsyy = []
  VVgsyy.append((VVL7a3 + "Cache File Info." , "inf"))
  VVgsyy.append(VVzHzv)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVgsyy.append(FFDNao("Save EPG to File%s" % fTxt , self.VVLCxa, valid))
  VVgsyy.append(FFDNao("Load EPG from File%s" % fTxt , self.VVpk5y, valid))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((VVL6GV + "Delete EPG (from RAM only)", self.VVGTwn))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(FFDNao("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVgsyy.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Translate Current Channel EPG %s(Experimental)" % VVL6GV, "VVbsCN"))
  FFNG7m(self, VVgsyy=VVgsyy)
  self.onShown.append(self.VVBp8x)
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVtdfc()
   elif item in (self.VVLCxa, self.VVpk5y, self.VVGTwn):
    reset = item == self.VVpk5y
    FFZnVu(self, BF(FF3LD6, self, BF(self.VVmn9h, item, reset)), VVWZXE="Continue ?")
   elif item == "refreshIptvEPG"  : CCA7uK.VVH3cl(self)
   elif item == "VVbsCN" : self.VVbsCN()
   elif item == "copyEpg"    : self.VVv8I1(False, onlyEpg=True)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VVmn9h(self, act, reset=False):
  ok = CCje5B.VVlw7J(act)
  if ok:
   if reset:
    CCje5B.VVPYQH(self)
   FF5kkM(self, "Done")
  else:
   FF5kkM(self, "Failed!")
 def VVtdfc(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCje5B.VVAssH()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFivHt("File not found (check System EPG settings).", VVL6GV))
   FFucjH(self, txt, title=title)
  else:
   FF2zEl(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVoF5V():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVbsCN(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVkkpG  = (""  , BF(self.VVQd0H, title, True) , [])
  VV6LI6 = ("Start" , BF(self.VVQd0H, title, False), [])
  VVmhJa = ("Change Language", self.VVmKZq      , [])
  widths  = (70 , 30)
  VV8zKo = (LEFT , CENTER)
  FFyrIU(self, None, title=title, VVX3UR=self.VVAOFm(), VV8zKo=VV8zKo, VVBL0l=widths, width=1200, vMargin=20, VVJA7R=30, VVkkpG=VVkkpG, VV6LI6=VV6LI6, VVmhJa=VVmhJa, VVREBJ=2
    , VVBBM8="#11201010", VVa80e=bg, VVaOdk=bg, VVlVSy="#00004455", VV3FyM=bg)
 def VVAOFm(self):
  Def, ch = "DISABLED", dict(CCje5B.VVoF5V())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVX3UR = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVX3UR
 def VVmKZq(self, VVgl66, title, txt, colList):
  ndx = VVgl66.VVKltF()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCYiJJ.VV0Bay(self, confItem, title, lst=CCje5B.VVoF5V(), cbFnc=BF(self.VVsSSq, VVgl66), isSave=True)
 def VVsSSq(self, VVgl66):
  for ndx, row in enumerate(self.VVAOFm()):
   VVgl66.VV13vu(ndx, row)
 def VVQd0H(self, Title, isAsk, VVgl66, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFRB11(VVgl66, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
   refCode, evList, err = CCje5B.VVziwn(refCode)
   fnc = BF(self.VVFIRv, Title, refCode, evList, VVgl66)
   if   err : FF2zEl(self, err, title=Title)
   elif isAsk : FFZnVu(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVFIRv(self, title, refCode, evList, VVgl66):
  self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV4vWy, evList)
      , VVRlGe = BF(self.VVWDPK, title, refCode))
  VVgl66.cancel()
 def VV4vWy(self, evList, VVxeRf):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVxeRf.VVPZSN(totEv)
  VVxeRf.VVxy84 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCje5B.VVUN8o(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVnoYr(1)
   VVxeRf.VVgQXn(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVxeRf.VVxy84 = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVWDPK(self, title, refCode, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVxy84
  if newLst: totEv, totOK = CCje5B.VVPx5z(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCje5B.VV2HnN()
   CCje5B.VVPYQH(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFucjH(self, txt, title=title)
 @staticmethod
 def VVUN8o(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVBMvF(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCje5B.VVcWGv(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVBMvF, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVcWGv(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FF4f8i(txt))
   txt, err = CCA7uK.VVkQUQ(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFBuNh(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCje5B.VV4SJi(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVAssH():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFQfFR(path)
   szTxt = CCxFIK.VVe4Bo(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVImsZ():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VV2HnN(): CCje5B.VVlw7J(CCje5B.VVLCxa)
 @staticmethod
 def VVlw7J(act):
  ec, inst = CCje5B.VVImsZ()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVPYQH(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVziwn(refCode):
  ec, inst = CCje5B.VVImsZ()
  if inst:
   try:
    evList = inst.lookupEvent([CCje5B.VV1VPJ, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVPx5z(refCode, events, longDescDays=0):
  ec, inst = CCje5B.VVImsZ()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVlvmR(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCje5B.VVImsZ()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCje5B.VV4iYj(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCTzTd.CCje5B(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VV4iYj(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCje5B.VVC308(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVAM04(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCje5B.VVImsZ()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCje5B.VV4iYj(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFwVZA(evTime)
       evEndTxt  = FFwVZA(evEnd)
       evDurTxt  = FFz41A(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFz41A(evPos)
        evRem = evEnd - now
        evRemTxt = FFz41A(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFz41A(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVC308(event):
  genre = PR = ""
  try:
   genre  = CCje5B.VVmYcn(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCje5B.VVfcPb(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVfcPb(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVmYcn(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCje5B.VVjzcM()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVjzcM():
  path = VVV9bl + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFU2DB(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFU2DB(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVFchT(VVgl66, title):
  ec, inst = CCje5B.VVImsZ()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVgl66.VV3eCu():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCje5B.VV1VPJ, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCje5B.VVPx5z(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCje5B.VV2HnN()
  txt  = "Services\t: %d\n"  % VVgl66.VVpibS()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVL5J4(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCje5B.VVkwGi(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCje5B.VVkwGi(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCje5B.VVkwGi(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVkwGi(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCje5B.VV4iYj(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCje5B.VVUN8o(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFivHt(evName, VVhb13)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFivHt(evNameTransl, VVhb13))
    if evTime           : txt += "Start Time\t: %s\n" % FFwVZA(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFwVZA(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFz41A(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFz41A(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFz41A(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFivHt(evShort, VVVJaM)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFivHt(evDesc , VVVJaM)
    if txt:
     txt = FFivHt("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVhb13) + txt
  return txt
 @staticmethod
 def VV4SJi(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCuZg4(Screen, CCzIkW):
 VVeoIH  = 0
 VVUmmS = 1
 VV5oj8  = 2
 VVBzaU  = 3
 VV0WE9 = 4
 VVdPAS = 5
 VVdZaP = 6
 VVD8kg   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VViv3e = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVgsyy = self.VV3Ysf()
  FFNG7m(self, VVgsyy=VVgsyy, title="Services/Channels")
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self["myMenu"].setList(self.VV3Ysf())
  FFyZo3(self["myMenu"])
  FFhtaK(self)
 def VV3Ysf(self):
  VVgsyy = []
  c = VVL7a3
  VVgsyy.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVgsyy.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVgsyy.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVgsyy.append(VVzHzv)
  c = VVhb13
  VVgsyy.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVgsyy.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVgsyy.append((VVgmAg + "More tables ..."     , "VV8tts"    ))
  c = VVVJaM
  VVgsyy.append(VVzHzv)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVgsyy.append((c + txt          , "VVMFNY"  ))
  else : VVgsyy.append((txt           ,          ))
  VVgsyy.append((c + 'Export Services to "channels.xml"'    , "VVfUIy"      ))
  VVgsyy.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVAQIK
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVgsyy.append((c + "Invalid Services Cleaner"       , "VV4RZN"    ))
  c = VVAQIK
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c + "Delete Channels with no names"     , "VVRyyG"    ))
  VVgsyy.append((c + "Delete Empty Bouquets"       , "VVKGSd"     ))
  VVgsyy.append(VVzHzv)
  VViNJC, VVLDFX = CCuZg4.VVUxBE()
  if fileExists(VViNJC):
   enab = fileExists(VVLDFX)
   if enab: VVgsyy.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVgsyy.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVgsyy.append(("Reset Parental Control Settings"      , "VV7PmC"    ))
  VVgsyy.append(("Reload Channels and Bouquets"       , "VVUfoc"      ))
  return VVgsyy
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCC5bX.VVBgB6(self.session)
   elif item == "openSignal"       : FFTXqQ(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFBxYU(self, fncMode=CCTzTd.VVfwSM)
   elif item == "lameDB_allChannels_with_refCode"  : FF3LD6(self, self.VVdEI0)
   elif item == "lameDB_allChannels_with_tranaponder" : FF3LD6(self, self.VVXan0)
   elif item == "VV8tts"     : self.VV8tts()
   elif item == "VVMFNY"  : CCMQGS.VVMFNY(self)
   elif item == "VVfUIy"      : self.VVfUIy()
   elif item == "copyEpgPicons"      : self.VVv8I1(False)
   elif item == "SatellitesCleaner"     : FF3LD6(self, self.FF3LD6_SatellitesCleaner)
   elif item == "VV4RZN"    : FF3LD6(self, BF(self.VV4RZN))
   elif item == "VVRyyG"    : FF3LD6(self, self.VVRyyG)
   elif item == "VVKGSd"     : self.VVKGSd(self)
   elif item == "enableHiddenChannels"     : self.VVuKb8(True)
   elif item == "disableHiddenChannels"    : self.VVuKb8(False)
   elif item == "VV7PmC"    : FFZnVu(self, self.VV7PmC, "Reset and Restart ?")
   elif item == "VVUfoc"      : FF3LD6(self, BF(CCuZg4.VVUfoc, self))
 def VV8tts(self):
  VVgsyy = []
  VVgsyy.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVgsyy.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVgsyy.append(("Services with PIcons for the System"  , "VVQynG"    ))
  VVgsyy.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVgsyy.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFCO3u(self, self.VVQy4B, VVgsyy=VVgsyy, title="Service Information", VVf67P=True)
 def VVQy4B(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FF3LD6(self, BF(self.VVkoG7, title))
   elif ref == "parentalControlChannels"   : FF3LD6(self, BF(self.VVI3pg, title))
   elif ref == "showHiddenChannels"    : FF3LD6(self, BF(self.VVOGxw, title))
   elif ref == "VVQynG"    : FF3LD6(self, BF(self.VVqzPb, title))
   elif ref == "servicesWithMissingPIcons"   : FF3LD6(self, BF(self.VVXrIQ, title))
   elif ref == "TranspondersStats"     : FF3LD6(self, BF(self.VV5Hdq, title))
   elif ref == "SatellitesXmlStats"    : FF3LD6(self, BF(self.VVvoGe, title))
 def VVfUIy(self):
  VVgsyy = []
  VVgsyy.append(("All DVB-S/C/T Services", "all"))
  VVgsyy.extend(CCqHUu.VVuaO0())
  FFCO3u(self, self.VVV2zT, VVgsyy=VVgsyy, title="", VVf67P=True)
 def VVV2zT(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCuZg4.VVJnoc("1:7:")
   else   : lst = FFlVIk(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FF5v7R(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFTEln(r)  : sat = "Stream Relay"
       elif FFH7Or(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFZsCH(CFG.exportedTablesPath.getValue()), FFvXEJ())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF5kkM(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFRB11(self, "No Services found !", 1500)
 @staticmethod
 def VVUfoc(SELF):
  FFjhC8()
  FF5kkM(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVdEI0(self):
  self.VViv3e = None
  self.lastfilterUsed  = None
  self.filterObj   = CCBykx(self)
  VVX2QD, err = CCuZg4.VVyoTY(self, self.VVeoIH)
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVkkpG  = ("Zap"   , self.VVaZQW     , [])
   VVPn7Q = (""    , self.VVaj8e   , [])
   VVH4Z8 = ("Options"  , self.VVBimz , [])
   VV6LI6 = ("Current Service", self.VVjyLx , [])
   VVmhJa = ("Filter"   , self.VV6XpK  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV8zKo  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindServices)
 def VVXan0(self):
  self.VViv3e = None
  self.lastfilterUsed  = None
  self.filterObj   = CCBykx(self)
  VVX2QD, err = CCuZg4.VVyoTY(self, self.VVUmmS)
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVkkpG  = ("Zap"   , self.VVaZQW      , [])
   VVPn7Q = (""    , self.VVaj8e    , [])
   VV6LI6 = ("Current Service", self.VVjyLx  , [])
   VVH4Z8 = ("Options"  , self.VVLOYE , [])
   VVmhJa = ("Filter"   , self.VVRnSX  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV8zKo  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindServices)
 def VVBimz(self, VVgl66, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCXfgt(self, VVgl66)
  VVgsyy = []
  isMulti = VVgl66.VVIa5A
  if isMulti:
   refCodeList = VVgl66.VVCkXr(3)
   if refCodeList:
    VVgsyy.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVgsyy.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVgsyy.append(VVzHzv)
    VVgsyy.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVgsyy.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVgsyy.append(VVzHzv)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVgsyy.append((txt1, "parentalControl_add" ))
    VVgsyy.append((txt2,        ))
   else:
    VVgsyy.append((txt1,       ))
    VVgsyy.append((txt2, "parentalControl_remove" ))
   VVgsyy.append(VVzHzv)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVgsyy.append((txt1, "hiddenServices_add"  ))
    VVgsyy.append((txt2,       ))
   else:
    VVgsyy.append((txt1,        ))
    VVgsyy.append((txt2, "hiddenServices_remove" ))
   VVgsyy.append(VVzHzv)
  cbFncDict = { "parentalControl_add"   : BF(self.VVcLs6, VVgl66, refCode, True)
     , "parentalControl_remove"  : BF(self.VVcLs6, VVgl66, refCode, False)
     , "hiddenServices_add"   : BF(self.VVRQJr, VVgl66, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVRQJr, VVgl66, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVIL84, VVgl66, True)
     , "parentalControl_sel_remove" : BF(self.VVIL84, VVgl66, False)
     , "hiddenServices_sel_add"  : BF(self.VVQ1ip, VVgl66, True)
     , "hiddenServices_sel_remove" : BF(self.VVQ1ip, VVgl66, False)
     }
  VVgsyy1, cbFncDict1 = CCuZg4.VV9uI5(self, VVgl66, servName, 3)
  VVgsyy.extend(VVgsyy1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVnFMb(VVgsyy, cbFncDict)
 def VVLOYE(self, VVgl66, title, txt, colList):
  servName = colList[0]
  mSel = CCXfgt(self, VVgl66)
  VVgsyy, cbFncDict = CCuZg4.VV9uI5(self, VVgl66, servName, 3)
  mSel.VVnFMb(VVgsyy, cbFncDict)
 @staticmethod
 def VV9uI5(SELF, VVgl66, servName, refCodeCol):
  tot = VVgl66.VVGnLM()
  if tot > 0:
   sTxt = FFivHt("%d Service%s" % (tot, FFZevi(tot)), VVhb13)
   VVgsyy = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFkgYM(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFivHt(servName, VVhb13)
   VVgsyy = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCuZg4.VVUKP9, SELF, VVgl66, refCodeCol, True)
     , "addToBouquet_one" : BF(CCuZg4.VVUKP9, SELF, VVgl66, refCodeCol, False)
     }
  return VVgsyy, cbFncDict
 @staticmethod
 def VVUKP9(SELF, VVgl66, refCodeCol, isMulti):
  picker = CCqHUu(SELF, VVgl66, "Add to Bouquet", BF(CCuZg4.VVtJWL, VVgl66, refCodeCol, isMulti))
 @staticmethod
 def VVtJWL(VVgl66, refCodeCol, isMulti):
  if isMulti : refCodeList = VVgl66.VVCkXr(refCodeCol)
  else  : refCodeList = [VVgl66.VVErbL()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVcLs6(self, VVgl66, refCode, isAddToBlackList):
  VVgl66.VVPBVj("Processing ...")
  FFnB9O(BF(self.VVQHn2, VVgl66, [refCode], isAddToBlackList))
 def VVIL84(self, VVgl66, isAddToBlackList):
  refCodeList = VVgl66.VVCkXr(3)
  if not refCodeList:
   FF2zEl(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVgl66.VVPBVj("Processing ...")
  FFnB9O(BF(self.VVQHn2, VVgl66, refCodeList, isAddToBlackList))
 def VVQHn2(self, VVgl66, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVXFf1, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVXFf1):
   lines = FFHq6Y(VVXFf1)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVXFf1, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVgl66.VVIa5A
   if isMulti:
    self.VV0S82(VVgl66, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV2WAB(VVgl66, refCode)
    VVgl66.VV3asq()
  else:
   VVgl66.VVD950("No changes")
 def VVRQJr(self, VVgl66, refCode, isHide):
  title = "Change Hidden State"
  if FFdpOF(refCode):
   VVgl66.VVPBVj("Processing ...")
   ret = FFMjJK(refCode, isHide)
   if ret : FF3LD6(self, BF(self.VV2WAB, VVgl66, refCode))
   else : FF2zEl(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF2zEl(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV2WAB(self, VVgl66, refCode):
  VVX2QD, err = CCuZg4.VVyoTY(self, self.VVeoIH, VVXiZB=[3, [refCode], False])
  done = False
  if VVX2QD:
   data = VVX2QD[0]
   if data[3] == refCode:
    done = VVgl66.VVhT9b(data)
  if not done:
   self.VVAohx(VVgl66, VVgl66.VVBJII(), self.VVeoIH)
  VVgl66.VV3asq()
 def VV0S82(self, VVgl66, totRefCodes):
  VVX2QD, err = CCuZg4.VVyoTY(self, self.VVeoIH, VVXiZB=self.VViv3e)
  VVgl66.VVrEsw(VVX2QD)
  VVgl66.VVVdMt(False)
  VVgl66.VVD950("%d Processed" % totRefCodes)
 def VVQ1ip(self, VVgl66, isHide):
  refCodeList = VVgl66.VVCkXr(3)
  if not refCodeList:
   FF2zEl(self, "Nothing selected", title="Change Hidden State")
   return
  VVgl66.VVPBVj("Processing ...")
  FFnB9O(BF(self.VVCHzi, VVgl66, refCodeList, isHide))
 def VVCHzi(self, VVgl66, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFMjJK(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFjhC8(True)
   self.VV0S82(VVgl66, len(refCodeList))
  else:
   VVgl66.VVD950("No changes")
 def VV6XpK(self, VVgl66, title, txt, colList):
  inFilterFnc = BF(self.VV3ZL5, VVgl66) if self.VViv3e else None
  self.filterObj.VVQ9Ad(1, VVgl66, 2, BF(self.VV6VVc, VVgl66), inFilterFnc=inFilterFnc)
 def VV6VVc(self, VVgl66, item):
  self.VVAcb8(VVgl66, False, item, 2, self.VVeoIH)
 def VV3ZL5(self, VVgl66, VVyxPv, item):
  self.VVAcb8(VVgl66, True, item, 2, self.VVeoIH)
 def VVRnSX(self, VVgl66, title, txt, colList):
  inFilterFnc = BF(self.VVgAXM, VVgl66) if self.VViv3e else None
  self.filterObj.VVQ9Ad(2, VVgl66, 4, BF(self.VVXoW4, VVgl66), inFilterFnc=inFilterFnc)
 def VVXoW4(self, VVgl66, item):
  self.VVAcb8(VVgl66, False, item, 4, self.VVUmmS)
 def VVgAXM(self, VVgl66, VVyxPv, item):
  self.VVAcb8(VVgl66, True, item, 4, self.VVUmmS)
 def VVXrSb(self, VVgl66, title, txt, colList):
  inFilterFnc = BF(self.VVtFEM, VVgl66) if self.VViv3e else None
  self.filterObj.VVQ9Ad(0, VVgl66, 4, BF(self.VV5uoK, VVgl66), inFilterFnc=inFilterFnc)
 def VV5uoK(self, VVgl66, item):
  self.VVAcb8(VVgl66, False, item, 4, self.VV5oj8)
 def VVtFEM(self, VVgl66, VVyxPv, item):
  self.VVAcb8(VVgl66, True, item, 4, self.VV5oj8)
 def VVAcb8(self, VVgl66, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVgl66.VVJJCV(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VViv3e = None
  else:
   words, asPrefix = CCBykx.VVVM3i(words)
   self.VViv3e = [col, words, asPrefix]
  if words: FF3LD6(VVgl66, BF(self.VVAohx, VVgl66, title, mode), clearMsg=False)
  else : FFRB11(VVgl66, "Incorrect filter", 2000)
 def VVAohx(self, VVgl66, title, mode):
  VVX2QD, err = CCuZg4.VVyoTY(self, mode, VVXiZB=self.VViv3e, VVCuKF=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVgl66.VV3eCu():
    try:
     ndx = VVX2QD.index(tuple(list(map(str.strip, row))))
     lst.append(VVX2QD[ndx])
    except:
     pass
   VVX2QD = lst
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVgl66.VVrEsw(VVX2QD, title, VVYHEIMsg=True)
  else:
   FFRB11(VVgl66, "Not found!", 1500)
 def VVQZvW(self, title, VVX3UR, VVkkpG=None, VVPn7Q=None, VVTaaj=None, VV6LI6=None, VVH4Z8=None, VVmhJa=None):
  VV6LI6 = ("Current Service", self.VVjyLx, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV8zKo = (LEFT  , LEFT  , CENTER, LEFT    )
  FFyrIU(self, None, title=title, header=header, VVX3UR=VVX3UR, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindServices)
 def VVjyLx(self, VVgl66, title, txt, colList):
  self.VVXGdD(VVgl66)
 def VVQZ9L(self, VVgl66, title, txt, colList):
  self.VVXGdD(VVgl66, True)
 def VVXGdD(self, VVgl66, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVgl66.VVWYsy(colDict, VVnkcm=True)
   else:
    VVgl66.VVrpKV(3, refCode, True)
   return
  FF2zEl(self, "Cannot read current Reference Code !")
 def VVkoG7(self, title):
  self.VViv3e = None
  self.lastfilterUsed  = None
  self.filterObj   = CCBykx(self)
  VVX2QD, err = CCuZg4.VVyoTY(self, self.VV5oj8)
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVPn7Q = (""    , self.VV0j6X , []      )
   VV6LI6 = ("Current Service", self.VVQZ9L  , []      )
   VVmhJa = ("Filter"   , self.VVXrSb   , [], "Loading Filters ..." )
   VVkkpG  = ("Zap"   , self.VVZcWa      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV8zKo  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VV6LI6=VV6LI6, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindServices)
 def VV0j6X(self, VVgl66, title, txt, colList):
  refCode  = self.VV2vAi(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFBxYU(self, fncMode=CCTzTd.VVXze0, refCode=refCode, chName=chName, text=txt)
 def VVZcWa(self, VVgl66, title, txt, colList):
  refCode = self.VV2vAi(colList)
  FFQhSW(self, refCode)
 def VVaZQW(self, VVgl66, title, txt, colList):
  FFQhSW(self, colList[3])
 def VV2vAi(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVN4rR(VViNJC, mode=0):
  lines = FFHq6Y(VViNJC, encLst=["UTF-8"])
  return CCuZg4.VVc3Tr(lines, mode)
 @staticmethod
 def VVc3Tr(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVyoTY(SELF, mode, VVXiZB=None, VVCuKF=True, VVQNH9=True):
  VViNJC, err = CCuZg4.VVSslP(SELF, VVQNH9)
  if err:
   return None, err
  asPrefix = False
  if VVXiZB:
   filterCol = VVXiZB[0]
   filterWords = VVXiZB[1]
   asPrefix = VVXiZB[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCuZg4.VVeoIH:
   blackList = None
   if fileExists(VVXFf1):
    blackList = FFHq6Y(VVXFf1)
    if blackList:
     blackList = set(blackList)
  elif mode == CCuZg4.VVUmmS:
   tp = CCgl59()
  VVdPgX, VVu9HV = FFcYq0()
  if mode in (CCuZg4.VVdPAS, CCuZg4.VVdZaP):
   VVX2QD = {}
  else:
   VVX2QD = []
  tagFound = False
  with ioOpen(VViNJC, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFDMS5(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCuZg4.VV5oj8:
       if sTypeInt in VVdPgX:
        STYPE = VVu9HV[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVX2QD.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVX2QD.append(tRow)
       else:
        VVX2QD.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCuZg4.VVD8kg:
        VVX2QD.append((chName, chProv, sat, refCode))
       elif mode == CCuZg4.VVdPAS:
        VVX2QD[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCuZg4.VVdZaP:
        VVX2QD[chName] = refCode
       elif mode == CCuZg4.VVeoIH:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVX2QD.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVX2QD.append(tRow)
        else:
         VVX2QD.append(tRow)
       elif mode == CCuZg4.VVUmmS:
        if sTypeInt in VVdPgX:
         STYPE = VVu9HV[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVTyLz(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVX2QD.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVX2QD.append(tRow)
        else:
         VVX2QD.append(tRow)
       elif mode == CCuZg4.VVBzaU:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVX2QD.append((chName, chProv, sat, refCode))
       elif mode == CCuZg4.VV0WE9:
        VVX2QD.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVX2QD and VVCuKF:
   FF2zEl(SELF, "No services found!")
  return VVX2QD, ""
 def VVI3pg(self, title):
  if fileExists(VVXFf1):
   lines = FFHq6Y(VVXFf1)
   if lines:
    newRows = []
    VVX2QD, err = CCuZg4.VVyoTY(self, self.VV0WE9)
    if VVX2QD:
     lines = set(lines)
     for item in VVX2QD:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVX2QD = newRows
      VVX2QD.sort(key=lambda x: x[0].lower())
      VVPn7Q = ("", self.VVaj8e, [])
      VVkkpG = ("Zap", self.VVaZQW, [])
      self.VVQZvW(title, VVX2QD, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q)
     else:
      FFucjH(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVX2QD)))
   else:
    FF5kkM(self, "No active Parental Control services.", FF3Vxe())
  else:
   FFdxlA(self, VVXFf1)
 def VVOGxw(self, title):
  VVX2QD, err = CCuZg4.VVyoTY(self, self.VVBzaU)
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVPn7Q = ("" , self.VVaj8e, [])
   VVkkpG  = ("Zap", self.VVaZQW, [])
   self.VVQZvW(title, VVX2QD, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q)
  elif err:
   pass
  else:
   FF5kkM(self, "No hidden services.", FF3Vxe())
 def VV4RZN(self):
  title = "Services unused in Tuner Configuration"
  VViNJC, err = CCuZg4.VVSslP(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCuZg4.VVqfNE()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VV4kZ6(str(item[0]))
    nsLst.add(ns)
  sysLst = CCuZg4.VVJnoc("1:7:")
  tpLst  = CCuZg4.VVN4rR(VViNJC, mode=1)
  VVX2QD = []
  for refCode, chName in sysLst:
   servID = CCuZg4.VVOGMg(refCode)
   tpID = CCuZg4.VVjz7g(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVX2QD.append((chName, FF5v7R(refCode, False), refCode, servID))
  if VVX2QD:
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVH4Z8 = ("Options"   , BF(self.VVi5z9, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VV8zKo  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVH4Z8=VVH4Z8, VVBBM8="#0a001122", VVa80e="#0a001122", VVaOdk="#0a001122", VVlVSy="#00004455", VV3FyM="#0a333333", VVf4Ym="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF5kkM(self, "No invalid service found !", title=title)
 def VVi5z9(self, Title, VVgl66, title, txt, colList):
  mSel = CCXfgt(self, VVgl66)
  isMulti = VVgl66.VVIa5A
  if isMulti : txt = "Remove %s Services" % FFivHt(str(VVgl66.VVGnLM()), VVgmAg)
  else  : txt = "Remove : %s" % FFivHt(VVgl66.VVErbL()[0], VVgmAg)
  VVgsyy = [(txt, "del")]
  cbFncDict = {"del": BF(FF3LD6, VVgl66, BF(self.VVcrNG, VVgl66, Title))}
  mSel.VVnFMb(VVgsyy, cbFncDict)
 def VVcrNG(self, VVgl66, title):
  VViNJC, err = CCuZg4.VVSslP(self, title=title)
  if err:
   return
  isMulti = VVgl66.VVIa5A
  skipLst = []
  if isMulti : skipLst = VVgl66.VVCkXr(3)
  else  : skipLst = [VVgl66.VVErbL()[3]]
  tpLst = CCuZg4.VVN4rR(VViNJC, mode=0)
  servLst = CCuZg4.VVN4rR(VViNJC, mode=10)
  tmpDbFile = VViNJC + ".tmp"
  lines   = FFHq6Y(VViNJC)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFlh8N("mv -f '%s' '%s'" % (tmpDbFile, VViNJC))
  VVX2QD = []
  for row in VVgl66.VV3eCu():
   if not row[3] in skipLst:
    VVX2QD.append(row)
  FFjhC8()
  FFucjH(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVX2QD:
   VVgl66.VVrEsw(VVX2QD, title)
   VVgl66.VVVdMt(False)
  else:
   VVgl66.cancel()
 def VV5Hdq(self, title):
  VViNJC, err = CCuZg4.VVSslP(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVRH4n(VViNJC)
  txt = FFivHt("Total Transponders:\n\n", VViC5D)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFivHt("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VViC5D)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFuXdz(item), satList.count(item))
  FFucjH(self, txt, title)
 def VVRH4n(self, VViNJC):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VViNJC, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVvoGe(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFdxlA(self, path, title=title)
   return
  elif not CCxFIK.VVeJOe(self, path, title):
   return
  if not CC5i9A.VVvyUl(self):
   return
  tree = CCuZg4.VVbwHw(self, path, title=title)
  if not tree:
   return
  VVX2QD = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFDMS5(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVX2QD.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVX2QD:
   VVX2QD.sort(key=lambda x: int(x[1]))
   VV6LI6 = ("Current Satellite", BF(self.VVEPQq, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VV8zKo  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=25, VVqPV4=1, VV6LI6=VV6LI6, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF2zEl(self, "No data found !", title=title)
 def VVEPQq(self, satCol, VVgl66, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  sat = FF5v7R(refCode, False)
  for ndx, row in enumerate(VVgl66.VV3eCu()):
   if sat == row[satCol].strip():
    VVgl66.VVICdA(ndx)
    break
  else:
   FFRB11(VVgl66, "No listed !", 1500)
 def FF3LD6_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FF2zEl(self, "No Satellites found !")
   return
  usedSats = CCuZg4.VVqfNE()
  VVX2QD = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVX2QD.append((sat[1], posTxt, FFDMS5(sat[0]), tuners, str(posVal)))
  if VVX2QD:
   VVaOdk = "#11222222"
   VVX2QD.sort(key=lambda x: int(x[1]))
   VV6LI6 = ("Current Satellite" , BF(self.VVEPQq, 2) , [])
   VVH4Z8 = ("Options"   , self.VVC8FB  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VV8zKo  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVBBM8=VVaOdk, VVa80e=VVaOdk, VVaOdk=VVaOdk, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF2zEl(self, "No data found !")
 def VVC8FB(self, VVgl66, title, txt, colList):
  mSel = CCXfgt(self, VVgl66)
  isMulti = VVgl66.VVIa5A
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFivHt(str(VVgl66.VVGnLM()), VVgmAg)
  else  : txt = "Remove ALL Services on : %s" % FFivHt(VVgl66.VVErbL()[0], VVgmAg)
  VVgsyy = []
  VVgsyy.append((txt, "deleteSat"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Delete Empty Bouquets", "VVKGSd"))
  cbFncDict = { "deleteSat"   : BF(FF3LD6, VVgl66, BF(self.VV4PTy, VVgl66))
     , "VVKGSd" : BF(self.VVKGSd, VVgl66)
     }
  mSel.VVnFMb(VVgsyy, cbFncDict)
 def VV4PTy(self, VVgl66):
  posLst = []
  isMulti = VVgl66.VVIa5A
  posLst = []
  if isMulti : posLst = VVgl66.VVCkXr(4)
  else  : posLst = [VVgl66.VVErbL()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VV4kZ6(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVBk9C(nsLst)
  FFjhC8(True)
  FFucjH(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVKGSd(self, winObj):
  title = "Delete Empty Bouquets"
  FFZnVu(self, BF(FF3LD6, winObj, BF(self.VVPMYe, title)), "Delete bouquets with no services ?", title=title)
 def VVPMYe(self, title):
  bList = CCqHUu.VVmUiX()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCqHUu.VVCQnS(bRef)
    bPath = VVKSHN + bFile
    FFAFdq(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVKSHN + fil
     if fileExists(path):
      lines = FFHq6Y(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFjhC8(True)
  if bNames: txt = "%s\n\n%s" % (FFivHt("Deleted Bouquets:", VVhb13), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFucjH(self, txt, title=title)
 def VV4kZ6(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVBk9C(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVKSHN)
  for srcF in files:
   if fileExists(srcF):
    lines = FFHq6Y(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFvqGJ(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVqzPb(self, title)   : self.VVQynG(title, True)
 def VVXrIQ(self, title) : self.VVQynG(title, False)
 def VVQynG(self, title, isWithPIcons):
  piconsPath = CC0NDf.VVqbLc()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC0NDf.VVOwGR(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVX2QD, err = CCuZg4.VVyoTY(self, self.VV0WE9)
    if VVX2QD:
     channels = []
     for (chName, chProv, sat, refCode) in VVX2QD:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFzBf3(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVX2QD)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVBMvF(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVBMvF("PIcons Path"  , piconsPath)
     txt += VVBMvF("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVBMvF("Total services" , totalServices)
     txt += VVBMvF("With PIcons"  , totalWithPIcons)
     txt += VVBMvF("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFucjH(self, txt)
     else:
      VVPn7Q     = (""      , self.VVaj8e , [])
      if isWithPIcons : VVmhJa = ("Export Current PIcon", self.VVrahI  , [])
      else   : VVmhJa = None
      VVH4Z8     = ("Statistics", FFucjH, [txt])
      VVkkpG      = ("Zap", self.VVaZQW, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVQZvW(title, channels, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa)
   else:
    FF2zEl(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF2zEl(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVaj8e(self, VVgl66, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFBxYU(self, fncMode=CCTzTd.VVXze0, refCode=refCode, chName=chName, text=txt)
 def VVrahI(self, VVgl66, title, txt, colList):
  png, path = CC0NDf.VVdCZt(colList[3], colList[0])
  if path:
   CC0NDf.VV6ltV(self, png, path)
 @staticmethod
 def VVUxBE():
  VViNJC  = "%slamedb" % VVKSHN
  VVLDFX = "%slamedb.disabled" % VVKSHN
  return VViNJC, VVLDFX
 @staticmethod
 def VV0V93():
  VVY0qL  = "%slamedb5" % VVKSHN
  VV6pvs = "%slamedb5.disabled" % VVKSHN
  return VVY0qL, VV6pvs
 def VVuKb8(self, isEnable):
  VViNJC, VVLDFX = CCuZg4.VVUxBE()
  if isEnable and not fileExists(VVLDFX):
   FF5kkM(self, "Aready enabled.")
  elif not isEnable and not fileExists(VViNJC):
   FF2zEl(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFZnVu(self, BF(self.VVIrbo, isEnable), "%s Hidden Channels ?" % word)
 def VVIrbo(self, isEnable):
  VViNJC , VVLDFX = CCuZg4.VVUxBE()
  VVY0qL, VV6pvs = CCuZg4.VV0V93()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVLDFX, VVLDFX, VViNJC)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV6pvs, VV6pvs, VVY0qL)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VViNJC  , VViNJC , VVLDFX)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVY0qL , VVY0qL, VV6pvs)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVLDFX, VViNJC )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV6pvs, VVY0qL)
  ok = FFlh8N(cmd)
  FFjhC8()
  if ok: FF5kkM(self, "Hidden List %s" % word)
  else : FF2zEl(self, "Error while restoring:\n\n%s" % fileName)
 def VV7PmC(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVKSHN
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVKSHN
  FFszeA(self, cmd)
 def VVRyyG(self):
  VViNJC, err = CCuZg4.VVSslP(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFAFdq(tmpFile)
  totChan = totRemoved = 0
  lines = FFHq6Y(VViNJC, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFZnVu(self, BF(FF3LD6, self, BF(self.VVFNwU, tmpFile, VViNJC, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFZevi(totRemoved), totChan, FFZevi(totChan))
      , callBack_No=BF(self.VV8rPq, tmpFile))
  else:
   FFucjH(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVFNwU(self, tmpFile, VViNJC, totRemoved, totChan):
  FFlh8N("mv -f '%s' '%s'" % (tmpFile, VViNJC))
  FFjhC8()
  FFucjH(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VV8rPq(self, tmpFile):
  FFAFdq(tmpFile)
 @staticmethod
 def VVSslP(SELF, VVQNH9=True, title=""):
  VViNJC, VVLDFX = CCuZg4.VVUxBE()
  if   not fileExists(VViNJC)       : err = "File not found !\n\n%s" % VViNJC
  elif not CCxFIK.VVeJOe(SELF, VViNJC) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVQNH9:
   FF2zEl(SELF, err, title=title)
  return VViNJC, err
 @staticmethod
 def VVjz7g(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVOGMg(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVJnoc(servTypes):
  VVTjE0  = eServiceCenter.getInstance()
  VVv8t2   = '%s ORDER BY name' % servTypes
  VVMrC7   = eServiceReference(VVv8t2)
  VVe1wx = VVTjE0.list(VVMrC7)
  if VVe1wx: return VVe1wx.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVqfNE():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCTzTd(Screen):
 VVfwSM  = 0
 VV69by   = 1
 VVMtw8   = 2
 VVXze0    = 3
 VVrAmw    = 4
 VVMkLw   = 5
 VVUuQB   = 6
 VVSo34    = 7
 VVf4Mv   = 8
 VVZwZl   = 9
 VVSrL1   = 10
 VVpEKx   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFAm4L(VVCmnq, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVfwSM)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFivHt("%s\n", VVPwgj) % SEP
  self.picViewer  = None
  FFNG7m(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVw0nl })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self["myLabel"].VVZ8z1(outputFileToSave="chann_info")
  if   self.fncMode == self.VVfwSM : fnc = self.VV03l1
  elif self.fncMode == self.VV69by  : fnc = self.VV03l1
  elif self.fncMode == self.VVMtw8  : fnc = self.VV03l1
  elif self.fncMode == self.VVXze0  : fnc = self.VVC5nR
  elif self.fncMode == self.VVrAmw  : fnc = self.VVe8X9
  elif self.fncMode == self.VVMkLw  : fnc = self.VVPR1t
  elif self.fncMode == self.VVUuQB  : fnc = self.VVAwpM
  elif self.fncMode == self.VVSo34  : fnc = self.VVjKDv
  elif self.fncMode == self.VVf4Mv  : fnc = self.VVfPN1
  elif self.fncMode == self.VVZwZl : fnc = self.VV17Z8
  elif self.fncMode == self.VVSrL1  : fnc = self.VV5qPC
  elif self.fncMode == self.VVpEKx : fnc = self.VVw5C6
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVsIzd()
  FFnB9O(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVPPxZ()
 def VVOH8n(self, err):
  self["myLabel"].setText(err)
  FFvobF(self["myTitle"], "#22200000")
  FFvobF(self["myBody"], "#22200000")
  self["myLabel"].VVnTh7("#22200000")
  self["myLabel"].VVsIzd()
 def VV03l1(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  self.refCode = refCode
  self.VVaH4S(chName)
 def VVC5nR(self):
  self.VVaH4S(self.chName)
 def VVe8X9(self):
  self.VVaH4S(self.chName)
 def VVPR1t(self):
  self.VVaH4S(self.chName)
 def VVAwpM(self):
  self.VVaH4S("Picon Info")
 def VVjKDv(self):
  self.VVaH4S(self.chName)
 def VVfPN1(self):
  self.VVaH4S(self.chName)
 def VV17Z8(self):
  self.VVaH4S(self.chName)
 def VV5qPC(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFElMG(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVOUnL(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVaH4S(self.chName)
 def VVw5C6(self):
  self.VVaH4S(self.chName)
 def VVaH4S(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFiRis(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV5u7Q(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFivHt(self.VVnywm(tUrl), VVrVS3)
  if not self.epg:
   epg = CCje5B.VVL5J4(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVBVx1(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC0NDf.VVdCZt(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVBVx1(path)
  self.VVcm3d()
  self.VV8wNW(decodedUrl)
  self["myLabel"].setText(self.text or "   No active service", VVFq7T=VVJKXb)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVsIzd(minHeight=minH)
 def VV8wNW(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFH7Or(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVqP89(FFBuNh(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCbrHa.VVfw4J(self.portalEpgUrl)
   else    : epg, err = CCbrHa.VVfw4J(decodedUrl)
  if epg:
   self.text += "\n" + FFExgP("EPG:", VVhb13) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVcm3d()
 def VVcm3d(self):
  if not self.piconShown and self.picUrl:
   path, err = FFZXhR(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVBVx1(path)
    if self.piconShown and self.refCode:
     self.VV5iT3(path, self.refCode)
 def VV5iT3(self, path, refCode):
  if path and fileExists(path) and FFwmhG("ffmpeg"):
   pPath = CC0NDf.VVqbLc()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCTzTd.VVi3sm(path)
    cmd += FFT1jM("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFlh8N(cmd)
 def VVBVx1(self, path):
  if path and fileExists(path):
   err, w, h = self.VVw5np(path)
   if not err:
    if h > w:
     self.VV6bXp(self["myPicF"], w, h, True)
     self.VV6bXp(self["myPicB"], w, h, False)
     self.VV6bXp(self["myPic"] , w, h, False)
   self.picViewer = CCHGEE.VVqFaS(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VV6bXp(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVw5np(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFU8jM(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV5u7Q(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFivHt(chName, VVhb13)
  txt += self.VVBMvF(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFivHt(state, VVL6GV)
   txt += "State\t: %s\n" % state
  w = FFR7wS(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFR7wS(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVJmkH(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVBMvF(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVBMvF(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVBMvF(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VV1Y6v()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV1REx()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCTzTd.VVb80o(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFivHt("Stream-Relay" if FFTEln(decodedUrl) else "IPTV", VViC5D)
   txt += self.VVfqvK(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVxOEU(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCgl59()
    tpTxt, namespace = tp.VVwYWy(refCode)
    if tpTxt:
     txt += FFivHt("Tuner:\n", VVhb13)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFivHt("Codes:\n", VVhb13)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVBMvF(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVBMvF(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVBMvF(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVBMvF(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVBMvF(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVBMvF(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVBMvF(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVBMvF(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVBMvF(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVJmkH(info):
  if info:
   aspect = FFR7wS(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVBMvF(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFR7wS(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVhUf5(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVhUf5(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VV1Y6v(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VV1REx(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVxOEU(self, refCode, iptvRef, chName):
  refCode = FF49Rh(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFU2DB(VVKSHN + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFU2DB(VVKSHN + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVX3UR = []
  tmpRefCode = FFBuNh(refCode)
  for item in fList:
   path = VVKSHN + item
   if fileExists(path):
    txt = FFU2DB(path)
    if tmpRefCode in FFBuNh(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVX3UR.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVX3UR:
   if len(VVX3UR) == 1:
    txt += "%s\t: %s%s\n" % (FFivHt("Bouquet", VVhb13), VVX3UR[0][0], " (%s)" % VVX3UR[0][1] if VVQrwB else "")
   else:
    txt += FFivHt("Bouquets:\n", VVhb13)
    for ndx, item in enumerate(VVX3UR):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVQrwB else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVfqvK(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFzxaC(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCbrHa()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFivHt("URL:", VViC5D) + "\n%s\n" % self.VVnywm(decodedUrl)
  else:
   txt = "\n"
   txt += FFivHt("Reference:", VViC5D) + "\n%s\n" % refCode
  return txt
 def VVnywm(self, url):
  if not FFTEln(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVmTYx:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFBuNh(url)
 def VVqP89(self, decodedUrl):
  if not CCQZYn.VVY3BC():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCA7uK.VVhDYU(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCA7uK.VVkQUQ(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVtXSM(tDict)
   elif uType == "movie" : epg, picUrl = CCTzTd.VVFhG3(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVtXSM(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCA7uK.VVqlay(item, "title"    , is_base64=True )
     lang    = CCA7uK.VVqlay(item, "lang"         ).upper()
     description   = CCA7uK.VVqlay(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCA7uK.VVqlay(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCA7uK.VVqlay(item, "start_timestamp"      )
     stop_timestamp  = CCA7uK.VVqlay(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCA7uK.VVqlay(item, "stop_timestamp"       )
     now_playing   = CCA7uK.VVqlay(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVWK7B, ""
      else     : color, txt = VVL6GV , "    (CURRENT EVENT)"
      epg += FFivHt("_" * 32 + "\n", VVPwgj)
      epg += FFivHt("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFivHt(description, VVrVS3)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCje5B.VVPx5z(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVFhG3(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCA7uK.VVqlay(item, "movie_image" )
    genre  = CCA7uK.VVqlay(item, "genre"   ) or "-"
    plot  = CCA7uK.VVqlay(item, "plot"   ) or "-"
    country  = CCA7uK.VVqlay(item, "country"  ) or "-"
    actors  = CCA7uK.VVqlay(item, "actors"   ) or "-"
    cast  = CCA7uK.VVqlay(item, "cast"   ) or "-"
    rating  = CCA7uK.VVqlay(item, "rating"   ) or "-"
    director = CCA7uK.VVqlay(item, "director"  ) or "-"
    releasedate = CCA7uK.VVqlay(item, "releasedate" ) or "-"
    duration = CCA7uK.VVqlay(item, "duration"  ) or "-"
    try:
     lang = CCA7uK.VVqlay(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFivHt(cast if cast != "-" else actors, VVrVS3)
    epg += "Plot:\n%s"    % FFivHt(plot, VVrVS3)
   except:
    pass
  return epg, movie_image
 def VVw0nl(self):
  if VVmTYx:
   def VVBMvF(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVBMvF(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCbrHa()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVBMvF(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFRB11(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVEuoo(SELF):
  if not CCD0Wo.VVzlRk(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF)
  err = url =  fSize = resumable = ""
  if FF8SD1(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCbrHa.VVTvVJ(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCbrHa.VVDnPN(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FF2zEl(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCxFIK.VVe4Bo(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFivHt(" (M3U/M3U8 File)", VVrVS3)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCS6qp.VV1geZ(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV65di(subj, val):
   return "%s\n%s\n\n" % (FFivHt("%s:" % subj, VVhb13), val)
  title = "File Size"
  txt  = VV65di(title , fSize or "?")
  txt += VV65di("Name" , chName)
  txt += VV65di("URL" , url)
  if resumable: txt += VV65di("Supports Download-Resume", resumable)
  if err  : txt += FFivHt("Error:\n", VVL6GV) + err
  FFucjH(SELF, txt, title=title)
 @staticmethod
 def VVb80o(SELF):
  fPath, fDir, fName = CCxFIK.VVscnA(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVi3sm(path):
  return FFT1jM("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VV6y0c(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CC0NDf.VVqbLc() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVgmmZ(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFH7Or(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFvqGJ(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCbrHa():
 def __init__(self):
  self.VVLNR5()
  self.VVBjHt    = ""
  self.VVwqYY   = "#f#11ffffaa#User"
  self.VVGD0r   = "#f#11aaffff#Server"
 def VVLNR5(self):
  self.VVSqEM   = ""
  self.VVCDPD    = ""
  self.VVgjGx   = ""
  self.VVur4K = ""
  self.VVWmlH  = ""
  self.VVo9tr = 0
 def VVPiQp(self, url, mac, ph1="", VVnkcm=True):
  self.VVLNR5()
  self.VVBjHt = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVPA6A(url)
  if not host:
   if VVnkcm:
    self.VV3xCD("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVZXCG(mac)
  if not host:
   if VVnkcm:
    self.VV3xCD("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVSqEM = host
  self.VVCDPD  = mac
  return True
 def VVb7PG(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVBjHt, "")
 def VVPA6A(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVZXCG(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVsq4O(self):
  res, err = self.VVtPbe(self.VVOz2i())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVSqEM.endswith("/c"):
    self.VVSqEM = self.VVSqEM[:-2]
    res, err = self.VVtPbe(self.VVOz2i())
   elif self.VVSqEM.endswith("/stalker_portal"):
    self.VVSqEM = self.VVSqEM[:-15]
    res, err = self.VVtPbe(self.VVOz2i())
   else:
    self.VVSqEM += "/c"
    res, err = self.VVtPbe(self.VVOz2i())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCA7uK.VVqlay(tDict["js"], "token")
    rand  = CCA7uK.VVqlay(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVT0Qs(self, VVnkcm=True):
  if not self.VVBjHt:
   self.VVveMk()
  err = blkMsg = FF5kkMTxt = ""
  try:
   token, rand, err = self.VVsq4O()
   if token:
    self.VVgjGx = token
    self.VVur4K = rand
    if rand:
     self.VVo9tr = 2
    prof, retTxt = self.VVvCLj(True)
    if prof:
     self.VVWmlH = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVo9tr = 3
      prof, retTxt = self.VVvCLj(False)
      if retTxt:
       self.VVWmlH = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF5kkMTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF5kkMTxt: tErr += "\n%s" % FF5kkMTxt
  if VVnkcm:
   self.VV3xCD(tErr)
  return "", "", tErr
 def VVveMk(self):
  try:
   import requests
   url = self.VVT8g3()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCbrHa.VVDnPN(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCbrHa.VVDnPN(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVSqEM = url
       self.VVBjHt = span.group(1)
       return
  except:
   pass
  self.VVBjHt = "/server/load.php"
 def VVT8g3(self):
  url = self.VVSqEM.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VV8LNL(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVtPbe("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVtPbe("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVvCLj(self, capMac):
  res, err = self.VVtPbe(self.VVVupa(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCA7uK.VVqlay(tDict["js"], "block_%s" % word)
    FF5kkMTxt = CCA7uK.VVqlay(tDict["js"], word)
    return tDict, FF5kkMTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVVupa(self, capMac):
  param = ""
  if self.VVWmlH or self.VVur4K:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVCDPD.upper() if capMac else self.VVCDPD.lower(), self.VVur4K))
  return self.VVNdKk() + "type=stb&action=get_profile" + param
 exec(FFElMG("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VViSx9(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVOLyu()
  if len(rows) < 10:
   rows = self.VV5gUe()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVSqEM ))
   rows.append(("MAC (from URL)" , self.VVCDPD ))
   rows.append(("Token"   , self.VVgjGx ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVwqYY  , "MAC" , self.VVCDPD ))
   rows.append(("2", self.VVGD0r, "Host" , self.VVSqEM ))
   rows.append(("2", self.VVGD0r, "Token" , self.VVgjGx ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVAOqJ(self, isPhp=True, VVnkcm=False):
  token, profile, tErr = self.VVT0Qs(VVnkcm)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVtNYZ()
  res, err = self.VVtPbe(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCA7uK.VVqlay(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FF4f8i(span.group(2))
     pass1 = FF4f8i(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVOLyu(self):
  m3u_Url, host, user1, pass1, err = self.VVAOqJ()
  rows = []
  if m3u_Url:
   res, err = self.VVtPbe(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFwVZA(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVwqYY, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFwVZA(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVGD0r, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV5gUe(self):
  token, profile, tErr = self.VVT0Qs()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFN7zT(val): val = FFElMG(val.decode("UTF-8"))
     else     : val = self.VVCDPD
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFwVZA(int(parts[1]))
      if parts[2] : ends = FFwVZA(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFwVZA(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVOUnL(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVT0Qs(VVnkcm=False)
  if not token:
   return ""
  crLinkUrl = self.VV0f97(mode, chCm, epNum, epId)
  res, err = self.VVtPbe(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCA7uK.VVqlay(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVNdKk(self):
  return self.VVSqEM + self.VVBjHt + "?"
 def VVOz2i(self):
  return self.VVNdKk() + "type=stb&action=handshake&token=&mac=%s" % self.VVCDPD
 def VVst8u(self, mode):
  url = self.VVNdKk() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVACLk(self, catID):
  return self.VVNdKk() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVeNF1(self, mode, catID, page):
  url = self.VVNdKk() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVwGyJ(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVNdKk() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVNVCj(self, stID):
  return self.VVNdKk() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VV0f97(self, mode, chCm, serCode, serId):
  url = self.VVNdKk() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVtNYZ(self):
  return self.VVNdKk() + "type=itv&action=create_link"
 def VV6v9u(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVzFtp(catID, stID, chNum)
  query = self.VVpFHP(mode, self.VVb7PG(), FFqA3T(host), FFqA3T(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVpFHP(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVNkab(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVpFHP(mode, ph1, host, mac, epNum, epId, FF4f8i(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFElMG(host)
  mac   = FFElMG(mac)
  valid = False
  if self.VVPA6A(playHost) and self.VVPA6A(host) and self.VVPA6A(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVtPbe(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCbrHa.VVDnPN()
   if self.VVgjGx:
    headers["Authorization"] = "Bearer %s" % self.VVgjGx
   if useCookies : cookies = {"mac": self.VVCDPD, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VV6uu3(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCbrHa.VVDnPN(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVDnPN():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VV3xCD(self, err, title="Portal Browser"):
  FF2zEl(self, str(err), title=title)
 def VVH30v(self, mode):
  if   mode in ("itv"  , CCA7uK.VVNrYr , CCA7uK.VVrWyY)  : return "Live"
  elif mode in ("vod"  , CCA7uK.VVSd85 , CCA7uK.VVxI0f)  : return "VOD"
  elif mode in ("series" , CCA7uK.VV1ys5 , CCA7uK.VVuk12) : return "Series"
  else                          : return "IPTV"
 def VVsvAK(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVH30v(mode), FFivHt(searchName, VVrVS3))
 def VVfE3b(self, catchup=False):
  VVgsyy = []
  VVgsyy.append(("Live"    , "live"  ))
  VVgsyy.append(("VOD"    , "vod"   ))
  VVgsyy.append(("Series"   , "series"  ))
  if catchup:
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Catch-up TV" , "catchup"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Account Info." , "accountInfo" ))
  return VVgsyy
 @staticmethod
 def VVc7Oc(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCbrHa()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(decodedUrl)
  if valid:
   ok = p.VVPiQp(host, mac, ph1, VVnkcm=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVAOqJ(isPhp=False, VVnkcm=False)
    streamId = CCbrHa.VV823F(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VV823F(decodedUrl):
  p = CCbrHa()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFElMG(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVTvVJ(decodedUrl):
  p = CCbrHa()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(decodedUrl)
  if valid:
   if CCbrHa.VVKD70(chCm):
    return FFBuNh(chCm)
   else:
    ok = p.VVPiQp(host, mac, ph1, VVnkcm=False)
    if ok:
     try:
      chUrl = p.VVOUnL(mode, chCm, epNum, epId)
      return FFBuNh(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVKD70(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVfw4J(decodedUrl, retLst=False):
  epg = err = res = ""
  if "mode=itv" in decodedUrl:
   p = CCbrHa()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(decodedUrl)
   if valid:
    if not stID:
     stID = CCbrHa.VV823F(decodedUrl)
    if stID:
     if p.VVPiQp(host, mac, ph1, VVnkcm=False):
      token, profile, tErr = p.VVT0Qs(VVnkcm=False)
      if token:
       res, err = p.VVtPbe(p.VVNVCj(stID))
       if res: epg, err = CCbrHa.VVKASR(res.text, retLst)
  return epg, err
 @staticmethod
 def VVKASR(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCA7uK.VVqlay(item, "actor"       )
    category   = CCA7uK.VVqlay(item, "category"      )
    descr    = CCA7uK.VVqlay(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCA7uK.VVqlay(item, "director"      )
    name    = CCA7uK.VVqlay(item, "name"   , is_base64=True)
    start_timestamp  = CCA7uK.VVqlay(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCA7uK.VVqlay(item, "start_timestamp"    )
    stop_timestamp  = CCA7uK.VVqlay(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCA7uK.VVqlay(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFivHt("    (CURRENT EVENT)", VVL7a3)
     except:
      pass
     if not skip:
      epg += FFivHt("_" * 32 + "\n", VVPwgj)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFivHt(name, VVhb13)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFivHt(descr , VVrVS3) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFivHt(category, VVrVS3) if category else ""
      epg += "Actors:\n%s\n"  % FFivHt(actor , VVrVS3) if actor else ""
      epg += "Director:\n%s\n" % FFivHt(director, VVrVS3) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCW2rl(CCbrHa):
 def __init__(self):
  CCbrHa.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVJjy0(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVNkab(decodedUrl)
  if valid:
   if self.VVPiQp(host, mac, ph1, VVnkcm=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVckUe(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFElMG(self.chCm[3:])
  else:
   try:
    chUrl = self.VVOUnL(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCbrHa.VVKD70(self.chCm):
   chUrl = FFBuNh(self.chCm)
   chUrl = FF4f8i(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVvgtM(chUrl)
  bPath = CCqHUu.VVuXJC()
  if newIptvRef:
   if passedSELF:
    FFQhSW(passedSELF, newIptvRef, VVehU2=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFQhSW(self, newIptvRef, VVehU2=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVYG0G(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVvgtM(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVYG0G(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=q", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFHq6Y(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFjhC8()
class CC39mE(CCW2rl):
 def __init__(self, passedSession):
  CCW2rl.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VV8Bbd(VV641B  )
  Main_Menu.VV8Bbd(VVoFWh)
  Main_Menu.VV8Bbd(VV66Jh  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVWVaL, iPlayableService.evEOF: self.VVBIfl, iPlayableService.evEnd: self.VVfao9})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVM3e9)
  except:
   self.timer2.callback.append(self.VVM3e9)
  self.timer2.start(3000, False)
  self.VVM3e9()
 def VVM3e9(self):
  if not CFG.downloadMonitor.getValue():
   self.VV03V7()
   return
  lst = CCS6qp.VV0nzr()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFQfFR(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCS6qp.VVoOmq(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCFzIL.VVsGcd(self.passedSession, txt, 30)
   else    : CCFzIL.VVIUc0(self.dnldWin, txt)
  elif self.dnldWin:
   self.VV03V7()
 def VV03V7(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVWVaL(self):
  self.startTime = iTime()
 def VVBIfl(self):
  global VVicJx
  VVicJx = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FF8SD1(decodedUrl):
     self.isFromEOF = True
     CCFzIL(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVfao9(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVJ5zU)
  except:
   self.timer1.callback.append(self.VVJ5zU)
  self.timer1.start(100, True)
 def VVJ5zU(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVJjy0(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCC5bX.VVbPxU:
       self.isFromEOF = False
       self.VVckUe(self.passedSession, isFromSession=True)
class CCzN6y():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F](.+)")
  self.prefixRemoveList = self.VVAAuY(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVAAuY(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVAAuY(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVV9bl, VVn5zG):
    path += fName
    if fileExists(path):
     for line in FFHq6Y(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVqpv6(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCA7uK.VVU3cm(name):
   return CCA7uK.VVwi3A(name)
  return self.VVcBTc(name)
 def VVcBTc(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVlKvE(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVcBTc(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVm5as(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVQrJA(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVXhfd(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCD0Wo(CCbrHa):
 def __init__(self):
  CCbrHa.__init__(self)
 def VV5XPK(self):
  if CCD0Wo.VVzlRk(self):
   FF3LD6(self, BF(self.VVX1vg, 2), title="Searching ...")
 def VVhSrZ(self, winSession, url, mac):
  self.curUrl = url
  if CCD0Wo.VVzlRk(self):
   if self.VVPiQp(url, mac):
    FF3LD6(winSession, self.VVw96R, title="Checking Server ...")
   else:
    FF2zEl(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVenAG(self, item=None):
  if item:
   VVyxPv, txt, path, ndx = item
   enc = CCCXVP.VVwlwm(path, self)
   if enc == -1:
    return
   self.session.open(CCNT6G, barTheme=CCNT6G.VVQKW9
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VV5zWY, path, enc)
       , VVRlGe = BF(self.VVEvKy, VVyxPv, path))
 def VV5zWY(self, path, enc, VVxeRf):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVxeRf.VVPZSN(totLines)
  VVxeRf.VVxy84 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVxeRf or VVxeRf.isCancelled:
     return
    VVxeRf.VVnoYr(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVPA6A(url)
     mac  = self.VVZXCG(mac)
     if host and mac and VVxeRf:
      VVxeRf.VVxy84.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVPA6A(url)
      mac  = self.VVZXCG(mac)
      if host and mac and not mac.startswith("AC") and VVxeRf:
       VVxeRf.VVxy84.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVEvKy(self, VVyxPv, path, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVxy84:
   VVTaaj  = ("Home Menu"  , FF90Z9            , [])
   VVH4Z8 = ("Edit File"  , BF(self.VVsoqV, path)       , [])
   VV6LI6 = ("M3U Options" , self.VVUchw         , [])
   VVmhJa = ("Check & Filter" , BF(self.VVJeJc, VVyxPv, path), [])
   VVkkpG  = ("Select"   , self.VVAXdk      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV8zKo  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVxy84, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVBBM8="#0a001122", VVa80e="#0a001122", VVaOdk="#0a001122", VVlVSy="#00004455", VV3FyM="#0a333333", VVf4Ym="#11331100", VVMXk9=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VV1FXh:
    FFRB11(VVgl66, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV1FXh:
    FF2zEl(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVUchw(self, VVgl66, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVgsyy = []
  VVgsyy.append(("Browse as M3U"  , "browse"))
  VVgsyy.append(("Download M3U File" , "downld"))
  FFCO3u(self, BF(self.VVkD3R, VVgl66, host, mac), title=title, VVgsyy=VVgsyy, width=600, VVf67P=True)
 def VVkD3R(self, VVgl66, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FF3LD6(VVgl66, BF(self.VVJvoV, VVgl66, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFZnVu(self, BF(FF3LD6, VVgl66, BF(self.VVJvoV, VVgl66, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVJvoV(self, VVgl66, title, host, mac, item):
  p = CCbrHa()
  m3u_Url = ""
  ok = p.VVPiQp(host, mac, VVnkcm=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVAOqJ(VVnkcm=False)
  if m3u_Url:
   if   item == "browse": self.VVbXEQ(title, m3u_Url)
   elif item == "downld": self.VVI4u1(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FF2zEl(self, err or "No response from Server !", title=title)
 def VVAXdk(self, VVgl66, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVhSrZ(VVgl66, url, mac)
 def VVsoqV(self, path, VVgl66, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCDQxK(self, path, VVRlGe=BF(self.VVQVKL, VVgl66), curRowNum=rowNum)
  else    : FFdxlA(self, path)
 def VVJeJc(self, VVyxPv, path, VVgl66, title, txt, colList):
  self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVxLaY, VVgl66)
      , VVRlGe = BF(self.VVMmyE, VVyxPv, VVgl66, path))
 def VVxLaY(self, VVgl66, VVxeRf):
  VVxeRf.VVxy84 = []
  VVxeRf.VVPZSN(VVgl66.VVpibS())
  for row in VVgl66.VV3eCu():
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVnoYr(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVPiQp(host, mac, VVnkcm=False):
    token, profile, tErr = self.VVT0Qs(VVnkcm=False)
    if token and VVxeRf and not VVxeRf.isCancelled:
     res, err = self.VVtPbe(self.VVst8u("itv"))
     if res and VVxeRf and not VVxeRf.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVxeRf.VVnoYr(0, showFound=True)
       VVxeRf.VVxy84.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVxeRf:
    return
 def VVMmyE(self, VVyxPv, VVgl66, path, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if VVxy84:
   VVgl66.close()
   VVyxPv.close()
   newPath = "%s_OK_%s.txt" % (path, FFvXEJ())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVxy84:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFivHt(str(threadCounter), VVL6GV)
    skipped = FFivHt(str(threadTotal - threadCounter), VVL6GV)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVxy84)
   txt += "%s\n\n%s"    %  (FFivHt("Result File:", VVhb13), newPath)
   FFucjH(self, txt, title="Accessible Portals")
  elif VV1FXh:
   FF2zEl(self, "No portal access found !", title="Accessible Portals")
 def VVCLDB(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFElMG(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVw96R(self):
  token, profile, tErr = self.VVT0Qs()
  if token:
   dots = "." * self.VVo9tr
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVb7PG(), "")
   dots += "*" if not self.VVSqEM == self.curUrl else ""
   VVgsyy  = self.VVfE3b()
   VVwWMp = self.VVkH6s
   VVxQ85 = self.VVgATY
   VVbSf3 = ("Home Menu", FF90Z9)
   VVOmbd= ("Add to Menu", BF(CCA7uK.VVW9QT, self, True, self.VVSqEM + "\t" + self.VVCDPD))
   VVtL1m = ("Bookmark Server", BF(CCA7uK.VV9Qil, self, True, self.VVSqEM + "\t" + self.VVCDPD))
   FFCO3u(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVCDPD, dots), VVgsyy=VVgsyy, VVwWMp=VVwWMp, VVxQ85=VVxQ85, VVbSf3=VVbSf3, VVOmbd=VVOmbd, VVtL1m=VVtL1m)
 def VVkH6s(self, item=None):
  if item:
   VVyxPv, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF3LD6(VVyxPv, BF(self.VVOv13, mode), title="Reading Categories ...")
   else : FF3LD6(VVyxPv, BF(self.VVvIHC, VVyxPv, title), title="Reading Account ...")
 def VVvIHC(self, VVyxPv, title, forceMoreInfo=False):
  rows, totCols = self.VViSx9(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVCDPD)
  VVTaaj  = ("Home Menu" , FF90Z9           , [])
  VV6LI6  = None
  if VVmTYx:
   VV6LI6 = ("Get JS"  , BF(self.VVNL9Y, self.VVT8g3()) , [])
  if totCols == 2:
   VVmhJa = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVmhJa = ("More Info.", BF(self.VVzbxG, VVyxPv)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFyrIU(self, None, title=title, width=1200, header=header, VVX3UR=rows, VVBL0l=widths, VVJA7R=26, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVmhJa=VVmhJa, VVBBM8="#0a00292B", VVa80e="#0a002126", VVaOdk="#0a002126", VVlVSy="#00000000", searchCol=searchCol)
 def VVNL9Y(self, url, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVO10o, url), title="Getting JS ...")
 def VVO10o(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVCDPD)
  ver, err = self.VV8LNL(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VV8LNL(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFucjH(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVzbxG(self, VVyxPv, VVgl66, title, txt, colList):
  VVgl66.cancel()
  FF3LD6(VVyxPv, BF(self.VVvIHC, VVyxPv, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVOv13(self, mode):
  token, profile, tErr = self.VVT0Qs()
  if not token:
   return
  res, err = self.VVtPbe(self.VVst8u(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCA7uK.VVqlay(item, "id"       )
      Title  = CCA7uK.VVqlay(item, "title"      )
      censored = CCA7uK.VVqlay(item, "censored"     )
      Title = self.VVm5as(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVQrwB:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVH30v(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs(mode)
   mName = self.VVH30v(mode)
   VVkkpG   = ("Show List"   , BF(self.VVI4YM, mode)   , [])
   VVTaaj  = ("Home Menu"   , FF90Z9        , [])
   if mode in ("vod", "series"):
    VVH4Z8 = ("Find in %s" % mName , BF(self.VVWKmp, mode, False), [])
    VVmhJa = ("Find in Selected" , BF(self.VVWKmp, mode, True) , [])
   else:
    VVH4Z8 = None
    VVmhJa = None
   header   = None
   widths   = (100   , 0  )
   FFyrIU(self, None, title=title, width=1200, header=header, VVX3UR=list, VVBL0l=widths, VVJA7R=30, VVTaaj=VVTaaj, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVkkpG=VVkkpG, VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVaOdk, VVlVSy=VVlVSy, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVWmlH:
     txt += "\n\n( %s )" % self.VVWmlH
   else:
    txt = "Could not get Categories from server!"
   FF2zEl(self, txt, title=title)
 def VVCbhs(self, mode, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVC0o8, mode, VVgl66, title, txt, colList), title="Downloading ...")
 def VVC0o8(self, mode, VVgl66, title, txt, colList):
  token, profile, tErr = self.VVT0Qs()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVtPbe(self.VVACLk(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCA7uK.VVqlay(item, "id"    )
      actors   = CCA7uK.VVqlay(item, "actors"   )
      added   = CCA7uK.VVqlay(item, "added"   )
      age    = CCA7uK.VVqlay(item, "age"   )
      category_id  = CCA7uK.VVqlay(item, "category_id" )
      description  = CCA7uK.VVqlay(item, "description" )
      director  = CCA7uK.VVqlay(item, "director"  )
      genres_str  = CCA7uK.VVqlay(item, "genres_str"  )
      name   = CCA7uK.VVqlay(item, "name"   )
      path   = CCA7uK.VVqlay(item, "path"   )
      screenshot_uri = CCA7uK.VVqlay(item, "screenshot_uri" )
      series   = CCA7uK.VVqlay(item, "series"   )
      cmd    = CCA7uK.VVqlay(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVkkpG  = ("Play"    , BF(self.VVNfY8, mode)       , [])
   VVPn7Q = (""     , BF(self.VVWfUO, mode)     , [])
   VVTaaj = ("Home Menu"   , FF90Z9            , [])
   VV6LI6 = ("Download Options" , BF(self.VVXz5G, mode, "sp", seriesName) , [])
   VVH4Z8 = ("Options"   , BF(self.VVcsCS, "pEp", mode, seriesName) , [])
   VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV8zKo  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFyrIU(self, None, title=seriesName, width=1200, header=header, VVX3UR=list, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindIptv, VVBBM8="#0a00292B", VVa80e="#0a002126", VVaOdk="#0a002126", VVlVSy="#00000000")
  else:
   FF2zEl(self, "Could not get Episodes from server!", title=seriesName)
 def VVWKmp(self, mode, searchInCat, VVgl66, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVgsyy = []
  VVgsyy.append(("Keyboard"  , "manualEntry"))
  VVgsyy.append(("From Filter" , "fromFilter"))
  FFCO3u(self, BF(self.VV3tIW, VVgl66, mode, searchCatId), title="Input Type", VVgsyy=VVgsyy, width=400)
 def VV3tIW(self, VVgl66, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF7lc9(self, BF(self.VVcwD7, VVgl66, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCBykx(self)
    filterObj.VVjDje(BF(self.VVcwD7, VVgl66, mode, searchCatId))
 def VVcwD7(self, VVgl66, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFH7ga(CFG.lastFindIptv, searchName)
   title = self.VVsvAK(mode, searchName)
   if "," in searchName : FF2zEl(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FF2zEl(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVQrJA([searchName]):
     FF2zEl(self, self.VVXhfd(), title=title)
    else:
     self.VVVn6S(mode, searchName, "", searchName, searchCatId)
 def VVI4YM(self, mode, VVgl66, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVVn6S(mode, bName, catID, "", "")
 def VVVn6S(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCNT6G, barTheme=CCNT6G.VVQKW9
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVvPnp, mode, bName, catID, searchName, searchCatId)
      , VVRlGe = BF(self.VVGaYo, mode, bName, catID, searchName, searchCatId))
 def VVGaYo(self, mode, bName, catID, searchName, searchCatId, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVsvAK(mode, searchName)
  else   : title = "%s : %s" % (self.VVH30v(mode), bName)
  if VVxy84:
   VV6LI6 = None
   VVH4Z8 = None
   if mode == "series":
    VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs("series2")
    VVkkpG  = ("Episodes"   , BF(self.VVCbhs, mode)           , [])
   else:
    VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs("")
    VVkkpG  = ("Play"    , BF(self.VVNfY8, mode)           , [])
    VV6LI6 = ("Download Options" , BF(self.VVXz5G, mode, "vp" if mode == "vod" else "", "") , [])
    VVH4Z8 = ("Options"   , BF(self.VVcsCS, "pCh", mode, bName)      , [])
   VVPn7Q = (""      , BF(self.VV5HHC, mode)         , [])
   VVTaaj = ("Home Menu"    , FF90Z9                , [])
   VVmhJa = ("Posters Mode"   , BF(self.VVbxAx, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VV8zKo  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVxy84, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindIptv, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVaOdk, VVlVSy=VVlVSy, VVMXk9=True, searchCol=1)
   if not VV1FXh:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVgl66.VVTAgm(VVgl66.VVBJII() + tot)
    if threadErr: FFRB11(VVgl66, "Error while reading !", 2000)
    else  : FFRB11(VVgl66, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF2zEl(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF2zEl(self, "Could not get list from server !", title=title)
 def VV5HHC(self, mode, VVgl66, title, txt, colList):
  ttl = lambda x, y: "%s\n%s\n\n" % (FFivHt(x, VVhb13), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFBxYU(self, fncMode=CCTzTd.VVpEKx, portalHost=self.VVSqEM, portalMac=self.VVCDPD, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV8Fiw(mode, VVgl66, title, txt, colList)
 def VVWfUO(self, mode, VVgl66, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFivHt(colList[10], VVrVS3)
  txt += "Description:\n%s" % FFivHt(colList[11], VVrVS3)
  self.VV8Fiw(mode, VVgl66, title, txt, colList)
 def VV8Fiw(self, mode, VVgl66, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVzpbx(mode, colList)
  refCode, chUrl = self.VV6v9u(self.VVSqEM, self.VVCDPD, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFBxYU(self, fncMode=CCTzTd.VVSrL1, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVvPnp(self, mode, bName, catID, searchName, searchCatId, VVxeRf):
  try:
   token, profile, tErr = self.VVT0Qs()
   if not token:
    return
   if VVxeRf.isCancelled:
    return
   VVxeRf.VVxy84, total_items, max_page_items, err = self.VVHrKi(mode, catID, 1, 1, searchName, searchCatId)
   if VVxeRf.isCancelled:
    return
   if VVxeRf.VVxy84 and total_items > -1 and max_page_items > -1:
    VVxeRf.VVPZSN(total_items)
    VVxeRf.VVnoYr(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVxeRf.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVHrKi(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVxeRf.VVCLpN()
     if VVxeRf.isCancelled:
      return
     if list:
      VVxeRf.VVxy84 += list
      VVxeRf.VVnoYr(len(list), True)
  except:
   pass
 def VVHrKi(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVwGyJ(mode, searchName, searchCatId, page)
  else   : url = self.VVeNF1(mode, catID, page)
  res, err = self.VVtPbe(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVI50O(CCA7uK.VVqlay(item, "total_items" ))
     max_page_items = self.VVI50O(CCA7uK.VVqlay(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCA7uK.VVqlay(item, "id"    )
      name   = CCA7uK.VVqlay(item, "name"   )
      o_name   = CCA7uK.VVqlay(item, "o_name"   )
      tv_genre_id  = CCA7uK.VVqlay(item, "tv_genre_id" )
      number   = CCA7uK.VVqlay(item, "number"   ) or str(counter)
      logo   = CCA7uK.VVqlay(item, "logo"   )
      screenshot_uri = CCA7uK.VVqlay(item, "screenshot_uri" )
      pic    = CCA7uK.VVqlay(item, "pic"   )
      cmd    = CCA7uK.VVqlay(item, "cmd"   )
      censored  = CCA7uK.VVqlay(item, "censored"  )
      genres_str  = CCA7uK.VVqlay(item, "genres_str"  )
      curPlay   = CCA7uK.VVqlay(item, "cur_playing" )
      actors   = CCA7uK.VVqlay(item, "actors"   )
      descr   = CCA7uK.VVqlay(item, "description" )
      director  = CCA7uK.VVqlay(item, "director"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFqA3T(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVSqEM + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVqpv6(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVI50O(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVNfY8(self, mode, VVgl66, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVzpbx(mode, colList)
  refCode, chUrl = self.VV6v9u(self.VVSqEM, self.VVCDPD, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVU3cm(chName):
   FFRB11(VVgl66, "This is a marker!", 300)
  else:
   FF3LD6(VVgl66, BF(self.VVolKc, mode, VVgl66, chUrl), title="Playing ...")
 def VVolKc(self, mode, VVgl66, chUrl):
  FFQhSW(self, chUrl, VVehU2=False)
  CCC5bX.VVBgB6(self.session, iptvTableParams=(self, VVgl66, mode))
 def VV8Xhc(self, mode, VVgl66, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVzpbx(mode, colList)
  refCode, chUrl = self.VV6v9u(self.VVSqEM, self.VVCDPD, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVzpbx(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVzlRk(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVgsyy = []
    VVgsyy.append((title        , "inst" ))
    VVgsyy.append(("Update Packages then %s" % title , "updInst" ))
    FFCO3u(SELF, BF(CCD0Wo.VVtWPu, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVgsyy=VVgsyy)
   return False
 @staticmethod
 def VVtWPu(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFYO4M(VV0BJl, "")
   if cmdUpd:
    cmdInst = FFcDAv(VV58Rq, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFyAzl(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VV5SfP=cbFnc)
   else:
    FFjIcG(SELF)
class CCA7uK(Screen, CCD0Wo, CCzN6y, CCzIkW):
 VV7gDy    = 0
 VVFQSd    = 1
 VVFHId    = 2
 VVpZjh    = 3
 VVKt6m     = 4
 VVzmiY     = 5
 VVmaU3     = 6
 VVsmpi     = 7
 VVif44     = 8
 VVvOme     = 9
 VVIEHs      = 10
 VVlc7G     = 11
 VV89j5     = 12
 VVlG0h     = 13
 VVQhkW     = 14
 VVbiFs      = 15
 VV4x6X      = 16
 VVydG3      = 17
 VVCL1m      = 18
 VVbify      = 19
 VVHUvD    = 0
 VVNrYr   = 1
 VVSd85   = 2
 VV1ys5   = 3
 VV0XTn  = 4
 VVRB9l  = 5
 VVrWyY   = 6
 VVxI0f   = 7
 VVuk12  = 8
 VVlG1U  = 9
 VViZrq  = 10
 VVfpIV = 0
 VVOwiU = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVgl66    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVMt5LData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCA7uK.VVILbD(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCD0Wo.__init__(self)
  CCzN6y.__init__(self)
  VVgsyy = self.VV3Ysf()
  FFNG7m(self, title="IPTV", VVgsyy=VVgsyy)
  self["myActionMap"].actions.update({
   "menu" : self.VVNDx1
  })
  self["myMenu"].onSelectionChanged.append(self.VVRewR)
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
  global VVz86I
  VVz86I = True
 def VVBp8x(self):
  self["myMenu"].setList(self.VV3Ysf())
  FFhtaK(self)
  FFfavv(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFyZo3(self["myMenu"])
   FFcTnD(self)
   if self.m3uOrM3u8File:
    self.VVGXFP(self.m3uOrM3u8File)
 def onExit(self):
  global VVz86I
  del VVz86I
 def VVRewR(self):
  if self["myMenu"].getCurrent()[1] in ("VVSsvv", "VVYmsEPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVNDx1(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVYmsEPortal" : confItem = CFG.favServerPortal
   elif item == "VVSsvv" : confItem = CFG.favServerPlaylist
   else         : return
   FFZnVu(self, BF(self.VVMFCb, confItem), 'Remove from menu ?', title=title)
 def VVMFCb(self, confItem):
  FFH7ga(confItem, "")
  self.VVBp8x()
 def VV3Ysf(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVAQIK
  VVgsyy = []
  if isFav1: VVgsyy.append((c +  "Favourite Playlist Server"   , "VVSsvv" ))
  if isFav2: VVgsyy.append((c +  "Favourite Portal Server"    , "VVYmsEPortal" ))
  VVgsyy.append(("IPTV Server Browser (from Playlists)"     , "VVMt5L_fromPlayList" ))
  VVgsyy.append(("IPTV Server Browser (from Portal List)"    , "VVMt5L_fromMac"  ))
  VVgsyy.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVMt5L_fromM3u"  ))
  qUrl, iptvRef = CCA7uK.VV2C8j(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVgsyy.append(FFDNao("IPTV Server Browser (from Current Channel)", "VVMt5L_fromCurrChan", fromCurCond))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("M3U/M3U8 File Browser"        , "VV33so"   ))
  if self.iptvFileAvailable:
   VVgsyy.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(FFDNao("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVgsyy.append(FFDNao("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVgsyy.append(VVzHzv)
   c1, c2 = VVVJaM, VVhb13
   t1 = FFivHt("auto-match names", VVAQIK)
   t2 = FFivHt("from xml file"  , VVAQIK)
   VVgsyy.append((c1 + "Count Available IPTV Channels"    , "VVPVfs"    ))
   VVgsyy.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVgsyy.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVLwk5" ))
   VVgsyy.append((VVgmAg + "More Reference Tools ..."  , "VVH5FV"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Reload Channels and Bouquets"       , "VVUfoc"   ))
  VVgsyy.append(VVzHzv)
  if not CCS6qp.VVnPmJ():
   VVgsyy.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVgsyy.append(("Download Manager ... No downloads"    ,       ))
  return VVgsyy
 def VVTAf8(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVxXHV"   : self.VVxXHV()
   elif item == "VVCPMC" : FFZnVu(self, self.VVCPMC, "Change Current List References to Unique Codes ?")
   elif item == "VVKVBz_rows" : FFZnVu(self, BF(FF3LD6, self.VVgl66, self.VVKVBz), "Change Current List References to Identical Codes ?")
   elif item == "VVbPz8"   : self.VVbPz8(tTitle)
   elif item == "VVf3Yd"   : self.VVf3Yd(tTitle)
   elif item == "VVSsvv" : self.VVYmsE(False)
   elif item == "VVYmsEPortal" : self.VVYmsE(True)
   elif item == "VVMt5L_fromPlayList" : FF3LD6(self, BF(self.VVX1vg, 1), title=title)
   elif item == "VVMt5L_fromM3u"  : FF3LD6(self, BF(self.VV6ASo, CCA7uK.VVfpIV), title=title)
   elif item == "VVMt5L_fromMac"  : self.VV5XPK()
   elif item == "VVMt5L_fromCurrChan" : self.VVMOnt()
   elif item == "VV33so"   : self.VV33so()
   elif item == "iptvTable_all"   : FF3LD6(self, BF(self.VVWiIQ, self.VV7gDy), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCA7uK.VVH3cl(self)
   elif item == "refreshIptvPicons"  : self.VVIZxN()
   elif item == "VVPVfs"    : FF3LD6(self, self.VVPVfs)
   elif item == "copyEpgPicons"   : self.VVv8I1(False)
   elif item == "renumIptvRef_fromFile" : self.VVv8I1(True)
   elif item == "VVLwk5" : FFZnVu(self, BF(FF3LD6, self, self.VVLwk5), VVWZXE="Continue ?")
   elif item == "VVH5FV"    : self.VVH5FV()
   elif item == "VVUfoc"   : FF3LD6(self, BF(CCuZg4.VVUfoc, self))
   elif item == "dload_stat"    : CCS6qp.VVKwKj(self)
 def VV33so(self):
  if CCD0Wo.VVzlRk(self):
   FF3LD6(self, BF(self.VV6ASo, CCA7uK.VVOwiU), title="Searching ...")
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVTAf8(item)
 def VVWiIQ(self, mode):
  VVX2QD = self.VV3egX(mode)
  if VVX2QD:
   VV6LI6 = ("Current Service", self.VVklI7 , [])
   VVH4Z8 = ("Options"  , self.VVC5Eb   , [])
   VVmhJa = ("Filter"   , self.VVRhy7   , [])
   VVkkpG  = ("Play"   , BF(self.VVwPWy)  , [])
   VVPn7Q = (""    , self.VV5dwi    , [])
   VV1Zg1 = (""    , self.VVY5eB     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VV8zKo  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFyrIU(self, None, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26
     , VVkkpG=VVkkpG, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVPn7Q=VVPn7Q, VV1Zg1=VV1Zg1
     , VVBBM8="#0a00292B", VVa80e="#0a002126", VVaOdk="#0a002126", VVlVSy="#00000000", VVMXk9=True, searchCol=1)
  else:
   if mode == self.VVvOme: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF2zEl(self, err)
 def VVY5eB(self, VVgl66, title, txt, colList):
  self.VVgl66 = VVgl66
 def VVC5Eb(self, VVgl66, title, txt, colList):
  VVgsyy = []
  VVgsyy.append(("Add Current List to a New Bouquet"    , "VVxXHV"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change Current List References to Unique Codes" , "VVCPMC"))
  VVgsyy.append(("Change Current List References to Identical Codes", "VVKVBz_rows" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Share Reference with DVB Service (manual entry)" , "VVbPz8"   ))
  VVgsyy.append(("Share Reference with DVB Service (auto-find)"  , "VVf3Yd"   ))
  FFCO3u(self, self.VVTAf8, title="IPTV Tools", VVgsyy=VVgsyy)
 def VVRhy7(self, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVNLOM, VVgl66))
 def VVNLOM(self, VVgl66):
  VVgsyy = []
  VVgsyy.append(("All"         , "all"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Prefix of Selected Channel"   , "sameName" ))
  VVgsyy.append(("Suggest Words from Selected Channel" , "partName" ))
  VVgsyy.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVgsyy.append(("Duplicate References"     , "depRef"  ))
  VVgsyy.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVgsyy.append(("Stream Relay"       , "SRelay"  ))
  VVgsyy.append(FFJi5u("Category"))
  VVgsyy.append(("Live TV"        , "live"  ))
  VVgsyy.append(("VOD"         , "vod"   ))
  VVgsyy.append(("Series"        , "series"  ))
  VVgsyy.append(("Uncategorised"      , "uncat"  ))
  VVgsyy.append(FFJi5u("Media"))
  VVgsyy.append(("Video"        , "video"  ))
  VVgsyy.append(("Audio"        , "audio"  ))
  VVgsyy.append(FFJi5u("File Type"))
  VVgsyy.append(("MKV"         , "MKV"   ))
  VVgsyy.append(("MP4"         , "MP4"   ))
  VVgsyy.append(("MP3"         , "MP3"   ))
  VVgsyy.append(("AVI"         , "AVI"   ))
  VVgsyy.append(("FLV"         , "FLV"   ))
  VVgsyy.extend(CCqHUu.VVuaO0(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVhPKM, VVgl66) if VVgl66.VVBJII().startswith("IPTV Filter ") else None
  filterObj = CCBykx(self)
  filterObj.VVKDLr(VVgsyy, VVgsyy, BF(self.VViD4l, VVgl66, False), inFilterFnc=inFilterFnc)
 def VVhPKM(self, VVgl66, VVyxPv, item):
  self.VViD4l(VVgl66, True, item)
 def VViD4l(self, VVgl66, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVgl66.VVJJCV(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV7gDy , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVFQSd , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVFHId , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVpZjh , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVmaU3  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVsmpi  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVif44  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVvOme  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVIEHs   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVlc7G  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VV89j5  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVlG0h  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVQhkW  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVbiFs   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV4x6X   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVydG3   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVCL1m   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVbify   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVKt6m  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVzmiY  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVFHId:
   VVgsyy = []
   chName = VVgl66.VVJJCV(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVgsyy.append((item, item))
    if not VVgsyy and chName:
     VVgsyy.append((chName, chName))
    FFCO3u(self, BF(self.VV7Fut, title), title="Words from Current Selection", VVgsyy=VVgsyy)
   else:
    VVgl66.VVD950("Invalid Channel Name")
  else:
   words, asPrefix = CCBykx.VVVM3i(words)
   if not words and mode in (self.VVKt6m, self.VVzmiY):
    FFRB11(self.VVgl66, "Incorrect filter", 2000)
   else:
    FF3LD6(self.VVgl66, BF(self.VVBKwn, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VV7Fut(self, title, word=None):
  if word:
   words = [word.lower()]
   FF3LD6(self.VVgl66, BF(self.VVBKwn, self.VVFHId, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVwi3A(txt):
  return "#f#11ffff00#" + txt
 def VVBKwn(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVX2QD = self.VV8QK3(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVX2QD = self.VV3egX(mode=mode, words=words, asPrefix=asPrefix)
  if VVX2QD : self.VVgl66.VVrEsw(VVX2QD, title)
  else  : self.VVgl66.VVD950("Not found")
 def VV8QK3(self, mode=0, words=None, asPrefix=False):
  VVX2QD = []
  for row in self.VVgl66.VV3eCu():
   row = list(map(str.strip, row))
   chNum, chName, VVaDL0, chType, refCode, url = row
   if self.VVEVqT(mode, refCode, FFBuNh(url).lower(), chName, words, VVaDL0.lower(), asPrefix):
    VVX2QD.append(row)
  VVX2QD = self.VVEQiR(mode, VVX2QD)
  return VVX2QD
 def VV3egX(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVX2QD = []
  files = CCA7uK.VVILbD()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFU2DB(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVaDL0 = span.group(1)
    else : VVaDL0 = ""
    VVaDL0_lCase = VVaDL0.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVU3cm(chName): chNameMod = self.VVwi3A(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVaDL0, chType + (" SRel" if FFTEln(url) else ""), refCode, url)
     if self.VVEVqT(mode, refCode, FFBuNh(url).lower(), chName, words, VVaDL0_lCase, asPrefix):
      VVX2QD.append(row)
      chNum += 1
  VVX2QD = self.VVEQiR(mode, VVX2QD)
  return VVX2QD
 def VVEQiR(self, mode, VVX2QD):
  newRows = []
  if VVX2QD and mode == self.VVmaU3:
   counted  = iCounter(elem[4] for elem in VVX2QD)
   for item in VVX2QD:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVX2QD
 def VVEVqT(self, mode, refCode, tUrl, chName, words, VVaDL0_lCase, asPrefix):
  if   mode == self.VV7gDy : return True
  elif mode == self.VVmaU3 : return True
  elif mode == self.VVsmpi  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVif44 : return FFTEln(tUrl)
  elif mode == self.VVlG0h  : return CCA7uK.VVhDYU(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVQhkW  : return CCA7uK.VVhDYU(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVvOme  : return CCA7uK.VVhDYU(tUrl, compareType="live")
  elif mode == self.VVIEHs  : return CCA7uK.VVhDYU(tUrl, compareType="movie")
  elif mode == self.VVlc7G : return CCA7uK.VVhDYU(tUrl, compareType="series")
  elif mode == self.VV89j5  : return CCA7uK.VVhDYU(tUrl, compareType="")
  elif mode == self.VVbiFs  : return CCA7uK.VVhDYU(tUrl, compareExt="mkv")
  elif mode == self.VV4x6X  : return CCA7uK.VVhDYU(tUrl, compareExt="mp4")
  elif mode == self.VVydG3  : return CCA7uK.VVhDYU(tUrl, compareExt="mp3")
  elif mode == self.VVCL1m  : return CCA7uK.VVhDYU(tUrl, compareExt="avi")
  elif mode == self.VVbify  : return CCA7uK.VVhDYU(tUrl, compareExt="flv")
  elif mode == self.VVFQSd: return chName.lower().startswith(words[0])
  elif mode == self.VVFHId: return words[0] in chName.lower()
  elif mode == self.VVpZjh: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVKt6m : return words[0] == VVaDL0_lCase
  elif mode == self.VVzmiY :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVxXHV(self):
  picker = CCqHUu(self, self.VVgl66, "Add to Bouquet", self.VVIA4B)
 def VVIA4B(self):
  chUrlLst = []
  for row in self.VVgl66.VV3eCu():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVH5FV(self):
  t1 = FFivHt("Bouquet" , VVhb13)
  t2 = FFivHt("ALL"  , VVgmAg)
  t3 = FFivHt("Unique"  , VVVJaM)
  t4 = FFivHt("Identical" , VVAQIK)
  VVgsyy = []
  VVgsyy.append((VVL7a3 + "Check System Acceptable Reference Types", "VVAT1K"))
  VVgsyy.append(FFDNao("Check Reference Codes Format", "VVZ2VQ", self.iptvFileAvailable, VVL7a3))
  VVgsyy.append(VVzHzv)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVgsyy.append((txt % t1, "VVq2PK" ))
  VVgsyy.append((txt % t2, "VVpMtW_all"  ))
  VVgsyy.append(VVzHzv)
  txt = "Change %s References to %s Codes .."
  VVgsyy.append((txt % (t1, t3), "VVA6EC" ))
  VVgsyy.append((txt % (t2, t3), "VVAYZc"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change %s References to %s Codes" % (t2, t4) , "VVKVBz_all"))
  VVwWMp = self.VVaHmg
  FFCO3u(self, None, width=1150, title="IPTV Reference Tools", VVgsyy=VVgsyy, VVwWMp=VVwWMp, VVBBM8="#22002233", VVa80e="#22001122")
 def VVaHmg(self, item=None):
  if item:
   ques = "Continue ?"
   VVyxPv, txt, item, ndx = item
   if   item == "VVAT1K"    : FF3LD6(VVyxPv, self.VVAT1K)
   elif item == "VVZ2VQ"     : FF3LD6(VVyxPv, self.VVZ2VQ)
   elif item == "VVq2PK" : self.VVv3Ek(VVyxPv, self.VV9WT0)
   elif item == "VVpMtW_all"  : self.VV9WT0(VVyxPv, None, None)
   elif item == "VVA6EC" : self.VVA6EC(VVyxPv, txt)
   elif item == "VVAYZc"  : FFZnVu(self, BF(self.VVAYZc , VVyxPv, txt), title=txt, VVWZXE=ques)
   elif item == "VVKVBz_all"  : FFZnVu(self, BF(FF3LD6, VVyxPv, self.VVKVBz), title=txt, VVWZXE=ques)
 def VV9WT0(self, VVyxPv, bName, bPath):
  VVgsyy = []
  for rt in CCA7uK.VV6ZB0():
   VVgsyy.append(("%s\t ... %s" % (rt, CCA7uK.VVRuwZ(rt)), rt))
  FFCO3u(self, BF(self.VVyJhF, VVyxPv, bName, bPath), VVgsyy=VVgsyy, width=800, title="Change Reference Types to:")
 def VVyJhF(self, VVyxPv, bName, bPath, rType=None):
  if rType:
   self.VVxcqO(VVyxPv, bName, bPath, rType)
 def VVv3Ek(self, VVyxPv, fnc):
  VVgsyy = CCqHUu.VVuaO0()
  if VVgsyy:
   FFCO3u(self, BF(self.VVL6za, VVyxPv, fnc), VVgsyy=VVgsyy, title="IPTV Bouquets", VVf67P=True)
  else:
   FFRB11(VVyxPv, "No bouquets Found !", 1500)
 def VVL6za(self, VVyxPv, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVKSHN + span.group(1)
    if fileExists(bPath): fnc(VVyxPv, bName, bPath)
    else    : FFRB11(VVyxPv, "Bouquet file not found!", 2000)
   else:
    FFRB11(VVyxPv, "Cannot process bouquet !", 2000)
 def VVxcqO(self, VVyxPv, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFivHt(bName, VVMdMA)
  else : title = "Change for %s" % FFivHt("All IPTV Services", VVMdMA)
  FFZnVu(self, BF(FF3LD6, VVyxPv, BF(self.VVLWoG, VVyxPv, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFivHt(rType, VVMdMA), title=title)
 def VVLWoG(self, VVyxPv, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCA7uK.VVILbD()
  if files:
   newRType = rType + ":"
   piconPath = CC0NDf.VVqbLc()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCxFIK.VVeJOe(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FF2zEl(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFlh8N("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFlh8N(cmd)
  self.VV0DlR(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVPVfs(self):
  totFiles = 0
  files  = CCA7uK.VVILbD()
  if files:
   totFiles = len(files)
  totChans = 0
  VVX2QD = self.VV3egX()
  if VVX2QD:
   totChans = len(VVX2QD)
  FFucjH(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVZ2VQ(self):
  files = CCA7uK.VVILbD()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFU2DB(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVd7n9
   else    : color = VVL6GV
   totInvalid = FFivHt(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFivHt("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFucjH(self, txt, title="Check IPTV References")
 def VVAT1K(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCA7uK.VV6ZB0()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCqHUu.VVd5ae(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVEjvG = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVEjvG:
   VVKIZS = FFlVIk(VVEjvG)
   if VVKIZS:
    for service in VVKIZS:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVKSHN + userBName
  bFile = VVKSHN + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFT1jM("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFT1jM("rm -f '%s'" % path)
  FFlh8N(cmd)
  FFjhC8()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVd7n9
    else     : res, color = "No" , VVL6GV
    pl = CCA7uK.VVRuwZ(item)
    txt += "    %s\t: %s%s\n" % (item, FFivHt(res, color), FFivHt("\t... %s" % pl, VVrVS3) if pl else "")
   FFucjH(self, txt, title=title)
  else:
   txt = FF2zEl(self, "Could not complete the test on your system!", title=title)
 def VVLwk5(self):
  VVVzTq, err = CCuZg4.VVyoTY(self, CCuZg4.VVdZaP)
  if VVVzTq:
   totChannels = 0
   totChange = 0
   for path in CCA7uK.VVILbD():
    toSave = False
    txt = FFU2DB(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVVzTq.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV0DlR(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF2zEl(self, 'No channels in "lamedb" !')
 def VVAYZc(self, VVyxPv, title):
  bFiles = CCA7uK.VVILbD()
  if bFiles: self.VVpjGs(bFiles, title)
  else  : FFRB11(VVyxPv, "No bouquets files !", 1500)
 def VVA6EC(self, VVyxPv, title):
  self.VVv3Ek(VVyxPv, BF(self.VVT7ZU, title))
 def VVT7ZU(self, title, VVyxPv, bName, bPath):
  self.VVpjGs([bPath], title)
 def VVpjGs(self, bFiles, title):
  self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVEv1S, bFiles)
      , VVRlGe = BF(self.VVxHrZ, title))
 def VVEv1S(self, bFiles, VVxeRf):
  VVxeRf.VVxy84 = ""
  VVxeRf.VV1hS4("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFHq6Y(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVxeRf or VVxeRf.isCancelled:
   return
  elif not totLines:
   VVxeRf.VVxy84 = "No IPTV Services !"
   return
  else:
   VVxeRf.VVPZSN(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVxeRf or VVxeRf.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFHq6Y(path)
    for ndx, line in enumerate(lines):
     if not VVxeRf or VVxeRf.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVxeRf:
       VVxeRf.VV1hS4("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVxeRf:
       VVxeRf.VVnoYr(1)
      refCode, startId, startNS = CCqHUu.VVxNVI(rType, CCqHUu.VVV72T, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVxeRf:
        VVxeRf.VVxy84 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVxHrZ(self, title, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVxy84:
   txt += "\n\n%s\n%s" % (FFivHt("Ended with Error:", VVL6GV), VVxy84)
  self.VV0DlR(True, title, txt)
 def VVCPMC(self):
  bFiles = CCA7uK.VVILbD()
  if not bFiles:
   FFRB11(self.VVgl66, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVgl66.VV3eCu():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFRB11(self.VVgl66, "Cannot read list", 1500)
   return
  self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVexs6, bFiles, tableRefList)
      , VVRlGe = BF(self.VVxHrZ, "Change Current List References to Unique Codes"))
 def VVexs6(self, bFiles, tableRefList, VVxeRf):
  VVxeRf.VVxy84 = ""
  VVxeRf.VV1hS4("Reading System References ...")
  refLst = CCqHUu.VVwZqA(CCqHUu.VVV72T, stripRType=True)
  if not VVxeRf or VVxeRf.isCancelled:
   return
  VVxeRf.VVPZSN(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVxeRf or VVxeRf.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFU2DB(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVxeRf or VVxeRf.isCancelled:
     return
    VVxeRf.VV1hS4("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVxeRf or VVxeRf.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVxeRf.VVnoYr(1)
      refCode, startId, startNS = CCqHUu.VVxNVI(rType, CCqHUu.VVV72T, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVxeRf:
        VVxeRf.VVxy84 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVKVBz(self):
  list = None
  if self.VVgl66:
   list = []
   for row in self.VVgl66.VV3eCu():
    list.append(row[4] + row[5])
  files = CCA7uK.VVILbD()
  totChange = 0
  if files:
   for path in files:
    lines = FFHq6Y(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VV0DlR(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV0DlR(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFjhC8()
   if refreshTable and self.VVgl66:
    VVX2QD = self.VV3egX()
    if VVX2QD and self.VVgl66:
     self.VVgl66.VVrEsw(VVX2QD, self.tableTitle)
     self.VVgl66.VVD950(txt)
   FFucjH(self, txt, title=title)
  else:
   FF5kkM(self, "No changes.")
 @staticmethod
 def VVILbD(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVKSHN + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFU2DB(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV5dwi(self, VVgl66, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFBuNh(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFBxYU(self, fncMode=CCTzTd.VVSo34, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVeejR(self, VVgl66, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVwPWy(self, VVgl66, title, txt, colList):
  chName, chUrl = self.VVeejR(VVgl66, colList)
  self.VVuDvb(VVgl66, chName, chUrl, "localIptv")
 def VVZXod(self, mode, VVgl66, colList):
  chName, chUrl, picUrl, refCode = self.VVywew(mode, colList)
  return chName, chUrl
 def VVaaC3(self, mode, VVgl66, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVywew(mode, colList)
  self.VVuDvb(VVgl66, chName, chUrl, mode)
 def VVuDvb(self, VVgl66, chName, chUrl, playerFlag):
  chName = FFkgYM(chName)
  if self.VVU3cm(chName):
   FFRB11(VVgl66, "This is a marker!", 300)
  else:
   FF3LD6(VVgl66, BF(self.VVLmb2, VVgl66, chUrl, playerFlag), title="Playing ...")
 def VVLmb2(self, VVgl66, chUrl, playerFlag):
  FFQhSW(self, chUrl, VVehU2=False)
  CCC5bX.VVBgB6(self.session, iptvTableParams=(self, VVgl66, playerFlag))
 @staticmethod
 def VVU3cm(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVklI7(self, VVgl66, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  if refCode:
   url1 = FFBuNh(origUrl.strip())
   for ndx, row in enumerate(VVgl66.VV3eCu()):
    if refCode in row[4]:
     tableRow = FFBuNh(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVgl66.VVICdA(ndx)
      break
   else:
    FFRB11(VVgl66, "No found", 1000)
 def VV6ASo(self, m3uMode):
  lines = self.VV2ytn(3)
  if lines:
   lines.sort()
   VVgsyy = []
   for line in lines:
    VVgsyy.append((line, line))
   if m3uMode == CCA7uK.VVfpIV:
    title = "Browse Server from M3U URLs"
    VVtL1m = ("All to Playlist", self.VVo0PM)
   else:
    title = "M3U/M3U8 File Browser"
    VVtL1m = None
   VVwWMp = BF(self.VVZEoG, m3uMode, title)
   VVxQ85 = self.VVjmxt
   FFCO3u(self, None, title=title, VVgsyy=VVgsyy, width=1200, VVwWMp=VVwWMp, VVxQ85=VVxQ85, VVGamv="", VVtL1m=VVtL1m, VVBBM8="#11221122", VVa80e="#11221122")
 def VVZEoG(self, m3uMode, title, item=None):
  if item:
   VVyxPv, txt, path, ndx = item
   if m3uMode == CCA7uK.VVfpIV:
    FF3LD6(VVyxPv, BF(self.VVA4iX, title, path))
   else:
    FF3LD6(VVyxPv, BF(self.VVGXFP, path))
 def VVGXFP(self, path, m3uFilterParam=None, VVgl66=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFU2DB(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VV4skD(propLine, "group-title") or "-"
   if not group == "-" and self.VVm5as(group):
    if not chName or self.VVqpv6(chName):
     if self.VVEVqT(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVX2QD = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVX2QD.append((name, str(tot), name))
    totAll += tot
   VVX2QD.sort(key=lambda x: x[0].lower())
   VVX2QD.insert(0, ("ALL", str(totAll), ""))
  if VVX2QD:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVgl66:
    VVgl66.VVrEsw(VVX2QD, newTitle=title, VVYHEIMsg=True)
   else:
    VVZAcA = self.VVu17j
    VVkkpG  = ("Select" , BF(self.VVS4dW, path, m3uFilterParam)  , [])
    VVmhJa = ("Filter" , BF(self.VVfWUv, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VV8zKo  = (LEFT  , CENTER , LEFT )
    FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, width= 1400, height= 1000, VVJA7R=28, VVkkpG=VVkkpG, VVmhJa=VVmhJa, VVZAcA=VVZAcA, lastFindConfigObj=CFG.lastFindIptv
      , VVBBM8="#11110022", VVa80e="#11110022", VVaOdk="#11110022", VVlVSy="#00444400")
  elif VVgl66:
   FFKCVv(VVgl66, "Not found !", 1500)
  else:
   self.VVOQZE(FFU2DB(path), "", m3uFilterParam)
 def VVS4dW(self, path, m3uFilterParam, VVgl66, title, txt, colList):
  self.VVOQZE(FFU2DB(path), colList[2], m3uFilterParam)
 def VVfWUv(self, path, m3uFilterParam, VVgl66, title, txt, colList):
  VVgsyy = []
  VVgsyy.append(("All"      , "all"  ))
  VVgsyy.append(FFJi5u("Category"))
  VVgsyy.append(("Live TV"     , "live" ))
  VVgsyy.append(("VOD"      , "vod"  ))
  VVgsyy.append(("Series"     , "series" ))
  VVgsyy.append(("Uncategorised"   , "uncat" ))
  VVgsyy.append(FFJi5u("Media"))
  VVgsyy.append(("Video"     , "video" ))
  VVgsyy.append(("Audio"     , "audio" ))
  VVgsyy.append(FFJi5u("File Type"))
  VVgsyy.append(("MKV"      , "MKV"  ))
  VVgsyy.append(("MP4"      , "MP4"  ))
  VVgsyy.append(("MP3"      , "MP3"  ))
  VVgsyy.append(("AVI"      , "AVI"  ))
  VVgsyy.append(("FLV"      , "FLV"  ))
  filterObj = CCBykx(self, VVBBM8="#11332244", VVa80e="#11222244")
  filterObj.VVKDLr(VVgsyy, [], BF(self.VVqukm, VVgl66, path), inFilterFnc=None)
 def VVqukm(self, VVgl66, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VV7gDy , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVvOme  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVIEHs  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVlc7G  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VV89j5  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVlG0h  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVQhkW  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVbiFs  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VV4x6X  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVydG3  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVCL1m  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVbify  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVzmiY  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCBykx.VVVM3i(words)
   if not mode == self.VV7gDy:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFivHt(fTitle, VVrVS3)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FF3LD6(VVgl66, BF(self.VVGXFP, path, m3uFilterParam, VVgl66), title="Filtering ...")
 def VVOQZE(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCNT6G, barTheme=CCNT6G.VVQKW9
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVGfmF, lst, filterGroup, m3uFilterParam)
       , VVRlGe = BF(self.VVKtoB, title, bName))
  else:
   self.VVGWcq("No valid lines found !", title)
 def VVGfmF(self, lst, filterGroup, m3uFilterParam, VVxeRf):
  VVxeRf.VVxy84 = []
  VVxeRf.VVPZSN(len(lst))
  num = 0
  for cols in lst:
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVnoYr(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VV4skD(propLine, "group-title") or "-"
   picon = self.VV4skD(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVm5as(group) : skip = True
    elif chName and not self.VVqpv6(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVEVqT(mode, "", FFBuNh(url).lower(), chName, words, "", asPrefix)
    if not skip and VVxeRf:
     num += 1
     VVxeRf.VVxy84.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVKtoB(self, title, bName, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if VVxy84:
   VVZAcA = self.VVu17j
   VVkkpG  = ("Select"   , BF(self.VVJtkq, title)   , [])
   VVPn7Q = (""    , self.VVzoVY        , [])
   VV6LI6 = ("Download PIcons", self.VV7X4F       , [])
   VVH4Z8 = ("Options"  , BF(self.VVcsCS, "m3Ch", "", bName) , [])
   VVmhJa = ("Posters Mode" , BF(self.VVbxAx, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV8zKo  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVxy84, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, VVkkpG=VVkkpG, VVZAcA=VVZAcA, VVPn7Q=VVPn7Q, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindIptv, VVMXk9=True, searchCol=1
     , VVBBM8="#0a00192B", VVa80e="#0a00192B", VVaOdk="#0a00192B", VVlVSy="#00000000")
  else:
   self.VVGWcq("Not found !", title)
 def VV7X4F(self, VVgl66, title, txt, colList):
  self.VVP7EG(VVgl66, "m3u/m3u8")
 def VVKOKj(self, rowNum, url, chName):
  refCode = self.VVRHBM(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FF4f8i(url), chName)
  return chUrl
 def VVRHBM(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVzFtp(catID, stID, chNum)
  return refCode
 def VV4skD(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVJtkq(self, Title, VVgl66, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF3LD6(VVgl66, BF(self.VV1Cse, Title, VVgl66, colList), title="Checking Server ...")
  else:
   self.VV8Nho(VVgl66, url, chName)
 def VV1Cse(self, title, VVgl66, colList):
  if not CCD0Wo.VVzlRk(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCbrHa.VV6uu3(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVgsyy = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCA7uK.VVLfXf(url, fPath)
     VVgsyy.append((resol, fullUrl))
    if VVgsyy:
     if len(VVgsyy) > 1:
      FFCO3u(self, BF(self.VVpndv, VVgl66, chName), VVgsyy=VVgsyy, title="Resolution", VVf67P=True, VVwQO5=True)
     else:
      self.VV8Nho(VVgl66, VVgsyy[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VV8Nho(VVgl66, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCA7uK.VVLfXf(url, span.group(1))
       self.VV8Nho(VVgl66, fullUrl, chName)
      else:
       self.VV3xCD("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVOQZE(txt, filterGroup="")
      return
    self.VV8Nho(VVgl66, url, chName)
   else:
    self.VVGWcq("Cannot process this channel !", title)
  else:
   self.VVGWcq(err, title)
 def VVpndv(self, VVgl66, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VV8Nho(VVgl66, resolUrl, chName)
 def VV8Nho(self, VVgl66, url, chName):
  FF3LD6(VVgl66, BF(self.VVyDRo, VVgl66, url, chName), title="Playing ...")
 def VVyDRo(self, VVgl66, url, chName):
  chUrl = self.VVKOKj(VVgl66.VVKltF(), url, chName)
  FFQhSW(self, chUrl, VVehU2=False)
  CCC5bX.VVBgB6(self.session, iptvTableParams=(self, VVgl66, "m3u/m3u8"))
 def VVDHk9(self, VVgl66, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVKOKj(VVgl66.VVKltF(), url, chName)
  return chName, chUrl
 def VVzoVY(self, VVgl66, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFBxYU(self, fncMode=CCTzTd.VVSo34, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVGWcq(self, err, title):
  FF2zEl(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVu17j(self, VVgl66):
  if self.m3uOrM3u8File:
   self.close()
  VVgl66.cancel()
 def VVo0PM(self, VV7Q6fObj, item=None):
  FF3LD6(VV7Q6fObj, BF(self.VVGQx6, VV7Q6fObj, item))
 def VVGQx6(self, VV7Q6fObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VV7Q6fObj.VVgsyy):
    path = item[1]
    if fileExists(path):
     enc = CCCXVP.VVwlwm(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCA7uK.VVGGz5(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCA7uK.VVzrAp()
    pListF = "%sPlaylist_%s.txt" % (path, FFvXEJ())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VV7Q6fObj.VVgsyy)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFucjH(self, txt, title=title)
   else:
    FF2zEl(self, "Could not obtain URLs from this file list !", title=title)
 def VVX1vg(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVpYKk
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVenAG
  lines = self.VV2ytn(mode)
  if lines:
   lines.sort()
   VVgsyy = []
   for line in lines:
    VVgsyy.append((FFivHt(line, VVhb13) if "Bookmarks" in line else line, line))
   VVxQ85 = self.VVjmxt
   FFCO3u(self, None, title=title, VVgsyy=VVgsyy, width=1200, VVwWMp=okFnc, VVxQ85=VVxQ85, VVGamv="")
 def VVjmxt(self, VVyxPv, txt, ref, ndx):
  txt = ref
  sz = FFQfFR(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCxFIK.VVe4Bo(sz)
  FFucjH(self, txt, title="File Path")
 def VVpYKk(self, item=None):
  if item:
   VVyxPv, txt, path, ndx = item
   FF3LD6(VVyxPv, BF(self.VVjIeD, VVyxPv, path), title="Processing File ...")
 def VVjIeD(self, VV7mD9, path):
  enc = CCCXVP.VVwlwm(path, self)
  if enc == -1:
   return
  VVX2QD = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFZsCH(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCA7uK.VVETwG(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVX2QD:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVX2QD.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVX2QD:
   title = "Playlist File : %s" % os.path.basename(path)
   VVkkpG  = ("Start"    , BF(self.VVuldj, "Playlist File")      , [])
   VVTaaj = ("Home Menu"   , FF90Z9             , [])
   VV6LI6 = ("Download M3U File" , self.VV0PXN         , [])
   VVH4Z8 = ("Edit File"   , BF(self.VV7R1G, path)        , [])
   VVmhJa = ("Check & Filter"  , BF(self.VVboT4, VV7mD9, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV8zKo  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVTaaj=VVTaaj, VVmhJa=VVmhJa, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVBBM8="#11001116", VVa80e="#11001116", VVaOdk="#11001116", VVlVSy="#00003635", VV3FyM="#0a333333", VVf4Ym="#11331100", VVMXk9=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FF2zEl(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV0PXN(self, VVgl66, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFZnVu(self, BF(FF3LD6, VVgl66, BF(self.VVI4u1, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVI4u1(self, title, url):
  path, err = FFZXhR(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF2zEl(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFU2DB(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFAFdq(path)
    FF2zEl(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFAFdq(path)
    FF2zEl(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCA7uK.VVzrAp() + fName
    FFlh8N("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FF5kkM(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF2zEl(self, "Could not download the M3U file!", title=errTitle)
 def VVuldj(self, Title, VVgl66, title, txt, colList):
  url = colList[6]
  FF3LD6(VVgl66, BF(self.VVbXEQ, Title, url), title="Checking Server ...")
 def VV7R1G(self, path, VVgl66, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCDQxK(self, path, VVRlGe=BF(self.VVQVKL, VVgl66), curRowNum=rowNum)
  else    : FFdxlA(self, path)
 def VVQVKL(self, VVgl66, fileChanged):
  if fileChanged:
   VVgl66.cancel()
 def VVbPz8(self, title):
  curChName = self.VVgl66.VVJJCV(1)
  FF7lc9(self, BF(self.VVCQJs, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVCQJs(self, title, name):
  if name:
   VVVzTq, err = CCuZg4.VVyoTY(self, CCuZg4.VV0WE9, VVCuKF=False, VVQNH9=False)
   list = []
   if VVVzTq:
    name = self.VVlKvE(name)
    ratio = "1"
    for item in VVVzTq:
     if name in item[0].lower():
      list.append((item[0], FFyyjf(item[2]), item[3], ratio))
   if list : self.VVQzsP(list, title)
   else : FF2zEl(self, "Not found:\n\n%s" % name, title=title)
 def VVf3Yd(self, title):
  curChName = self.VVgl66.VVJJCV(1)
  self.session.open(CCNT6G, barTheme=CCNT6G.VVQKW9
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVpTpN
      , VVRlGe = BF(self.VVqTLj, title, curChName))
 def VVpTpN(self, VVxeRf):
  curChName = self.VVgl66.VVJJCV(1)
  VVVzTq, err = CCuZg4.VVyoTY(self, CCuZg4.VVdPAS, VVCuKF=False, VVQNH9=False)
  if not VVVzTq or not VVxeRf or VVxeRf.isCancelled:
   return
  VVxeRf.VVxy84 = []
  VVxeRf.VVPZSN(len(VVVzTq))
  curCh = self.VVlKvE(curChName)
  for refCode in VVVzTq:
   chName, sat, inDB = VVVzTq.get(refCode, ("", "", 0))
   ratio = CC0NDf.VVr65X(chName.lower(), curCh)
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVnoYr(1, True)
   if VVxeRf and ratio > 50:
    VVxeRf.VVxy84.append((chName, FFyyjf(sat), refCode.replace("_", ":"), str(ratio)))
 def VVqTLj(self, title, curChName, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if VVxy84: self.VVQzsP(VVxy84, title)
  elif VV1FXh: FF2zEl(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVQzsP(self, VVX2QD, title):
  curChName = self.VVgl66.VVJJCV(1)
  VVemVu = self.VVgl66.VVJJCV(4)
  curUrl  = self.VVgl66.VVJJCV(5)
  VVX2QD.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVkkpG  = ("Share Sat/C/T Ref.", BF(self.VVT7V9, title, curChName, VVemVu, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVBBM8="#0a00112B", VVa80e="#0a001126", VVaOdk="#0a001126", VVlVSy="#00000000")
 def VVT7V9(self, newtitle, curChName, VVemVu, curUrl, VVgl66, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVemVu, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFZnVu(self.VVgl66, BF(FF3LD6, self.VVgl66, BF(self.VVJmR1, VVgl66, data)), ques, title=newtitle, VVOuLx=True)
 def VVJmR1(self, VVgl66, data):
  VVgl66.cancel()
  title, curChName, VVemVu, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVemVu = VVemVu.strip()
  newRefCode = newRefCode.strip()
  if not VVemVu.endswith(":") : VVemVu += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVemVu, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVemVu + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCA7uK.VVILbD():
    txt = FFU2DB(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFjhC8()
    newRow = []
    for i in range(6):
     newRow.append(self.VVgl66.VVJJCV(i))
    newRow[4] = newRefCode
    done = self.VVgl66.VVhT9b(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFnB9O(BF(FF5kkM , self, resTxt, title=title))
  elif resErr: FFnB9O(BF(FF2zEl, self, resErr, title=title))
 def VVboT4(self, VV7mD9, path, VVgl66, title, txt, colList):
  self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVK5HR, VVgl66)
      , VVRlGe = BF(self.VVyU3G, VV7mD9, path, VVgl66))
 def VVK5HR(self, VVgl66, VVxeRf):
  VVxeRf.VVPZSN(VVgl66.VVFbUd())
  VVxeRf.VVxy84 = []
  for row in VVgl66.VV3eCu():
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVnoYr(1, True)
   qUrl = self.VVYavd(self.VVHUvD, row[6])
   txt, err = self.VVkQUQ(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVqlay(item, "auth") == "0":
       VVxeRf.VVxy84.append(qUrl)
    except:
     pass
 def VVyU3G(self, VV7mD9, path, VVgl66, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if VV1FXh:
   list = VVxy84
   title = "Authorized Servers"
   if list:
    totChk = VVgl66.VVFbUd()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFvXEJ()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVX1vg(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFivHt(str(totAuth), VVd7n9)
     txt += "%s\n\n%s"    %  (FFivHt("Result File:", VVhb13), newPath)
     FFucjH(self, txt, title=title)
     VVgl66.close()
     VV7mD9.close()
    else:
     FF5kkM(self, "All URLs are authorized.", title=title)
   else:
    FF2zEl(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVkQUQ(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVETwG(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVhDYU(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCuwo1.VVTrvd()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVjCHm(decodedUrl):
  return CCA7uK.VVhDYU(decodedUrl, justRetDotExt=True)
 def VVYavd(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVETwG(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVHUvD   : return "%s"            % url
  elif mode == self.VVNrYr   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVSd85   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV1ys5  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV0XTn  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVRB9l : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVrWyY   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVxI0f    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVuk12  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VViZrq : return "%s&action=get_live_streams"      % url
  elif mode == self.VVlG1U  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVqlay(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFwVZA(int(val))
    elif is_base64 : val = FFElMG(val)
    elif isToHHMMSS : val = FFz41A(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVA4iX(self, title, path):
  if fileExists(path):
   enc = CCCXVP.VVwlwm(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCA7uK.VVGGz5(line)
     if qUrl:
      break
   if qUrl : self.VVbXEQ(title, qUrl)
   else : FF2zEl(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF2zEl(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVMOnt(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCA7uK.VV2C8j(self)
  if qUrl or "chCode" in iptvRef:
   p = CCbrHa()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVNkab(iptvRef)
   if valid:
    self.VVhSrZ(self, host, mac)
    return
   elif qUrl:
    FF3LD6(self, BF(self.VVbXEQ, title, qUrl), title="Checking Server ...")
    return
  FF2zEl(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VV2C8j(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF)
  qUrl = CCA7uK.VVGGz5(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVGGz5(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVbXEQ(self, title, url):
  self.curUrl = url
  self.VVMt5LData = {}
  qUrl = self.VVYavd(self.VVHUvD, url)
  txt, err = self.VVkQUQ(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVMt5LData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVMt5LData["username"    ] = self.VVqlay(item, "username"        )
    self.VVMt5LData["password"    ] = self.VVqlay(item, "password"        )
    self.VVMt5LData["message"    ] = self.VVqlay(item, "message"        )
    self.VVMt5LData["auth"     ] = self.VVqlay(item, "auth"         )
    self.VVMt5LData["status"    ] = self.VVqlay(item, "status"        )
    self.VVMt5LData["exp_date"    ] = self.VVqlay(item, "exp_date"    , isDate=True )
    self.VVMt5LData["is_trial"    ] = self.VVqlay(item, "is_trial"        )
    self.VVMt5LData["active_cons"   ] = self.VVqlay(item, "active_cons"       )
    self.VVMt5LData["created_at"   ] = self.VVqlay(item, "created_at"   , isDate=True )
    self.VVMt5LData["max_connections"  ] = self.VVqlay(item, "max_connections"      )
    self.VVMt5LData["allowed_output_formats"] = self.VVqlay(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVMt5LData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVMt5LData["url"    ] = self.VVqlay(item, "url"        )
    self.VVMt5LData["port"    ] = self.VVqlay(item, "port"        )
    self.VVMt5LData["https_port"  ] = self.VVqlay(item, "https_port"      )
    self.VVMt5LData["server_protocol" ] = self.VVqlay(item, "server_protocol"     )
    self.VVMt5LData["rtmp_port"   ] = self.VVqlay(item, "rtmp_port"       )
    self.VVMt5LData["timezone"   ] = self.VVqlay(item, "timezone"       )
    self.VVMt5LData["timestamp_now"  ] = self.VVqlay(item, "timestamp_now"  , isDate=True )
    self.VVMt5LData["time_now"   ] = self.VVqlay(item, "time_now"       )
    VVgsyy  = self.VVfE3b(True)
    VVwWMp = self.VVFtY3
    VVxQ85 = self.VVgATY
    VVbSf3 = ("Home Menu", FF90Z9)
    VVOmbd= ("Add to Menu", BF(CCA7uK.VVW9QT, self, False, self.VVMt5LData["playListURL"]))
    VVtL1m = ("Bookmark Server", BF(CCA7uK.VV9Qil, self, False, self.VVMt5LData["playListURL"]))
    FFCO3u(self, None, title="IPTV Server Resources", VVgsyy=VVgsyy, VVwWMp=VVwWMp, VVxQ85=VVxQ85, VVbSf3=VVbSf3, VVOmbd=VVOmbd, VVtL1m=VVtL1m)
   else:
    err = "Could not get data from server !"
  if err:
   FF2zEl(self, err, title=title)
  FFRB11(self)
 def VVFtY3(self, item=None):
  if item:
   VVyxPv, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF3LD6(VVyxPv, BF(self.VVpaB2, self.VVNrYr  , title=title), title=wTxt)
   elif ref == "vod"   : FF3LD6(VVyxPv, BF(self.VVpaB2, self.VVSd85  , title=title), title=wTxt)
   elif ref == "series"  : FF3LD6(VVyxPv, BF(self.VVpaB2, self.VV1ys5 , title=title), title=wTxt)
   elif ref == "catchup"  : FF3LD6(VVyxPv, BF(self.VVpaB2, self.VV0XTn , title=title), title=wTxt)
   elif ref == "accountInfo" : FF3LD6(VVyxPv, BF(self.VVPWKC           , title=title), title=wTxt)
 def VVgATY(self, VVyxPv, txt, ref, ndx):
  FF3LD6(VVyxPv, self.VVGZCS)
 def VVGZCS(self):
  txt = self.curUrl
  if VVmTYx:
   ver, err = self.VV8LNL(self.VVT8g3())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVSqEM
   txt += "PHP\t: %s\n"  % self.VVBjHt
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVo9tr, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFucjH(self, txt, title="Current Server URL")
 def VVPWKC(self, title):
  rows = []
  for key, val in self.VVMt5LData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVGD0r
   else:
    num, part = "1", self.VVwqYY
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVTaaj  = ("Home Menu", FF90Z9, [])
  VV6LI6  = None
  if VVmTYx:
   VV6LI6 = ("Get JS" , BF(self.VVNL9Y, "/".join(self.VVMt5LData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFyrIU(self, None, title=title, width=1200, header=header, VVX3UR=rows, VVBL0l=widths, VVJA7R=26, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVBBM8="#0a00292B", VVa80e="#0a002126", VVaOdk="#0a002126", VVlVSy="#00000000", searchCol=2)
 def VVHmMK(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVrWyY, self.VVlG1U):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVqlay(item, "num"         )
      name     = self.VVqlay(item, "name"        )
      stream_id    = self.VVqlay(item, "stream_id"       )
      stream_icon    = self.VVqlay(item, "stream_icon"       )
      epg_channel_id   = self.VVqlay(item, "epg_channel_id"      )
      added     = self.VVqlay(item, "added"    , isDate=True )
      is_adult    = self.VVqlay(item, "is_adult"       )
      category_id    = self.VVqlay(item, "category_id"       )
      tv_archive    = self.VVqlay(item, "tv_archive"       )
      direct_source   = self.VVqlay(item, "direct_source"      )
      tv_archive_duration  = self.VVqlay(item, "tv_archive_duration"     )
      name = self.VVqpv6(name, is_adult)
      if name:
       if mode == self.VVrWyY or mode == self.VVlG1U and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVxI0f:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVqlay(item, "num"         )
      name    = self.VVqlay(item, "name"        )
      stream_id   = self.VVqlay(item, "stream_id"       )
      stream_icon   = self.VVqlay(item, "stream_icon"       )
      added    = self.VVqlay(item, "added"    , isDate=True )
      is_adult   = self.VVqlay(item, "is_adult"       )
      category_id   = self.VVqlay(item, "category_id"       )
      container_extension = self.VVqlay(item, "container_extension"     ) or "mp4"
      name = self.VVqpv6(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVuk12:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVqlay(item, "num"        )
      name    = self.VVqlay(item, "name"       )
      series_id   = self.VVqlay(item, "series_id"      )
      cover    = self.VVqlay(item, "cover"       )
      genre    = self.VVqlay(item, "genre"       )
      episode_run_time = self.VVqlay(item, "episode_run_time"    )
      category_id   = self.VVqlay(item, "category_id"      )
      container_extension = self.VVqlay(item, "container_extension"    ) or "mp4"
      name = self.VVqpv6(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVpaB2(self, mode, title):
  cList, err = self.VVPdL2(mode)
  if cList and mode == self.VV0XTn:
   cList = self.VVFlIn(cList)
  if err:
   FF2zEl(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs(mode)
   mName = self.VVH30v(mode)
   if   mode == self.VVNrYr  : fMode = self.VVrWyY
   elif mode == self.VVSd85  : fMode = self.VVxI0f
   elif mode == self.VV1ys5 : fMode = self.VVuk12
   elif mode == self.VV0XTn : fMode = self.VVlG1U
   if mode == self.VV0XTn:
    VVH4Z8 = None
    VVmhJa = None
   else:
    VVH4Z8 = ("Find in %s" % mName , BF(self.VVX6no, fMode, True) , [])
    VVmhJa = ("Find in Selected" , BF(self.VVX6no, fMode, False) , [])
   VVkkpG   = ("Show List"   , BF(self.VVWcfV, mode)  , [])
   VVTaaj  = ("Home Menu"   , FF90Z9         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFyrIU(self, None, title=title, width=1200, header=header, VVX3UR=cList, VVBL0l=widths, VVJA7R=30, VVTaaj=VVTaaj, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVkkpG=VVkkpG, VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVaOdk, VVlVSy=VVlVSy, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF2zEl(self, "No list from server !", title=title)
  FFRB11(self)
 def VVPdL2(self, mode):
  qUrl  = self.VVYavd(mode, self.VVMt5LData["playListURL"])
  txt, err = self.VVkQUQ(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVqlay(item, "category_id"  )
     category_name = self.VVqlay(item, "category_name" )
     parent_id  = self.VVqlay(item, "parent_id"  )
     category_name = self.VVm5as(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVFlIn(self, catList):
  mode  = self.VVlG1U
  qUrl  = self.VVYavd(mode, self.VVMt5LData["playListURL"])
  txt, err = self.VVkQUQ(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVHmMK(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVWcfV(self, mode, VVgl66, title, txt, colList):
  title = colList[1]
  FF3LD6(VVgl66, BF(self.VVWDZj, mode, VVgl66, title, txt, colList), title="Downloading ...")
 def VVWDZj(self, mode, VVgl66, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVH30v(mode) + " : "+ bName
  if   mode == self.VVNrYr  : mode = self.VVrWyY
  elif mode == self.VVSd85  : mode = self.VVxI0f
  elif mode == self.VV1ys5 : mode = self.VVuk12
  elif mode == self.VV0XTn : mode = self.VVlG1U
  qUrl  = self.VVYavd(mode, self.VVMt5LData["playListURL"], catID)
  txt, err = self.VVkQUQ(qUrl)
  list  = []
  if not err and mode in (self.VVrWyY, self.VVxI0f, self.VVuk12, self.VVlG1U):
   list, err = self.VVHmMK(mode, txt)
  if err:
   FF2zEl(self, err, title=title)
  elif list:
   VVTaaj  = ("Home Menu"   , FF90Z9            , [])
   if mode in (self.VVrWyY, self.VVlG1U):
    VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs(mode)
    VVPn7Q = (""     , BF(self.VV2Cha, mode)      , [])
    VV6LI6 = ("Download Options" , BF(self.VVXz5G, mode, "", "")   , [])
    VVH4Z8 = ("Options"   , BF(self.VVcsCS, "lv", mode, bName)   , [])
    VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, False)     , [])
    if mode == self.VVrWyY:
     VVkkpG = ("Play"    , BF(self.VVaaC3, mode)       , [])
    else:
     VVkkpG = ("Programs"   , BF(self.VVhucq, mode, bName) , [])
   elif mode == self.VVxI0f:
    VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs(mode)
    VVkkpG  = ("Play"    , BF(self.VVaaC3, mode)       , [])
    VVPn7Q = (""     , BF(self.VV2Cha, mode)      , [])
    VV6LI6 = ("Download Options" , BF(self.VVXz5G, mode, "v", "")   , [])
    VVH4Z8 = ("Options"   , BF(self.VVcsCS, "v", mode, bName)   , [])
    VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, False)     , [])
   elif mode == self.VVuk12:
    VVBBM8, VVa80e, VVaOdk, VVlVSy = self.VVVoHs("series2")
    VVkkpG  = ("Show Seasons"  , BF(self.VVXhb0, mode)       , [])
    VVPn7Q = (""     , BF(self.VVBb8O, mode)     , [])
    VV6LI6 = None
    VVH4Z8 = None
    VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, True)      , [])
   header, widths, VV8zKo = self.VVM2HR(mode)
   FFyrIU(self, None, title=title, header=header, VVX3UR=list, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindIptv, VVPn7Q=VVPn7Q, VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVaOdk, VVlVSy=VVlVSy, VVMXk9=True, searchCol=1)
  else:
   FF2zEl(self, "No Channels found !", title=title)
  FFRB11(self)
 def VVM2HR(self, mode):
  if mode in (self.VVrWyY, self.VVlG1U):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VV8zKo  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVxI0f:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VV8zKo  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVuk12:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VV8zKo  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VV8zKo
 def VVhucq(self, mode, bName, VVgl66, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVMt5LData["playListURL"]
  ok_fnc  = BF(self.VVDYt2, hostUrl, chName, catId, streamId)
  FF3LD6(VVgl66, BF(CCA7uK.VVAHPb, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVDYt2(self, chUrl, chName, catId, streamId, VVgl66, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCA7uK.VVETwG(chUrl)
   chNum = "333"
   refCode = CCA7uK.VVzFtp(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFQhSW(self, chUrl, VVehU2=False)
   CCC5bX.VVBgB6(self.session)
  else:
   FF2zEl(self, "Incorrect Timestamp", pTitle)
 def VVXhb0(self, mode, VVgl66, title, txt, colList):
  title = colList[1]
  FF3LD6(VVgl66, BF(self.VVk63s, mode, VVgl66, title, txt, colList), title="Downloading ...")
 def VVk63s(self, mode, VVgl66, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVYavd(self.VVRB9l, self.VVMt5LData["playListURL"], series_id)
  txt, err = self.VVkQUQ(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVqlay(tDict["info"], "name"   )
      category_id = self.VVqlay(tDict["info"], "category_id" )
      icon  = self.VVqlay(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVqlay(EP, "id"     )
        episode_num   = self.VVqlay(EP, "episode_num"   )
        epTitle    = self.VVqlay(EP, "title"     )
        container_extension = self.VVqlay(EP, "container_extension" )
        seasonNum   = self.VVqlay(EP, "season"    )
        epTitle = self.VVqpv6(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF2zEl(self, err, title=title)
  elif list:
   VVTaaj = ("Home Menu"   , FF90Z9          , [])
   VV6LI6 = ("Download Options" , BF(self.VVXz5G, mode, "s", title), [])
   VVH4Z8 = ("Options"   , BF(self.VVcsCS, "s", mode, title) , [])
   VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, False)   , [])
   VVPn7Q = (""     , BF(self.VV2Cha, mode)    , [])
   VVkkpG  = ("Play"    , BF(self.VVaaC3, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV8zKo  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFyrIU(self, None, title=title, header=header, VVX3UR=list, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, lastFindConfigObj=CFG.lastFindIptv, VVBBM8="#0a00292B", VVa80e="#0a002126", VVaOdk="#0a002126", VVlVSy="#00000000")
  else:
   FF2zEl(self, "No Channels found !", title=title)
  FFRB11(self)
 def VVX6no(self, mode, isAll, VVgl66, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVgsyy = []
  VVgsyy.append(("Keyboard"  , "manualEntry"))
  VVgsyy.append(("From Filter" , "fromFilter"))
  FFCO3u(self, BF(self.VVzqz8, VVgl66, mode, onlyCatID), title="Input Type", VVgsyy=VVgsyy, width=400)
 def VVzqz8(self, VVgl66, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF7lc9(self, BF(self.VV1LT3, VVgl66, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCBykx(self)
    filterObj.VVjDje(BF(self.VV1LT3, VVgl66, mode, onlyCatID))
 def VV1LT3(self, VVgl66, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFH7ga(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCBykx.VVVM3i(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FF2zEl(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FF2zEl(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVQrJA(words):
      FF2zEl(self, self.VVXhfd(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCNT6G, barTheme=CCNT6G.VVQKW9
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVAYJd, VVgl66, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVRlGe = BF(self.VVyz0N, mode, toFind, title))
   if not words:
    FFRB11(VVgl66, "Nothing to find !", 1500)
 def VVAYJd(self, VVgl66, mode, onlyCatID, title, words, toFind, asPrefix, VVxeRf):
  VVxeRf.VVPZSN(VVgl66.VVpibS() if onlyCatID is None else 1)
  VVxeRf.VVxy84 = []
  for row in VVgl66.VV3eCu():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVnoYr(1)
   VVxeRf.VV4dOP(catName)
   qUrl  = self.VVYavd(mode, self.VVMt5LData["playListURL"], catID)
   txt, err = self.VVkQUQ(qUrl)
   if not err:
    tList, err = self.VVHmMK(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVqpv6(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVxeRf or VVxeRf.isCancelled:
        return
       VVxeRf.VVxy84.append(item)
       VVxeRf.VV4dOP(catName)
 def VVyz0N(self, mode, toFind, title, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if VVxy84:
   title = self.VVsvAK(mode, toFind)
   if mode == self.VVrWyY or mode == self.VVxI0f:
    if mode == self.VVxI0f : typ = "v"
    else          : typ = ""
    bName   = CCA7uK.VV84lT(toFind)
    VVkkpG  = ("Play"     , BF(self.VVaaC3, mode)     , [])
    VV6LI6 = ("Download Options" , BF(self.VVXz5G, mode, typ, "") , [])
    VVH4Z8 = ("Options"   , BF(self.VVcsCS, "fnd", mode, bName), [])
    VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, False)   , [])
    VVPn7Q = (""     , BF(self.VV2Cha, mode)    , [])
   elif mode == self.VVuk12:
    VVkkpG  = ("Show Seasons"  , BF(self.VVXhb0, mode)     , [])
    VVH4Z8 = None
    VV6LI6 = None
    VVmhJa = ("Posters Mode"  , BF(self.VVbxAx, mode, True)    , [])
    VVPn7Q = (""     , BF(self.VVBb8O, mode)   , [])
   VVTaaj  = ("Home Menu"   , FF90Z9          , [])
   header, widths, VV8zKo = self.VVM2HR(mode)
   VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVxy84, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVPn7Q=VVPn7Q, VVBBM8="#0a00292B", VVa80e="#0a002126", VVaOdk="#0a002126", VVlVSy="#00000000", VVMXk9=True, searchCol=1)
   if not VV1FXh:
    FFRB11(VVgl66, "Stopped" , 1000)
  else:
   if VV1FXh:
    FF2zEl(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVywew(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVrWyY, self.VVlG1U):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVxI0f:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFkgYM(chName)
  url = self.VVMt5LData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVETwG(url)
  refCode = self.VVzFtp(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV2Cha(self, mode, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVy9ct, mode, VVgl66, title, txt, colList))
 def VVy9ct(self, mode, VVgl66, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVywew(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFBxYU(self, fncMode=CCTzTd.VVf4Mv, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVBb8O(self, mode, VVgl66, title, txt, colList):
  FF3LD6(VVgl66, BF(self.VVFjpL, mode, VVgl66, title, txt, colList))
 def VVFjpL(self, mode, VVgl66, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFBxYU(self, fncMode=CCTzTd.VVZwZl, chName=name, text=txt, picUrl=Cover)
 def VVbxAx(self, mode, isSerNames, VVgl66, title, txt, colList):
  if   mode in ("itv"  , CCA7uK.VVrWyY, CCA7uK.VVlG1U): category = "live"
  elif mode in ("vod"  , CCA7uK.VVxI0f )          : category = "vod"
  elif mode in ("series" , CCA7uK.VVuk12)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVrWyY : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVlG1U : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVxI0f  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVuk12 : picCol, descCol, descTxt = 5, 0, "Season"
  FF3LD6(VVgl66, BF(self.session.open, CCdynj, VVgl66, category, nameCol, picCol, descCol, descTxt))
 def VVXz5G(self, mode, typ, seriesName, VVgl66, title, txt, colList):
  VVgsyy = []
  isMulti = VVgl66.VVIa5A
  tot  = VVgl66.VVGnLM()
  if isMulti:
   if tot < 1:
    FFRB11(VVgl66, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVgsyy.append(("Download %s PIcon%s" % (name, FFZevi(tot)), "dnldPicons" ))
  if typ:
   VVgsyy.append(VVzHzv)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVgsyy.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVgsyy.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVgsyy.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCS6qp.VVnPmJ():
    VVgsyy.append(VVzHzv)
    VVgsyy.append(("Download Manager"      , "dload_stat" ))
  FFCO3u(self, BF(self.VVmpva, VVgl66, mode, typ, seriesName, colList), title="Download Options", VVgsyy=VVgsyy)
 def VVmpva(self, VVgl66, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVP7EG(VVgl66, mode)
   elif item == "dnldSel"  : self.VVlLZ3(VVgl66, mode, typ, colList, True)
   elif item == "addSel"  : self.VVlLZ3(VVgl66, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVVqVk(VVgl66, mode, typ, seriesName)
   elif item == "dload_stat" : CCS6qp.VVKwKj(self, VVgl66)
 def VVlLZ3(self, VVgl66, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVqPDZ(mode, typ, colList)
  if startDnld:
   CCS6qp.VVlmci(self, decodedUrl)
  else:
   self.VVC0p8(VVgl66, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVVqVk(self, VVgl66, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVgl66.VV3eCu():
   chName, decodedUrl = self.VVqPDZ(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVC0p8(VVgl66, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVC0p8(self, VVgl66, title, chName, decodedUrl_list, startDnld):
  FFZnVu(self, BF(self.VVsMjf, VVgl66, decodedUrl_list, startDnld), chName, title=title)
 def VVsMjf(self, VVgl66, decodedUrl_list, startDnld):
  added, skipped = CCS6qp.VVLvrE(decodedUrl_list)
  FFRB11(VVgl66, "Added", 1000)
 def VVqPDZ(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVywew(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVzpbx(mode, colList)
   refCode, chUrl = self.VV6v9u(self.VVSqEM, self.VVCDPD, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFzxaC(chUrl)
  return chName, decodedUrl
 def VVP7EG(self, VVgl66, mode):
  if FFwmhG("ffmpeg"):
   self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVoVv6, VVgl66, mode)
       , VVRlGe = self.VVGCZ4)
  else:
   FFZnVu(self, BF(CCA7uK.VVLWn1, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVGCZ4(self, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVxy84["proces"], VVxy84["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVxy84["ok"], VVxy84["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVxy84["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVxy84["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVxy84["badURL"]
  txt += "Download Failure\t: %d\n"   % VVxy84["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVxy84["path"]
  if not VV1FXh  : color = "#11402000"
  elif VVxy84["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVxy84["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVxy84["err"], txt)
  title = "PIcons Download Result"
  if not VV1FXh:
   title += "  (cancelled)"
  FFucjH(self, txt, title=title, VVaOdk=color)
 def VVoVv6(self, VVgl66, mode, VVxeRf):
  isMulti = VVgl66.VVIa5A
  if isMulti : totRows = VVgl66.VVGnLM()
  else  : totRows = VVgl66.VVpibS()
  VVxeRf.VVPZSN(totRows)
  VVxeRf.VVNxjs(0)
  counter     = VVxeRf.counter
  maxValue    = VVxeRf.maxValue
  pPath     = CC0NDf.VVqbLc()
  VVxeRf.VVxy84 = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVgl66.VV3eCu()):
    if VVxeRf.isCancelled:
     break
    if not isMulti or VVgl66.VV8P9i(rowNum):
     VVxeRf.VVxy84["proces"] += 1
     VVxeRf.VVnoYr(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVzpbx(mode, row)
      refCode = CCA7uK.VVzFtp(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVRHBM(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVywew(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVxeRf.VVxy84["attempt"] += 1
       path, err = FFZXhR(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVxeRf:
         VVxeRf.VVxy84["ok"] += 1
         VVxeRf.VVNxjs(VVxeRf.VVxy84["ok"])
        if FFQfFR(path) > 0:
         cmd = CCTzTd.VVi3sm(path)
         cmd += FFT1jM("mv -f '%s' '%s'" % (path, pPath))
         FFlh8N(cmd)
        else:
         if VVxeRf:
          VVxeRf.VVxy84["size0"] += 1
         FFAFdq(path)
       elif err:
        if VVxeRf:
         VVxeRf.VVxy84["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVxeRf:
          VVxeRf.VVxy84["err"] = err.title()
         break
      else:
       if VVxeRf:
        VVxeRf.VVxy84["exist"] += 1
     else:
      if VVxeRf:
       VVxeRf.VVxy84["badURL"] += 1
  except:
   pass
 def VVIZxN(self):
  title = "Download PIcons for Current Bouquet"
  if FFwmhG("ffmpeg"):
   self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
       , titlePrefix = ""
       , fncToRun  = self.VV0dIk
       , VVRlGe = BF(self.VVw8iD, title))
  else:
   FFZnVu(self, BF(CCA7uK.VVLWn1, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VV0dIk(self, VVxeRf):
  bName = CCqHUu.VVy1MN()
  pPath = CC0NDf.VVqbLc()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVxeRf.VVxy84 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCqHUu.VVeLhz()
  if not VVxeRf or VVxeRf.isCancelled:
   return
  if not services or len(services) == 0:
   VVxeRf.VVxy84 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVxeRf.VVPZSN(totCh)
  VVxeRf.VVNxjs(0)
  for serv in services:
   if not VVxeRf or VVxeRf.isCancelled:
    return
   VVxeRf.VVxy84 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVxeRf.VVnoYr(1)
   VVxeRf.VVNxjs(totPic)
   fullRef  = serv[0]
   if FFH7Or(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFzxaC(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCbrHa.VVc7Oc(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCA7uK.VVhDYU(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCA7uK.VVkQUQ(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCTzTd.VVFhG3(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFZXhR(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVxeRf:
     VVxeRf.VVNxjs(totPic)
    if FFQfFR(path) > 0:
     cmd = CCTzTd.VVi3sm(path)
     cmd += FFT1jM("mv -f '%s' '%s'" % (path, pPath))
     FFlh8N(cmd)
     totPicOK += 1
    else:
     totSize0
     FFAFdq(path)
  if VVxeRf:
   VVxeRf.VVxy84 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVw8iD(self, title, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVxy84
  if err:
   FF2zEl(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFivHt(str(totExist)  , VVL6GV)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFivHt(str(totNotIptv)  , VVL6GV)
    if totServErr : txt += "Server Errors\t: %s\n" % FFivHt(str(totServErr) + t1, VVL6GV)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFivHt(str(totParseErr) , VVL6GV)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFivHt(str(totInvServ)  , VVL6GV)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFivHt(str(totInvPicUrl) , VVL6GV)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFivHt(str(totSize0)  , VVL6GV)
   if not VV1FXh:
    title += "  (stopped)"
   FFucjH(self, txt, title=title)
 @staticmethod
 def VVLWn1(SELF):
  cmd = FFcDAv(VV58Rq, "ffmpeg")
  if cmd : FFyAzl(SELF, cmd, title="Installing FFmpeg")
  else : FFjIcG(SELF)
 @staticmethod
 def VVH3cl(SELF):
  SELF.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2
      , titlePrefix = ""
      , fncToRun  = CCA7uK.VVBADu
      , VVRlGe = BF(CCA7uK.VVTEem, SELF))
 @staticmethod
 def VVBADu(VVxeRf):
  bName = CCqHUu.VVy1MN()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVxeRf.VVxy84 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCqHUu.VVeLhz()
  if not VVxeRf or VVxeRf.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVxeRf.VVPZSN(totCh)
   for serv in services:
    if not VVxeRf or VVxeRf.isCancelled:
     return
    VVxeRf.VVnoYr(1)
    fullRef = serv[0]
    if FFH7Or(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFzxaC(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCbrHa.VVfw4J(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCA7uK.VVhDYU(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCA7uK.VVswBk(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVxeRf:
      VVxeRf.VVfmtR(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCje5B.VVPx5z(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVxeRf:
     VVxeRf.VVxy84 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVxeRf.VVxy84 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVTEem(SELF, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVxy84
  title = "IPTV EPG Import"
  if err:
   FF2zEl(SELF, err, title=title)
  else:
   if VV1FXh and totEpgOK > 0:
    CCje5B.VV2HnN()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFivHt(str(totNotIptv), VVL6GV)
    if totServErr : txt += "Server Errors\t: %s\n" % FFivHt(str(totServErr) + t1, VVL6GV)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFivHt(str(totInv), VVL6GV)
   if not VV1FXh:
    title += "  (stopped)"
   FFucjH(SELF, txt, title=title)
 @staticmethod
 def VVswBk(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCA7uK.VVETwG(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCA7uK.VVkQUQ(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCA7uK.VVqlay(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCA7uK.VVqlay(item, "lang"        ).upper()
    now_playing   = CCA7uK.VVqlay(item, "now_playing"      )
    start    = CCA7uK.VVqlay(item, "start"        )
    start_timestamp  = CCA7uK.VVqlay(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCA7uK.VVqlay(item, "start_timestamp"     )
    stop_timestamp  = CCA7uK.VVqlay(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCA7uK.VVqlay(item, "stop_timestamp"      )
    tTitle    = CCA7uK.VVqlay(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVzFtp(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCA7uK.VV2rJX(catID, MAX_4b)
  TSID = CCA7uK.VV2rJX(chNum, MAX_4b)
  ONID = CCA7uK.VV2rJX(chNum, MAX_4b)
  NS  = CCA7uK.VV2rJX(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VV2rJX(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV84lT(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVVoHs(mode):
  if   mode in ("itv"  , CCA7uK.VVNrYr)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCA7uK.VVSd85)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCA7uK.VV1ys5) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCA7uK.VV0XTn) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCA7uK.VVlG1U    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VV2ytn(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVNY3V:
   excl = FFcVVX(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FF2zEl(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFIeeK('find %s %s %s' % (path, excl, par))
  if files:
   err = CCxFIK.VVjWm9(files)
   if err : FF2zEl(self, err + FFivHt('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVhb13))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FF2zEl(self, err)
  return []
 @staticmethod
 def VVzrAp():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFZsCH(path)
  return "/"
 @staticmethod
 def VVAHPb(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCA7uK.VVswBk(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FF2zEl(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVBBM8, VVa80e, VVaOdk, VVlVSy = CCA7uK.VVVoHs("")
   VVTaaj = ("Home Menu" , FF90Z9, [])
   VVkkpG  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV8zKo  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFyrIU(SELF, None, title="Programs for : " + chName, header=header, VVX3UR=pList, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=24, VVkkpG=VVkkpG, VVTaaj=VVTaaj, VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVaOdk, VVlVSy=VVlVSy)
  else:
   FF2zEl(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVLfXf(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVW9QT(self, isPortal, line, VV7Q6fObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFZnVu(self, BF(self.VV2nvx, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFH7ga(confItem, line)
   FF5kkM(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV2nvx(self, title, confItem):
  FFH7ga(confItem, "")
  FF5kkM(self, "Removed from IPTV Menu.", title=title)
 def VVYmsE(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVhSrZ(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FF3LD6(self, BF(self.VVbXEQ, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FF2zEl(self, "Incorrect server data !")
 @staticmethod
 def VV9Qil(SELF, isPortal, line, VV7Q6fObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCA7uK.VVzrAp()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF2zEl(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF5kkM(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF2zEl(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVcsCS(self, source, mode, curBName, VVgl66, title, txt, colList):
  isMulti = VVgl66.VVIa5A
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVgl66.VVGnLM()
   totTxt = "%d Service%s" % (tot, FFZevi(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFivHt(totTxt, VVhb13)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCXfgt(self, VVgl66, addSep=False)
  thTxt = "Adding Services ..."
  VVgsyy, cbFncDict = [], None
  VVgsyy.append(VVzHzv)
  if itemsOK:
   VVgsyy.append(("Add %s to New Bouquet : %s"    % (totTxt, FFivHt(curBName , VVd7n9)), "addToCur1"))
   if curBName2: VVgsyy.append(("Add %s to New Bouquet : %s" % (totTxt, FFivHt(curBName2, VViC5D)) , "addToCur2"))
   VVgsyy.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FF3LD6, mSel.VVgl66, BF(self.VVjzfY,source, mode, curBName , VVgl66, title), title=thTxt)
      , "addToCur2": BF(FF3LD6, mSel.VVgl66, BF(self.VVjzfY,source, mode, curBName2, VVgl66, title), title=thTxt)
      , "addToNew" : BF(self.VVxqEr, source, mode, curBName, VVgl66, title)
      }
  else:
   VVgsyy.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVnFMb(VVgsyy, cbFncDict, width=1400)
 def VVjzfY(self, source, mode, curBName, VVgl66, Title):
  chUrlLst = self.VVqnc2(source, mode, VVgl66)
  CCqHUu.VVd5ae(self, Title, curBName, "", chUrlLst)
 def VVxqEr(self, source, mode, curBName, VVgl66, Title):
  picker = CCqHUu(self, VVgl66, Title, BF(self.VVqnc2, source, mode, VVgl66), defBName=curBName)
 def VVqnc2(self, source, mode, VVgl66):
  totChange = 0
  isMulti = VVgl66.VVIa5A
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVgl66.VV3eCu()):
   if not isMulti or VVgl66.VV8P9i(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVzpbx(mode, row)
     refCode, chUrl = self.VV6v9u(self.VVSqEM, self.VVCDPD, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVKOKj(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVywew(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVLNfs():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VV6ZB0():
  return sorted(tuple(CCA7uK.VVLNfs()))
 @staticmethod
 def VVRuwZ(rt):
  return CCA7uK.VVLNfs().get(str(rt), "")
 @staticmethod
 def VVKhAQ(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCA7uK.VVRuwZ(span.group(1)) if span else ""
 @staticmethod
 def VVHyGP(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVFs6h():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVgsyy = []
  for ndx, rt in enumerate(CCA7uK.VV6ZB0()):
   VVgsyy.append(FFDNao("%s\t... %s" % (CCA7uK.VVRuwZ(rt), rt), rt, CCA7uK.VVHyGP(rt), VVL7a3 if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVgsyy.append(VVzHzv)
  return VVgsyy
class CC6BVm(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVQdld(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFvobF(self.frm, frmColor)
  FFvobF(self.bak, bakColor)
  FFvobF(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVA3zG(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFGgcy(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCSUvI(CC6BVm):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CC6BVm.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VVjvan()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VV7SnD   ,
   "down" : self.VValPP  ,
   "left" : self.VVSzgb  ,
   "right" : self.VV7Npu  ,
   "next" : self.VVAKEH ,
   "last" : self.VVW9G8
  }, -1)
 def VVTu4U(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVQdld(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVItNC()
 def VVMJBL(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VV7SnD(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV93MR()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVvuSW()
 def VValPP(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVltoc()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVvuSW()
 def VVSzgb(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV93MR()
  else:
   self.curCol -= 1
   self.VVvuSW()
 def VV7Npu(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVltoc()
  else:
   self.curCol += 1
   self.VVvuSW()
 def VVW9G8(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVvuSW(oldPage != self.curPage)
 def VVAKEH(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVvuSW(oldPage != self.curPage)
 def VVltoc(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVvuSW(force)
 def VV93MR(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVvuSW(force)
 def VVvuSW(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV7psd = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV7psd: self.curPage = VV7psd
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVgJS5()
  self["myPiconPtr"].hide()
  self.VVA3zG(self.curPage + 1, self.totalPages)
  FFnB9O(BF(self.VVX78o, force or not oldPage == self.curPage, VV7psd))
 def VVX78o(self, force, VV7psd):
  try:
   if force:
    self.VVHPzQ()
   if self.curPage == VV7psd:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVgJS5()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
   self["myPiconPtr"].show()
  except:
   pass
  self["myPiconPtr"].show()
 def VV0p7H(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVvuSW(False if oldPage == self.curPage else True)
  else:
   FFRB11(self, "Not found", 1000)
 def VVFQJs(self):
  self.VV0p7H(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVvwuP(self):
  self["myPiconPtr"].hide()
 def VVjvan(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVkDNV(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVY1lH, CCNJZ7, defFG=fg, defBG=bg, onlyBG=True)
 def VVY1lH(self, fg, bg):
  if self.colorCfg and bg:
   FFH7ga(self.colorCfg, bg)
   self.VVItNC()
 def VVItNC(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFvobF(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVD3lg(self, lbl, txt, color=""):
  CCSUvI.VVlS7w(lbl, txt, color)
 @staticmethod
 def VVlS7w(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVGdWN(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCdynj(Screen, CCSUvI):
 def __init__(self, session, VVgl66, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFAm4L(VVw4no, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVgl66  = VVgl66
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVX3UR    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFNG7m(self, self.Title)
  CCSUvI.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVn5zG, subPath)
  if not pathExists(self.pPath):
   FFlh8N("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVMcMd    ,
   "cancel": self.close    ,
   "menu" : self.VVRcAb ,
   "info" : self.VVsw26  ,
   "0"  : self.VVFQJs
  })
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  FFzs4L(self)
  self.VVTu4U()
  self.VVPJtt()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVRcAb(self):
  chName, subj, desc, fName, picUrl = self.VVX3UR[self.curIndex]
  VVgsyy = []
  VVgsyy.append(FFDNao("Show Selected Picture"        , "VVFqBX"  , fName))
  VVgsyy.append(FFDNao("Copy Selected Picture to Export-Directory"   , "VVq70m" , fName))
  VVgsyy.append(FFDNao("Set Selected Picture as a Poster for a Local Media" , "VVlFTB", fName))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Cache details"       , "VVWplb"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change Poster/Picon Transparency Color" , "VVkDNV" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Help (Keys)"        , "help"     ))
  FFCO3u(self, self.VVJZ6a, title=self.Title, VVgsyy=VVgsyy)
 def VVJZ6a(self, item=None):
  if item is not None:
   if   item == "VVFqBX"   : self.VVFqBX()
   elif item == "VVq70m"   : self.VVq70m()
   elif item == "VVlFTB"  : self.VVlFTB()
   elif item == "VVWplb"  : FF3LD6(self, self.VVWplb, title="Calculating ...")
   elif item == "VVkDNV": self.VVkDNV()
   elif item == "help"     : FF6duf(self, "_help_servBr", "Server Browser (Keys)")
 def VVMcMd(self):
  self.VVgl66.VVICdA(self.curIndex)
  self.VVgl66.VVncK3()
 def VVsw26(self):
  self.VVgl66.VVICdA(self.curIndex)
  self.VVgl66.VVjK8t()
 def VVPJtt(self):
  for colList in self.VVgl66.VV3eCu():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVX3UR.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVX3UR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVgl66.VVKltF()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVvuSW(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVrNOr)
  except:
   self.timer.callback.append(self.VVrNOr)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVPpbY)
  self.myThread.start()
 def VVPpbY(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVX3UR):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFZXhR(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFlh8N("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVX3UR[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVrNOr(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVHEBa + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVX3UR[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVX3UR[ndx] = (chName, subj, desc, fName, "")
     CCSUvI.VVGdWN(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVHPzQ(self):
  self.VVjvan()
  f1, f2 = self.VVMJBL()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVX3UR[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVD3lg(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVV9bl + "iptv.png"
   CCSUvI.VVGdWN(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVgJS5(self):
  chName, subj, desc, fName, picUrl = self.VVX3UR[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVFqBX(self):
  chName, subj, desc, fName, picUrl = self.VVX3UR[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCslfl.VVIg0A(self, self.pPath + fName)
  else          : FFRB11(self, "File not found", 1500)
 def VVq70m(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVX3UR[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFlh8N("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FF5kkM(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FF2zEl(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FF2zEl(self, "No Poster/PIcon found", title=title)
 def VVlFTB(self):
  self.session.openWithCallback(self.VVhZ0u, BF(CCxFIK, patternMode="movies", VVn9uf=CFG.MovieDownloadPath.getValue()))
 def VVhZ0u(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVX3UR[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFlh8N("cp -f '%s' '%s'" % (srcF, dstF)):
     FF5kkM(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FF2zEl(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CC0Ist.VVDjkx(dstF)
   else:
    FF2zEl(self, "No Poster/PIcon found", title=title)
 def VVWplb(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVn5zG, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFU8jM("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCxFIK.VVe4Bo(size)
   txt += "%s\n    %s\n\n" % (FFivHt(path, VVhb13), size)
  mainPath = "%sPosters" % VVn5zG
  totFiles = FFU8jM("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFZevi(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFivHt("Total space used by Posters/PIcons%s:" % totFTxt, VVMdMA), CCxFIK.VVe4Bo(totSize))
  mountPath = CCxFIK.VV5UJg(mainPath)
  if pathExists(mountPath):
   totSize  = CCxFIK.VVf1LM(mountPath)
   freeSize = CCxFIK.VVZLIW(mountPath)
   usedSize = CCxFIK.VVe4Bo(totSize - freeSize)
   totSize  = CCxFIK.VVe4Bo(totSize)
   freeSize = CCxFIK.VVe4Bo(freeSize)
   txt += "%s\n" % SEP
   txt += FFivHt("Media Space:\n", VVAQIK)
   txt += "    Media Path\t: %s\n" % FFivHt(mountPath, VVVJaM)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFucjH(self, txt, title="Cache Used Size", height=1000)
class CC0Ist(Screen, CCSUvI):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFAm4L(VVlPyO, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVX3UR    = lst
  FFNG7m(self, self.Title)
  CCSUvI.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVMcMd    ,
   "cancel": self.close    ,
   "menu" : self.VVniu3 ,
   "info" : self.VVtayz  ,
   "0"  : self.VVFQJs
  })
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  FFzs4L(self)
  self.VVTu4U()
  self.totalItems = len(self.VVX3UR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvuSW(True)
 def VVHPzQ(self):
  self.VVjvan()
  f1, f2 = self.VVMJBL()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVX3UR[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVV9bl + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVD3lg(lbl, os.path.splitext(os.path.basename(path))[0])
   CCSUvI.VVGdWN(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVf4UY(self):
  path, movie, poster = self.VVX3UR[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVgJS5(self):
  path, poster = self.VVf4UY()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVniu3(self):
  path, poster = self.VVf4UY()
  VVgsyy = []
  VVgsyy.append(("Go to movie ...", "VVjFYL"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(FFDNao("Show Poster"      , "VVFqBX" , poster))
  VVgsyy.append(FFDNao("Copy Poster to Export-Directory" , "VVq70m", poster))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change Poster/Picon Transparency Color"  , "VVkDNV" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change Poster (from current movie path) ..." , "VVbmVO1"  ))
  VVgsyy.append(("Change Poster (locate manually) ..."   , "VVbmVO2"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Help (Keys)"         , "help"     ))
  FFCO3u(self, self.VVaWM2, title=self.Title, VVgsyy=VVgsyy)
 def VVaWM2(self, item=None):
  if item is not None:
   if   item == "VVjFYL"    : self.VVjFYL()
   elif item == "VVq70m"    : self.VVq70m()
   elif item == "VVFqBX"    : self.VVFqBX()
   elif item == "VVkDNV" : self.VVkDNV()
   elif item == "VVbmVO1"  : self.VVbmVO()
   elif item == "VVbmVO2"  : self.VVbmVO(True)
   elif item == "help"      : FF6duf(self, "_help_movBr", "Movies Browser (Keys)")
 def VVjFYL(self):
  VVX2QD = []
  for ndx, item in enumerate(self.VVX3UR):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVX2QD.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVX2QD.sort(key=lambda x: x[0].lower())
  VVkkpG = ("Select" , self.VVVT8P, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFyrIU(self, None, title="Select Movie", width=1800, height=1000, header=header, VVX3UR=VVX2QD, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, lastFindConfigObj=CFG.lastFindMovie)
 def VVVT8P(self, VVgl66, title, txt, colList):
  self.VV0p7H(int(colList[2].strip()))
  VVgl66.cancel()
 def VVMcMd(self):
  path, poster = self.VVf4UY()
  FF3LD6(self, BF(CCxFIK.VVB4hc, self, path), title="Playing Media ...")
 def VVtayz(self):
  path, poster = self.VVf4UY()
  txt = "%s:\n%s\n\n" % (FFivHt("Path", VVhb13), path)
  size = FFQfFR(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFivHt("File Size", VVhb13), CCxFIK.VVe4Bo(size))
  if poster:
   txt += "%s:\n%s" % (FFivHt("Poster", VVhb13), poster)
  FFucjH(self, txt, title="Media File Information")
 def VVFqBX(self):
  path, poster = self.VVf4UY()
  if fileExists(poster): CCslfl.VVIg0A(self, poster)
  else     : FFRB11(self, "No Poster", 1500)
 def VVq70m(self):
  title = "Copy Poster"
  path, poster = self.VVf4UY()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFlh8N("cp -f '%s' '%s'" % (poster, dstF)):
    FF5kkM(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FF2zEl(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFRB11(self, "No Poster", 1500)
 def VVbmVO(self, isManual=False):
  path, poster = self.VVf4UY()
  sDir = FFZsCH(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVg5Dh, sDir, path), BF(CCxFIK, patternMode="poster", VVn9uf=sDir))
  else:
   VVgsyy = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVgsyy.append((os.path.basename(item), sDir + item))
   if VVgsyy:
    VVgsyy.sort(key=lambda x: x[0].lower())
    VVxQ85 = self.VVeJX6
    FFCO3u(self, BF(self.VVg5Dh, sDir, path), VVgsyy=VVgsyy, title="Posters", VVxQ85=VVxQ85, VVGamv=sDir)
   else:
    FFRB11(self, "No jpg/png in current dir", 1500)
 def VVeJX6(self, VVyxPv, txt, ref, ndx):
  CCslfl.VVIg0A(self, VVBK02=ref)
 def VVg5Dh(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFlh8N("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVX3UR[self.curIndex] = (self.VVX3UR[self.curIndex][0], self.VVX3UR[self.curIndex][1], os.path.basename(newPath))
    FF3LD6(self, self.VVHPzQ)
    CC0Ist.VVDjkx(newPath)
   else:
    FFRB11(self, "Cannot copy file", 1000)
 @staticmethod
 def VVDjkx(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFlh8N("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVvMMZ(SELF):
  eLst = CCuwo1.VVTrvd()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CC0Ist, title, lst)
  else  : FF2zEl(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCblKT(Screen, CCSUvI):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFAm4L(VVVBB0, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVX3UR    = lst
  self.pPath    = CC0NDf.VVqbLc()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFNG7m(self, self.Title)
  FFTBJT(self["keyRed"] , "OK = Zap (Review)")
  FFTBJT(self["keyGreen"] , "Zap & Exit")
  FFTBJT(self["keyYellow"], "Find Current Service")
  CCSUvI.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVkXEJ, False),
   "cancel" : self.VVIvk9      ,
   "menu"  : self.VVPxRw   ,
   "red"  : self.VVIvk9      ,
   "green"  : BF(self.VVkXEJ, True) ,
   "yellow" : BF(self.VVcluT, True)  ,
   "0"   : self.VVFQJs
  })
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFfavv(self)
   FFzs4L(self)
   FFvobF(self["keyRed"], "#0a333333")
   self.VVTu4U()
  else:
   pName, srvLst = CCblKT.VVHajI()
   if srvLst and not srvLst == self.VVX3UR:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVX3UR = srvLst
   else:
    force = False
  self.totalItems = len(self.VVX3UR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvuSW(force)
  self.VVcluT()
 def VVPxRw(self):
  VVgsyy = []
  VVgsyy.append(("Find Name (sorted list)" , "findSrt"  ))
  VVgsyy.append(("Find Name (as listed)" , "findNoSrt"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Change Background Color" , "VVkDNV"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Help (Keys)", "help"))
  FFCO3u(self, self.VVKNUW, title="Options", VVgsyy=VVgsyy)
 def VVKNUW(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVfSFk(True)
   elif item == "findNoSrt"   : self.VVfSFk(False)
   elif item == "VVkDNV": self.VVkDNV()
   elif item == "help"     : FF6duf(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVfSFk(self, isSort):
  VVgsyy = []
  for ndx, item in enumerate(self.VVX3UR):
   VVgsyy.append((item[1], ndx))
  if isSort:
   VVgsyy.sort(key=lambda x: x[0].lower())
  FFCO3u(self, self.VVCK4S, title="Find Name", VVgsyy=VVgsyy, width=1300)
 def VVCK4S(self, ndx=None):
  if ndx is not None:
   self.VV0p7H(ndx)
 def VVIvk9(self):
  if self.shown: self.close()
  else   : self.show()
 def VVkXEJ(self, isExit):
  FF3LD6(self, BF(self.VVSPqR, isExit), title="Starting ...")
 def VVSPqR(self, isExit):
  try:
   if self.shown:
    FFQhSW(self, self.VVX3UR[self.curIndex][0], VVehU2=False)
    if isExit: self.close()
    else  : CCC5bX.VVBgB6(self.session)
   else:
    self.show()
  except:
   pass
 def VVcluT(self, VVnkcm=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVX3UR):
    if curRef == item[0]:
     self.VV0p7H(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVnkcm and err:
   FFRB11(self, err, 500)
  return -1
 def VVHPzQ(self):
  self.VVjvan()
  f1, f2 = self.VVMJBL()
  row = col = 0
  noPos = VVV9bl + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVX3UR[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVD3lg(lbl, name)
   path = CC0NDf.VVhOX3(self.pPath, ref, name) or noPos
   CCSUvI.VVGdWN(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVgJS5(self):
  ref, name = self.VVX3UR[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VV4Hr1():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VV15Ea = InfoBar.instance
  if VV15Ea:
   csel = VV15Ea.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFz86a(rootRef)
    refName  = FFz86a(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVHajI(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCblKT.VV4Hr1()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFlVIk(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCqHUu.VVeLhz()
   pName  = CCqHUu.VVy1MN() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVsrrs(SELF):
  pName, srvLst = CCblKT.VVHajI()
  if srvLst: SELF.session.open(CCblKT, pName, srvLst)
  else  : FF2zEl(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCBTkh(Screen, CCSUvI):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFAm4L(VV122f, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVX3UR    = CCBTkh.VV4AYl(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFNG7m(self, self.Title)
  FFTBJT(self["keyRed"] , "OK = Start Plugin")
  FFTBJT(self["keyYellow"], "Package Info.")
  FFTBJT(self["keyBlue"] , "Plugins Group")
  CCSUvI.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVfIUc   ,
   "cancel" : self.VVIvk9    ,
   "menu"  : self.VV9lG1 ,
   "info"  : self.VVp5Yf  ,
   "red"  : self.VVIvk9    ,
   "yellow" : BF(FF3LD6, self, self.VVdYKi),
   "blue"  : self.VVL3gF  ,
   "0"   : self.VVFQJs
  })
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  FFzs4L(self)
  FFvobF(self["keyRed"], "#0a333333")
  self.VVTu4U()
  self.totalItems = len(self.VVX3UR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvuSW(True)
 def VVIvk9(self):
  self.close()
 def VVfIUc(self):
  name, desc = self.VVfEUX(self.curIndex)
  if name == PLUGIN_NAME:
   FFRB11(self, "Already running.", 500)
  else:
   try:
    p = self.VVX3UR[self.curIndex]
    p(session=self.session)
   except:
    FF2zEl(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVp5Yf(self):
  def VVBMvF(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVX3UR[self.curIndex]
  txt = ""
  try:
   txt += VVBMvF("Path"  , p.path  )
   txt += VVBMvF("Description" , p.description )
   txt += VVBMvF("Icon"  , p.iconstr  )
   txt += VVBMvF("Wakeup Fnc" , p.wakeupfnc )
   txt += VVBMvF("NeedsRestart", p.needsRestart)
   txt += VVBMvF("Internal" , p.internal )
   txt += VVBMvF("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVfEUX(self.curIndex)
  if txt : FFucjH(self, txt, title=name)
  else : FF2zEl(self, "Could not read plugin info.", title=name)
 def VVdYKi(self):
  p = self.VVX3UR[self.curIndex]
  name, desc = self.VVfEUX(self.curIndex)
  path = p.path
  pkg, err = CC3nMC.VVwbHP(path)
  if pkg : CC3nMC.VV1q0o(self, pkg, name)
  else : FFKCVv(self, err, 1000)
 def VV9lG1(self):
  path = self.VVX3UR[self.curIndex].path
  VVgsyy = []
  txt = "Open Plugin Path in File Manager"
  VVgsyy.append(FFDNao("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Use Original Icon Size", "setOrigSize"))
  FFCO3u(self, self.VVdBtI, title="Plugins Group", VVgsyy=VVgsyy)
 def VVdBtI(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCxFIK, mode=CCxFIK.VVFKZ8, VVn9uf=self.VVX3UR[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVvuSW(True)
 def VVL3gF(self):
  FFCO3u(self, self.VV7oyB, title="Plugins Group", VVgsyy=CCBTkh.VVEciY(True, True), width=700, VVf67P=True)
 def VV7oyB(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCBTkh.VVwO88(where)
   if lst:
    self.VVX3UR = CCBTkh.VV4AYl(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVX3UR)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVvuSW(True)
   else:
    FF2zEl(self, "Not found !", title=self.Title)
 def VVHPzQ(self):
  self.VVjvan()
  f1, f2 = self.VVMJBL()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVfEUX(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVD3lg(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVX3UR[ndx].icon:
    try:
     pngSz = self.VVX3UR[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVX3UR[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVX3UR[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVV9bl + "plugin.png")
    for path in icons:
     pixMap = CCSUvI.VVGdWN(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVfEUX(self, ndx):
  name = str(self.VVX3UR[ndx].name).strip()
  desc = str(self.VVX3UR[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFSHhe(self.VVX3UR[ndx].path)
  return name, desc
 def VVgJS5(self):
  name, desc = self.VVfEUX(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVEciY(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCBTkh.VVwO88(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVrVS3, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVzHzv)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVwO88(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VV4AYl(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFSHhe(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVsrrs(SELF):
  title = "Plugins Browser"
  lst = CCBTkh.VVwO88(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCBTkh, title, lst)
  else : FF2zEl(SELF, "No plugins found !", title=title)
class CCkk2Z(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFAm4L(VVAfZq, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVWQo9  = 0
  self.VVibIk = 1
  self.VV1UMm  = 2
  VVgsyy = []
  VVgsyy.append(("Find in All Service (from filter)" , "VV0SIN" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Find in All (Manual Entry)"   , "VVCioL"    ))
  VVgsyy.append(("Find in TV"       , "VV8LT3"    ))
  VVgsyy.append(("Find in Radio"      , "VVhqGv"   ))
  if self.VVUAmw():
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Hide Channel: %s" % self.servName , "VVUJg5"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Zap History"       , "VVRVqb"    ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("IPTV Tools"       , "iptv"      ))
  VVgsyy.append(("PIcons Tools"       , "PIconsTools"     ))
  VVgsyy.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVgsyy.append(("EPG Tools"       , "epgTools"     ))
  FFNG7m(self, VVgsyy=VVgsyy, title=title)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self)
  if self.isFindMode:
   self.VVjbdH(self.VV4YhE())
 def VVMcMd(self):
  global VV6yYU
  VV6yYU = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVCioL"    : self.VVCioL()
   elif item == "VV0SIN" : self.VV0SIN()
   elif item == "VV8LT3"    : self.VV8LT3()
   elif item == "VVhqGv"   : self.VVhqGv()
   elif item == "VVUJg5"   : self.VVUJg5()
   elif item == "VVRVqb"    : self.VVRVqb()
   elif item == "iptv"       : self.session.open(CCA7uK)
   elif item == "PIconsTools"     : self.session.open(CC0NDf)
   elif item == "ChannelsTools"    : self.session.open(CCuZg4)
   elif item == "epgTools"      : self.session.open(CCje5B)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV8LT3(self) : self.VVjbdH(self.VVWQo9)
 def VVhqGv(self) : self.VVjbdH(self.VVibIk)
 def VVCioL(self) : self.VVjbdH(self.VV1UMm)
 def VVjbdH(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF7lc9(self, BF(self.VV9Fyn, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VV0SIN(self):
  filterObj = CCBykx(self)
  filterObj.VVjDje(self.VV1iIE)
 def VV1iIE(self, item):
  self.VV9Fyn(self.VV1UMm, item)
 def VVUAmw(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFH7Or(self.refCode)        : return False
  return True
 def VV9Fyn(self, mode, VVNM0w):
  FF3LD6(self, BF(self.VVCL4C, mode, VVNM0w), title="Searching ...")
 def VVCL4C(self, mode, VVNM0w):
  if VVNM0w:
   VVNM0w = VVNM0w.strip()
  if VVNM0w:
   self.findTxt = VVNM0w
   CFG.lastFindContextFind.setValue(VVNM0w)
   if   mode == self.VVWQo9  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVibIk : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVNM0w)
   if len(title) > 55:
    title = title[:55] + ".."
   VVX2QD = self.VVqf8C(VVNM0w, servTypes)
   if self.isFindMode or mode == self.VV1UMm:
    VVX2QD += self.VVrZhk(VVNM0w)
   if VVX2QD:
    VVX2QD.sort(key=lambda x: x[0].lower())
    VVZAcA = self.VVzMd9
    VVkkpG  = ("Zap"   , self.VV58Q4    , [])
    VV6LI6 = ("Current Service", self.VVwMc2 , [])
    VVH4Z8 = ("Options"  , self.VVOY6x , [])
    VVPn7Q = (""    , self.VVI68N , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV8zKo  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVZAcA=VVZAcA, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVPn7Q=VVPn7Q, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVjbdH(self.VV4YhE())
    FF5kkM(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVqf8C(self, VVNM0w, servTypes):
  VVX3UR = CCuZg4.VVJnoc(servTypes)
  VVX2QD = []
  if VVX3UR:
   VVdPgX, VVu9HV = FFcYq0()
   tp = CCgl59()
   words, asPrefix = CCBykx.VVVM3i(VVNM0w)
   colorYellow  = CCajWE.VVUSPc(VVMdMA)
   colorWhite  = CCajWE.VVUSPc(VVWK7B)
   for s in VVX3UR:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FF5v7R(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVdPgX:
        STYPE = VVu9HV[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVTyLz(refCode)
       if not "-S" in syst:
        sat = syst
       VVX2QD.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVX2QD
 def VVrZhk(self, VVNM0w):
  VVNM0w = VVNM0w.lower()
  VVX2QD = []
  colorYellow  = CCajWE.VVUSPc(VVMdMA)
  colorWhite  = CCajWE.VVUSPc(VVWK7B)
  for b in CCqHUu.VVVC9n():
   VVaDL0  = b[0]
   VVviB4  = b[1].toString()
   VVEjvG = eServiceReference(VVviB4)
   VVKIZS = FFlVIk(VVEjvG)
   for service in VVKIZS:
    refCode  = service[0]
    if FFH7Or(refCode):
     servName = service[1]
     if VVNM0w in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVNM0w), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVX2QD.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVX2QD
 def VV4YhE(self):
  VV15Ea = InfoBar.instance
  if VV15Ea:
   VVziWT = VV15Ea.servicelist
   if VVziWT:
    return VVziWT.mode == 1
  return self.VV1UMm
 def VVzMd9(self, VVgl66):
  self.close()
  VVgl66.cancel()
 def VV58Q4(self, VVgl66, title, txt, colList):
  FFQhSW(VVgl66, colList[2], VVehU2=False, checkParentalControl=True)
 def VVwMc2(self, VVgl66, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(VVgl66)
  if refCode:
   VVgl66.VVrpKV(2, FF49Rh(refCode, iptvRef, chName), True)
 def VVOY6x(self, VVgl66, title, txt, colList):
  servName = colList[0]
  mSel = CCXfgt(self, VVgl66)
  VVgsyy, cbFncDict = CCuZg4.VV9uI5(self, VVgl66, servName, 2)
  mSel.VVnFMb(VVgsyy, cbFncDict)
 def VVI68N(self, VVgl66, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFBxYU(self, fncMode=CCTzTd.VVrAmw, refCode=refCode, chName=chName, text=txt)
 def VVUJg5(self):
  FFZnVu(self, self.VVMBny, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVMBny(self):
  ret = FFMjJK(self.refCode, True)
  if ret:
   self.VVqvTx()
   self.close()
  else:
   FFRB11(self, "Cannot change state" , 1000)
 def VVqvTx(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVRyT6()
  except:
   self.VVDd3m()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFlfXr(self, serviceRef)
 def VVRyT6(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV15Ea = InfoBar.instance
   if VV15Ea:
    VVziWT = VV15Ea.servicelist
    if VVziWT:
     hList = VVziWT.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVziWT.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVziWT.history  = newList
       VVziWT.history_pos = pos
 def VVDd3m(self):
  VV15Ea = InfoBar.instance
  if VV15Ea:
   VVziWT = VV15Ea.servicelist
   if VVziWT:
    VVziWT.history  = []
    VVziWT.history_pos = 0
 def VVRVqb(self):
  VV15Ea = InfoBar.instance
  VVX2QD = []
  if VV15Ea:
   VVziWT = VV15Ea.servicelist
   if VVziWT:
    VVdPgX, VVu9HV = FFcYq0()
    for serv in VVziWT.history:
     refCode = serv[-1].toString()
     chName = FFz86a(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFH7Or(refCode)
     isSRel = FFTEln(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FF5v7R(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVdPgX:
       STYPE = VVu9HV[sTypeInt]
     VVX2QD.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVX2QD:
   VVkkpG  = ("Zap"   , self.VV9ftp   , [])
   VVH4Z8 = ("Clear History" , self.VVygLK   , [])
   VVPn7Q = (""    , self.VVXVEH , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV8zKo  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, VVkkpG=VVkkpG, VVH4Z8=VVH4Z8, VVPn7Q=VVPn7Q)
  else:
   FF5kkM(self, "History is empty.", title=title)
 def VV9ftp(self, VVgl66, title, txt, colList):
  FFQhSW(VVgl66, colList[3], VVehU2=False, checkParentalControl=True)
 def VVygLK(self, VVgl66, title, txt, colList):
  FFZnVu(self, BF(self.VV0XDL, VVgl66), "Clear Zap History ?")
 def VV0XDL(self, VVgl66):
  self.VVDd3m()
  VVgl66.cancel()
 def VVXVEH(self, VVgl66, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFBxYU(self, fncMode=CCTzTd.VVMkLw, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVs7p7():
  try:
   global VVvZeW
   if VVvZeW is None:
    VVvZeW    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCkk2Z.VVocKC
   ChannelContextMenu.VV2jpU = CCkk2Z.VV2jpU
  except:
   pass
 @staticmethod
 def VVocKC(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVvZeW(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   t = ( PLUGIN_NAME + " - Channels Browser"
    , PLUGIN_NAME + " - Find"
    , PLUGIN_NAME + " - Channels Tools"  )
   for i in range(3):
    SELF["menu"].list.insert(i, ChoiceEntryComponent(key=" ", text=(t[i] , BF(SELF.VV2jpU, t[i], csel, mode=i))))
 @staticmethod
 def VV2jpU(self, title, csel, mode):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFz86a(refCode)
  except:
   refCode = refName = ""
  if mode == 0: CCblKT.VVsrrs(self)
  else  : self.session.open(BF(CCkk2Z, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False))
  self.close()
class CC0NDf(Screen, CCSUvI, CCzN6y):
 VVzatq   = 0
 VVd5gM  = 1
 VVnm7c  = 2
 VVrUZK  = 3
 VVEXai  = 4
 VVGcX2  = 5
 VVEkoe  = 6
 VVbRb2  = 7
 VVcdaP = 8
 VVXGuR = 9
 VViUuA = 10
 VVeqlq = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVOOPZ, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CC0NDf.VVqbLc()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVX3UR    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFNG7m(self, self.Title)
  FFTBJT(self["keyRed"] , "OK = Zap")
  FFTBJT(self["keyGreen"] , "Current Service")
  FFTBJT(self["keyYellow"], "Page Options")
  FFTBJT(self["keyBlue"] , "Filter")
  CCSUvI.__init__(self, 5, 7, CFG.transpColorPicons)
  CCzN6y.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVb7x7     ,
   "green"  : self.VVp71X    ,
   "yellow" : self.VVBQjG     ,
   "blue"  : self.VVmYL2     ,
   "menu"  : self.VVhygq     ,
   "info"  : self.VVGlhz    ,
   "pageUp" : BF(self.VVf7L6, True) ,
   "chanUp" : BF(self.VVf7L6, True) ,
   "pageDown" : BF(self.VVf7L6, False) ,
   "chanDown" : BF(self.VVf7L6, False) ,
   "0"   : self.VVFQJs  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  FFzs4L(self)
  FFvobF(self["keyRed"], "#0a333333")
  self.VVTu4U()
  self.VVvwuP()
  FF3LD6(self, BF(self.VVTsCQ, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVhygq(self):
  if not self.isBusy:
   VVgsyy = []
   VVgsyy.append(("Statistics"           , "VVk49V"    ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Suggest PIcons for Current Channel"     , "VVw7cF"   ))
   VVgsyy.append(("Set to Current Channel (copy file)"     , "VVswpP_file"  ))
   VVgsyy.append(("Set to Current Channel (as SymLink)"     , "VVswpP_link"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Export Current File Names List"      , "VVrGu1" ))
   VVgsyy.append(CC0NDf.VVTrBv())
   VVgsyy.append(VVzHzv)
   c, cond = VVgmAg, self.filterTitle == "PIcons without Channels"
   VVgsyy.append(FFDNao("Move Unused PIcons to a Directory", "VVHxzd" , cond, c))
   VVgsyy.append(FFDNao("DELETE Unused PIcons"    , "VV0gxV" , cond, c))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VV9k8p"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy += CC0NDf.VVcjzm()
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Change Poster/Picon Transparency Color"    , "VVkDNV" ))
   VVgsyy.append(("Keys Help"           , "VVNwdU"    ))
   FFCO3u(self, self.VVTAf8, width=1100, height=1050, title=self.Title, VVgsyy=VVgsyy)
 def VVTAf8(self, item=None):
  if item is not None:
   if   item == "VVk49V"    : self.VVk49V()
   elif item == "VVw7cF"   : self.VVw7cF()
   elif item == "VVswpP_file"  : self.VVswpP(0)
   elif item == "VVswpP_link"  : self.VVswpP(1)
   elif item == "VVrGu1"  : self.VVrGu1()
   elif item == "VVzkki"  : CC0NDf.VVzkki(self)
   elif item == "VVHxzd"   : self.VVHxzd()
   elif item == "VV0gxV"  : self.VV0gxV()
   elif item == "VV9k8p"  : self.VV9k8p()
   elif item == "VVFNew"  : CC0NDf.VVFNew(self)
   elif item == "findPiconBrokenSymLinks" : CC0NDf.VVFU7A(self, True)
   elif item == "FindAllBrokenSymLinks" : CC0NDf.VVFU7A(self, False)
   elif item == "VVkDNV" : self.VVkDNV()
   elif item == "VVNwdU"     : FF6duf(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVBQjG(self):
  if not self.isBusy:
   VVgsyy = []
   VVgsyy.append(("Go to First PIcon"  , "VVltoc"  ))
   VVgsyy.append(("Go to Last PIcon"   , "VV93MR"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Sort by Channel Name"     , "sortByChan" ))
   VVgsyy.append(("Sort by File Name"  , "sortByFile" ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Find from File List .." , "VV7ivZ" ))
   FFCO3u(self, self.VV2zfV, title=self.Title, VVgsyy=VVgsyy)
 def VV2zfV(self, item=None):
  if item is not None:
   if   item == "VVltoc"   : self.VVltoc()
   elif item == "VV93MR"   : self.VV93MR()
   elif item == "sortByChan"  : self.VVUecH(2)
   elif item == "sortByFile"  : self.VVUecH(0)
   elif item == "VV7ivZ"  : self.VV7ivZ()
 def VV7ivZ(self):
  VVgsyy = []
  for item in self.VVX3UR:
   VVgsyy.append((item[0], item[0]))
  FFCO3u(self, self.VVuM2t, title='PIcons ".png" Files', VVgsyy=VVgsyy, VVf67P=True)
 def VVuM2t(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV0p7H(ndx)
 def VVb7x7(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV2E6m()
   if refCode:
    FFQhSW(self, refCode)
    self.VVznx2()
    self.VVgJS5()
 def VVf7L6(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVznx2()
   self.VVgJS5()
  except:
   pass
 def VVp71X(self):
  if self["keyGreen"].getVisible():
   self.VV0p7H(self.curChanIndex)
 def VVUecH(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF3LD6(self, BF(self.VVTsCQ, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVswpP(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV2E6m()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVgsyy = []
     VVgsyy.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVgsyy.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFCO3u(self, BF(self.VVhfY6, mode, curChF, selPiconF), VVgsyy=VVgsyy, title="Current Channel PIcon (already exists)")
    else:
     self.VVhfY6(mode, curChF, selPiconF, "overwrite")
   else:
    FF2zEl(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF2zEl(self, "Could not read current channel info. !", title=title)
 def VVhfY6(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFlh8N(cmd)
   FF3LD6(self, BF(self.VVTsCQ, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVHxzd(self):
  defDir = FFZsCH(CC0NDf.VVqbLc() + "picons_backup")
  FFlh8N("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVQUnh, defDir), BF(CCxFIK
         , mode=CCxFIK.VVU9xO, VVn9uf=CC0NDf.VVqbLc()))
 def VVQUnh(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC0NDf.VVqbLc():
    FF2zEl(self, "Cannot move to same directory !", title=title)
   else:
    if not FFZsCH(path) == FFZsCH(defDir):
     self.VVexAP(defDir)
    FFZnVu(self, BF(FF3LD6, self, BF(self.VVPXSR, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVX3UR), path), title=title)
  else:
   self.VVexAP(defDir)
 def VVPXSR(self, title, defDir, toPath):
  if not iMove:
   self.VVexAP(defDir)
   FF2zEl(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFZsCH(toPath)
  pPath = CC0NDf.VVqbLc()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVX3UR:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVX3UR)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFucjH(self, txt, title=title, VVaOdk="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VV97hK("all")
 def VVexAP(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV0gxV(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVX3UR)
  FFZnVu(self, BF(FF3LD6, self, BF(self.VVSLEZ, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFZevi(tot)), title=title)
 def VVSLEZ(self, title):
  pPath = CC0NDf.VVqbLc()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVX3UR:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVX3UR)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFivHt(str(totErr), VVL6GV)
  FFucjH(self, txt, title=title)
 def VV9k8p(self):
  lines = FFIeeK("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFZnVu(self, BF(self.VVGHQz, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFZevi(tot)), VVOuLx=True)
  else:
   FF5kkM(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVGHQz(self, fList):
  FFlh8N("find -L '%s' -type l -delete" % self.pPath)
  FF5kkM(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVGlhz(self):
  FF3LD6(self, self.VV8cbW)
 def VV8cbW(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV2E6m()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFivHt("PIcon Directory:\n", VViC5D)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF0Ck9(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF0Ck9(path)
   txt += FFivHt("PIcon File:\n", VViC5D)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFivHt("Found %d SymLink%s to this file from:\n" % (tot, FFZevi(tot)), VViC5D)
     for fPath in slLst:
      txt += "  %s\n" % FFivHt(fPath, VVrVS3)
     txt += "\n"
   if chName:
    txt += FFivHt("Channel:\n", VViC5D)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFivHt(chName, VVd7n9)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFivHt("Remarks:\n", VViC5D)
    txt += "  %s\n" % FFivHt("Unused", VVL6GV)
  else:
   txt = "No info found"
  FFBxYU(self, fncMode=CCTzTd.VVUuQB, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV2E6m(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVX3UR[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFyyjf(sat)
  return fName, refCode, chName, sat, inDB
 def VVznx2(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVX3UR):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVgJS5(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV2E6m()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFivHt("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VViC5D))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV2E6m()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFTEln(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFivHt(self.curChanName, VVMdMA)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VV2E6m()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVk49V(self):
  VVdPgX, VVu9HV = FFcYq0()
  sTypeNameDict = {}
  for key, val in VVu9HV.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVX3UR:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVu9HV: sTypeDict[VVu9HV[stNum]] = sTypeDict.get(VVu9HV[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFU8jM("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVX2QD = []
  c = "#b#11003333#"
  VVX2QD.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVX2QD.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVX2QD.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVX2QD.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVX2QD.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVX2QD.append((c + "Satellites"    , str(len(self.nsList))))
  VVX2QD.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVX2QD.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVX2QD.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVX2QD.extend(sTypeRows)
  FFyrIU(self, None, title=self.Title, VVX3UR=VVX2QD, VVJA7R=28, VVlVSy="#00003333", VV3FyM="#00222222")
 def VVrGu1(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFZsCH(CFG.exportedTablesPath.getValue()), txt, FFvXEJ())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVX3UR:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF5kkM(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVmYL2(self):
  if not self.isBusy:
   VVgsyy = []
   VVgsyy.append(("All"        , "all"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Used by Channels"     , "used" ))
   VVgsyy.append(("Unused PIcons"     , "unused" ))
   VVgsyy.append(("IPTV PIcons"      , "iptv" ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("PIcons Files"      , "pFiles" ))
   VVgsyy.append(("SymLinks to PIcons"    , "pLinks" ))
   VVgsyy.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVgsyy.append(("By Files Date ..."    , "pDate" ))
   VVgsyy.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVgsyy.append(FFJi5u("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFDMS5(val)
      VVgsyy.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCBykx(self)
   filterObj.VVKDLr(VVgsyy, self.nsList, self.VVpqKn)
 def VVpqKn(self, item=None):
  if item is not None:
   self.VV97hK(item)
 def VV97hK(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVzatq   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVd5gM   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVnm7c  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVEkoe   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVrUZK  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVEXai  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVGcX2  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VViUuA , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVeqlq , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVbRb2   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVcdaP , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVGcX2:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFIeeK("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFSHhe(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFRB11(self, "Not found", 1000)
     return
   elif mode == self.VViUuA:
    self.VVLieT(mode)
    return
   elif mode == self.VVeqlq:
    self.VVGbHJ(mode)
    return
   elif mode == self.VVXGuR:
    return
   else:
    words, asPrefix = CCBykx.VVVM3i(words)
   if not words and mode in (self.VVbRb2, self.VVcdaP):
    FFRB11(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF3LD6(self, BF(self.VVTsCQ, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVLieT(self, mode):
  VVgsyy = []
  VVgsyy.append(("Today"   , "today" ))
  VVgsyy.append(("Since Yesterday" , "yest" ))
  VVgsyy.append(("Since 7 days"  , "week" ))
  FFCO3u(self, BF(self.VV7K8J, mode), VVgsyy=VVgsyy, title="Filter by Added/Modified Date")
 def VV7K8J(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFPlYZ(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFPlYZ(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFPlYZ(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FF3LD6(self, BF(self.VVTsCQ, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVGbHJ(self, mode):
  VVdPgX, VVu9HV = FFcYq0()
  lst = set()
  for key, val in VVu9HV.items():
   lst.add(val)
  VVgsyy = []
  for item in lst:
   VVgsyy.append((item, item))
  VVgsyy.sort(key=lambda x: x[0])
  FFCO3u(self, BF(self.VVf2vr, mode), VVgsyy=VVgsyy, title="Filter by Service Type")
 def VVf2vr(self, mode, item=None):
  if item:
   VVdPgX, VVu9HV = FFcYq0()
   sTypeList = []
   for key, val in VVu9HV.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FF3LD6(self, BF(self.VVTsCQ, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVw7cF(self):
  self.session.open(CCNT6G, barTheme=CCNT6G.VVQKW9
      , titlePrefix = ""
      , fncToRun  = self.VVNUbl
      , VVRlGe = self.VVvQzX)
 def VVNUbl(self, VVxeRf):
  VVVzTq, err = CCuZg4.VVyoTY(self, CCuZg4.VVdPAS, VVCuKF=False, VVQNH9=False)
  files = []
  words = []
  if not VVxeRf or VVxeRf.isCancelled:
   return
  VVxeRf.VVxy84 = []
  VVxeRf.VVPZSN(len(VVVzTq))
  if VVVzTq:
   curCh = self.VVlKvE(self.curChanName)
   for refCode in VVVzTq:
    if not VVxeRf or VVxeRf.isCancelled:
     return
    VVxeRf.VVnoYr(1, True)
    chName, sat, inDB = VVVzTq.get(refCode, ("", "", 0))
    ratio = CC0NDf.VVr65X(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC0NDf.VVBQdt(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFSHhe(f)
       fil = f.replace(".png", "")
       if not fil in VVxeRf.VVxy84:
        VVxeRf.VVxy84.append(fil)
 def VVvQzX(self, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  if VVxy84 : FF3LD6(self, BF(self.VVTsCQ, mode=self.VVXGuR, words=VVxy84), title="Loading ...")
  else   : FFRB11(self, "Not found", 2000)
 def VVTsCQ(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVwYb5(isFirstTime):
   return
  self.isBusy = True
  VVQNH9 = True if isFirstTime else False
  VVVzTq, err = CCuZg4.VVyoTY(self, CCuZg4.VVdPAS, VVCuKF=False, VVQNH9=VVQNH9)
  if err:
   self.close()
  iptvRefList = self.VVa8Tm()
  tList = []
  for fName, fType in CC0NDf.VVOwGR(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVVzTq:
    if fName in VVVzTq:
     chName, sat, inDB = VVVzTq.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVzatq:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVd5gM  and chName         : isAdd = True
   elif mode == self.VVnm7c and not chName        : isAdd = True
   elif mode == self.VVrUZK  and fType == 0        : isAdd = True
   elif mode == self.VVEXai  and fType == 1        : isAdd = True
   elif mode == self.VVGcX2  and fName in words       : isAdd = True
   elif mode == self.VVXGuR and fName in words       : isAdd = True
   elif mode == self.VVEkoe  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVbRb2  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVcdaP:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VViUuA:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVeqlq:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVX3UR   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFRB11(self)
  else:
   self.isBusy = False
   FFRB11(self, "Not found", 1000)
   return
  self.VVX3UR.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVznx2()
  self.totalItems = len(self.VVX3UR)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVvuSW(True)
 def VVwYb5(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC0NDf.VVOwGR(self.pPath):
    if fName:
     return True
   if isFirstTime : FF2zEl(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFRB11(self, "Not found", 1000)
  else:
   FF2zEl(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVa8Tm(self):
  VVX2QD = {}
  files  = CCA7uK.VVILbD()
  if files:
   for path in files:
    txt = FFU2DB(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVX2QD[refCode] = item[1]
  return VVX2QD
 def VVHPzQ(self):
  self.VVjvan()
  f1, f2 = self.VVMJBL()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVX3UR[ndx]
   fName = self.VVX3UR[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCSUvI.VVGdWN(pic, path) : color = VVd7n9 if inDB else ""
   elif not chName           : color = ""
   else             : color = VVuURa
   self.VVD3lg(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVr65X(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVTrBv():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVzkki")
 @staticmethod
 def VVcjzm():
  VVgsyy = []
  VVgsyy.append(("Find SymLinks (to PIcon Directory)"   , "VVFNew"  ))
  VVgsyy.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVgsyy.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVgsyy
 @staticmethod
 def VVzkki(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF)
  png, path = CC0NDf.VVdCZt(refCode)
  if path : CC0NDf.VV6ltV(SELF, png, path)
  else : FF2zEl(SELF, "No PIcon found for current channel in:\n\n%s" % CC0NDf.VVqbLc())
 @staticmethod
 def VVFNew(SELF):
  if VVMdMA:
   sed1 = FFmPm4("->", VVMdMA)
   sed2 = FFmPm4("picon", VVL6GV)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVuURa, VVWK7B)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFy48B(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFcVVX(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVFU7A(SELF, isPIcon):
  sed1 = FFmPm4("->", VVuURa)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFmPm4("picon", VVL6GV)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFy48B(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFcVVX(), grep, sed1, sed2))
 @staticmethod
 def VV6ltV(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFmPm4("%s%s" % (dest, png), VVd7n9))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFmPm4(errTxt, VVHEBa))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFeWAm(SELF, cmd)
 @staticmethod
 def VVOwGR(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVqbLc():
  path = CFG.PIconsPath.getValue()
  return FFZsCH(path)
 @staticmethod
 def VVdCZt(refCode, chName=None):
  if FFH7Or(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFzxaC(refCode)
  allPath, fName, refCodeFile, pList = CC0NDf.VVBQdt(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVhOX3(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCA7uK.VV6ZB0():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFkgYM(chName)
   for name in (chName, chName.lower(), chName.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVBQdt(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC0NDf.VVqbLc()
   pList = []
   lst = FFPCH3(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFkgYM(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFSHhe(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCW1XA():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVFLoi  = None
  self.VVTFt8 = ""
  self.VVG882  = noService
  self.VV8Lcx = 0
  self.VVVv1K  = noService
  self.VVnRo9 = 0
  self.VV3ygU  = "-"
  self.VVekCN = 0
  self.VVGraL  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVxVBE(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVFLoi = frontEndStatus
     self.VVsfhx()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVsfhx(self):
  if self.VVFLoi:
   val = self.VVFLoi.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVTFt8 = "%3.02f dB" % (val / 100.0)
   else         : self.VVTFt8 = ""
   val = self.VVFLoi.get("tuner_signal_quality", 0) * 100 / 65536
   self.VV8Lcx = int(val)
   self.VVG882  = "%d%%" % val
   val = self.VVFLoi.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVnRo9 = int(val)
   self.VVVv1K  = "%d%%" % val
   val = self.VVFLoi.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV3ygU  = "%d" % val
   val = int(val * 100 / 500)
   self.VVekCN = min(500, val)
   val = self.VVFLoi.get("tuner_locked", 0)
   if val == 1 : self.VVGraL = "Locked"
   else  : self.VVGraL = "Not locked"
 def VVVAeA(self)   : return self.VVTFt8
 def VVpvnG(self)   : return self.VVG882
 def VVckjk(self)  : return self.VV8Lcx
 def VVk8Js(self)   : return self.VVVv1K
 def VVIKqj(self)  : return self.VVnRo9
 def VVSPsn(self)   : return self.VV3ygU
 def VVBixX(self)  : return self.VVekCN
 def VVE6sQ(self)   : return self.VVGraL
 def VVnPvc(self) : return self.serviceName
class CCgl59():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VV5Skx(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFvqGJ(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVVJpr(self.ORPOS  , mod=1   )
      self.sat2  = self.VVVJpr(self.ORPOS  , mod=2   )
      self.freq  = self.VVVJpr(self.FREQ  , mod=3   )
      self.sr   = self.VVVJpr(self.SR   , mod=4   )
      self.inv  = self.VVVJpr(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVVJpr(self.POL  , self.D_POL )
      self.fec  = self.VVVJpr(self.FEC  , self.D_FEC )
      self.syst  = self.VVVJpr(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVVJpr("modulation" , self.D_MOD )
       self.rolof = self.VVVJpr("rolloff"  , self.D_ROLOF )
       self.pil = self.VVVJpr("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVVJpr("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVVJpr("pls_code"  )
       self.iStId = self.VVVJpr("is_id"   )
       self.t2PlId = self.VVVJpr("t2mi_plp_id" )
       self.t2PId = self.VVVJpr("t2mi_pid"  )
 def VVVJpr(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFDMS5(val)
  elif mod == 2   : return FFrc8H(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVwYWy(self, refCode):
  txt = ""
  self.VV5Skx(refCode)
  if self.data:
   def VVBMvF(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVBMvF("System"   , self.syst)
    txt += VVBMvF("Satellite"  , self.sat2)
    txt += VVBMvF("Frequency"  , self.freq)
    txt += VVBMvF("Inversion"  , self.inv)
    txt += VVBMvF("Symbol Rate"  , self.sr)
    txt += VVBMvF("Polarization" , self.pol)
    txt += VVBMvF("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVBMvF("Modulation" , self.mod)
     txt += VVBMvF("Roll-Off" , self.rolof)
     txt += VVBMvF("Pilot"  , self.pil)
     txt += VVBMvF("Input Stream", self.iStId)
     txt += VVBMvF("T2MI PLP ID" , self.t2PlId)
     txt += VVBMvF("T2MI PID" , self.t2PId)
     txt += VVBMvF("PLS Mode" , self.plsMod)
     txt += VVBMvF("PLS Code" , self.plsCod)
   else:
    txt += VVBMvF("System"   , self.txMedia)
    txt += VVBMvF("Frequency"  , self.freq)
  return txt, self.namespace
 def VVy6gq(self, refCode):
  txt = "Transpoder : ?"
  self.VV5Skx(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVTyLz(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFvqGJ(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVVJpr(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVVJpr(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVVJpr(self.SYST, self.D_SYS_S)
     freq = self.VVVJpr(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVVJpr(self.POL , self.D_POL)
      fec = self.VVVJpr(self.FEC , self.D_FEC)
      sr = self.VVVJpr(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV8AtE(self, refCode):
  self.data = None
  self.VV5Skx(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCDQxK():
 def __init__(self, VV5Nvb, path, VVRlGe=None, curRowNum=-1):
  self.VV5Nvb  = VV5Nvb
  self.origFile   = path
  self.Title    = "File Editor: " + FFSHhe(path)
  self.VVRlGe  = VVRlGe
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  if FFlh8N("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FF3LD6(self.VV5Nvb, BF(self.VVQCFg, curRowNum), title="Loading file ...")
  else:
   FF2zEl(self.VV5Nvb, "Error while preparing edit!")
 def VVQCFg(self, curRowNum):
  VVX2QD = self.VVvwLO()
  VV6LI6 = ("Save Changes" , self.VVR9Kf   , [])
  VVkkpG  = ("Edit Line"  , self.VVhYNh    , [])
  VVH4Z8 = ("Go to Line Num" , self.VVYeax   , [])
  VVmhJa = ("Line Options" , self.VVsKhF   , [])
  VV1Zg1 = (""    , self.VVbP21 , [])
  VVZAcA = self.VVxY47
  VVfGJE  = self.VVJ1ly
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV8zKo  = (CENTER  , LEFT  )
  VVgl66 = FFyrIU(self.VV5Nvb, None, title=self.Title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VV6LI6=VV6LI6, VVkkpG=VVkkpG, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVZAcA=VVZAcA, VVfGJE=VVfGJE, VV1Zg1=VV1Zg1, VVMXk9=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVBBM8   = "#11001111"
    , VVa80e   = "#11001111"
    , VVaOdk   = "#11001111"
    , VVlVSy  = "#05333333"
    , VV3FyM  = "#00222222"
    , VVf4Ym  = "#11331133"
    )
  VVgl66.VVICdA(curRowNum)
 def VVYeax(self, VVgl66, title, txt, colList):
  totRows = VVgl66.VVpibS()
  lineNum = VVgl66.VVKltF() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FF7lc9(self.VV5Nvb, BF(self.VVWeET, VVgl66, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVWeET(self, VVgl66, lineNum, totRows, VVfLRn):
  if VVfLRn:
   VVfLRn = VVfLRn.strip()
   if VVfLRn.isdigit():
    num = FFVUcd(int(VVfLRn) - 1, 0, totRows)
    VVgl66.VVICdA(num)
    self.lastLineNum = num + 1
   else:
    FFRB11(VVgl66, "Incorrect number", 1500)
 def VVsKhF(self, VVgl66, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVgl66.VVFbUd()
  VVgsyy = []
  VVgsyy.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVgsyy.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVyMwx"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVr97O:
   VVgsyy.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(  ("Delete Line"         , "deleteLine"   ))
  FFCO3u(self.VV5Nvb, BF(self.VVlN93, VVgl66, lineNum), VVgsyy=VVgsyy, title="Line Options")
 def VVlN93(self, VVgl66, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVw6bU("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVgl66)
   elif item == "VVyMwx"  : self.VVyMwx(VVgl66, lineNum)
   elif item == "copyToClipboard"  : self.VVptZJ(VVgl66, lineNum)
   elif item == "pasteFromClipboard" : self.VVXU14(VVgl66, lineNum)
   elif item == "deleteLine"   : self.VVw6bU("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVgl66)
 def VVJ1ly(self, VVgl66):
  VVgl66.VVzU64()
 def VVbP21(self, VVgl66, title, txt, colList):
  if   self.insertMode == 1: VVgl66.VVHCuh()
  elif self.insertMode == 2: VVgl66.VVS0MS()
  self.insertMode = 0
 def VVyMwx(self, VVgl66, lineNum):
  if lineNum == VVgl66.VVFbUd():
   self.insertMode = 1
   self.VVw6bU("echo '' >> '%s'" % self.tmpFile, VVgl66)
  else:
   self.insertMode = 2
   self.VVw6bU("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVgl66)
 def VVptZJ(self, VVgl66, lineNum):
  global VVr97O
  VVr97O = FFU8jM("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVgl66.VVD950("Copied to clipboard")
 def VVR9Kf(self, VVgl66, title, txt, colList):
  if self.fileChanged:
   if FF5lNb(self.origFile):
    if FFlh8N("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVgl66.VVD950("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVgl66.VVzU64()
    else:
     FF2zEl(self.VV5Nvb, "Cannot save file!")
   else:
    FF2zEl(self.VV5Nvb, "Cannot create backup copy of original file!")
 def VVxY47(self, VVgl66):
  if self.fileChanged:
   FFZnVu(self.VV5Nvb, BF(self.VVJKez, VVgl66), "Cancel changes ?")
  else:
   FFlh8N("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVJKez(VVgl66)
 def VVJKez(self, VVgl66):
  VVgl66.cancel()
  FFAFdq(self.tmpFile)
  if self.VVRlGe:
   self.VVRlGe(self.fileSaved)
 def VVhYNh(self, VVgl66, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVWK7B + "ORIGINAL TEXT:\n" + VVrVS3 + lineTxt
  FF7lc9(self.VV5Nvb, BF(self.VV8MLQ, lineNum, VVgl66), title="File Line", defaultText=lineTxt, message=message)
 def VV8MLQ(self, lineNum, VVgl66, VVfLRn):
  if not VVfLRn is None:
   if VVgl66.VVFbUd() <= 1:
    self.VVw6bU("echo %s > '%s'" % (VVfLRn, self.tmpFile), VVgl66)
   else:
    self.VVVbB1(VVgl66, lineNum, VVfLRn)
 def VVXU14(self, VVgl66, lineNum):
  if lineNum == VVgl66.VVFbUd() and VVgl66.VVFbUd() == 1:
   self.VVw6bU("echo %s >> '%s'" % (VVr97O, self.tmpFile), VVgl66)
  else:
   self.VVVbB1(VVgl66, lineNum, VVr97O)
 def VVVbB1(self, VVgl66, lineNum, newTxt):
  VVgl66.VVPBVj("Saving ...")
  lines = FFHq6Y(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVgl66.VVFaTA()
  VVX2QD = self.VVvwLO()
  VVgl66.VVrEsw(VVX2QD)
 def VVw6bU(self, cmd, VVgl66):
  tCons = CCu0fe()
  tCons.ePopen(cmd, BF(self.VVEKfF, VVgl66))
  self.fileChanged = True
  VVgl66.VVFaTA()
 def VVEKfF(self, VVgl66, result, retval):
  VVX2QD = self.VVvwLO()
  VVgl66.VVrEsw(VVX2QD)
 def VVvwLO(self):
  if fileExists(self.tmpFile):
   lines = FFHq6Y(self.tmpFile)
   VVX2QD = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVX2QD.append((str(ndx), line.strip()))
   if not VVX2QD:
    VVX2QD.append((str(1), ""))
   return VVX2QD
  else:
   FFdxlA(self.VV5Nvb, self.tmpFile)
class CCBykx():
 def __init__(self, callingSELF, VVBBM8="#22003344", VVa80e="#22002233"):
  self.callingSELF = callingSELF
  self.VVgsyy  = []
  self.satList  = []
  self.VVBBM8  = VVBBM8
  self.VVa80e   = VVa80e
 def VVjDje(self, VVRlGe):
  self.VVgsyy = []
  VVgsyy, VVfOz8 = CCBykx.VVEb0Q(self.callingSELF, False, True)
  if VVgsyy:
   self.VVgsyy += VVgsyy
   self.VVzLlU(VVRlGe, VVfOz8)
 def VVQ9Ad(self, mode, VVgl66, satCol, VVRlGe, inFilterFnc=None):
  VVgl66.VVPBVj("Loading Filters ...")
  self.VVgsyy = []
  self.VVgsyy.append(("All Services" , "all"))
  if mode == 1:
   self.VVgsyy.append(VVzHzv)
   self.VVgsyy.append(("Parental Control", "parentalControl" ))
   self.VVgsyy.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVgsyy.append(VVzHzv)
   self.VVgsyy.append(("Selected Transponder"   , "selectedTP" ))
   self.VVgsyy.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVMd0E(VVgl66, satCol)
  VVgsyy, VVfOz8 = CCBykx.VVEb0Q(self.callingSELF, True, False)
  if VVgsyy:
   VVgsyy.insert(0, FFJi5u("Custom Words"))
   self.VVgsyy += VVgsyy
  VVgl66.VV3asq()
  self.VVzLlU(VVRlGe, VVfOz8, inFilterFnc)
 def VVKDLr(self, VVgsyy, sats, VVRlGe, inFilterFnc=None):
  self.VVgsyy = VVgsyy
  VVgsyy, VVfOz8 = CCBykx.VVEb0Q(self.callingSELF, True, False)
  if VVgsyy:
   self.VVgsyy.append(FFJi5u("Custom Words"))
   self.VVgsyy += VVgsyy
  self.VVzLlU(VVRlGe, VVfOz8, inFilterFnc)
 def VVzLlU(self, VVRlGe, VVfOz8, inFilterFnc=None):
  VV2u6t  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVOmbd = ("Edit Filter"  , BF(self.VVEMmX, VVfOz8))
  VVtL1m  = ("Filter Help"  , BF(self.VVrljB, VVfOz8))
  FFCO3u(self.callingSELF, BF(self.VVvWyl, VVRlGe), VVgsyy=self.VVgsyy, title="Select Filter", VV2u6t=VV2u6t, VVOmbd=VVOmbd, VVtL1m=VVtL1m, VVwQO5=True, VVBBM8=self.VVBBM8, VVa80e=self.VVa80e)
 def VVvWyl(self, VVRlGe, item):
  if item:
   VVRlGe(item)
 def VVEMmX(self, VVfOz8, VV7Q6fObj, sel):
  if fileExists(VVfOz8) : CCDQxK(self.callingSELF, VVfOz8, VVRlGe=None)
  else       : FFdxlA(self.callingSELF, VVfOz8)
  VV7Q6fObj.cancel()
 def VVrljB(self, VVfOz8, VV7Q6fObj, sel):
  FF6duf(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVMd0E(self, VVgl66, satColNum):
  if not self.satList:
   satList = VVgl66.VVc6Bk(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFyyjf(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFJi5u("Satellites"))
  if self.VVgsyy:
   self.VVgsyy += self.satList
 @staticmethod
 def VVEb0Q(SELF, addTag, VVnkcm):
  FFlWSy()
  fileName  = "ajpanel_services_filter"
  VVfOz8 = VVn5zG + fileName
  VVgsyy  = []
  if not fileExists(VVfOz8):
   FFlh8N("cp -f '%s' '%s'" % (VVV9bl + fileName, VVfOz8))
  fileFound = False
  if fileExists(VVfOz8):
   fileFound = True
   lines = FFHq6Y(VVfOz8)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVgsyy.append((line, "__w__" + line))
       else  : VVgsyy.append((line, line))
  if VVnkcm:
   if   not fileFound : FFdxlA(SELF, VVfOz8)
   elif not VVgsyy : FFKQXu(SELF, VVfOz8)
  return VVgsyy, VVfOz8
 @staticmethod
 def VVVM3i(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCXfgt():
 def __init__(self, callingSELF, VVgl66, addSep=True):
  self.callingSELF = callingSELF
  self.VVgl66 = VVgl66
  self.VVgsyy = []
  iMulSel = self.VVgl66.VVWR9J()
  if iMulSel : self.VVgsyy.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVgsyy.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVgl66.VVGnLM()
  self.VVgsyy.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVgsyy.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVgsyy.append(VVzHzv)
 def VVnFMb(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVgsyy.extend(extraMenu)
  FFCO3u(self.callingSELF, BF(self.VVI71M, cbFncDict, okFnc), width=width, title="Options", VVgsyy=self.VVgsyy)
 def VVI71M(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVgl66.VVVdMt(True)
   elif item == "MultSelDisab" : self.VVgl66.VVVdMt(False)
   elif item == "selectAll" : self.VVgl66.VVK1tz()
   elif item == "unselectAll" : self.VVgl66.VVww5b()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCPhYN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVDOlP, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFNG7m(self)
  FFTBJT(self["keyRed"]  , "Exit")
  FFTBJT(self["keyGreen"]  , "Save")
  FFTBJT(self["keyYellow"] , "Refresh")
  FFTBJT(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVwgSz  ,
   "green" : self.VVpeH8 ,
   "yellow": self.VVKK7u  ,
   "blue" : self.VVkfFb   ,
   "up" : self.VV7SnD    ,
   "down" : self.VValPP   ,
   "left" : self.VVSzgb   ,
   "right" : self.VV7Npu   ,
   "cancel": self.VVwgSz
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self.VVKK7u()
  self.VVovVc()
  FFzs4L(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVoIep)
  except:
   self.timer.callback.append(self.VVoIep)
  self.timer.start(1000, False)
  self.VVoIep()
 def onExit(self):
  self.timer.stop()
 def VVwgSz(self) : self.close(True)
 def VVM2wo(self) : self.close(False)
 def VVkfFb(self):
  self.session.openWithCallback(self.VVf851, BF(CCvfe4))
 def VVf851(self, closeAll):
  if closeAll:
   self.close()
 def VVoIep(self):
  self["curTime"].setText(str(FFwVZA(iTime())))
 def VV7SnD(self):
  self.VVam1m(1)
 def VValPP(self):
  self.VVam1m(-1)
 def VVSzgb(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVovVc()
 def VV7Npu(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVovVc()
 def VVam1m(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVyjwm(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVyjwm(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVyjwm(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVUxrR(year)):
   days += 1
  return days
 def VVUxrR(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVovVc(self):
  for obj in self.list:
   FFvobF(obj, "#11404040")
  FFvobF(self.list[self.index], "#11ff8000")
 def VVKK7u(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVpeH8(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCu0fe()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV8Czl)
 def VV8Czl(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FF5kkM(self, "Nothing returned from the system!")
  else    : FF5kkM(self, str(result))
class CCvfe4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVmJx6, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFNG7m(self, addLabel=True)
  FFTBJT(self["keyRed"]  , "Exit")
  FFTBJT(self["keyGreen"]  , "Sync")
  FFTBJT(self["keyYellow"] , "Refresh")
  FFTBJT(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVwgSz   ,
   "green" : self.VVSiEJ  ,
   "yellow": self.VVm5X5 ,
   "blue" : self.VVZ6P7  ,
   "cancel": self.VVwgSz
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVYHEI()
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  FFzs4L(self)
  FFnB9O(self.VVHIvO)
 def VVHIvO(self):
  self.VV7lTo()
  self.VVd4XD(False)
 def VVwgSz(self)  : self.close(True)
 def VVZ6P7(self) : self.close(False)
 def VVYHEI(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VV7lTo(self):
  self.VVIgz9()
  self.VVQ5Ip()
  self.VVpdxh()
  self.VVFwdP()
 def VVm5X5(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVYHEI()
   self.VV7lTo()
   FFnB9O(self.VVHIvO)
 def VVSiEJ(self):
  if len(self["keyGreen"].getText()) > 0:
   FFZnVu(self, self.VV6cxe, "Synchronize with Internet Date/Time ?")
 def VV6cxe(self):
  self.VV7lTo()
  FFnB9O(BF(self.VVd4XD, True))
 def VVIgz9(self)  : self["keyRed"].show()
 def VVGqlc(self)  : self["keyGreen"].show()
 def VVRZqG(self) : self["keyYellow"].show()
 def VV2SOd(self)  : self["keyBlue"].show()
 def VVQ5Ip(self)  : self["keyGreen"].hide()
 def VVpdxh(self) : self["keyYellow"].hide()
 def VVFwdP(self)  : self["keyBlue"].hide()
 def VVd4XD(self, sync):
  localTime = FFUEda()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVqnOu(server)
   if epoch_time is not None:
    ntpTime = FFwVZA(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCu0fe()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VV8Czl, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVRZqG()
  self.VV2SOd()
  if ok:
   self.VVGqlc()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV8Czl(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVd4XD(False)
  except:
   pass
 def VVqnOu(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCQZYn.VVY3BC():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCo5Xr(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAm4L(VVGr3W, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFNG7m(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFnB9O(self.VV0oxk)
 def VV0oxk(self):
  if CCQZYn.VVY3BC() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFvobF(self["myBody"], color)
   FFvobF(self["myLabel"], color)
  except:
   pass
class CCGivv(Screen):
 VVJIlu = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFTuEm()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFAm4L(VVnYzd, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCc5WF(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCc5WF(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCc5WF(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCW1XA()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFNG7m(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VV7SnD       ,
   "down"  : self.VValPP      ,
   "left"  : self.VVSzgb      ,
   "right"  : self.VV7Npu      ,
   "info"  : self.VVR7oo     ,
   "epg"  : self.VVR7oo     ,
   "menu"  : self.VVNwdU      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVBivD, -1)  ,
   "next"  : BF(self.VVBivD, 1)  ,
   "pageUp" : BF(self.VVh1SK, True) ,
   "chanUp" : BF(self.VVh1SK, True) ,
   "pageDown" : BF(self.VVh1SK, False) ,
   "chanDown" : BF(self.VVh1SK, False) ,
   "0"   : BF(self.VVBivD, 0)  ,
   "1"   : BF(self.VVRlia, pos=1) ,
   "2"   : BF(self.VVRlia, pos=2) ,
   "3"   : BF(self.VVRlia, pos=3) ,
   "4"   : BF(self.VVRlia, pos=4) ,
   "5"   : BF(self.VVRlia, pos=5) ,
   "6"   : BF(self.VVRlia, pos=6) ,
   "7"   : BF(self.VVRlia, pos=7) ,
   "8"   : BF(self.VVRlia, pos=8) ,
   "9"   : BF(self.VVRlia, pos=9) ,
  }, -1)
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  if not CCGivv.VVJIlu:
   CCGivv.VVJIlu = self
  self.sliderSNR.VV0eTY()
  self.sliderAGC.VV0eTY()
  self.sliderBER.VV0eTY(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVRlia()
  self.VVaouT()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV1dfg)
  except:
   self.timer.callback.append(self.VV1dfg)
  self.timer.start(500, False)
 def VVaouT(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVxVBE(service)
  serviceName = self.tunerInfo.VVnPvc()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  tp = CCgl59()
  tpTxt, satTxt = tp.VVy6gq(refCode)
  if tpTxt == "?" :
   tpTxt = FFivHt("NO SIGNAL", VVgmAg)
  self["myTPInfo"].setText(tpTxt + "  " + FFivHt(satTxt, VVhb13))
 def VV1dfg(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVxVBE(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVVAeA())
   self["mySNR"].setText(self.tunerInfo.VVpvnG())
   self["myAGC"].setText(self.tunerInfo.VVk8Js())
   self["myBER"].setText(self.tunerInfo.VVSPsn())
   self.sliderSNR.VVjUu7(self.tunerInfo.VVckjk())
   self.sliderAGC.VVjUu7(self.tunerInfo.VVIKqj())
   self.sliderBER.VVjUu7(self.tunerInfo.VVBixX())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVjUu7(0)
   self.sliderAGC.VVjUu7(0)
   self.sliderBER.VVjUu7(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
    if state and not state == "Tuned":
     FFRB11(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVR7oo(self):
  FFBxYU(self, fncMode=CCTzTd.VV69by)
 def VVNwdU(self):
  FF6duf(self, "_help_signal", "Signal Monitor (Keys)")
 def VV7SnD(self)  : self.VVRlia(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VValPP(self) : self.VVRlia(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVSzgb(self) : self.VVRlia(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV7Npu(self) : self.VVRlia(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVRlia(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFH7ga(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVBivD(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFVUcd(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFH7ga(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCGivv.VVJIlu = None
 def VVh1SK(self, isUp):
  FFRB11(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVaouT()
  except:
   pass
class CCc5WF(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV0eTY(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFvobF(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVV9bl +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFvobF(self.covObj, self.covColor)
   else:
    FFvobF(self.covObj, "#00006688")
    self.isColormode = True
  self.VVjUu7(0)
 def VVjUu7(self, val):
  val  = FFVUcd(val, self.minN, self.maxN)
  width = int(FFGgcy(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFVUcd(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCNT6G(Screen):
 VVQKW9    = 0
 VV3Zg2 = 1
 VVIhda = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVRlGe=None, barTheme=VVQKW9, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVTPze(barTheme)
  self.skin, self.skinParam = FFAm4L(VVkwlJ, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVRlGe = VVRlGe
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVxy84 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFNG7m(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self.VV1Uyz()
  self["myProgBarVal"].setText("0%")
  FFvobF(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVNBdr()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVNBdr)
  except:
   self.timer.callback.append(self.VVNBdr)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVPZSN(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV4dOP(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVxy84), self.counter, self.maxValue, catName)
 def VVfmtR(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVNxjs(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVgQXn(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVK5Ir(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVELUC(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VV1hS4(self, txt):
  self.newTitle = txt
 def VVnoYr(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVxy84), self.counter, self.maxValue)
  except:
   pass
 def VVxkae(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVjRF0(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVCLpN(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFRB11(self, "Cancelling ...")
  self.isCancelled = True
  self.VV3cwH(False)
 def VV3cwH(self, isDone):
  FFnB9O(BF(self.VVmQw2, isDone))
 def VVmQw2(self, isDone):
  if self.VVRlGe:
   self.VVRlGe(isDone, self.VVxy84, self.counter, self.maxValue, self.isError)
  self.close()
 def VVNBdr(self):
  val = FFVUcd(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFGgcy(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VV3cwH(True)
 def VV1Uyz(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV3Zg2, self.VVIhda):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVTPze(self, barTheme):
  if   barTheme == self.VV3Zg2 : return 0.7
  if   barTheme == self.VVIhda : return 0.5
  else             : return 1
class CCu0fe(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVRlGe = {}
  self.commandRunning = False
  self.VVi6yH  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVRlGe, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVRlGe[name] = VVRlGe
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVi6yH:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVcd7d, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVcVAn , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVcd7d, name))
    self.appContainers[name].appClosed.append(BF(self.VVcVAn , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVcVAn(name, retval)
  return True
 def VVcd7d(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFivHt("[UN-DECODED STRING]", VVgmAg))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVcVAn(self, name, retval):
  if not self.VVi6yH:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVRlGe[name]:
   self.VVRlGe[name](self.appResults[name], retval)
  del self.VVRlGe[name]
 def VVqGqE(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCeuXy(Screen):
 def __init__(self, session, title="", VVZU3B=None, VVV183=False, VVrY2s=False, VV2SjC=False, VV5D0x=False, VVj8De=False, VVT2So=False, VVFq7T=VVnE8x, VV5SfP=None, VVveXN=False, VVpjHk=None, VVeYT2="", checkNetAccess=False, VVJA7R=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFAm4L(VVCmnq, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVJA7R, usefixedFont=consFont)
  self.session   = session
  self.VVeYT2 = VVeYT2
  FFNG7m(self, addScrollLabel=True)
  self.VVV183   = VVV183
  self.VVrY2s   = VVrY2s
  self.VV2SjC   = VV2SjC
  self.VV5D0x  = VV5D0x
  self.VVj8De = VVj8De
  self.VVT2So = VVT2So
  self.VVFq7T   = VVFq7T
  self.VV5SfP = VV5SfP
  self.VVveXN  = VVveXN
  self.VVpjHk  = VVpjHk
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCu0fe()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FF3Vxe()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVZU3B, str):
   self.VVZU3B = [VVZU3B]
  else:
   self.VVZU3B = VVZU3B
  if self.VV2SjC or self.VV5D0x:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVZU3B.append("echo -e '\n%s\n' %s" % (restartNote, FFmPm4(restartNote, VVMdMA)))
   if self.VV2SjC:
    self.VVZU3B.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVZU3B.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVj8De:
   FFRB11(self, "Processing ...")
  self.onLayoutFinish.append(self.VVUGY7)
  self.onClose.append(self.VVIY57)
 def VVUGY7(self):
  self["myLabel"].VVZ8z1(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVeYT2 or "Processing ..."))
  if self.VVV183:
   self["myLabel"].VVsIzd()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVyKOw()
  else:
   self.VVoPC3()
 def VVyKOw(self):
  if CCQZYn.VVY3BC():
   self["myLabel"].setText("Processing ...")
   self.VVoPC3()
  else:
   self["myLabel"].setText(FFivHt("\n   No connection to internet!", VVL6GV))
 def VVoPC3(self):
  allOK = self.container.ePopen(self.VVZU3B[0], self.VVRbqn, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVRbqn("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVT2So or self.VV2SjC or self.VV5D0x:
    self["myLabel"].setText(FFExgP("STARTED", VVMdMA) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVpjHk:
   colorWhite = CCajWE.VVUSPc(VVWK7B)
   color  = CCajWE.VVUSPc(self.VVpjHk[0])
   words  = self.VVpjHk[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVFq7T=self.VVFq7T)
 def VVRbqn(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVZU3B):
   allOK = self.container.ePopen(self.VVZU3B[self.cmdNum], self.VVRbqn, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVRbqn("Cannot connect to Console!", -1)
  else:
   if self.VVj8De and FFsY7N(self):
    FFRB11(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVT2So:
    self["myLabel"].appendText("\n" + FFExgP("FINISHED", VVMdMA), self.VVFq7T)
   if self.VVV183 or self.VVrY2s:
    self["myLabel"].VVsIzd()
   if self.VV5SfP is not None:
    self.VV5SfP()
   if not retval and self.VVveXN:
    self.VVIY57()
 def VVIY57(self):
  if self.container.VVqGqE():
   self.container.killAll()
class CCID7J(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVCmnq, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVn5zG + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFU8jM("pwd") or "/home/root"
  self.container   = CCu0fe()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFNG7m(self, title="Terminal", addScrollLabel=True)
  FFTBJT(self["keyRed"] , self.exitBtnText)
  FFTBJT(self["keyGreen"] , "OK = History")
  FFTBJT(self["keyYellow"], "Menu = Custom Cmds")
  FFTBJT(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVrc86 ,
   "cancel": self.VVIVWh  ,
   "menu" : self.VVwkuy ,
   "last" : self.VVWazG  ,
   "next" : self.VVWazG  ,
   "1"  : self.VVWazG  ,
   "2"  : self.VVWazG  ,
   "3"  : self.VVWazG  ,
   "4"  : self.VVWazG  ,
   "5"  : self.VVWazG  ,
   "6"  : self.VVWazG  ,
   "7"  : self.VVWazG  ,
   "8"  : self.VVWazG  ,
   "9"  : self.VVWazG  ,
   "0"  : self.VVWazG
  })
  self.onLayoutFinish.append(self.VVBp8x)
  self.onClose.append(self.VV8gXY)
 def VVBp8x(self):
  self["myLabel"].VVZ8z1(isResizable=False, outputFileToSave="terminal")
  FFtB5m(self["keyRed"]  , "#00ff8000")
  FFvobF(self["keyRed"]  , self.skinParam["titleColor"])
  FFvobF(self["keyGreen"]  , self.skinParam["titleColor"])
  FFvobF(self["keyYellow"] , self.skinParam["titleColor"])
  FFvobF(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVcgWH(FFU8jM("date"), 5)
  result = FFU8jM("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVpAdg()
  self.VV2for()
 def VV2for(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVn5zG + "LinuxCommands.lst"
  templPath = VVV9bl + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFlh8N("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFdy80("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VV8gXY(self):
  if self.container.VVqGqE():
   self.container.killAll()
   self.VVcgWH("Process killed\n", 4)
   self.VVpAdg()
 def VVIVWh(self):
  if self.container.VVqGqE():
   self.VV8gXY()
  else:
   FFZnVu(self, self.close, "Exit ?", VVCEKd=False)
 def VVpAdg(self):
  self.VVcgWH(self.prompt, 1)
  self["keyRed"].hide()
 def VVcgWH(self, txt, mode):
  if   mode == 1 : color = VVMdMA
  elif mode == 2 : color = VViC5D
  elif mode == 3 : color = VVWK7B
  elif mode == 4 : color = VVL6GV
  elif mode == 5 : color = VVrVS3
  elif mode == 6 : color = VVPwgj
  else   : color = VVWK7B
  try:
   self["myLabel"].appendText(FFivHt(txt, color))
  except:
   pass
 def VVrc86(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVPINV() == "":
   self.VVQnhZ("cd /tmp")
   self.VVQnhZ("ls")
  VVX2QD = []
  if fileExists(self.commandHistoryFile):
   lines  = FFHq6Y(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVX2QD.append((str(c), line, str(lNum)))
   self.VVgRk7(VVX2QD, title, self.commandHistoryFile, isHistory=True)
  else:
   FFdxlA(self, self.commandHistoryFile, title=title)
 def VVPINV(self):
  lastLine = FFU8jM("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVQnhZ(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVwkuy(self, VVgl66=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFHq6Y(self.customCommandsFile)
   VVX2QD = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVX2QD.append((str(c), line, str(lNum)))
   if VVgl66:
    VVgl66.VVrEsw(VVX2QD)
    VVgl66.VVICdA(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVgRk7(VVX2QD, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFdxlA(self, self.customCommandsFile, title=title)
 def VVgRk7(self, VVX2QD, title, filePath=None, isHistory=False):
  if VVX2QD:
   VVlVSy = "#05333333"
   if isHistory: VVBBM8 = VVa80e = VVaOdk = "#11000020"
   else  : VVBBM8 = VVa80e = VVaOdk = "#06002020"
   VVkkpG   = ("Send"   , BF(self.VVi2Xi, isHistory)  , [])
   VV6LI6  = ("Modify & Send" , self.VVleaN     , [])
   if isHistory:
    VVH4Z8 = ("Clear History" , self.VVZFjN     , [])
    VVmhJa = None
    VVPn7Q = None
   elif filePath:
    VVH4Z8 = ("Options"  , self.VVLtUJ      , [])
    VVmhJa = ("Edit File"  , BF(self.VV6xRf, filePath) , [])
    VVPn7Q = (""    , self.VVsWiQ     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VV8zKo = (CENTER , LEFT   , CENTER )
   VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa, VVPn7Q=VVPn7Q, lastFindConfigObj=CFG.lastFindTerminal, VVMXk9=True, searchCol=1
         , VVBBM8=VVBBM8, VVa80e=VVa80e, VVaOdk=VVaOdk, VVlVSy=VVlVSy)
   if not isHistory:
    VVgl66.VVICdA(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFZnVu(self, BF(self.VVtpr5, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVsWiQ(self, VVgl66, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFivHt("Command:", VVhb13), colList[1])
  txt += "%s\n%s\n\n" % (FFivHt("Line %s in File:" % colList[2], VVhb13), self.customCommandsFile)
  FFucjH(self, txt, title=title)
 def VVLtUJ(self, VVgl66, title, txt, colList):
  mSel = CCXfgt(self, VVgl66)
  VVgsyy = []
  txt1 = "Change Custom Commands File"
  if VVgl66.VVIa5A:
   VVgsyy.append((txt1, ))
   VVgsyy.append(VVzHzv)
   totSel = VVgl66.VVGnLM()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFivHt(totTxt, VVMdMA) if totSel else totTxt, FFZevi(totSel))
   VVgsyy.append((txt2, "send") if totSel else (txt2,))
  else:
   VVgsyy.append((txt1, "newFile"))
   VVgsyy.append(VVzHzv)
   txt2 = "Send current line"
   VVgsyy.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVtpr5, VVgl66, txt1)
     , "send" : BF(self.VVi2Xi, False, VVgl66, title, txt2, colList) }
  mSel.VVnFMb(VVgsyy, cbFncDict, okFnc=BF(self.VVxakH, VVgl66))
 def VVtpr5(self, VVgl66, title):
  VVgsyy = []
  for fName in os.listdir(VVn5zG):
   path = os.path.join(VVn5zG, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVgsyy.append((fName, path))
  VVgsyy.sort(key=lambda x: x[0].lower())
  if VVgsyy : FFCO3u(self, BF(self.VV8run, VVgl66, title), VVgsyy=VVgsyy, title=title, minRows=3, VVBBM8="#11220000", VVa80e="#11220000")
  else  : FF2zEl(self, "No valid files found in:\n\n%s" % VVn5zG, title=title)
 def VV8run(self, VVgl66, title, path=None):
  if path:
   if CCxFIK.VVy2Za(path):
    FF2zEl(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFHq6Y(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFH7ga(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFH7ga(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVwkuy(VVgl66)
      break
    else:
     FF2zEl(self, "File is empty:\n\n%s" % path, title=title)
 def VVxakH(self, VVgl66):
  if VVgl66.VVIa5A : VVgl66.VVzU64()
  else        : VVgl66.VVFaTA()
 def VVi2Xi(self, isHistory, VVgl66, title, txt, colList):
  if VVgl66.VVIa5A:
   lst = VVgl66.VVCkXr(1)
   curNdx = VVgl66.VVyKl2()
  else:
   lst = [colList[1]]
   curNdx = VVgl66.VVKltF()
  if not isHistory:
   FFH7ga(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVgl66.cancel()
  FFnB9O(self.VVPeAD)
 def VVPeAD(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVcgWH("\n%s\n" % cmd, 6)
    self.VVcgWH(self.prompt, 1)
    self.VVPeAD()
   else:
    self.VV2x4u(cmd)
 def VV2x4u(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVcgWH(cmd, 2)
   self.VVcgWH("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVcgWH(ch, 0)
   self.VVcgWH("\nor\n", 4)
   self.VVcgWH("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVpAdg()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFivHt(parts[0].strip(), VViC5D)
    right = FFivHt("#" + parts[1].strip(), VVPwgj)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVcgWH(txt, 2)
   lastLine = self.VVPINV()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVQnhZ(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVRbqn, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF2zEl(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVcgWH(data, 3)
 def VVRbqn(self, data, retval):
  if not retval == 0:
   self.VVcgWH("Exit Code : %d\n" % retval, 4)
  self.VVpAdg()
  if self.commandsList:
   self.VVPeAD()
 def VVleaN(self, VVgl66, title, txt, colList):
  if VVgl66.VVrqfa():
   cmd = colList[1]
   self.VVvg44(VVgl66, cmd)
 def VVZFjN(self, VVgl66, title, txt, colList):
  FFZnVu(self, BF(self.VV6BJq, VVgl66), "Reset History File ?", title="Command History")
 def VV6BJq(self, VVgl66):
  FFdy80("> '%s'" % self.commandHistoryFile)
  VVgl66.cancel()
 def VV6xRf(self, filePath, VVgl66, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCDQxK(self, filePath, VVRlGe=BF(self.VVBBpC, VVgl66), curRowNum=rowNum)
  else     : FFdxlA(self, filePath)
 def VVBBpC(self, VVgl66, fileChanged):
  if fileChanged:
   VVgl66.cancel()
   FFnB9O(self.VVwkuy)
 def VVWazG(self):
  self.VVvg44(None, self.lastCommand)
 def VVvg44(self, VVgl66, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF7lc9(self, BF(self.VVo7Bq, VVgl66), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVo7Bq(self, VVgl66, cmd):
  if cmd and len(cmd) > 0:
   self.VV2x4u(cmd)
   if VVgl66:
    VVgl66.cancel()
class CC0B12(Screen):
 def __init__(self, session, title="", message="", VVFq7T=VVnE8x, width=1400, height=900, VVMeLm=False, titleBg="#22002020", VVaOdk="#22001122", VVJA7R=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFAm4L(VVCmnq, width, height, titleFontSize, 30, 20, titleBg, VVaOdk, VVJA7R)
  self.session   = session
  FFNG7m(self, title, addScrollLabel=True)
  self.VVFq7T   = VVFq7T
  self.VVMeLm   = VVMeLm
  self.VVaOdk   = VVaOdk
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self["myLabel"].VVZ8z1(VVMeLm=self.VVMeLm, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVFq7T)
  self["myLabel"].VVsIzd()
class CCUVEU(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFAm4L(VVvs8q, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFNG7m(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFo9Jy(self["errPic"], "err")
class CCKJ4S(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFAm4L(VVWpcL, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFNG7m(self, " ", addCloser=True)
class CCFzIL():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCFzIL.VVsGcd(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVk9sh)
  except: self.timer.callback.append(self.VVk9sh)
  self.timer.start(timeout, True)
 def VVk9sh(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVsGcd(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCKJ4S, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FF6C1b(win["myWinTitle"], shadColor, shadW)
  CCFzIL.VVIUc0(win, txt)
  return win
 @staticmethod
 def VVIUc0(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCS6qp():
 VVnCvV    = 0
 VVCGFs  = 1
 VVU8H9   = ""
 VVlLeb    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVgl66   = None
  self.timer     = eTimer()
  self.VVpxSz   = 0
  self.VVUhcH  = 1
  self.VViTt5  = 2
  self.VV4doy   = 3
  self.VV6wU0   = 4
  VVX2QD = self.VVbXxj()
  if VVX2QD:
   self.VVgl66 = self.VVQjS9(VVX2QD)
  if not VVX2QD and mode == self.VVnCvV:
   self.VV3xCD("Download list is empty !")
   self.cancel()
  if mode == self.VVCGFs:
   FF3LD6(self.VVgl66 or self.SELF, BF(self.VVcREQ, startDnld, decodedUrl), title="Checking Server ...")
  self.VVOf9r(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVOf9r)
  except:
   self.timer.callback.append(self.VVOf9r)
  self.timer.start(1000, False)
 def VVQjS9(self, VVX2QD):
  VVX2QD.sort(key=lambda x: int(x[0]))
  VVZAcA = self.VVn5nN
  VVkkpG  = ("Play"  , self.VVm4BE , [])
  VVPn7Q = (""   , self.VVkP9z  , [])
  VVTaaj = ("Stop"  , self.VVXrpr  , [])
  VV6LI6 = ("Resume"  , self.VVwiDn , [])
  VVH4Z8 = ("Options" , self.VVhygq  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV8zKo  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFyrIU(self.SELF, None, title=self.Title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVkkpG=VVkkpG, VVPn7Q=VVPn7Q, VVZAcA=VVZAcA, VVTaaj=VVTaaj, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, lastFindConfigObj=CFG.lastFindIptv, VVBBM8="#11220022", VVa80e="#11110011", VVaOdk="#11110011", VVlVSy="#00223025", VV3FyM="#0a333333", VVf4Ym="#0a400040", VVMXk9=True, searchCol=1)
 def VVbXxj(self):
  lines = CCS6qp.VVXdF1()
  VVX2QD = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VV1hI4(decodedUrl)
      if fName:
       if   FFGkXb(decodedUrl) : sType = "Movie"
       elif FF6H6X(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVBT4f(decodedUrl, fName)
       if size > -1: sizeTxt = CCxFIK.VVe4Bo(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVX2QD.append((str(len(VVX2QD) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVX2QD
 def VVa7oo(self):
  VVX2QD = self.VVbXxj()
  if VVX2QD:
   if self.VVgl66 : self.VVgl66.VVrEsw(VVX2QD, VVYHEIMsg=False)
   else     : self.VVgl66 = self.VVQjS9(VVX2QD)
  else:
   self.cancel()
 def VVOf9r(self, force=False):
  if self.VVgl66:
   thrListUrls = self.VVRdSi()
   VVX2QD = []
   changed = False
   for ndx, row in enumerate(self.VVgl66.VV3eCu()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVpxSz
    if m3u8Log:
     percent = CCS6qp.VVoOmq(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VV4doy , "%.2f %%" % percent
      else   : flag, progr = self.VV6wU0 , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFQfFR(mPath)
     if curSize > -1:
      fSize = CCxFIK.VVe4Bo(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCxFIK.VVe4Bo(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFQfFR(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VV4doy , "%.2f %%" % percent
       else   : flag, progr = self.VV6wU0 , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCxFIK.VVe4Bo(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VViTt5
     if m3u8Log :
      if not speed and not force : flag = self.VVUhcH
      elif curSize == -1   : self.VVfljB(False)
    elif flag == self.VVpxSz  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVpxSz  : color2 = "#f#00555555#"
    elif flag == self.VVUhcH : color2 = "#f#0000FFFF#"
    elif flag == self.VViTt5 : color2 = "#f#0000FFFF#"
    elif flag == self.VV4doy  : color2 = "#f#00FF8000#"
    elif flag == self.VV6wU0  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVjXSQ(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVX2QD.append(row)
   if changed or force:
    self.VVgl66.VVrEsw(VVX2QD, VVYHEIMsg=False)
 def VVjXSQ(self, flag):
  tDict = self.VVJp2F()
  return tDict.get(flag, "?")
 def VVaeKv(self, state):
  for flag, txt in self.VVJp2F().items():
   if txt == state:
    return flag
  return -1
 def VVJp2F(self):
  return { self.VVpxSz: "Not started", self.VVUhcH: "Connecting", self.VViTt5: "Downloading", self.VV4doy: "Stopped", self.VV6wU0: "Completed" }
 def VVQ9HF(self, title):
  colList = self.VVgl66.VVErbL()
  path = colList[6]
  url  = colList[8]
  if self.VVhqmm() : self.VV3xCD("Cannot delete !\n\nFile is downloading.")
  else      : FFZnVu(self.SELF, BF(self.VVjRue, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVjRue(self, path, url):
  m3u8Log = self.VVgl66.VVErbL()[12]
  if m3u8Log : FFlh8N("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFlh8N("rm -rf '%s'" % path)
  self.VVSGRd(False)
  self.VVa7oo()
 def VVSGRd(self, VVnkcm=True):
  if self.VVhqmm():
   FFRB11(self.VVgl66, self.VVjXSQ(self.VViTt5), 500)
  else:
   colList  = self.VVgl66.VVErbL()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVaeKv(state) in (self.VVpxSz, self.VV6wU0, self.VV4doy):
    lines = CCS6qp.VVXdF1()
    newLines = []
    found = False
    for line in lines:
     if CCS6qp.VVUVST(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVGoE7(newLines)
     self.VVa7oo()
     FFRB11(self.VVgl66, "Removed.", 1000)
    else:
     FFRB11(self.VVgl66, "Not found.", 1000)
   elif VVnkcm:
    self.VV3xCD("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV8b0d(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFZnVu(self.SELF, BF(self.VVUJiD, flag), ques, title=title)
 def VVUJiD(self, flag):
  list = []
  for ndx, row in enumerate(self.VVgl66.VV3eCu()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVaeKv(state)
   if   flag == flagVal == self.VV6wU0: list.append(decodedUrl)
   elif flag == flagVal == self.VVpxSz : list.append(decodedUrl)
  lines = CCS6qp.VVXdF1()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVGoE7(newLines)
   self.VVa7oo()
   FFRB11(self.VVgl66, "%d removed." % totRem, 1000)
  else:
   FFRB11(self.VVgl66, "Not found.", 1000)
 def VVGmbc(self):
  colList  = self.VVgl66.VVErbL()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFRB11(self.VVgl66, "Poster exists", 1500)
  else    : FF3LD6(self.VVgl66, BF(self.VVyztO, decodedUrl, path, png), title="Checking Server ...")
 def VVyztO(self, decodedUrl, path, png):
  err = self.VVback(decodedUrl, path, png)
  if err:
   FF2zEl(self.SELF, err, title="Poster Download")
 def VVback(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCbrHa.VVTvVJ(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCA7uK.VVhDYU(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCA7uK.VVkQUQ(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCA7uK.VVqlay(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFZXhR(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFlh8N("mv -f '%s' '%s'" % (tPath, png))
   CCslfl.VVIg0A(self.SELF, VVBK02=png, showGrnMsg="Downloaded")
   return ""
 def VVkP9z(self, VVgl66, title, txt, colList):
  def VV65di(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVBMvF(key, val) : return "\n%s:\n%s\n" % (FFivHt(key, VVhb13), val.strip())
  heads  = self.VVgl66.VVCwRO()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV65di(heads[i]  , CCxFIK.VVe4Bo(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV65di("Downloaded" , CCxFIK.VVe4Bo(int(curSize), mode=0))
   else:
    txt += VV65di(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVBMvF(heads[i], colList[i])
  FFucjH(self.SELF, txt, title=title)
 def VVm4BE(self, VVgl66, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCxFIK.VVB4hc(self.SELF, path)
  else    : FFRB11(self.VVgl66, "File not found", 1000)
 def VVn5nN(self, VVgl66):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVgl66:
   self.VVgl66.cancel()
  del self
 def VVhygq(self, VVgl66, title, txt, colList):
  c1, c2, c3 = VVAQIK, VVL6GV, VVhb13
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVgsyy = []
  VVgsyy.append((c1 + "Remove current row"       , "VVSGRd" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVgsyy.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Delete the file (and remove from list)"  , "VVQ9HF"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((resumeTxt + " Auto Resume"       , "VVLdDi" ))
  VVgsyy.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVgsyy.append(VVzHzv)
  cond = FFGkXb(decodedUrl)
  VVgsyy.append(FFDNao("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVGmbc", cond, c3))
  VVgsyy.append(FFDNao("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFCO3u(self.SELF, BF(self.VVDPz2, VVgl66), VVgsyy=VVgsyy, title=self.Title, VVf67P=True, width=800, VVwQO5=True, VVBBM8="#1a001122", VVa80e="#1a001122")
 def VVDPz2(self, VVgl66, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVSGRd"  : self.VVSGRd()
   elif ref == "remFinished"   : self.VV8b0d(self.VV6wU0, txt)
   elif ref == "remPending"   : self.VV8b0d(self.VVpxSz, txt)
   elif ref == "VVQ9HF" : self.VVQ9HF(txt)
   elif ref == "VVGmbc"  : self.VVGmbc()
   elif ref == "VVLdDi"  : FFH7ga(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFH7ga(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCxFIK, mode=CCxFIK.VV5Jpg, jumpToFile=path)
    else    : FFRB11(VVgl66, "Path not found !", 1500)
 def VVcREQ(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCbrHa.VVTvVJ(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VV3xCD("Could not get download link !\n\nTry again later.")
     return
  for line in CCS6qp.VVXdF1():
   if CCS6qp.VVUVST(decodedUrl, line):
    if self.VVgl66:
     self.VV6gkz(decodedUrl)
     FFnB9O(BF(FFRB11, self.VVgl66, "Already listed !", 2000))
    break
  else:
   params = self.VVzhTN(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VV3xCD(params[0])
   elif len(params) == 2:
    FFZnVu(self.SELF, BF(self.VVfdgY, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCxFIK.VVe4Bo(fSize)
    FFZnVu(self.SELF, BF(self.VVBa8A, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVBa8A(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCS6qp.VVWo83(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVa7oo()
  if self.VVgl66:
   self.VVgl66.VVS0MS()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCS6qp.VVlLeb, path, decodedUrl)
   self.VVEmSv(threadName, url, decodedUrl, path, resp)
 def VV6gkz(self, decodedUrl):
  if self.VVgl66:
   for ndx, row in enumerate(self.VVgl66.VV3eCu()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVgl66:
     self.VVgl66.VVICdA(ndx)
     break
 def VVzhTN(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VV1hI4(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVBT4f(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCbrHa.VVTvVJ(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCbrHa.VVDnPN()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCS6qp.VV1geZ(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCS6qp.VVsOjf(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVfdgY(self, resp, decodedUrl):
  if not FFwmhG("ffmpeg"):
   FFZnVu(self.SELF, BF(CCA7uK.VVLWn1, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VV1hI4(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVimTp(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFZnVu(self.SELF, BF(self.VVJnAW, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVJnAW(rTxt, rUrl)
  else:
   self.VV3xCD("Cannot process m3u8 file !")
 def VVimTp(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVgsyy = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCA7uK.VVLfXf(rUrl, fPath)
   VVgsyy.append((resol, fullUrl))
  if VVgsyy:
   FFCO3u(self.SELF, self.VVxivz, VVgsyy=VVgsyy, title="Resolution", VVf67P=True, VVwQO5=True)
  else:
   self.VV3xCD("Cannot get Resolutions list from server !")
 def VVxivz(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFZnVu(self.SELF, BF(FFnB9O, BF(self.VVvFQY, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFnB9O(BF(self.VVvFQY, resolUrl))
 def VVvFQY(self, resolUrl):
  txt, err = CCbrHa.VV6uu3(resolUrl)
  if err : self.VV3xCD(err)
  else : self.VVJnAW(txt, resolUrl)
 def VVZSRR(self, logF, decodedUrl):
  found = False
  lines = CCS6qp.VVXdF1()
  with open(CCS6qp.VVWo83(), "w") as f:
   for line in lines:
    if CCS6qp.VVUVST(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCS6qp.VVWo83(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVa7oo()
  if self.VVgl66:
   self.VVgl66.VVS0MS()
 def VVJnAW(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCA7uK.VVLfXf(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VV3xCD("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVZSRR(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFT1jM("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCS6qp.VVlLeb, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVoOmq(dnldLog):
  if fileExists(dnldLog):
   dur = CCS6qp.VVdHtr(dnldLog)
   if dur > -1:
    tim = CCS6qp.VVFK9I(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVdHtr(dnldLog):
  lines = FFIeeK("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVFK9I(dnldLog):
  lines = FFIeeK("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVBT4f(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FF6H6X(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFlh8N("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVEmSv(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVgl66.VVErbL()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVvo8d, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVvo8d(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVU8H9 == path:
       break
     else:
      break
  except:
   return
  if CCS6qp.VVU8H9:
   CCS6qp.VVU8H9 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFQfFR(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVzhTN(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVvo8d(url, decodedUrl, path, resp, totFileSize, True)
 def VVXrpr(self, VVgl66, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVA90B() : FFRB11(self.VVgl66, self.VVjXSQ(self.VV6wU0), 500)
  elif not self.VVhqmm() : FFRB11(self.VVgl66, self.VVjXSQ(self.VV4doy), 500)
  elif m3u8Log      : FFZnVu(self.SELF, self.VVfljB, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVRdSi():
    CCS6qp.VVU8H9 = colList[6]
    FFRB11(self.VVgl66, "Stopping ...", 1000)
   else:
    FFRB11(self.VVgl66, "Stopped", 500)
 def VVfljB(self, withMsg=True):
  if withMsg:
   FFRB11(self.VVgl66, "Stopping ...", 1000)
  FFlh8N("killall -INT ffmpeg")
 def VVwiDn(self, *args):
  if   self.VVA90B() : FFRB11(self.VVgl66, self.VVjXSQ(self.VV6wU0) , 500)
  elif self.VVhqmm() : FFRB11(self.VVgl66, self.VVjXSQ(self.VViTt5), 500)
  else:
   resume = False
   m3u8Log = self.VVgl66.VVErbL()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFZnVu(self.SELF, BF(self.VVbxl6, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV0FaX():
    resume = True
   if resume: FF3LD6(self.VVgl66, BF(self.VVQGY1), title="Checking Server ...")
   else  : FFRB11(self.VVgl66, "Cannot resume !", 500)
 def VVbxl6(self, m3u8Log):
  FFlh8N("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FF3LD6(self.VVgl66, BF(self.VVQGY1), title="Checking Server ...")
 def VVQGY1(self):
  colList  = self.VVgl66.VVErbL()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCbrHa.VVTvVJ(decodedUrl)
   if url:
    decodedUrl = self.VVErNI(decodedUrl, url)
   else:
    self.VV3xCD("Could not get download link !\n\nTry again later.")
    return
  curSize = FFQfFR(path)
  params = self.VVzhTN(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VV3xCD(params[0])
   return
  elif len(params) == 2:
   self.VVfdgY(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVErNI(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCS6qp.VVlLeb, path, decodedUrl)
  if resumable: self.VVEmSv(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VV3xCD("Cannot resume from server !")
 def VV1hI4(self, decodedUrl):
  fileExt = CCA7uK.VVjCHm(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF8SD1(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VV3xCD(self, txt):
  FF2zEl(self.SELF, txt, title=self.Title)
 def VVRdSi(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCS6qp.VVlLeb, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVhqmm(self):
  decodedUrl = self.VVgl66.VVErbL()[9]
  return decodedUrl in self.VVRdSi()
 def VVA90B(self):
  colList = self.VVgl66.VVErbL()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFQfFR(path)) == size
 def VV0FaX(self):
  colList = self.VVgl66.VVErbL()
  path = colList[6]
  size = int(colList[7])
  curSize = FFQfFR(path)
  if curSize > -1:
   size -= curSize
  err = CCS6qp.VVsOjf(size)
  if err:
   FF2zEl(self.SELF, err, title=self.Title)
   return False
  return True
 def VVGoE7(self, list):
  with open(CCS6qp.VVWo83(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVErNI(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCS6qp.VVXdF1()
  url = decodedUrl
  with open(CCS6qp.VVWo83(), "w") as f:
   for line in lines:
    if CCS6qp.VVUVST(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVa7oo()
  return url
 @staticmethod
 def VVXdF1():
  list = []
  if fileExists(CCS6qp.VVWo83()):
   for line in FFHq6Y(CCS6qp.VVWo83()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVUVST(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVsOjf(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCxFIK.VVZLIW(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCxFIK.VVe4Bo(size), CCxFIK.VVe4Bo(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVDsMP(SELF):
  tot = CCS6qp.VVSpE9()
  if tot:
   FF2zEl(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVSpE9():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCS6qp.VVlLeb):
    c += 1
  return c
 @staticmethod
 def VV0nzr():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCS6qp.VVlLeb, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVnPmJ():
  return len(CCS6qp.VVXdF1()) == 0
 @staticmethod
 def VVy125():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVDA0i():
  mPoints = CCS6qp.VVy125()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFlh8N("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVWo83():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVKwKj(SELF, waitMsgObj=None):
  FF3LD6(waitMsgObj or SELF, BF(CCS6qp.VVZBtm, SELF, CCS6qp.VVnCvV))
 @staticmethod
 def VV618R(SELF):
  CCS6qp.VVZBtm(SELF, CCS6qp.VVCGFs, startDnld=True)
 @staticmethod
 def VVlmci(SELF, url):
  CCS6qp.VVZBtm(SELF, CCS6qp.VVCGFs, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVs0xM(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF)
  added, skipped = CCS6qp.VVLvrE([decodedUrl])
  FFRB11(SELF, "Added", 1000)
 @staticmethod
 def VVLvrE(list):
  added = skipped = 0
  for line in CCS6qp.VVXdF1():
   for ndx, url in enumerate(list):
    if url and CCS6qp.VVUVST(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCS6qp.VVWo83(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVZBtm(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCD0Wo.VVzlRk(SELF):
   return
  if mode == CCS6qp.VVnCvV and CCS6qp.VVnPmJ():
   FF2zEl(SELF, "Download list is empty !", title=title)
  else:
   inst = CCS6qp(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VV1geZ(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCC5bX(Screen, CCW2rl):
 VVbPxU = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFAm4L(VVmKq8, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCW2rl.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFNG7m(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVzXpg())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVMcMd       ,
   "info"  : self.VVR7oo      ,
   "epg"  : self.VVR7oo      ,
   "menu"  : self.VVoGnj     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVZHOB   ,
   "green"  : self.VVGV3V  ,
   "blue"  : self.VVgzqs      ,
   "yellow" : self.VVUoXr ,
   "left"  : BF(self.VVgCmb, -1)    ,
   "right"  : BF(self.VVgCmb,  1)    ,
   "play"  : self.VVldCS      ,
   "pause"  : self.VVldCS      ,
   "playPause" : self.VVldCS      ,
   "stop"  : self.VVldCS      ,
   "rewind" : self.VV287z      ,
   "forward" : self.VVGwrl      ,
   "rewindDm" : self.VV287z      ,
   "forwardDm" : self.VVGwrl      ,
   "last"  : self.VVPVYt      ,
   "next"  : self.VVrjf4      ,
   "pageUp" : BF(self.VV3CwL, True)  ,
   "pageDown" : BF(self.VV3CwL, False)  ,
   "chanUp" : BF(self.VV3CwL, True)  ,
   "chanDown" : BF(self.VV3CwL, False)  ,
   "up"  : BF(self.VV3CwL, True)  ,
   "down"  : BF(self.VV3CwL, False)  ,
   "audio"  : BF(self.VVAKXC, True)  ,
   "subtitle" : BF(self.VVAKXC, False)  ,
   "text"  : self.VVlBIG  ,
   "0"   : BF(self.VVUWYs , 10)   ,
   "1"   : BF(self.VVUWYs , 1)   ,
   "2"   : BF(self.VVUWYs , 2)   ,
   "3"   : BF(self.VVUWYs , 3)   ,
   "4"   : BF(self.VVUWYs , 4)   ,
   "5"   : BF(self.VVUWYs , 5)   ,
   "6"   : BF(self.VVUWYs , 6)   ,
   "7"   : BF(self.VVUWYs , 7)   ,
   "8"   : BF(self.VVUWYs , 8)   ,
   "9"   : BF(self.VVUWYs , 9)
  }, -1)
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  if not CCC5bX.VVbPxU:
   CCC5bX.VVbPxU = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFo9Jy(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFo9Jy(self["myPlayRpt"], "rpt")
  self.VVx8Fm()
  self.instance.move(ePoint(40, 40))
  self.VVKGkR(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVi5yo)
  except:
   self.timer.callback.append(self.VVi5yo)
  self.timer.start(250, False)
  self.VVi5yo("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVySfn()
 def VVGV3V(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  self.lastSubtitle = CCMW6L.VVojGM()
  if "chCode" in iptvRef:
   if CCD0Wo.VVzlRk(self):
    self.VVySfn(True)
  else:
   self.VVi5yo("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVx8Fm(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVviNO()
  chName = FFkgYM(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVgmAg + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFvobF(self["myTitle"], tColor)
  FFvobF(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFvobF(self["myPlay%s" % item], tColor)
  picFile = CCTzTd.VV6y0c(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCTzTd.VVb80o(self)
  cl = CCHGEE.VVqFaS(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVi5yo(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCS6qp.VVSpE9()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVviNO()
  if evName:
   evName = "    %s    " % FFivHt(evName, VVrVS3)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVmFbq():
   FFtB5m(self["myPlayBlu"], "#00FFFFFF")
   FFvobF(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFtB5m(self["myPlayBlu"], "#00FFFF88")
   FFvobF(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCA7uK.VVKhAQ(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVPwgj + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFvobF(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFVUcd(percVal, 0, 100)
   width = int(FFGgcy(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFvobF(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFtB5m(self["myPlayMsg"], "#0000ffff")
   else  : FFtB5m(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFtB5m(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFtB5m(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVd7HR()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVooUP(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCMW6L.VVcq7D(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVPVYt()
  state = self.VVZqNz()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFtB5m(self["myPlayMsg"], "#0000ff00")
  else     : FFtB5m(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVviNO(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFiRis(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCTzTd.VVgmmZ(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCgl59()
   tpTxt, satTxt = tp.VVy6gq(refCode)
   self.satInfo_TP = tpTxt + "  " + FFivHt(satTxt, VVVJaM)
  evName = evNameNext = ""
  evLst = CCje5B.VVAM04(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFR7wS(info, iServiceInformation.sVideoWidth) or -1
   h = FFR7wS(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFR7wS(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCTzTd.VVJmkH(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VV3wSN(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFz41A(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFz41A(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFz41A(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVoGnj(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVviNO()
  FFGkXbSeries = FF8SD1(decodedUrl)
  VVgsyy = []
  if not "VVRBe7" in globals() and not "VVz86I" in globals():
   VVgsyy.append((VVVJaM + "IPTV Menu", "iptv"))
   VVgsyy.append(VVzHzv)
  if isIptv and not "&end=" in decodedUrl and not FFGkXbSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCA7uK.VVhDYU(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVgsyy.append((VVVJaM + "Catchup Programs", "catchup" ))
    VVgsyy.append(VVzHzv)
  if refCode:
   c = VVgmAg
   VVgsyy.append((c + "Stop Current Service"  , "stop"  ))
   VVgsyy.append((c + "Restart Current Service" , "restart"  ))
   VVgsyy.append(FFDNao("Replay with ..." , "replayWith", not isDvb, c))
   VVgsyy.append(VVzHzv)
  if FFGkXbSeries:
   VVgsyy.append((VVVJaM + "File Size (on server)", "fileSize" ))
   VVgsyy.append(VVzHzv)
  if self.enableDownloadMenu:
   c = VVVJaM
   addSep = False
   if isIptv and FFGkXbSeries:
    VVgsyy.append((c + "Start Download"  , "dload_cur" ))
    VVgsyy.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCS6qp.VVnPmJ():
    VVgsyy.append((VVVJaM + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVgsyy.append(VVzHzv)
  fPath, fDir, fName = CCxFIK.VVscnA(self)
  if fPath:
   c = VVL7a3
   if not "VV48b4" in globals():
    VVgsyy.append((c + "Open path in File Manager", "VVCF0C"))
   VVgsyy.append((c + "Add to Bouquet"             , "VVyPdf" ))
   VVgsyy.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV1Fid"  ))
   VVgsyy.append(VVzHzv)
  elif isFtp:
   VVgsyy.append((VVhb13 + "Add FTP Media to Bouquet"     , "VV6Npk"))
  if isDvb:
   VVgsyy.append((VVVJaM + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVgsyy.append((VVhb13 + "Start Subtitle", "VVvFU0"))
   VVgsyy.append(VVzHzv)
  if CFG.playerPos.getValue() : VVgsyy.append(("Move Bar to Bottom" , "botm"))
  else      : VVgsyy.append(("Move Bar to Top" , "top" ))
  VVgsyy.append(("Help", "help"))
  FFCO3u(self, self.VVzE3N, VVgsyy=VVgsyy, width=600, title="Options")
 def VVzE3N(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVUoXr()
   elif item == "stop"     : self.VVMwk3(0)
   elif item == "restart"    : self.VVMwk3(1)
   elif item == "replayWith"   : self.VVNn19()
   elif item == "fileSize"    : FF3LD6(self, BF(CCTzTd.VVEuoo, self), title="Checking Server")
   elif item == "dload_cur"   : CCS6qp.VV618R(self)
   elif item == "addToDload"   : CCS6qp.VVs0xM(self)
   elif item == "dload_stat"   : CCS6qp.VVKwKj(self)
   elif item == "VVCF0C" : self.close("close_openInFileMan")
   elif item == "VVyPdf" : self.VVyPdf()
   elif item == "VV6Npk" : self.VV6Npk()
   elif item == "VVvFU0"  : self.VVCXN3()
   elif item == "VV1Fid"  : self.VV1Fid()
   elif item == "botm"     : self.VVKGkR(0)
   elif item == "top"     : self.VVKGkR(1)
   elif item == "sigMon"    : self.VVZHOB()
   elif item == "help"     : FF6duf(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCC5bX.VVbPxU = None
 def VVMwk3(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVx8Fm()
   elif typ == 1:
    self.VVi5yo("Restarting Service ...")
    FFnB9O(BF(self.VVEWjz, serv))
 def VVEWjz(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  if "&end=" in decodedUrl: BF(self.VVySfn, True)
  else     : self.session.nav.playService(serv)
 def VVNn19(self):
  FFCO3u(self, self.VVIZHt, VVgsyy=CCA7uK.VVFs6h(), width=650, title="Select Player", VVBBM8="#11220000", VVa80e="#11220000")
 def VVIZHt(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFlfXr(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVi5yo("No active service !")
 def VVyPdf(self):
  fPath, fDir, fName = CCxFIK.VVscnA(self)
  if fPath: picker = CCqHUu(self, self, "Add Current Movie to a Bouquet", BF(self.VVXfD8, [fPath]))
  else : FFRB11(self, "Path not found !", 1500)
 def VVXfD8(self, pathLst):
  return CCqHUu.VVhsoS(pathLst)
 def VV6Npk(self):
  picker = CCqHUu(self, self, "Add FTP Media to Bouquet", self.VVtLPS)
 def VVtLPS(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  return CCqHUu.VVhsoS([origUrl], rType=refCode.split(":", 1)[0])
 def VV1Fid(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVi5yo(txt, highlight=ok)
 def VVKGkR(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFH7ga(CFG.playerPos, pos)
 def VVZHOB(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCTzTd.VVgmmZ(serv)
   if isDvb: self.close("close_sig")
   else : self.VVi5yo("No Signal for Current Service")
 def VVCXN3(self):
  self.session.openWithCallback(self.VVbwy5, BF(CCMW6L))
 def VVlBIG(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVviNO()
   if posTxt and durTxt: self.VVCXN3()
   else    : self.VVi5yo("No duration Info. !")
 def VVbwy5(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VV3CwL(True)
  elif reason == "subtZapDn" : self.VV3CwL(False)
  elif reason == "pause"  : self.VVldCS()
  elif reason == "audio"  : self.VVAKXC(True)
  elif reason == "subtitle" : self.VVAKXC(False)
  elif reason == "rewind"     : self.VV287z()
  elif reason == "forward" : self.VVGwrl()
  elif reason == "rewindDm" : self.VV287z()
  elif reason == "forwardDm" : self.VVGwrl()
  else      : txt = reason
  if txt:
   FFRB11(self, txt, 2000)
 def VVMcMd(self):
  if self.isManualSeek:
   self.VVIV2r()
   self.VVooUP(self.manualSeekPts)
  elif self.shown:
   if CCMW6L.VVJFyy(self): self.VVCXN3()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVIV2r()
  else    : self.close()
 def VVR7oo(self):
  FFBxYU(self, fncMode=CCTzTd.VVMtw8)
 def VVldCS(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVi5yo("Toggling Play/Pause ...")
 def VVIV2r(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVgCmb(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVX82P()
   else:
    self.manualSeekSec += direc * self.VVX82P()
    self.manualSeekSec = FFVUcd(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFGgcy(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFz41A(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVUWYs(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVzXpg())
   FFH7ga(CFG.playerJumpMin, self.jumpMinutes)
  self.VVi5yo("Changed Seek Time to : %d%s" % (val, self.VVOMAG()))
 def VVzXpg(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVOMAG())
 def VVOMAG(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVMzL0(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVX82P(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVd7HR(self):
  if "VVicJx" in globals():
   global VVicJx
   if VVicJx:
    VVicJx = VVicJx[1:-1]
    if len(VVicJx) == 3: VVicJx = ""
    else     : return VVicJx
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVgzqs(self):
  cList = self.VVmFbq()
  if cList:
   VVgsyy = []
   for pts, what in cList:
    txt = FFz41A(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVgsyy.append((txt, pts))
   FFCO3u(self, self.VVVugq, VVgsyy=VVgsyy, title="Cut List")
  else:
   self.VVi5yo("No Cut-List for this channel !")
 def VVVugq(self, item=None):
  if item:
   self.VVooUP(item)
 def VVmFbq(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVGwrl(self) : self.VV2MyO(1)
 def VV287z(self) : self.VV2MyO(-1)
 def VV2MyO(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVX82P() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVMzL0())
    self.VVi5yo(txt)
  except:
   self.VVi5yo("Cannot jump")
 def VVooUP(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVi5yo("Changing Time ...")
 def VVPVYt(self):
  self.VVMwk3(1)
  self.VVi5yo("Replaying ...")
  self.VVIV2r()
 def VVrjf4(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVi5yo("Jumping to end ...")
  except:
   pass
 def VVZqNz(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV3CwL(self, isUp):
  if self.enableZapping:
   self.VVi5yo("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVIV2r()
   if self.iptvTableParams:
    FFnB9O(BF(self.VVEXCE, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
    if "/timeshift/" in decodedUrl:
     self.VVi5yo("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVpTOH()
  else:
   self.VVi5yo("Zap Disabled !")
 def VVpTOH(self):
  self.lastPlayPos = 0
  self.VVx8Fm()
  self.VVySfn()
 def VVEXCE(self, isUp):
  CCA7uK_inatance, VVgl66, mode = self.iptvTableParams
  if isUp : VVgl66.VVroOn()
  else : VVgl66.VV97DQ()
  colList = VVgl66.VVErbL()
  if mode == "localIptv":
   chName, chUrl = CCA7uK_inatance.VVeejR(VVgl66, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCA7uK_inatance.VVDHk9(VVgl66, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCA7uK_inatance.VVZXod(mode, VVgl66, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCA7uK_inatance.VV8Xhc(mode, VVgl66, colList)
  else:
   self.VVi5yo("Cannot Zap")
   return
  FFQhSW(self, chUrl, VVehU2=False)
  self.VVpTOH()
 def VVySfn(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
   if not self.VVJjy0(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVi5yo("Refreshing Portal")
   FFnB9O(self.VVSBFU)
  except:
   pass
 def VVSBFU(self):
  self.restoreLastPlayPos = self.VVckUe()
 def VVUoXr(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
  if not decodedUrl or FF8SD1(decodedUrl):
   self.VVi5yo("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCA7uK.VVhDYU(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVi5yo("Reading Program List ...")
   ok_fnc = BF(self.VVr0Ub, refCode, chName, streamId, uHost, uUser, uPass)
   FFnB9O(BF(CCA7uK.VVAHPb, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVi5yo("Cannot process this channel")
 def VVr0Ub(self, refCode, chName, streamId, uHost, uUser, uPass, VVgl66, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVgl66.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVi5yo("Changing Program ...")
   FFnB9O(BF(self.VVwkbL, chUrl))
  else:
   self.VVi5yo("Incorrect Timestamp !")
 def VVwkbL(self, chUrl):
  FFQhSW(self, chUrl, VVehU2=False)
  self.lastPlayPos = 0
  self.VVx8Fm()
 def VVAKXC(self, isAudio):
  try:
   VV15Ea = InfoBar.instance
   if VV15Ea:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV15Ea)
    else  : self.session.open(SubtitleSelection, VV15Ea)
  except:
   pass
 @staticmethod
 def VVZRqA(session, mode=None):
  if   mode == "close_sig"   : FFTXqQ(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCA7uK)
  elif mode == "close_openInFileMan" : session.open(CCxFIK, gotoMovie=True)
 @staticmethod
 def VVBgB6(session, **kwargs):
  session.openWithCallback(BF(CCC5bX.VVZRqA, session), CCC5bX, **kwargs)
class CCR2bg(Screen):
 def __init__(self, session, title="", VVWZXE="Continue?", VVCEKd=True, VVOuLx=False):
  self.skin, self.skinParam = FFAm4L(VVLyZo, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVWZXE = VVWZXE
  self.VVOuLx = VVOuLx
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVCEKd : VVgsyy = [no , yes]
  else   : VVgsyy = [yes, no ]
  FFNG7m(self, title, VVgsyy=VVgsyy, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVMcMd ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVWZXE)
  if self.VVOuLx:
   self["myLabel"].instance.setHAlign(0)
  self.VViPfG()
  FFyZo3(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFm4TZ(self["myMenu"])
  FFYdpp(self, self["myMenu"])
 def VVMcMd(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VViPfG(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCJFTB(Screen):
 def __init__(self, session, title="", VVgsyy=None, width=1000, height=850, VVJA7R=30, barText="", minRows=1, VVwWMp=None, VVxQ85=None, VVbSf3=None, VV2u6t=None, VVOmbd=None, VVtL1m=None, VVf67P=False, VVwQO5=False, VVGamv=None, VVzKMB=True, VVBBM8="#22003344", VVa80e="#22002233"):
  self.skin, self.skinParam = FFAm4L(VVAfZq, width, height, 50, 40, 30, VVBBM8, VVa80e, VVJA7R, barHeight=40, topRightBtns=3 if VVxQ85 else 0)
  self.session   = session
  self.VVgsyy   = VVgsyy
  self.barText   = barText
  self.minRows   = minRows
  self.VVwWMp   = VVwWMp
  self.VVxQ85   = VVxQ85
  self.VVbSf3   = VVbSf3
  self.VV2u6t  = VV2u6t
  self.VVOmbd  = ("Delete File", BF(self.VVfZIP, VVGamv)) if not VVGamv is None else VVOmbd
  self.VVtL1m   = VVtL1m
  self.VVf67P  = VVf67P
  self.VVwQO5  = VVwQO5
  self.Title    = title
  FFNG7m(self, title, VVgsyy=VVgsyy)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVMcMd    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVZRkm   ,
   "red"  : self.VV3M0b   ,
   "green"  : self.VVVbuO   ,
   "yellow" : self.VVksN6   ,
   "blue"  : self.VV4NRt   ,
   "pageUp" : self.VVKtFP ,
   "chanUp" : self.VVKtFP ,
   "pageDown" : self.VVBDL8  ,
   "chanDown" : self.VVBDL8  ,
   "0"   : BF(self.VV9eLQ, 0) ,
   "1"   : BF(self.VV9eLQ, 1) ,
   "2"   : BF(self.VV9eLQ, 2) ,
   "3"   : BF(self.VV9eLQ, 3) ,
   "4"   : BF(self.VV9eLQ, 4) ,
   "5"   : BF(self.VV9eLQ, 5) ,
   "6"   : BF(self.VV9eLQ, 6) ,
   "7"   : BF(self.VV9eLQ, 7) ,
   "8"   : BF(self.VV9eLQ, 8) ,
   "9"   : BF(self.VV9eLQ, 9)
  }, -1)
  if VVzKMB:
   FFFTn6(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFyZo3(self["myMenu"])
  FFhtaK(self, minRows=self.minRows)
  FFfavv(self)
  self.VViTPW(self["keyRed"]  , self.VVbSf3 )
  self.VViTPW(self["keyGreen"] , self.VV2u6t )
  self.VViTPW(self["keyYellow"] , self.VVOmbd )
  self.VViTPW(self["keyBlue"]  , self.VVtL1m )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFzs4L(self)
 def VViTPW(self, btnObj, btnFnc):
  if btnFnc:
   FFTBJT(btnObj, btnFnc[0])
 def VVMFbN(self, fnc=None):
  self.VV2u6t = fnc
  if fnc : self.VViTPW(self["keyGreen"], self.VV2u6t)
  else : self["keyGreen"].hide()
 def VV9eLQ(self, digit):
  digit = str(digit)
  VVgsyy = self["myMenu"].list
  for ndx, item in enumerate(VVgsyy):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFkgYM(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVCNsC(ndx)
     self.VVMcMd()
     break
 def VVMcMd(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVwWMp:
    self.VVwWMp((self, txt, ref, ndx))
   else:
    if self.VVf67P: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVZRkm(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVxQ85 and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVxQ85(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VV3M0b(self)  : self.VVPR5N(self.VVbSf3)
 def VVVbuO(self) : self.VVPR5N(self.VV2u6t)
 def VVksN6(self) : self.VVPR5N(self.VVOmbd)
 def VV4NRt(self) : self.VVPR5N(self.VVtL1m)
 def VVPR5N(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVwQO5:
    self.cancel()
 def VVJBkC(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVgsyy = self["myMenu"].list
  VVgsyy.pop(ndx)
  if len(VVgsyy) > 0: self["myMenu"].setList(VVgsyy)
  else    : self.close()
 def VVfZIP(self, basePath, menuObj, fName):
  FFZnVu(self, BF(self.VVdfHH, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVdfHH(self, path):
  FFAFdq(path)
  if fileExists(path) : FFRB11(self, "Not deleted", 1000)
  else    : self.VVJBkC()
 def VVqTM0(self, VVgsyy):
  if len(VVgsyy) > 0:
   newList = []
   for item in VVgsyy:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFhtaK(self, minRows=self.minRows)
  else:
   self.close("")
 def VVbEsC(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFhtaK(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVNQdb(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVCNsC(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VViQkW(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVCNsC(ndx)
    break
 def VVSIKM(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVCNsC(ndx)
    break
 def VVKtFP(self) : self["myMenu"].moveToIndex(0)
 def VVBDL8(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCFKe9(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVX3UR=None, VV8zKo=None, VVBL0l=None, VVJA7R=26, VVMXk9=False, VVqPV4=0, VVkkpG=None, VVPn7Q=None, menuButtonFnc=None, VVTaaj=None, VV6LI6=None, VVH4Z8=None, VVmhJa=None, VVfGJE=None, VV1Zg1=None, VVZAcA=None, VVhwQH=-1, VVREBJ=0, searchCol=0, lastFindConfigObj=None, VVBBM8=None, VVa80e=None, VVVZTw="#00dddddd", VVaOdk="#11002233", VVXZ9d=None, VVlVSy="#11111111", VV3FyM="#0a555555", VV6d0J="#0affffff", VVf4Ym="#11552200", VVV2RM="#0055ff55", VVV2RMRev="#0000bbff"):
  self.skin, self.skinParam = FFAm4L(VV7DNj, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFNG7m(self, title)
  self.Title     = title
  self.header     = header
  self.VVX3UR     = VVX3UR
  self.totalCols    = len(VVX3UR[0])
  self.VVqPV4   = VVqPV4
  self.lastSortModeIsReverese = False
  self.VVMXk9   = VVMXk9
  self.VVcrus   = 0.01
  self.VV1oOY   = 0.02
  self.VV48lL = 0.03
  self.VV1BGh  = 1
  self.VVBL0l = VVBL0l
  self.colWidthPixels   = []
  self.VVkkpG   = VVkkpG
  self.OKButtonObj   = None
  self.VVPn7Q   = VVPn7Q
  self.VVTaaj   = VVTaaj
  self.VV6LI6   = VV6LI6
  self.VVH4Z8  = VVH4Z8
  self.VVmhJa   = VVmhJa
  self.VVfGJE    = VVfGJE
  self.VV1Zg1   = VV1Zg1
  self.tableRefreshCB   = None
  self.VVZAcA  = VVZAcA
  self.menuButtonFnc   = menuButtonFnc
  self.VVhwQH    = VVhwQH
  self.VVREBJ   = VVREBJ
  self.searchCol    = searchCol
  self.VV8zKo    = VV8zKo
  self.keyPressed    = -1
  self.VVJA7R    = FFpjhu(VVJA7R)
  self.VV4xuv    = FFGBnA(self.VVJA7R, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVBBM8    = VVBBM8
  self.VVa80e      = VVa80e
  self.VVVZTw    = FFy2pz(VVVZTw)
  self.VVaOdk    = FFy2pz(VVaOdk)
  self.VVXZ9d    = VVXZ9d
  self.VVlVSy    = FFy2pz(VVlVSy)
  self.VV3FyM   = FFy2pz(VV3FyM)
  self.VV6d0J    = FFy2pz(VV6d0J)
  self.VVf4Ym    = FFy2pz(VVf4Ym)
  self.VVV2RM   = FFy2pz(VVV2RM)
  self.VVV2RMRev  = FFy2pz(VVV2RMRev)
  self.VVIa5A  = False
  self.selectedItems   = 0
  self.VVZyKd   = FFy2pz("#01fefe01")
  self.VVGqEY   = FFy2pz("#11400040")
  self.VVT4TJ  = self.VVZyKd
  self.VVOruJ  = self.VVlVSy
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVREBJ:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVREBJ == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVncK3  ,
   "red"  : self.VV8zC0  ,
   "green"  : self.VVY7au ,
   "yellow" : self.VVlfuE ,
   "blue"  : self.VVcgt6  ,
   "menu"  : self.VViCFp ,
   "info"  : self.VVjK8t  ,
   "cancel" : self.VViIhR  ,
   "up"  : self.VV97DQ    ,
   "down"  : self.VVroOn  ,
   "left"  : self.VVW9G8   ,
   "right"  : self.VVAKEH  ,
   "next"  : self.VVglkp  ,
   "last"  : self.VVHwEc  ,
   "home"  : self.VVjEpw  ,
   "pageUp" : self.VVjEpw  ,
   "chanUp" : self.VVjEpw  ,
   "end"  : self.VVS0MS  ,
   "pageDown" : self.VVS0MS  ,
   "chanDown" : self.VVS0MS
  }, -1)
  FFFTn6(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  try:
   self.VVa9qK()
  except Exception as e:
   FF2zEl(self, str(e), title=self.Title)
   self.close(None)
 def VVa9qK(self):
  FFzs4L(self)
  if self.VVBBM8:
   FFvobF(self["myTitle"], self.VVBBM8)
  if self.VVa80e:
   FFvobF(self["myBody"] , self.VVa80e)
   FFvobF(self["myTableH"] , self.VVa80e)
   FFvobF(self["myTable"] , self.VVa80e)
   FFvobF(self["myBar"]  , self.VVa80e)
  self.VViTPW(self.VVTaaj  , self["keyRed"])
  self.VViTPW(self.VV6LI6  , self["keyGreen"])
  self.VViTPW(self.VVH4Z8 , self["keyYellow"])
  self.VViTPW(self.VVmhJa  , self["keyBlue"])
  if self.VVkkpG:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVkkpG[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVkkpG[0])
    FFvobF(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV4xuv)
  self["myTableH"].l.setFont(0, gFont(VVoHbv, self.VVJA7R))
  self["myTable"].l.setItemHeight(self.VV4xuv)
  self["myTable"].l.setFont(0, gFont(VVoHbv, self.VVJA7R))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV4xuv)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV4xuv))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV4xuv)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV4xuv
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV4xuv * len(self.VVX3UR) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVBL0l:
   self.VVBL0l = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVBL0l)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV8zKo:
   self.VV8zKo = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV8zKo
   self.VV8zKo = []
   for item in tmpList:
    self.VV8zKo.append(item | RT_VALIGN_CENTER)
  self.VVbhPG()
  if self.VVfGJE:
   self.VVfGJE(self)
 def VViTPW(self, btnFnc, btn):
  if btnFnc : FFTBJT(btn, btnFnc[0])
  else  : FFTBJT(btn, "")
 def VVvDUY(self, waitTxt):
  FF3LD6(self, self.VVbhPG, title=waitTxt)
 def VVbhPG(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVV2RMRev if self.lastSortModeIsReverese else self.VVV2RM
    self["myTableH"].setList([self.VV3sTc(0, self.header, self.VV6d0J, self.VVf4Ym, self.VV6d0J, self.VVf4Ym, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVX3UR):
    self["myTable"].list.append(self.VV3sTc(c, row, self.VVVZTw, self.VVaOdk, self.VVXZ9d, self.VVlVSy, None))
   self.VVX3UR = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVhwQH > -1:
    self["myTable"].moveToIndex(self.VVhwQH )
   self.VVzK8M()
   if self.VVREBJ:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV4xuv * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFsH5e(self, width, newH)
   if self.VV1Zg1:
    self.VVPR5N(self.VV1Zg1, None)
   if self.tableRefreshCB:
    self.VVPR5N(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FF2zEl(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VV3sTc(self, keyIndex, columns, VVVZTw, VVaOdk, VVXZ9d, VVlVSy, VVV2RM):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVV2RM and ndx == self.VVqPV4 : textColor = VVV2RM
   else           : textColor = VVVZTw
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFy2pz(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVaOdk = c
    entry = span.group(3)
   if self.VV8zKo[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV4xuv)
           , font   = 0
           , flags   = self.VV8zKo[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVaOdk
           , color_sel  = VVXZ9d or textColor
           , backcolor_sel = VVlVSy
           , border_width = 1
           , border_color = self.VV3FyM
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVjK8t(self):
  rowData = self.VVlPGf()
  if rowData:
   title, txt, colList = rowData
   if self.VVPn7Q:
    fnc  = self.VVPn7Q[1]
    params = self.VVPn7Q[2]
    fnc(self, title, txt, colList)
   else:
    FFucjH(self, txt, title)
 def VVncK3(self):
  if   self.VVIa5A : self.VVk6vk(self.VVKltF(), mode=2)
  elif self.VVkkpG  : self.VVPR5N(self.VVkkpG, None)
  else      : self.VVjK8t()
 def VV8zC0(self) : self.VVPR5N(self.VVTaaj , self["keyRed"])
 def VVY7au(self) : self.VVPR5N(self.VV6LI6 , self["keyGreen"])
 def VVlfuE(self): self.VVPR5N(self.VVH4Z8 , self["keyYellow"])
 def VVcgt6(self) : self.VVPR5N(self.VVmhJa , self["keyBlue"])
 def VVPR5N(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFRB11(self, buttonFnc[3])
    FFnB9O(BF(self.VVO9c0, buttonFnc))
   else:
    self.VVO9c0(buttonFnc)
 def VVO9c0(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVlPGf()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVk6vk(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVZyKd
   newRow = self.VVErbL()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV3sTc(ndx, newRow, self.VVVZTw, self.VVaOdk, self.VVXZ9d, self.VVlVSy, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV3sTc(ndx, newRow, self.VVZyKd, self.VVGqEY, self.VVT4TJ, self.VVOruJ, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVKltF() < len(self["myTable"].list) - 1:
    self.VVroOn()
   else:
    self.VVzK8M()
 def VVK1tz(self)  : FF3LD6(self, BF(self.VVZwZh, True ), title="Selecting all ..."  )
 def VVww5b(self) : FF3LD6(self, BF(self.VVZwZh, False), title="Unselecting all ...")
 def VVZwZh(self, isSel=True):
  if isSel:
   fg, bg = self.VVZyKd, self.VVGqEY
   self.selectedItems = len(self["myTable"].list)
   self.VVVdMt(True)
  else:
   fg, bg = self.VVVZTw, self.VVaOdk
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVZyKd
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVlPGf(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVBL0l[i] > 1 or self.VVBL0l[i] == self.VVcrus or self.VVBL0l[i] == self.VV48lL:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VViIhR(self):
  if self.VVZAcA : self.VVZAcA(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVBJII(self):
  return self["myTitle"].getText().strip()
 def VVCwRO(self):
  return self.header
 def VVTAgm(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVvRQU(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFtB5m(self["myBar"], color)
 def VVPBVj(self, txt):
  FFRB11(self, txt)
 def VVD950(self, txt, Time=1000):
  FFRB11(self, txt, Time)
 def VVFaTA(self): self["keyGreen"].show()
 def VVzU64(self): self["keyGreen"].hide()
 def VVrqfa(self): return self["keyGreen"].visible
 def VV3asq(self):
  FFRB11(self)
 def VVz6sq(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVFbUd(self):
  return len(self["myTable"].list)
 def VVKltF(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVpibS(self):
  return len(self["myTable"].list)
 def VVVdMt(self, isOn):
  self.VVIa5A = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVmhJa: self["keyBlue"].hide()
   if self.VVkkpG and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVmhJa: self["keyBlue"].show()
   if self.VVkkpG and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVkkpG[0])
   self.VVww5b()
  FFvobF(self["myTitle"], color)
  FFvobF(self["myBar"]  , color)
 def VVWR9J(self):
  return self.VVIa5A
 def VVGnLM(self):
  return self.selectedItems
 def VVHCuh(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVzK8M()
 def VVGbCD(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVXESm(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVFbUd()
  txt += FFExgP("Total Unique Items", VVL6GV)
  for i in range(self.totalCols):
   if self.VVBL0l[i - 1] > 1 or self.VVBL0l[i - 1] == self.VVcrus or self.VVBL0l[i - 1] == self.VV48lL:
    name, tot = self.VVGbCD(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFucjH(self, txt)
 def VVJJCV(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVErbL(self):
  return self.VVdCEN(self["myTable"].l.getCurrentSelectionIndex())
 def VVdCEN(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVrEsw(self, newList, newTitle="", VVYHEIMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVTAgm(newTitle)
  if newList:
   self.VVX3UR = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVMXk9 and self.VVqPV4 == 0:
    isNum = True
   else:
    for cols in self.VVX3UR:
     if not FFAETn(cols[self.VVqPV4]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVX3UR.sort(key=lambda x: int(x[self.VVqPV4])  , reverse=self.lastSortModeIsReverese)
    else : self.VVX3UR.sort(key=lambda x: x[self.VVqPV4].lower() , reverse=self.lastSortModeIsReverese)
   if VVYHEIMsg : self.VVvDUY("Refreshing ...")
   else   : self.VVbhPG()
  else:
   FF2zEl(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVoBKf(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VV3sTc(self.VVpibS(), row, self.VVVZTw, self.VVaOdk, self.VVXZ9d, self.VVlVSy, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVS0MS()
 def VVaBD0(self):
  self["myTable"].list.pop(self.VVKltF())
  self["myTable"].l.setList(self["myTable"].list)
 def VVhT9b(self, data):
  ndx = self.VVKltF()
  newRow = self.VV3sTc(ndx, data, self.VVVZTw, self.VVaOdk, self.VVXZ9d, self.VVlVSy, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVzK8M()
   return True
  else:
   return False
 def VV13vu(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VV3sTc(ndx, data, self.VVVZTw, self.VVaOdk, self.VVXZ9d, self.VVlVSy, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVV1Un()
 def VVV1Un(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VV0LFL(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVrpKV(self, colNum, textToFind, VVnkcm=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVzK8M()
    break
  else:
   if VVnkcm:
    FFRB11(self, "Not found", 1000)
 def VVWYsy(self, colDict, VVnkcm=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVzK8M()
    return
  if VVnkcm:
   FFRB11(self, "Not found", 1000)
 def VVc6Bk(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV6x8v(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFAETn(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVCkXr(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVZyKd:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVyKl2(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVZyKd:
     return ndx
  return -1
 def VVXysw(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVZyKd:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VV8P9i(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVZyKd: return True
  else        : return False
 def VV3eCu(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VViCFp(self):
  if self.menuButtonFnc:
   self.VVO9c0(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVREBJ:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVKltF()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVgsyy1, VVfOz8 = CCBykx.VVEb0Q(self, False, False)
  VVgsyy = []
  VVgsyy.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVgsyy.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVgsyy.append(("Find ...\t\t%s" % (FFivHt(txt, VViC5D) if txt else ""), "findNew"   ))
  VVgsyy.append(itemOf(bool(VVgsyy1)    , "Find (from Filter) ..."   , "filter"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Table Statistcis"             , "tableStat"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((FFivHt("Export Table to .html"     , VVL6GV) , "VVY96r" ))
  VVgsyy.append((FFivHt("Export Table to .csv"     , VVL6GV) , "VViBLY" ))
  VVgsyy.append((FFivHt("Export Table to .txt (Tab Separated)", VVL6GV) , "VVKTDa" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVBL0l[i] > 1 or self.VVBL0l[i] == self.VV1oOY:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVgsyy.append(VVzHzv)
   if tot == 1 : VVgsyy.append(("Sort", sList[0][1]))
   else  : VVgsyy += sList
  VVtL1m = ("Keys Help", self.FFyrIUHelp)
  FFCO3u(self, self.VVZ2n9, VVgsyy=VVgsyy, title=self.VVBJII(), VVtL1m=VVtL1m)
 def VVZ2n9(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVfmLX()
   elif item == "findPrev"  : self.VVfmLX(isPrev=True)
   elif item == "findNew"  : self.VVCDAH()
   elif item == "filter"  : self.VV4fgv()
   elif item == "tableStat" : self.VVXESm()
   elif item == "VVY96r": FF3LD6(self, self.VVY96r, title=title)
   elif item == "VViBLY" : FF3LD6(self, self.VViBLY , title=title)
   elif item == "VVKTDa" : FF3LD6(self, self.VVKTDa , title=title)
   else:
    if self.VVqPV4 == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVqPV4, self.lastSortModeIsReverese = item, False
    if self.VVMXk9 and self.VVqPV4 == 0 or self.VV6x8v(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVbhPG(onlyHeader=True)
 def FFyrIUHelp(self, VVyxPv, path):
  FF6duf(self, "_help_table", "Table (Keys Help)")
 def VV97DQ(self):
  self["myTable"].up()
  self.VVzK8M()
 def VVroOn(self):
  self["myTable"].down()
  self.VVzK8M()
 def VVW9G8(self):
  self["myTable"].pageUp()
  self.VVzK8M()
 def VVAKEH(self):
  self["myTable"].pageDown()
  self.VVzK8M()
 def VVjEpw(self):
  self["myTable"].moveToIndex(0)
  self.VVzK8M()
 def VVS0MS(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVzK8M()
 def VVICdA(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVzK8M()
 def VVglkp(self):
  if self.lastFindConfigObj.getValue():
   if self.VVKltF() == len(self["myTable"].list) - 1 : FFRB11(self, "End reached", 1000)
   else              : self.VVfmLX()
  else:
   FFRB11(self, 'Set "Find" in Menu', 1500)
 def VVHwEc(self):
  if self.lastFindConfigObj.getValue():
   if self.VVKltF() == 0 : FFRB11(self, "Top reached", 1000)
   else       : self.VVfmLX(isPrev=True)
  else:
   FFRB11(self, 'Set "Find" in Menu', 1500)
 def VVDfRe(self, txt):
  FFH7ga(self.lastFindConfigObj, txt)
 def VVCDAH(self):
  FF7lc9(self, self.VVMbvb, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVMbvb(self, VVfLRn):
  if not VVfLRn is None:
   txt = VVfLRn.strip()
   self.VVDfRe(txt)
   if VVfLRn: self.VVfmLX(reset=True)
   else  : FFRB11(self, "Nothing to find !", 1500)
 def VV4fgv(self):
  VVgsyy, VVfOz8 = CCBykx.VVEb0Q(self, False, False)
  VVOmbd = ("Edit Filter", BF(self.VVdP5K, VVfOz8))
  if VVgsyy : FFCO3u(self, self.VVATTi, VVgsyy=VVgsyy, VVOmbd=VVOmbd, title="Find from Filter")
  else  : FFRB11(self, "Filter Error !", 1500)
 def VVATTi(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVDfRe(txt)
    self.VVfmLX(reset=True)
   else:
    FFRB11(self, "No entry !", 1500)
 def VVdP5K(self, VVfOz8, VV7Q6fObj, sel):
  if fileExists(VVfOz8) : CCDQxK(self, VVfOz8, VVRlGe=None)
  else       : FFdxlA(self, VVfOz8)
  VV7Q6fObj.cancel()
 def VVfmLX(self, reset=False, isPrev=False):
  curRow = self.VVKltF()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCBykx.VVVM3i(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVICdA(i)
      break
    elif any(x in line for x in tupl):
     self.VVICdA(i)
     break
   else:
    FFRB11(self, "Not found", 1000)
  else:
   FFRB11(self, "Check your query", 1500)
 def VVKTDa(self):
  expFile = self.VVVRpM() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVfRDv()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVdCEN(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVBL0l[ndx] > self.VV1BGh or self.VVBL0l[ndx] == self.VV48lL:
      col = self.VV6hBY(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVqti3(expFile)
 def VViBLY(self):
  expFile = self.VVVRpM() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVfRDv()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVdCEN(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVBL0l[ndx] > self.VV1BGh or self.VVBL0l[ndx] == self.VV48lL:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VV6hBY(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVqti3(expFile)
 def VVY96r(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVBJII(), PLUGIN_NAME, VVkRol)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVBJII()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVfRDv()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVBL0l:
   colgroup += '   <colgroup>'
   for w in self.VVBL0l:
    if w > self.VV1BGh or w == self.VV48lL:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVVRpM() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVdCEN(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVBL0l[ndx] > self.VV1BGh or self.VVBL0l[ndx] == self.VV48lL:
      col = self.VV6hBY(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVqti3(expFile)
 def VVfRDv(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVBL0l[ndx] > self.VV1BGh or self.VVBL0l[ndx] == self.VV48lL:
     newRow.append(col.strip())
  return newRow
 def VV6hBY(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFkgYM(col)
 def VVVRpM(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVBJII())
  fileName = fileName.replace("__", "_")
  path  = FFZsCH(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFvXEJ()
  return expFile
 def VVqti3(self, expFile):
  FF5kkM(self, "File exported to:\n\n%s" % expFile, title=self.VVBJII())
 def VVzK8M(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCHGEE():
 def __init__(self, pixmapObj, picPath, VVaOdk=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVaOdk  = VVaOdk or "#2200002a"
 def VVe5QX(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVN2CB)
    except:
     self.picLoad.PictureData.get().append(self.VVN2CB)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVaOdk])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVN2CB(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVPPxZ(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVqFaS(pixmapObj, path, VVaOdk=None):
  cl = CCHGEE(pixmapObj, path, VVaOdk)
  ok = cl.VVe5QX()
  if ok: return cl
  else : return None
class CCslfl(Screen):
 def __init__(self, session, VVBK02, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFTuEm()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFAm4L(VVBqoq, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVBK02 = VVBK02
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFNG7m(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVWL34  ,
   "up" : BF(self.VVg4Gv, -1),
   "down" : BF(self.VVg4Gv,  1),
   "left" : BF(self.VVg4Gv, -1),
   "right" : BF(self.VVg4Gv,  1)
  }, -1)
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  self.VVGNX6()
  self.picViewer = CCHGEE.VVqFaS(self["myPic"], self.VVBK02)
  if self.picViewer:
   if self.showGrnMsg:
    FFRB11(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF2zEl(self, "Cannot view picture file:\n\n%s" % self.VVBK02)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVPPxZ()
  if self.cbFnc  : self.cbFnc(self.VVBK02)
 def VVg4Gv(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVBK02 = FFZsCH(os.path.dirname(self.VVBK02)) + fName
    self.picViewer.picPath = self.VVBK02
    self.picViewer.VVe5QX()
    self.VVGNX6()
 def VVWL34(self):
  txt = "%s:\n  %s" % (FFivHt("Path", VVhb13), self.fakePath or self.VVBK02)
  size, sizeTxt, resTxt, form, mode = CCYT65.VVX5tb(self.VVBK02)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFivHt("Properties", VVhb13)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFucjH(self, txt, title="File Information")
 def VVGNX6(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVBK02)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVIg0A(SELF, VVBK02, **kwargs):
  SELF.session.open(CCslfl, VVBK02, **kwargs)
class CCaWg8(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFAm4L(VVHFSz, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFNG7m(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.onExit)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFlh8N("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VV7Zo4(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCaWg8.VV5OjQ, SELF), CCaWg8, mviFile)
 @staticmethod
 def VV5OjQ(SELF, reason=None):
  if reason == -1: FF2zEl(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCYiJJ(Screen, ConfigListScreen):
 VV8E0w = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVvBiK, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFNG7m(self, title=self.Title)
  FFTBJT(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VV4OM8()
  self.onShown.append(self.VVBp8x)
 def VV4OM8(self):
  kList = {
    "ok" : self.VVMcMd   ,
    "green" : self.VVVhWU ,
    "menu" : self.VVfgnx ,
    "cancel": self.VV3GDf ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVH1pU, 0)
     kList["chanDown"] = BF(self["config"].VVH1pU, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFfavv(self)
  FFyZo3(self["config"])
  FFhtaK(self, self["config"])
  FFzs4L(self)
  self["config"].onSelectionChanged.append(self.VV03NL)
  FFvobF(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VV03NL()
 def VV03NL(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVMcMd(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVC4Eo()
   elif item == CFG.MovieDownloadPath   : self.VV4Iby(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVAbH2()
   elif isinstance(item, ConfigDirectory) : self.VVhiWc(item)
   else         : CCYiJJ.VV0Bay(self, item, title)
 @staticmethod
 def VV0Bay(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVgsyy = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VViC5D + txt
    elif val == confItem.default: defNdx, txt = ndx, VVMdMA + txt
   VVgsyy.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVtL1m  = ("Current", BF(CCYiJJ.VVAOGz, curNdx))
  VVOmbd = ("Default", BF(CCYiJJ.VVAOGz, defNdx))
  VVyxPv = FFCO3u(SELF, BF(CCYiJJ.VVpq8C, confItem, cbFnc, isSave), VVgsyy=VVgsyy, width=1200, VVOmbd=VVOmbd, VVtL1m=VVtL1m, title=title, VVBBM8="#33221111", VVa80e="#33110011")
  VVyxPv.VVCNsC(curNdx)
 @staticmethod
 def VVpq8C(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFH7ga(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVAOGz(ndx, VV7Q6fObj, item):
  VV7Q6fObj.VVCNsC(ndx)
 @staticmethod
 def VVC77d(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VV4Iby(self, item, title):
  tot = CCS6qp.VVSpE9()
  if tot : FF2zEl(self, "Cannot change while downloading.", title=title)
  else : self.VVhiWc(item)
 def VVAbH2(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCCXVP.VV3xYk(self, "", curEnc)
  if lst:
   VVOmbd = ("Default", self.VVrC6V)
   VVtL1m  = ("Current", self.VV8VBA)
   VVyxPv = FFCO3u(self, self.VVO7vf, title="Select Priority Encoding", VVgsyy=lst, width=1000, height=1000, VVtL1m=VVtL1m, VVOmbd=VVOmbd, VVBBM8="#22220000", VVa80e="#22220000", VVf67P=True)
   VVyxPv.VViQkW(curEnc)
 def VVO7vf(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVrC6V(self, VVyxPv, item): VVyxPv.VViQkW(VVA5PC)
 def VV8VBA(self, VVyxPv, item): VVyxPv.VViQkW(CFG.subtDefaultEnc.getValue())
 def VVC4Eo(self):
  VVgsyy = []
  VVgsyy.append(("Auto Find" , "auto"))
  VVgsyy.append(("Custom Path" , "cust"))
  FFCO3u(self, self.VVjZpW, VVgsyy=VVgsyy, title="IPTV Hosts Files Path")
 def VVjZpW(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVNY3V)
   elif item == "cust":
    VVX2QD = self.VVxF2C()
    if VVX2QD : self.VVzSMX(VVX2QD)
    else  : self.session.openWithCallback(self.VVroDD, BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf="/"))
 def VVzSMX(self, VVX2QD):
  VVZAcA = self.VVoFqN
  VVTaaj = ("Remove"  , self.VV5Sue , [])
  VVH4Z8 = ("Add "  , self.VV0bjY, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VV8zKo  = (LEFT   , LEFT  )
  FFyrIU(self, None, title="IPTV Hosts Search Paths", header=header, VVX3UR=VVX2QD, width=1200, height=700, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=26, VVZAcA=VVZAcA, VVTaaj=VVTaaj, VVH4Z8=VVH4Z8
    , VVBBM8="#22220000", VVa80e="#22110000", VVaOdk="#22110011", VVlVSy="#11223025", VV3FyM="#0a333333", VVf4Ym="#11400040")
 def VVoFqN(self, VVgl66):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VV69rC)
  VVgl66.cancel()
 def VVroDD(self, path):
  if path:
   FFH7ga(CFG.iptvHostsDirs, FFZsCH(path.strip()))
   VVX2QD = self.VVxF2C()
   if VVX2QD : self.VVzSMX(VVX2QD)
   else  : FFRB11(self, "Cannot add dir", 1500)
 def VVtJUx(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVNY3V:
   return []
  return lst
 def VVxF2C(self):
  lst = self.VVtJUx()
  if lst:
   VVX2QD = []
   for Dir in lst:
    VVX2QD.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVX2QD.sort(key=lambda x: x[0].lower())
   return VVX2QD
  else:
   return []
 def VV0bjY(self, VVgl66, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVEs1z, VVgl66)
         , BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=sDir))
 def VVEs1z(self, VVgl66, path):
  if path:
   path = FFZsCH(path.strip())
   if self.VV3Grl(VVgl66, path):
    FFRB11(VVgl66, "Already added", 1500)
   else:
    lst = self.VVtJUx()
    lst.append(path)
    FFH7ga(CFG.iptvHostsDirs, ",".join(lst))
    VVX2QD = self.VVxF2C()
    VVgl66.VVrEsw(VVX2QD, tableRefreshCB=BF(self.VVhiKU, path))
 def VVhiKU(self, path, VVgl66, title, txt, colList):
  self.VV3Grl(VVgl66, path)
 def VV3Grl(self, VVgl66, path):
  for ndx, row in enumerate(VVgl66.VV3eCu()):
   if row[0].strip() == path.strip():
    VVgl66.VVICdA(ndx)
    return True
  return False
 def VV5Sue(self, VVgl66, title, txt, colList):
  path = colList[0]
  FFZnVu(self, BF(self.VV5r4R, VVgl66), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VV5r4R(self, VVgl66):
  row = VVgl66.VVErbL()
  path, rem = row[0], row[1]
  VVX2QD = []
  lst = []
  for ndx, row in enumerate(VVgl66.VV3eCu()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVX2QD.append((tPath, tRem))
  if len(VVX2QD) > 0:
   FFH7ga(CFG.iptvHostsDirs, ",".join(lst))
   VVgl66.VVrEsw(VVX2QD)
   FFRB11(VVgl66, "Deleted", 1500)
  else:
   FFH7ga(CFG.iptvHostsMode, VVNY3V)
   FFH7ga(CFG.iptvHostsDirs, "")
   VVgl66.cancel()
   FFnB9O(BF(FFRB11, self, "Changed to Auto-Find", 1500))
 def VVhiWc(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VV9FF5, configObj)
         , BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=sDir))
 def VV9FF5(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV3GDf(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFZnVu(self, self.VVVhWU, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVVhWU(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVAytJ()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVfgnx(self):
  VVgsyy = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVgsyy.append((txt    , "VVZze8"   ))
  else        : VVgsyy.append((txt    ,       ))
  VVgsyy.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Reset %s Settings" % PLUGIN_NAME      , "VVXMPT"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Backup %s Settings" % PLUGIN_NAME      , "VVjySz"  ))
  VVgsyy.append(("Restore %s Settings" % PLUGIN_NAME     , "VVviOk"  ))
  if fileExists(VVn5zG + CCYiJJ.VV8E0w):
   VVgsyy.append(VVzHzv)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVgsyy.append(('%s Checking for Update' % txt1     , txt2     ))
   VVgsyy.append(("Reinstall %s" % PLUGIN_NAME      , "VVGarK"  ))
   VVgsyy.append(("Update %s" % PLUGIN_NAME      , "VVgl41"   ))
  FFCO3u(self, self.VVBkZN, VVgsyy=VVgsyy, title="Config. Options")
 def VVBkZN(self, item=None):
  if item:
   if   item == "VVZze8"  : FFZnVu(self, self.VVZze8 , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCajWE)
   elif item == "VVXMPT"  : FFZnVu(self, BF(self.VVXMPT, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVjySz" : self.VVjySz()
   elif item == "VVviOk" : FF3LD6(self, self.VVviOk, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFH7ga(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFH7ga(CFG.checkForUpdateAtStartup, False)
   elif item == "VVGarK" : FF3LD6(self, BF(self.VVAG8M, True ), "Checking Server ...")
   elif item == "VVgl41"  : FF3LD6(self, BF(self.VVAG8M, False), "Checking Server ...")
 def VVjySz(self):
  path = "%sajpanel_settings_%s" % (VVn5zG, FFvXEJ())
  FFdy80("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVKSHN, path))
  FF5kkM(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVviOk(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFIeeK("find / %s -iname '%s*' | grep %s" % (FFcVVX(1), name, name))
  if files:
   err = CCxFIK.VVjWm9(files)
   if err:
    FFZnVu(self, BF(self.VVKGf6, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVgsyy = []
    for line in files:
     VVgsyy.append((line, line))
    FFCO3u(self, BF(self.VVSZmL, title), title=title, VVgsyy=VVgsyy, width=1200, VVGamv="")
  else:
   FF2zEl(self, "No settings files found !", title=title)
 def VVKGf6(self, title, path=None):
  sDir = "/"
  for path in (VVn5zG, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVSZmL, title), BF(CCxFIK, patternMode="ajpSet", VVn9uf=sDir))
 def VVSZmL(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFHq6Y(path)
    self.VVXMPT()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVAytJ()
    FFlWSy()
    FFRB11(self, "Apllied", 1500, isGrn=True)
   else:
    FFdxlA(self, path, title=title)
 def VVZze8(self):
  newPath = FFZsCH(VVn5zG)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVAytJ()
 @staticmethod
 def VVeX0r():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVXMPT(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVAytJ()
  if exit:
   self.close()
 def VVAytJ(self):
  configfile.save()
  global VVn5zG
  VVn5zG = CFG.backupPath.getValue()
  FFnwfK()
 def VVAG8M(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCYiJJ.VV83tv()
  if   err    : FF2zEl(self, err, title)
  elif isHigher or force : FFZnVu(self, BF(FF3LD6, self, BF(self.VVUQDL, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FF5kkM(self, FFivHt("No update required.", VVd7n9) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVUQDL(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FF9djL() == "dpkg" else "ipk")
  path, err = FFZXhR(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFcDAv(VVG7vb, path)
   else : cmd = FFcDAv(VVexTQ, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFyAzl(self, cmd, title=title)
   else:
    FFjIcG(self, title=title)
  else:
   FF2zEl(self, err, title=title)
 @staticmethod
 def VV83tv():
  span = iSearch(r"v*(\d.\d.\d)", VVkRol, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVn5zG + CCYiJJ.VV8E0w
  if fileExists(path):
   span = iSearch(r"(http.+)", FFU2DB(path), IGNORECASE)
   if span : url = FFZsCH(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFZXhR(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFU2DB(path).strip().replace(" ", "")
   FFAFdq(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCajWE(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVlSRC, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVoSGn
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFNG7m(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVqHZq("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVqHZq("\c00888888", i) + sp + "GREY\n"
   txt += self.VVqHZq("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVqHZq("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVqHZq("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVqHZq("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVqHZq("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVqHZq("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVqHZq("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVqHZq("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVqHZq("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVqHZq("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVMcMd ,
   "green" : self.VVMcMd ,
   "left" : self.VVSzgb ,
   "right" : self.VV7Npu ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  self.VVReMz()
 def VVMcMd(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFZnVu(self, self.VV0sXc, "Change to : %s" % txt, title=self.Title)
 def VV0sXc(self):
  FFH7ga(CFG.mixedColorScheme, self.cursorPos)
  global VVoSGn
  VVoSGn = self.cursorPos
  self.VVp7eP()
  self.close()
 def VVSzgb(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVReMz()
 def VV7Npu(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVReMz()
 def VVReMz(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVqHZq(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVUSPc(color):
  if VVMdMA: return "\\" + color
  else    : return ""
 @staticmethod
 def VVp7eP():
  global VVPwgj, VVrVS3, VVHEBa, VVgmAg, VVL6GV, VVAQIK, VVjK42, VVXhzj, VVd7n9, VVL7a3, VVMdMA, VVhb13, VViC5D, VVVJaM, VVuURa, VVWK7B
  VVWK7B   = CCajWE.VVqHZq("\c00FFFFFF", VVoSGn)
  VVrVS3    = CCajWE.VVqHZq("\c00888888", VVoSGn)
  VVPwgj  = CCajWE.VVqHZq("\c005A5A5A", VVoSGn)
  VVXhzj    = CCajWE.VVqHZq("\c00FF0000", VVoSGn)
  VVHEBa   = CCajWE.VVqHZq("\c00FF5000", VVoSGn)
  VVgmAg   = CCajWE.VVqHZq("\c00FFBB66", VVoSGn)
  VVMdMA   = CCajWE.VVqHZq("\c00FFFF00", VVoSGn)
  VVhb13 = CCajWE.VVqHZq("\c00FFFFAA", VVoSGn)
  VVd7n9   = CCajWE.VVqHZq("\c0000FF00", VVoSGn)
  VVL7a3  = CCajWE.VVqHZq("\c00AAFFAA", VVoSGn)
  VVjK42    = CCajWE.VVqHZq("\c000066FF", VVoSGn)
  VViC5D    = CCajWE.VVqHZq("\c0000FFFF", VVoSGn)
  VVVJaM  = CCajWE.VVqHZq("\c00AAFFFF", VVoSGn)  #
  VVuURa   = CCajWE.VVqHZq("\c00FA55E7", VVoSGn)
  VVL6GV    = CCajWE.VVqHZq("\c00FF8F5F", VVoSGn)
  VVAQIK  = CCajWE.VVqHZq("\c00FFC0C0", VVoSGn)
CCajWE.VVp7eP()
class CCItJq(Screen):
 def __init__(self, session, path, VVi6yH):
  self.skin, self.skinParam = FFAm4L(VVmJx6, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VV1G81   = path
  self.VVmIpk   = ""
  self.VVclYi   = ""
  self.VVi6yH    = VVi6yH
  self.VVWdNg    = ""
  self.VVmfg8  = ""
  self.VVbblR    = False
  self.VVc3m3  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVYQud  = "enigma2-plugin-extensions-"
  self.VVeweB  = "enigma2-plugin-systemplugins-"
  self.VVKUiq = "enigma2-"
  self.VVkfyF  = 0
  self.VVduey  = 1
  self.VVcIit  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVshn6 = "DEBIAN"
  else        : self.VVshn6 = "CONTROL"
  self.controlPath = self.Path + self.VVshn6
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVi6yH:
   self.packageExt  = ".deb"
   self.VVaOdk  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVaOdk  = "#11001020"
  FFNG7m(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFTBJT(self["keyRed"] , "Create")
  FFTBJT(self["keyGreen"] , "Post Install")
  FFTBJT(self["keyYellow"], "Installation Path")
  FFTBJT(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVqszQ  ,
   "green"   : self.VVXP7f ,
   "yellow"  : self.VVpghN  ,
   "blue"   : self.VVThju  ,
   "cancel"  : self.VVwgSz
  }, -1)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFzs4L(self)
  if self.VVaOdk:
   FFvobF(self["myBody"], self.VVaOdk)
   FFvobF(self["myLabel"], self.VVaOdk)
  self.VVGeiH(True)
  self.VVVfey(True)
 def VVVfey(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVqZX5()
  if isFirstTime:
   if   package.startswith(self.VVYQud) : self.VV1G81 = VV3ket + self.VVWdNg + "/"
   elif package.startswith(self.VVeweB) : self.VV1G81 = VV35QH + self.VVWdNg + "/"
   else            : self.VV1G81 = self.Path
  if self.VVbblR : myColor = VVL6GV
  else    : myColor = VVWK7B
  txt  = ""
  txt += "Source Path\t: %s\n" % FFivHt(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFivHt(self.VV1G81, VVMdMA)
  if self.VVclYi : txt += "Package File\t: %s\n" % FFivHt(self.VVclYi, VVrVS3)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFivHt("Check Control File fields : %s" % errTxt, VVHEBa)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFivHt("Restart GUI", VVL6GV)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFivHt("Reboot Device", VVL6GV)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFivHt("Post Install", VVd7n9), act)
  if not errTxt and VVHEBa in controlInfo:
   txt += "Warning\t: %s\n" % FFivHt("Errors in control file may affect the result package.", VVHEBa)
  txt += "\nControl File\t: %s\n" % FFivHt(self.controlFile, VVrVS3)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVXP7f(self):
  if self["keyGreen"].getVisible():
   VVgsyy = []
   VVgsyy.append(("No Action"    , "noAction"  ))
   VVgsyy.append(("Restart GUI"    , "VV2SjC"  ))
   VVgsyy.append(("Reboot Device"   , "rebootDev"  ))
   FFCO3u(self, self.VVQSOL, title="Package Installation Option (after completing installation)", VVgsyy=VVgsyy)
 def VVQSOL(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV2SjC"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVGeiH(False)
   self.VVVfey()
 def VVpghN(self):
  rootPath = FFivHt("/%s/" % self.VVWdNg, VVhb13)
  VVgsyy = []
  VVgsyy.append(("Current Path"        , "toCurrent"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Extension Path"       , "toExtensions" ))
  VVgsyy.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVgsyy.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFCO3u(self, self.VV6NUv, title="Installation Path", VVgsyy=VVgsyy)
 def VV6NUv(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVBIV1(FFCdvu(self.Path, True))
   elif item == "toExtensions"  : self.VVBIV1(VV3ket)
   elif item == "toSystemPlugins" : self.VVBIV1(VV35QH)
   elif item == "toRootPath"  : self.VVBIV1("/")
   elif item == "toRoot"   : self.VVBIV1("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVGzrv, BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=VVn5zG))
 def VVGzrv(self, path):
  if len(path) > 0:
   self.VVBIV1(path)
 def VVBIV1(self, parent, withPackageName=True):
  if withPackageName : self.VV1G81 = parent + self.VVWdNg + "/"
  else    : self.VV1G81 = "/"
  mode = self.VVZOFZ()
  FFlh8N("sed -i '/Package/c\Package: %s' %s" % (self.VV8CiN(mode), self.controlFile))
  self.VVVfey()
 def VVThju(self):
  if fileExists(self.controlFile):
   lines = FFHq6Y(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF7lc9(self, self.VV1hLl, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF2zEl(self, "Version not found or incorrectly set !")
  else:
   FFdxlA(self, self.controlFile)
 def VV1hLl(self, VVfLRn):
  if VVfLRn:
   version, color = self.VVs2Pj(VVfLRn, False)
   if color == VViC5D:
    FFlh8N("sed -i '/Version:/c\Version: %s' %s" % (VVfLRn, self.controlFile))
    self.VVVfey()
   else:
    FF2zEl(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVwgSz(self):
  if self.newControlPath:
   if self.VVbblR:
    self.VV4ALW()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFivHt(self.newControlPath, VVrVS3)
    txt += FFivHt("Do you want to keep these files ?", VVMdMA)
    FFZnVu(self, self.close, txt, callBack_No=self.VV4ALW, title="Create Package", VVOuLx=True)
  else:
   self.close()
 def VV4ALW(self):
  FFlh8N("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VV8CiN(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVmfg8
  if package.startswith(self.VVKUiq):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVKUiq, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVduey : prefix = self.VVYQud
  elif mode == self.VVcIit : prefix = self.VVeweB
  return (prefix + name).lower()
 def VVZOFZ(self):
  if   self.VV1G81.startswith(VV3ket) : return self.VVduey
  elif self.VV1G81.startswith(VV35QH) : return self.VVcIit
  else            : return self.VVkfyF
 def VVGeiH(self, isFirstTime):
  self.VVWdNg   = FFSHhe(self.Path)
  self.VVWdNg   = "_".join(self.VVWdNg.split())
  self.VVmfg8 = self.VVWdNg.lower()
  self.VVbblR = self.VVmfg8 == VVpToT.lower()
  if self.VVbblR and self.VVmfg8.endswith(VVpToT.lower()):
   self.VVmfg8 += "el"
  if self.VVbblR : self.VVmIpk = VVn5zG
  else    : self.VVmIpk = CFG.packageOutputPath.getValue()
  self.VVmIpk = FFZsCH(self.VVmIpk)
  if not pathExists(self.controlPath):
   FFlh8N("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVZOFZ()
  if fileExists(self.controlFile):
   lines = FFHq6Y(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVbblR : version, descripton, maintainer = VVkRol , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVWdNg , self.VVWdNg
   txt = ""
   txt += "Package: %s\n"  % self.VV8CiN(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVbblR : t = PLUGIN_NAME
  else    : t = self.VVWdNg
  self.VV1ZCN(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VV1ZCN(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVbblR : self.VV1ZCN(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVkRol))
  else    : self.VV1ZCN(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVWdNg)
  if isFirstTime and not mode == self.VVkfyF:
   self.postInstAcion = 1
  txt = self.VVw7al(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFU2DB(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVw7al(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFlh8N("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VV1ZCN(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVw7al(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVqZX5(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFHq6Y(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFivHt(line, VVHEBa)
     elif not line.startswith(" ")    : line = FFivHt(line, VVHEBa)
     else          : line = FFivHt(line, VViC5D)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VViC5D
   else   : color = VVHEBa
   descr = FFivHt(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVHEBa
     elif line.startswith((" ", "\t")) : color = VVHEBa
     elif line.startswith("#")   : color = VVrVS3
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVs2Pj(val, True)
      elif key == "Version"  : version, color = self.VVs2Pj(val, False)
      elif key == "Maintainer" : maint  , color = val, VViC5D
      elif key == "Architecture" : arch  , color = val, VViC5D
      else:
       color = VViC5D
      if not key == "OE" and not key.istitle():
       color = VVHEBa
     else:
      color = VVL6GV
     txt += FFivHt(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVclYi = self.VVmIpk + packageName
   self.VVc3m3 = True
   errTxt = ""
  else:
   self.VVclYi  = ""
   self.VVc3m3 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVs2Pj(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VViC5D
  else          : return val, VVHEBa
 def VVqszQ(self):
  if not self.VVc3m3:
   FF2zEl(self, "Please fix Control File errors first.")
   return
  if self.VVi6yH: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFCdvu(self.VV1G81, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVWdNg
  symlinkTo  = FFjJ1n(self.Path)
  dataDir   = self.VV1G81.rstrip("/")
  removePorjDir = FFT1jM("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFT1jM("rm -f '%s'" % self.VVclYi)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFiCnc()
  if self.VVi6yH:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFWSuq("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVbblR:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VV1G81 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVshn6)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVclYi, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVclYi
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVclYi, FFmPm4(result  , VVd7n9))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VV1G81, FFmPm4(instPath, VViC5D))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFmPm4(failed, VVHEBa))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFyAzl(self, cmd)
class CCqHUu():
 VVjqB1  = "666"
 VVV72T   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVyxPv   = None
  self.VVTFxr()
 def VVTFxr(self):
  VVgsyy = CCqHUu.VVuaO0()
  if VVgsyy:
   VVOmbd = ("Create New", self.VVAmLw)
   self.VVyxPv = FFCO3u(self.SELF, self.VVBXfK, VVgsyy=VVgsyy, title=self.Title, VVOmbd=VVOmbd, VVf67P=True, VVBBM8="#22222233", VVa80e="#22222233")
  else:
   self.VVAmLw()
 def VVBXfK(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVvhwm(bName, bRef)
  else:
   CCqHUu.VVqtYD(self)
 def VVAmLw(self, VV7Q6fObj=None, item=None):
  FF7lc9(self.SELF, BF(self.VVph4c), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVph4c(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVyxPv:
     self.VVyxPv.cancel()
    self.VVvhwm(bName, "")
   else:
    FFRB11(self.VVyxPv, "Incorrect Bouquet Name !", 2000)
    CCqHUu.VVqtYD(self)
 def VVvhwm(self, bName, bRef):
  FF3LD6(self.waitMsgSELF, BF(self.VVSvS8, bName, bRef), title="Adding Services ...")
 def VVSvS8(self, bName, bRef):
  CCqHUu.VVd5ae(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVqtYD(classObj):
  del classObj
 @staticmethod
 def VVd5ae(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FF2zEl(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVKSHN + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFdxlA(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCqHUu.VVCQnS(bRef)
   bPath = VVKSHN + bFile
  else:
   fName = CCA7uK.VV84lT(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVKSHN + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVKSHN + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFZs4V(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFZs4V(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CC0NDf.VVqbLc()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFlh8N("cp -f '%s' '%s'" % (poster, picon))
       FFlh8N(CCTzTd.VVi3sm(picon))
       break
  FFjhC8()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFucjH(SELF, txt, title=title)
 @staticmethod
 def VVuaO0(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVgsyy = []
  if mode in (0, 2): VVgsyy.extend(CCqHUu.VVRKuU(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVgsyy.extend(CCqHUu.VVRKuU(1, showTitle, prefix, onlyIptv))
  return VVgsyy
 @staticmethod
 def VVRKuU(mode, showTitle, prefix, onlyIptv):
  VVgsyy = []
  lst = CCqHUu.VVc5P1(mode)
  if onlyIptv:
   lst = CCqHUu.VVfVbm(lst)
  if lst:
   if showTitle:
    VVgsyy.append(FFJi5u("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVgsyy.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVgsyy.append((item[0], item[1].toString()))
  return VVgsyy
 @staticmethod
 def VVfVbm(lst):
  fLst = CCA7uK.VVILbD(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVVC9n():
  bLise = CCqHUu.VVc5P1(0)
  bLise.extend(CCqHUu.VVc5P1(1))
  return bLise
 @staticmethod
 def VVc5P1(mode=0):
  bList = []
  VV15Ea = InfoBar.instance
  VVziWT = VV15Ea and VV15Ea.servicelist
  if VVziWT:
   curMode = VVziWT.mode
   CCqHUu.VVNu9S(VVziWT, mode)
   bList.extend(VVziWT.getBouquetList() or [])
   CCqHUu.VVNu9S(VVziWT, curMode)
  return bList
 @staticmethod
 def VVNu9S(VVziWT, mode):
  if not mode == VVziWT.mode:
   if   mode == 0: VVziWT.setModeTv()
   elif mode == 1: VVziWT.setModeRadio()
 @staticmethod
 def VVCQnS(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVuXJC():
  try:
   fName = CCqHUu.VVCQnS(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVKSHN, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVy1MN():
  path = CCqHUu.VVuXJC()
  if path:
   txt = FFU2DB(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVeLhz():
  return FFlVIk(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVmUiX():
  lst = []
  for b in CCqHUu.VVVC9n():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVKSHN + CCqHUu.VVCQnS(bRef)
   if fileExists(path):
    lines = FFHq6Y(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVGyuY(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVwZqA(SID="", stripRType=False):
  if SID : patt = CCqHUu.VVGyuY(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCqHUu.VVVC9n():
   for service in FFlVIk(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVQW9t():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCqHUu.VVVC9n():
   for service in FFlVIk(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVxNVI(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVhsoS(pathLst, rType=""):
  refLst = CCqHUu.VVwZqA(CCqHUu.VVjqB1, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCqHUu.VVxNVI(rType, CCqHUu.VVjqB1, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCxFIK(Screen):
 VV5Jpg   = 0
 VVFKZ8  = 1
 VVU9xO  = 2
 VV14Ew = 3
 VVGBTC    = 20
 VVO6CV   = 0
 VV15Rc   = 1
 VVP0Z4   = 2
 def __init__(self, session, VVn9uf="/", mode=VV5Jpg, VVCX5f="Select", width=1400, height=920, VVJA7R=30, VVBBM8="#22001111", VVa80e="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFAm4L(VVAfZq, width, height, 30, 40, 20, VVBBM8, VVa80e, VVJA7R, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVBBM8   = VVBBM8
  self.VVa80e    = VVa80e
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFNG7m(self)
  FFTBJT(self["keyRed"] , "Exit")
  FFTBJT(self["keyYellow"], "More Options")
  FFTBJT(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVCX5f = VVCX5f
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVgstT = None
  if patternMode:
   self.mode = self.VV14Ew
   if   patternMode == "srt"  : VVgstT = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVgstT = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVgstT = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVgstT = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVgstT = ("^.*\.(%s)$" % "|".join(CCuwo1.VVTrvd()["mov"]), IGNORECASE)
   else       : VVgstT = None
  if self.mode in (self.VVU9xO, self.VV14Ew):
   FFTBJT(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVvyHf, self.VVn9uf = True , FFCdvu(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVvyHf, self.VVn9uf = True , CCxFIK.VVscnA(self)[1] or "/"
  elif self.mode == self.VV5Jpg  : VVvyHf, self.VVn9uf = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVU9xO : VVvyHf, self.VVn9uf = False, VVn9uf
  elif self.mode == self.VV14Ew : VVvyHf, self.VVn9uf = True , VVn9uf
  else           : VVvyHf, self.VVn9uf = True , VVn9uf
  self.VVn9uf = FFZsCH(self.VVn9uf)
  self["myMenu"] = CCuwo1(  directory   = None
         , VVgstT = VVgstT
         , VVvyHf   = VVvyHf
         , VV5lGq = True
         , VVTCfu = True
         , VVY0fV   = self.skinParam["width"]
         , VVJA7R   = self.skinParam["bodyFontSize"]
         , VV4xuv  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVMcMd    ,
   "red" : self.VVvWN9   ,
   "green" : self.VVdfnh,
   "yellow": self.VVfAle  ,
   "blue" : self.VVh98w ,
   "menu" : self.VVbRAJ  ,
   "info" : self.VVqe98  ,
   "cancel": self.VVbKFD    ,
   "pageUp": self.VVwTa6   ,
   "chanUp": self.VVwTa6
  }, -1)
  FFFTn6(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVovVc)
  global VV48b4
  VV48b4 = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  global VV48b4
  del VV48b4
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVovVc)
  FFfavv(self)
  FFyZo3(self["myMenu"], bg=self.cursorBG)
  FFzs4L(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVU9xO, self.VV14Ew):
   FFTBJT(self["keyGreen"], self.VVCX5f)
   self.VVzClf(self.VV15Rc)
  self.VVovVc()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVWXr4(self.VVn9uf) > self.bigDirSize: FF3LD6(self, self.VVWvJs, title="Changing directory...")
  else              : self.VVWvJs()
 def VVWvJs(self):
  if self.jumpToFile : self.VVcH91(self.jumpToFile)
  elif self.gotoMovie : self.VV3aid(chDir=False)
  else    : self["myMenu"].VVRQxi(self.VVn9uf)
 def VVICdA(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVhgTv(self):
  FF3LD6(self, self.VVDddV, title="Refreshing list ...")
 def VVDddV(self):
  isSel = self["myMenu"].VVtTbd()
  if not isSel:
   self.VVJ5lh(False)
  FFSoy0()
 def VVFyFw(self, saved):
  if saved: self.VVhgTv()
 def VVWXr4(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVMcMd(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVMdXI()
   if ok : self["keyBlue"].setText(self.VVDWfl())
   else : FFRB11(self, "Cannot select item", 500)
  elif self["myMenu"].VV9idc(): self.VVzYg5()
  else       : self.VVT2zH()
 def VVwTa6(self):
  if self.multiSelectState:
   FFRB11(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVwJLZ():
    self.VVzYg5()
 def VVzYg5(self, isDirUp=False):
  if self["myMenu"].VV9idc():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVTZ6K(self.VV7Q6f())
   if self.VVWXr4(path) > self.bigDirSize : FF3LD6(self, self.VVWWyv, title="Changing directory...")
   else           : self.VVWWyv()
 def VVWWyv(self):
  self["myMenu"].descent()
  self.VVovVc()
 def VVbKFD(self):
  if   self.multiSelectState     : self.VVJ5lh(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVvWN9()
  else          : self.VVwTa6()
 def VVvWN9(self):
  if not FFsY7N(self):
   self.close("")
 def VVdfnh(self):
  path = self.VVTZ6K(self.VV7Q6f())
  if self.mode == self.VVU9xO:
   self.close(path)
  elif self.mode == self.VV14Ew:
   if os.path.isfile(path) : self.close(path)
   else     : FFRB11(self, "Cannot access this file", 1000)
 def VVqe98(self):
  FF3LD6(self, self.VViil3, title="Calculating size ...")
 def VViil3(self):
  path = self.VVTZ6K(self.VV7Q6f())
  param = self.VVHwse(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFU8jM("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCxFIK.VVf1LM(path)
     freeSize = CCxFIK.VVZLIW(path)
     size = totSize - freeSize
     totSize  = CCxFIK.VVe4Bo(totSize)
     freeSize = CCxFIK.VVe4Bo(freeSize)
    else:
     size = FFngsO(path)
   usedSize = CCxFIK.VVe4Bo(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFivHt(pathTxt, VVL6GV) + "\n"
   if slBroken : fileTime = self.VVcZKs(path)
   else  : fileTime = self.VVhiC5(path)
   def VV65di(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV65di("Path"    , pathTxt)
   txt += VV65di("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV65di("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV65di("Total Size"   , "%s" % totSize)
    txt += VV65di("Used Size"   , "%s" % usedSize)
    txt += VV65di("Free Size"   , "%s" % freeSize)
   else:
    txt += VV65di("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV65di("Owner"    , owner)
   txt += VV65di("Group"    , group)
   txt += VV65di("Perm. (User)"  , permUser)
   txt += VV65di("Perm. (Group)"  , permGroup)
   txt += VV65di("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV65di("Perm. (Ext.)" , permExtra)
   txt += VV65di("iNode"    , iNode)
   txt += VV65di("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVyq7c(path)
  else:
   FF2zEl(self, "Cannot access information !")
  if len(txt) > 0:
   FFucjH(self, txt)
 def VVHwse(self, path):
  path = path.strip()
  path = FFjJ1n(path)
  result = FFU8jM("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVkW8H(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVkW8H(perm, 1, 4)
   permGroup = VVkW8H(perm, 4, 7)
   permOther = VVkW8H(perm, 7, 10)
   permExtra = VVkW8H(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFEEr4("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVyq7c(self, path):
  txt  = ""
  res  = FFU8jM("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFivHt("File Attributes:", VVuURa), txt)
  return txt
 def VVhiC5(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFwVZA(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFwVZA(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFwVZA(os.path.getctime(path))
  return txt
 def VVcZKs(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFU8jM("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFU8jM("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFU8jM("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVTZ6K(self, currentSel):
  currentDir  = self["myMenu"].VVcOn2()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV9idc():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VV7Q6f(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVovVc(self):
  path = self.VVTZ6K(self.VV7Q6f())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VV4LSM()
  if self.mode == self.VV5Jpg:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VV14Ew:
   path = self.VVTZ6K(self.VV7Q6f())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVbRAJ(self):
  color1 = VVAQIK
  color2 = VVhb13
  color3 = VVVJaM
  totSel = 0
  menuW = 1000
  title = "Options"
  VVgsyy= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVQO1n()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFZevi(totSel))
     VVgsyy.append((color1 + txt1     , "VVfr4m1" ))
     VVgsyy.append((color1 + txt1 + txt2   , "VVfr4m2" ))
     VVgsyy.append(VVzHzv)
    VVgsyy.append(("[6] Copy"       , "copyBulk" ))
    VVgsyy.append(("[7] Move"       , "moveBulk" ))
    VVgsyy.append(("[8] %sDELETE" % VVL6GV , "VVxXfO" ))
   else:
    FFRB11(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVU9xO, self.VV14Ew):
   VVgsyy.append(("Properties"           , "properties" ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVTZ6K(self.VV7Q6f())
   isEditable = self["myMenu"].VVIdz3()
   VVgsyy.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVgsyy.append(VVzHzv)
     VVgsyy.append((color1 + "Archiving / Packaging", "VVXtsS_dir"))
   elif os.path.isfile(path):
    selFile = self.VV7Q6f()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVgsyy.append((color1 + "Archive ...", "VVXtsS_file"))
    isText = False
    txt = ""
    if   isArch            : VVgsyy.extend(self.VV5TyZ(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVgsyy.extend(self.VVuKL8(True))
    elif selFile.endswith(".sh"):
     VVgsyy.extend(self.VVEY0d(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCxFIK.VVy2Za(path):
     VVgsyy.append(VVzHzv)
     VVgsyy.append((color2 + "View"     , "textView_def"))
     VVgsyy.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVgsyy.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVvf1u(path) == "pic":
     VVgsyy.append(VVzHzv)
     VVgsyy.append((color2 + "Set as PIcon for current channel" , "VVUT2f" ))
     if FFwmhG("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVgsyy.append(VVzHzv)
      VVgsyy.append((color2 + "Convert to MVI (1280 x 720 )" , "VVz63pHd"   ))
      VVgsyy.append((color2 + "Convert to MVI (1920 x 1080)" , "VVz63pFhd"   ))
    elif selFile.endswith(CCxFIK.VV1djP()):
     if selFile.endswith(".mvi"):
      if FFwmhG("showiframe"):
       VVgsyy.append(VVzHzv)
       VVgsyy.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVgsyy.append(VVzHzv)
      VVgsyy.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVgsyy.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVgsyy.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVgsyy.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVgsyy.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVgsyy.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVhIUq" ))
    if len(txt) > 0:
     VVgsyy.append(VVzHzv)
     VVgsyy.append((color1 + txt, "VVT2zH"))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("[4] Create SymLink", "VVqoOp"))
   if isEditable:
    VVgsyy.append(("[5] Rename"      , "VVItwO" ))
    VVgsyy.append(("[6] Copy"       , "copyFileOrDir" ))
    VVgsyy.append(("[7] Move"       , "moveFileOrDir" ))
    VVgsyy.append(("[8] %sDELETE" % VVL6GV , "VVgoeO" ))
    if fileExists(path):
     VVgsyy.append(VVzHzv)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVgsyy.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVgsyy.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVgsyy.append((chmodTxt + "777)", "chmod777"))
   VVgsyy.append(VVzHzv)
   VVgsyy.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVgsyy.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCxFIK.VVscnA(self)
   if fPath:
    VVgsyy.append(VVzHzv)
    VVgsyy.append((color2 + "Go to Current Movie Dir", "VV3aid"))
  FFCO3u(self, self.VVUDuu, width=menuW, height=1050, title=title, VVgsyy=VVgsyy, VVzKMB=False, VVBBM8="#00101020", VVa80e="#00101A2A")
 def VVUDuu(self, item=None):
  if item is not None:
   path = self.VVTZ6K(self.VV7Q6f())
   selFile = self.VV7Q6f()
   if   item == "VVfr4m1"    : self.VVfr4m(False)
   if   item == "VVfr4m2"    : self.VVfr4m(True)
   elif item == "copyBulk"     : self.VV01oW(False)
   elif item == "moveBulk"     : self.VV01oW(True)
   elif item == "VVxXfO"    : self.VVxXfO()
   elif item == "properties"    : self.VVqe98()
   elif item == "VVXtsS_dir" : self.VVXtsS(path, True)
   elif item == "VVXtsS_file" : self.VVXtsS(path, False)
   elif item == "VVtWxO"  : self.VVtWxO(path)
   elif item == "VVPXKD"  : self.VVPXKD(path)
   elif item.startswith("extract_")  : self.VVuNdk(path, selFile, item)
   elif item.startswith("script_")   : self.VVifo6(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVgvSa(path, selFile, item)
   elif item.startswith("textView_def") : FFpcNr(self, path)
   elif item.startswith("textView_enc") : self.VV2vAg(path)
   elif item.startswith("text_Edit")  : FF3LD6(self, BF(CCDQxK, self, path, VVRlGe=self.VVFyFw), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVmZLU(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVmZLU(path, "Save as Other Encoding", False)
   elif item.startswith("VVhIUq") : self.VVhIUq(path)
   elif item == "viewAsBootlogo"   : self.VVS4Cj(path, True)
   elif item == "addMovieToBouquet"  : self.VVENZa(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVENZa(path, True)
   elif item == "playWith"     : self.VV0L8k(path)
   elif item == "VVUT2f" : self.VVUT2f(path)
   elif item == "VVz63pHd"   : FF3LD6(self, BF(self.VVz63p, path, False))
   elif item == "VVz63pFhd"   : FF3LD6(self, BF(self.VVz63p, path, True))
   elif item == "VVqoOp"   : self.VVqoOp(path, selFile)
   elif item == "VVItwO"   : self.VVItwO(path, selFile)
   elif item == "copyFileOrDir"   : self.VVh24x(path, False)
   elif item == "moveFileOrDir"   : self.VVh24x(path, True)
   elif item == "VVgoeO"   : self.VVgoeO(path, selFile)
   elif item == "chmod644"     : self.VVquPC(path, selFile, "644")
   elif item == "chmod755"     : self.VVquPC(path, selFile, "755")
   elif item == "chmod777"     : self.VVquPC(path, selFile, "777")
   elif item == "createNewFile"   : self.VVOSK9(path, True)
   elif item == "createNewDir"    : self.VVOSK9(path, False)
   elif item == "VV3aid"   : self.VV3aid()
   elif item == "VVT2zH"    : self.VVT2zH()
 def VVT2zH(self):
  if self.mode == self.VV14Ew and not self.patternMode == "poster":
   return
  selFile = self.VV7Q6f()
  path  = self.VVTZ6K(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVvf1u(path)
   if   cat == "pic"       : self.VVtJ27(path)
   elif cat == "txt"       : FFpcNr(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVOGb0(path, selFile)
   elif cat == "scr"       : self.VVkan0(path, selFile)
   elif cat == "m3u"       : self.VVW7VD(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVoUaT(path, selFile)
   elif cat in ("mov", "mus")     : self.VVS4Cj(path)
   elif not CCxFIK.VVy2Za(path) : FFpcNr(self, path)
 def VVtJ27(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVvf1u(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCslfl.VVIg0A(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVUPGr)
 def VVUPGr(self, path):
  self.VVcH91(path)
 def VVS4Cj(self, path, asLogo=False):
  if asLogo : CCaWg8.VV7Zo4(self, path)
  else  : FF3LD6(self, BF(self.VVB4hc, self, path), title="Playing Media ...")
 def VVh98w(self):
  if self["keyBlue"].getVisible():
   VVX3UR = self.VVRlK5()
   if VVX3UR:
    path = self.VVTZ6K(self.VV7Q6f())
    enableGreenBtn = False if path in self.VVRlK5() else True
    newList = []
    for line in VVX3UR:
     newList.append((line, line))
    VVbSf3  = ("Delete"    , self.VVGSby    )
    VV2u6t  = ("Add Current Dir"   , BF(self.VVeNiV, path) ) if enableGreenBtn else None
    VVOmbd = ("Move Up"     , self.VVelkx    )
    VVtL1m  = ("Move Down"   , self.VVMOsO    )
    self.bookmarkMenu = FFCO3u(self, self.VVakss, width=1200, title="Bookmarks", VVgsyy=newList, minRows=10 ,VVbSf3=VVbSf3, VV2u6t=VV2u6t, VVOmbd=VVOmbd, VVtL1m=VVtL1m, VVBBM8="#00000022", VVa80e="#00000022")
 def VVGSby(self, VVyxPv=None, path=None):
  VVX3UR = self.VVRlK5()
  if VVX3UR:
   while path in VVX3UR:
    VVX3UR.remove(path)
   self.VVt2zg(VVX3UR)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVqTM0(VVX3UR)
   self.bookmarkMenu.VVMFbN(("Add Current Dir", BF(self.VVeNiV, path)))
  else:
   FFRB11(self, "Removed", 800)
  self.VV4LSM()
 def VVeNiV(self, path, VVyxPv=None, item=None):
  VVX3UR = self.VVRlK5()
  if len(VVX3UR) >= self.VVGBTC:
   FF2zEl(SELF, "Max bookmarks reached (max=%d)." % self.VVGBTC)
  elif not path in VVX3UR:
   if not os.path.isdir(path):
    path = FFCdvu(path, True)
   newList = [path] + VVX3UR
   self.VVt2zg(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVqTM0(newList)
    self.bookmarkMenu.VVMFbN()
   else:
    FFRB11(self, "Added", 800)
  self.VV4LSM()
 def VVelkx(self, VV7Q6fObj, path):
  if self.bookmarkMenu:
   VVX3UR = self.bookmarkMenu.VVNQdb(True)
   if VVX3UR:
    self.VVt2zg(VVX3UR)
 def VVMOsO(self, VV7Q6fObj, path):
  if self.bookmarkMenu:
   VVX3UR = self.bookmarkMenu.VVNQdb(False)
   if VVX3UR:
    self.VVt2zg(VVX3UR)
 def VVakss(self, folder=None):
  if folder:
   folder = FFZsCH(folder)
   self["myMenu"].VVRQxi(folder)
   self["myMenu"].moveToIndex(0)
  self.VVovVc()
 def VVRlK5(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVDhAZ(self):
  return True if VVRlK5() else False
 def VVt2zg(self, VVX3UR):
  line = ",".join(VVX3UR)
  FFH7ga(CFG.browserBookmarks, line)
 def VVcH91(self, path):
  if fileExists(path):
   fDir  = FFZsCH(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVRQxi(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFRB11(self, "Not found", 1000)
 def VV3aid(self, chDir=True):
  fPath, fDir, fName = CCxFIK.VVscnA(self)
  self.VVcH91(fPath)
 def VVfAle(self):
  path = self.VVTZ6K(self.VV7Q6f())
  isAdd = False if path in self.VVRlK5() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VViC5D, VVL7a3, VVhb13
  VVgsyy = []
  VVgsyy.append(("Find Files ..." , "find"))
  VVgsyy.append(("Sort ..."   , "sort"))
  VVgsyy.append(VVzHzv)
  if isAdd: VVgsyy.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVgsyy.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VV5Jpg:
   VVgsyy.append(VVzHzv)
   if self.multiSelectState: VVgsyy.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVgsyy.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVgsyy.append(       (c3 + "Select all"    , "selAll"  ))
  FFCO3u(self, BF(self.VVdWMs, path), width=750, title="More Options", VVgsyy=VVgsyy, VVBBM8="#00221111", VVa80e="#00221111")
 def VVdWMs(self, path, item):
  if item:
   if   item == "find"  : self.VV6RWP(path)
   elif item == "sort"  : self.VVSQIV()
   elif item == "addBM" : self.VVeNiV(path)
   elif item == "remBM" : self.VVGSby(None, path)
   elif item == "start" : self.VV5Yws(path)
   elif item == "multiOn" : self.VVJ5lh(True)
   elif item == "multiOff" : self.VVJ5lh(False)
   elif item == "selAll" : self.VVJ5lh(True, True)
 def VVJ5lh(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FF3LD6(self, BF(self["myMenu"].VVd9i6, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVzClf(self.VVP0Z4 if isOn else self.VVO6CV)
 def VVzClf(self, mode=0):
  if   mode == self.VV15Rc : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVP0Z4: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVBBM8, self.VVa80e
  FFvobF(self["myTitle"], titBg)
  FFvobF(self["myBar"], titBg)
  FFvobF(self["myBody"], bodBg)
  FFvobF(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVDWfl()
  else     : bg, txt = VVZ4OB[3], "Bookmarks"
  FFTBJT(self["keyBlue"], txt)
  FFvobF(self["keyBlue"], bg)
  self.VV4LSM()
 def VVDWfl(self):
  return "Selected Items = %d" % self["myMenu"].VVQO1n()
 def VV4LSM(self):
  if self.VVRlK5() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VV6RWP(self, path):
  VVgsyy = []
  VVgsyy.append(("Find in Current Directory"    , "findCur"  ))
  VVgsyy.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVgsyy.append(("Find in all Storage Systems"    , "findAll"  ))
  FFCO3u(self, BF(self.VVwteP, path), width=700, title="Find File/Pattern", VVgsyy=VVgsyy, VVf67P=True, VVwQO5=True, VVBBM8="#00221111", VVa80e="#00221111")
 def VVwteP(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VV7JAk(0, path, title)
   elif item == "findCurR" : self.VV7JAk(1, path, title)
   elif item == "findAll" : self.VV7JAk(2, path, title)
 def VV7JAk(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FF7lc9(self, BF(self.VVLXxZ, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVLXxZ(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFH7ga(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFRB11(self, "No entery", 1500)
   elif badLst  : FFRB11(self, "Too many file !", 1500)
   else   : FF3LD6(self, BF(self.VV5SEh, mode, path, title, filePatt), title="Searching ...")
 def VV5SEh(self, mode, path, title, filePatt):
  lst = FFIeeK(FFh3QW("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCxFIK.VVjWm9(lst)
   if err:
    FF2zEl(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVPn7Q = (""     , self.VV7ot5 , [])
    VV6LI6 = ("Go to File Location", self.VVe5Vo  , [])
    FFyrIU(self, None, title="%s : %s" % (title, filePatt), header=header, VVX3UR=lst, VVBL0l=widths, VVJA7R=26, VVPn7Q=VVPn7Q, VV6LI6=VV6LI6)
  else:
   FFKCVv(self, "Not found !", 2000)
 def VVe5Vo(self, VVgl66, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVgl66.cancel()
   self.VVcH91(path)
  else:
   FFRB11(VVgl66, "Path not found !", 1000)
 def VV7ot5(self, VVgl66, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFivHt("File:"  , VVhb13), colList[0])
  txt += "%s\n%s"  % (FFivHt("Directory:", VVhb13), FFZsCH(colList[1]))
  FFucjH(VVgl66, txt, title=title)
 def VVSQIV(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV2RKo()
  VVgsyy = []
  VVgsyy.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVgsyy.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVgsyy.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVgsyy.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVtL1m = ("Mix", BF(self.VVyNSn, True))
  FFCO3u(self, BF(self.VVvwTx, False), barText=txt, width=650, title="Sort Options", VVgsyy=VVgsyy, VVtL1m=VVtL1m, VVwQO5=True, VVBBM8="#00221111", VVa80e="#00221111")
 def VVyNSn(self, isMix, VVyxPv, item):
  self.VVvwTx(True, item)
 def VVvwTx(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VV2RKo()
   title = "Sorting ... "
   if   item == "nameAlp": FF3LD6(self, BF(self["myMenu"].VVEZQN, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FF3LD6(self, BF(self["myMenu"].VVEZQN, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FF3LD6(self, BF(self["myMenu"].VVEZQN, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FF3LD6(self, BF(self["myMenu"].VVEZQN, typeMode , isMix, False), title=title)
 def VV5Yws(self, path):
  if not os.path.isdir(path):
   path = FFCdvu(path, True)
  FFH7ga(CFG.browserStartPath, path)
  FFRB11(self, "Done", 500)
 def VV9i5e(self, selFile, VVWZXE, command):
  FFZnVu(self, BF(FFyAzl, self, command, consFont=True, VV5SfP=self.VVhgTv), "%s\n\n%s" % (VVWZXE, selFile))
 def VV5TyZ(self, path, calledFromMenu):
  destPath = self.VVykEn(path)
  lastPart = FFSHhe(destPath)
  color = VVhb13 if calledFromMenu else ""
  VVgsyy = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVgsyy.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVgsyy.append(VVzHzv)
   VVgsyy.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVgsyy.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVgsyy.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVgsyy.append(VVzHzv)
     VVgsyy.append((color + "Convert .zip to .tar.gz"       , "VVtWxO" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVgsyy.append(VVzHzv)
     VVgsyy.append((color + "Convert .tar.gz to .zip"       , "VVPXKD" ))
  return VVgsyy
 def VVOGb0(self, path, selFile):
  FFCO3u(self, BF(self.VVuNdk, path, selFile), title="Compressed File Options", VVgsyy=self.VV5TyZ(path, False))
 def VVuNdk(self, path, selFile, item=None):
  if item is not None:
   parent  = FFCdvu(path, False)
   destPath = self.VVykEn(path)
   lastPart = FFSHhe(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFWSuq("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFWSuq("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFy48B(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVtWxO" : self.VVtWxO(path)
    else       : self.VVn4J8(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVPXKD" and path.endswith(".tar.gz"):
    self.VVPXKD(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFU8jM("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FF5kkM(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVhgTv()
    else:
     FF2zEl(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VV8kxc(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFT1jM("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV9i5e(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV9i5e(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFCdvu(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV9i5e(selFile, "Extract Here ?"      , cmd)
 def VVykEn(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVn4J8(self, item, path, parent, destPath, VVWZXE):
  FFZnVu(self, BF(self.VV9fOH, item, path, parent, destPath), VVWZXE)
 def VV9fOH(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFWSuq("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFmPm4(destPath, VVd7n9))
  cmd +=   sep
  cmd += "fi;"
  FF0Zhf(self, cmd, VV5SfP=self.VVhgTv)
 def VV8kxc(self, item, path, parent, destPath, VVWZXE):
  FFZnVu(self, BF(self.VVlMjt, item, path, parent, destPath), VVWZXE)
 def VVlMjt(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFZsCH(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFWSuq("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFmPm4(destPath, VVd7n9))
  cmd +=   sep
  cmd += "fi;"
  FF0Zhf(self, cmd, VV5SfP=self.VVhgTv)
 def VVEY0d(self, addSep=False):
  VVgsyy = []
  if addSep:
   VVgsyy.append(VVzHzv)
  VVgsyy.append((VVhb13 + "View Script File"  , "script_View"  ))
  VVgsyy.append((VVhb13 + "Execute Script File" , "script_Execute" ))
  VVgsyy.append((VVhb13 + "Edit"     , "script_Edit"  ))
  return VVgsyy
 def VVkan0(self, path, selFile):
  FFCO3u(self, BF(self.VVifo6, path, selFile), title="Script File Options", VVgsyy=self.VVEY0d())
 def VVifo6(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFpcNr(self, path)
   elif item == "script_Execute" : self.VV9i5e(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCDQxK(self, path, VVRlGe=self.VVFyFw)
 def VVuKL8(self, addSep=False):
  VVgsyy = []
  if addSep:
   VVgsyy.append(VVzHzv)
  VVgsyy.append((VVhb13 + "Browse IPTV Channels" , "m3u_Browse" ))
  VVgsyy.append((VVhb13 + "Edit"     , "m3u_Edit" ))
  VVgsyy.append((VVhb13 + "View"     , "m3u_View" ))
  return VVgsyy
 def VVW7VD(self, path, selFile):
  FFCO3u(self, BF(self.VVgvSa, path, selFile), title="M3U/M3U8 File Options", VVgsyy=self.VVuKL8())
 def VVgvSa(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF3LD6(self, BF(self.session.open, CCA7uK, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCDQxK(self, path, VVRlGe=self.VVFyFw)
   elif item == "m3u_View"  : FFpcNr(self, path)
 def VV2vAg(self, path):
  if fileExists(path) : FF3LD6(self, BF(CCCXVP.VV3NXk, self, path, BF(self.VV5oEc, path)), title="Loading Codecs ...")
  else    : FFdxlA(self, path)
 def VV5oEc(self, path, item=None):
  if item:
   FFpcNr(self, path, encLst=item)
 def VVmZLU(self, path, title, asUtf8):
  if fileExists(path) : FF3LD6(self, BF(CCCXVP.VV3NXk, self, path, BF(self.VVQgmw, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFdxlA(self, path)
 def VVQgmw(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVD9rt(path, title, fromEnc, "UTF-8")
   else  : CCCXVP.VV9I3o(self, BF(self.VVD9rt, path, title, fromEnc), title="Convert to Encoding")
 def VVD9rt(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFivHt("Successful\n\n", VVd7n9)
      txt += FFivHt("From Encoding (%s):\n" % fromEnc, VVMdMA)
      txt += "%s\n\n" % path
      txt += FFivHt("To Encoding (%s):\n" % toEnc, VVMdMA)
      txt += "%s\n\n" % outFile
      FFucjH(self, txt, title=title)
    except:
     FF2zEl(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFRB11(self, "Cannot open file", 2000)
   self.VVhgTv()
 def VVhIUq(self, path):
  title = "File Line-Break Conversion"
  FFZnVu(self, BF(self.VVLenI, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVLenI(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFivHt("File converted:", VVd7n9), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF5kkM(self, txt, title=title)
  else:
   FFdxlA(self, path, title=title)
 def VVquPC(self, path, selFile, newChmod):
  FFZnVu(self, BF(self.VVy4KY, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVy4KY(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVso67)
  result = FFU8jM(cmd)
  if result == "Successful" : FF5kkM(self, result)
  else      : FF2zEl(self, result)
 def VVqoOp(self, path, selFile):
  parent = FFCdvu(path, False)
  self.session.openWithCallback(self.VVMMD6, BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=parent, VVCX5f="Create Symlink here"))
 def VVMMD6(self, newPath):
  if len(newPath) > 0:
   target = self.VVTZ6K(self.VV7Q6f())
   target = FFjJ1n(target)
   linkName = FFSHhe(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFZsCH(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF2zEl(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFZnVu(self, BF(self.VVKTTW, target, link), "Create Soft Link ?\n\n%s" % txt, VVOuLx=True)
 def VVKTTW(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVso67)
  result = FFU8jM(cmd)
  if result == "Successful" : FF5kkM(self, result)
  else      : FF2zEl(self, result)
 def VVItwO(self, path, selFile):
  lastPart = FFSHhe(path)
  FF7lc9(self, BF(self.VVgSpm, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVgSpm(self, path, selFile, VVfLRn):
  if VVfLRn:
   parent = FFCdvu(path, True)
   if os.path.isdir(path):
    path = FFjJ1n(path)
   newName = parent + VVfLRn
   cmd = "mv '%s' '%s' %s" % (path, newName, VVso67)
   if VVfLRn:
    if selFile != VVfLRn:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFZnVu(self, BF(self.VVbwwh, cmd), message, title="Rename file?")
    else:
     FF2zEl(self, "Cannot use same name!", title="Rename")
 def VVbwwh(self, cmd):
  result = FFU8jM(cmd)
  if "Fail" in result:
   FF2zEl(self, result)
  self.VVhgTv()
 def VVfr4m(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVZIrs, title, preserve)
      , VVRlGe = BF(self.VVYrcT, title))
 def VVZIrs(self, title, preserve, VVxeRf):
  totSel = self["myMenu"].VVQO1n()
  totOk = totFail = 0
  VVxeRf.VVPZSN(totSel)
  VVxeRf.VVxy84 = ["", totSel, totOk, totFail, ""]
  VVxeRf.VV1hS4("Prepareing targz file")
  curDir = self["myMenu"].VVcOn2()
  lastPart = FFSHhe(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVxeRf or VVxeRf.isCancelled:
      return
     if row[2][6]:
      VVxeRf.VVnoYr(1)
      name  = FFjJ1n(row[0][0])
      lastPath = FFSHhe(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVxeRf:
       VVxeRf.VVxy84 = [outF, totSel, totOk, totFail, path]
       VVxeRf.VVELUC(totOk, lastPath)
  except:
   totFail += 1
   if VVxeRf:
    VVxeRf.VVxy84 = [outF, totSel, totOk, totFail, path]
 def VVYrcT(self, title, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVxy84
  txt  = "%s:\n%s\n\n"   % (FFivHt("Output File", VVd7n9), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFivHt("Failed\t: %d\n" % totFail, VVL6GV)
  if not VV1FXh: txt += "%s\n%s" % (FFivHt("\nCancelled while copying:", VVL6GV), path)
  FFucjH(self, txt, title=title)
  self.VVhgTv()
 def VV01oW(self, isMove):
  self.session.openWithCallback(BF(self.VVIqZB, isMove), BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=self["myMenu"].VVcOn2(), VVCX5f="Move to here" if isMove else "Paste here"))
 def VVIqZB(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVQuac, title, action, isMove, newPath)
       , VVRlGe = BF(self.VVufIW, title, action, isMove, newPath))
 def VVQuac(self, title, action, isMove, newPath, VVxeRf):
  curDir = self["myMenu"].VVcOn2()
  totOk = totFail = 0
  totSel = self["myMenu"].VVQO1n()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVxeRf.VVPZSN(totSel)
  VVxeRf.VVxy84 = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVxeRf or VVxeRf.isCancelled:
    return
   if row[2][6]:
    VVxeRf.VVnoYr(1)
    VVxeRf.VVK5Ir(action, totOk, FFSHhe(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFSHhe(path)
    if os.path.isdir(path): path = FFjJ1n(path)
    dest = os.path.join(newPath, lastPart)
    if FFlh8N("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVxeRf:
     VVxeRf.VVxy84 = [totSel, totOk, totFail, path]
     VVxeRf.VVK5Ir(action, totOk, FFSHhe(row[0][0]))
 def VVufIW(self, title, action, isMove, newPath, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVxy84
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFivHt("Failed\t: %d\n" % totFail, VVL6GV)
  if not VV1FXh: txt += "%s\n%s" % (FFivHt("\nCancelled while copying:", VVL6GV), path)
  FFucjH(self, txt, title=title)
  self.VVhgTv()
 def VVxXfO(self):
  tot = self["myMenu"].VVQO1n()
  FFZnVu(self, BF(FF3LD6, self, self.VV4VnS, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFZevi(tot)), title="Delete Selection")
 def VV4VnS(self):
  path = self["myMenu"].VVcOn2()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFVlAt(os.path.join(path, row[0][0]))
  FFRB11(self)
  self.VVhgTv()
 def VVh24x(self, path, isMove):
  self.session.openWithCallback(BF(self.VV2L4i, isMove, path), BF(CCxFIK, mode=CCxFIK.VVU9xO, VVn9uf=FFCdvu(path, False), VVCX5f="Move to here" if isMove else "Paste here"))
 def VV2L4i(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFjJ1n(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFjJ1n(src)
  dst = os.path.join(dst, FFSHhe(src))
  if src == dst:
   FF2zEl(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFZnVu(self, BF(self.VVd9ML, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFZnVu(self, BF(self.VVd9ML, prams), "Overwrite Destination Files", title=title)
  else         : self.VVd9ML(prams)
 def VVd9ML(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCxFIK.VV5UJg(src) == CCxFIK.VV5UJg(dst):
   FF3LD6(self, BF(self.VV74OI, prams), title="Moving %s ..." % srcSubj)
  else:
   FF3LD6(self, BF(self.VV32j7, prams), title="Calculating Size ...")
 def VV74OI(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFU8jM("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVhgTv()
  else:
   FF2zEl(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VV32j7(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFQfFR(src)
  else  : size = FFngsO(src)
  if size > -1:
   self.session.open(CCNT6G, barTheme=CCNT6G.VV3Zg2, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVUSfw, prams, size)
       , VVRlGe = BF(self.VVo3lP, prams))
  else:
   FF2zEl(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVUSfw(self, prams, size, VVxeRf):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVxeRf.VVPZSN(size)
  VVxeRf.VVxy84 = ("", "", False)
  def VVaiQL(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFAFdq(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVxeRf or VVxeRf.isCancelled:
        VVxeRf.VVxy84 = (srcFile, "", True)
        FFAFdq(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVxeRf.VVnoYr(len(data))
       except Exception as e:
        VVxeRf.VVxy84 = (srcFile, str(e), False)
        FFAFdq(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFAFdq(srcFile)
   return True
  if isFile:
   tot = 1
   VVaiQL(src, dst)
  else:
   VVxeRf.VV1hS4("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFXtMv(src)
   if not VVxeRf or VVxeRf.isCancelled:
    VVxeRf.VVxy84 = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVxeRf.VVxy84 = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVxeRf.VV1hS4("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVaiQL(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFlh8N("rm -fr '%s'" % Dir)
   if isMove:
    FFlh8N("rm -fr '%s'" % src)
 def VVo3lP(self, prams, VV1FXh, VVxy84, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVxy84
  if err:
   FF2zEl(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFRB11(self, "Canelled", 1000)
   else  : FF2zEl(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFRB11(self, "Done", 1500, isGrn=True)
  if VV1FXh and isMove:
   self.VVhgTv()
 def VVgoeO(self, path, fileName):
  path = FFjJ1n(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFZnVu(self, BF(FF3LD6, self, BF(self.VV9I2B, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV9I2B(self, path):
  FFVlAt(path)
  FFRB11(self)
  self.VVhgTv()
 def VVOSK9(self, path, isFile):
  dirName = FFZsCH(os.path.dirname(path))
  if isFile : objName, VVfLRn = "File"  , self.edited_newFile
  else  : objName, VVfLRn = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF7lc9(self, BF(self.VVNp3u, dirName, isFile, title), title=title, defaultText=VVfLRn, message="Enter %s Name:" % objName)
 def VVNp3u(self, dirName, isFile, title, VVfLRn):
  if VVfLRn:
   if isFile : self.edited_newFile = VVfLRn
   else  : self.edited_newDir  = VVfLRn
   path = dirName + VVfLRn
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVso67)
    else  : cmd = "mkdir '%s' %s" % (path, VVso67)
    result = FFU8jM(cmd)
    if "Fail" in result:
     FF2zEl(self, result)
    self.VVhgTv()
   else:
    FF2zEl(self, "Name already exists !\n\n%s" % path, title)
 def VVoUaT(self, path, selFile):
  c1, c2, c3 = VVL7a3, VVhb13, VVAQIK
  VVgsyy = []
  VVgsyy.append((c1 + "List Package Files"         , "VVuES9"     ))
  VVgsyy.append((c1 + "Package Information"         , "VVUyyf"     ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Install Package"          , "VVpwJs_CheckVersion" ))
  VVgsyy.append((c2 + "Install Package (force reinstall)"     , "VVpwJs_ForceReinstall" ))
  VVgsyy.append((c2 + "Install Package (force overwrite)"     , "VVpwJs_ForceOverwrite" ))
  VVgsyy.append((c2 + "Install Package (force downgrade)"     , "VVpwJs_ForceDowngrade" ))
  VVgsyy.append((c2 + "Install Package (ignore failed dependencies)"  , "VVpwJs_IgnoreDepends" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c3 + "Remove Related Package"        , "VVT4TX_ExistingPackage" ))
  VVgsyy.append((c3 + "Remove Related Package (force remove)"    , "VVT4TX_ForceRemove"  ))
  VVgsyy.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVT4TX_IgnoreDepends" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Extract Files"           , "VVWMbm"     ))
  VVgsyy.append(("Unbuild Package"           , "VVVqhc"     ))
  FFCO3u(self, BF(self.VVOZMZ, path, selFile), VVgsyy=VVgsyy)
 def VVOZMZ(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVuES9"      : self.VVuES9(path, selFile)
   elif item == "VVUyyf"      : self.VVUyyf(path)
   elif item == "VVpwJs_CheckVersion"  : self.VVpwJs(path, selFile, VV58Rq     )
   elif item == "VVpwJs_ForceReinstall" : self.VVpwJs(path, selFile, VVG7vb )
   elif item == "VVpwJs_ForceOverwrite" : self.VVpwJs(path, selFile, VVexTQ )
   elif item == "VVpwJs_ForceDowngrade" : self.VVpwJs(path, selFile, VVwHSw )
   elif item == "VVpwJs_IgnoreDepends" : self.VVpwJs(path, selFile, VVuIYv )
   elif item == "VVT4TX_ExistingPackage" : self.VVT4TX(path, selFile, VV4aqy     )
   elif item == "VVT4TX_ForceRemove"  : self.VVT4TX(path, selFile, VV50Yb  )
   elif item == "VVT4TX_IgnoreDepends"  : self.VVT4TX(path, selFile, VVUGjK )
   elif item == "VVWMbm"     : self.VVWMbm(path, selFile)
   elif item == "VVVqhc"     : self.VVVqhc(path, selFile)
   else           : self.close()
 def VVuES9(self, path, selFile):
  if FFwmhG("ar") : cmd = "allOK='1';"
  else    : cmd  = FFiCnc()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FF9J6v(self, cmd, VV5SfP=self.VVhgTv)
 def VVWMbm(self, path, selFile):
  lastPart = FFSHhe(path)
  dest  = FFCdvu(path, True) + selFile[:-4]
  cmd  =  FFiCnc()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFT1jM("mkdir '%s'" % dest)
  cmd +=    FFT1jM("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFmPm4(dest, VVd7n9))
  cmd += "fi;"
  FFyAzl(self, cmd, VV5SfP=self.VVhgTv)
 def VVVqhc(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVwmxb = os.path.splitext(path)[0]
  else        : VVwmxb = path + "_"
  if path.endswith(".deb")   : VVshn6 = "DEBIAN"
  else        : VVshn6 = "CONTROL"
  cmd  = FFiCnc()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVwmxb
  cmd += "  mkdir '%s';"      % VVwmxb
  cmd += "  CONTPATH='%s/%s';"    % (VVwmxb, VVshn6)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVwmxb
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVwmxb, VVwmxb)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVwmxb
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVwmxb, VVwmxb)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVwmxb
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVwmxb
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVwmxb, FFmPm4(VVwmxb, VVd7n9))
  cmd += "fi;"
  FFyAzl(self, cmd, VV5SfP=self.VVhgTv)
 def VVUyyf(self, path):
  listCmd  = FFYO4M(VVC4fX, "")
  infoCmd  = FFcDAv(VVpgtv , "")
  filesCmd = FFcDAv(VVRD1w, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFHble(VVMdMA)
   notInst = "Package not installed."
   cmd  = FFouUN("File Info", VVMdMA)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFouUN("System Info", VVMdMA)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFmPm4(notInst, VVL6GV))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFouUN("Related Files", VVMdMA)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFy48B(self, cmd)
  else:
   FFjIcG(self)
 def VVpwJs(self, path, selFile, cmdOpt):
  cmd = FFcDAv(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFZnVu(self, BF(FFyAzl, self, cmd, VV5SfP=FFSoy0), "Install Package ?\n\n%s" % selFile)
  else:
   FFjIcG(self)
 def VVT4TX(self, path, selFile, cmdOpt):
  listCmd  = FFYO4M(VVC4fX, "")
  infoCmd  = FFcDAv(VVpgtv, "")
  instRemCmd = FFcDAv(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFmPm4(errTxt, VVL6GV))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFmPm4(cannotTxt, VVL6GV))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFmPm4(tryTxt, VVL6GV))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFZnVu(self, BF(FFyAzl, self, cmd, VV5SfP=FFSoy0), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFjIcG(self)
 def VVVL3O(self, path):
  hostName = FFU8jM("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVXtsS(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVgsyy = []
  VVgsyy.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVgsyy.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVgsyy.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVgsyy.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVgsyy.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVgsyy.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVgsyy.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVgsyy.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVgsyy.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVgsyy.append(VVzHzv)
   VVgsyy.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVgsyy.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFCO3u(self, BF(self.VVkUTY, path, isDir, title), VVgsyy=VVgsyy, title=title, VVBBM8=c1, VVa80e=c2)
 def VVkUTY(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVY21k(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVY21k(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVY21k(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVY21k(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVY21k(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVY21k(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVY21k(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVY21k(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVY21k(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVY21k(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVME7j(path, False)
   elif item == "convertDirToDeb" : self.VVME7j(path, True)
 def VVME7j(self, path, VVi6yH):
  self.session.openWithCallback(self.VVhgTv, BF(CCItJq, path=path, VVi6yH=VVi6yH))
 def VVY21k(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFCdvu(path, True)
  lastPart = FFSHhe(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFWSuq("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFWSuq("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFWSuq("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFT1jM("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFmPm4(failed, VVgmAg))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFmPm4(srcTxt, VViC5D))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFmPm4("Output", VVd7n9))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFmPm4(failed, VVHEBa))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FF9J6v(self, cmd, VV5SfP=self.VVhgTv, title=title)
 def VVENZa(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCxFIK.VVA1GK(FFCdvu(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCqHUu(self, self, title, BF(self.VVXfD8, pathLst))
 def VVXfD8(self, pathLst):
  return CCqHUu.VVhsoS(pathLst)
 def VVtWxO(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVxKJc, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFZnVu(self, BF(FF3LD6, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF3LD6(self, fnc, title=txt)
  else:
   FF2zEl(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVxKJc(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFucjH(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVhgTv()
  else:
   FFAFdq(tarPath)
   FF2zEl(self, "Error while converting.", title=title)
 def VVPXKD(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVYB4d, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFZnVu(self, BF(FF3LD6, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FF3LD6(self, fnc, title=txt)
  else:
   FF2zEl(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVYB4d(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFucjH(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVhgTv()
  else:
   FFAFdq(zipPath)
   FF2zEl(self, "Error while converting.", title=title)
 def VVz63p(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFZsCH(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFlh8N("rm -f '%s' '%s'" % (m1v, mvi))
  if FFlh8N("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFlh8N("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVhgTv()
   FF5kkM(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FF2zEl(self, "Cannot convert this file !", title=title)
 def VVUT2f(self, path):
  title = "Set as PIcon for current channel"
  pPath = CC0NDf.VVqbLc()
  if pathExists(pPath):
   if CCYT65.VVvGIJ(self, title, False, cbFnc=BF(self.VVUT2f, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVgsyy = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVgsyy.append(("%d x %d" % (item), item))
    VVxQ85 = self.VV6wGI
    VVtL1m = ("Stretch", BF(self.VVSBsu, title, path, picon))
    VVyxPv = FFCO3u(self, BF(self.VVM547, title, path, picon, False), VVgsyy=VVgsyy, width=700, title='PIcon Max. Size', VVxQ85=VVxQ85, VVtL1m=VVtL1m, barText="OK = Fit within size")
    VVyxPv.VVCNsC(3)
  else:
   FF2zEl(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVSBsu(self, title, path, picon, VV7Q6fObj, item):
  self.VVM547(title, path, picon, True, item)
  VV7Q6fObj.cancel()
 def VVM547(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFBxYU(self, fncMode=CCTzTd.VVfwSM)
   except Exception as e:
    FF2zEl(self, "Image Processing error:\n\n%s" % e)
 def VV6wGI(self, VVyxPv, txt, ref, ndx):
  FF6duf(self, "_help_resize", "Picture File Resizing")
 def VV0L8k(self, path):
  FFCO3u(self, BF(self.VVcfdS, path), VVgsyy=CCA7uK.VVFs6h(), width=650, title="Select Player", VVBBM8="#11220000", VVa80e="#11220000")
 def VVcfdS(self, path, rType=None):
  if rType:
   FF3LD6(self, BF(self.VVB4hc, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVB4hc(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCC5bX.VVBgB6(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVscnA(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFZsCH(fDir), fName
  return "", "", ""
 @staticmethod
 def VVf1LM(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVZLIW(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVe4Bo(size, mode=0):
  txt = CCxFIK.VVYP0R(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVYP0R(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVy2Za(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVeJOe(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FF2zEl(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV1djP():
  tDict = CCuwo1.VVTrvd()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVA1GK(path):
  lst = []
  for ext in CCxFIK.VV1djP():
   lst.extend(FFPCH3(path, "*.%s" % ext))
  return sorted(lst, key=FFbRsK(FFDjgW))
 @staticmethod
 def VVsGUQ(path):
  return FFlh8N("tar -tzf '%s'" % path)
 @staticmethod
 def VV5UJg(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVjWm9(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VV2Pt1:
   return VV2Pt1
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCuwo1(MenuList):
 VV1Wzx   = 0
 VVurcY   = 1
 VVXMyk   = 2
 VVUmjm   = 3
 VVF5eW   = 4
 VVZezc   = 5
 VV3sD9   = 6
 VVfmXr   = 7
 VVtV53   = "<List of Storage Devices>"
 VVYIiH  = "<Parent Directory>"
 VVEs3R   = 0
 VVDWkl   = 1
 VVBj9M = 2
 VV0hI4  = 3
 VVaV8A   = 4
 VVHkm8   = 5
 FILE_TYPE_LINK   = 6
 VVEJD9  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVTCfu=False, directory="/", VVeZLi=True, VVvyHf=True, VV5lGq=True, VVgstT=None, VVo77b=False, VVi3fw=False, VVHAIx=False, isTop=False, VVWOzn=None, VVY0fV=1000, VVJA7R=30, VV4xuv=30):
  MenuList.__init__(self, list, VVTCfu, eListboxPythonMultiContent)
  self.VVeZLi  = VVeZLi
  self.VVvyHf    = VVvyHf
  self.VV5lGq  = VV5lGq
  self.VVgstT  = VVgstT
  self.VVo77b   = VVo77b
  self.VVi3fw   = VVi3fw or []
  self.VVHAIx   = VVHAIx or []
  self.isTop     = isTop
  self.additional_extensions = VVWOzn
  self.VVY0fV    = VVY0fV
  self.VVJA7R    = VVJA7R
  self.VV4xuv    = VV4xuv
  self.EXTENSIONS    = CCuwo1.VVTrvd()
  self.VVTjE0   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFy2pz("#11ff4444")
  self.l.setFont(0, gFont(VVoHbv, self.VVJA7R))
  self.l.setItemHeight(self.VV4xuv)
  self.png_mem   = CCuwo1.VVr2ko("mem")
  self.png_usb   = CCuwo1.VVr2ko("usb")
  self.png_fil   = CCuwo1.VVr2ko("fil")
  self.png_dir   = CCuwo1.VVr2ko("dir")
  self.png_dirup   = CCuwo1.VVr2ko("dirup")
  self.png_srv   = CCuwo1.VVr2ko("srv")
  self.png_slwfil   = CCuwo1.VVr2ko("slwfil")
  self.png_slbfil   = CCuwo1.VVr2ko("slbfil")
  self.png_slwdir   = CCuwo1.VVr2ko("slwdir")
  self.VVUE89()
  self.VVRQxi(directory)
 @staticmethod
 def VVr2ko(category):
  return LoadPixmap("%s%s.png" % (VVV9bl, category), getDesktop(0))
 @staticmethod
 def VVTrvd():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVwUya(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFjJ1n(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFivHt(" -> " , VVMdMA) + FFivHt(os.readlink(path), VVd7n9)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV4xuv + 10, 0, self.VVY0fV, self.VV4xuv, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVmpKX: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV4xuv-4, self.VV4xuv-4, png, None, None, VVmpKX))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV4xuv-4, self.VV4xuv-4, png, None, None))
  return tableRow
 def VVvf1u(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVUE89(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVGEUM(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVt2RR(self, file):
  if os.path.realpath(file) == file:
   return self.VVGEUM(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVGEUM(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVGEUM(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVMdXI(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVv10h(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVd9i6(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVv10h(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVv10h(self, row, bg):
  if self.VVAtzj(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVAtzj(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVHkm8, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVaV8A:
    if   VVQrwB           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVIdz3(self):
  return self.VVAtzj(self.list[self.l.getCurrentSelectionIndex()])
 def VVQO1n(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVK67u(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVRQxi(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VV5lGq:
    self.current_mountpoint = self.VVt2RR(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VV5lGq:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVHAIx and not self.VVK67u(path, self.VVi3fw):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVwUya(name=p.description, absolute=path, isDir=True, typ=self.VVEs3R, png=png))
    path = "/"
    if path not in self.VVHAIx and not self.VVK67u(path, self.VVi3fw):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVwUya(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVDWkl, png=self.png_mem))
  elif self.VVo77b:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVTjE0 = eServiceCenter.getInstance()
   list = VVTjE0.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVeZLi and not self.isTop:
   if directory == self.current_mountpoint and self.VV5lGq:
    self.list.append(self.VVwUya(name=self.VVtV53, absolute=None, isDir=True, typ=self.VVBj9M, png=self.png_dirup))
   elif (directory != "/") and not (self.VVHAIx and self.VVGEUM(directory) in self.VVHAIx):
    self.list.append(self.VVwUya(name=self.VVYIiH, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VV0hI4, png=self.png_dirup))
  if self.VVeZLi:
   for x in directories:
    if not (self.VVHAIx and self.VVGEUM(x) in self.VVHAIx) and not self.VVK67u(x, self.VVi3fw):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVwUya(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFjJ1n(x)) else self.VVaV8A, png=png))
  if self.VVvyHf:
   for x in files:
    if self.VVo77b:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFivHt(" -> " , VVMdMA) + FFivHt(target, VVd7n9)
       else:
        png = self.png_slbfil
        name += FFivHt(" -> " , VVMdMA) + FFivHt(target, VVHEBa)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVvf1u(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVV9bl, category))
    if (self.VVgstT is None) or iCompile(self.VVgstT[0], flags=self.VVgstT[1]).search(path):
     self.list.append(self.VVwUya(name=name, absolute=x , isDir=False, typ=self.VVHkm8, png=png))
  if self.VV5lGq and len(self.list) == 0:
   self.list.append(self.VVwUya(name=FFivHt("No USB connected", VVrVS3), absolute=None, isDir=False, typ=self.VVEJD9, png=self.png_usb))
  self.l.setList(self.list)
  self.VVEZQN()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVcOn2(self):
  return self.current_directory
 def VV9idc(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVwJLZ(self):
  return self.VVOl7X() and self.VVcOn2()
 def VVOl7X(self):
  return self.list[0][1][7] in (self.VVtV53, self.VVYIiH)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVRQxi(self.getSelection()[0], self.current_directory)
 def VV1oIL(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV5wVQ)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV5wVQ)
 def VV5wVQ(self, action, device):
  self.VVUE89()
  if self.current_directory is None:
   self.VVtTbd()
 def VVtTbd(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVRQxi(self.current_directory, self.VV1oIL())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VV2RKo(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VV1Wzx : nameAlpMode, nameAlpTxt = self.VVurcY, sZA
  else       : nameAlpMode, nameAlpTxt = self.VV1Wzx, sAZ
  if mode == self.VVXMyk : nameNumMode, nameNumTxt = self.VVUmjm, s90
  else       : nameNumMode, nameNumTxt = self.VVXMyk, s09
  if mode == self.VVF5eW : dateMode, dateTxt = self.VVZezc, sON
  else       : dateMode, dateTxt = self.VVF5eW, sNO
  if mode == self.VV3sD9 : typeMode, typeTxt = self.VVfmXr, sZA
  else       : typeMode, typeTxt = self.VV3sD9, sAZ
  if   mode in (self.VV1Wzx, self.VVurcY): txt = "Name (%s)" % (sAZ if mode == self.VV1Wzx else sZA)
  elif mode in (self.VVXMyk, self.VVUmjm): txt = "Name (%s)" % (s09 if mode == self.VV1Wzx else s90)
  elif mode in (self.VVF5eW, self.VVZezc): txt = "Date (%s)" % (sNO if mode == self.VVF5eW else sON)
  elif mode in (self.VV3sD9, self.VVfmXr): txt = "Type (%s)" % (sAZ if mode == self.VV3sD9 else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVEZQN(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFH7ga(CFG.browserSortMode, mode)
   FFH7ga(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVOl7X() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VV1Wzx, self.VVurcY):
    rev = True if mode == self.VVurcY else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVXMyk, self.VVUmjm):
    rev = True if mode == self.VVUmjm else False
    self.list = sorted(self.list[item0:], key=FFbRsK(BF(self.VVsybY, isMix, rev)), reverse=rev)
   elif mode in (self.VVF5eW, self.VVZezc):
    rev = True if mode == self.VVZezc else False
    self.list = sorted(self.list[item0:], key=FFbRsK(BF(self.VV6bhQ, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVfmXr else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVsybY(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFDjgW(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFYrpL(dir2, dir1) or FFDjgW(name1, name2)
 def VV6bhQ(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFYrpL(stat2.st_ctime, stat1.st_ctime)
    else : return FFYrpL(dir2, dir1) or FFYrpL(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCNJZ7(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFAm4L(VVWDEH, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVX3UR   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVontS(defFG, "#00FFFFFF")
  self.defBG   = self.VVontS(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFNG7m(self, self.Title)
  self["keyRed"].show()
  FFTBJT(self["keyGreen"] , "< > Transp.")
  FFTBJT(self["keyYellow"], "Foreground")
  FFTBJT(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVHpCt     ,
   "green"   : self.VVHpCt     ,
   "yellow"  : BF(self.VVlCc1, False)  ,
   "blue"   : BF(self.VVlCc1, True)  ,
   "up"   : self.VV7SnD       ,
   "down"   : self.VValPP      ,
   "left"   : self.VVSzgb      ,
   "right"   : self.VV7Npu      ,
   "last"   : BF(self.VVPKd7, -5) ,
   "next"   : BF(self.VVPKd7, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVBp8x)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFvobF(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFvobF(self["keyRed"] , c)
  FFvobF(self["keyGreen"] , c)
  self.VVRsgz()
  self.VVcQCU()
  FFtB5m(self["myColorTst"], self.defFG)
  FFvobF(self["myColorTst"], self.defBG)
 def VVontS(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVcQCU(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVgh7d(0, 0)
     return
 def VVHpCt(self):
  self.close(self.defFG, self.defBG)
 def VV7SnD(self): self.VVgh7d(-1, 0)
 def VValPP(self): self.VVgh7d(1, 0)
 def VVSzgb(self): self.VVgh7d(0, -1)
 def VV7Npu(self): self.VVgh7d(0, 1)
 def VVgh7d(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVYx5N()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVGHXk()
 def VVRsgz(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVGHXk(self):
  color = self.VVYx5N()
  if self.isBgMode: FFvobF(self["myColorTst"], color)
  else   : FFtB5m(self["myColorTst"], color)
 def VVlCc1(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVRsgz()
   self.VVcQCU()
 def VVPKd7(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVgh7d(0, 0)
 def VVFyvM(self):
  return hex(self.transp)[2:].zfill(2)
 def VVYx5N(self):
  return ("#%s%s" % (self.VVFyvM(), self.colors[self.curRow][self.curCol])).upper()
class CCMW6L(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAm4L(VVfxqt, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFNG7m(self, title="%s%s%s" % (self.Title, " " * 10, FFivHt("Change values with Up , Down, < , 0 , >", VVrVS3)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVMcMd      ,
   "cancel" : self.VVIvk9      ,
   "info"  : self.VVX73N    ,
   "red"  : self.VV4bXr  ,
   "green"  : self.VVu0CC   ,
   "yellow" : BF(self.VVGTxP, 0)  ,
   "blue"  : self.VVRANn    ,
   "menu"  : self.VVjkeg      ,
   "left"  : self.VVSzgb      ,
   "right"  : self.VV7Npu      ,
   "last"  : self.VVWX8T     ,
   "next"  : self.VVWgIy     ,
   "0"   : self.VV5HHJ    ,
   "up"  : self.VV7SnD       ,
   "down"  : self.VValPP      ,
   "pageUp" : BF(self.VVywQR, True) ,
   "pageDown" : BF(self.VVywQR, False) ,
   "chanUp" : BF(self.VVywQR, True) ,
   "chanDown" : BF(self.VVywQR, False) ,
   "play"  : BF(self.VVy445, "pause")  ,
   "pause"  : BF(self.VVy445, "pause")  ,
   "playPause" : BF(self.VVy445, "pause")  ,
   "stop"  : BF(self.VVy445, "pause")  ,
   "audio"  : BF(self.VVy445, "audio")  ,
   "subtitle" : BF(self.VVy445, "subtitle") ,
   "rewind" : BF(self.VVy445, "rewind" ) ,
   "forward" : BF(self.VVy445, "forward" ) ,
   "rewindDm" : BF(self.VVy445, "rewindDm") ,
   "forwardDm" : BF(self.VVy445, "forwardDm")
  }, -1)
  self.VV1mUn()
  self.onShown.append(self.VVBp8x)
  self.onClose.append(self.VV7BfB)
 def VV1mUn(self):
  lst = []
  for fil in FFPCH3(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVN3E9:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVBp8x(self):
  self.onShown.remove(self.VVBp8x)
  FFzs4L(self)
  FFfavv(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VV6FFW()
  self.VVAb6x()
  self.VVvFU0()
 def VV7BfB(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVN7rN(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFvobF(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVquv1()
 def VV6FFW(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFvobF(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVMcMd(self):
  if self.settingShown:
   confItem = self.VV8hLX()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVgsyy = []
   if isinstance(lst[0], tuple):
    for item in lst: VVgsyy.append((item[1], item[0]))
   else:
    for item in lst: VVgsyy.append((item, item))
   VVyxPv = FFCO3u(self, self.VVeyGT, VVgsyy=VVgsyy, width=700, title=title, VVBBM8="#33221111", VVa80e="#33110011")
   VVyxPv.VVSIKM(confItem.getText())
  else:
   self.close("subtExit")
 def VVeyGT(self, item=None):
  if item:
   self.VV8hLX()[self.CursorPos].setValue(item)
   self.VVquv1()
   self.VVAb6x()
   self.VVqKsw(True)
 def VVIvk9(self):
  for confItem in self.VV8hLX():
   if confItem.isChanged():
    FFZnVu(self, BF(self.VV4PhQ, cbFnc=self.VVt3eM), "Save Changes ?", callBack_No=self.VV8dvj, title=self.Title)
    break
  else:
   self.VVt3eM()
 def VVt3eM(self):
   if self.settingShown: self.VV6FFW()
   else    : self.close("subtExit")
 def VVjkeg(self):
  if self.settingShown: self.VVjh4g()
  else    : self.VVN7rN()
 def VVSzgb(self): self.VVKdKC(-1)
 def VV7Npu(self): self.VVKdKC(1)
 def VVKdKC(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVnWhX()
   if pos == -1: ndx = self.VVSIQG(posVal)
   else  : ndx = self.VVdDzF(posVal)
   if   ndx < 0      : FFRB11(self, "Not found" , 500)
   elif ndx == 0      : FFRB11(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFRB11(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVpEOv(frmSec)
    if allow:
     self.VVGTxP(delay, True)
     self.VVqKsw(force=True)
     CCFzIL(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFRB11(self, "Delay out of range", 800)
 def VVywQR(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVy445(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVWX8T(self) : self.VVmyVN(5)
 def VVWgIy(self) : self.VVmyVN(6)
 def VV5HHJ(self) : self.VVmyVN(-1)
 def VV7SnD(self):
  if self.settingShown: self.VVmyVN(1)
  else    : self.VVywQR(True)
 def VValPP(self):
  if self.settingShown: self.VVmyVN(0)
  else    : self.VVywQR(False)
 def VVmyVN(self, direction):
  if self.settingShown:
   confItem = self.VV8hLX()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVquv1()
   self.VVAb6x()
   self.VVqKsw(True)
 def VV8hLX(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VV8dvj(self):
  for confItem in self.VV8hLX(): confItem.cancel()
  self.VVquv1()
  self.VVAb6x()
  self.VV6FFW()
 def VV4bXr(self):
  if self.settingShown:
   FFZnVu(self, self.VVWfE3, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVWfE3(self):
  for confItem in self.VV8hLX(): confItem.setValue(confItem.default)
  self.VV4PhQ()
  self.VVquv1()
  self.VVAb6x()
 def VVGTxP(self, delay, force=False):
  if self.settingShown or force:
   FFH7ga(CFG.subtDelaySec, delay)
   self.VVUKfK()
   self.VVquv1()
   self.VVAb6x()
   if self.settingShown:
    FFRB11(self, 'Reset to "0"', 800, isGrn=True)
 def VVu0CC(self):
  if self.settingShown:
   self.VV4PhQ()
   self.VV6FFW()
 def VV4PhQ(self, cbFnc=None):
  for confItem in self.VV8hLX(): confItem.save()
  configfile.save()
  self.VVUKfK()
  FFRB11(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVquv1(self):
  cfgLst = self.VV8hLX()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVAb6x(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFy505(path, fnt, isRepl=1)
  else:
   fnt = VVoHbv
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFGgcy(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFtB5m(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFvobF(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFGBnA(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFGgcy(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFTuEm()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFsH5e(self, winW, winH)
 def VVX73N(self):
  sp = "    "
  txt  = "%s\n"   % FFivHt("Subtitle File:", VVhb13)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFivHt("Subtitle Settings:", VVhb13)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVnWhX()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFz41A(frmSec1)
   time2 = FFz41A(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFivHt("Timing:", VVhb13)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFz41A(durVal)
   txt += sp + "Progress\t: %s\n" % FFz41A(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFivHt("Subtitle end reached.", VVgmAg)
  FFucjH(self, txt, title="Current Subtitle")
 def VVvFU0(self, path="", delay=0, enc=""):
  FF3LD6(self, BF(self.VVqwx6, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVqwx6(self, path="", delay=0, enc=""):
  FFRB11(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVcRj2(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVquv1()
     self.VVYxXz()
   else:
    path, delay, enc = CCMW6L.VV3LiZ(self)
    if path:
     self.VVvFU0(path=path, delay=delay, enc=enc)
    else:
     self.VVjh4g()
  except:
   pass
 def VVYxXz(self):
  posVal, durVal = self.VVnWhX()
  if self.VVRwAc(posVal):
   return
  CCMW6L.VVcq7D(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVqKsw)
  except:
   self.timerUpdate.callback.append(self.VVqKsw)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVr6g5)
  except:
   self.timerEndText.callback.append(self.VVr6g5)
  FFRB11(self, "Subtitle started", 700, isGrn=True)
 def VVRwAc(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCMW6L.VVuis8(self)
   FFAFdq(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVjh4g(self):
  c1, c2, c3, c4, c5 = "", VVhb13, VVVJaM, VVAQIK, VVgmAg
  VVgsyy = []
  VVgsyy.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVgsyy.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVgsyy.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVgsyy.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVgsyy.append(VVzHzv)
   VVgsyy.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVgsyy.append(VVzHzv)
   VVgsyy.append(("Help (Keys)"        , "help"  ))
  FFCO3u(self, self.VVVpdi, VVgsyy=VVgsyy, width=700, title='Find Subtitle ".srt" File', VVBBM8="#33221111", VVa80e="#33110011")
 def VVVpdi(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVVLYz(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVVLYz(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVPhzq, BF(CCxFIK, patternMode="srt", VVn9uf=sDir))
   elif item.startswith("sugSrt") : self.VVVLYz(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FF3LD6(self, BF(CCCXVP.VV3NXk, self, self.lastSubtFile, self.VVnDHB, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFRB11(self, "SRT File error", 1000)
   elif item == "disab":
    FFAFdq(CCMW6L.VVuis8(self))
    self.close("subtExit")
   elif item == "help"    : FF6duf(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVnDHB(self, item=None):
  if item:
   FF3LD6(self, BF(self.VVvFU0, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVPhzq(self, path):
  if path:
   FFH7ga(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVvFU0(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVVLYz(self, defSrt="", mode=0, coeff=0.25):
  FF3LD6(self, BF(self.VVvxWG, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVvxWG(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCMW6L.VVtHZf(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFIeeK('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFcVVX(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVmCsQ(srtList, coeff)
     if err:
      if self.settingShown: FFKCVv(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVX2QD = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFZsCH(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVX2QD.append((fName, Dir))
   VVkkpG  = ("Select"    , self.VVYwAn     , [])
   VVZAcA = self.VVr5zD
   VVPn7Q = (""     , self.VVHu2c       , [])
   VV1Zg1 = (""     , BF(self.VVsrHv, defSrt, False) , [])
   VV6LI6 = ("Find Current File" , BF(self.VVsrHv, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VVBL0l=widths, VVJA7R=28, VVkkpG=VVkkpG, VVZAcA=VVZAcA, VVPn7Q=VVPn7Q, VV1Zg1=VV1Zg1, VV6LI6=VV6LI6, lastFindConfigObj=CFG.lastFindSubtitle
     , VVBBM8="#11002222", VVa80e="#33001111", VVaOdk="#33001111", VVXZ9d="#11ffff00", VVlVSy="#11445544", VV3FyM="#22222222", VVf4Ym="#11002233")
  elif self.settingShown : FFKCVv(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVr5zD(self, VVgl66):
  VVgl66.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVHu2c(self, VVgl66, title, txt, colList):
  fName, Dir = colList
  FFucjH(VVgl66, "%s\n\n%s%s" % (FFivHt("Path:", VVhb13), Dir, fName), title=title)
 def VVsrHv(self, path, VVnkcm, VVgl66, title, txt, colList):
  for ndx, row in enumerate(VVgl66.VV3eCu()):
   if path == row[1].strip() + row[0].strip():
    VVgl66.VVICdA(ndx)
    break
  else:
   if VVnkcm:
    FFRB11(VVgl66, "Not in list !", 1000)
 def VVYwAn(self, VVgl66, title, txt, colList):
  VVgl66.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVvFU0(path=path)
 def VVmCsQ(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCje5B.VVlvmR(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCje5B.VVcWGv(evName, "en")[0] or evName
   lst, err = CCMW6L.VVjQTX(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVcRj2(self, path, enc=None):
  if enc and CCCXVP.VVjy6G(path, enc)      : enc = enc
  elif CCCXVP.VVjy6G(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFQfFR(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFHq6Y(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVb5PL(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVph5d(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVUKfK()
  return subtList, ""
 def VVph5d(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVb5PL(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVUKfK(self):
  path = CCMW6L.VVuis8(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVqKsw(self, force=False):
  posVal, durVal = self.VVnWhX()
  if self.VVRwAc(posVal):
   return
  curIndex = self.VV41GI(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVr6g5()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFtB5m(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVnWhX(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCC5bX.VV3wSN(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCje5B.VVlvmR(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VV41GI(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVSIQG(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVdDzF(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVr6g5(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFtB5m(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVRANn(self):
  FF3LD6(self, self.VVhkaB, title="Loading Lines ...")
 def VVhkaB(self):
  VVX2QD = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVX2QD.append((cap, FFz41A(frm), str(frm), firstLine))
  if VVX2QD:
   title = "Select Current Subtitle Line"
   VVfGJE  = self.VVii3B
   VVZAcA = self.VVphC9
   VVkkpG  = ("Select"   , self.VVx2nj , [title])
   VV6LI6 = ("Current Line" , self.VVrKhr , [True])
   VVH4Z8 = ("Reset Delay" , self.VVXNss , [])
   VVmhJa = ("New Delay"  , self.VVsaWy   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VV8zKo  = (CENTER , CENTER, CENTER , LEFT    )
   VVgl66 = FFyrIU(self, None, title=title, header=header, VVX3UR=VVX2QD, VV8zKo=VV8zKo, VVBL0l=widths, VVJA7R=28, VVfGJE=VVfGJE, VVZAcA=VVZAcA, VVkkpG=VVkkpG, VV6LI6=VV6LI6, VVH4Z8=VVH4Z8, VVmhJa=VVmhJa
          , VVBBM8="#33002222", VVa80e="#33001111", VVaOdk="#33110011", VVXZ9d="#11ffff00", VVlVSy="#0a334455", VV3FyM="#22222222", VVf4Ym="#33002233")
  else:
   FFKCVv(self, "Cannot read lines !", 2000)
 def VVii3B(self, VVgl66):
  self.subtLinesTable = VVgl66
  if CFG.subtDelaySec.getValue():
   VVgl66["keyYellow"].show()
   VVgl66["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVgl66["keyYellow"].hide()
  VVgl66["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFvobF(VVgl66["keyBlue"], "#22222222")
  VVgl66.VVz6sq(BF(self.VVDBN1, VVgl66))
  self.VVrKhr(VVgl66, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVJzFU)
  except:
   self.timerSubtLines.callback.append(self.VVJzFU)
  self.timerSubtLines.start(1000, False)
 def VVphC9(self, VVgl66):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVgl66.cancel()
 def VVJzFU(self):
  if self.subtLinesTable:
   VVgl66 = self.subtLinesTable
   posVal, durVal = self.VVnWhX()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VV41GI(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVgl66.VVdCEN(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVgl66.VV13vu(self.subtLinesTableNdx, row)
     row = VVgl66.VVdCEN(curIndex)
     row[0] = color + row[0]
     VVgl66.VV13vu(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVx2nj(self, VVgl66, Title):
  delay, color, allow = self.VVchqs(VVgl66)
  if allow:
   self.VVphC9(VVgl66)
   self.VVGTxP(delay, True)
  else:
   FFRB11(VVgl66, "Delay out of range", 1500)
 def VVrKhr(self, VVgl66, VVnkcm, onlyColor=False):
  if VVgl66:
   posVal, durVal = self.VVnWhX()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VV41GI(posVal)
    if curIndex > -1:
     VVgl66.VVICdA(curIndex)
    else:
     ndx = self.VVSIQG(posVal)
     if ndx > -1:
      VVgl66.VVICdA(ndx)
 def VVXNss(self, VVgl66, title, txt, colList):
  if VVgl66["keyYellow"].getVisible():
   self.VVGTxP(0, True)
   VVgl66["keyYellow"].hide()
   self.VVrKhr(VVgl66, False)
 def VVDBN1(self, VVgl66):
  delay, color, allow = self.VVchqs(VVgl66)
  VVgl66["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVchqs(self, VVgl66):
  lineTime = float(VVgl66.VVErbL()[2].strip())
  return self.VVpEOv(lineTime)
 def VVpEOv(self, lineTime):
  posVal, durVal = self.VVnWhX()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVL7a3
   else     : allow, color = False, VVgmAg
   delay = FFVUcd(val, -600, 600)
  return delay, color, allow
 def VVsaWy(self, VVgl66, title, txt, colList):
  pass
 @staticmethod
 def VVJFyy(SELF):
  path, delay, enc = CCMW6L.VV3LiZ(SELF)
  return True if path else False
 @staticmethod
 def VV3LiZ(SELF):
  path, delay, enc = CCMW6L.VVXSV6(SELF)
  if not path:
   path = CCMW6L.VV64ru(SELF)
  return path, delay, enc
 @staticmethod
 def VVXSV6(SELF):
  srtCfgPath = CCMW6L.VVuis8(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFHq6Y(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVuis8(SELF):
  fPath, fDir, fName = CCxFIK.VVscnA(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCje5B.VVlvmR(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiRis(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VV64ru(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCxFIK.VVscnA(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCMW6L.VVtHZf(SELF)
    bLst, err = CCMW6L.VVjQTX(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVtHZf(SELF):
  fPath, fDir, fName = CCxFIK.VVscnA(SELF)
  if pathExists(fDir):
   files = FFPCH3(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVjQTX(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVojGM():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVcq7D(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCMW6L.VVm4Z7()
 @staticmethod
 def VVm4Z7():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CC3EMw(ScrollLabel):
 def __init__(self, parentSELF, text="", VV81Cx=True):
  ScrollLabel.__init__(self, text)
  self.VV81Cx   = VV81Cx
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVakc1  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVJA7R    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVpNjo ,
   "green"   : self.VV8uuL ,
   "yellow"  : self.VVEnoz ,
   "blue"   : self.VVFFxe ,
   "up"   : self.VVW9G8   ,
   "down"   : self.VVAKEH  ,
   "left"   : self.VVW9G8   ,
   "right"   : self.VVAKEH  ,
   "last"   : BF(self.VVpUD0, 0) ,
   "0"    : BF(self.VVpUD0, 1) ,
   "next"   : BF(self.VVpUD0, 2) ,
   "pageUp"  : self.VVsnYY   ,
   "chanUp"  : self.VVsnYY   ,
   "pageDown"  : self.VV7psd   ,
   "chanDown"  : self.VV7psd
  }, -1)
 def VVZ8z1(self, isResizable=True, VVMeLm=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFtB5m(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFvobF(self.parentSELF["keyRedTop"], "#113A5365")
  FFzs4L(self.parentSELF, True)
  self.isResizable = isResizable
  if VVMeLm:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVJA7R  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFvobF(self, color)
 def VVnTh7(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VV4xuv  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VV4xuv)
  margin   = int(VV4xuv / 6)
  self.pageHeight = int(self.pageLines * VV4xuv)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVakc1 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVo301()
 def VVW9G8(self):
  if self.VVakc1 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVAKEH(self):
  if self.VVakc1 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVsnYY(self):
  self.setPos(0)
 def VV7psd(self):
  self.setPos(self.VVakc1-self.pageHeight)
 def VV2EWV(self):
  return self.VVakc1 <= self.pageHeight or self.curPos == self.VVakc1 - self.pageHeight
 def getText(self):
  return self.message
 def VVo301(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVakc1, 3))
   start = int((100 - vis) * self.curPos / (self.VVakc1 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVFq7T=VVnE8x):
  old_VV2EWV = self.VV2EWV()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVakc1 = self.long_text.calculateSize().height()
   if self.VV81Cx and self.VVakc1 > self.pageHeight:
    self.scrollbar.show()
    self.VVo301()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVakc1))
    self.VVakc1 = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVakc1))
   else:
    self.scrollbar.hide()
   if   VVFq7T == VVJKXb: self.setPos(0)
   elif VVFq7T == VVVykt : self.VV7psd()
   elif old_VV2EWV    : self.VV7psd()
 def appendText(self, text, VVFq7T=VVVykt):
  self.setText(self.message + str(text), VVFq7T=VVFq7T)
 def VVEnoz(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVzEnu(size)
 def VVFFxe(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVzEnu(size)
 def VV8uuL(self):
  self.VVzEnu(self.VVJA7R)
 def VVzEnu(self, VVJA7R):
  self.long_text.setFont(gFont(self.fontFamily, VVJA7R))
  self.setText(self.message, VVFq7T=VVnE8x)
  self.VVsIzd()
 def VVpUD0(self, align):
  self.long_text.setHAlign(align)
 def VVpNjo(self):
  VVgsyy = []
  VVgsyy.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Align Left" , "left" ))
  VVgsyy.append(("Align Center" , "center" ))
  VVgsyy.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVgsyy.append(VVzHzv)
   VVgsyy.append((FFivHt("Save to File", VVhb13), "save"))
  VVgsyy.append(VVzHzv)
  VVgsyy.append(("Keys (Shortcuts)", "help"))
  FFCO3u(self.parentSELF, self.VVMRw0, VVgsyy=VVgsyy, title="Text Option", width=500)
 def VVMRw0(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVpUD0(0)
   elif item == "center" : self.VVpUD0(1)
   elif item == "right" : self.VVpUD0(2)
   elif item == "save"  : self.VV3fso()
   elif item == "help"  : FF6duf(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VV3fso(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFZsCH(expPath), self.outputFileToSave, FFvXEJ())
   with open(outF, "w") as f:
    f.write(FFkgYM(self.message))
   FF5kkM(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FF2zEl(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVsIzd(self, minHeight=0):
  if self.isResizable:
   VV4xuv = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VV4xuv * (len(self.message.splitlines()) + 1))
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
