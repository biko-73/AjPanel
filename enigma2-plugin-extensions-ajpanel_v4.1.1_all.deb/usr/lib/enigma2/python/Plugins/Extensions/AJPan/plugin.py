import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger, ConfigSubList
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVE71u   = "v4.1.1"
VVkIic    = "19-02-2022"
EASY_MODE    = 0
VVVJct   = 0
VV47pg   = 0
VVy60U  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVsxXY  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVx8df    = "/media/usb/"
VVyTQa    = "/usr/share/enigma2/picon/"
VVrXSk   = "/etc/enigma2/"
VVCqQX  = "ajpanel_update_url"
VVd5St   = "AJPan"
VVWnkq    = "AUTO FIND"
VV78jn    = ""
VVEixg    = "Regular"
VVJwpo      = "-" * 80
VVIEqe    = ("-" * 100, )
VVZjBX    = ""
VV2IM6   = " && echo 'Successful' || echo 'Failed!'"
VVDxcD    = []
VVn6jj  = "Cannot continue (No Enough Memory) !"
VVz4Y7   = (None, "utf-8", "ISO8859-15", "ISO8859-7", "ISO8859-5", "ISO6937", "windows-1250", "windows-1252", "unicode_escape")
VVkBs8  = False
VVt4jw  = False
VVBJBx = False
VVxulX     = 0
VVi3pc    = 1
VVoKhm    = 2
VVV4Js   = 3
VVPtcs    = 4
VV0eWr    = 5
VVXzV5 = 6
VVEG99 = 7
VVTKnm  = 8
VVDhOp   = 9
VV5IWe   = 10
VVOlRK   = 11
VVZ4Z6  = 12
VVpjxY  = 13
VVjaS2    = 14
VVxZAL   = 15
VVbVWE   = 16
VVkeFs    = 17
VVEj4h  = 18
VVHE4T  = 15
VVLLcg   = 0
VVIFZO   = 1
VV3zRr   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=False)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVWnkq, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVyTQa, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVx8df, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
def FFhdPn():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV3kCD  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVCAvI = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV3kCD  : return 0
  elif VVCAvI : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVP5Kc = FFhdPn()
VVcP3M = VVLLOq = VVvqWy = VVCyLg = VVzNDT = VV4S6b = VVuV1K = VV106B = COLOR_CONS_BRIGHT_YELLOW = VV4E8E = VVhHzk = VVfDjZ = VVbwNy = ""
def FFqvDb()  : return FFSWpF()
def FF5Vvx(*args) : FFUkqn(True , *args)
def FFvaLj(*args): FFUkqn(False, *args)
def FFUkqn(addSep=True, *args):
 if VVVJct:
  txt  = (">>>> %s\n" % VVJwpo) if addSep else ""
  txt += ">>>> %s" % " , ".join(map(str, args))
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFf9SN(txt, isAppend=True, ignoreErr=False):
 if VVVJct:
  tm = FF56ER()
  err = ""
  if not ignoreErr:
   err = FFSWpF()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF5Vvx(err)
  FF5Vvx("Output Log File : %s" % fileName)
def FFSWpF():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF56ER()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFiNSP():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVDxcD = []
def FFFARc(win):
 global VVDxcD
 if not win in VVDxcD:
  VVDxcD.append(win)
def FF2wr6(*args):
 global VVDxcD
 for win in VVDxcD:
  try:
   win.close()
  except:
   pass
 VVDxcD = []
def FF1f4x():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVgEBF = FF1f4x()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFahGi()     : return PluginDescriptor(fnc=FFKRUJ, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFjtXj()      : return getDescriptor(FF5c55   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFDdKb()       : return getDescriptor(FFvREL  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFPcz0()   : return getDescriptor(FFRD50 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFXUVs(): return getDescriptor(FFVqLk , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFlFM1()  : return getDescriptor(FF93TZ  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFmm6t()     : return getDescriptor(FFHrRR , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFjtXj() , FFDdKb() , FFahGi() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFPcz0())
  result.append(FFXUVs())
  result.append(FFlFM1())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFmm6t())
 return result
def FFKRUJ(reason, **kwargs):
 if reason == 0:
  FF828x()
  if "session" in kwargs:
   session = kwargs["session"]
   FFgDon(session)
   CCA6xu(session)
def FFvREL(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF5c55, PLUGIN_NAME, 45)]
 else:
  return []
def FF5c55(session, **kwargs):
 session.open(Main_Menu)
def FFRD50(session, **kwargs):
 session.open(CCpqJe)
def FFVqLk(session, **kwargs):
 FFgVOc(session, isFromSession=True)
def FF93TZ(session, **kwargs):
 session.open(CCy3Ly)
def FFHrRR(session, **kwargs):
 session.open(CCdLyC, fncMode=CCdLyC.VVFrdh)
def FFC7fb():
 FFD4Z7(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFPcz0(), FFXUVs(), FFlFM1() ])
 FFD4Z7(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFmm6t() ])
def FFD4Z7(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVZ5GS = None
def FF828x():
 try:
  global VVZ5GS
  if VVZ5GS is None:
   VVZ5GS    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFXy0m
  ChannelContextMenu.FF2B1D = FF2B1D
 except:
  pass
def FFXy0m(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVZ5GS(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FF2B1D, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FF2B1D, title1, csel, isFind=True))))
def FF2B1D(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFLN5X(refCode)
 except:
  pass
 self.session.open(boundFunction(CCM9We, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFgDon(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FF6EcM, session, "lok")
 hk.actions['longCancel'] = boundFunction(FF6EcM, session, "lesc")
 hk.actions['longRed']  = boundFunction(FF6EcM, session, "lred")
def FF6EcM(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFgVOc(session, isFromSession=True)
def FFBDfs(SELF, title="", addLabel=False, addScrollLabel=False, VVWaOb=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFChu1()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCM8fv(SELF)
 if VVWaOb:
  SELF["myMenu"] = MenuList(VVWaOb)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVAJFV        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFiDNM(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFM3kY, SELF, "0") ,
  "1"    : boundFunction(FFM3kY, SELF, "1") ,
  "2"    : boundFunction(FFM3kY, SELF, "2") ,
  "3"    : boundFunction(FFM3kY, SELF, "3") ,
  "4"    : boundFunction(FFM3kY, SELF, "4") ,
  "5"    : boundFunction(FFM3kY, SELF, "5") ,
  "6"    : boundFunction(FFM3kY, SELF, "6") ,
  "7"    : boundFunction(FFM3kY, SELF, "7") ,
  "8"    : boundFunction(FFM3kY, SELF, "8") ,
  "9"    : boundFunction(FFM3kY, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFhJCc, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFM3kY(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVbwNy:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVbwNy + SELF.keyPressed + VVLLOq)
    txt = VVLLOq + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFU7uG(SELF, txt)
def FFhJCc(SELF, tableObj, colNum):
 FFU7uG(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVuEmH(i)
     break
 except:
  pass
def FFeWTY(SELF, setMenuAction=True):
 if setMenuAction:
  global VVZjBX
  VVZjBX = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFChu1():
 return ("  %s" % VVZjBX)
def FFOV9c(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF0IQR(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFJrVj(color):
 return parseColor(color).argb()
def FFnGw1(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFIRRt(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFiulc(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF8tq9(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVbwNy)
 else:
  return ""
def FFaT5W(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVJwpo, word, VVJwpo, VVbwNy)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVJwpo, word, VVJwpo)
def FFKY60(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVbwNy
def FFaVi1(color):
 if color: return "echo -e '%s' %s;" % (VVJwpo, FF8tq9(VVJwpo, VV106B))
 else : return "echo -e '%s';" % VVJwpo
def FFMugM(title, color):
 title = "%s\n%s\n%s\n" % (VVJwpo, title, VVJwpo)
 return FFKY60(title, color)
def FF0JHQ(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFSlzW(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFewwi(callBackFunction):
 tCons = CC1uI6()
 tCons.ePopen("echo", boundFunction(FFKIee, callBackFunction))
def FFKIee(callBackFunction, result, retval):
 callBackFunction()
def FFJ3IJ(SELF, fnc, title="Processing ...", clearMsg=True):
 FFU7uG(SELF, title)
 tCons = CC1uI6()
 tCons.ePopen("echo", boundFunction(FFsMNS, SELF, fnc, clearMsg))
def FFsMNS(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFU7uG(SELF)
def FFNh54(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVn6jj
  else       : return ""
def FF8xGt(cmd):
 txt = FFNh54(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFKH1d(cmd):
 lines = FF8xGt(cmd)
 if lines: return lines[0]
 else : return ""
def FFU8Qj(SELF, cmd):
 lines = FF8xGt(cmd)
 VVuwbt = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVuwbt.append((key, val))
  elif line:
   VVuwbt.append((line, ""))
 if VVuwbt:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFemUu(SELF, None, header=header, VVeBho=VVuwbt, VVEHj0=widths, VVZWCz=28)
 else:
  FFfB0P(SELF, cmd)
def FFfB0P(    SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, VVQ9hK=True, VVJQke=VVIFZO, **kwargs)
def FFDb10(  SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, **kwargs)
def FFOKKC(   SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, VVSTOG=True, VV3MYb=True, VVJQke=VVIFZO, **kwargs)
def FFvO2C(  SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, VVSTOG=True, VV3MYb=True, VVJQke=VV3zRr, **kwargs)
def FFsUMt(  SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, VVYmU2=True , **kwargs)
def FF3OqS( SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, VVQ59H=True   , **kwargs)
def FF818p( SELF, cmd, **kwargs): SELF.session.open(CCYWEZ, VVuqfs=cmd, VVGMOB=True  , **kwargs)
def FFFaNy(cmd):
 return cmd + " > /dev/null 2>&1"
def FF35kh():
 return " > /dev/null 2>&1"
def FFLz4T(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFcd50(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FF3RNN():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFKH1d(cmd)
VV2iC7     = 0
VVvw0t      = 1
VVoeQ8   = 2
VVKo8d      = 3
VVB5Tr      = 4
VVnIxU     = 5
VVlyKc     = 6
VV89BS = 7
VVs9RN = 8
VVq23Q = 9
VVqPlm  = 10
VVKAAT     = 11
VVjkH2  = 12
VVnwKT  = 13
def FFkwB2(parmNum, grepTxt):
 if   parmNum == VV2iC7  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVvw0t   : param = ["list"   , "apt list" ]
 elif parmNum == VVoeQ8: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FF3RNN()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFNOBr(parmNum, package):
 if   parmNum == VVKo8d      : param = ["info"      , "apt show"         ]
 elif parmNum == VVB5Tr      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVnIxU     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVlyKc     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VV89BS : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVs9RN : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVq23Q : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVqPlm  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVKAAT     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVjkH2  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVnwKT  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF3RNN()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFS5rX():
 result = FFKH1d("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFNOBr(VVlyKc , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFFaNy("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFFaNy("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF8tq9(failed1, VV106B))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF8tq9(failed2, VV106B))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF8tq9(failed3, VVvqWy))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFBYZw(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFNOBr(VVlyKc , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFFaNy("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF8tq9(failed1, VV106B))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF8tq9(failed2, VVvqWy))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFeI9s(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFFaNy('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFFaNy("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFGKC4(path, maxSize=-1):
 txt = ""
 for enc in VVz4Y7:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFcG5u(path, keepends=False, maxSize=-1):
 lines = FFGKC4(path, maxSize)
 return lines.splitlines(keepends)
def FFpIfw(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFfblo(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFcG5u(path, maxSize=maxSize)
  if lines: FFx6I1(SELF, lines, title=title, VVJQke=VVIFZO)
  else : FFoblU(SELF, path, title=title)
 else:
  FFl2xw(SELF, path, title)
def FF2Z5t(SELF, path, title):
 if fileExists(path):
  txt = FFGKC4(path)
  txt = txt.replace("#W#", VVbwNy)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVLLOq)
  txt = txt.replace("#C#", VV4E8E)
  txt = txt.replace("#P#", VVCyLg)
  FFx6I1(SELF, txt, title=title)
 else:
  FFl2xw(SELF, path, title)
def FFiPeJ(path, SELF=None):
 txt = ""
 for enc in VVz4Y7:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return enc
  except:
   pass
 if SELF:
  FF23yv(SELF, "Cannot detect file encoding for:\n\n%s" % path)
 return -1
def FFfihj(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFb1OU(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF86q9(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFVqav(parent)
 else    : return FFMS0I(parent)
def FFfblo(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFVqav(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFMS0I(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFDsDn():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVy60U)
 paths.append(VVy60U.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFb1OU(ba)
 for p in list:
  p = ba + p + VVy60U
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVd5St, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVy60U, VVd5St , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVYZN0, VVGuqQ = FFDsDn()
def FFlr2o():
 def VVmTGh(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVWnkq and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVWnkq)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVWnkq
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVmTGh(CFG.MovieDownloadPath, CCuRcG.VVqbxo())
 VVo2rb   = VVmTGh(CFG.backupPath, CCiWF9.VVbTow())
 VVuA9m   = VVmTGh(CFG.downloadedPackagesPath, t)
 VVlRmX  = VVmTGh(CFG.exportedTablesPath, t)
 VVhh0D  = VVmTGh(CFG.exportedPIconsPath, t)
 VVBIrn   = VVmTGh(CFG.packageOutputPath, t)
 global VVx8df
 VVx8df = FFVqav(CFG.backupPath.getValue())
 if VVo2rb or VVBIrn or VVuA9m or VVlRmX or VVhh0D or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVo2rb, VVBIrn, VVuA9m, VVlRmX, VVhh0D, oldIptvHostsPath, oldMovieDownloadPath
def FFEyqu(path):
 path = FFMS0I(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFjbda(SELF, pathList, tarFileName, addTimeStamp=True):
 VVeBho = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVeBho.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVeBho.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVeBho.append(path)
 if not VVeBho:
  FF23yv(SELF, "Files not found!")
 elif not pathExists(VVx8df):
  FF23yv(SELF, "Path not found!\n\n%s" % VVx8df)
 else:
  VVNE0V = FFVqav(VVx8df)
  tarFileName = "%s%s" % (VVNE0V, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFBQPI())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVeBho:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVJwpo
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF8tq9(tarFileName, VVuV1K))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF8tq9(failed, VVuV1K))
  cmd += "fi;"
  cmd +=  sep
  FFDb10(SELF, cmd)
def FFrRM6(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFMpsS(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFMpsS(SELF["keyInfo"], "info")
def FFMpsS(barObj, fName):
 path = "%s%s%s" % (VVGuqQ, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFJYru(SELF, title, VVl8kD, showGrnMsg=""):
 SELF.session.open(boundFunction(CCGHol, title=title, VVl8kD=VVl8kD, showGrnMsg=showGrnMsg))
def FFAVQ4(labelObj, VVl8kD):
 if VVl8kD and fileExists(VVl8kD):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVHDjF(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVHDjF)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVl8kD)
   return True
  except:
   pass
 return False
def FFMhop(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFzQfp(satNum)
  return satName
def FFzQfp(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFXG8g(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFMhop(val)
  else  : sat = FFzQfp(val)
 return sat
def FFUXWI(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFMhop(num)
 except:
  pass
 return sat
def FFRfrW(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFpoqY(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFeTHY(info, iServiceInformation.sServiceref)
   prov = FFeTHY(info, iServiceInformation.sProvider)
   state = str(FFeTHY(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFqdX4(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFlKLF(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFeTHY(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFEfck(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFLN5X(refCode):
 info = FFKUsY(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFxPSj(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFQwIx(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFKUsY(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVmOHg = eServiceCenter.getInstance()
  if VVmOHg:
   info = VVmOHg.info(service)
 return info
def FFFZZb(SELF, refCode, VVYxnj=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFYtlH(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVYxnj:
   FFgVOc(SELF, isFromSession)
 try:
  VVzHgb = InfoBar.instance
  if VVzHgb:
   VV8sHQ = VVzHgb.servicelist
   if VV8sHQ:
    servRef = eServiceReference(refCode)
    VV8sHQ.saveChannel(servRef)
 except:
  pass
def FFYtlH(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCG19q()
    if pr.VVoiqq(refCode, chName, decodedUrl, iptvRef):
     pr.VV0thB(SELF, isFromSession)
def FFqdX4(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFUVTe(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFVS8N(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FF50RV(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFlKLF(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFmq3z(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFiQxL(userBfile):
 txt = ""
 bFile = VVrXSk + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVrXSk + userBfile):
  fTxt = FFGKC4(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFKH1d('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFmq3z(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFob6x(url):
 if iQuote : return iQuote(url)
 else  : return url
def FF7l1d(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFkCIh(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFLnw8(txt):
 try:
  return FF7l1d(FFkCIh(txt)) == txt
 except:
  return False
def FFgVOc(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCjjWk, isFromExternal=isFromSession)
 else      : FFAQKH(session, reopen=True, isFromExternal=isFromSession)
def FFAQKH(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFAQKH, session, isFromExternal=isFromExternal), boundFunction(CCMRdH, isFromExternal=isFromExternal))
  except:
   try:
    FFaQsI(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FF6jl4(refCode):
 tp = CC38xH()
 if tp.VVtYBX(refCode) : return True
 else        : return False
def FFlSYx(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FF0eVO():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF6YXr():
 VVzHgb = InfoBar.instance
 if VVzHgb:
  VV8sHQ = VVzHgb.servicelist
  if VV8sHQ:
   return VV8sHQ.getBouquetList()
 return None
def FFNtMz():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FF9Obv():
 path = FFNtMz()
 if path:
  txt = FFGKC4(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FF9t4m():
 return FFx460(InfoBar.instance.servicelist.getRoot())
def FFx460(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVmOHg = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVmOHg.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFcN34():
 VV7Z6a = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVezZF = list(VV7Z6a)
 return VVezZF, VV7Z6a
def FFMA4x():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFyEMn(session, VVUVvk):
 VVL92J, VVIgSe, VVqp0R, camCommand = FFYhhj()
 if VVIgSe:
  runLog = False
  if   VVUVvk == CCMbjU.VVCk9O : runLog = True
  elif VVUVvk == CCMbjU.VVFBym : runLog = True
  elif not VVqp0R          : FFaQsI(session, message="SoftCam not started yet!")
  elif fileExists(VVqp0R)        : runLog = True
  else             : FFaQsI(session, message="File not found !\n\n%s" % VVqp0R)
  if runLog:
   session.open(boundFunction(CCMbjU, VVL92J=VVL92J, VVIgSe=VVIgSe, VVqp0R=VVqp0R, VVUVvk=VVUVvk))
 else:
  FFaQsI(session, message="No active OSCam/NCam found !", title="Live Log")
def FFYhhj():
 VVL92J = "/etc/tuxbox/config/"
 VVIgSe = None
 VVqp0R  = None
 camCommand = FFKH1d("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVIgSe = "oscam"
 elif "ncam"  in camCommand : VVIgSe = "ncam"
 if VVIgSe:
  path = FFKH1d(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFVqav(path)
  if pathExists(path):
   VVL92J = path
  tFile = VVL92J + VVIgSe + ".conf"
  tFile = FFKH1d("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVqp0R = tFile
 return VVL92J, VVIgSe, VVqp0R, camCommand
def FFv8BC(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFejuP():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFBQPI():
 return FFejuP().replace(" ", "_").replace("-", "").replace(":", "")
def FFSof4(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF56ER():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFmoGG(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCy3Ly.VV8ofO(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCy3Ly.VVQdXE_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFFaNy("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFyl8X(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFOfUP(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VV5gI0 = 0
def FFjrFq():
 global VV5gI0
 VV5gI0 = iTime()
def FFdmHT():
 FF5Vvx(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VV5gI0).rstrip("0").rstrip("."))
def FFuW4T(SELF, message, title=""):
 SELF.session.open(boundFunction(CCg3Sc, title=title, message=message, VVMjH7=True))
def FFx6I1(SELF, message, title="", VVJQke=VVIFZO, **kwargs):
 SELF.session.open(boundFunction(CCg3Sc, title=title, message=message, VVJQke=VVJQke, **kwargs))
def FF23yv(SELF, message, title="")  : FFaQsI(SELF.session, message, title)
def FFl2xw(SELF, path, title="") : FFaQsI(SELF.session, "File not found !\n\n%s" % path, title)
def FFoblU(SELF, path, title="") : FFaQsI(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF5N91(SELF, title="")  : FFaQsI(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFaQsI(session, message, title="") : session.open(boundFunction(CCCkN8, title=title, message=message))
def FF3PZZ(SELF, VVn4v8, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVn4v8, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVn4v8, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVn4v8, boundFunction(CCQB6F, title=title, message=message, VVfP6g=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF23yv(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFyVJ3(SELF, callBack_Yes, VVB4L8, callBack_No=None, title="", VV29o7=False, VVOlvi=True):
 SELF.session.openWithCallback(boundFunction(FFRvQ9, callBack_Yes, callBack_No)
        , boundFunction(CCWlfT, title=title, VVB4L8=VVB4L8, VVOlvi=VVOlvi, VV29o7=VV29o7))
def FFRvQ9(callBack_Yes, callBack_No, FFyVJ3ed):
 if FFyVJ3ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFU7uG(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFIRRt(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFOhLA(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFJrZA(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVexmr = eTimer()
def FFOhLA(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFBhXz, SELF))
 fnc = boundFunction(FFBhXz, SELF)
 try:
  t = VVexmr.timeout.connect(fnc)
 except:
  VVexmr.callback.append(fnc)
 VVexmr.start(milliSeconds, 1)
def FFBhXz(SELF):
 VVexmr.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFemUu(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCQc3e, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCQc3e, **kwargs))
  FFFARc(win)
  return win
 except:
  return None
def FFg6MQ(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCMyIz, **kwargs))
 FFFARc(win)
 return win
def FFEjmz(SELF, **kwargs):
 SELF.session.open(CCdLyC, **kwargs)
def FFkJyH(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFlEQt(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVEixg, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFeGgr(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFlEQt(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFjdS6():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFbWyc(VVZWCz):
 screenSize  = FFjdS6()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVZWCz)
 return bodyFontSize
def FFtbg0(VVZWCz, extraSpace):
 font = gFont(VVEixg, VVZWCz)
 VVEvPQ = fontRenderClass.getInstance().getLineHeight(font) or (VVZWCz * 1.25)
 return int(VVEvPQ + VVEvPQ * extraSpace)
def FFZ0sl(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVEixg
def FFDOid(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFjdS6()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVHE4T)
 bodyFontStr  = 'font="%s;%d"' % (VVEixg, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFtbg0(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVEixg, titleFontSize, alignLeftCenter)
 if winType == VVxulX or winType == VVi3pc:
  if winType == VVi3pc : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVEj4h:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVjaS2:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFuW4TL = b2Left2 + timeW + marginLeft
  FFuW4TW = b2Left3 - marginLeft - FFuW4TL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFuW4TL  , b2Top, FFuW4TW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="1000" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVxZAL:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVPtcs:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVoKhm:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVV4Js:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVEixg, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVEixg, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV5IWe:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFuW4TH = int(bodyH * 0.5)
  inpTop = bodyTop + FFuW4TH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFuW4TH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVEixg, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVEixg, mapF, alignCenter)
 elif winType == VVOlRK:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVZ4Z6:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVEixg, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVbVWE:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVEixg, fontH, alignCenter)
 elif winType == VVpjxY:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVEixg, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVEixg, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVEixg, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVkeFs:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVEG99 : align = alignLeftCenter
  elif winType == VVXzV5 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVDhOp:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VV0eWr:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVXzV5:
    fontStr = 'font="%s;%d"' % (FFZ0sl("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVZWCz = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVEixg, VVZWCz, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVTMiH = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVEixg, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVTMiH[i], VVEixg, barFont, alignCenter)
   left += btnW + gap
 if winType == VVXzV5:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVTMiH = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVTMiH[i], VVEixg, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVWaOb = []
  if VV47pg:
   VVWaOb.append(("-- MY TEST --"    , "myTest"   ))
  VVWaOb.append(("  File Manager"     , "FileManager"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("  Services/Channels"    , "ChannelsTools" ))
  VVWaOb.append(("  IPTV"       , "IptvTools"  ))
  VVWaOb.append(("  PIcons"       , "PIconsTools"  ))
  VVWaOb.append(("  SoftCam"      , "SoftCam"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("  Plugins"      , "PluginsTools" ))
  VVWaOb.append(("  Terminal"      , "Terminal"  ))
  VVWaOb.append(("  Backup & Restore"    , "BackupRestore" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("  Date/Time"      , "Date_Time"  ))
  VVWaOb.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVWaOb)
  FFBDfs(self, VVWaOb=VVWaOb)
  FFOV9c(self["keyRed"] , "Exit")
  FFOV9c(self["keyGreen"] , "Settings")
  FFOV9c(self["keyYellow"], "Dev. Info.")
  FFOV9c(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVK8zK       ,
   "yellow"  : self.VVZwxv       ,
   "blue"   : self.VVeWzL       ,
   "info"   : self.VVeWzL       ,
   "last"   : self.VV3t96      ,
   "next"   : self.VVZ0yJ       ,
   "menu"   : self.VVnipw     ,
   "0"    : boundFunction(self.VVyiJa, 0) ,
   "1"    : boundFunction(self.VV31gb, 1)   ,
   "2"    : boundFunction(self.VV31gb, 2)   ,
   "3"    : boundFunction(self.VV31gb, 3)   ,
   "4"    : boundFunction(self.VV31gb, 4)   ,
   "5"    : boundFunction(self.VV31gb, 5)   ,
   "6"    : boundFunction(self.VV31gb, 6)   ,
   "7"    : boundFunction(self.VV31gb, 7)   ,
   "8"    : boundFunction(self.VV31gb, 8)   ,
   "9"    : boundFunction(self.VV31gb, 9)
  })
  self.onShown.append(self.VVKQSI)
  self.onClose.append(self.onExit)
  global VVkBs8, VVt4jw, VVBJBx
  VVkBs8 = VVt4jw = VVBJBx = False
 def VVAJFV(self):
  item = FFeWTY(self)
  self.VV31gb(item)
 def VV31gb(self, item):
  if item is not None:
   if   item == "myTest"     : self.VV4Aev()
   elif item in ("FileManager"  , 1) : self.session.open(CCpqJe)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCpfVT)
   elif item in ("IptvTools"  , 3) : self.session.open(CCy3Ly)
   elif item in ("PIconsTools"  , 4) : self.VVCfYQ()
   elif item in ("SoftCam"   , 5) : self.session.open(CCz0kj)
   elif item in ("PluginsTools" , 6) : self.session.open(CCf3vw)
   elif item in ("Terminal"  , 7) : self.session.open(CCq3PM)
   elif item in ("BackupRestore" , 8) : self.session.open(CCeNUw)
   elif item in ("Date_Time"  , 9) : self.session.open(CCT258)
   elif item in ("CheckInternet" , 10) : self.session.open(CCR6Pe)
   else         : self.close()
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
  FFkJyH(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVE71u)
  self["myTitle"].setText(title)
  VVo2rb, VVBIrn, VVuA9m, VVlRmX, VVhh0D, oldIptvHostsPath, oldMovieDownloadPath = FFlr2o()
  self.VV2PiK()
  if VVo2rb or VVBIrn or VVuA9m or VVlRmX or VVhh0D or oldIptvHostsPath or oldMovieDownloadPath:
   VVOCz2 = lambda path, subj: "%s:\n%s\n\n" % (subj, FFKY60(path, VVvqWy)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVOCz2(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVOCz2(VVo2rb   , "Backup/Restore Path"    )
   txt += VVOCz2(VVBIrn  , "Created Package Files (IPK/DEB)" )
   txt += VVOCz2(VVuA9m  , "Download Packages (from feeds)" )
   txt += VVOCz2(VVlRmX , "Exported Tables"     )
   txt += VVOCz2(VVhh0D , "Exported PIcons"     )
   txt += VVOCz2(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFx6I1(self, txt, title="Settings Paths")
  if (EASY_MODE or VVVJct or VV47pg):
   FFIRRt(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFU7uG(self, "Welcome", 300)
  FFewwi(boundFunction(self.VVenGt, title))
 def VVenGt(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCiWF9.VVCPAO()
   if url:
    newWebVer = CCiWF9.VVNGK5(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFFaNy("rm /tmp/ajpanel*"))
  global VVkBs8, VVt4jw, VVBJBx
  VVkBs8 = VVt4jw = VVBJBx = False
 def VVyiJa(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VVkBs8, VVBJBx
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VVkBs8 = True
    FFIRRt(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVBJBx = True
 def VVZ0yJ(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVt4jw
   VVt4jw = True
   FFIRRt(self["myTitle"], "#dd5588")
 def VV3t96(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFU7uG(self, txt, 2000, isGrn=ok)
 def VVCfYQ(self):
  found = False
  pPath = CCgMHO.VV4aVy()
  if pathExists(pPath):
   for fName, fType in CCgMHO.VVl27c(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCgMHO)
  else:
   VVWaOb = []
   VVWaOb.append(("PIcons Manager" , "CCgMHO" ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(CCgMHO.VV0GRV())
   VVWaOb.append(VVIEqe)
   VVWaOb += CCgMHO.VVwS02()
   FFg6MQ(self, self.VVyLtj, VVWaOb=VVWaOb)
 def VVyLtj(self, item=None):
  if item:
   if   item == "CCgMHO"   : self.session.open(CCgMHO)
   elif item == "VVQPtU"  : CCgMHO.VVQPtU(self)
   elif item == "VVgwj9"  : CCgMHO.VVgwj9(self)
   elif item == "findPiconBrokenSymLinks" : CCgMHO.VVSwgt(self, True)
   elif item == "FindAllBrokenSymLinks" : CCgMHO.VVSwgt(self, False)
 def VVK8zK(self):
  self.session.open(CCiWF9)
 def VVZwxv(self):
  self.session.open(CCR7pk)
 def VVeWzL(self):
  changeLogFile = VVGuqQ + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFcG5u(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFKY60("\n%s\n%s\n%s" % (VVJwpo, line, VVJwpo), VVCyLg, VVbwNy)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFKY60(line, VVLLOq, VVbwNy)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFx6I1(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVE71u), VVZWCz=26)
 def VVnipw(self):
  VVWaOb = []
  VVWaOb.append(("Title Colors"   , "title" ))
  VVWaOb.append(("Menu Area Colors"  , "body" ))
  VVWaOb.append(("Menu Pointer Colors" , "cursor" ))
  VVWaOb.append(("Bottom Bar Colors" , "bar"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFg6MQ(self, boundFunction(self.VVUCjA, title), VVWaOb=VVWaOb, width=500, title=title)
 def VVUCjA(self, title, item=None):
  if item:
   if item == "reset":
    FFyVJ3(self, self.VV08b8, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV4zEt()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVWQPP, tDict, item), CCZebD, defFG=fg, defBG=bg)
 def VVY3Cs(self):
  return VVx8df + "ajpanel_colors"
 def VV4zEt(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVY3Cs()
  if fileExists(p):
   txt = FFGKC4(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVWQPP(self, tDict, item, fg, bg):
  if fg:
   self.VVNd4R(item, fg)
   self.VVnJOJ(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVeotT(tDict)
 def VVeotT(self, tDict):
   p = self.VVY3Cs()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVNd4R(self, item, fg):
  if   item == "title" : FFnGw1(self["myTitle"], fg)
  elif item == "body"  :
   FFnGw1(self["myMenu"], fg)
   FFnGw1(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFIRRt(self["myBar"], fg)
   FFnGw1(self["keyRed"], fg)
   FFnGw1(self["keyGreen"], fg)
   FFnGw1(self["keyYellow"], fg)
   FFnGw1(self["keyBlue"], fg)
 def VVnJOJ(self, item, bg):
  if   item == "title" : FFIRRt(self["myTitle"], bg)
  elif item == "body"  :
   FFIRRt(self["myMenu"], bg)
   FFIRRt(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFIRRt(self["myBar"], bg)
 def VV08b8(self):
  os.system(FFFaNy("rm %s" % self.VVY3Cs()))
  self.close()
 def VV2PiK(self):
  tDict = self.VV4zEt()
  self.VVZV2t(tDict, "title")
  self.VVZV2t(tDict, "body")
  self.VVZV2t(tDict, "cursor")
  self.VVZV2t(tDict, "bar")
 def VVZV2t(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVNd4R(name, fg)
  if bg: self.VVnJOJ(name, bg)
 def VV4Aev(self):
  pass
class CCR7pk(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVWaOb = []
  VVWaOb.append(("Settings File"        , "SettingsFile"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Box Info"          , "VVPXg2"    ))
  VVWaOb.append(("Tuners Info"         , "VVO6CY"   ))
  VVWaOb.append(("Python Version"        , "VV73nO"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Screen Size"         , "ScreenSize"    ))
  VVWaOb.append(("Locale"          , "Locale"     ))
  VVWaOb.append(("Processor"         , "Processor"    ))
  VVWaOb.append(("Operating System"        , "OperatingSystem"   ))
  VVWaOb.append(("Drivers"          , "drivers"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("System Users"         , "SystemUsers"    ))
  VVWaOb.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVWaOb.append(("Uptime"          , "Uptime"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Host Name"         , "HostName"    ))
  VVWaOb.append(("MAC Address"         , "MACAddress"    ))
  VVWaOb.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVWaOb.append(("Network Status"        , "NetworkStatus"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Disk Usage"         , "VV2wWt"    ))
  VVWaOb.append(("Mount Points"         , "MountPoints"    ))
  VVWaOb.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVWaOb.append(("USB Devices"         , "USB_Devices"    ))
  VVWaOb.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVWaOb.append(("Directory Size"        , "DirectorySize"   ))
  VVWaOb.append(("Memory"          , "Memory"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVWaOb.append(("Running Processes"       , "RunningProcesses"  ))
  VVWaOb.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFBDfs(self, VVWaOb=VVWaOb, title="Device Information")
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCF29H)
   elif item == "VVPXg2"    : self.VVPXg2()
   elif item == "VVO6CY"   : self.VVO6CY()
   elif item == "VV73nO"   : self.VV73nO()
   elif item == "ScreenSize"    : FFx6I1(self, "Width\t: %s\nHeight\t: %s" % (FFjdS6()[0], FFjdS6()[1]))
   elif item == "Locale"     : self.VVIsUu()
   elif item == "Processor"    : self.VV4Q7J()
   elif item == "OperatingSystem"   : FFfB0P(self, "uname -a"        )
   elif item == "drivers"     : self.VVQrOn()
   elif item == "SystemUsers"    : FFfB0P(self, "id"          )
   elif item == "LoggedInUsers"   : FFfB0P(self, "who -a"         )
   elif item == "Uptime"     : FFfB0P(self, "uptime"         )
   elif item == "HostName"     : FFfB0P(self, "hostname"        )
   elif item == "MACAddress"    : self.VVrW8X()
   elif item == "NetworkConfiguration"  : FFfB0P(self, "ifconfig %s %s" % (FF8tq9("HWaddr", VVfDjZ), FF8tq9("addr:", VV106B)))
   elif item == "NetworkStatus"   : FFfB0P(self, "netstat -tulpn"       )
   elif item == "VV2wWt"    : self.VV2wWt()
   elif item == "MountPoints"    : FFfB0P(self, "mount %s" % (FF8tq9(" on ", VV106B)))
   elif item == "FileSystemTable"   : FFfB0P(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFfB0P(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFfB0P(self, "blkid"         )
   elif item == "DirectorySize"   : FFfB0P(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVktQH="Reading size ...")
   elif item == "Memory"     : FFfB0P(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVl4J2()
   elif item == "RunningProcesses"   : FFfB0P(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFfB0P(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVT4Ks()
   else         : self.close()
 def VVrW8X(self):
  res = FFNh54("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFx6I1(self, txt)
  else:
   FFfB0P(self, "ip link")
 def VVxQTx(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF8xGt(cmd)
  return lines
 def VVDMX1(self, lines, headerRepl, widths, VVFXpL):
  VVuwbt = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVuwbt.append(parts)
  if VVuwbt and len(header) == len(widths):
   VVuwbt.sort(key=lambda x: x[0].lower())
   FFemUu(self, None, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=28, VVTqck=True)
   return True
  else:
   return False
 def VV2wWt(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVxQTx(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVFXpL = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVDMX1(lines, headerRepl, widths, VVFXpL)
  if not allOK:
   lines = FF8xGt(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFMS0I(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVuV1K:
     note = "\n%s" % FFKY60("Green = Mounted Partitions", VVuV1K)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VV106B
     elif line.endswith(mountList) : color = VVuV1K
     else       : color = VVLLOq
     txt += FFKY60(line, color) + "\n"
    FFx6I1(self, txt + note)
   else:
    FF23yv(self, "Not data from system !")
 def VVl4J2(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVxQTx(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVFXpL = (LEFT , CENTER, LEFT )
  allOK = self.VVDMX1(lines, headerRepl, widths, VVFXpL)
  if not allOK:
   FFfB0P(self, cmd)
 def VVIsUu(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFx6I1(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVQrOn(self):
  cmd = FFkwB2(VVoeQ8, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFfB0P(self, cmd)
  else : FF5N91(self)
 def VV4Q7J(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFfB0P(self, cmd)
 def VVT4Ks(self):
  cmd = FFkwB2(VVvw0t, "| grep secondstage")
  if cmd : FFfB0P(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF5N91(self)
 def VVPXg2(self):
  c = VVuV1K
  VVeBho = []
  VVeBho.append((FFKY60("Box Type"  , c), FFKY60(self.VVbXgw("boxtype").upper(), c)))
  VVeBho.append((FFKY60("Board Version", c), FFKY60(self.VVbXgw("board_revision") , c)))
  VVeBho.append((FFKY60("Chipset"  , c), FFKY60(self.VVbXgw("chipset")  , c)))
  VVeBho.append((FFKY60("S/N"   , c), FFKY60(self.VVbXgw("sn")    , c)))
  VVeBho.append((FFKY60("Version"  , c), FFKY60(self.VVbXgw("version")  , c)))
  VVv3G4   = []
  VViRD7 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VViRD7 = SystemInfo[key]
     else:
      VVv3G4.append((FFKY60(str(key), VV4E8E), FFKY60(str(SystemInfo[key]), VV4E8E)))
  except:
   pass
  if VViRD7:
   VVMBDh = self.VVamv6(VViRD7)
   if VVMBDh:
    VVMBDh.sort(key=lambda x: x[0].lower())
    VVeBho += VVMBDh
  if VVv3G4:
   VVv3G4.sort(key=lambda x: x[0].lower())
   VVeBho += VVv3G4
  if VVeBho:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFemUu(self, None, header=header, VVeBho=VVeBho, VVEHj0=widths, VVZWCz=28, VVTqck=True)
  else:
   FFx6I1(self, "Could not read info!")
 def VVbXgw(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFcG5u(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVamv6(self, mbDict):
  try:
   mbList = list(mbDict)
   VVeBho = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVeBho.append((FFKY60(subject, VV106B), FFKY60(value, VV106B)))
  except:
   pass
  return VVeBho
 def VVO6CY(self):
  txt = self.VV7Wby("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VV7Wby("/proc/bus/nim_sockets")
  if not txt: txt = self.VVu6ZQ()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFx6I1(self, txt)
 def VVu6ZQ(self):
  txt = ""
  VVOCz2 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVOCz2("Slot Name" , slot.getSlotName())
     txt += FFKY60(slotName, VV106B)
     txt += VVOCz2("Description"  , slot.getFullDescription())
     txt += VVOCz2("Frontend ID"  , slot.frontend_id)
     txt += VVOCz2("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VV7Wby(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFcG5u(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFKY60(line, VV106B)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV73nO(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFx6I1(self, txt)
class CCF29H(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVWaOb = []
  VVWaOb.append(("Settings (All)"   , "Settings_All"   ))
  VVWaOb.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVt4jw:
   VVWaOb.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVWaOb.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVWaOb.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVWaOb.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVWaOb.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVWaOb.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFBDfs(self, VVWaOb=VVWaOb)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFfB0P(self, cmd                )
   elif item == "Settings_HotKeys"   : FFfB0P(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFfB0P(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFfB0P(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFfB0P(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFfB0P(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFfB0P(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFfB0P(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCz0kj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVL92J, VVIgSe, VVqp0R, camCommand = FFYhhj()
  self.VVIgSe = VVIgSe
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVWaOb = []
  VVWaOb.append(("OSCam Files"        , "OSCamFiles"  ))
  VVWaOb.append(("NCam Files"        , "NCamFiles"  ))
  VVWaOb.append(("CCcam Files"        , "CCcamFiles"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVWaOb.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVWaOb.append(VVIEqe)
  if VVIgSe:
   if   "oscam" in VVIgSe : camName = "OSCam"
   elif "ncam"  in VVIgSe : camName = "NCam"
   VVWaOb.append((camName + " Info."      , "camInfo"   ))
   VVWaOb.append((camName + " Live Status"    , "camLiveStatus" ))
   VVWaOb.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVWaOb.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVWaOb.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFBDfs(self, VVWaOb=VVWaOb)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCDNYP, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCDNYP, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCDNYP, "cccam"))
   elif item == "OSCamReaders"  : self.VV94AE("os")
   elif item == "NSCamReaders"  : self.VV94AE("n")
   elif item == "camInfo"   : FFU8Qj(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFyEMn(self.session, CCMbjU.VVCk9O)
   elif item == "camLiveReaders" : FFyEMn(self.session, CCMbjU.VVFBym)
   elif item == "camLiveLog"  : FFyEMn(self.session, CCMbjU.VV18bM)
   else       : self.close()
 def VV94AE(self, camPrefix):
  VVuwbt = self.VVvkjg(camPrefix)
  if VVuwbt:
   VVuwbt.sort(key=lambda x: int(x[0]))
   if self.VVIgSe and self.VVIgSe.startswith(camPrefix):
    VV76K2 = ("Toggle State", self.VVzg1r, [camPrefix], "Changing State ...")
   else:
    VV76K2 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVFXpL  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFemUu(self, None, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VV76K2=VV76K2, VVhUO0=True)
 def VVvkjg(self, camPrefix):
  readersFile = self.VVL92J + camPrefix + "cam.server"
  VVuwbt = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFcG5u(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVuwbt.append((str(len(VVuwbt) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVuwbt:
    FF23yv(self, "No readers found !")
  else:
   FFl2xw(self, readersFile)
  return VVuwbt
 def VVzg1r(self, VVgIs9, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVL92J, camPrefix)
  readerState  = VVgIs9.VVZVaS(1)
  readerLabel  = VVgIs9.VVZVaS(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCz0kj.VVdGOP(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVgIs9.VVMe3Y()
    FF23yv(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVuwbt = self.VVvkjg(camPrefix)
   if VVuwbt:
    VVgIs9.VVDgsH(VVuwbt)
 @staticmethod
 def VVdGOP(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFcG5u(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF23yv(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF23yv(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFl2xw(SELF, confFile)
   return None
  if not iRequest:
   FF23yv(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF23yv(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF23yv(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCDNYP(Screen):
 def __init__(self, VV2TFo, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVL92J, VVIgSe, VVqp0R, camCommand = FFYhhj()
  if   VV2TFo == "ncam" : self.prefix = "n"
  elif VV2TFo == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVWaOb = []
  if self.prefix == "":
   VVWaOb.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVWaOb.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVWaOb.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVWaOb.append(("constant.cw"         , "x_constant_cw" ))
   VVWaOb.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVWaOb.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVWaOb.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVWaOb.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVWaOb.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVWaOb.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVWaOb.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVWaOb.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVWaOb.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVWaOb.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVWaOb.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFBDfs(self, VVWaOb=VVWaOb)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFpIfw(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFpIfw(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFpIfw(self, self.VVL92J + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFpIfw(self, self.VVL92J + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVmL39("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVmL39("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVmL39("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVmL39("cam.provid"        )
   elif item == "x_cam_server"  : self.VVmL39("cam.server"        )
   elif item == "x_cam_services" : self.VVmL39("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVmL39("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVmL39("cam.user"        )
   elif item == "x_VVJwpo"   : pass
   elif item == "x_SoftCam_Key" : FFpIfw(self, self.VVL92J + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFpIfw(self, self.VVL92J + "CCcam.cfg"    )
   elif item == "x_VVJwpo"   : pass
   elif item == "x_cam_log"  : FFpIfw(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFpIfw(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFpIfw(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVmL39(self, fileName):
  FFpIfw(self, self.VVL92J + self.prefix + fileName)
class CCMbjU(Screen):
 VVCk9O  = 0
 VVFBym = 1
 VV18bM = 2
 def __init__(self, session, VVL92J="", VVIgSe="", VVqp0R="", VVUVvk=VVCk9O):
  self.skin, self.skinParam = FFDOid(VVXzV5, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVqp0R   = VVqp0R
  self.VVUVvk  = VVUVvk
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVL92J + VVIgSe + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVIgSe : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVL92J, self.camPrefix)
  if self.VVUVvk == self.VVCk9O:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVUVvk == self.VVFBym:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFBDfs(self, self.Title, addScrollLabel=True)
  FFOV9c(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVZ69O
  self.onShown.append(self.VVKQSI)
  self.onClose.append(self.onExit)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self["myLabel"].VVqzy0(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFkJyH(self)
  self.VVZ69O()
 def onExit(self):
  self.timer.stop()
 def VV9Z01(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VViy6w)
  except:
   self.timer.callback.append(self.VViy6w)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFU7uG(self, "Started", 1000)
 def VVgzPq(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VViy6w)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFU7uG(self, "Stopped", 1000)
 def VVZ69O(self):
  if self.timerRunning:
   self.VVgzPq()
  else:
   self.VV9Z01()
   if self.VVUVvk == self.VVCk9O or self.VVUVvk == self.VVFBym:
    if self.VVUVvk == self.VVCk9O : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCz0kj.VVdGOP(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFewwi(self.VVmTGV)
    else:
     self.close()
   else:
    self.VV7LUL()
 def VViy6w(self):
  if self.timerRunning:
   if   self.VVUVvk == self.VVCk9O : self.VVrZWl()
   elif self.VVUVvk == self.VVFBym : self.VVrZWl()
   else            : self.VV7LUL()
 def VV7LUL(self):
  if fileExists(self.VVqp0R):
   fTime = FFv8BC(os.path.getmtime(self.VVqp0R))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVGGRL(), VVJQke=VV3zRr)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVqp0R)
 def VVmTGV(self):
  self.VVrZWl()
 def VVrZWl(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFKY60("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVCyLg))
   self.camWebIfErrorFound = True
   self.VVgzPq()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVUVvk == self.VVCk9O : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFKY60("Error while parsing data elements !\n\nError = %s" % str(e), VVvqWy)
   self.camWebIfErrorFound = True
   self.VVgzPq()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV03rf(root)
  self["myLabel"].setText(txt, VVJQke=VV3zRr)
  self["myBar"].setText("Last Update : %s" % FFejuP())
 def VV03rf(self, rootElement):
  def VVOCz2(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVUVvk == self.VVCk9O:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFKY60(status, VVuV1K)
    else          : status = FFKY60(status, VVvqWy)
    txt += VVJwpo + "\n"
    txt += VVOCz2("Name"  , name)
    txt += VVOCz2("Description" , desc)
    txt += VVOCz2("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVOCz2("Protocol" , protocol)
    txt += VVOCz2("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFKY60("Yes", VVuV1K)
    else    : enabTxt = FFKY60("No", VVvqWy)
    txt += VVJwpo + "\n"
    txt += VVOCz2("Label"  , label)
    txt += VVOCz2("Protocol" , protocol)
    txt += VVOCz2("Enabled" , enabTxt)
  return txt
 def VVGGRL(self):
  wordsDict = self.VV5B1Q()
  color = [ VV106B, VVfDjZ, VVuV1K, VVvqWy, VV4E8E, VVzNDT]
  lines = FF8xGt("tail -n %d %s" % (100, self.VVqp0R))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVCyLg + line[:19] + VVLLOq + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVbwNy + line[ndx + 3:] + VVLLOq
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VV106B + line[ndx + 8 : ndx1 + 4] + VVLLOq + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVLLOq)
   elif line.startswith("----") or ">>" in line:
    line = FFKY60(line, VV106B)
   txt += line + "\n"
  return txt
 def VV5B1Q(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFcG5u(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCeNUw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVWaOb = []
  VVWaOb.append(("Backup Channels"    , "VVBX4l"   ))
  VVWaOb.append(("Restore Channels"    , "Restore_Channels"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Backup SoftCAM Files"   , "VV0TW3" ))
  VVWaOb.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVWaOb.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVWaOb.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Backup Network Settings"  , "VV5zT6"   ))
  VVWaOb.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVt4jw:
   VVWaOb.append(VVIEqe)
   VVWaOb.append((VVCyLg + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVqqY7"   ))
   VVWaOb.append((VVuV1K + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVkIic) , "createMyIpk"   ))
   VVWaOb.append((VVuV1K + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVkIic) , "createMyDeb"   ))
   VVWaOb.append((VV4E8E + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVWaOb.append((VV4E8E + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVHB2U" ))
  FFBDfs(self, VVWaOb=VVWaOb)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVBX4l"    : self.VVBX4l()
   elif item == "Restore_Channels"    : self.VVCMaC("channels_backup*.tar.gz", self.VVm5Jq)
   elif item == "VV0TW3"   : self.VV0TW3()
   elif item == "Restore_SoftCAM_Files"  : self.VVCMaC("softcam_backup*.tar.gz", self.VVOuvD)
   elif item == "Backup_TunerDiSEqC"   : self.VVstGU("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVCMaC("tuner_backup*.backup", boundFunction(self.VVViXx, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVstGU("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVCMaC("hotkey_*backup*.backup", boundFunction(self.VVViXx, "misc"))
   elif item == "VV5zT6"    : self.VV5zT6()
   elif item == "Restore_Network"    : self.VVCMaC("network_backup*.tar.gz", self.VVYRzS)
   elif item == "VVqqY7"     : FFyVJ3(self, boundFunction(FFJ3IJ, self, boundFunction(CCeNUw.VVqqY7, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVAV3J(False)
   elif item == "createMyDeb"     : self.VVAV3J(True)
   elif item == "createMyTar"     : self.VVxFhs()
   elif item == "VVHB2U"   : self.VVHB2U()
 @staticmethod
 def VVqqY7(SELF):
  OBF_Path = VVYZN0 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVYZN0, VVE71u, VVkIic)
   if err : FF23yv(SELF, err)
   else : FFx6I1(SELF, txt)
  else:
   FFl2xw(SELF, OBF_Path)
 def VVAV3J(self, VVC9Ss):
  OBF_Path = VVYZN0 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF23yv(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVYZN0)
  os.system("mv -f %s %s" % (VVYZN0 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVYZN0 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVYZN0 + "plugin.py"))
  self.session.openWithCallback(self.VVAV3J1, boundFunction(CC8jHO, path=VVYZN0, VVC9Ss=VVC9Ss))
 def VVAV3J1(self):
  os.system("mv -f %s %s" % (VVYZN0 + "OBF/main.py"  , VVYZN0))
  os.system("mv -f %s %s" % (VVYZN0 + "OBF/plugin.py" , VVYZN0))
 def VVHB2U(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF23yv(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF23yv(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVhMZr("%s*.list" % path)
  if err:
   FFl2xw(self, path + "*.list")
   return
  srcF, err = self.VVhMZr("%s*main_final.py" % path)
  if err:
   FFl2xw(self, path + "*.final.py")
   return
  VVeBho = []
  for f in files:
   f = os.path.basename(f)
   VVeBho.append((f, f))
  FFg6MQ(self, boundFunction(self.VVFfrl, path, codF, srcF), VVWaOb=VVeBho)
 def VVFfrl(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFl2xw(self, logF)
   else     : FFJ3IJ(self, boundFunction(self.VVSUqB, logF, codF, srcF))
 def VVSUqB(self, logF, codF, srcF):
  lst  = []
  lines = FFcG5u(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF23yv(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVSgLq(lst, logF, newLogF)
  totSrc  = self.VVSgLq(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFx6I1(self, txt)
 def VVhMZr(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVSgLq(self, lst, f1, f2):
  txt = FFGKC4(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVxFhs(self):
  VVeBho = []
  VVeBho.append("%s%s" % (VVYZN0, "*.py"))
  VVeBho.append("%s%s" % (VVYZN0, "*.png"))
  VVeBho.append("%s%s" % (VVYZN0, "*.xml"))
  VVeBho.append("%s"  % (VVGuqQ))
  FFjbda(self, VVeBho, "%s_%s" % (PLUGIN_NAME, VVE71u), addTimeStamp=False)
 def VVBX4l(self):
  path1 = VVrXSk
  path2 = "/etc/tuxbox/"
  VVeBho = []
  VVeBho.append("%s%s" % (path1, "*.tv"))
  VVeBho.append("%s%s" % (path1, "*.radio"))
  VVeBho.append("%s%s" % (path1, "*list"))
  VVeBho.append("%s%s" % (path1, "lamedb*"))
  VVeBho.append("%s%s" % (path2, "*.xml"))
  FFjbda(self, VVeBho, "channels_backup", addTimeStamp=True)
 def VV0TW3(self):
  VVeBho = []
  VVeBho.append("/etc/tuxbox/config/")
  VVeBho.append("/usr/keys/")
  VVeBho.append("/usr/scam/")
  VVeBho.append("/etc/CCcam.cfg")
  FFjbda(self, VVeBho, "softcam_backup", addTimeStamp=True)
 def VV5zT6(self):
  VVeBho = []
  VVeBho.append("/etc/hostname")
  VVeBho.append("/etc/default_gw")
  VVeBho.append("/etc/resolv.conf")
  VVeBho.append("/etc/wpa_supplicant*.conf")
  VVeBho.append("/etc/network/interfaces")
  VVeBho.append("/etc/enigma2/nameserversdns.conf")
  FFjbda(self, VVeBho, "network_backup", addTimeStamp=True)
 def VVm5Jq(self, fileName):
  if fileName:
   FFyVJ3(self, boundFunction(self.VVEQUF, fileName), "Overwrite current channels ?")
 def VVEQUF(self, fileName):
  path = "%s%s" % (VVx8df, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCpfVT.VVuDPd()
   lamedb5File, diabled5File = CCpfVT.VVr0Jc()
   cmd = ""
   cmd += FFFaNy("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFFaNy("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FF0eVO()
   if res == 0 : FFuW4T(self, "Channels Restored.")
   else  : FF23yv(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFl2xw(self, path)
 def VVOuvD(self, fileName):
  if fileName:
   FFyVJ3(self, boundFunction(self.VV7m0X, fileName), "Overwrite SoftCAM files ?")
 def VV7m0X(self, fileName):
  fileName = "%s%s" % (VVx8df, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVJwpo
   note = "You may need to restart your SoftCAM."
   FFvO2C(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF8tq9(note, VV106B), sep))
  else:
   FFl2xw(self, fileName)
 def VVYRzS(self, fileName):
  if fileName:
   FFyVJ3(self, boundFunction(self.VVJAr6, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVJAr6(self, fileName):
  fileName = "%s%s" % (VVx8df, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFsUMt(self,  cmd)
  else:
   FFl2xw(self, fileName)
 def VVCMaC(self, pattern, callBackFunction, isTuner=False):
  title = FFChu1()
  if pathExists(VVx8df):
   myFiles = iGlob("%s%s" % (VVx8df, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVeBho = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVeBho.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVB6Er = ("Sat. List", self.VVjCq5)
    else  : VVB6Er = None
    VVIAKx = ("Delete File", boundFunction(self.VV5CEJ, boundFunction(self.VVCMaC, pattern, callBackFunction, isTuner)))
    FFg6MQ(self, callBackFunction, title=title, VVWaOb=VVeBho, VVB6Er=VVB6Er, VVIAKx=VVIAKx)
   else:
    FF23yv(self, "No files found in:\n\n%s" % VVx8df, title)
  else:
   FF23yv(self, "Path not found:\n\n%s" % VVx8df, title)
 def VV5CEJ(self, cbFnc, VVsszyObj, path):
  FFyVJ3(self, boundFunction(self.VVuvyw, cbFnc, VVsszyObj, path), "Delete this file ?\n\n%s" % path)
 def VVuvyw(self, cbFnc, VVsszyObj, path):
  os.system(FFFaNy("rm -f '%s%s'" % (VVx8df, path)))
  cbFnc()
  VVsszyObj.cancel()
 def VVstGU(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CC1uI6()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VV7clr, filePrefix))
 def VV7clr(self, filePrefix, result, retval):
  title = FFChu1()
  if pathExists(VVx8df):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF23yv(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVx8df, filePrefix, FFBQPI())
    try:
     VVeBho = str(result.strip()).split()
     if VVeBho:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVeBho:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVJwpo, FFKY60(fName, VV106B), VVJwpo)
       FFx6I1(self, txt, title=title, VVJQke=VV3zRr)
      else:
       FF23yv(self, "File creation failed!", title)
     else:
      FF23yv(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFFaNy("rm %s" % fName))
     FF23yv(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFFaNy("rm %s" % fName))
     FF23yv(self, "Error while writing file.")
  else:
   FF23yv(self, "Path not found:\n\n%s" % VVx8df, title)
 def VVViXx(self, mode, path):
  if path:
   path = "%s%s" % (VVx8df, path)
   if fileExists(path):
    lines = FFcG5u(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFyVJ3(self, boundFunction(self.VVbcLX, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFoblU(self, path, title=FFChu1())
   else:
    FFl2xw(self, path)
 def VVbcLX(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVuqfs = []
  VVuqfs.append("echo -e 'Reading current settings ...'")
  VVuqfs.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVuqfs.append("echo -e 'Preparing new settings ...'")
  VVuqfs.append(settingsLines)
  VVuqfs.append("echo -e 'Applying new settings ...'")
  VVuqfs.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FF818p(self, VVuqfs)
 def VVjCq5(self, VVsszyObj, path):
  if not path:
   return
  path = VVx8df + path
  if not fileExists(path):
   FFl2xw(self, path)
   return
  txt = FFGKC4(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVeBho  = []
   for item in satList:
    VVeBho.append("%s\t%s" % (item[0], FFMhop(item[1])))
   FFx6I1(self, VVeBho, title="  Satellites List")
  else:
   FF23yv(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCf3vw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVxulX, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVWaOb = []
  VVWaOb.append(("Plugins Browser List"       , "VVcMOI"   ))
  VVWaOb.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVWaOb.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVWaOb.append(("Remove Packages (show all)"     , "VVedVCsAll"   ))
  VVWaOb.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Update List of Available Packages"   , "VVbTXD"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Packaging Tool"        , "VVtAVC"    ))
  VVWaOb.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFBDfs(self, VVWaOb=VVWaOb)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVcMOI"   : self.VVcMOI()
   elif item == "pluginsMenus"     : self.VVyv9N(0)
   elif item == "pluginsStartup"    : self.VVyv9N(1)
   elif item == "pluginsDirList"    : self.VVMNIs()
   elif item == "downloadInstallPackages"  : FFJ3IJ(self, boundFunction(self.VVqCMy, 0, ""))
   elif item == "VVedVCsAll"   : FFJ3IJ(self, boundFunction(self.VVqCMy, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFJ3IJ(self, boundFunction(self.VVqCMy, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVbTXD"   : self.VVbTXD()
   elif item == "VVtAVC"    : self.VVtAVC()
   elif item == "packagesFeeds"    : self.VVp7R2()
   else          : self.close()
 def VVMNIs(self):
  extDirs  = FFb1OU(VVy60U)
  sysDirs  = FFb1OU(VVsxXY)
  VVeBho  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVeBho.append((item, VVy60U + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVeBho.append((item, VVsxXY + item))
  if VVeBho:
   VVeBho = sorted(VVeBho, key=lambda x: x[0].lower())
   VVSWdY = ("Package Info.", self.VVC0oJ, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFemUu(self, None, header=header, VVeBho=VVeBho, VVEHj0=widths, VVZWCz=28, VVSWdY=VVSWdY)
  else:
   FF23yv(self, "Nothing found!")
 def VVC0oJ(self, VVgIs9, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVy60U) : loc = "extensions"
  elif path.startswith(VVsxXY) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVvBFN(package)
  else:
   FF23yv(self, "No info!")
 def VVp7R2(self):
  pkg = FF3RNN()
  if pkg : FFfB0P(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF5N91(self)
 def VVcMOI(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVOCz2(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVJwpo + "\n"
    txt += VVOCz2("Number"   , str(c))
    txt += VVOCz2("Name"   , FFKY60(str(p.name), VV106B))
    txt += VVOCz2("Path"  , p.path  )
    txt += VVOCz2("Description" , p.description )
    txt += VVOCz2("Icon"  , p.iconstr  )
    txt += VVOCz2("Wakeup Fnc" , p.wakeupfnc )
    txt += VVOCz2("NeedsRestart", p.needsRestart)
    txt += VVOCz2("Internal" , p.internal )
    txt += VVOCz2("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFx6I1(self, txt)
 def VVyv9N(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVeBho = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVeBho.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVeBho:
   VVeBho.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFemUu(self, None, title=title, header=header, VVeBho=VVeBho, VVEHj0=widths, VVZWCz=26)
  else:
   FF23yv(self, "Nothing Found", title=title)
 def VVbTXD(self):
  cmd = FFkwB2(VV2iC7, "")
  if cmd : FFsUMt(self, cmd, checkNetAccess=True)
  else : FF5N91(self)
 def VVtAVC(self):
  pkg = FF3RNN()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFuW4T(self, txt)
 def VVqCMy(self, mode, grep, VVgIs9=None, title=""):
  if   mode == 0: cmd = FFkwB2(VVvw0t    , grep)
  elif mode == 1: cmd = FFkwB2(VVoeQ8 , grep)
  elif mode == 2: cmd = FFkwB2(VVoeQ8 , grep)
  if not cmd:
   FF5N91(self)
   return
  VVuwbt = FF8xGt(cmd)
  if not VVuwbt:
   if VVgIs9: VVgIs9.VVMe3Y()
   FF23yv(self, "No packages found!")
   return
  elif len(VVuwbt) == 1 and VVuwbt[0] == VVn6jj:
   FF23yv(self, VVn6jj)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVeBho  = []
  for item in VVuwbt:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVeBho.append((name, package, version))
  if mode > 0:
   extensions = FF8xGt("ls %s -l | grep '^d' | awk '{print $9}'" % VVy60U)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVeBho:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVeBho.append((name, VVy60U + item, "-"))
   systemPlugins = FF8xGt("ls %s -l | grep '^d' | awk '{print $9}'" % VVsxXY)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVeBho:
      if item.lower() == row[0].lower():
       break
     else:
      VVeBho.append((item, VVsxXY + item, "-"))
  if not VVeBho:
   FF23yv(self, "No packages found!")
   return
  if VVgIs9:
   VVeBho.sort(key=lambda x: x[0].lower())
   VVgIs9.VVDgsH(VVeBho, title)
  else:
   widths = (20, 50, 30)
   VV76K2 = None
   VVzVsH = None
   if mode == 0:
    VVINMZ = ("Install" , self.VVuCad   , [])
    VV76K2 = ("Download" , self.VVp6sN   , [])
    VVzVsH = ("Filter"  , self.VVIRzg , [])
   elif mode == 1:
    VVINMZ = ("Uninstall", self.VVedVC, [])
   elif mode == 2:
    VVINMZ = ("Uninstall", self.VVedVC, [])
    widths= (18, 57, 25)
   VVeBho = sorted(VVeBho, key=lambda x: x[0].lower())
   VVSWdY = ("Package Info.", self.VVYsmo, [])
   header   = ("Name" ,"Package" , "Version" )
   FFemUu(self, None, header=header, VVeBho=VVeBho, VVEHj0=widths, VVZWCz=28, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH, VVPytF=self.lastSelectedRow
     , VVKeoU="#22110011", VVJRMb="#22191111", VVTMiH="#22191111", VVeFdq="#00003030", VVmeUl="#00333333")
 def VVYsmo(self, VVgIs9, title, txt, colList):
  package = colList[1]
  self.VVvBFN(package)
 def VVIRzg(self, VVgIs9, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVWaOb = []
  VVWaOb.append(("All Packages", "all"))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVWaOb.append(VVIEqe)
  for word in words:
   VVWaOb.append((word, word))
  FFg6MQ(self, boundFunction(self.VVyNub, VVgIs9), VVWaOb=VVWaOb, title="Select Filter")
 def VVyNub(self, VVgIs9, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFJ3IJ(VVgIs9, boundFunction(self.VVqCMy, 0, grep, VVgIs9, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVedVC(self, VVgIs9, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVy60U, VVsxXY)):
   FFyVJ3(self, boundFunction(self.VVhTs3, VVgIs9, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVWaOb = []
   VVWaOb.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVWaOb.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVWaOb.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFg6MQ(self, boundFunction(self.VVoypP, VVgIs9, package), VVWaOb=VVWaOb)
 def VVhTs3(self, VVgIs9, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV2IM6)
  FFsUMt(self, cmd, VVsNdD=boundFunction(self.VVV8gv, VVgIs9))
 def VVoypP(self, VVgIs9, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVKAAT
   elif item == "remove_ForceRemove"  : cmdOpt = VVjkH2
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVnwKT
   FFyVJ3(self, boundFunction(self.VVM1bd, VVgIs9, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVM1bd(self, VVgIs9, package, cmdOpt):
  self.lastSelectedRow = VVgIs9.VVIxU2()
  cmd = FFNOBr(cmdOpt, package)
  if cmd : FFsUMt(self, cmd, VVsNdD=boundFunction(self.VVV8gv, VVgIs9))
  else : FF5N91(self)
 def VVV8gv(self, VVgIs9):
  VVgIs9.cancel()
  FFMA4x()
 def VVuCad(self, VVgIs9, title, txt, colList):
  package  = colList[1]
  VVWaOb = []
  VVWaOb.append(("Install Package"         , "install_CheckVersion" ))
  VVWaOb.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVWaOb.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVWaOb.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVWaOb.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFg6MQ(self, boundFunction(self.VVWf1O, package), VVWaOb=VVWaOb)
 def VVWf1O(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVlyKc
   elif item == "install_ForceReinstall" : cmdOpt = VV89BS
   elif item == "install_ForceOverwrite" : cmdOpt = VVs9RN
   elif item == "install_ForceDowngrade" : cmdOpt = VVq23Q
   elif item == "install_IgnoreDepends" : cmdOpt = VVqPlm
   FFyVJ3(self, boundFunction(self.VVDsMe, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVDsMe(self, package, cmdOpt):
  cmd = FFNOBr(cmdOpt, package)
  if cmd : FFsUMt(self, cmd, VVsNdD=FFMA4x, checkNetAccess=True)
  else : FF5N91(self)
 def VVp6sN(self, VVgIs9, title, txt, colList):
  package  = colList[1]
  FFyVJ3(self, boundFunction(self.VVOxAt, package), "Download Package ?\n\n%s" % package)
 def VVOxAt(self, package):
  if FFeI9s():
   cmd = FFNOBr(VVnIxU, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF8tq9(success, VVuV1K))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF8tq9(fail, VVvqWy))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFsUMt(self, cmd, VVLiPR=[VVvqWy, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF5N91(self)
  else:
   FF23yv(self, "No internet connection !")
 def VVvBFN(self, package):
  infoCmd  = FFNOBr(VVKo8d, package)
  filesCmd = FFNOBr(VVB5Tr, package)
  listInstCmd = FFkwB2(VVoeQ8, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFaVi1(VV106B)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF8tq9(notInst, VVCyLg))
   cmd += "else "
   cmd +=   FFaT5W("System Info", VV106B)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFaT5W("Related Files", VV106B)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFOKKC(self, cmd)
  else:
   FF5N91(self)
class CCpfVT(Screen):
 VVFZZq  = 0
 VV3M1Q = 1
 VVzIX9  = 2
 VVUzBc  = 3
 VVDM5S = 4
 VV4cXk = 5
 VV44pv = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFDOid(VVxulX, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVLxxC = None
  self.lastfilterUsed  = None
  VVWaOb = self.VVkUDh()
  FFBDfs(self, VVWaOb=VVWaOb, title="Services/Channels")
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self["myMenu"].setList(self.VVkUDh())
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
 def VVkUDh(self):
  VVWaOb = []
  VVWaOb.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVWaOb.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVWaOb.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVWaOb.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVWaOb.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVWaOb.append(("Services with PIcons for the System"  , "VVtTkw"     ))
  VVWaOb.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVWaOb.append(VVIEqe)
  lamedbFile, disabledFile = CCpfVT.VVuDPd()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVWaOb.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVWaOb.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVWaOb.append(("Reset Parental Control Settings"   , "VVZEoL"    ))
  VVWaOb.append(("Delete Channels with no names"   , "VVgCsy"    ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Reload Channels and Bouquets"    , "VVXIWO"      ))
  return VVWaOb
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFgVOc(self)
   elif item == "currentServiceInfo"     : FFEjmz(self, fncMode=CCdLyC.VVFrdh)
   elif item == "TranspondersStats"     : FFJ3IJ(self, self.VVOJRA     )
   elif item == "lameDB_allChannels_with_refCode"  : FFJ3IJ(self, self.VVQrXZ )
   elif item == "lameDB_allChannels_with_tranaponder" : FFJ3IJ(self, self.VVyWCG)
   elif item == "lameDB_allChannels_with_details"  : FFJ3IJ(self, self.VVVwQu )
   elif item == "parentalControlChannels"    : FFJ3IJ(self, self.VV0hYf   )
   elif item == "showHiddenChannels"     : FFJ3IJ(self, self.VV1XuO     )
   elif item == "VVtTkw"     : FFJ3IJ(self, self.VVyVyr     )
   elif item == "servicesWithMissingPIcons"   : FFJ3IJ(self, self.VVN8Ub   )
   elif item == "enableHiddenChannels"     : self.VVD1CC(True)
   elif item == "disableHiddenChannels"    : self.VVD1CC(False)
   elif item == "VVZEoL"    : FFyVJ3(self, self.VVZEoL, "Reset and Restart ?" )
   elif item == "VVgCsy"    : FFJ3IJ(self, self.VVgCsy)
   elif item == "VVXIWO"      : FFJ3IJ(self, boundFunction(CCpfVT.VVXIWO, self))
   else            : self.close()
 @staticmethod
 def VVXIWO(SELF):
  FF0eVO()
  FFuW4T(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVQrXZ(self):
  self.VVLxxC = None
  self.lastfilterUsed  = None
  self.filterObj   = CCJJAn(self)
  VVuwbt = CCpfVT.VVPQV0(self, self.VVFZZq)
  if VVuwbt:
   VVuwbt.sort(key=lambda x: x[0].lower())
   VViQOR  = ("Zap"   , self.VVYgao     , [])
   VVf1jQ = (""    , self.VVgf4e   , [])
   VVSWdY = ("Options"  , self.VVt2kE , [])
   VV76K2 = ("Current Service", self.VVaNtg , [])
   VVzVsH = ("Filter"   , self.VVyocI  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVFXpL  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFemUu(self, None, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH)
 def VVyWCG(self):
  self.VVLxxC = None
  self.lastfilterUsed  = None
  self.filterObj   = CCJJAn(self)
  VVuwbt = CCpfVT.VVPQV0(self, self.VV3M1Q)
  if VVuwbt:
   VVuwbt.sort(key=lambda x: x[0].lower())
   VViQOR  = ("Zap"   , self.VVYgao      , [])
   VVf1jQ = (""    , self.VVgf4e    , [])
   VV76K2 = ("Current Service", self.VVaNtg  , [])
   VVSWdY = ("Options"  , self.VVPNUj , [])
   VVzVsH = ("Filter"   , self.VV9LTU  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVFXpL  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFemUu(self, None, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH)
 def VVt2kE(self, VVgIs9, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCIKdH(self, VVgIs9, 3)
  mSel.VVWjJx(servName, refCode, pcState, hidState)
 def VVPNUj(self, VVgIs9, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCIKdH(self, VVgIs9, 3)
  mSel.VVsoqo(servName, refCode)
 def VVKnzM(self, VVgIs9, refCode, isAddToBlackList):
  self.VVLxxC = None
  self.lastfilterUsed  = None
  VVgIs9.VVGxQC("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFJ3IJ(self, boundFunction(self.VV8SbV, VVgIs9, refCode))
  else:
   FFl2xw(self, path)
 def VV1wLP(self, VVgIs9, refCode, isHide):
  self.VVLxxC = None
  self.lastfilterUsed  = None
  VVgIs9.VVGxQC("Changing state ...")
  if FF6jl4(refCode):
   ret = FFlSYx(refCode, isHide)
   if ret : FFJ3IJ(self, boundFunction(self.VV8SbV, VVgIs9, refCode))
   else : FF23yv(self, "Cannot Hide/Unhide this channel.")
  else:
   FF23yv(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VV8SbV(self, VVgIs9, refCode):
  VVuwbt = CCpfVT.VVPQV0(self, self.VVFZZq, VVnnUw=[3, [refCode], False])
  done = False
  if VVuwbt:
   data = VVuwbt[0]
   if data[3] == refCode:
    done = VVgIs9.VVJCuN(data)
  if not done:
   self.VVKppp(VVgIs9, VVgIs9.VVfnQk(), self.VVFZZq)
  VVgIs9.VVMe3Y()
 def VVyocI(self, VVgIs9, title, txt, colList):
  self.filterObj.VVN1AA(1, VVgIs9, 2, boundFunction(self.VViIbE, VVgIs9))
 def VViIbE(self, VVgIs9, item):
  self.VVlNcR(VVgIs9, item, 2, self.VVFZZq)
 def VV9LTU(self, VVgIs9, title, txt, colList):
  self.filterObj.VVN1AA(2, VVgIs9, 4, boundFunction(self.VVHdVy, VVgIs9))
 def VVHdVy(self, VVgIs9, item):
  self.VVlNcR(VVgIs9, item, 4, self.VV3M1Q)
 def VVYzDL(self, VVgIs9, title, txt, colList):
  self.filterObj.VVN1AA(0, VVgIs9, 4, boundFunction(self.VVQxVw, VVgIs9))
 def VVQxVw(self, VVgIs9, item):
  self.VVlNcR(VVgIs9, item, 4, self.VVzIX9)
 def VVlNcR(self, VVgIs9, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVgIs9.VVZVaS(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVLxxC = None
  else:
   words, asPrefix = CCJJAn.VVYNrj(words)
   self.VVLxxC = [col, words, asPrefix]
  if words: FFJ3IJ(self, boundFunction(self.VVKppp, VVgIs9, title, mode), title="Reading Services ...")
  else : FFU7uG(VVgIs9, "Incorrect filter", 2000)
 def VVKppp(self, VVgIs9, title, mode):
  VVuwbt = CCpfVT.VVPQV0(self, mode, VVnnUw=self.VVLxxC, VVUZCj=False)
  if VVuwbt:
   VVuwbt.sort(key=lambda x: x[0].lower())
   VVgIs9.VVDgsH(VVuwbt, title)
  else:
   VVgIs9.VVMe3Y()
   FFU7uG(VVgIs9, "Not found!", 1500)
 def VVIoit(self, VVeBho, VViQOR=None, VVf1jQ=None, VVINMZ=None, VV76K2=None, VVSWdY=None, VVzVsH=None):
  VV76K2 = ("Current Service", self.VVaNtg, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVFXpL = (LEFT  , LEFT  , CENTER, LEFT    )
  FFemUu(self, None, header=header, VVeBho=VVeBho, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH)
 def VVaNtg(self, VVgIs9, title, txt, colList):
  self.VVJN8O(VVgIs9)
 def VVLqse(self, VVgIs9, title, txt, colList):
  self.VVJN8O(VVgIs9, True)
 def VVJN8O(self, VVgIs9, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVgIs9.VVxwwa(colDict, VVxzdz=True)
   else:
    VVgIs9.VVPRhs(3, refCode, True)
   return
  FF23yv(self, "Colud not read current Reference Code !")
 def VVVwQu(self):
  self.VVLxxC = None
  self.lastfilterUsed  = None
  self.filterObj   = CCJJAn(self)
  VVuwbt = CCpfVT.VVPQV0(self, self.VVzIX9)
  if VVuwbt:
   VVuwbt.sort(key=lambda x: x[0].lower())
   VVf1jQ = (""    , self.VVdrsO , []      )
   VV76K2 = ("Current Service", self.VVLqse  , []      )
   VVzVsH = ("Filter"   , self.VVYzDL   , [], "Loading Filters ..." )
   VViQOR  = ("Zap"   , self.VV5oxT      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVFXpL  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFemUu(self, None, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VV76K2=VV76K2, VVzVsH=VVzVsH)
 def VVdrsO(self, VVgIs9, title, txt, colList):
  refCode  = self.VVdYEW(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFEjmz(self, fncMode=CCdLyC.VV3zQg, refCode=refCode, chName=chName, text=txt)
 def VV5oxT(self, VVgIs9, title, txt, colList):
  refCode = self.VVdYEW(colList)
  FFFZZb(self, refCode)
 def VVYgao(self, VVgIs9, title, txt, colList):
  FFFZZb(self, colList[3])
 def VVdYEW(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVPQV0(SELF, mode, VVnnUw=None, VVUZCj=True, VV3Thx=True):
  lamedbFile, disabledFile = CCpfVT.VVuDPd()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVnnUw:
    filterCol = VVnnUw[0]
    filterWords = VVnnUw[1]
    asPrefix = VVnnUw[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCpfVT.VVFZZq:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFcG5u(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCpfVT.VV3M1Q:
    tp = CC38xH()
   VVezZF, VV7Z6a = FFcN34()
   tagFound  = False
   if mode in (CCpfVT.VV4cXk, CCpfVT.VV44pv):
    VVuwbt = {}
   else:
    VVuwbt = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFzQfp(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCpfVT.VVzIX9:
        if sTypeInt in VVezZF:
         STYPE = VV7Z6a[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVuwbt.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVuwbt.append(tRow)
        else:
         VVuwbt.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCpfVT.VV4cXk:
         VVuwbt[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCpfVT.VV44pv:
         VVuwbt[chName] = refCode
        elif mode == CCpfVT.VVFZZq:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVuwbt.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVuwbt.append(tRow)
         else:
          VVuwbt.append(tRow)
        elif mode == CCpfVT.VV3M1Q:
         if sTypeInt in VVezZF:
          STYPE = VV7Z6a[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVNLQ6(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVuwbt.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVuwbt.append(tRow)
         else:
          VVuwbt.append(tRow)
        elif mode == CCpfVT.VVUzBc:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVuwbt.append((chName, chProv, sat, refCode))
        elif mode == CCpfVT.VVDM5S:
         VVuwbt.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVuwbt and VVUZCj:
    FF23yv(SELF, "No services found!")
   return VVuwbt
  else:
   if VV3Thx:
    FFl2xw(SELF, lamedbFile)
   return None
 def VV0hYf(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFcG5u(path)
   if lines:
    newRows  = []
    VVuwbt = CCpfVT.VVPQV0(self, self.VVDM5S)
    if VVuwbt:
     lines = set(lines)
     for item in VVuwbt:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVuwbt = newRows
      VVuwbt.sort(key=lambda x: x[0].lower())
      VVf1jQ = ("", self.VVgf4e, [])
      VViQOR = ("Zap", self.VVYgao, [])
      self.VVIoit(VVeBho=VVuwbt, VViQOR=VViQOR, VVf1jQ=VVf1jQ)
     else:
      FFx6I1(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVuwbt)))
   else:
    FFuW4T(self, "No active Parental Control services.", FFChu1())
  else:
   FFl2xw(self, path)
 def VV1XuO(self):
  VVuwbt = CCpfVT.VVPQV0(self, self.VVUzBc)
  if VVuwbt:
   VVuwbt.sort(key=lambda x: x[0].lower())
   VVf1jQ = ("" , self.VVgf4e, [])
   VViQOR  = ("Zap", self.VVYgao, [])
   self.VVIoit(VVeBho=VVuwbt, VViQOR=VViQOR, VVf1jQ=VVf1jQ)
  else:
   FFuW4T(self, "No hidden services.", FFChu1())
 def VVOJRA(self):
  totT, totC, totA, totS, totS2, satList = self.VVmQto()
  txt = FFKY60("Total Transponders:\n\n", VV4E8E)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFKY60("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV4E8E)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFRfrW(item), satList.count(item))
  FFx6I1(self, txt)
 def VVmQto(self):
  lamedbFile, disabledFile = CCpfVT.VVuDPd()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFl2xw(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVyVyr(self)   : self.VVtTkw(True)
 def VVN8Ub(self) : self.VVtTkw(False)
 def VVtTkw(self, isWithPIcons):
  piconsPath = CCgMHO.VV4aVy()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCgMHO.VVl27c(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVuwbt = CCpfVT.VVPQV0(self, self.VVDM5S)
    if VVuwbt:
     channels = []
     for (chName, chProv, sat, refCode) in VVuwbt:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFQwIx(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVuwbt)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVOCz2(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVOCz2("PIcons Path"  , piconsPath)
     txt += VVOCz2("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVOCz2("Total services" , totalServices)
     txt += VVOCz2("With PIcons"  , totalWithPIcons)
     txt += VVOCz2("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFx6I1(self, txt)
     else:
      VVf1jQ     = (""      , self.VVgf4e , [])
      if isWithPIcons : VVzVsH = ("Export Current PIcon", self.VVpzUJ  , [])
      else   : VVzVsH = None
      VVSWdY     = ("Statistics", FFx6I1, [txt])
      VViQOR      = ("Zap", self.VVYgao, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVIoit(VVeBho=channels, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VVSWdY=VVSWdY, VVzVsH=VVzVsH)
   else:
    FF23yv(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF23yv(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVgf4e(self, VVgIs9, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFEjmz(self, fncMode=CCdLyC.VV3zQg, refCode=refCode, chName=chName, text=txt)
 def VVpzUJ(self, VVgIs9, title, txt, colList):
  png, path = CCgMHO.VVNJD6(colList[3], colList[0])
  if path:
   CCgMHO.VVzF96(self, png, path)
 @staticmethod
 def VVuDPd():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVr0Jc():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVD1CC(self, isEnable):
  lamedbFile, disabledFile = CCpfVT.VVuDPd()
  if isEnable and not fileExists(disabledFile):
   FFuW4T(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF23yv(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFyVJ3(self, boundFunction(self.VV6mRJ, isEnable), "%s Hidden Channels ?" % word)
 def VV6mRJ(self, isEnable):
  lamedbFile , disabledFile = CCpfVT.VVuDPd()
  lamedb5File, diabled5File = CCpfVT.VVr0Jc()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FF0eVO()
  if res == 0 : FFuW4T(self, "Hidden List %s" % word)
  else  : FF23yv(self, "Error while restoring:\n\n%s" % fileName)
 def VVZEoL(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FF818p(self, cmd)
 def VVgCsy(self):
  lamedbFile, disabledFile = CCpfVT.VVuDPd()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFFaNy("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFcG5u(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFFaNy("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FF0eVO()
   FFx6I1(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFl2xw(self, lamedbFile)
class CCdLyC(Screen):
 VVFrdh  = 0
 VVTSD8   = 1
 VVX1bN   = 2
 VV3zQg    = 3
 VVNEqF    = 4
 VVFv3p   = 5
 VVSjYd   = 6
 VVVW19    = 7
 VVvqxH   = 8
 VVWGJY   = 9
 VVZ1XQ   = 10
 VVi6Se   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFDOid(VVXzV5, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVFrdh)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFKY60("%s\n", VVcP3M) % VVJwpo
  FFBDfs(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVOxzI })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self["myLabel"].VVqzy0(textOutFile="chann_info")
  if   self.fncMode == self.VVFrdh : fnc = self.VVki2m_VVFrdh
  elif self.fncMode == self.VVTSD8  : fnc = self.VVki2m_VVFrdh
  elif self.fncMode == self.VVX1bN  : fnc = self.VVki2m_VVFrdh
  elif self.fncMode == self.VV3zQg  : fnc = self.VVki2m_VV3zQg
  elif self.fncMode == self.VVNEqF  : fnc = self.VVki2m_VVNEqF
  elif self.fncMode == self.VVFv3p  : fnc = self.VVki2m_VVFv3p
  elif self.fncMode == self.VVSjYd  : fnc = self.VVki2m_VVSjYd
  elif self.fncMode == self.VVVW19  : fnc = self.VVki2m_VVVW19
  elif self.fncMode == self.VVvqxH  : fnc = self.VVki2m_VVvqxH
  elif self.fncMode == self.VVWGJY : fnc = self.VVki2m_VVWGJY
  elif self.fncMode == self.VVZ1XQ  : fnc = self.VVki2m_VVZ1XQ
  elif self.fncMode == self.VVi6Se : fnc = self.VVki2m_VVi6Se
  self["myLabel"].setText("\n   Reading Info ...")
  FFewwi(fnc)
 def VVOuln(self, err):
  self["myLabel"].setText(err)
  FFIRRt(self["myTitle"], "#22200000")
  FFIRRt(self["myBody"], "#22200000")
  self["myLabel"].FFIRRtColor("#22200000")
  self["myLabel"].VVTNO5()
 def VVki2m_VVFrdh(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  self.refCode = refCode
  self.VV2ntQ(chName)
 def VVki2m_VV3zQg(self):
  self.VV2ntQ(self.chName)
 def VVki2m_VVNEqF(self):
  self.VV2ntQ(self.chName)
 def VVki2m_VVFv3p(self):
  self.VV2ntQ(self.chName)
 def VVki2m_VVSjYd(self):
  self.VV2ntQ("Picon Info")
 def VVki2m_VVVW19(self):
  self.VV2ntQ(self.chName)
 def VVki2m_VVvqxH(self):
  self.VV2ntQ(self.chName)
 def VVki2m_VVWGJY(self):
  self.VV2ntQ(self.chName)
 def VVki2m_VVZ1XQ(self):
  self.chUrl = self.refCode + self.callingSELF.VVYKXF(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VV2ntQ(self.chName)
 def VVki2m_VVi6Se(self):
  self.VV2ntQ(self.chName)
 def VV2ntQ(self, title):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VViyAN(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFKY60(self.VVWlaG(tUrl), VVLLOq)
  if not self.epg:
   epg = self.VVcm8J(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV3SHU(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCgMHO.VVNJD6(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV3SHU(path)
  self.VVIXOl()
  self.VVBxvO()
  self["myLabel"].setText(self.text, VVJQke=VVIFZO)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVTNO5(minHeight=minH)
 def VVBxvO(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFqdX4(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVsReN(FFmq3z(url))
  if epg:
   self.text += "\n" + FFMugM("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVIXOl()
 def VVIXOl(self):
  if not self.piconShown and self.picUrl:
   path, err = FFmoGG(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV3SHU(path)
    if self.piconShown and self.refCode:
     self.VVd5AT(path, self.refCode)
 def VVd5AT(self, path, refCode):
  if path and fileExists(path) and os.system(FFFaNy("which ffmpeg")) == 0:
   pPath = CCgMHO.VV4aVy()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFFaNy("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV3SHU(self, path):
  if path and fileExists(path):
   err, w, h = self.VVGg61(path)
   if not err:
    if h > w:
     self.VVMIyq(self["myPicF"], w, h, True)
     self.VVMIyq(self["myPic"] , w, h, False)
   allOK = FFAVQ4(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVMIyq(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVGg61(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFKH1d(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VViyAN(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFKY60(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVOCz2(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFKY60(state, VVCyLg)
   txt += "State\t: %s\n" % state
  w = FFeTHY(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFeTHY(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVEyX0(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVOCz2(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVOCz2(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVOCz2(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVV60t()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVnF0N()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = self.VV5MSE()
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFKY60("IPTV", VV4E8E)
   txt += self.VVtCMA(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVPO7A(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC38xH()
    tpTxt, namespace = tp.VVjni9(refCode)
    del tp
    if tpTxt:
     txt += FFKY60("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFKY60("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVOCz2(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVOCz2(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVOCz2(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVOCz2(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVOCz2(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVOCz2(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVOCz2(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVOCz2(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVOCz2(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVEyX0(info):
  if info:
   aspect = FFeTHY(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVOCz2(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFeTHY(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVpUwl(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV5MSE(self):
  fPath, fDir, fName = CCpqJe.VVd6oA(self)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVpUwl(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVV60t(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVnF0N(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVPO7A(self, refCode, iptvRef, chName):
  refCode = FFEfck(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFGKC4(VVrXSk + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFGKC4(VVrXSk + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVeBho = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVrXSk + item
   if fileExists(path):
    txt = FFGKC4(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVeBho.append(bName)
  txt = self.Sep
  if VVeBho:
   if len(VVeBho) == 1:
    txt += "%s\t: %s\n" % (FFKY60("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVeBho[0])
   else:
    txt += FFKY60("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVeBho):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVcm8J(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VV1pbF(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VV1pbF(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VV1pbF(event, 0)
     except:
      pass
  return epg
 def VV1pbF(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVcqiV(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFKY60(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFKY60(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFv8BC(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFv8BC(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFSof4(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFSof4(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFSof4(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFKY60(evShort, VVhHzk)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFKY60(evDesc , VVhHzk)
    if txt:
     txt = FFKY60("\n%s\n%s Event:\n%s\n" % (VVJwpo, ("Current", "Next")[evNum], VVJwpo), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVtCMA(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFlKLF(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CClqge()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVNEsx(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFKY60("URL:", VV4E8E) + "\n%s\n" % self.VVWlaG(decodedUrl)
  else:
   txt = "\n"
   txt += FFKY60("Reference:", VV4E8E) + "\n%s\n" % refCode
  return txt
 def VVWlaG(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVt4jw:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVsReN(self, decodedUrl):
  if not FFeI9s():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCy3Ly.VV8ofO(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCy3Ly.VVSslx(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVY5NI(tDict)
   elif uType == "movie" : epg, picUrl = self.VVCOz6(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVY5NI(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCy3Ly.VVvKvd(item, "title"    , is_base64=True )
     lang    = CCy3Ly.VVvKvd(item, "lang"         ).upper()
     description   = CCy3Ly.VVvKvd(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCy3Ly.VVvKvd(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCy3Ly.VVvKvd(item, "start_timestamp"      )
     stop_timestamp  = CCy3Ly.VVvKvd(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCy3Ly.VVvKvd(item, "stop_timestamp"       )
     now_playing   = CCy3Ly.VVvKvd(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVbwNy, ""
      else     : color, txt = VVCyLg , "    (CURRENT EVENT)"
      epg += FFKY60("_" * 32 + "\n", VVcP3M)
      epg += FFKY60("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFKY60(description, VVLLOq)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVioD7(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVCOz6(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCy3Ly.VVvKvd(item, "movie_image" )
    genre  = CCy3Ly.VVvKvd(item, "genre"   ) or "-"
    plot  = CCy3Ly.VVvKvd(item, "plot"   ) or "-"
    cast  = CCy3Ly.VVvKvd(item, "cast"   ) or "-"
    rating  = CCy3Ly.VVvKvd(item, "rating"   ) or "-"
    director = CCy3Ly.VVvKvd(item, "director"  ) or "-"
    releasedate = CCy3Ly.VVvKvd(item, "releasedate" ) or "-"
    duration = CCy3Ly.VVvKvd(item, "duration"  ) or "-"
    try:
     lang = CCy3Ly.VVvKvd(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFKY60(cast, VVLLOq)
    epg += "Plot:\n%s"    % FFKY60(self.VVcqiV(plot), VVLLOq)
   except:
    pass
  return epg, movie_image
 def VVcqiV(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VV5u14(evTxt, lang)
   return CCdLyC.VVF3dm(txt).strip() or evTxt
 @staticmethod
 def VVF3dm(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV5u14(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFob6x(txt))
   txt, err = CCy3Ly.VVSslx(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFmq3z(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVioD7(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVfJDu(SELF):
  if not CCoCKj.VV8GeH(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(SELF)
  err = url =  fSize = resumable = ""
  if FFUVTe(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CClqge.VV8lKz(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CClqge.VVggfkHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FF23yv(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCpqJe.VVhdHk(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFKY60(" (M3U/M3U8 File)", VVLLOq)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVCkU8(subj, val):
   return "%s\n%s\n\n" % (FFKY60("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVCkU8(title , fSize or "?")
  txt += VVCkU8("Name" , chName)
  txt += VVCkU8("URL" , url)
  if resumable: txt += VVCkU8("Supports Download-Resume", resumable)
  if err  : txt += FFKY60("Error:\n", VVCyLg) + err
  FFx6I1(SELF, txt, title=title)
 def VVOxzI(self):
  if VVt4jw:
   def VVOCz2(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
   n = ("info" , "refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (info , refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVOCz2(n[i], v[i])
   if "chCode" in iptvRef:
    p = CClqge()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVNEsx(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVOCz2(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVJwpo, txt))
   FFU7uG(self, "Saved to:", 1000)
class CClqge():
 def __init__(self):
  self.VVbRw9  = ""
  self.VVj2cG   = ""
  self.VVhoTd  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVeXVn(self, url, mac, VVxzdz=True):
  self.VVbRw9 = ""
  self.VVj2cG  = ""
  self.VVhoTd = ""
  host = self.VVNH2U(url)
  if not host:
   if VVxzdz:
    self.VVxzdzor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVTYAa(mac)
  if not host:
   if VVxzdz:
    self.VVxzdzor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVbRw9 = host
  self.VVj2cG  = mac
  self.VVhoTd = ""
  return True
 def VVNH2U(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  return url
 def VVTYAa(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVK9xt(self, VVxzdz=True):
  err = ""
  try:
   token, err = self.VVZvIS()
   if token:
    self.VVhoTd = token
    return token, self.VVswlh(), ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if VVxzdz:
   self.VVxzdzor(tErr)
  return "", "", tErr
 def VVZvIS(self):
  res, err = self.VVWwGq(self.VVhGnw())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVbRw9:
   self.VVbRw9 = self.VVbRw9.replace(urlPath, "")
   res, err = self.VVWwGq(self.VVhGnw())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCy3Ly.VVvKvd(tDict["js"], "token")
    return token.strip(), ""
   except:
    pass
  return "", err
 def VVswlh(self):
  res, err = self.VVWwGq(self.VV3rqy())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVd6Lv(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV0qzL()
  if len(rows) < 10:
   rows = self.VVRhf2()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVbRw9 ))
   rows.append(("MAC (from URL)" , self.VVj2cG ))
   rows.append(("Token"   , self.VVhoTd ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVj2cG ))
   rows.append(("2", self.colored_server, "Host" , self.VVbRw9 ))
   rows.append(("2", self.colored_server, "Token" , self.VVhoTd ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVbp1c(self, isPhp=True, VVxzdz=False):
  token, profile, tErr = self.VVK9xt(VVxzdz)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVnTZB()
  res, err = self.VVWwGq(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCy3Ly.VVvKvd(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFob6x(span.group(2))
     pass1 = FFob6x(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VV0qzL(self):
  m3u_Url, err = self.VVbp1c()
  rows = []
  if m3u_Url:
   res, err = self.VVWwGq(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFv8BC(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFv8BC(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVRhf2(self):
  token, profile, tErr = self.VVK9xt()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFLnw8(val): val = FFkCIh(val.decode("UTF-8"))
     else     : val = self.VVj2cG
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFv8BC(int(parts[1]))
      if parts[2] : ends = FFv8BC(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFv8BC(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVYKXF(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVcZlV(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVK9xt(VVxzdz=False)
  if not token:
   return ""
  res, err = self.VVWwGq(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCy3Ly.VVvKvd(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVIa5P(self):
  return self.VVbRw9 + "/server/load.php?"
 def VVhGnw(self):
  return self.VVIa5P() + "type=stb&action=handshake&token=&mac=%s" % self.VVj2cG
 def VV3rqy(self):
  return self.VVIa5P() + "type=stb&action=get_profile"
 def VVc8hp(self, mode):
  url = self.VVIa5P() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVXahj(self, catID):
  return self.VVIa5P() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVFgLC(self, mode, catID, page):
  url = self.VVIa5P() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVclSV(self, mode, searchName, page):
  return self.VVIa5P() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVDjt5(self, mode, catID):
  return self.VVIa5P() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVcZlV(self, mode, chCm, serCode, serId):
  url = self.VVIa5P() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVnTZB(self):
  return self.VVIa5P() + "type=itv&action=create_link"
 def VV6Lk7(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVwtHq(catID, stID, chNum)
  query = self.VVBG8a(mode, FF7l1d(host), FF7l1d(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVBG8a(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVNEsx(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVBG8a(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFkCIh(host)
  mac   = FFkCIh(mac)
  valid = False
  if self.VVNH2U(playHost) and self.VVNH2U(host) and self.VVNH2U(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVWwGq(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CClqge.VVggfkHeader()
   if self.VVhoTd:
    headers["Authorization"] = "Bearer %s" % self.VVhoTd
   if useCookies : cookies = {"mac": self.VVj2cG, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVHykG(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CClqge.VVggfkHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVggfkHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVg9UQ(host, mac, tType, action, keysList=[]):
  myPortal = CClqge()
  ok = myPortal.VVeXVn(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVK9xt(VVxzdz=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVWwGq(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVmDnz(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVmDnz(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVxzdzor(self, err, title="Portal Browser"):
  FF23yv(self, str(err), title=title)
 def VVI3A4(self, mode):
  if   mode in ("itv"  , CCy3Ly.VVaO1A , CCy3Ly.VVpUfk)  : return "Live"
  elif mode in ("vod"  , CCy3Ly.VVjc9y , CCy3Ly.VVV3u0)  : return "VOD"
  elif mode in ("series" , CCy3Ly.VVP7vl , CCy3Ly.VVqvJr) : return "Series"
  else                          : return "IPTV"
 def VVZfGl(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVI3A4(mode), searchName)
 def VVpjMm(self, catchup=False):
  VVWaOb = []
  VVWaOb.append(("Live"    , "live"  ))
  VVWaOb.append(("VOD"    , "vod"   ))
  VVWaOb.append(("Series"   , "series"  ))
  if catchup:
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Catchup TV" , "catchup"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Account Info." , "accountInfo" ))
  return VVWaOb
 @staticmethod
 def VVVyR1(decodedUrl):
  m3u_Url = ""
  p = CClqge()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVNEsx(decodedUrl)
  if valid:
   ok = p.VVeXVn(host, mac, VVxzdz=False)
   if ok:
    m3u_Url, err = p.VVbp1c(isPhp=False, VVxzdz=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VV8lKz(decodedUrl):
  p = CClqge()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVNEsx(decodedUrl)
  if valid:
   ok = p.VVeXVn(host, mac, VVxzdz=False)
   if ok:
    try:
     chUrl = p.VVYKXF(mode, chCm, epNum, epId)
     return FFmq3z(chUrl)
    except Exception as e:
     pass
  return ""
class CCG19q(CClqge):
 def __init__(self):
  CClqge.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVoiqq(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVNEsx(decodedUrl)
  if valid:
   if self.VVeXVn(host, mac, VVxzdz=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VV0thB(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVYKXF(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VV05MZ(chUrl)
  if newIptvRef:
   success = self.VV5kA7(self.iptvRef, newIptvRef)
   if passedSELF:
    FFFZZb(passedSELF, newIptvRef, VVYxnj=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFFZZb(self, newIptvRef, VVYxnj=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VV05MZ(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV5kA7(self, oldCode, newCode):
  bPath = FFNtMz()
  if bPath:
   txt = FFGKC4(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FF0eVO()
    return True
  return False
class CCA6xu(CCG19q):
 def __init__(self, passedSession):
  CCG19q.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVjuUo, iPlayableService.evEOF: self.VVOWcj, iPlayableService.evEnd: self.VVFbF4})
  except:
   pass
 def VVjuUo(self):
  self.starttime = iTime()
 def VVOWcj(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self.passedSession, isFromSession=True)
    if iptvRef and not FFUVTe(decodedUrl):
     CCWCk4(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVFbF4(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVLO6U)
  except:
   self.timer1.callback.append(self.VVLO6U)
  self.timer1.start(100, True)
 def VVLO6U(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVoiqq(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCjjWk.VVO8OD:
       self.VV0thB(self.passedSession, isFromSession=True)
class CCySN5():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVQcDU(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCy3Ly.VVfTVS(name):
   return CCy3Ly.VVtg6G(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVNFAq(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVxCdj(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVsBqy(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVJ6l1(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCoCKj(CClqge):
 def __init__(self):
  CClqge.__init__(self)
 def VVQm9y(self):
  if CCoCKj.VV8GeH(self):
   FFJ3IJ(self, self.VV0ti8, title="Searching ...")
 def VV91UW(self, winSession, url, mac):
  if CCoCKj.VV8GeH(self):
   if self.VVeXVn(url, mac):
    FFJ3IJ(winSession, self.VVH5z3, title="Checking Server ...")
   else:
    FF23yv(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV0ti8(self):
  path = CCy3Ly.VVbLIu()
  lines = FF8xGt('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFcd50(1)))
  if lines:
   lines.sort()
   VVWaOb = []
   for line in lines:
    VVWaOb.append((line, line))
   OKBtnFnc = self.VVnHNg
   VVIAKx = ("Delete File", boundFunction(self.VV9lYV, boundFunction(FFJ3IJ, self, self.VV0ti8, title="Searching ...")))
   FFg6MQ(self, None, title="Select Portals File", VVWaOb=VVWaOb, width=1200, OKBtnFnc=OKBtnFnc, VVIAKx=VVIAKx)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF23yv(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV9lYV(self, cbFnc, VVsszyObj, path):
  FFyVJ3(self, boundFunction(self.VVUI2c, cbFnc, VVsszyObj, path), "Delete this file ?\n\n%s" % path)
 def VVUI2c(self, cbFnc, VVsszyObj, path):
  os.system(FFFaNy("rm -f '%s'" % path))
  VVsszyObj.cancel()
  cbFnc()
 def VVnHNg(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = FFiPeJ(path, self)
   if enc == -1:
    return
   self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVKy5s, path, enc)
       , VVn4v8 = boundFunction(self.VVS0Ux, menuInstance, path))
 def VVKy5s(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVPaCP(totLines)
  progBarObj.VV6IKE = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVKTFH(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip() or "-"
     host = self.VVNH2U(url)
     mac  = self.VVTYAa(mac)
     if host and mac and progBarObj:
      progBarObj.VV6IKE.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip() or "-"
      host = self.VVNH2U(url)
      mac  = self.VVTYAa(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VV6IKE.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVS0Ux(self, menuInstance, path, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VV6IKE:
   VVINMZ  = ("Home Menu", FF2wr6, [])
   VVzVsH  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVSWdY = ("Edit File" , boundFunction(self.VV941m, path) , [])
   VV76K2 = ("Open as M3U", self.VVN4nE     , [])
   VViQOR  = ("Select"  , self.VV91UW_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVFXpL  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVgIs9 = FFemUu(self, None, title=title, header=header, VVeBho=VV6IKE, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH, VVKeoU="#0a001122", VVJRMb="#0a001122", VVTMiH="#0a001122", VVeFdq="#00004455", VVmeUl="#0a333333", VV98nY="#11331100", VVhUO0=True, searchCol=1)
   if not VVbWpI:
    FFU7uG(VVgIs9, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVbWpI:
    FF23yv(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVN4nE(self, VVgIs9, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFJ3IJ(VVgIs9, boundFunction(self.VVmMAg, VVgIs9, host, mac), title="Checking Server ...")
 def VVmMAg(self, VVgIs9, host, mac):
  p = CClqge()
  m3u_Url = ""
  ok = p.VVeXVn(host, mac, VVxzdz=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVbp1c(VVxzdz=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVJ06o(title, m3u_Url)
  else:
   FF23yv(self, err or "No response from Server !", title=title)
 def VV91UW_fromMacFiles(self, VVgIs9, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV91UW(VVgIs9, url, mac)
 def VV941m(self, path, VVgIs9, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCpY82(self, path, VVn4v8=boundFunction(self.VVgxM4, VVgIs9), curRowNum=rowNum)
  else    : FFl2xw(self, path)
 def VVb9Hj(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFkCIh(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVH5z3(self):
  token, profile, tErr = self.VVK9xt()
  if token:
   VVWaOb  = self.VVpjMm()
   OKBtnFnc = self.VVtMBr
   VVinCp = ("Home Menu", FF2wr6)
   FFg6MQ(self, None, title="Portal Resources (MAC=%s)" % self.VVj2cG, VVWaOb=VVWaOb, OKBtnFnc=OKBtnFnc, VVinCp=VVinCp)
 def VVtMBr(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFJ3IJ(menuInstance, boundFunction(self.VVx9FC, mode), title="Reading Categories ...")
   else : FFJ3IJ(menuInstance, boundFunction(self.VVv7fc, menuInstance, title), title="Reading Account ...")
 def VVv7fc(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVd6Lv(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVj2cG)
  VVINMZ  = ("Home Menu" , FF2wr6, [])
  if totCols == 2:
   VVzVsH = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVzVsH = ("More Info.", boundFunction(self.VVtxoK, menuInstance) , [])
  FFemUu(self, None, title=title, width=1200, header=header, VVeBho=rows, VVEHj0=widths, VVZWCz=26, VVINMZ=VVINMZ, VVzVsH=VVzVsH, VVKeoU="#0a00292B", VVJRMb="#0a002126", VVTMiH="#0a002126", VVeFdq="#00000000", searchCol=searchCol)
 def VVtxoK(self, menuInstance, VVgIs9, title, txt, colList):
  VVgIs9.cancel()
  FFJ3IJ(menuInstance, boundFunction(self.VVv7fc, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVx9FC(self, mode):
  token, profile, tErr = self.VVK9xt()
  if not token:
   return
  res, err = self.VVWwGq(self.VVc8hp(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCySN5()
     chList = tDict["js"]
     for item in chList:
      Id   = CCy3Ly.VVvKvd(item, "id"       )
      Title  = CCy3Ly.VVvKvd(item, "title"      )
      censored = CCy3Ly.VVvKvd(item, "censored"     )
      Title = processChanName.VVxCdj(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVkBs8:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVI3A4(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx(mode)
   mName = self.VVI3A4(mode)
   VViQOR   = ("Show List"   , boundFunction(self.VVjELW, mode) , [])
   VVINMZ  = ("Home Menu"   , FF2wr6         , [])
   if mode in ("vod", "series"):
    VVSWdY = ("Find in %s" % mName , boundFunction(self.VVGWBD, mode), [])
   else:
    VVSWdY = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFemUu(self, None, title=title, width=1200, header=header, VVeBho=list, VVEHj0=widths, VVZWCz=30, VVINMZ=VVINMZ, VVSWdY=VVSWdY, VViQOR=VViQOR, VVKeoU=VVKeoU, VVJRMb=VVJRMb, VVTMiH=VVTMiH, VVeFdq=VVeFdq)
  else:
   FF23yv(self, "Could not get Categories from server!", title=title)
 def VVTfOp(self, mode, VVgIs9, title, txt, colList):
  FFJ3IJ(VVgIs9, boundFunction(self.VVgc8g, mode, VVgIs9, title, txt, colList), title="Downloading ...")
 def VVgc8g(self, mode, VVgIs9, title, txt, colList):
  token, profile, tErr = self.VVK9xt()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVWwGq(self.VVXahj(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCy3Ly.VVvKvd(item, "id"    )
      actors   = CCy3Ly.VVvKvd(item, "actors"   )
      added   = CCy3Ly.VVvKvd(item, "added"   )
      age    = CCy3Ly.VVvKvd(item, "age"   )
      category_id  = CCy3Ly.VVvKvd(item, "category_id" )
      description  = CCy3Ly.VVvKvd(item, "description" )
      director  = CCy3Ly.VVvKvd(item, "director"  )
      genres_str  = CCy3Ly.VVvKvd(item, "genres_str"  )
      name   = CCy3Ly.VVvKvd(item, "name"   )
      path   = CCy3Ly.VVvKvd(item, "path"   )
      screenshot_uri = CCy3Ly.VVvKvd(item, "screenshot_uri" )
      series   = CCy3Ly.VVvKvd(item, "series"   )
      cmd    = CCy3Ly.VVvKvd(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VViQOR  = ("Play"    , boundFunction(self.VVfs5I, mode)       , [])
   VVf1jQ = (""     , boundFunction(self.VVNacH, mode)     , [])
   VVINMZ = ("Home Menu"   , FF2wr6               , [])
   VV76K2 = ("Download Options" , boundFunction(self.VVBmzF, mode, "sp", seriesName) , [])
   VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVaFrk, mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVFXpL  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFemUu(self, None, title=seriesName, width=1200, header=header, VVeBho=list, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VVKeoU="#0a00292B", VVJRMb="#0a002126", VVTMiH="#0a002126", VVeFdq="#00000000")
  else:
   FF23yv(self, "Could not get Episodes from server!", title=seriesName)
 def VVGWBD(self, mode, VVgIs9, title, txt, colList):
  VVWaOb = []
  VVWaOb.append(("Keyboard"  , "manualEntry"))
  VVWaOb.append(("From Filter" , "fromFilter"))
  FFg6MQ(self, boundFunction(self.VVUqBj, VVgIs9, mode), title="Input Type", VVWaOb=VVWaOb, width=400)
 def VVUqBj(self, VVgIs9, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF3PZZ(self, boundFunction(self.VVVKZr, VVgIs9, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCJJAn(self)
    filterObj.VV5fxX(boundFunction(self.VVVKZr, VVgIs9, mode))
 def VVVKZr(self, VVgIs9, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVZfGl(mode, searchName)
   if len(searchName) < 3:
    FF23yv(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCySN5()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVsBqy([searchName]):
     FF23yv(self, processChanName.VVJ6l1(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVjzgT(mode, searchName, "", searchName)
 def VVjELW(self, mode, VVgIs9, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVjzgT(mode, bName, catID, "")
 def VVjzgT(self, mode, bName, catID, searchName):
  self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVTaCG, mode, bName, catID, searchName)
      , VVn4v8 = boundFunction(self.VVivY1, mode, bName, catID, searchName))
 def VVivY1(self, mode, bName, catID, searchName, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVZfGl(mode, searchName)
  else   : title = "%s : %s" % (self.VVI3A4(mode), bName)
  if VV6IKE:
   VV76K2 = None
   VVSWdY = None
   if mode == "series":
    VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx("series2")
    VViQOR  = ("Episodes", boundFunction(self.VVTfOp, mode) , [])
   else:
    VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx("")
    VViQOR  = ("Play"    , boundFunction(self.VVfs5I, mode)           , [])
    VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVaFrk, mode, bName)       , [])
    VV76K2 = ("Download Options" , boundFunction(self.VVBmzF, mode, "vp" if mode == "vod" else "", "") , [])
   VVf1jQ = (""      , boundFunction(self.VV1vUN, mode)          , [])
   VVINMZ = ("Home Menu"    , FF2wr6                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVFXpL  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVgIs9 = FFemUu(self, None, title=title, header=header, VVeBho=VV6IKE, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VVKeoU=VVKeoU, VVJRMb=VVJRMb, VVTMiH=VVTMiH, VVeFdq=VVeFdq, VVhUO0=True, searchCol=1)
   if not VVbWpI:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVgIs9.VVeZJv(VVgIs9.VVfnQk() + tot)
    if threadErr: FFU7uG(VVgIs9, "Error while reading !", 2000)
    else  : FFU7uG(VVgIs9, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF23yv(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF23yv(self, "Could not get list from server !", title=title)
 def VV1vUN(self, mode, VVgIs9, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFEjmz(self, fncMode=CCdLyC.VVi6Se, portalHost=self.VVbRw9, portalMac=self.VVj2cG, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVGVlC(mode, VVgIs9, title, txt, colList)
 def VVNacH(self, mode, VVgIs9, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFKY60(colList[10], VVLLOq)
  txt += "Description:\n%s" % FFKY60(colList[11], VVLLOq)
  self.VVGVlC(mode, VVgIs9, title, txt, colList)
 def VVGVlC(self, mode, VVgIs9, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVhqCe(mode, colList)
  refCode, chUrl = self.VV6Lk7(self.VVbRw9, self.VVj2cG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFEjmz(self, fncMode=CCdLyC.VVZ1XQ, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVTaCG(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVK9xt()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VV6IKE, total_items, max_page_items, err = self.VVCSjd(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VV6IKE and total_items > -1 and max_page_items > -1:
    progBarObj.VVPaCP(total_items)
    progBarObj.VVKTFH(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVCSjd(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VV2BvL()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VV6IKE += list
      progBarObj.VVKTFH(len(list), True)
  except:
   pass
 def VVCSjd(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVclSV(mode, searchName, page)
  else   : url = self.VVFgLC(mode, catID, page)
  res, err = self.VVWwGq(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVOKet(CCy3Ly.VVvKvd(item, "total_items" ))
     max_page_items = self.VVOKet(CCy3Ly.VVvKvd(item, "max_page_items" ))
     processChanName = CCySN5()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCy3Ly.VVvKvd(item, "id"    )
      name   = CCy3Ly.VVvKvd(item, "name"   )
      tv_genre_id  = CCy3Ly.VVvKvd(item, "tv_genre_id" )
      number   = CCy3Ly.VVvKvd(item, "number"   ) or str(counter)
      logo   = CCy3Ly.VVvKvd(item, "logo"   )
      screenshot_uri = CCy3Ly.VVvKvd(item, "screenshot_uri" )
      cmd    = CCy3Ly.VVvKvd(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVQcDU(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVaFrk(self, mode, bName, VVgIs9, title, txt, colList):
  FFJ3IJ(VVgIs9, boundFunction(self.VVe0pl, mode, bName, VVgIs9, title, txt, colList), title="Adding Channels ...")
 def VVe0pl(self, mode, bName, VVgIs9, title, txt, colList):
  bNameFile = CCy3Ly.VVQdXE_forBouquet(bName)
  num  = 0
  path = VVrXSk + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVrXSk + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVgIs9.VVnSZ7():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVhqCe(mode, row)
    refCode, chUrl = self.VV6Lk7(self.VVbRw9, self.VVj2cG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFiQxL(os.path.basename(path))
  self.VV0s4u(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVOKet(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVfs5I(self, mode, VVgIs9, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVhqCe(mode, colList)
  refCode, chUrl = self.VV6Lk7(self.VVbRw9, self.VVj2cG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVfTVS(chName):
   FFU7uG(VVgIs9, "This is a marker!", 300)
  else:
   FFJ3IJ(VVgIs9, boundFunction(self.VVrTij, mode, VVgIs9, chUrl), title="Playing ...")
 def VVrTij(self, mode, VVgIs9, chUrl):
  FFFZZb(self, chUrl, VVYxnj=False)
  self.session.open(CCjjWk, portalTableParam=(self, VVgIs9, mode))
 def VVWG3m(self, mode, VVgIs9, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVhqCe(mode, colList)
  refCode, chUrl = self.VV6Lk7(self.VVbRw9, self.VVj2cG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVhqCe(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV8GeH(SELF):
  try:
   import requests
   return True
  except:
   FFyVJ3(SELF, boundFunction(CCoCKj.VVzWEk, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVzWEk(SELF):
  from sys import version_info
  cmdUpd = FFkwB2(VV2iC7, "")
  if cmdUpd:
   cmdInst = FFNOBr(VVlyKc, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFsUMt(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FF5N91(SELF)
class CCy3Ly(Screen, CCoCKj):
 VVKq4h    = 0
 VVwEqE    = 1
 VVVcUH    = 2
 VVP47K    = 3
 VVl8ZK     = 4
 VV4pfK     = 5
 VVg40B     = 6
 VVHSGA     = 7
 VVhiUl      = 8
 VV94SL     = 9
 VVGIG8     = 10
 VVN1oI     = 11
 VVgIgi     = 12
 VVwEyz      = 13
 VV69DT      = 14
 VVg4BX      = 15
 VVjshi      = 16
 VV5BSA      = 17
 VVZJLJ    = 0
 VVaO1A   = 1
 VVjc9y   = 2
 VVP7vl   = 3
 VVTQsG  = 4
 VVURhr  = 5
 VVpUfk   = 6
 VVV3u0   = 7
 VVqvJr  = 8
 VVxlHg  = 9
 VVIdjS  = 10
 VVBMSg = 0
 VVPwqR = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFDOid(VVxulX, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVgIs9  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVk8EXData  = {}
  self.lastFindIptvName = ""
  CCoCKj.__init__(self)
  VVWaOb= self.VVtgNb()
  FFBDfs(self, title="IPTV", VVWaOb=VVWaOb)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
  FFFARc(self)
  if self.m3uOrM3u8File:
   self.VVr4eT(self.m3uOrM3u8File)
 def VVtgNb(self):
  files = self.VVmQLI()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVk8EX_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVk8EX_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVk8EX_fromM3u"  ))
  qUrl, iptvRef = self.VV2oNw()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVk8EX_fromCurrChan" ))
  VVWaOb = []
  if files:
   if self.VVgIs9:
    VVWaOb.append(("Add Current List to a New Bouquet"      , "VVguat"  ))
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("Change Current List References to Unique Codes"   , "VVLBEB"))
    VVWaOb.append(("Change Current List References to Identical Codes"  , "VVRNLT_rows" ))
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVhNDp"   ))
    VVWaOb.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VV3gZO"   ))
   else:
    VVWaOb += tList
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("M3U/M3U8 Channels Browser"        , "VV4uJX"   ))
    VVWaOb.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVWaOb.append(VVIEqe)
     VVWaOb.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("Count Available IPTV Channels"       , "VVW6N8"    ))
    VVWaOb.append(("Check Reference Codes Format"        , "VVSlCx"   ))
    VVWaOb.append(("Check System Acceptable Reference Types"     , "VVQqWB"   ))
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VV3WHB" ))
    VVWaOb.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVTsRH"  ))
    VVWaOb.append(("Change ALL References to Unique Codes"     , "VVDyTB" ))
    VVWaOb.append(("Change ALL References to Identical Codes"     , "VVRNLT_all" ))
  if not self.VVgIs9:
   if not files:
    VVWaOb += tList
   if not CCuRcG.VV1snA():
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("Download Manager"           , "dload_stat"    ))
  return VVWaOb
 def VV31gb(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVguat"   : FF3PZZ(self, self.VVguat, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVLBEB" : FFyVJ3(self, boundFunction(FFJ3IJ, self.VVgIs9, self.VVLBEB ), "Change Current List References to Unique Codes ?")
   elif item == "VVRNLT_rows" : FFyVJ3(self, boundFunction(FFJ3IJ, self.VVgIs9, self.VVRNLT   ), "Change Current List References to Identical Codes ?")
   elif item == "VVhNDp"   : self.VVhNDp(tTitle)
   elif item == "VV3gZO"   : self.VV3gZO(tTitle)
   elif item == "VVk8EX_fromPlayList" : FFJ3IJ(self, self.VVYCRs, title=title)
   elif item == "VVk8EX_fromM3u"  : FFJ3IJ(self, boundFunction(self.VV9S5o, 0), title=title)
   elif item == "VVk8EX_fromMac"  : self.VVQm9y()
   elif item == "VVk8EX_fromCurrChan" : self.VV91UW_fromCurrChan()
   elif item == "VV4uJX"   : self.VV4uJX()
   elif item == "iptvTable_live"   : FFJ3IJ(self, boundFunction(self.VVmyyn, self.VVHSGA ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFJ3IJ(self, boundFunction(self.VVmyyn, self.VVKq4h) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVJqrj()
   elif item == "VVW6N8"    : FFJ3IJ(self, self.VVW6N8)
   elif item == "VVSlCx"    : FFJ3IJ(self, self.VVSlCx)
   elif item == "VVQqWB"   : FFJ3IJ(self, self.VVQqWB)
   elif item == "VV3WHB"  : FFyVJ3(self, boundFunction(FFJ3IJ, self, self.VV3WHB ), "Continue ?")
   elif item == "VVTsRH"  : self.VVTsRH()
   elif item == "VVDyTB" : FFyVJ3(self, boundFunction(FFJ3IJ, self, self.VVDyTB ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVRNLT_all" : FFyVJ3(self, boundFunction(FFJ3IJ, self, self.VVRNLT  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCuRcG.VVcmaF(self)
   elif item == "VVXIWO"   : FFJ3IJ(self, boundFunction(CCpfVT.VVXIWO, self))
 def VV4uJX(self):
  if CCoCKj.VV8GeH(self):
   FFJ3IJ(self, boundFunction(self.VV9S5o, 1), title="Searching ...")
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VV31gb(item)
 def VVmyyn(self, mode):
  VVuwbt = self.VVeqFi(mode)
  if VVuwbt:
   VV76K2 = ("Current Service", self.VVQ1Nk  , [])
   VVSWdY = ("Options"  , self.VV6w2c    , [])
   VVzVsH = ("Filter"   , self.VV1ntj    , [])
   VViQOR  = ("Play"   , boundFunction(self.VVUVSs) , [])
   VVf1jQ = (""    , self.VVgP9T     , [])
   VVnz5d = (""    , self.VVIOwv      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVFXpL  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFemUu(self, None, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26
     , VViQOR=VViQOR, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH, VVf1jQ=VVf1jQ, VVnz5d=VVnz5d
     , VVKeoU="#0a00292B", VVJRMb="#0a002126", VVTMiH="#0a002126", VVeFdq="#00000000", VVhUO0=True, searchCol=1)
  else:
   if mode == self.VVHSGA: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF23yv(self, err)
 def VVIOwv(self, VVgIs9, title, txt, colList):
  self.VVgIs9 = VVgIs9
 def VV6w2c(self, VVgIs9, title, txt, colList):
  VVWaOb= self.VVtgNb()
  FFg6MQ(self, self.VV31gb, title="IPTV Tools", VVWaOb=VVWaOb)
 def VV1ntj(self, VVgIs9, title, txt, colList):
  VVWaOb = []
  VVWaOb.append(("All"         , "all"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Prefix of Selected Channel"   , "sameName" ))
  VVWaOb.append(("Suggest Words from Selected Channel" , "partName" ))
  VVWaOb.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Live TV"        , "live"  ))
  VVWaOb.append(("VOD"         , "vod"   ))
  VVWaOb.append(("Series"        , "series"  ))
  VVWaOb.append(("Uncategorised"      , "uncat"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Video"        , "video"  ))
  VVWaOb.append(("Audio"        , "audio"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("MKV"         , "MKV"   ))
  VVWaOb.append(("MP4"         , "MP4"   ))
  VVWaOb.append(("MP3"         , "MP3"   ))
  VVWaOb.append(("AVI"         , "AVI"   ))
  VVWaOb.append(("FLV"         , "FLV"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVFty5()
  if bNames:
   bNames.sort()
   VVWaOb.append(VVIEqe)
   for item in bNames:
    VVWaOb.append((item, "__b__" + item))
  filterObj = CCJJAn(self)
  filterObj.VVBzCy(VVWaOb, VVWaOb, boundFunction(self.VVZzZJ, VVgIs9))
 def VVZzZJ(self, VVgIs9, item=None):
  prefix = VVgIs9.VVZVaS(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVKq4h, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVwEqE , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVVcUH , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVP47K , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVHSGA  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVhiUl   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VV94SL  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVGIG8  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVN1oI  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVgIgi  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVwEyz   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV69DT   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVg4BX   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVjshi   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV5BSA   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVg40B  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVl8ZK  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VV4pfK  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVVcUH:
   VVWaOb = []
   chName = VVgIs9.VVZVaS(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVWaOb.append((item, item))
    if not VVWaOb and chName:
     VVWaOb.append((chName, chName))
    FFg6MQ(self, boundFunction(self.VVPWnP_partOfName, title), title="Words from Current Selection", VVWaOb=VVWaOb)
   else:
    VVgIs9.VVjSfv("Invalid Channel Name")
  else:
   words, asPrefix = CCJJAn.VVYNrj(words)
   if not words and mode in (self.VVl8ZK, self.VV4pfK):
    FFU7uG(self.VVgIs9, "Incorrect filter", 2000)
   else:
    FFJ3IJ(self.VVgIs9, boundFunction(self.VVA4cD, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVPWnP_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFJ3IJ(self.VVgIs9, boundFunction(self.VVA4cD, self.VVVcUH, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVtg6G(txt):
  return "#f#11ffff00#" + txt
 def VVA4cD(self, mode, words, asPrefix, title):
  VVuwbt = self.VVeqFi(mode=mode, words=words, asPrefix=asPrefix)
  if VVuwbt : self.VVgIs9.VVDgsH(VVuwbt, title)
  else  : self.VVgIs9.VVjSfv("Not found")
 def VVeqFi(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVuwbt = []
  files  = self.VVmQLI()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFGKC4(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVJjC4 = span.group(1)
    else : VVJjC4 = ""
    VVJjC4_lCase = VVJjC4.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVfTVS(chName): chNameMod = self.VVtg6G(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVJjC4, chType, refCode, url)
     ok = False
     tUrl = FFmq3z(url).lower()
     if mode == self.VVKq4h       : ok = True
     elif mode == self.VVg40B       : ok = True
     elif mode == self.VVN1oI:
      if CCy3Ly.VV8ofO(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVgIgi:
      if CCy3Ly.VV8ofO(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVHSGA:
      if CCy3Ly.VV8ofO(tUrl, compareType="live")  : ok = True
     elif mode == self.VVhiUl:
      if CCy3Ly.VV8ofO(tUrl, compareType="movie") : ok = True
     elif mode == self.VV94SL:
      if CCy3Ly.VV8ofO(tUrl, compareType="series") : ok = True
     elif mode == self.VVGIG8:
      if CCy3Ly.VV8ofO(tUrl, compareType="")   : ok = True
     elif mode == self.VVwEyz:
      if CCy3Ly.VV8ofO(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VV69DT:
      if CCy3Ly.VV8ofO(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVg4BX:
      if CCy3Ly.VV8ofO(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVjshi:
      if CCy3Ly.VV8ofO(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VV5BSA:
      if CCy3Ly.VV8ofO(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVwEqE:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVVcUH:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVP47K:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVl8ZK:
      if words[0] == VVJjC4_lCase:
       ok = True
     elif mode == self.VV4pfK:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVuwbt.append(row)
      chNum += 1
  if VVuwbt and mode == self.VVg40B:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVuwbt)
   for item in VVuwbt:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVuwbt = newRows
  return VVuwbt
 def VVguat(self, bName):
  if bName:
   FFJ3IJ(self.VVgIs9, boundFunction(self.VVLaVy, bName), title="Adding Channels ...")
 def VVLaVy(self, bName):
  num = 0
  path = VVrXSk + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVrXSk + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVgIs9.VVnSZ7():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FF0IQR(row[1]))
    totChange += 1
  FFiQxL(os.path.basename(path))
  self.VV0s4u(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVTsRH(self):
  txt = "Stream Type "
  VVWaOb = []
  VVWaOb.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVWaOb.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVWaOb.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVWaOb.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVWaOb.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVWaOb.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFg6MQ(self, self.VVWnoI, title="Change Reference Types to:", VVWaOb=VVWaOb)
 def VVWnoI(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVeNw8("1"   )
   elif item == "RT_4097" : self.VVeNw8("4097")
   elif item == "RT_5001" : self.VVeNw8("5001")
   elif item == "RT_5002" : self.VVeNw8("5002")
   elif item == "RT_8192" : self.VVeNw8("8192")
   elif item == "RT_8193" : self.VVeNw8("8193")
 def VVeNw8(self, rType):
  FFyVJ3(self, boundFunction(FFJ3IJ, self, boundFunction(self.VViHA2, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VViHA2(self, refType):
  totChange = 0
  files  = self.VVmQLI()
  if files:
   for path in files:
    txt = FFGKC4(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFiQxL(os.path.basename(path))
  self.VV0s4u(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVW6N8(self):
  totFiles = 0
  files  = self.VVmQLI()
  if files:
   totFiles = len(files)
  totChans = 0
  VVuwbt = self.VVeqFi()
  if VVuwbt:
   totChans = len(VVuwbt)
  FFx6I1(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVSlCx(self):
  files  = self.VVmQLI()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFGKC4(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVuV1K
   else    : color = VVCyLg
   totInvalid = FFKY60(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFKY60("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFx6I1(self, txt, title="Check IPTV References")
 def VVQqWB(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVrXSk + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFiQxL(os.path.basename(path))
  FF0eVO()
  acceptedList = []
  VVH5DQ = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVH5DQ:
   VV8PRc = FFx460(VVH5DQ)
   if VV8PRc:
    for service in VV8PRc:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVrXSk + userBName
  bFile = VVrXSk + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFFaNy("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFFaNy("rm -f '%s'" % path)
  os.system(cmd)
  FF0eVO()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVuV1K
    else     : res, color = "No" , VVCyLg
    txt += "    %s\t: %s\n" % (item, FFKY60(res, color))
   FFx6I1(self, txt, title=title)
  else:
   txt = FF23yv(self, "Could not complete the test on your system!", title=title)
 def VV3WHB(self):
  lameDbChans = CCpfVT.VVPQV0(self, CCpfVT.VV44pv)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVmQLI():
    toSave = False
    txt = FFGKC4(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV0s4u(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF23yv(self, 'No channels in "lamedb" !')
 def VVDyTB(self):
  files  = self.VVmQLI()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFcG5u(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVyE6u(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV0s4u(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVLBEB(self):
  iptvRefList = []
  files  = self.VVmQLI()
  if files:
   for path in files:
    txt = FFGKC4(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVgIs9.VVqaMa(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVyE6u(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVmQLI()
  if files:
   for path in files:
    lines = FFcG5u(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VV0s4u(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVyE6u(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVRNLT(self):
  list = None
  if self.VVgIs9:
   list = []
   for row in self.VVgIs9.VVnSZ7():
    list.append(row[4] + row[5])
  files  = self.VVmQLI()
  totChange = 0
  if files:
   for path in files:
    lines = FFcG5u(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV0s4u(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV0s4u(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF0eVO()
   if refreshTable and self.VVgIs9:
    VVuwbt = self.VVeqFi()
    if VVuwbt and self.VVgIs9:
     self.VVgIs9.VVDgsH(VVuwbt, self.tableTitle)
     self.VVgIs9.VVjSfv(txt)
   FFx6I1(self, txt, title=title)
  else:
   FFuW4T(self, "No changes.")
 def VVFty5(self):
  files = self.VVmQLI()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVyfiC = FF6YXr()
    if VVyfiC:
     for b in VVyfiC:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVmQLI(self):
  return CCy3Ly.VVOhYu(self)
 @staticmethod
 def VVOhYu(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVrXSk + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFGKC4(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVgP9T(self, VVgIs9, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFmq3z(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFEjmz(self, fncMode=CCdLyC.VVVW19, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVUtGk(self, VVgIs9, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVUVSs(self, VVgIs9, title, txt, colList):
  chName, chUrl = self.VVUtGk(VVgIs9, colList)
  self.VV3Npr(VVgIs9, chName, chUrl, "localIptv")
 def VVrbJT(self, mode, VVgIs9, colList):
  chName, chUrl, picUrl, refCode = self.VVssNr(mode, colList)
  return chName, chUrl
 def VV6ehB(self, mode, VVgIs9, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVssNr(mode, colList)
  self.VV3Npr(VVgIs9, chName, chUrl, mode)
 def VV3Npr(self, VVgIs9, chName, chUrl, playerFlag):
  chName = FF0IQR(chName)
  if self.VVfTVS(chName):
   FFU7uG(VVgIs9, "This is a marker!", 300)
  else:
   FFJ3IJ(VVgIs9, boundFunction(self.VVOIeq, VVgIs9, chUrl, playerFlag), title="Playing ...")
 def VVOIeq(self, VVgIs9, chUrl, playerFlag):
  FFFZZb(self, chUrl, VVYxnj=False)
  self.session.open(CCjjWk, portalTableParam=(self, VVgIs9, playerFlag))
 @staticmethod
 def VVfTVS(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVQ1Nk(self, VVgIs9, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if refCode:
   bName = FF9Obv()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFEfck(refCode, origUrl, chName) }
   VVgIs9.VVxwwa_partial(colDict, VVxzdz=True)
 def VV9S5o(self, m3uMode):
  path = CCy3Ly.VVbLIu()
  lines = FF8xGt("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFcd50(1)))
  if lines:
   lines.sort()
   VVWaOb = []
   for line in lines:
    VVWaOb.append((line, line))
   if m3uMode == self.VVBMSg:
    title = "Browse Server from M3U URLs"
    VVFoGM = ("All to Playlist", self.VVZmhl)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVFoGM = None
   OKBtnFnc = boundFunction(self.VVW6hy, m3uMode, title)
   VVB6Er = ("Show Full Path", self.VVXUFB)
   VVIAKx = ("Delete File", boundFunction(self.VV9lYV, boundFunction(FFJ3IJ, self, boundFunction(self.VV9S5o, m3uMode), title="Searching ...")))
   FFg6MQ(self, None, title=title, VVWaOb=VVWaOb, width=1200, OKBtnFnc=OKBtnFnc, VVB6Er=VVB6Er, VVIAKx=VVIAKx, VVFoGM=VVFoGM)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FF23yv(self, 'No ".m3u" files found %s' % txt)
 def VVXUFB(self, VVsszyObj, url):
  FFx6I1(self, url, title="Full Path")
 def VVW6hy(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVBMSg:
    FFJ3IJ(menuInstance, boundFunction(self.VVvUYh, title, path))
   else:
    FFJ3IJ(menuInstance, boundFunction(self.VVr4eT, path))
 def VVr4eT(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFGKC4(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCySN5()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVr6y0(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVQcDU(group):
    groups.add(group)
  VVuwbt = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVuwbt.append((group, group))
   VVuwbt.append(("ALL", ""))
   VVuwbt.sort(key=lambda x: x[0].lower())
   VV4h3C = self.VVGVwG
   VViQOR  = ("Select" , boundFunction(self.VVrn4q, srcPath), [])
   widths   = (100  , 0)
   VVFXpL  = (LEFT  , LEFT)
   FFemUu(self, None, title=title, width= 800, header=None, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=30, VViQOR=VViQOR, VV4h3C=VV4h3C
     , VVKeoU="#11110022", VVJRMb="#11110022", VVTMiH="#11110022", VVeFdq="#00444400")
  else:
   txt = FFGKC4(srcPath)
   self.VV7xlE(txt, filterGroup="")
 def VVrn4q(self, srcPath, VVgIs9, title, txt, colList):
  group = colList[1]
  txt = FFGKC4(srcPath)
  self.VV7xlE(txt, filterGroup=group)
 def VV7xlE(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVbbl5, lst, filterGroup)
       , VVn4v8 = boundFunction(self.VV1zO4, title, bName))
  else:
   self.VVrogL("No valid lines found !", title)
 def VVbbl5(self, lst, filterGroup, progBarObj):
  progBarObj.VV6IKE = []
  progBarObj.VVPaCP(len(lst))
  processChanName = CCySN5()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVKTFH(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVr6y0(propLine, "tvg-logo")
   group = self.VVr6y0(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVQcDU(group) : skip = True
    if chName and not processChanName.VVQcDU(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VV6IKE.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVPXQN_forcedUpdate("Loading %d Channels" % len(progBarObj.VV6IKE))
 def VV1zO4(self, title, bName, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  if VV6IKE:
   VV4h3C = self.VVGVwG
   VViQOR  = ("Select"    , boundFunction(self.VVjM6V, title) , [])
   VVf1jQ = (""     , self.VVIpRy         , [])
   VV76K2 = ("Download PIcons" , self.VVpUx0        , [])
   VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVX35f, bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVFXpL  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFemUu(self, None, title=title, header=header, VVeBho=VV6IKE, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=28, VViQOR=VViQOR, VV4h3C=VV4h3C, VVf1jQ=VVf1jQ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVhUO0=True, searchCol=1
     , VVKeoU="#0a00192B", VVJRMb="#0a00192B", VVTMiH="#0a00192B", VVeFdq="#00000000")
  else:
   self.VVrogL("No valid lines found !", title)
 def VVpUx0(self, VVgIs9, title, txt, colList):
  self.VVk2vE(VVgIs9, "m3u/m3u8")
 def VVX35f(self, bName, VVgIs9, title, txt, colList):
  FFJ3IJ(VVgIs9, boundFunction(self.VVMVE5, bName, VVgIs9), title="Adding Channels ...")
 def VVMVE5(self, bName, VVgIs9):
  bNameFile = CCy3Ly.VVQdXE_forBouquet(bName)
  num  = 0
  path = VVrXSk + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVrXSk + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   for row in VVgIs9.VVnSZ7():
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VV1cSl(rowNum, url, chName)
    rowNum += 1
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFiQxL(os.path.basename(path))
  self.VV0s4u(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV1cSl(self, rowNum, url, chName):
  refCode = self.VVscP3(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFob6x(url), chName)
  return chUrl
 def VVscP3(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVwtHq(catID, stID, chNum)
  return refCode
 def VVr6y0(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVjM6V(self, Title, VVgIs9, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFJ3IJ(VVgIs9, boundFunction(self.VV0dat, Title, VVgIs9, colList), title="Checking Server ...")
  else:
   self.VVsCqu(VVgIs9, url, chName)
 def VV0dat(self, title, VVgIs9, colList):
  if not CCoCKj.VV8GeH(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CClqge.VVHykG(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVWaOb = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCy3Ly.VV2KWG(url, fPath)
     VVWaOb.append((resol, fullUrl))
    if VVWaOb:
     if len(VVWaOb) > 1:
      FFg6MQ(self, boundFunction(self.VVWmZy, VVgIs9, chName), VVWaOb=VVWaOb, title="Resolution", VVsg09=True, VVTIf5=True)
     else:
      self.VVsCqu(VVgIs9, VVWaOb[0][1], chName)
    else:
     self.VVxzdzor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV7xlE(txt, filterGroup="")
      return
    self.VVsCqu(VVgIs9, url, chName)
   else:
    self.VVrogL("Cannot process this channel !", title)
  else:
   self.VVrogL(err, title)
 def VVWmZy(self, VVgIs9, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVsCqu(VVgIs9, resolUrl, chName)
 def VVsCqu(self, VVgIs9, url, chName):
  FFJ3IJ(VVgIs9, boundFunction(self.VVhOLy, VVgIs9, url, chName), title="Playing ...")
 def VVhOLy(self, VVgIs9, url, chName):
  chUrl = self.VV1cSl(VVgIs9.VVIxU2(), url, chName)
  FFFZZb(self, chUrl, VVYxnj=False)
  self.session.open(CCjjWk, portalTableParam=(self, VVgIs9, "m3u/m3u8"))
 def VVVXLb(self, VVgIs9, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV1cSl(VVgIs9.VVIxU2(), url, chName)
  return chName, chUrl
 def VVIpRy(self, VVgIs9, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFEjmz(self, fncMode=CCdLyC.VVVW19, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVrogL(self, err, title):
  FF23yv(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVGVwG(self, VVgIs9):
  if self.m3uOrM3u8File:
   self.close()
  VVgIs9.cancel()
 def VVZmhl(self, VVsszyObj, item=None):
  FFJ3IJ(VVsszyObj, boundFunction(self.VVljWz, VVsszyObj, item))
 def VVljWz(self, VVsszyObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVsszyObj.VVWaOb):
    path = item[1]
    if fileExists(path):
     enc = FFiPeJ(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVrEvg(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCy3Ly.VVbLIu(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFBQPI())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVsszyObj.VVWaOb)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFx6I1(self, txt, title=title)
   else:
    FF23yv(self, "Could not obtain URLs from this file list !", title=title)
 def VVYCRs(self):
  path = CCy3Ly.VVbLIu()
  lines = FF8xGt('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFcd50(1)))
  if lines:
   lines.sort()
   VVWaOb = []
   for line in lines:
    VVWaOb.append((line, line))
   OKBtnFnc = self.VV6Fxt
   VVIAKx = ("Delete File", boundFunction(self.VV9lYV, boundFunction(FFJ3IJ, self, self.VVYCRs, title="Searching ...")))
   FFg6MQ(self, None, title="Select Playlist File", VVWaOb=VVWaOb, width=1200, OKBtnFnc=OKBtnFnc, VVIAKx=VVIAKx)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF23yv(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VV6Fxt(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFJ3IJ(menuInstance, boundFunction(self.VVmSE9, menuInstance, path), title="Processing File ...")
 def VVmSE9(self, fileMenuInstance, path):
  enc = FFiPeJ(path, self)
  if enc == -1:
   return
  VVuwbt = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFVqav(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCy3Ly.VVT9WV(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVuwbt:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVuwbt.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVuwbt:
   title = "Playlist File"
   VViQOR  = ("Start"    , boundFunction(self.VVThxF, title)  , [])
   VVINMZ = ("Home Menu"   , FF2wr6         , [])
   VV76K2 = ("Download M3U File" , self.VV67eS     , [])
   VVSWdY = ("Edit File"   , boundFunction(self.VVy8wm, path) , [])
   VVzVsH = ("Check & Filter"  , boundFunction(self.VVQOCr, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVFXpL  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFemUu(self, None, title=title, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVINMZ=VVINMZ, VVzVsH=VVzVsH, VV76K2=VV76K2, VVSWdY=VVSWdY, VVKeoU="#11001116", VVJRMb="#11001116", VVTMiH="#11001116", VVeFdq="#00003635", VVmeUl="#0a333333", VV98nY="#11331100", VVhUO0=True)
  else:
   FF23yv(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV67eS(self, VVgIs9, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFyVJ3(self, boundFunction(FFJ3IJ, VVgIs9, boundFunction(self.VVAolQ, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVAolQ(self, title, url):
  path, err = FFmoGG(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF23yv(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFGKC4(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFFaNy("rm -f '%s'" % path))
    FF23yv(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFFaNy("rm -f '%s'" % path))
    FF23yv(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCy3Ly.VVbLIu(orExportPath=True) + fName
    os.system(FFFaNy("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFuW4T(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF23yv(self, "Could not download the M3U file!", title=errTitle)
 def VVThxF(self, Title, VVgIs9, title, txt, colList):
  url = colList[6]
  FFJ3IJ(VVgIs9, boundFunction(self.VVJ06o, Title, url), title="Checking Server ...")
 def VVy8wm(self, path, VVgIs9, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCpY82(self, path, VVn4v8=boundFunction(self.VVgxM4, VVgIs9), curRowNum=rowNum)
  else    : FFl2xw(self, path)
 def VVgxM4(self, VVgIs9, fileChanged):
  if fileChanged:
   VVgIs9.cancel()
 def VVhNDp(self, title):
  curChName = self.VVgIs9.VVZVaS(1)
  FF3PZZ(self, boundFunction(self.VVXPjj, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVXPjj(self, title, name):
  if name:
   lameDbChans = CCpfVT.VVPQV0(self, CCpfVT.VVDM5S, VVUZCj=False, VV3Thx=False)
   list = []
   if lameDbChans:
    processChanName = CCySN5()
    name = processChanName.VVNFAq(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFUXWI(item[2]), item[3], ratio))
   if list : self.VVG7U6(list, title)
   else : FF23yv(self, "Not found:\n\n%s" % name, title=title)
 def VV3gZO(self, title):
  curChName = self.VVgIs9.VVZVaS(1)
  self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVu1Wf
      , VVn4v8 = boundFunction(self.VV6OIx, title, curChName))
 def VVu1Wf(self, progBarObj):
  curChName = self.VVgIs9.VVZVaS(1)
  lameDbChans = CCpfVT.VVPQV0(self, CCpfVT.VV4cXk, VVUZCj=False, VV3Thx=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV6IKE = []
  progBarObj.VVPaCP(len(lameDbChans))
  processChanName = CCySN5()
  curCh = processChanName.VVNFAq(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCgMHO.VVm5KS(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVKTFH(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VV6IKE.append((chName, FFUXWI(sat), refCode.replace("_", ":"), str(ratio)))
 def VV6OIx(self, title, curChName, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  if VV6IKE: self.VVG7U6(VV6IKE, title)
  elif VVbWpI: FF23yv(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVG7U6(self, VVuwbt, title):
  curChName = self.VVgIs9.VVZVaS(1)
  curRefCode = self.VVgIs9.VVZVaS(4)
  curUrl  = self.VVgIs9.VVZVaS(5)
  VVuwbt = sorted(VVuwbt, key=lambda x: (100-int(x[3]), x[0].lower()))
  VViQOR  = ("Share Sat/C/T Ref.", boundFunction(self.VVo3Oj, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFemUu(self, None, title=title, header=header, VVeBho=VVuwbt, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVKeoU="#0a00112B", VVJRMb="#0a001126", VVTMiH="#0a001126", VVeFdq="#00000000")
 def VVo3Oj(self, newtitle, curChName, curRefCode, curUrl, VVgIs9, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFyVJ3(self.VVgIs9, boundFunction(FFJ3IJ, self.VVgIs9, boundFunction(self.VV6UTT, VVgIs9, data)), ques, title=newtitle, VV29o7=True)
 def VV6UTT(self, VVgIs9, data):
  VVgIs9.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVmQLI():
    txt = FFGKC4(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FF0eVO()
    newRow = []
    for i in range(6):
     newRow.append(self.VVgIs9.VVZVaS(i))
    newRow[4] = newRefCode
    done = self.VVgIs9.VVJCuN(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFewwi(boundFunction(FFuW4T , self, resTxt, title=title))
  elif resErr: FFewwi(boundFunction(FF23yv , self, resErr, title=title))
 def VVQOCr(self, fileMenuInstance, path, VVgIs9, title, txt, colList):
  self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVFYT2, VVgIs9)
      , VVn4v8 = boundFunction(self.VVxU8r, fileMenuInstance, path, VVgIs9))
 def VVFYT2(self, VVgIs9, progBarObj):
  progBarObj.VVPaCP(VVgIs9.VVbTV2())
  progBarObj.VV6IKE = []
  for row in VVgIs9.VVnSZ7():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVKTFH(1, True)
   qUrl = self.VVCvo1(self.VVZJLJ, row[6])
   txt, err = self.VVSslx(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVvKvd(item, "auth") == "0":
       progBarObj.VV6IKE.append(qUrl)
    except:
     pass
 def VVxU8r(self, fileMenuInstance, path, VVgIs9, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  if VVbWpI:
   list = VV6IKE
   title = "Authorized Servers"
   if list:
    totChk = VVgIs9.VVbTV2()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFBQPI()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVYCRs()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFKY60(str(totAuth), VVuV1K)
     txt += "%s\n\n%s"    %  (FFKY60("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFx6I1(self, txt, title=title)
     VVgIs9.close()
     fileMenuInstance.close()
    else:
     FFuW4T(self, "All URLs are authorized.", title=title)
   else:
    FF23yv(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVSslx(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVT9WV(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV8ofO(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVCvo1(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVT9WV(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVZJLJ   : return "%s"            % url
  elif mode == self.VVaO1A   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVjc9y   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVP7vl  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVTQsG  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVURhr : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVpUfk   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVV3u0    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVqvJr  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVIdjS : return "%s&action=get_live_streams"      % url
  elif mode == self.VVxlHg  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVvKvd(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFv8BC(int(val))
    elif is_base64 : val = FFkCIh(val)
    elif isToHHMMSS : val = FFSof4(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVvUYh(self, title, path):
  if fileExists(path):
   enc = FFiPeJ(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVrEvg(line)
     if qUrl:
      break
   if qUrl : self.VVJ06o(title, qUrl)
   else : FF23yv(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF23yv(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV91UW_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV2oNw()
  if qUrl:
   host, mac, isPortalUrl = self.VVb9Hj(iptvRef)
   if isPortalUrl:
    if host and mac : self.VV91UW(self, host, mac)
    else   : FF23yv(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFJ3IJ(self, boundFunction(self.VVJ06o, title, qUrl), title="Checking Server ...")
  else:
   FF23yv(self, "Error in current channel URL !", title=title)
 def VV2oNw(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  qUrl = self.VVrEvg(decodedUrl)
  return qUrl, iptvRef
 def VVrEvg(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVJ06o(self, title, url):
  self.VVk8EXData = {}
  qUrl = self.VVCvo1(self.VVZJLJ, url)
  txt, err = self.VVSslx(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVk8EXData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVk8EXData["username"    ] = self.VVvKvd(item, "username"        )
    self.VVk8EXData["password"    ] = self.VVvKvd(item, "password"        )
    self.VVk8EXData["message"    ] = self.VVvKvd(item, "message"        )
    self.VVk8EXData["auth"     ] = self.VVvKvd(item, "auth"         )
    self.VVk8EXData["status"    ] = self.VVvKvd(item, "status"        )
    self.VVk8EXData["exp_date"    ] = self.VVvKvd(item, "exp_date"    , isDate=True )
    self.VVk8EXData["is_trial"    ] = self.VVvKvd(item, "is_trial"        )
    self.VVk8EXData["active_cons"   ] = self.VVvKvd(item, "active_cons"       )
    self.VVk8EXData["created_at"   ] = self.VVvKvd(item, "created_at"   , isDate=True )
    self.VVk8EXData["max_connections"  ] = self.VVvKvd(item, "max_connections"      )
    self.VVk8EXData["allowed_output_formats"] = self.VVvKvd(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVk8EXData[key] = lst
    item = tDict["server_info"]
    self.VVk8EXData["url"    ] = self.VVvKvd(item, "url"        )
    self.VVk8EXData["port"    ] = self.VVvKvd(item, "port"        )
    self.VVk8EXData["https_port"  ] = self.VVvKvd(item, "https_port"      )
    self.VVk8EXData["server_protocol" ] = self.VVvKvd(item, "server_protocol"     )
    self.VVk8EXData["rtmp_port"   ] = self.VVvKvd(item, "rtmp_port"       )
    self.VVk8EXData["timezone"   ] = self.VVvKvd(item, "timezone"       )
    self.VVk8EXData["timestamp_now"  ] = self.VVvKvd(item, "timestamp_now"  , isDate=True )
    self.VVk8EXData["time_now"   ] = self.VVvKvd(item, "time_now"       )
    VVWaOb  = self.VVpjMm(True)
    OKBtnFnc = self.VVk8EXOptions
    VVinCp = ("Home Menu", FF2wr6)
    FFg6MQ(self, None, title="IPTV Server Resources", VVWaOb=VVWaOb, OKBtnFnc=OKBtnFnc, VVinCp=VVinCp)
   else:
    err = "Could not get data from server !"
  if err:
   FF23yv(self, err, title=title)
  FFU7uG(self)
 def VVk8EXOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFJ3IJ(menuInstance, boundFunction(self.VV51Cc, self.VVaO1A  , title=title), title=wTxt)
   elif ref == "vod"   : FFJ3IJ(menuInstance, boundFunction(self.VV51Cc, self.VVjc9y  , title=title), title=wTxt)
   elif ref == "series"  : FFJ3IJ(menuInstance, boundFunction(self.VV51Cc, self.VVP7vl , title=title), title=wTxt)
   elif ref == "catchup"  : FFJ3IJ(menuInstance, boundFunction(self.VV51Cc, self.VVTQsG , title=title), title=wTxt)
   elif ref == "accountInfo" : FFJ3IJ(menuInstance, boundFunction(self.VVgw1E           , title=title), title=wTxt)
 def VVgw1E(self, title):
  rows = []
  for key, val in self.VVk8EXData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVINMZ = ("Home Menu", FF2wr6, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFemUu(self, None, title=title, width=1200, header=header, VVeBho=rows, VVEHj0=widths, VVZWCz=26, VVINMZ=VVINMZ, VVKeoU="#0a00292B", VVJRMb="#0a002126", VVTMiH="#0a002126", VVeFdq="#00000000", searchCol=2)
 def VVgtcy(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCySN5()
    if mode in (self.VVpUfk, self.VVxlHg):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVvKvd(item, "num"         )
      name     = self.VVvKvd(item, "name"        )
      stream_id    = self.VVvKvd(item, "stream_id"       )
      stream_icon    = self.VVvKvd(item, "stream_icon"       )
      epg_channel_id   = self.VVvKvd(item, "epg_channel_id"      )
      added     = self.VVvKvd(item, "added"    , isDate=True )
      is_adult    = self.VVvKvd(item, "is_adult"       )
      category_id    = self.VVvKvd(item, "category_id"       )
      tv_archive    = self.VVvKvd(item, "tv_archive"       )
      name = processChanName.VVQcDU(name)
      if name:
       if mode == self.VVpUfk or mode == self.VVxlHg and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVV3u0:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVvKvd(item, "num"         )
      name    = self.VVvKvd(item, "name"        )
      stream_id   = self.VVvKvd(item, "stream_id"       )
      stream_icon   = self.VVvKvd(item, "stream_icon"       )
      added    = self.VVvKvd(item, "added"    , isDate=True )
      is_adult   = self.VVvKvd(item, "is_adult"       )
      category_id   = self.VVvKvd(item, "category_id"       )
      container_extension = self.VVvKvd(item, "container_extension"     ) or "mp4"
      name = processChanName.VVQcDU(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVqvJr:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVvKvd(item, "num"        )
      name    = self.VVvKvd(item, "name"       )
      series_id   = self.VVvKvd(item, "series_id"      )
      cover    = self.VVvKvd(item, "cover"       )
      genre    = self.VVvKvd(item, "genre"       )
      episode_run_time = self.VVvKvd(item, "episode_run_time"    )
      category_id   = self.VVvKvd(item, "category_id"      )
      container_extension = self.VVvKvd(item, "container_extension"    ) or "mp4"
      name = processChanName.VVQcDU(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VV51Cc(self, mode, title):
  cList, err = self.VVmhCw(mode)
  if cList and mode == self.VVTQsG:
   cList = self.VVO6TS(cList)
  if err:
   FF23yv(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx(mode)
   mName = self.VVI3A4(mode)
   if   mode == self.VVaO1A  : fMode = self.VVpUfk
   elif mode == self.VVjc9y  : fMode = self.VVV3u0
   elif mode == self.VVP7vl : fMode = self.VVqvJr
   elif mode == self.VVTQsG : fMode = self.VVxlHg
   if mode == self.VVTQsG:
    VVSWdY = None
   else:
    VVSWdY = ("Find in %s" % mName , boundFunction(self.VVozIQ, fMode) , [])
   VViQOR   = ("Show List"   , boundFunction(self.VVFh8j, mode) , [])
   VVINMZ  = ("Home Menu"   , FF2wr6          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFemUu(self, None, title=title, width=1200, header=header, VVeBho=cList, VVEHj0=widths, VVZWCz=30, VVINMZ=VVINMZ, VVSWdY=VVSWdY, VViQOR=VViQOR, VVKeoU=VVKeoU, VVJRMb=VVJRMb, VVTMiH=VVTMiH, VVeFdq=VVeFdq)
  else:
   FF23yv(self, "No list from server !", title=title)
  FFU7uG(self)
 def VVmhCw(self, mode):
  qUrl  = self.VVCvo1(mode, self.VVk8EXData["playListURL"])
  txt, err = self.VVSslx(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCySN5()
    for item in tDict:
     category_id  = self.VVvKvd(item, "category_id"  )
     category_name = self.VVvKvd(item, "category_name" )
     parent_id  = self.VVvKvd(item, "parent_id"  )
     category_name = processChanName.VVxCdj(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVO6TS(self, catList):
  mode  = self.VVxlHg
  qUrl  = self.VVCvo1(mode, self.VVk8EXData["playListURL"])
  txt, err = self.VVSslx(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVgtcy(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVFh8j(self, mode, VVgIs9, title, txt, colList):
  title = colList[1]
  FFJ3IJ(VVgIs9, boundFunction(self.VVgcvk, mode, VVgIs9, title, txt, colList), title="Downloading ...")
 def VVgcvk(self, mode, VVgIs9, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVI3A4(mode) + " : "+ bName
  if   mode == self.VVaO1A  : mode = self.VVpUfk
  elif mode == self.VVjc9y  : mode = self.VVV3u0
  elif mode == self.VVP7vl : mode = self.VVqvJr
  elif mode == self.VVTQsG : mode = self.VVxlHg
  qUrl  = self.VVCvo1(mode, self.VVk8EXData["playListURL"], catID)
  txt, err = self.VVSslx(qUrl)
  list  = []
  if not err and mode in (self.VVpUfk, self.VVV3u0, self.VVqvJr, self.VVxlHg):
   list, err = self.VVgtcy(mode, txt)
  if err:
   FF23yv(self, err, title=title)
  elif list:
   VVINMZ  = ("Home Menu"   , FF2wr6             , [])
   if mode in (self.VVpUfk, self.VVxlHg):
    VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx(mode)
    VVf1jQ = (""     , boundFunction(self.VVXfr6, mode)     , [])
    VV76K2 = ("Download Options" , boundFunction(self.VVBmzF, mode, "", "")  , [])
    VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVQwYU, mode, bName)  , [])
    if mode == self.VVpUfk:
     VViQOR = ("Play"    , boundFunction(self.VV6ehB, mode)     , [])
    elif mode == self.VVxlHg:
     VViQOR  = ("Programs", boundFunction(self.VVzrF6_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVFXpL  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVV3u0:
    VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx(mode)
    VViQOR  = ("Play"    , boundFunction(self.VV6ehB, mode)    , [])
    VVf1jQ = (""     , boundFunction(self.VVXfr6, mode)    , [])
    VV76K2 = ("Download Options" , boundFunction(self.VVBmzF, mode, "v", ""), [])
    VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVQwYU, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVFXpL  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVqvJr:
    VVKeoU, VVJRMb, VVTMiH, VVeFdq = self.VVhQqx("series2")
    VViQOR  = ("Show Seasons", boundFunction(self.VVtDDU, mode) , [])
    VVf1jQ = ("", boundFunction(self.VVLgcX, mode)  , [])
    VV76K2 = None
    VVSWdY = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVFXpL  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFemUu(self, None, title=title, header=header, VVeBho=list, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVf1jQ=VVf1jQ, VVKeoU=VVKeoU, VVJRMb=VVJRMb, VVTMiH=VVTMiH, VVeFdq=VVeFdq, VVhUO0=True, searchCol=1)
  else:
   FF23yv(self, "No Channels found !", title=title)
  FFU7uG(self)
 def VVzrF6_fromIptvTable(self, mode, bName, VVgIs9, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVk8EXData["playListURL"]
  ok_fnc  = boundFunction(self.VVvIqy, hostUrl, chName, catId, streamId)
  FFJ3IJ(VVgIs9, boundFunction(CCy3Ly.VVzrF6, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVvIqy(self, chUrl, chName, catId, streamId, VVgIs9, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCy3Ly.VVT9WV(chUrl)
   chNum = "333"
   refCode = CCy3Ly.VVwtHq(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFFZZb(self, chUrl, VVYxnj=False)
   self.session.open(CCjjWk)
  else:
   FF23yv(self, "Incorrect Timestamp", pTitle)
 def VVtDDU(self, mode, VVgIs9, title, txt, colList):
  title = colList[1]
  FFJ3IJ(VVgIs9, boundFunction(self.VVit4H, mode, VVgIs9, title, txt, colList), title="Downloading ...")
 def VVit4H(self, mode, VVgIs9, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVCvo1(self.VVURhr, self.VVk8EXData["playListURL"], series_id)
  txt, err = self.VVSslx(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVvKvd(tDict["info"], "name"   )
      category_id = self.VVvKvd(tDict["info"], "category_id" )
      icon  = self.VVvKvd(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVvKvd(EP, "id"     )
        episode_num   = self.VVvKvd(EP, "episode_num"   )
        epTitle    = self.VVvKvd(EP, "title"     )
        container_extension = self.VVvKvd(EP, "container_extension" )
        seasonNum   = self.VVvKvd(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF23yv(self, err, title=title)
  elif list:
   VVINMZ = ("Home Menu"   , FF2wr6             , [])
   VV76K2 = ("Download Options" , boundFunction(self.VVBmzF, mode, "s", title) , [])
   VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVQwYU, mode, title)  , [])
   VVf1jQ = (""     , boundFunction(self.VVXfr6, mode)     , [])
   VViQOR  = ("Play"    , boundFunction(self.VV6ehB, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVFXpL  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFemUu(self, None, title=title, header=header, VVeBho=list, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VVINMZ=VVINMZ, VV76K2=VV76K2, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VVSWdY=VVSWdY, VVKeoU="#0a00292B", VVJRMb="#0a002126", VVTMiH="#0a002126", VVeFdq="#00000000")
  else:
   FF23yv(self, "No Channels found !", title=title)
  FFU7uG(self)
 def VVozIQ(self, mode, VVgIs9, title, txt, colList):
  VVWaOb = []
  VVWaOb.append(("Keyboard"  , "manualEntry"))
  VVWaOb.append(("From Filter" , "fromFilter"))
  FFg6MQ(self, boundFunction(self.VVaHFG, VVgIs9, mode), title="Input Type", VVWaOb=VVWaOb, width=400)
 def VVaHFG(self, VVgIs9, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF3PZZ(self, boundFunction(self.VVXyPT, VVgIs9, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCJJAn(self)
    filterObj.VV5fxX(boundFunction(self.VVXyPT, VVgIs9, mode))
 def VVXyPT(self, VVgIs9, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCySN5()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVsBqy(words):
     FF23yv(self, processChanName.VVJ6l1(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVztZ5, VVgIs9, mode, title, words, toFind, asPrefix, processChanName)
         , VVn4v8 = boundFunction(self.VV9Y8I, mode, toFind, title))
   else:
    FF23yv(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVztZ5(self, VVgIs9, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVPaCP(VVgIs9.VVM3Tt())
  progBarObj.VV6IKE = []
  for row in VVgIs9.VVnSZ7():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVKTFH(1)
   progBarObj.VVPXQN_fromIptvFind(catName)
   qUrl  = self.VVCvo1(mode, self.VVk8EXData["playListURL"], catID)
   txt, err = self.VVSslx(qUrl)
   if not err:
    tList, err = self.VVgtcy(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVQcDU(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVpUfk:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VV6IKE.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVV3u0:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VV6IKE.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVqvJr:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VV6IKE.append((num, name, catID, ID, genre, catName, ext, cover))
 def VV9Y8I(self, mode, toFind, title, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  if VV6IKE:
   title = self.VVZfGl(mode, toFind)
   if mode == self.VVpUfk or mode == self.VVV3u0:
    if mode == self.VVV3u0 : typ = "v"
    else          : typ = ""
    bName   = CCy3Ly.VVQdXE_forBouquet(toFind)
    VViQOR  = ("Play"     , boundFunction(self.VV6ehB, mode)    , [])
    VV76K2 = ("Download Options" , boundFunction(self.VVBmzF, mode, typ, ""), [])
    VVSWdY = ("Add ALL to Bouquet" , boundFunction(self.VVQwYU, mode, bName) , [])
   elif mode == self.VVqvJr:
    VViQOR  = ("Show Seasons"  , boundFunction(self.VVtDDU, mode)    , [])
    VVSWdY = None
    VV76K2 = None
   VVf1jQ  = (""     , boundFunction(self.VVXfr6, mode)    , [])
   VVINMZ  = ("Home Menu"   , FF2wr6            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVFXpL  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVgIs9 = FFemUu(self, None, title=title, header=header, VVeBho=VV6IKE, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVf1jQ=VVf1jQ, VVKeoU="#0a00292B", VVJRMb="#0a002126", VVTMiH="#0a002126", VVeFdq="#00000000", VVhUO0=True, searchCol=1)
   if not VVbWpI:
    FFU7uG(VVgIs9, "Stopped" , 1000)
  else:
   if VVbWpI:
    FF23yv(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVssNr(self, mode, colList):
  if mode in (self.VVpUfk, self.VVxlHg):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVV3u0:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FF0IQR(chName)
  url = self.VVk8EXData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVT9WV(url)
  refCode = self.VVwtHq(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVXfr6(self, mode, VVgIs9, title, txt, colList):
  FFJ3IJ(VVgIs9, boundFunction(self.VVkv1b, mode, VVgIs9, title, txt, colList))
 def VVkv1b(self, mode, VVgIs9, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVssNr(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFEjmz(self, fncMode=CCdLyC.VVvqxH, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVLgcX(self, mode, VVgIs9, title, txt, colList):
  FFJ3IJ(VVgIs9, boundFunction(self.VVi8RO, mode, VVgIs9, title, txt, colList))
 def VVi8RO(self, mode, VVgIs9, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFEjmz(self, fncMode=CCdLyC.VVWGJY, chName=name, text=txt, picUrl=Cover)
 def VVQwYU(self, mode, bName, VVgIs9, title, txt, colList):
  FFJ3IJ(VVgIs9, boundFunction(self.VVeIFG, mode, bName, VVgIs9, title, txt, colList), title="Adding Channels ...")
 def VVeIFG(self, mode, bName, VVgIs9, title, txt, colList):
  url = self.VVk8EXData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVT9WV(url)
  bNameFile = CCy3Ly.VVQdXE_forBouquet(bName)
  num  = 0
  path = VVrXSk + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVrXSk + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVgIs9.VVnSZ7():
    chName, chUrl, picUrl, refCode = self.VVssNr(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFiQxL(os.path.basename(path))
  self.VV0s4u(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVBmzF(self, mode, typ, seriesName, VVgIs9, title, txt, colList):
  VVWaOb = []
  VVWaOb.append(("Download all PIcons"       , "dnldPicons" ))
  if typ:
   VVWaOb.append(VVIEqe)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVWaOb.append(("Download Selected %s" % tName    , "dnldSel"  ))
   VVWaOb.append(("Add Selected %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVWaOb.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCuRcG.VV1snA():
    VVWaOb.append(VVIEqe)
    VVWaOb.append(("Download Manager"      , "dload_stat" ))
  FFg6MQ(self, boundFunction(self.VV31gb_VVlcB0, VVgIs9, mode, typ, seriesName, colList), title="Download Options", VVWaOb=VVWaOb)
 def VV31gb_VVlcB0(self, VVgIs9, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVk2vE(VVgIs9, mode)
   elif item == "dnldSel"  : self.VV4Okh(VVgIs9, mode, typ, colList, True)
   elif item == "addSel"  : self.VV4Okh(VVgIs9, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVLM3r(VVgIs9, mode, typ, seriesName)
   elif item == "dload_stat" : CCuRcG.VVcmaF(self)
 def VV4Okh(self, VVgIs9, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVggVr(mode, typ, colList)
  if startDnld:
   CCuRcG.VVD8EE_url(self, decodedUrl)
  else:
   self.VVlcB0_FFyVJ3(VVgIs9, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVLM3r(self, VVgIs9, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVgIs9.VVnSZ7():
   chName, decodedUrl = self.VVggVr(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVlcB0_FFyVJ3(VVgIs9, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVlcB0_FFyVJ3(self, VVgIs9, title, chName, decodedUrl_list, startDnld):
  FFyVJ3(self, boundFunction(self.VVZ4Ca, VVgIs9, decodedUrl_list, startDnld), chName, title=title)
 def VVZ4Ca(self, VVgIs9, decodedUrl_list, startDnld):
  added, skipped = CCuRcG.VVhGCwList(decodedUrl_list)
  FFU7uG(VVgIs9, "Added", 1000)
 def VVggVr(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVssNr(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVhqCe(mode, colList)
   refCode, chUrl = self.VV6Lk7(self.VVbRw9, self.VVj2cG, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFlKLF(chUrl)
  return chName, decodedUrl
 def VVk2vE(self, VVgIs9, mode):
  if os.system(FFFaNy("which ffmpeg")) == 0:
   self.session.open(CC34Kz, barTheme=CC34Kz.VV1Vhb
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV2FPj, VVgIs9, mode)
       , VVn4v8 = self.VVgvWJ)
  else:
   FFyVJ3(self, boundFunction(CCy3Ly.VVeWyk, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVgvWJ(self, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VV6IKE["proces"], VV6IKE["total"])
  txt += "Download Success\t: %d of %s\n"  % (VV6IKE["ok"], VV6IKE["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VV6IKE["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VV6IKE["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VV6IKE["badURL"]
  txt += "Download Failure\t: %d\n"   % VV6IKE["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VV6IKE["path"]
  if not VVbWpI  : color = "#11402000"
  elif VV6IKE["err"]: color = "#11201000"
  else     : color = None
  if VV6IKE["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VV6IKE["err"], txt)
  title = "PIcons Download Result"
  if not VVbWpI:
   title += "  (cancelled)"
  FFx6I1(self, txt, title=title, VVTMiH=color)
 def VV2FPj(self, VVgIs9, mode, progBarObj):
  totRows = VVgIs9.VVM3Tt()
  progBarObj.VVPaCP(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCgMHO.VV4aVy()
  progBarObj.VV6IKE = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVgIs9.VVnSZ7()):
    if progBarObj.isCancelled:
     break
    progBarObj.VV6IKE["proces"] += 1
    progBarObj.VVKTFH(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVhqCe(mode, row)
     refCode = CCy3Ly.VVwtHq(catID, stID, chNum)
    elif mode == "m3u/m3u8":
     chName = row[1].strip()
     url  = row[3].strip()
     picUrl = row[4].strip()
     refCode = self.VVscP3(rowNum, url, chName)
    else:
     chName, chUrl, picUrl, refCode = self.VVssNr(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VV6IKE["attempt"] += 1
      path, err = FFmoGG(picUrl, picon, timeout=1, mustBeImage=True)
      if path:
       progBarObj.VV6IKE["ok"] += 1
       if FFfblo(path) > 0:
        cmd = ""
        if not mode == CCy3Ly.VVpUfk:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFFaNy("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VV6IKE["size0"] += 1
        os.system(FFFaNy("rm -f '%s'" % path))
      elif err:
       progBarObj.VV6IKE["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VV6IKE["err"] = err.title()
        break
     else:
      progBarObj.VV6IKE["exist"] += 1
    else:
     progBarObj.VV6IKE["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVeWyk(SELF):
  cmd = FFNOBr(VVlyKc, "ffmpeg")
  if cmd : FFsUMt(SELF, cmd, title="Installing FFmpeg")
  else : FF5N91(SELF)
 def VVJqrj(self):
  self.session.open(CC34Kz, barTheme=CC34Kz.VV1Vhb
      , titlePrefix = ""
      , fncToRun  = self.VVWBcJ
      , VVn4v8 = self.VV1sOO)
 def VVWBcJ(self, progBarObj):
  bName = FF9Obv()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VV6IKE = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FF9t4m()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVPaCP(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVKTFH(1)
    progBarObj.VVPXQN_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFqdX4(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFlKLF(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CClqge.VVVyR1(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCy3Ly.VV8ofO(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCy3Ly.VV8ofO(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCy3Ly.VV8ofO(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCy3Ly.VVFxNH(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCdLyC.VVioD7(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VV6IKE = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VV6IKE = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VV1sOO(self, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VV6IKE
  title = "IPTV EPG Import"
  if err:
   FF23yv(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFKY60(str(totNotIptv), VVCyLg)
    if totServErr : txt += "Server Errors\t: %s\n" % FFKY60(str(totServErr) + t1, VVCyLg)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFKY60(str(totInv), VVCyLg)
   if not VVbWpI:
    title += "  (stopped)"
   FFx6I1(self, txt, title=title)
 @staticmethod
 def VVFxNH(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCy3Ly.VVT9WV(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCy3Ly.VVSslx(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCy3Ly.VVvKvd(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCy3Ly.VVvKvd(item, "has_archive"      )
    lang    = CCy3Ly.VVvKvd(item, "lang"        ).upper()
    now_playing   = CCy3Ly.VVvKvd(item, "now_playing"      )
    start    = CCy3Ly.VVvKvd(item, "start"        )
    start_timestamp  = CCy3Ly.VVvKvd(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCy3Ly.VVvKvd(item, "start_timestamp"     )
    stop_timestamp  = CCy3Ly.VVvKvd(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCy3Ly.VVvKvd(item, "stop_timestamp"      )
    tTitle    = CCy3Ly.VVvKvd(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVwtHq(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCy3Ly.VVjCpx(catID, MAX_4b)
  TSID = CCy3Ly.VVjCpx(chNum, MAX_4b)
  ONID = CCy3Ly.VVjCpx(chNum, MAX_4b)
  NS  = CCy3Ly.VVjCpx(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVjCpx(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVQdXE_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVhQqx(mode):
  if   mode in ("itv"  , CCy3Ly.VVaO1A)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCy3Ly.VVjc9y)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCy3Ly.VVP7vl) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCy3Ly.VVTQsG) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCy3Ly.VVxlHg    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVbLIu(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVWnkq:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFVqav(path)
 @staticmethod
 def VVzrF6(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCy3Ly.VVFxNH(hostUrl, streamId, True)
  if err:
   FF23yv(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVKeoU, VVJRMb, VVTMiH, VVeFdq = CCy3Ly.VVhQqx("")
   VVINMZ = ("Home Menu" , FF2wr6, [])
   VViQOR  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVFXpL  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFemUu(SELF, None, title="Programs for : " + chName, header=header, VVeBho=pList, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=24, VViQOR=VViQOR, VVINMZ=VVINMZ, VVKeoU=VVKeoU, VVJRMb=VVJRMb, VVTMiH=VVTMiH, VVeFdq=VVeFdq)
  else:
   FF23yv(SELF, "No Programs from server", title=title)
 @staticmethod
 def VV2KWG(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
class CCM9We(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFDOid(VVxulX, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VV9kDN  = 0
  self.VVn9Ea = 1
  self.VVyoky  = 2
  VVWaOb = []
  VVWaOb.append(("Find in All Service (from filter)" , "VV4Zmq" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Find in All (Manual Entry)"   , "VVL1ZJ"    ))
  VVWaOb.append(("Find in TV"       , "VVTkPz"    ))
  VVWaOb.append(("Find in Radio"      , "VVS9zC"   ))
  if self.VVQUXa():
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Hide Channel: %s" % self.servName , "VVcOw9"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Zap History"       , "VVKq99"    ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("IPTV Tools"       , "iptv"      ))
  VVWaOb.append(("PIcons Tools"       , "PIconsTools"     ))
  VVWaOb.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFBDfs(self, VVWaOb=VVWaOb, title=title)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
  if self.isFindMode:
   self.VVDcvQ(self.VVGvDj())
 def VVAJFV(self):
  global VVZjBX
  VVZjBX = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVL1ZJ"    : self.VVL1ZJ()
   elif item == "VV4Zmq" : self.VV4Zmq()
   elif item == "VVTkPz"    : self.VVTkPz()
   elif item == "VVS9zC"   : self.VVS9zC()
   elif item == "VVcOw9"   : self.VVcOw9()
   elif item == "VVKq99"    : self.VVKq99()
   elif item == "iptv"       : self.session.open(CCy3Ly)
   elif item == "PIconsTools"     : self.session.open(CCgMHO)
   elif item == "ChannelsTools"    : self.session.open(CCpfVT)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVTkPz(self) : self.VVDcvQ(self.VV9kDN)
 def VVS9zC(self) : self.VVDcvQ(self.VVn9Ea)
 def VVL1ZJ(self) : self.VVDcvQ(self.VVyoky)
 def VVDcvQ(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF3PZZ(self, boundFunction(self.VVuNy7, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VV4Zmq(self):
  filterObj = CCJJAn(self)
  filterObj.VV5fxX(self.VVudZb)
 def VVudZb(self, item):
  self.VVuNy7(self.VVyoky, item)
 def VVQUXa(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFqdX4(self.refCode)        : return False
  return True
 def VVuNy7(self, mode, VV7XK7):
  FFJ3IJ(self, boundFunction(self.VVX8AT, mode, VV7XK7), title="Searching ...")
 def VVX8AT(self, mode, VV7XK7):
  if VV7XK7:
   self.findTxt = VV7XK7
   if   mode == self.VV9kDN  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVn9Ea : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV7XK7)
   if len(title) > 55:
    title = title[:55] + ".."
   VVuwbt = self.VVXsZc(VV7XK7, servTypes)
   if self.isFindMode or mode == self.VVyoky:
    VVuwbt += self.VVWs9G(VV7XK7)
   if VVuwbt:
    VVuwbt.sort(key=lambda x: x[0].lower())
    VV4h3C = self.VVwo2o
    VViQOR  = ("Zap"   , self.VV4gcj    , [])
    VV76K2 = ("Current Service", self.VV4Lr6 , [])
    VVSWdY = ("Options"  , self.VVQB1G , [])
    VVf1jQ = (""    , self.VVGqpp , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVFXpL  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFemUu(self, None, title=title, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VV4h3C=VV4h3C, VV76K2=VV76K2, VVSWdY=VVSWdY, VVf1jQ=VVf1jQ)
   else:
    self.VVDcvQ(self.VVGvDj())
    FFuW4T(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVXsZc(self, VV7XK7, servTypes):
  VVmOHg  = eServiceCenter.getInstance()
  VVflEP   = '%s ORDER BY name' % servTypes
  VVkdhb   = eServiceReference(VVflEP)
  VV5pcY = VVmOHg.list(VVkdhb)
  if VV5pcY: VVeBho = VV5pcY.getContent("CN", False)
  else     : VVeBho = None
  VVuwbt = []
  if VVeBho:
   VVezZF, VV7Z6a = FFcN34()
   tp   = CC38xH()
   words, asPrefix = CCJJAn.VVYNrj(VV7XK7)
   colorYellow  = CCY16h.VVo19M(VV106B)
   colorWhite  = CCY16h.VVo19M(VVbwNy)
   for s in VVeBho:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFXG8g(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVezZF:
        STYPE = VV7Z6a[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVNLQ6(refCode)
       if not "-S" in syst:
        sat = syst
       VVuwbt.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVuwbt
 def VVWs9G(self, VV7XK7):
  VV7XK7 = VV7XK7.lower()
  VVyfiC = FF6YXr()
  VVuwbt = []
  colorYellow  = CCY16h.VVo19M(VV106B)
  colorWhite  = CCY16h.VVo19M(VVbwNy)
  if VVyfiC:
   for b in VVyfiC:
    VVJjC4  = b[0]
    VVO9MV  = b[1].toString()
    VVH5DQ = eServiceReference(VVO9MV)
    VV8PRc = FFx460(VVH5DQ)
    for service in VV8PRc:
     refCode  = service[0]
     if FFqdX4(refCode):
      servName = service[1]
      if VV7XK7 in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV7XK7), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVuwbt.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVuwbt
 def VVGvDj(self):
  VVzHgb = InfoBar.instance
  if VVzHgb:
   VV8sHQ = VVzHgb.servicelist
   if VV8sHQ:
    return VV8sHQ.mode == 1
  return self.VVyoky
 def VVwo2o(self, VVgIs9):
  self.close()
  VVgIs9.cancel()
 def VV4gcj(self, VVgIs9, title, txt, colList):
  FFFZZb(VVgIs9, colList[2], VVYxnj=False, checkParentalControl=True)
 def VV4Lr6(self, VVgIs9, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(VVgIs9)
  if refCode:
   VVgIs9.VVPRhs(2, FFEfck(refCode, iptvRef, chName), True)
 def VVQB1G(self, VVgIs9, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCIKdH(self, VVgIs9, 2)
  mSel.VVsoqo(servName, refCode)
 def VVGqpp(self, VVgIs9, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFEjmz(self, fncMode=CCdLyC.VVNEqF, refCode=refCode, chName=chName, text=txt)
 def VVcOw9(self):
  FFyVJ3(self, self.VV1gl2, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV1gl2(self):
  ret = FFlSYx(self.refCode, True)
  if ret:
   self.VVfmha()
   self.close()
  else:
   FFU7uG(self, "Cannot change state" , 1000)
 def VVfmha(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVPpZM()
  except:
   self.VV55ie()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFYtlH(self, serviceRef)
 def VV07UM(self):
  VVzHgb = InfoBar.instance
  if VVzHgb:
   VV8sHQ = VVzHgb.servicelist
   if VV8sHQ:
    VV8sHQ.setMode()
 def VVPpZM(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVzHgb = InfoBar.instance
   if VVzHgb:
    VV8sHQ = VVzHgb.servicelist
    if VV8sHQ:
     hList = VV8sHQ.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV8sHQ.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV8sHQ.history  = newList
       VV8sHQ.history_pos = pos
 def VV55ie(self):
  VVzHgb = InfoBar.instance
  if VVzHgb:
   VV8sHQ = VVzHgb.servicelist
   if VV8sHQ:
    VV8sHQ.history  = []
    VV8sHQ.history_pos = 0
 def VVKq99(self):
  VVzHgb = InfoBar.instance
  VVuwbt = []
  if VVzHgb:
   VV8sHQ = VVzHgb.servicelist
   if VV8sHQ:
    VVezZF, VV7Z6a = FFcN34()
    for chParams in VV8sHQ.history:
     refCode = chParams[-1].toString()
     chName = FFLN5X(refCode)
     isIptv = FFqdX4(refCode)
     if isIptv: sat = "-"
     else  : sat = FFXG8g(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVezZF:
       STYPE = VV7Z6a[sTypeInt]
     VVuwbt.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVuwbt:
   VViQOR  = ("Zap"   , self.VVTTBg   , [])
   VVSWdY = ("Clear History" , self.VVYEst   , [])
   VVf1jQ = (""    , self.VVki2mFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVFXpL  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFemUu(self, None, title=title, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=28, VViQOR=VViQOR, VVSWdY=VVSWdY, VVf1jQ=VVf1jQ)
  else:
   FFuW4T(self, "Not found", title=title)
 def VVTTBg(self, VVgIs9, title, txt, colList):
  FFFZZb(VVgIs9, colList[3], VVYxnj=False, checkParentalControl=True)
 def VVYEst(self, VVgIs9, title, txt, colList):
  FFyVJ3(self, boundFunction(self.VVs3XR, VVgIs9), "Clear Zap History ?")
 def VVs3XR(self, VVgIs9):
  self.VV55ie()
  VVgIs9.cancel()
 def VVki2mFromZapHistory(self, VVgIs9, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFEjmz(self, fncMode=CCdLyC.VVFv3p, refCode=refCode, chName=chName, text=txt)
class CCgMHO(Screen):
 VVmFcJ   = 0
 VVRRRm  = 1
 VVQN6m  = 2
 VVmV5c  = 3
 VV92kw  = 4
 VViLjZ  = 5
 VV894C  = 6
 VVLdVD  = 7
 VVinj4 = 8
 VVJ399 = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFDOid(VVpjxY, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFBDfs(self, self.Title)
  FFOV9c(self["keyRed"] , "OK = Zap")
  FFOV9c(self["keyGreen"] , "Current Service")
  FFOV9c(self["keyYellow"], "Page Options")
  FFOV9c(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCgMHO.VV4aVy()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVeBho    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVQVP7        ,
   "green"   : self.VV5ndx       ,
   "yellow"  : self.VVXy1f        ,
   "blue"   : self.VVxtWH        ,
   "menu"   : self.VV7IyR        ,
   "info"   : self.VVki2m         ,
   "up"   : self.VVOGfJ          ,
   "down"   : self.VVXQkw         ,
   "left"   : self.VV2JtA         ,
   "right"   : self.VVuZuU         ,
   "pageUp"  : boundFunction(self.VV8DMz, True) ,
   "chanUp"  : boundFunction(self.VV8DMz, True) ,
   "pageDown"  : boundFunction(self.VV8DMz, False) ,
   "chanDown"  : boundFunction(self.VV8DMz, False) ,
   "next"   : self.VVNs4T        ,
   "last"   : self.VVe8m4         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFrRM6(self)
  FFkJyH(self)
  FFIRRt(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFJ3IJ(self, boundFunction(self.VVgZrs, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV7IyR(self):
  if not self.isBusy:
   VVWaOb = []
   VVWaOb.append(("Statistics"           , "VVFXm9"    ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Suggest PIcons for Current Channel"     , "VVHqa4"   ))
   VVWaOb.append(("Set to Current Channel (copy file)"     , "VVTreh_file"  ))
   VVWaOb.append(("Set to Current Channel (as SymLink)"     , "VVTreh_link"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(CCgMHO.VV0GRV())
   VVWaOb.append(VVIEqe)
   if self.filterTitle == "PIcons without Channels":
    c = VVCyLg
    VVWaOb.append((FFKY60("Move Unused PIcons to a Directory", c) , "VVrbdn"  ))
    VVWaOb.append((FFKY60("DELETE Unused PIcons", c)    , "VVPitc" ))
    VVWaOb.append(VVIEqe)
   VVWaOb.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VV3BSF"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb += CCgMHO.VVwS02()
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("RCU Keys Help"          , "VVEZ2R"    ))
   FFg6MQ(self, self.VV31gb, title=self.Title, VVWaOb=VVWaOb)
 def VV31gb(self, item=None):
  if item is not None:
   if   item == "VVFXm9"     : self.VVFXm9()
   elif item == "VVHqa4"    : self.VVHqa4()
   elif item == "VVTreh_file"   : self.VVTreh(0)
   elif item == "VVTreh_link"   : self.VVTreh(1)
   elif item == "VViv9b_file"  : self.VViv9b(0)
   elif item == "VViv9b_link"  : self.VViv9b(1)
   elif item == "VVVrFd"   : self.VVVrFd()
   elif item == "VVsG7f"  : self.VVsG7f()
   elif item == "VVrbdn"    : self.VVrbdn()
   elif item == "VVPitc"   : self.VVPitc()
   elif item == "VV3BSF"   : self.VV3BSF()
   elif item == "VVQPtU"   : CCgMHO.VVQPtU(self)
   elif item == "VVgwj9"   : CCgMHO.VVgwj9(self)
   elif item == "findPiconBrokenSymLinks"  : CCgMHO.VVSwgt(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCgMHO.VVSwgt(self, False)
   elif item == "VVEZ2R"      : self.VVEZ2R()
 def VVXy1f(self):
  if not self.isBusy:
   VVWaOb = []
   VVWaOb.append(("Go to First PIcon"  , "VVJA3q"  ))
   VVWaOb.append(("Go to Last PIcon"   , "VVWf3A"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Sort by Channel Name"     , "sortByChan" ))
   VVWaOb.append(("Sort by File Name"  , "sortByFile" ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Find from File List .." , "VVJiVe" ))
   FFg6MQ(self, self.VVrP8t, title=self.Title, VVWaOb=VVWaOb)
 def VVrP8t(self, item=None):
  if item is not None:
   if   item == "VVJA3q"   : self.VVJA3q()
   elif item == "VVWf3A"   : self.VVWf3A()
   elif item == "sortByChan"  : self.VV4vgH(2)
   elif item == "sortByFile"  : self.VV4vgH(0)
   elif item == "VVJiVe"  : self.VVJiVe()
 def VVEZ2R(self):
  FF2Z5t(self, VVGuqQ + "_help_picons", "PIcons Manager (Keys Help)")
 def VVOGfJ(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVWf3A()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVpA5U()
 def VVXQkw(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVJA3q()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVpA5U()
 def VV2JtA(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVWf3A()
  else:
   self.curCol -= 1
   self.VVpA5U()
 def VVuZuU(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVJA3q()
  else:
   self.curCol += 1
   self.VVpA5U()
 def VVe8m4(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVpA5U(True)
 def VVNs4T(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVpA5U(True)
 def VVJA3q(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVpA5U(True)
 def VVWf3A(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVpA5U(True)
 def VVJiVe(self):
  VVWaOb = []
  for item in self.VVeBho:
   VVWaOb.append((item[0], item[0]))
  FFg6MQ(self, self.VVIMzF, title='PIcons ".png" Files', VVWaOb=VVWaOb, VVsg09=True)
 def VVIMzF(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVQcWd(ndx)
 def VVQVP7(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VViVbV()
   if refCode:
    FFFZZb(self, refCode)
    self.VVgw3r()
    self.VVvjMy()
 def VV8DMz(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVgw3r()
   self.VVvjMy()
  except:
   pass
 def VV5ndx(self):
  if self["keyGreen"].getVisible():
   self.VVQcWd(self.curChanIndex)
 def VVQcWd(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVpA5U(True)
  else:
   FFU7uG(self, "Not found", 1000)
 def VV4vgH(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFJ3IJ(self, boundFunction(self.VVgZrs, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVTreh(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VViVbV()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVWaOb = []
     VVWaOb.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVWaOb.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFg6MQ(self, boundFunction(self.VVwjsn, mode, curChF, selPiconF), VVWaOb=VVWaOb, title="Current Channel PIcon (already exists)")
    else:
     self.VVwjsn(mode, curChF, selPiconF, "overwrite")
   else:
    FF23yv(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF23yv(self, "Could not read current channel info. !", title=title)
 def VVwjsn(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFJ3IJ(self, boundFunction(self.VVgZrs, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VViv9b(self, mode):
  pass
 def VVVrFd(self):
  pass
 def VVsG7f(self):
  pass
 def VVrbdn(self):
  defDir = FFVqav(CCgMHO.VV4aVy() + "picons_backup")
  os.system(FFFaNy("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VV07W5, defDir), boundFunction(CCpqJe
         , mode=CCpqJe.VVYZsL, VVM0xu=CCgMHO.VV4aVy()))
 def VV07W5(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCgMHO.VV4aVy():
    FF23yv(self, "Cannot move to same directory !", title=title)
   else:
    if not FFVqav(path) == FFVqav(defDir):
     self.VV8ww9(defDir)
    FFyVJ3(self, boundFunction(FFJ3IJ, self, boundFunction(self.VVC8h1, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVeBho), path), title=title)
  else:
   self.VV8ww9(defDir)
 def VVC8h1(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VV8ww9(defDir)
   FF23yv(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFVqav(toPath)
  pPath = CCgMHO.VV4aVy()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVeBho:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVeBho)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFx6I1(self, txt, title=title, VVTMiH="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVPWnP("all")
 def VV8ww9(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVPitc(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVeBho)
  s = "s" if tot > 1 else ""
  FFyVJ3(self, boundFunction(FFJ3IJ, self, boundFunction(self.VVlwqy, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVlwqy(self, title):
  pPath = CCgMHO.VV4aVy()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVeBho:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVeBho)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFKY60(str(totErr), VVCyLg)
  FFx6I1(self, txt, title=title)
 def VV3BSF(self):
  lines = FF8xGt("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFyVJ3(self, boundFunction(self.VVJJP7, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VV29o7=True)
  else:
   FFuW4T(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVJJP7(self, fList):
  os.system(FFFaNy("find -L '%s' -type l -delete" % self.pPath))
  FFuW4T(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVki2m(self):
  FFJ3IJ(self, self.VVgkGn)
 def VVgkGn(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VViVbV()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFKY60("PIcon Directory:\n", VV4E8E)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFEyqu(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFEyqu(path)
   txt += FFKY60("PIcon File:\n", VV4E8E)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FF8xGt(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFKY60("Found %d SymLink%s to this file from:\n" % (tot, s), VV4E8E)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFLN5X(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFKY60(tChName, VVuV1K)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFKY60(line, VVLLOq), tChName)
    txt += "\n"
   if chName:
    txt += FFKY60("Channel:\n", VV4E8E)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFKY60(chName, VVuV1K)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFKY60("Remarks:\n", VV4E8E)
    txt += "  %s\n" % FFKY60("Unused", VVCyLg)
  else:
   txt = "No info found"
  FFEjmz(self, fncMode=CCdLyC.VVSjYd, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VViVbV(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVeBho[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFUXWI(sat)
  return fName, refCode, chName, sat, inDB
 def VVgw3r(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVeBho):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVvjMy(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VViVbV()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFKY60("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV4E8E))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VViVbV()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFKY60(self.curChanName, VV106B)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVFXm9(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVeBho:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFKH1d("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFx6I1(self, txt, title=self.Title)
 def VVxtWH(self):
  if not self.isBusy:
   VVWaOb = []
   VVWaOb.append(("All"         , "all"   ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Used by Channels"      , "used"  ))
   VVWaOb.append(("Unused PIcons"      , "unused"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("PIcons Files"       , "pFiles"  ))
   VVWaOb.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVWaOb.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVWaOb.append(VVIEqe)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFzQfp(val)
      VVWaOb.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCJJAn(self)
   filterObj.VVBzCy(VVWaOb, self.nsList, self.VVGaRk)
 def VVGaRk(self, item=None):
  if item is not None:
   self.VVPWnP(item)
 def VVPWnP(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVmFcJ   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVRRRm   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVQN6m  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVmV5c  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VV92kw  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VViLjZ  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV894C   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVLdVD   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVinj4 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VViLjZ:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF8xGt("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFU7uG(self, "Not found", 1000)
     return
   elif mode == self.VVJ399:
    return
   else:
    words, asPrefix = CCJJAn.VVYNrj(words)
   if not words and mode in (self.VVLdVD, self.VVinj4):
    FFU7uG(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFJ3IJ(self, boundFunction(self.VVgZrs, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVHqa4(self):
  self.session.open(CC34Kz, barTheme=CC34Kz.VVwxZE
      , titlePrefix = ""
      , fncToRun  = self.VVDZAQ
      , VVn4v8 = self.VVw1LQ)
 def VVDZAQ(self, progBarObj):
  lameDbChans = CCpfVT.VVPQV0(self, CCpfVT.VV4cXk, VVUZCj=False, VV3Thx=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VV6IKE = []
  progBarObj.VVPaCP(len(lameDbChans))
  if lameDbChans:
   processChanName = CCySN5()
   curCh = processChanName.VVNFAq(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVKTFH(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCgMHO.VVm5KS(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCgMHO.VVhKtS(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VV6IKE.append(f.replace(".png", ""))
 def VVw1LQ(self, VVbWpI, VV6IKE, threadCounter, threadTotal, threadErr):
  if VV6IKE:
   self.timer = eTimer()
   fnc = boundFunction(FFJ3IJ, self, boundFunction(self.VVgZrs, mode=self.VVJ399, words=VV6IKE), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFU7uG(self, "Not found", 2000)
 def VVgZrs(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVPKMr(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCpfVT.VVPQV0(self, CCpfVT.VV4cXk, VVUZCj=False, VV3Thx=False)
  iptvRefList = self.VVEQNw()
  tList = []
  for fName, fType in CCgMHO.VVl27c(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVmFcJ:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVRRRm  and chName         : isAdd = True
   elif mode == self.VVQN6m and not chName        : isAdd = True
   elif mode == self.VVmV5c  and fType == 0        : isAdd = True
   elif mode == self.VV92kw  and fType == 1        : isAdd = True
   elif mode == self.VViLjZ  and fName in words       : isAdd = True
   elif mode == self.VVJ399 and fName in words       : isAdd = True
   elif mode == self.VV894C  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVLdVD  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVinj4:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVeBho   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFU7uG(self)
  else:
   self.isBusy = False
   FFU7uG(self, "Not found", 1000)
   return
  self.VVeBho.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVgw3r()
  self.totalPIcons = len(self.VVeBho)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVpA5U(True)
 def VVPKMr(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCgMHO.VVl27c(self.pPath):
    if fName:
     return True
   if isFirstTime : FF23yv(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFU7uG(self, "Not found", 1000)
  else:
   FF23yv(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVEQNw(self):
  VVuwbt = {}
  files  = CCy3Ly.VVOhYu(self)
  if files:
   for path in files:
    txt = FFGKC4(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVuwbt[refCode] = item[1]
  return VVuwbt
 def VVpA5U(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV7gHf = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV7gHf: self.curPage = VV7gHf
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVBe4U()
  if self.curPage == VV7gHf:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVvjMy()
  filName, refCode, chName, sat, inDB = self.VViVbV()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVBe4U(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVeBho[ndx]
   fName = self.VVeBho[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFKY60(chName, VVuV1K))
    else : lbl.setText("-")
   except:
    lbl.setText(FFKY60(chName, VVfDjZ))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVm5KS(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV0GRV():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVQPtU"   )
 @staticmethod
 def VVwS02():
  VVWaOb = []
  VVWaOb.append(("Find SymLinks (to PIcon Directory)"   , "VVgwj9"   ))
  VVWaOb.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVWaOb.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVWaOb
 @staticmethod
 def VVQPtU(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(SELF)
  png, path = CCgMHO.VVNJD6(refCode)
  if path : CCgMHO.VVzF96(SELF, png, path)
  else : FF23yv(SELF, "No PIcon found for current channel in:\n\n%s" % CCgMHO.VV4aVy())
 @staticmethod
 def VVgwj9(SELF):
  if VV106B:
   sed1 = FF8tq9("->", VV106B)
   sed2 = FF8tq9("picon", VVCyLg)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVfDjZ, VVbwNy)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFOKKC(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFcd50(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVSwgt(SELF, isPIcon):
  sed1 = FF8tq9("->", VVfDjZ)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF8tq9("picon", VVCyLg)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFOKKC(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFcd50(), grep, sed1, sed2))
 @staticmethod
 def VVl27c(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV4aVy():
  path = CFG.PIconsPath.getValue()
  return FFVqav(path)
 @staticmethod
 def VVNJD6(refCode, chName=None):
  if FFqdX4(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFlKLF(refCode)
  allPath, fName, refCodeFile, pList = CCgMHO.VVhKtS(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVzF96(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF8tq9("%s%s" % (dest, png), VVuV1K))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF8tq9(errTxt, VVvqWy))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFfB0P(SELF, cmd)
 @staticmethod
 def VVhKtS(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCgMHO.VV4aVy()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FF0IQR(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC4jJF():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVuOuH  = None
  self.VVYb7a = ""
  self.VVcqLq  = noService
  self.VVdLFB = 0
  self.VVSskS  = noService
  self.VVZduP = 0
  self.VVyDkT  = "-"
  self.VVXFTY = 0
  self.VV9ydl  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVaoRr(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVuOuH = frontEndStatus
     self.VVwzPY()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVwzPY(self):
  if self.VVuOuH:
   val = self.VVuOuH.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVYb7a = "%3.02f dB" % (val / 100.0)
   else         : self.VVYb7a = ""
   val = self.VVuOuH.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVdLFB = int(val)
   self.VVcqLq  = "%d%%" % val
   val = self.VVuOuH.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVZduP = int(val)
   self.VVSskS  = "%d%%" % val
   val = self.VVuOuH.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVyDkT  = "%d" % val
   val = int(val * 100 / 500)
   self.VVXFTY = min(500, val)
   val = self.VVuOuH.get("tuner_locked", 0)
   if val == 1 : self.VV9ydl = "Locked"
   else  : self.VV9ydl = "Not locked"
 def VV2GV7(self)   : return self.VVYb7a
 def VVQKCW(self)   : return self.VVcqLq
 def VVoRYy(self)  : return self.VVdLFB
 def VVJYWq(self)   : return self.VVSskS
 def VVvOLr(self)  : return self.VVZduP
 def VV9p4j(self)   : return self.VVyDkT
 def VVRYWX(self)  : return self.VVXFTY
 def VVP4Vn(self)   : return self.VV9ydl
 def VV2g3G(self) : return self.serviceName
class CC38xH():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVamxI(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFxPSj(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVjsuM(self.ORPOS  , mod=1   )
      self.sat2  = self.VVjsuM(self.ORPOS  , mod=2   )
      self.freq  = self.VVjsuM(self.FREQ  , mod=3   )
      self.sr   = self.VVjsuM(self.SR   , mod=4   )
      self.inv  = self.VVjsuM(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVjsuM(self.POL  , self.D_POL )
      self.fec  = self.VVjsuM(self.FEC  , self.D_FEC )
      self.syst  = self.VVjsuM(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVjsuM("modulation" , self.D_MOD )
       self.rolof = self.VVjsuM("rolloff"  , self.D_ROLOF )
       self.pil = self.VVjsuM("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVjsuM("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVjsuM("pls_code"  )
       self.iStId = self.VVjsuM("is_id"   )
       self.t2PlId = self.VVjsuM("t2mi_plp_id" )
       self.t2PId = self.VVjsuM("t2mi_pid"  )
 def VVjsuM(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFzQfp(val)
  elif mod == 2   : return FFMhop(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVjni9(self, refCode):
  txt = ""
  self.VVamxI(refCode)
  if self.data:
   def VVOCz2(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVOCz2("System"   , self.syst)
    txt += VVOCz2("Satellite"  , self.sat2)
    txt += VVOCz2("Frequency"  , self.freq)
    txt += VVOCz2("Inversion"  , self.inv)
    txt += VVOCz2("Symbol Rate"  , self.sr)
    txt += VVOCz2("Polarization" , self.pol)
    txt += VVOCz2("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVOCz2("Modulation" , self.mod)
     txt += VVOCz2("Roll-Off" , self.rolof)
     txt += VVOCz2("Pilot"  , self.pil)
     txt += VVOCz2("Input Stream", self.iStId)
     txt += VVOCz2("T2MI PLP ID" , self.t2PlId)
     txt += VVOCz2("T2MI PID" , self.t2PId)
     txt += VVOCz2("PLS Mode" , self.plsMod)
     txt += VVOCz2("PLS Code" , self.plsCod)
   else:
    txt += VVOCz2("System"   , self.txMedia)
    txt += VVOCz2("Frequency"  , self.freq)
  return txt, self.namespace
 def VVVxg8(self, refCode):
  txt = "Transpoder : ?"
  self.VVamxI(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV4E8E + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVNLQ6(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFxPSj(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVjsuM(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVjsuM(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVjsuM(self.SYST, self.D_SYS_S)
     freq = self.VVjsuM(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVjsuM(self.POL , self.D_POL)
      fec = self.VVjsuM(self.FEC , self.D_FEC)
      sr = self.VVjsuM(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVtYBX(self, refCode):
  self.data = None
  self.VVamxI(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCpY82():
 def __init__(self, VV7MC7, path, VVn4v8=None, curRowNum=-1):
  self.VV7MC7  = VV7MC7
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVn4v8  = VVn4v8
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFFaNy("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVfS7Y(curRowNum)
  else:
   FF23yv(self.VV7MC7, "Error while preparing edit!")
 def VVfS7Y(self, curRowNum):
  VVuwbt = self.VVChdP()
  VVINMZ = None #("Delete Line" , self.deleteLine  , [])
  VV76K2 = ("Save Changes" , self.VVmGAQ   , [])
  VViQOR  = ("Edit Line"  , self.VVQi3b    , [])
  VVzVsH = ("Line Options" , self.VVeAE2   , [])
  VVnz5d = (""    , self.VVx34f , [])
  VV4h3C = self.VV7jLH
  VVffKi  = self.VV0LIU
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVFXpL  = (CENTER  , LEFT  )
  VVgIs9 = FFemUu(self.VV7MC7, None, title=self.Title, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VVINMZ=VVINMZ, VV76K2=VV76K2, VViQOR=VViQOR, VVzVsH=VVzVsH, VV4h3C=VV4h3C, VVffKi=VVffKi, VVnz5d=VVnz5d, VVhUO0=True
    , VVKeoU   = "#11001111"
    , VVJRMb   = "#11001111"
    , VVTMiH   = "#11001111"
    , VVeFdq  = "#05333333"
    , VVmeUl  = "#00222222"
    , VV98nY  = "#11331133"
    )
  VVgIs9.VVJZto(curRowNum)
 def VVeAE2(self, VVgIs9, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVgIs9.VVbTV2()
  VVWaOb = []
  VVWaOb.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVWaOb.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVxNRX"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VV78jn:
   VVWaOb.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(  ("Delete Line"         , "deleteLine"   ))
  FFg6MQ(self.VV7MC7, boundFunction(self.VVGBxP, VVgIs9, lineNum), VVWaOb=VVWaOb, title="Line Options")
 def VVGBxP(self, VVgIs9, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVnQ2r("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVgIs9)
   elif item == "VVxNRX"  : self.VVxNRX(VVgIs9, lineNum)
   elif item == "copyToClipboard"  : self.VVQN05(VVgIs9, lineNum)
   elif item == "pasteFromClipboard" : self.VVbqwm(VVgIs9, lineNum)
   elif item == "deleteLine"   : self.VVnQ2r("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVgIs9)
 def VV0LIU(self, VVgIs9):
  VVgIs9.VV8bg2()
 def VVx34f(self, VVgIs9, title, txt, colList):
  if   self.insertMode == 1: VVgIs9.VVExql()
  elif self.insertMode == 2: VVgIs9.VVmqK6()
  self.insertMode = 0
 def VVxNRX(self, VVgIs9, lineNum):
  if lineNum == VVgIs9.VVbTV2():
   self.insertMode = 1
   self.VVnQ2r("echo '' >> '%s'" % self.tmpFile, VVgIs9)
  else:
   self.insertMode = 2
   self.VVnQ2r("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVgIs9)
 def VVQN05(self, VVgIs9, lineNum):
  global VV78jn
  VV78jn = FFKH1d("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVgIs9.VVjSfv("Copied to clipboard")
 def VVmGAQ(self, VVgIs9, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFFaNy("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFFaNy("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVgIs9.VVjSfv("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVgIs9.VV8bg2()
    else:
     FF23yv(self.VV7MC7, "Cannot save file!")
   else:
    FF23yv(self.VV7MC7, "Cannot create backup copy of original file!")
 def VV7jLH(self, VVgIs9):
  if self.fileChanged:
   FFyVJ3(self.VV7MC7, boundFunction(self.VV1JIi, VVgIs9), "Cancel changes ?")
  else:
   finalOK = os.system(FFFaNy("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VV1JIi(VVgIs9)
 def VV1JIi(self, VVgIs9):
  VVgIs9.cancel()
  os.system(FFFaNy("rm -f '%s'" % self.tmpFile))
  if self.VVn4v8:
   self.VVn4v8(self.fileSaved)
 def VVQi3b(self, VVgIs9, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVbwNy + "ORIGINAL TEXT:\n" + VVLLOq + lineTxt
  FF3PZZ(self.VV7MC7, boundFunction(self.VV5P0T, lineNum, VVgIs9), title="File Line", defaultText=lineTxt, message=message)
 def VV5P0T(self, lineNum, VVgIs9, VVfP6g):
  if not VVfP6g is None:
   if VVgIs9.VVbTV2() <= 1:
    self.VVnQ2r("echo %s > '%s'" % (VVfP6g, self.tmpFile), VVgIs9)
   else:
    self.VV0UQh(VVgIs9, lineNum, VVfP6g)
 def VVbqwm(self, VVgIs9, lineNum):
  if lineNum == VVgIs9.VVbTV2() and VVgIs9.VVbTV2() == 1:
   self.VVnQ2r("echo %s >> '%s'" % (VV78jn, self.tmpFile), VVgIs9)
  else:
   self.VV0UQh(VVgIs9, lineNum, VV78jn)
 def VV0UQh(self, VVgIs9, lineNum, newTxt):
  VVgIs9.VVGxQC("Saving ...")
  lines = FFcG5u(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVgIs9.VVDie1()
  VVuwbt = self.VVChdP()
  VVgIs9.VVDgsH(VVuwbt)
 def VVnQ2r(self, cmd, VVgIs9):
  tCons = CC1uI6()
  tCons.ePopen(cmd, boundFunction(self.VVfN5Q, VVgIs9))
  self.fileChanged = True
  VVgIs9.VVDie1()
 def VVfN5Q(self, VVgIs9, result, retval):
  VVuwbt = self.VVChdP()
  VVgIs9.VVDgsH(VVuwbt)
 def VVChdP(self):
  if fileExists(self.tmpFile):
   lines = FFcG5u(self.tmpFile)
   VVuwbt = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVuwbt.append((str(ndx), line.strip()))
   if not VVuwbt:
    VVuwbt.append((str(1), ""))
   return VVuwbt
  else:
   FFl2xw(self.VV7MC7, self.tmpFile)
class CCJJAn():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVWaOb   = []
  self.satList   = []
 def VV5fxX(self, VVn4v8):
  self.VVWaOb = []
  VVWaOb, VVRo1A = self.VVPafQ(False, True)
  if VVWaOb:
   self.VVWaOb += VVWaOb
   self.VVeCiA(VVn4v8, VVRo1A)
 def VVN1AA(self, mode, VVgIs9, satCol, VVn4v8):
  VVgIs9.VVGxQC("Loading Filters ...")
  self.VVWaOb = []
  self.VVWaOb.append(("All Services" , "all"))
  if mode == 1:
   self.VVWaOb.append(VVIEqe)
   self.VVWaOb.append(("Parental Control", "parentalControl"))
   self.VVWaOb.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVWaOb.append(VVIEqe)
   self.VVWaOb.append(("Selected Transponder"   , "selectedTP" ))
   self.VVWaOb.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVPwGC(VVgIs9, satCol)
  VVWaOb, VVRo1A = self.VVPafQ(True, False)
  if VVWaOb:
   VVWaOb.insert(0, VVIEqe)
   self.VVWaOb += VVWaOb
  VVgIs9.VVMe3Y()
  self.VVeCiA(VVn4v8, VVRo1A)
 def VVBzCy(self, VVWaOb, sats, VVn4v8):
  self.VVWaOb = VVWaOb
  VVWaOb, VVRo1A = self.VVPafQ(True, False)
  if VVWaOb:
   self.VVWaOb.append(VVIEqe)
   self.VVWaOb += VVWaOb
  self.VVeCiA(VVn4v8, VVRo1A)
 def VVeCiA(self, VVn4v8, VVRo1A):
  VVIAKx = ("Edit Filter", boundFunction(self.VVm3Wb, VVRo1A))
  VVFoGM  = ("Filter Help", boundFunction(self.VVR1dP, VVRo1A))
  FFg6MQ(self.callingSELF, boundFunction(self.VV6yVy, VVn4v8), VVWaOb=self.VVWaOb, title="Select Filter", VVIAKx=VVIAKx, VVFoGM=VVFoGM)
 def VV6yVy(self, VVn4v8, item):
  if item:
   VVn4v8(item)
 def VVm3Wb(self, VVRo1A, VVsszyObj, sel):
  if fileExists(VVRo1A) : CCpY82(self.callingSELF, VVRo1A, VVn4v8=None)
  else       : FFl2xw(self.callingSELF, VVRo1A)
  VVsszyObj.cancel()
 def VVR1dP(self, VVRo1A, VVsszyObj, sel):
  FF2Z5t(self.callingSELF, VVGuqQ + "_help_service_filter", "Service Filter")
 def VVPwGC(self, VVgIs9, satColNum):
  if not self.satList:
   satList = VVgIs9.VVqaMa(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFUXWI(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVIEqe)
  if self.VVWaOb:
   self.VVWaOb += self.satList
 def VVPafQ(self, addTag, VVxzdz):
  FFlr2o()
  fileName  = "ajpanel_services_filter"
  VVRo1A = VVx8df + fileName
  VVWaOb  = []
  if not fileExists(VVRo1A):
   os.system(FFFaNy("cp -f '%s' '%s'" % (VVGuqQ + fileName, VVRo1A)))
  fileFound = False
  if fileExists(VVRo1A):
   fileFound = True
   lines = FFcG5u(VVRo1A)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVWaOb.append((line, "__w__" + line))
       else  : VVWaOb.append((line, line))
  if VVxzdz:
   if   not fileFound : FFl2xw(self.callingSELF , VVRo1A)
   elif not VVWaOb : FFoblU(self.callingSELF , VVRo1A)
  return VVWaOb, VVRo1A
 @staticmethod
 def VVYNrj(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCIKdH():
 def __init__(self, callingSELF, VVgIs9, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVgIs9 = VVgIs9
  self.refCodeColNum = refCodeColNum
  self.VVWaOb = []
  iMulSel = self.VVgIs9.VVt0eR()
  if iMulSel : self.VVWaOb.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVWaOb.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVgIs9.VV23gB()
  self.VVWaOb.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVWaOb.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVWaOb.append(VVIEqe)
 def VVsoqo(self, servName, refCode):
  tot = self.VVgIs9.VV23gB()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVWaOb.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVvGk0_multi" ))
  else    : self.VVWaOb.append( ("Add to Bouquet : %s"      % servName , "VVvGk0_one" ))
  self.VV4GQA(servName, refCode)
 def VVWjJx(self, servName, refCode, pcState, hidState):
  self.VVWaOb = []
  if pcState == "No" : self.VVWaOb.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVWaOb.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVWaOb.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVWaOb.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VV4GQA(servName, refCode)
 def VV4GQA(self, servName, refCode):
  FFg6MQ(self.callingSELF, boundFunction(self.VVCpqh, servName, refCode), title="Options", VVWaOb=self.VVWaOb)
 def VVCpqh(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVgIs9.VV4kpS(True)
   elif item == "MultSelDisab"    : self.VVgIs9.VV4kpS(False)
   elif item == "selectAll"    : self.VVgIs9.VVpMUR()
   elif item == "unselectAll"    : self.VVgIs9.VVMLjp()
   elif item == "parentalControl_add"  : self.callingSELF.VVKnzM(self.VVgIs9, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVKnzM(self.VVgIs9, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VV1wLP(self.VVgIs9, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VV1wLP(self.VVgIs9, refCode, False)
   elif item == "VVvGk0_multi" : self.VVvGk0(refCode, True)
   elif item == "VVvGk0_one" : self.VVvGk0(refCode, False)
 def VVvGk0(self, refCode, isMulti):
  bouquets = FF6YXr()
  if bouquets:
   VVWaOb = []
   for item in bouquets:
    VVWaOb.append((item[0], item[1].toString()))
   VVIAKx = ("Create New", boundFunction(self.VVsrtn, refCode, isMulti))
   FFg6MQ(self.callingSELF, boundFunction(self.VVIy7m, refCode, isMulti), VVWaOb=VVWaOb, title="Add to Bouquet", VVIAKx=VVIAKx, VVsg09=True, VVTIf5=True)
  else:
   FFyVJ3(self.callingSELF, boundFunction(self.VVh3ph, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVIy7m(self, refCode, isMulti, bName=None):
  if bName:
   FFJ3IJ(self.VVgIs9, boundFunction(self.VV3PwR, refCode, isMulti, bName), title="Adding Channels ...")
 def VV3PwR(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVXRCg(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVzHgb = InfoBar.instance
    if VVzHgb:
     VV8sHQ = VVzHgb.servicelist
     if VV8sHQ:
      mutableList = VV8sHQ.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVgIs9.VVMe3Y()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFuW4T(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF23yv(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVXRCg(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVgIs9.VVqwv9(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVsrtn(self, refCode, isMulti, VVsszyObj, path):
  self.VVh3ph(refCode, isMulti)
 def VVh3ph(self, refCode, isMulti):
  FF3PZZ(self.callingSELF, boundFunction(self.VV1YkK, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV1YkK(self, refCode, isMulti, name):
  if name:
   FFJ3IJ(self.VVgIs9, boundFunction(self.VV1d0W, refCode, isMulti, name), title="Adding Channels ...")
 def VV1d0W(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVXRCg(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVzHgb = InfoBar.instance
    if VVzHgb:
     VV8sHQ = VVzHgb.servicelist
     if VV8sHQ:
      try:
       VV8sHQ.addBouquet(name, services)
       allOK = True
      except:
       try:
        VV8sHQ.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVgIs9.VVMe3Y()
   title = "Add to Bouquet"
   if allOK: FFuW4T(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF23yv(self.callingSELF, "Nothing added!", title=title)
class CCT258(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVV4Js, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFBDfs(self)
  FFOV9c(self["keyRed"]  , "Exit")
  FFOV9c(self["keyGreen"]  , "Save")
  FFOV9c(self["keyYellow"] , "Refresh")
  FFOV9c(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVTlfv  ,
   "green"   : self.VVHHUp ,
   "yellow"  : self.VVCQUf  ,
   "blue"   : self.VV3F30   ,
   "up"   : self.VVOGfJ    ,
   "down"   : self.VVXQkw   ,
   "left"   : self.VV2JtA   ,
   "right"   : self.VVuZuU   ,
   "cancel"  : self.VVTlfv
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVCQUf()
  self.VVtGp3()
  FFkJyH(self)
 def VVTlfv(self) : self.close(True)
 def VV3GUn(self) : self.close(False)
 def VV3F30(self):
  self.session.openWithCallback(self.VVnnGG, boundFunction(CCXY6f))
 def VVnnGG(self, closeAll):
  if closeAll:
   self.close()
 def VVOGfJ(self):
  self.VVFCAM(1)
 def VVXQkw(self):
  self.VVFCAM(-1)
 def VV2JtA(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVtGp3()
 def VVuZuU(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVtGp3()
 def VVFCAM(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVH2Ty(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVH2Ty(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVH2Ty(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVrbCN(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVrbCN(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVtGp3(self):
  for obj in self.list:
   FFIRRt(obj, "#11404040")
  FFIRRt(self.list[self.index], "#11ff8000")
 def VVCQUf(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVHHUp(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC1uI6()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVrzfb)
 def VVrzfb(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFuW4T(self, "Nothing returned from the system!")
  else:
   FFuW4T(self, str(result))
class CCXY6f(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVEG99, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFBDfs(self, addLabel=True)
  FFOV9c(self["keyRed"]  , "Exit")
  FFOV9c(self["keyGreen"]  , "Sync")
  FFOV9c(self["keyYellow"] , "Refresh")
  FFOV9c(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVTlfv   ,
   "green"   : self.VVaisS  ,
   "yellow"  : self.VVl5jl ,
   "blue"   : self.VVdyvd  ,
   "cancel"  : self.VVTlfv
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVdy2v()
  self.onShow.append(self.start)
 def start(self):
  FFewwi(self.refresh)
  FFkJyH(self)
 def refresh(self):
  self.VVXgXM()
  self.VVHWq0(False)
 def VVTlfv(self)  : self.close(True)
 def VVdyvd(self) : self.close(False)
 def VVdy2v(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVXgXM(self):
  self.VV58jU()
  self.VVtuq7()
  self.VVKvo9()
  self.VVIbYI()
 def VVl5jl(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVdy2v()
   self.VVXgXM()
   FFewwi(self.refresh)
 def VVaisS(self):
  if len(self["keyGreen"].getText()) > 0:
   FFyVJ3(self, self.VVdAKp, "Synchronize with Internet Date/Time ?")
 def VVdAKp(self):
  self.VVXgXM()
  FFewwi(boundFunction(self.VVHWq0, True))
 def VV58jU(self)  : self["keyRed"].show()
 def VV2nya(self)  : self["keyGreen"].show()
 def VVN8x6(self) : self["keyYellow"].show()
 def VVVxOW(self)  : self["keyBlue"].show()
 def VVtuq7(self)  : self["keyGreen"].hide()
 def VVKvo9(self) : self["keyYellow"].hide()
 def VVIbYI(self)  : self["keyBlue"].hide()
 def VVHWq0(self, sync):
  localTime = FFejuP()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVdd6s(server)
   if epoch_time is not None:
    ntpTime = FFv8BC(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC1uI6()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVrzfb, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVN8x6()
  self.VVVxOW()
  if ok:
   self.VV2nya()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVrzfb(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVHWq0(False)
  except:
   pass
 def VVdd6s(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFeI9s():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCR6Pe(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFDOid(VVTKnm, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFBDfs(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFewwi(self.VVt4N5)
 def VVt4N5(self):
  if FFeI9s(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFIRRt(self["myBody"], color)
   FFIRRt(self["myLabel"], color)
  except:
   pass
class CCMRdH(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFjdS6()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFDOid(VVZ4Z6, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCeggc(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCeggc(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCeggc(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC4jJF()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFBDfs(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVOGfJ          ,
   "down"  : self.VVXQkw         ,
   "left"  : self.VV2JtA         ,
   "right"  : self.VVuZuU         ,
   "info"  : self.VVm8io        ,
   "epg"  : self.VVm8io        ,
   "menu"  : self.VVEZ2R         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VV0bAF       ,
   "last"  : boundFunction(self.VVCeNQ, -1)  ,
   "next"  : boundFunction(self.VVCeNQ, 1)  ,
   "pageUp" : boundFunction(self.VVMdOw, True) ,
   "chanUp" : boundFunction(self.VVMdOw, True) ,
   "pageDown" : boundFunction(self.VVMdOw, False) ,
   "chanDown" : boundFunction(self.VVMdOw, False) ,
   "0"   : boundFunction(self.VVCeNQ, 0)  ,
   "1"   : boundFunction(self.VVs8Vj, pos=1) ,
   "2"   : boundFunction(self.VVs8Vj, pos=2) ,
   "3"   : boundFunction(self.VVs8Vj, pos=3) ,
   "4"   : boundFunction(self.VVs8Vj, pos=4) ,
   "5"   : boundFunction(self.VVs8Vj, pos=5) ,
   "6"   : boundFunction(self.VVs8Vj, pos=6) ,
   "7"   : boundFunction(self.VVs8Vj, pos=7) ,
   "8"   : boundFunction(self.VVs8Vj, pos=8) ,
   "9"   : boundFunction(self.VVs8Vj, pos=9) ,
  }, -1)
  self.onShown.append(self.VVKQSI)
  self.onClose.append(self.onExit)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self.sliderSNR.VV8DHd()
  self.sliderAGC.VV8DHd()
  self.sliderBER.VV8DHd(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVs8Vj()
  self.VVzUEkInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzUEk)
  except:
   self.timer.callback.append(self.VVzUEk)
  self.timer.start(500, False)
 def VVzUEkInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVaoRr(service)
  serviceName = self.tunerInfo.VV2g3G()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  tp = CC38xH()
  txt = tp.VVVxg8(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVzUEk(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVaoRr(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV2GV7())
   self["mySNR"].setText(self.tunerInfo.VVQKCW())
   self["myAGC"].setText(self.tunerInfo.VVJYWq())
   self["myBER"].setText(self.tunerInfo.VV9p4j())
   self.sliderSNR.VVkhYB(self.tunerInfo.VVoRYy())
   self.sliderAGC.VVkhYB(self.tunerInfo.VVvOLr())
   self.sliderBER.VVkhYB(self.tunerInfo.VVRYWX())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVkhYB(0)
   self.sliderAGC.VVkhYB(0)
   self.sliderBER.VVkhYB(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
    if state and not state == "Tuned":
     FFU7uG(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVm8io(self):
  FFEjmz(self, fncMode=CCdLyC.VVTSD8)
 def VVEZ2R(self):
  FF2Z5t(self, VVGuqQ + "_help_signal", "Signal Monitor (Keys)")
 def VV0bAF(self):
  self.session.open(CCjjWk, isFromExternal=self.isFromExternal)
  self.close()
 def VVOGfJ(self)  : self.VVs8Vj(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVXQkw(self) : self.VVs8Vj(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV2JtA(self) : self.VVs8Vj(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVuZuU(self) : self.VVs8Vj(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVs8Vj(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVCeNQ(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFyl8X(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVMdOw(self, isUp):
  FFU7uG(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVzUEkInfo()
  except:
   pass
class CCeggc(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV8DHd(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFIRRt(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVGuqQ +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFIRRt(self.covObj, self.covColor)
   else:
    FFIRRt(self.covObj, "#00006688")
    self.isColormode = True
  self.VVkhYB(0)
 def VVkhYB(self, val):
  val  = FFyl8X(val, self.minN, self.maxN)
  width = int(FFOfUP(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFyl8X(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC34Kz(Screen):
 VVwxZE    = 0
 VV1Vhb = 1
 VVFEoW = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVn4v8=None, barTheme=VVwxZE):
  ratio = self.VVJFZr(barTheme)
  self.skin, self.skinParam = FFDOid(VVbVWE, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVn4v8 = VVn4v8
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VV6IKE = None
  self.timer   = eTimer()
  self.myThread  = None
  FFBDfs(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVKQSI)
  self.onClose.append(self.onExit)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self.VVKqLZ()
  self["myProgBarVal"].setText("0%")
  FFIRRt(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVdeWI()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVdeWI)
  except:
   self.timer.callback.append(self.VVdeWI)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVPaCP(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVPXQN_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VV6IKE), self.counter, self.maxValue, catName)
 def VVPXQN_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVPXQN_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVdeWI()
  except:
   pass
 def VVKTFH(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VV6IKE), self.counter, self.maxValue)
  except:
   pass
 def VVsaof(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVdlNq(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV2BvL(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFU7uG(self, "Cancelling ...")
  self.isCancelled = True
  self.VV8PpP(False)
 def VV8PpP(self, isDone):
  if self.VVn4v8:
   self.VVn4v8(isDone, self.VV6IKE, self.counter, self.maxValue, self.isError)
  self.close()
 def VVdeWI(self):
  val = FFyl8X(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFOfUP(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VV8PpP(True)
 def VVKqLZ(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV1Vhb, self.VVFEoW):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVJFZr(self, barTheme):
  if   barTheme == self.VV1Vhb : return 0.7
  if   barTheme == self.VVFEoW : return 0.5
  else             : return 1
class CC1uI6(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVn4v8 = {}
  self.commandRunning = False
  self.VVC9Ss  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVn4v8, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVn4v8[name] = VVn4v8
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVC9Ss:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVKWWy, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVdxCa , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVKWWy, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVdxCa , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVdxCa(name, retval)
  return True
 def VVKWWy(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVdxCa(self, name, retval):
  if not self.VVC9Ss:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVn4v8[name]:
   self.VVn4v8[name](self.appResults[name], retval)
  del self.VVn4v8[name]
 def VVfUAc(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCYWEZ(Screen):
 def __init__(self, session, title="", VVuqfs=None, VVQ9hK=False, VV3MYb=False, VVQ59H=False, VVGMOB=False, VVSTOG=False, VVYmU2=False, VVJQke=VVLLcg, VVsNdD=None, VVNt88=False, VVLiPR=None, VVktQH="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFDOid(VVXzV5, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFBDfs(self, addScrollLabel=True)
  if not VVktQH:
   VVktQH = "Processing ..."
  self["myLabel"].setText("   %s" % VVktQH)
  self.VVQ9hK   = VVQ9hK
  self.VV3MYb   = VV3MYb
  self.VVQ59H   = VVQ59H
  self.VVGMOB  = VVGMOB
  self.VVSTOG = VVSTOG
  self.VVYmU2 = VVYmU2
  self.VVJQke   = VVJQke
  self.VVsNdD = VVsNdD
  self.VVNt88  = VVNt88
  self.VVLiPR  = VVLiPR
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC1uI6()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFChu1()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVuqfs, str):
   self.VVuqfs = [VVuqfs]
  else:
   self.VVuqfs = VVuqfs
  if self.VVQ59H or self.VVGMOB:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVJwpo, VVJwpo)
   self.VVuqfs.append("echo -e '\n%s\n' %s" % (restartNote, FF8tq9(restartNote, VV106B)))
   if self.VVQ59H:
    self.VVuqfs.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVuqfs.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVSTOG:
   FFU7uG(self, "Processing ...")
  self.onLayoutFinish.append(self.VVd9bO)
  self.onClose.append(self.VVBrB7)
 def VVd9bO(self):
  self["myLabel"].VVqzy0(textOutFile="console" if self.enableSaveRes else "")
  if self.VVQ9hK:
   self["myLabel"].VVTNO5()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVWL6Q()
  else:
   self.VVPxD7()
 def VVWL6Q(self):
  if FFeI9s():
   self["myLabel"].setText("Processing ...")
   self.VVPxD7()
  else:
   self["myLabel"].setText(FFKY60("\n   No connection to internet!", VVCyLg))
 def VVPxD7(self):
  allOK = self.container.ePopen(self.VVuqfs[0], self.VVEted, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVEted("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVYmU2 or self.VVQ59H or self.VVGMOB:
    self["myLabel"].setText(FFMugM("STARTED", VV106B) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVLiPR:
   colorWhite = CCY16h.VVo19M(VVbwNy)
   color  = CCY16h.VVo19M(self.VVLiPR[0])
   words  = self.VVLiPR[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVJQke=self.VVJQke)
 def VVEted(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVuqfs):
   allOK = self.container.ePopen(self.VVuqfs[self.cmdNum], self.VVEted, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVEted("Cannot connect to Console!", -1)
  else:
   if self.VVSTOG and FFJrZA(self):
    FFU7uG(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVYmU2:
    self["myLabel"].appendText("\n" + FFMugM("FINISHED", VV106B), self.VVJQke)
   if self.VVQ9hK or self.VV3MYb:
    self["myLabel"].VVTNO5()
   if self.VVsNdD is not None:
    self.VVsNdD()
   if not retval and self.VVNt88:
    self.VVBrB7()
 def VVBrB7(self):
  if self.container.VVfUAc():
   self.container.killAll()
class CCq3PM(Screen):
 def __init__(self, session, VVuqfs=None, VVSTOG=False):
  self.skin, self.skinParam = FFDOid(VVXzV5, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVx8df + "ajpanel_terminal.history"
  self.customCommandsFile = VVx8df + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFKH1d("pwd") or "/home/root"
  self.container   = CC1uI6()
  FFBDfs(self, addScrollLabel=True)
  FFOV9c(self["keyRed"] , "Exit = Stop Command")
  FFOV9c(self["keyGreen"] , "OK = History")
  FFOV9c(self["keyYellow"], "Menu = Custom Cmds")
  FFOV9c(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVvj7g ,
   "cancel" : self.VVkRdt  ,
   "menu"  : self.VVl7L6 ,
   "last"  : self.VVd8E4  ,
   "next"  : self.VVd8E4  ,
   "1"   : self.VVd8E4  ,
   "2"   : self.VVd8E4  ,
   "3"   : self.VVd8E4  ,
   "4"   : self.VVd8E4  ,
   "5"   : self.VVd8E4  ,
   "6"   : self.VVd8E4  ,
   "7"   : self.VVd8E4  ,
   "8"   : self.VVd8E4  ,
   "9"   : self.VVd8E4  ,
   "0"   : self.VVd8E4
  })
  self.onLayoutFinish.append(self.VVKQSI)
  self.onClose.append(self.VVPJIa)
 def VVKQSI(self):
  self["myLabel"].VVqzy0(isResizable=False, textOutFile="terminal")
  FFnGw1(self["keyRed"]  , "#00ff8000")
  FFIRRt(self["keyRed"]  , self.skinParam["titleColor"])
  FFIRRt(self["keyGreen"]  , self.skinParam["titleColor"])
  FFIRRt(self["keyYellow"] , self.skinParam["titleColor"])
  FFIRRt(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV8NfM(FFKH1d("date"), 5)
  result = FFKH1d("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVae70()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVGuqQ + "LinuxCommands.lst"
   newTemplate = VVGuqQ + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFFaNy("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFFaNy("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVPJIa(self):
  if self.container.VVfUAc():
   self.container.killAll()
   self.VV8NfM("Process killed\n", 4)
   self.VVae70()
 def VVkRdt(self):
  if self.container.VVfUAc():
   self.VVPJIa()
  else:
   FFyVJ3(self, self.close, "Exit ?", VVOlvi=False)
 def VVae70(self):
  self.VV8NfM(self.prompt, 1)
  self["keyRed"].hide()
 def VV8NfM(self, txt, mode):
  if   mode == 1 : color = VV106B
  elif mode == 2 : color = VV4E8E
  elif mode == 3 : color = VVbwNy
  elif mode == 4 : color = VVCyLg
  elif mode == 5 : color = VVLLOq
  elif mode == 6 : color = VVcP3M
  else   : color = VVbwNy
  try:
   self["myLabel"].appendText(FFKY60(txt, color))
  except:
   pass
 def VV3YQG(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV8NfM(cmd, 2)
   self.VV8NfM("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV8NfM(ch, 0)
   self.VV8NfM("\nor\n", 4)
   self.VV8NfM("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVae70()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFKY60(parts[0].strip(), VV4E8E)
    right = FFKY60("#" + parts[1].strip(), VVcP3M)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV8NfM(txt, 2)
   lastLine = self.VVEcWa()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVgHhw(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVEted, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF23yv(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV8NfM(data, 3)
 def VVEted(self, data, retval):
  if not retval == 0:
   self.VV8NfM("Exit Code : %d\n" % retval, 4)
  self.VVae70()
 def VVvj7g(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVEcWa() == "":
   self.VVgHhw("cd /tmp")
   self.VVgHhw("ls")
  VVuwbt = []
  if fileExists(self.commandHistoryFile):
   lines  = FFcG5u(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVuwbt.append((str(c), line, str(lNum)))
   self.VV4VGX(VVuwbt, title, self.commandHistoryFile, isHistory=True)
  else:
   FFl2xw(self, self.commandHistoryFile, title=title)
 def VVEcWa(self):
  lastLine = FFKH1d("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVgHhw(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVl7L6(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFcG5u(self.customCommandsFile)
   lastLineIsSep = False
   VVuwbt = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVuwbt.append((str(c), line, str(lNum)))
   self.VV4VGX(VVuwbt, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFl2xw(self, self.customCommandsFile, title=title)
 def VV4VGX(self, VVuwbt, title, filePath=None, isHistory=False):
  if VVuwbt:
   VVeFdq = "#05333333"
   if isHistory: VVKeoU = VVJRMb = VVTMiH = "#11000020"
   else  : VVKeoU = VVJRMb = VVTMiH = "#06002020"
   VVSWdY = VVzVsH = None
   VViQOR   = ("Send"   , self.VVzP6F        , [])
   VV76K2  = ("Modify & Send" , self.VVN5xy        , [])
   if isHistory:
    VVSWdY = ("Clear History" , self.VVH5sX        , [])
   elif filePath:
    VVzVsH = ("Edit File"  , boundFunction(self.VVQMeV, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVFXpL     = (CENTER  , LEFT   , CENTER )
   FFemUu(self, None, title=title, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VV76K2=VV76K2, VVSWdY=VVSWdY, VVzVsH=VVzVsH, VVhUO0=True
     , VVKeoU   = VVKeoU
     , VVJRMb   = VVJRMb
     , VVTMiH   = VVTMiH
     , VVzW3E  = "#05ffff00"
     , VVeFdq  = VVeFdq
    )
  else:
   FFoblU(self, filePath, title=title)
 def VVzP6F(self, VVgIs9, title, txt, colList):
  cmd = colList[1].strip()
  VVgIs9.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VV8NfM("\n%s\n" % cmd, 6)
   self.VV8NfM(self.prompt, 1)
  else:
   self.VV3YQG(cmd)
 def VVN5xy(self, VVgIs9, title, txt, colList):
  cmd = colList[1]
  self.VVP0sU(VVgIs9, cmd)
 def VVH5sX(self, VVgIs9, title, txt, colList):
  FFyVJ3(self, boundFunction(self.VVuQNf, VVgIs9), "Reset History File ?", title="Command History")
 def VVuQNf(self, VVgIs9):
  os.system(FFFaNy("echo '' > %s" % self.commandHistoryFile))
  VVgIs9.cancel()
 def VVQMeV(self, filePath, VVgIs9, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCpY82(self, filePath, VVn4v8=boundFunction(self.VVczrJ, VVgIs9), curRowNum=rowNum)
  else     : FFl2xw(self, filePath)
 def VVczrJ(self, VVgIs9, fileChanged):
  if fileChanged:
   VVgIs9.cancel()
   FFewwi(self.VVl7L6)
 def VVd8E4(self):
  self.VVP0sU(None, self.lastCommand)
 def VVP0sU(self, VVgIs9, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF3PZZ(self, boundFunction(self.VVFFIe, VVgIs9), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVFFIe(self, VVgIs9, cmd):
  if cmd and len(cmd) > 0:
   self.VV3YQG(cmd)
   if VVgIs9:
    VVgIs9.cancel()
class CCQB6F(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVfP6g="", VV30Nw=False, VVjQaP=False, isTrimEnds=True):
  self.skin, self.skinParam = FFDOid(VV5IWe, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFBDfs(self, title, addLabel=True)
  FFOV9c(self["keyRed"] , "Up/Down = Change")
  FFOV9c(self["keyGreen"] , "Overwrite")
  FFOV9c(self["keyYellow"], "Pick Key Map")
  FFOV9c(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVjQaP   = VVjQaP
  self.VV30Nw  = VV30Nw
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVfP6g, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVvQdN      ,
   "green"    : self.VVy7qU    ,
   "yellow"   : self.VVik0O      ,
   "blue"    : self.VVJKEO     ,
   "menu"    : self.VVKhoJ     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVbb2l, True) ,
   "down"    : boundFunction(self.VVbb2l, False) ,
   "left"    : self.VVvVAd       ,
   "right"    : self.VVsyVT       ,
   "home"    : self.VVN92Q       ,
   "end"    : self.VVjPyo       ,
   "next"    : self.VVCHyr      ,
   "last"    : self.VVaOPS      ,
   "deleteForward"  : self.VVCHyr      ,
   "deleteBackward" : self.VVaOPS      ,
   "tab"    : self.VVCcnc       ,
   "toggleOverwrite" : self.VVy7qU    ,
   "0"     : self.VV0Vsq     ,
   "1"     : self.VV0Vsq     ,
   "2"     : self.VV0Vsq     ,
   "3"     : self.VV0Vsq     ,
   "4"     : self.VV0Vsq     ,
   "5"     : self.VV0Vsq     ,
   "6"     : self.VV0Vsq     ,
   "7"     : self.VV0Vsq     ,
   "8"     : self.VV0Vsq     ,
   "9"     : self.VV0Vsq
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VV2RnE()
  self.onShown.append(self.VVKQSI)
  self.onClose.append(self.onExit)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFrRM6(self)
  self["myLabel"].setText(self.message)
  self.VVIoCz()
  if self.VV30Nw : self.VVy7qU()
  else    : self.VVNOYD()
  FFkJyH(self)
  FFIRRt(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVjEoO)
  except:
   self.timer.callback.append(self.VVjEoO)
 def onExit(self):
  self.timer.stop()
 def VVvQdN(self):
  self.VVojs3()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVojs3()
  self.close(None)
 def VVKhoJ(self):
  VVWaOb = []
  VVWaOb.append(("Home"         , "home"    ))
  VVWaOb.append(("End"         , "end"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Clear All"       , "clearAll"   ))
  VVWaOb.append(("Clear To Home"      , "clearToHome"   ))
  VVWaOb.append(("Clear To End"       , "clearToEnd"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VV78jn:
   VVWaOb.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("To Capital Letters"     , "toCapital"   ))
  VVWaOb.append(("To Small Letters"      , "toSmall"    ))
  FFg6MQ(self, self.VVvd6v, title="Edit Options", VVWaOb=VVWaOb)
 def VVvd6v(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVN92Q()
   elif item == "end"     : self.VVjPyo()
   elif item == "clearAll"    : self.VVDk3Z()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVN92Q()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VV78jn
    VV78jn = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VV78jn)
    self.VVN92Q()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVjEoO(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVy7qU(self):
  self["myInput"].toggleOverwrite()
  self.VVNOYD()
 def VVik0O(self):
  self.session.openWithCallback(self.VVn3TI, boundFunction(CCdR76, mode=self.charMode, VVjQaP=self.VVjQaP))
 def VVn3TI(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVIoCz()
 def VVNOYD(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VV2RnE(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVojs3(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVf927(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVvVAd(self)     : self.VVlbIQ(self["myInput"].left)
 def VVsyVT(self)     : self.VVlbIQ(self["myInput"].right)
 def VVCHyr(self)     : self.VVlbIQ(self["myInput"].delete)
 def VVN92Q(self)     : self.VVlbIQ(self["myInput"].home)
 def VVjPyo(self)     : self.VVlbIQ(self["myInput"].end)
 def VVaOPS(self)    : self.VVlbIQ(self["myInput"].deleteBackward)
 def VVCcnc(self)     : self.VVlbIQ(self["myInput"].tab)
 def VVDk3Z(self)     : self["myInput"].setText("")
 def VVlbIQ(self, fnc):
  fnc()
  self.VVjEoO()
 def VV0Vsq(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVf927(newChar, overwrite)
   self.VVLXEa(newChar, self["myInput"].mapping[number])
 def VVbb2l(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCdR76.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCdR76.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVf927(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVLXEa(newChar, group)
     break
 def VVLXEa(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVbwNy:
    group = VVLLOq + group.replace(newChar, FFKY60(newChar, VVbwNy, VVLLOq))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVJKEO(self):
  if self.VVjQaP : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVIoCz()
 def VVIoCz(self):
  self["myInput"].mapping = CCdR76.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCdR76.RCU_MAP_TITLES[self.charMode])
class CCdR76(Screen):
 VV3znz  = 0
 VVpwhP  = 1
 VVUmOz  = 2
 VVddyq  = 3
 VVv7sM = 4
 VVuuOp = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VV3znz, VVjQaP=False):
  self.skin, self.skinParam = FFDOid(VVOlRK, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVjQaP  = VVjQaP
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFBDfs(self, title=self.Title)
  FFOV9c(self["keyRed"] ,"OK = Select")
  FFOV9c(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVOF0Q     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VV3BaD, -1) ,
   "next"  : boundFunction(self.VV3BaD, +1) ,
   "left"  : boundFunction(self.VV3BaD, -1) ,
   "right"  : boundFunction(self.VV3BaD, +1) ,
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFIRRt(self["keyRed"], "#11222222")
  FFIRRt(self["keyGreen"], "#11222222")
  self.VVhXBY()
 def VVhXBY(self):
  self.VVZR0f()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVZR0f(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VV3BaD(self, direction):
  if self.VVjQaP : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVhXBY()
 def VVOF0Q(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCg3Sc(Screen):
 def __init__(self, session, title="", message="", VVJQke=VVLLcg, VVMjH7=False, VVTMiH=None, VVZWCz=30):
  self.skin, self.skinParam = FFDOid(VVXzV5, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVZWCz)
  self.session   = session
  FFBDfs(self, title, addScrollLabel=True)
  self.VVJQke   = VVJQke
  self.VVMjH7   = VVMjH7
  self.VVTMiH   = VVTMiH
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self["myLabel"].VVqzy0(VVMjH7=self.VVMjH7)
  self["myLabel"].setText(self.message, self.VVJQke)
  if self.VVTMiH:
   FFIRRt(self["myBody"], self.VVTMiH)
   FFIRRt(self["myLabel"], self.VVTMiH)
   FFiulc(self["myLabel"], self.VVTMiH)
  self["myLabel"].VVTNO5()
class CCCkN8(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFDOid(VVDhOp, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFBDfs(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFMpsS(self["errPic"], "err")
class CCSx0Y(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFDOid(VVEj4h, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFBDfs(self, " ", addCloser=True)
class CCWCk4():
 def __init__(self, tSession, txt):
  self.win = tSession.instantiateDialog(CCSx0Y, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.timer   = eTimer()
  self.timerCounter = 0
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzh9n)
  except:
   self.timer.callback.append(self.VVzh9n)
  self.timer.start(100, False)
 def VVzh9n(self):
  self.timerCounter += 1
  if self.timerCounter > 15:
   self.timer.stop()
   self.win.hide()
class CCuRcG():
 VVn5ST    = 0
 VVVKbG  = 1
 VVQcMY   = ""
 VVFeuE    = "ajpDownload"
 VVjKbg    = "/home/root/ajpanel_downloads"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVgIs9   = None
  self.timer     = eTimer()
  self.VVfBAO   = 0
  self.VVueEX  = 1
  self.VVtvsD  = 2
  self.VVunvy   = 3
  self.VVKMBC   = 4
  VVuwbt = self.VVFaaX()
  if VVuwbt:
   self.VVgIs9 = self.VVtTKm(VVuwbt)
  if not VVuwbt and mode == self.VVn5ST:
   self.VVxzdzor("Download list is empty !")
   self.cancel()
  if mode == self.VVVKbG:
   FFJ3IJ(self.VVgIs9 or self.SELF, boundFunction(self.VVkQBK, startDnld, decodedUrl), title="Checking Server ...")
  self.VV9ykH(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9ykH)
  except:
   self.timer.callback.append(self.VV9ykH)
  self.timer.start(1000, False)
 def VVtTKm(self, VVuwbt):
  VVuwbt.sort(key=lambda x: int(x[0]))
  VV4h3C = self.VVzXgr
  VViQOR  = ("Play"  , self.VVC8F6 , [])
  VVf1jQ = (""   , self.VVIK8C  , [])
  VVINMZ = ("Stop"  , self.VV6Dja  , [])
  VV76K2 = ("Resume"  , self.VVNRm9 , [])
  VVSWdY = ("Options" , self.VV7IyR  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVFXpL  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFemUu(self.SELF, None, title=self.Title, header=header, VVeBho=VVuwbt, VVFXpL=VVFXpL, VVEHj0=widths, VVZWCz=26, VViQOR=VViQOR, VVf1jQ=VVf1jQ, VV4h3C=VV4h3C, VVINMZ=VVINMZ, VV76K2=VV76K2, VVSWdY=VVSWdY, VVJRMb="#11110011", VVKeoU="#11220022", VVTMiH="#11110011", VVzW3E="#00ffff00", VVeFdq="#00223025", VVmeUl="#0a333333", VV98nY="#0a400040", VVhUO0=True, searchCol=1)
 def VVFaaX(self):
  lines = CCuRcG.VVcnmH()
  VVuwbt = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVaygh(decodedUrl)
      if fName:
       if   FFVS8N(decodedUrl) : sType = "Movie"
       elif FF50RV(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVmBR1(decodedUrl, fName)
       if size > -1: sizeTxt = CCpqJe.VVhdHk(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVuwbt.append((str(len(VVuwbt) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVuwbt
 def VV2GUA(self):
  VVuwbt = self.VVFaaX()
  if VVuwbt:
   if self.VVgIs9 : self.VVgIs9.VVDgsH(VVuwbt, VVdy2vMsg=False)
   else     : self.VVgIs9 = self.VVtTKm(VVuwbt)
  else:
   self.cancel()
 def VV9ykH(self, force=False):
  if self.VVgIs9:
   thrList = self.VVmkIz()
   VVuwbt = []
   changed = False
   for ndx, row in enumerate(self.VVgIs9.VVnSZ7()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVfBAO
    if m3u8Log:
     percent = self.VVfkky(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVunvy , "%.2f %%" % percent
      else   : flag, progr = self.VVKMBC , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFfblo(mPath)
     if curSize > -1:
      fSize = CCpqJe.VVhdHk(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCpqJe.VVhdHk(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFfblo(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVunvy , "%.2f %%" % percent
       else   : flag, progr = self.VVKMBC , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCpqJe.VVhdHk(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVtvsD
     if m3u8Log :
      if not speed and not force : flag = self.VVueEX
      elif curSize == -1   : self.VVMUGZ(False)
    elif flag == self.VVfBAO  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVfBAO  : color2 = "#f#00555555#"
    elif flag == self.VVueEX : color2 = "#f#0000FFFF#"
    elif flag == self.VVtvsD : color2 = "#f#0000FFFF#"
    elif flag == self.VVunvy  : color2 = "#f#00FF8000#"
    elif flag == self.VVKMBC  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVhGFq(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVuwbt.append(row)
   if changed or force:
    self.VVgIs9.VVDgsH(VVuwbt, VVdy2vMsg=False)
 def VVhGFq(self, flag):
  tDict = self.VVn1uy()
  return tDict.get(flag, "?")
 def VVj1ng(self, state):
  for flag, txt in self.VVn1uy().items():
   if txt == state:
    return flag
  return -1
 def VVn1uy(self):
  return { self.VVfBAO: "Not started", self.VVueEX: "Connecting", self.VVtvsD: "Downloading", self.VVunvy: "Stopped", self.VVKMBC: "Completed" }
 def VVHtaZ(self, title):
  colList = self.VVgIs9.VVxWgR()
  path = colList[6]
  url  = colList[8]
  if self.VVthGU() : self.VVxzdzor("Cannot delete !\n\nFile is downloading.")
  else      : FFyVJ3(self.SELF, boundFunction(self.VVGih1, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVGih1(self, path, url):
  m3u8Log = self.VVgIs9.VVxWgR()[12].strip()
  if m3u8Log : os.system(FFFaNy("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFFaNy("rm -r '%s'" % path))
  self.VVXF4p()
  self.VV2GUA()
 def VVXF4p(self):
  if self.VVthGU():
   FFU7uG(self.VVgIs9, self.VVhGFq(self.VVtvsD), 500)
  else:
   colList  = self.VVgIs9.VVxWgR()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVj1ng(state) in (self.VVfBAO, self.VVKMBC):
    lines = CCuRcG.VVcnmH()
    newLines = []
    found = False
    for line in lines:
     if CCuRcG.VVhMAi(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVs1JQ(newLines)
     self.VV2GUA()
     FFU7uG(self.VVgIs9, "Removed.", 1000)
    else:
     FFU7uG(self.VVgIs9, "Not found.", 1000)
   else:
    self.VVxzdzor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVTVi7(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFyVJ3(self.SELF, boundFunction(self.VVaZXm, flag), ques, title=title)
 def VVaZXm(self, flag):
  list = []
  for ndx, row in enumerate(self.VVgIs9.VVnSZ7()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVj1ng(state)
   if   flag == flagVal == self.VVKMBC: list.append(decodedUrl)
   elif flag == flagVal == self.VVfBAO : list.append(decodedUrl)
  lines = CCuRcG.VVcnmH()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVs1JQ(newLines)
   self.VV2GUA()
   FFU7uG(self.VVgIs9, "%d removed." % totRem, 1000)
  else:
   FFU7uG(self.VVgIs9, "Not found.", 1000)
 def VVtL0R(self):
  colList  = self.VVgIs9.VVxWgR()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFU7uG(self.VVgIs9, "Poster exists", 1500)
  else    : FFJ3IJ(self.VVgIs9, boundFunction(self.VV4APY, decodedUrl, path, png), title="Checking Server ...")
 def VV4APY(self, decodedUrl, path, png):
  err = self.VVPYFS(decodedUrl, path, png)
  if err:
   FF23yv(self.SELF, err, title="Poster Download")
 def VVPYFS(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CClqge.VV8lKz(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCy3Ly.VV8ofO(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCy3Ly.VVSslx(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCy3Ly.VVvKvd(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFmoGG(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFFaNy("mv -f '%s' '%s'" % (tPath, png)))
    FFJYru(self.SELF, title=os.path.basename(png), VVl8kD=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVIK8C(self, VVgIs9, title, txt, colList):
  def VVCkU8(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVOCz2(key, val) : return "\n%s:\n%s\n" % (FFKY60(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVgIs9.VVfBqA()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVCkU8(heads[i]  , CCpqJe.VVhdHk(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVCkU8("Downloaded" , CCpqJe.VVhdHk(int(curSize), mode=0))
   else:
    txt += VVCkU8(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVOCz2(heads[i], colList[i])
  FFx6I1(self.SELF, txt, title=title)
 def VVC8F6(self, VVgIs9, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCpqJe.VVJMzy(self.SELF, path)
  else    : FFU7uG(self.VVgIs9, "File not found", 1000)
 def VVzXgr(self, VVgIs9):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVgIs9:
   self.VVgIs9.cancel()
  del self
 def VV7IyR(self, VVgIs9, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVWaOb = []
  VVWaOb.append(("Remove current row"      , "VVXF4p"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(('Remove all "Completed"'     , "remFinished"    ))
  VVWaOb.append(('Remove all "Not started"'     , "remPending"    ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Delete the file (and remove from list)" , "VVHtaZ" ))
  if FFVS8N(decodedUrl):
   VVWaOb.append(VVIEqe)
   VVWaOb.append(("Download Movie Poster (from server)" , "VVtL0R"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append((resumeTxt + " Auto Resume"     , "VVizx7"  ))
  FFg6MQ(self.SELF, self.VVbIUr, VVWaOb=VVWaOb, title=self.Title, VVsg09=True, VVTIf5=True)
 def VVbIUr(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVXF4p"  : self.VVXF4p()
   elif ref == "remFinished"   : self.VVTVi7(self.VVKMBC, txt)
   elif ref == "remPending"   : self.VVTVi7(self.VVfBAO, txt)
   elif ref == "VVHtaZ" : self.VVHtaZ(txt)
   elif ref == "VVtL0R"  : self.VVtL0R()
   elif ref == "VVizx7"  : self.VVizx7()
 def VVkQBK(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CClqge.VV8lKz(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVxzdzor("Could not get download link !\n\nTry again later.")
     return
  for line in CCuRcG.VVcnmH():
   if CCuRcG.VVhMAi(decodedUrl, line):
    self.VVoezh(decodedUrl)
    FFewwi(boundFunction(FFU7uG, self.VVgIs9, "Already listed !", 2000))
    break
  else:
   params = self.VV6amE(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVxzdzor(params[0])
   elif len(params) == 2:
    self.VVx8aB(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCpqJe.VVhdHk(fSize)
    FFyVJ3(self.SELF, boundFunction(self.VVMxdU, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVMxdU(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCuRcG.VVjKbg, "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VV2GUA()
  if self.VVgIs9:
   self.VVgIs9.VVmqK6()
  if startDnld:
   threadName = self.VVFeuE + decodedUrl
   self.VVXf8o(threadName, url, decodedUrl, path, resp)
 def VVoezh(self, decodedUrl):
  for ndx, row in enumerate(self.VVgIs9.VVnSZ7()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVgIs9:
    self.VVgIs9.VVuEmH(ndx)
    break
 def VV6amE(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVaygh(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVmBR1(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CClqge.VV8lKz(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CClqge.VVggfkHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCuRcG.VVGsxr(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVx8aB(self, resp, decodedUrl):
  if not os.system(FFFaNy("which ffmpeg")) == 0:
   FFyVJ3(self.SELF, boundFunction(CCy3Ly.VVeWyk, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVaygh(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVcjPA(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFyVJ3(self.SELF, boundFunction(self.VViPn3, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VViPn3(rTxt, rUrl)
  else:
   self.VVxzdzor("Cannot process m3u8 file !")
 def VVcjPA(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVWaOb = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCy3Ly.VV2KWG(rUrl, fPath)
   VVWaOb.append((resol, fullUrl))
  if VVWaOb:
   FFg6MQ(self.SELF, self.VVEYna, VVWaOb=VVWaOb, title="Resolution", VVsg09=True, VVTIf5=True)
  else:
   self.VVxzdzor("Cannot get Resolutions list from server !")
 def VVEYna(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFyVJ3(self.SELF, boundFunction(FFewwi, boundFunction(self.VVLqUe, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFewwi(boundFunction(self.VVLqUe, resolUrl))
 def VVLqUe(self, resolUrl):
  txt, err = CClqge.VVHykG(resolUrl)
  if err : self.VVxzdzor(err)
  else : self.VViPn3(txt, resolUrl)
 def VVVJMS(self, logF, decodedUrl):
  found = False
  lines = CCuRcG.VVcnmH()
  with open(CCuRcG.VVjKbg, "w") as f:
   for line in lines:
    if CCuRcG.VVhMAi(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCuRcG.VVjKbg, "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VV2GUA()
 def VViPn3(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCy3Ly.VV2KWG(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVxzdzor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVVJMS(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFFaNy("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVFeuE + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVfkky(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVhn6U(dnldLog)
   if dur > -1:
    tim = self.VVJv18(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVhn6U(self, dnldLog):
  lines = FF8xGt("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVJv18(self, dnldLog):
  lines = FF8xGt("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVmBR1(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FF50RV(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFFaNy("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVXf8o(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVgIs9.VVxWgR()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VV09rP, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV09rP(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCuRcG.VVQcMY == path:
       break
     else:
      break
  except:
   return
  if CCuRcG.VVQcMY:
   CCuRcG.VVQcMY = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFfblo(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV6amE(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV09rP(url, decodedUrl, path, resp, totFileSize, True)
 def VV6Dja(self, VVgIs9, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV71nL() : FFU7uG(self.VVgIs9, self.VVhGFq(self.VVKMBC), 500)
  elif not self.VVthGU() : FFU7uG(self.VVgIs9, self.VVhGFq(self.VVunvy), 500)
  elif m3u8Log      : FFyVJ3(self.SELF, self.VVMUGZ, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVmkIz():
    CCuRcG.VVQcMY = colList[6]
    FFU7uG(self.VVgIs9, "Stopping ...", 1000)
   else:
    FFU7uG(self.VVgIs9, "Stopped", 500)
 def VVMUGZ(self, withMsg=True):
  if withMsg:
   FFU7uG(self.VVgIs9, "Stopping ...", 1000)
  os.system(FFFaNy("killall -INT ffmpeg"))
 def VVizx7(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVNRm9(self, *args):
  if   self.VV71nL() : FFU7uG(self.VVgIs9, self.VVhGFq(self.VVKMBC) , 500)
  elif self.VVthGU() : FFU7uG(self.VVgIs9, self.VVhGFq(self.VVtvsD), 500)
  else:
   resume = False
   m3u8Log = self.VVgIs9.VVxWgR()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFyVJ3(self.SELF, boundFunction(self.VVj5kq, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV6PY8():
    resume = True
   if resume: FFJ3IJ(self.VVgIs9, boundFunction(self.VVYr8m), title="Checking Server ...")
   else  : FFU7uG(self.VVgIs9, "Cannot resume !", 500)
 def VVj5kq(self, m3u8Log):
  os.system(FFFaNy("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFJ3IJ(self.VVgIs9, boundFunction(self.VVYr8m), title="Checking Server ...")
 def VVYr8m(self):
  colList  = self.VVgIs9.VVxWgR()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CClqge.VV8lKz(decodedUrl)
   if url:
    decodedUrl = self.VVK3Eb(decodedUrl, url)
   else:
    self.VVxzdzor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFfblo(path)
  params = self.VV6amE(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVxzdzor(params[0])
   return
  elif len(params) == 2:
   self.VVx8aB(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVK3Eb(decodedUrl, url, fSize)
  threadName = self.VVFeuE + decodedUrl
  if resumable: self.VVXf8o(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVxzdzor("Cannot resume from server !")
 def VVaygh(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVxzdzor(self, txt):
  FF23yv(self.SELF, txt, title=self.Title)
 def VVmkIz(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVFeuE in thr.name:
    thrList.append(thr.name.replace(self.VVFeuE, ""))
  return thrList
 def VVthGU(self):
  decodedUrl = self.VVgIs9.VVxWgR()[9].strip()
  return decodedUrl in self.VVmkIz()
 def VV71nL(self):
  colList = self.VVgIs9.VVxWgR()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFfblo(path)) == size
 def VV6PY8(self):
  colList = self.VVgIs9.VVxWgR()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFfblo(path)
  if curSize > -1:
   size -= curSize
  err = CCuRcG.VVGsxr(size)
  if err:
   FF23yv(self.SELF, err, title=self.Title)
   return False
  return True
 def VVs1JQ(self, list):
  with open(CCuRcG.VVjKbg, "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVK3Eb(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCuRcG.VVcnmH()
  url = decodedUrl
  with open(CCuRcG.VVjKbg, "w") as f:
   for line in lines:
    if CCuRcG.VVhMAi(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VV2GUA()
  return url
 @staticmethod
 def VVcnmH():
  list = []
  if fileExists(CCuRcG.VVjKbg):
   for line in FFcG5u(CCuRcG.VVjKbg):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVhMAi(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVGsxr(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCpqJe.VVx4F9(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCpqJe.VVhdHk(size), CCpqJe.VVhdHk(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVyEwB(SELF):
  tot = CCuRcG.VVMiyH()
  if tot:
   FF23yv(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVMiyH():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCuRcG.VVFeuE):
    c += 1
  return c
 @staticmethod
 def VV1snA():
  return len(CCuRcG.VVcnmH()) == 0
 @staticmethod
 def VVapAR():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVqbxo():
  mPoints = CCuRcG.VVapAR()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFFaNy("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVcmaF(SELF):
  CCuRcG.VVDdYC(SELF, CCuRcG.VVn5ST)
 @staticmethod
 def VVD8EE_cur(SELF):
  CCuRcG.VVDdYC(SELF, CCuRcG.VVVKbG, startDnld=True)
 @staticmethod
 def VVD8EE_url(SELF, url):
  CCuRcG.VVDdYC(SELF, CCuRcG.VVVKbG, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVhGCwCurrent(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(SELF)
  added, skipped = CCuRcG.VVhGCwList([decodedUrl])
  FFU7uG(SELF, "Added", 1000)
 @staticmethod
 def VVhGCwList(list):
  added = skipped = 0
  for line in CCuRcG.VVcnmH():
   for ndx, url in enumerate(list):
    if url and CCuRcG.VVhMAi(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCuRcG.VVjKbg, "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVDdYC(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCoCKj.VV8GeH(SELF):
   return
  if mode == CCuRcG.VVn5ST and CCuRcG.VV1snA():
   FF23yv(SELF, "Download list is empty !", title=title)
  else:
   inst = CCuRcG(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCjjWk(Screen, CCG19q):
 VVO8OD = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFDOid(VVjaS2, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCG19q.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFBDfs(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVeYb9())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVAJFV         ,
   "info"  : self.VVm8io        ,
   "epg"  : self.VVm8io        ,
   "menu"  : self.VVdT34       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVHeSY        ,
   "green"  : self.VVRf93    ,
   "yellow" : self.VV4Jls   ,
   "left"  : boundFunction(self.VVm4OS, -1)   ,
   "right"  : boundFunction(self.VVm4OS,  1)   ,
   "play"  : self.VVaFsZ        ,
   "pause"  : self.VVaFsZ        ,
   "playPause" : self.VVaFsZ        ,
   "stop"  : self.VVaFsZ        ,
   "rewind" : self.VVgUPb        ,
   "forward" : self.VVzGdB        ,
   "rewindDm" : self.VVgUPb        ,
   "forwardDm" : self.VVzGdB        ,
   "last"  : boundFunction(self.VVWV8k, 0)    ,
   "next"  : self.VV68Dg        ,
   "pageUp" : boundFunction(self.VVnNn4, True) ,
   "pageDown" : boundFunction(self.VVnNn4, False) ,
   "chanUp" : boundFunction(self.VVnNn4, True) ,
   "chanDown" : boundFunction(self.VVnNn4, False) ,
   "up"  : boundFunction(self.VVnNn4, True) ,
   "down"  : boundFunction(self.VVnNn4, False) ,
   "audio"  : boundFunction(self.VVC25k, True) ,
   "subtitle" : boundFunction(self.VVC25k, False) ,
   "0"   : boundFunction(self.VVrxn8 , 10)  ,
   "1"   : boundFunction(self.VVrxn8 , 1)  ,
   "2"   : boundFunction(self.VVrxn8 , 2)  ,
   "3"   : boundFunction(self.VVrxn8 , 3)  ,
   "4"   : boundFunction(self.VVrxn8 , 4)  ,
   "5"   : boundFunction(self.VVrxn8 , 5)  ,
   "6"   : boundFunction(self.VVrxn8 , 6)  ,
   "7"   : boundFunction(self.VVrxn8 , 7)  ,
   "8"   : boundFunction(self.VVrxn8 , 8)  ,
   "9"   : boundFunction(self.VVrxn8 , 9)
  }, -1)
  self.onShown.append(self.VVKQSI)
  self.onClose.append(self.onExit)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFrRM6(self)
  if not CCjjWk.VVO8OD:
   CCjjWk.VVO8OD = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  self["myPlayDnld"].instance.move(ePoint(int(left - self.skinParam["titleH"]), int(top)))
  self["myPlayDnld"].hide()
  FFMpsS(self["myPlayDnld"], "dnld")
  self.VVsehL()
  self.instance.move(ePoint(40, 40))
  self.VVtQHl(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZBiM)
  except:
   self.timer.callback.append(self.VVZBiM)
  self.timer.start(250, False)
  self.VVZBiM("Checking ...")
  self.VVrjHT()
 def VVRf93(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if "chCode" in iptvRef:
   if CCoCKj.VV8GeH(self):
    self.VVrjHT(True)
 def VVsehL(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFIRRt(self["myTitle"], color)
 def VVdT34(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  VVWaOb = []
  if self.isFromExternal:
   VVWaOb.append(("IPTV Menu"     , "iptv"  ))
   VVWaOb.append(VVIEqe)
  if FFqdX4(iptvRef) and not "&end=" in decodedUrl and not FFUVTe(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCy3Ly.VV8ofO(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVWaOb.append(("Catchup Programs"   , "catchup"  ))
    VVWaOb.append(VVIEqe)
  VVWaOb.append(("Stop Current Service"    , "stop"  ))
  VVWaOb.append(("Restart Current Service"   , "restart"  ))
  VVWaOb.append(VVIEqe)
  FFVS8NSeries = FFUVTe(decodedUrl)
  if FFVS8NSeries:
   VVWaOb.append(("File Size"     , "fileSize" ))
   VVWaOb.append(VVIEqe)
  if self.enableDownloadMenu:
   addSep = False
   if FFqdX4(iptvRef) and FFVS8NSeries:
    VVWaOb.append(("Start Download"   , "dload_cur" ))
    VVWaOb.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCuRcG.VV1snA():
    VVWaOb.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVWaOb.append(VVIEqe)
  if not CCpqJe.VVRNBC:
   fPath, fDir, fName = CCpqJe.VVd6oA(self)
   if fPath:
    VVWaOb.append((VV106B + "Open path in File Manager", "VVJmHE"))
    VVWaOb.append(VVIEqe)
  VVWaOb.append(("Move to Top"      , "top"   ))
  VVWaOb.append(("Move to Bottom"     , "botm"  ))
  VVWaOb.append(("Help"        , "help"  ))
  FFg6MQ(self, self.VVy9EN, VVWaOb=VVWaOb, width=550, title="Options")
 def VVy9EN(self, item=None):
  if item:
   if item == "iptv"    : self.VV8X9i()
   elif item == "catchup"   : self.VV4Jls()
   elif item == "stop"    : self.VVE1hs(0)
   elif item == "restart"   : self.VVE1hs(1)
   elif item == "fileSize"   : FFJ3IJ(self, boundFunction(CCdLyC.VVfJDu, self), title="Checking Server")
   elif item == "dload_cur"  : CCuRcG.VVD8EE_cur(self)
   elif item == "addToDload"  : CCuRcG.VVhGCwCurrent(self)
   elif item == "dload_stat"  : CCuRcG.VVcmaF(self)
   elif item == "VVJmHE": self.VVJmHE()
   elif item == "botm"    : self.VVtQHl(0)
   elif item == "top"    : self.VVtQHl(1)
   elif item == "help"    : FF2Z5t(self, VVGuqQ + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCjjWk.VVO8OD = None
 def VVphwV(self):
  if CCjjWk.VVO8OD:
   self.session.open(CCjjWk, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVJmHE(self):
  self.session.open(CCpqJe, gotoMovie=True)
  self.VVphwV()
 def VV8X9i(self):
  self.session.open(CCy3Ly)
  self.VVphwV()
 def VVE1hs(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVZBiM("Restarting Service ...")
    FFewwi(boundFunction(self.VVywYQ, serv))
 def VVywYQ(self, serv):
  self.session.nav.stopService()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if "&end=" in decodedUrl: boundFunction(self.VVrjHT, True)
  else     : self.session.nav.playService(serv)
 def VVtQHl(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVAJFV(self):
  if self.isManualSeek:
   self.VVGWoK()
   self.VVWV8k(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVGWoK()
  else:
   self.close()
 def VVm8io(self):
  FFEjmz(self, fncMode=CCdLyC.VVX1bN)
 def VVaFsZ(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVZBiM("Toggling Play/Pause ...")
 def VVGWoK(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVm4OS(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVejKf()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFyl8X(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFOfUP(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFSof4(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVrxn8(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFOV9c(self["myPlayJmp"], self.VVeYb9())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVZBiM("Changed Jump Minutes to : %d" % val)
 def VVeYb9(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVZBiM(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  fr = res = ""
  if info:
   w = FFeTHY(info, iServiceInformation.sVideoWidth) or -1
   h = FFeTHY(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFeTHY(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCdLyC.VVEyX0(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVejKf()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFyl8X(percVal, 0, 100)
    width = int(FFOfUP(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFIRRt(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFIRRt(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVDpDb() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFnGw1(self["myPlayMsg"], "#0000ffff")
   else  : FFnGw1(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFXG8g(refCode, True))
   FFnGw1(self["myPlayMsg"], "#00ff8066")
  tot = CCuRcG.VVMiyH()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVRLmx()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVWV8k(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VV5WFH()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFnGw1(self["myPlayMsg"], "#0000ff00")
  else     : FFnGw1(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVejKf(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFSof4(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFSof4(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFSof4(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVRLmx(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVHeSY(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVDpDb()
   if cList:
    VVWaOb = []
    for pts, what in cList:
     txt = FFSof4(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVWaOb.append((txt, pts))
    FFg6MQ(self, self.VVEo4U, VVWaOb=VVWaOb, title="Cut List")
   else:
    self.VVZBiM("No Cut-List for this channel !")
 def VVEo4U(self, item=None):
  if item:
   self.VVWV8k(item)
 def VVDpDb(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVzGdB(self) : self.VVZz3l(self.jumpMinutes)
 def VVgUPb(self) : self.VVZz3l(-self.jumpMinutes)
 def VVZz3l(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVZBiM("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVZBiM("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVZBiM("Cannot jump")
 def VVPhxe(self):
  InfoBar.instance.VVPhxe()
 def VVWV8k(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVZBiM("Changing Time ...")
 def VV68Dg(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVejKf()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVZBiM("Jumping to end ...")
  except:
   pass
 def VV5WFH(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVnNn4(self, isUp):
  if self.enableZapping:
   self.VVZBiM("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVGWoK()
   if self.portalTableParam:
    FFewwi(boundFunction(self.VVlQPD, isUp))
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
    if "/timeshift/" in decodedUrl:
     self.VVZBiM("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVpNO1()
 def VVpNO1(self):
  self.lastPlayPos = 0
  self.VVsehL()
  self.VVrjHT()
 def VVlQPD(self, isUp):
  CCy3Ly_inatance, VVgIs9, mode = self.portalTableParam
  if isUp : VVgIs9.VV28oe()
  else : VVgIs9.VV6fbj()
  colList = VVgIs9.VVxWgR()
  if mode == "localIptv":
   chName, chUrl = CCy3Ly_inatance.VVUtGk(VVgIs9, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCy3Ly_inatance.VVVXLb(VVgIs9, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCy3Ly_inatance.VVrbJT(mode, VVgIs9, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCy3Ly_inatance.VVWG3m(mode, VVgIs9, colList)
  else:
   self.VVZBiM("Cannot Zap")
   return
  FFFZZb(self, chUrl, VVYxnj=False)
  self.VVpNO1()
 def VVrjHT(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVejKf()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
   if not self.VVoiqq(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVZBiM("Refreshing Portal")
   FFewwi(self.VV9Jwp)
  except:
   pass
 def VV9Jwp(self):
  self.restoreLastPlayPos = self.VV0thB()
 def VV4Jls(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpoqY(self)
  if not decodedUrl or FFUVTe(decodedUrl):
   self.VVZBiM("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCy3Ly.VV8ofO(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVZBiM("Reading Program List ...")
   ok_fnc = boundFunction(self.VVe2Ja, refCode, chName, streamId, uHost, uUser, uPass)
   FFewwi(boundFunction(CCy3Ly.VVzrF6, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVZBiM("Cannot process this channel")
 def VVe2Ja(self, refCode, chName, streamId, uHost, uUser, uPass, VVgIs9, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVgIs9.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVZBiM("Changing Program ...")
   FFewwi(boundFunction(self.VV4pII, chUrl))
  else:
   self.VVZBiM("Incorrect Timestamp !")
 def VV4pII(self, chUrl):
   FFFZZb(self, chUrl, VVYxnj=False)
   self.lastPlayPos = 0
   self.VVsehL()
 def VVC25k(self, isAudio):
  try:
   VVzHgb = InfoBar.instance
   if VVzHgb:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVzHgb)
    else  : self.session.open(SubtitleSelection, VVzHgb)
  except:
   pass
class CCWlfT(Screen):
 def __init__(self, session, title="", VVB4L8="Continue?", VVOlvi=True, VV29o7=False):
  self.skin, self.skinParam = FFDOid(VVPtcs, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVB4L8 = VVB4L8
  self.VV29o7 = VV29o7
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVOlvi : VVWaOb = [no , yes]
  else   : VVWaOb = [yes, no ]
  FFBDfs(self, title, VVWaOb=VVWaOb, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVAJFV ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVB4L8)
  if self.VV29o7:
   self["myLabel"].instance.setHAlign(0)
  self.VVjv4d()
  FF0JHQ(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFSlzW(self["myMenu"])
  FFlEQt(self, self["myMenu"])
 def VVAJFV(self):
  item = FFeWTY(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVjv4d(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCMyIz(Screen):
 def __init__(self, session, title="", VVWaOb=None, width=1000, OKBtnFnc=None, VVinCp=None, VVB6Er=None, VVIAKx=None, VVFoGM=None, VVsg09=False, VVTIf5=False):
  self.skin, self.skinParam = FFDOid(VVxulX, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVWaOb   = VVWaOb
  self.OKBtnFnc   = OKBtnFnc
  self.VVinCp   = VVinCp
  self.VVB6Er  = VVB6Er
  self.VVIAKx  = VVIAKx
  self.VVFoGM   = VVFoGM
  self.VVsg09  = VVsg09
  self.VVTIf5  = VVTIf5
  FFBDfs(self, title, VVWaOb=VVWaOb)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVAJFV          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVy5tu         ,
   "green"  : self.VVav9E         ,
   "yellow" : self.VVeyOh         ,
   "blue"  : self.VViPPg         ,
   "pageUp" : self.VVFhwE       ,
   "chanUp" : self.VVFhwE       ,
   "pageDown" : self.VV70VM        ,
   "chanDown" : self.VV70VM
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FF0JHQ(self["myMenu"])
  FFeGgr(self)
  self.VVb4Sc(self["keyRed"]  , self.VVinCp )
  self.VVb4Sc(self["keyGreen"] , self.VVB6Er )
  self.VVb4Sc(self["keyYellow"] , self.VVIAKx )
  self.VVb4Sc(self["keyBlue"]  , self.VVFoGM )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFkJyH(self)
 def VVb4Sc(self, btnObj, btnFnc):
  if btnFnc:
   FFOV9c(btnObj, btnFnc[0])
 def VVAJFV(self):
  item = FFeWTY(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVsg09: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVy5tu(self)  : self.VVlbIQ(self.VVinCp)
 def VVav9E(self) : self.VVlbIQ(self.VVB6Er)
 def VVeyOh(self) : self.VVlbIQ(self.VVIAKx)
 def VViPPg(self) : self.VVlbIQ(self.VVFoGM)
 def VVlbIQ(self, btnFnc):
  if btnFnc:
   item = FFeWTY(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVTIf5:
    self.cancel()
 def VVHYqW(self, VVWaOb):
  if len(VVWaOb) > 0:
   newList = []
   for item in VVWaOb:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVSJx2(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVFhwE(self):
  self["myMenu"].moveToIndex(0)
 def VV70VM(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCQc3e(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVeBho=None, VVFXpL=None, VVEHj0=None, VVZWCz=26, VVhUO0=False, VViQOR=None, VVf1jQ=None, VVINMZ=None, VV76K2=None, VVSWdY=None, VVzVsH=None, VVffKi=None, VVnz5d=None, VV4h3C=None, VVPytF=-1, VVTqck=False, searchCol=0, VVKeoU=None, VVJRMb=None, VVa4YU="#00dddddd", VVTMiH="#11002233", VVzW3E="#00ff8833", VVeFdq="#11111111", VVmeUl="#0a555555", VVRC9a="#0affffff", VV98nY="#11552200", VV5GXT="#0055ff55"):
  self.skin, self.skinParam = FFDOid(VVoKhm, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFBDfs(self, title)
  self.header     = header
  self.VVeBho     = VVeBho
  self.totalCols    = len(VVeBho[0])
  self.VVpfJg   = 0
  self.lastSortModeIsReverese = False
  self.VVhUO0   = VVhUO0
  self.VVYPJm   = 0.01
  self.VVzV1w   = 0.02
  self.VVJ0IY = 0.03
  self.VVpczJ  = 1
  self.VVEHj0 = VVEHj0
  self.colWidthPixels   = []
  self.VViQOR   = VViQOR
  self.OKButtonObj   = None
  self.VVf1jQ   = VVf1jQ
  self.VVINMZ   = VVINMZ
  self.VV76K2   = VV76K2
  self.VVSWdY  = VVSWdY
  self.VVzVsH   = VVzVsH
  self.VVffKi    = VVffKi
  self.VVnz5d   = VVnz5d
  self.VV4h3C  = VV4h3C
  self.VVPytF    = VVPytF
  self.VVTqck   = VVTqck
  self.searchCol    = searchCol
  self.VVFXpL    = VVFXpL
  self.keyPressed    = -1
  self.VVZWCz    = FFbWyc(VVZWCz)
  self.VVEvPQ    = FFtbg0(self.VVZWCz, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVKeoU    = VVKeoU
  self.VVJRMb      = VVJRMb
  self.VVa4YU    = FFJrVj(VVa4YU)
  self.VVTMiH    = FFJrVj(VVTMiH)
  self.VVzW3E    = FFJrVj(VVzW3E)
  self.VVeFdq    = FFJrVj(VVeFdq)
  self.VVmeUl   = FFJrVj(VVmeUl)
  self.VVRC9a    = FFJrVj(VVRC9a)
  self.VV98nY    = FFJrVj(VV98nY)
  self.VV5GXT   = FFJrVj(VV5GXT)
  self.VVXex3  = False
  self.selectedItems   = 0
  self.VVpwrT   = FFJrVj("#01fefe01")
  self.VVscXR   = FFJrVj("#11400040")
  self.VV3tAt  = self.VVpwrT
  self.VVh0do  = self.VVeFdq
  if self.VVTqck:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVu1Uk  ,
   "red"   : self.VVAYE9  ,
   "green"   : self.VVyWnO ,
   "yellow"  : self.VV7AYF ,
   "blue"   : self.VVRPoW  ,
   "menu"   : self.VV4j4G ,
   "info"   : self.VVhNXE  ,
   "cancel"  : self.VVjTqL  ,
   "up"   : self.VV6fbj    ,
   "down"   : self.VV28oe  ,
   "left"   : self.VVe8m4   ,
   "right"   : self.VVNs4T  ,
   "pageUp"  : self.VVyqjt  ,
   "chanUp"  : self.VVyqjt  ,
   "pageDown"  : self.VVmqK6  ,
   "chanDown"  : self.VVmqK6
  }, -1)
  FFiDNM(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFrRM6(self)
  try:
   self.VVKfOg()
  except Exception as err:
   FF23yv(self, str(err))
   self.close(None)
 def VVKfOg(self):
  FFkJyH(self)
  if self.VVKeoU:
   FFIRRt(self["myTitle"], self.VVKeoU)
  if self.VVJRMb:
   FFIRRt(self["myBody"] , self.VVJRMb)
   FFIRRt(self["myTableH"] , self.VVJRMb)
   FFIRRt(self["myTable"] , self.VVJRMb)
   FFIRRt(self["myBar"]  , self.VVJRMb)
  self.VVb4Sc(self.VVINMZ  , self["keyRed"])
  self.VVb4Sc(self.VV76K2  , self["keyGreen"])
  self.VVb4Sc(self.VVSWdY , self["keyYellow"])
  self.VVb4Sc(self.VVzVsH  , self["keyBlue"])
  if self.VViQOR:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VViQOR[0])
    FFIRRt(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVEvPQ)
  self["myTableH"].l.setFont(0, gFont(VVEixg, self.VVZWCz))
  self["myTable"].l.setItemHeight(self.VVEvPQ)
  self["myTable"].l.setFont(0, gFont(VVEixg, self.VVZWCz))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVEvPQ)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVEvPQ))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVEvPQ)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVEvPQ
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVEvPQ * len(self.VVeBho) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVEHj0:
   self.VVEHj0 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVEHj0)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVFXpL:
   self.VVFXpL = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVFXpL
   self.VVFXpL = []
   for item in tmpList:
    self.VVFXpL.append(item | RT_VALIGN_CENTER)
  self.VV39O8()
  if self.VVffKi:
   self.VVffKi(self)
 def VVb4Sc(self, btnFnc, btn):
  if btnFnc : FFOV9c(btn, btnFnc[0])
  else  : FFOV9c(btn, "")
 def VVwf2y(self, waitTxt):
  FFJ3IJ(self, self.VV39O8, title=waitTxt)
 def VV39O8(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVPH0a(0, self.header, self.VVRC9a, self.VV98nY, self.VVRC9a, self.VV98nY, self.VV5GXT)])
   rows = []
   for c, row in enumerate(self.VVeBho):
    rows.append(self.VVPH0a(c, row, self.VVa4YU, self.VVTMiH, self.VVzW3E, self.VVeFdq, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVPytF > -1:
    self["myTable"].moveToIndex(self.VVPytF )
   self.VVRBRl()
   if self.VVTqck:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVEvPQ * len(self.VVeBho)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVnz5d:
    self.VVlbIQ(self.VVnz5d, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF23yv(self, str(err))
    self.close()
   except:
    pass
 def VVPH0a(self, keyIndex, columns, VVa4YU, VVTMiH, VVzW3E, VVeFdq, VV5GXT):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV5GXT and ndx == self.VVpfJg : textColor = VV5GXT
   else           : textColor = VVa4YU
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFJrVj(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVTMiH = c
    entry = span.group(3)
   if self.VVFXpL[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVEvPQ)
           , font   = 0
           , flags   = self.VVFXpL[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVTMiH
           , color_sel  = VVzW3E
           , backcolor_sel = VVeFdq
           , border_width = 1
           , border_color = self.VVmeUl
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVhNXE(self):
  rowData = self.VVHHEa()
  if rowData:
   title, txt, colList = rowData
   if self.VVf1jQ:
    fnc  = self.VVf1jQ[1]
    params = self.VVf1jQ[2]
    fnc(self, title, txt, colList)
   else:
    FFx6I1(self, txt, title)
 def VVu1Uk(self):
  if   self.VVXex3 : self.VVlhyz(self.VVIxU2(), mode=2)
  elif self.VViQOR  : self.VVlbIQ(self.VViQOR, None)
  else      : self.VVhNXE()
 def VVAYE9(self) : self.VVlbIQ(self.VVINMZ , self["keyRed"])
 def VVyWnO(self) : self.VVlbIQ(self.VV76K2 , self["keyGreen"])
 def VV7AYF(self): self.VVlbIQ(self.VVSWdY , self["keyYellow"])
 def VVRPoW(self) : self.VVlbIQ(self.VVzVsH , self["keyBlue"])
 def VVlbIQ(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFU7uG(self, buttonFnc[3])
    FFewwi(boundFunction(self.VVTIqK, buttonFnc))
   else:
    self.VVTIqK(buttonFnc)
 def VVTIqK(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVHHEa()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVlhyz(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVeBho[ndx]
   isSelected = row[1][9] == self.VVpwrT
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVPH0a(ndx, item, self.VVa4YU, self.VVTMiH, self.VVzW3E, self.VVeFdq, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVPH0a(ndx, item, self.VVpwrT, self.VVscXR, self.VV3tAt, self.VVh0do, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVRBRl()
 def VVpMUR(self):
  FFJ3IJ(self, self.VVJfro, title="Selecting all ...")
 def VVJfro(self):
  self.VV4kpS(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVpwrT
   if not isSelected:
    item = self.VVeBho[ndx]
    newRow = self.VVPH0a(ndx, item, self.VVpwrT, self.VVscXR, self.VV3tAt, self.VVh0do, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVRBRl()
  self.VVgT9B()
 def VVMLjp(self):
  FFJ3IJ(self, self.VVVelD, title="Unselecting all ...")
 def VVVelD(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVpwrT:
    item = self.VVeBho[ndx]
    newRow = self.VVPH0a(ndx, item, self.VVa4YU, self.VVTMiH, self.VVzW3E, self.VVeFdq, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVRBRl()
  self.VVgT9B()
 def VVgT9B(self):
  self.hide()
  self.show()
 def VVHHEa(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVEHj0[i] > 1 or self.VVEHj0[i] == self.VVYPJm or self.VVEHj0[i] == self.VVJ0IY:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVeBho))
   return rowNum, txt, colList
  else:
   return None
 def VVjTqL(self):
  if self.VV4h3C : self.VV4h3C(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVfnQk(self):
  return self["myTitle"].getText().strip()
 def VVfBqA(self):
  return self.header
 def VVeZJv(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVGxQC(self, txt):
  FFU7uG(self, txt)
 def VVjSfv(self, txt):
  FFU7uG(self, txt, 1000)
 def VVMe3Y(self):
  FFU7uG(self)
 def VVbTV2(self):
  return len(self.VVeBho)
 def VVDie1(self): self["keyGreen"].show()
 def VV8bg2(self): self["keyGreen"].hide()
 def VVIxU2(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVM3Tt(self):
  return len(self["myTable"].list)
 def VV4kpS(self, isOn):
  self.VVXex3 = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVzVsH: self["keyBlue"].hide()
   if self.VViQOR and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVzVsH: self["keyBlue"].show()
   if self.VViQOR and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VViQOR[0])
   self.VVMLjp()
  FFIRRt(self["myTitle"], color)
  FFIRRt(self["myBar"]  , color)
 def VVt0eR(self):
  return self.VVXex3
 def VV23gB(self):
  return self.selectedItems
 def VVJZto(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVRBRl()
 def VVExql(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVRBRl()
 def VVbdsm(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVeBho:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVAM6U(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVbTV2()
  txt += FFMugM("Total Unique Items", VVCyLg)
  for i in range(self.totalCols):
   if self.VVEHj0[i - 1] > 1 or self.VVEHj0[i - 1] == self.VVYPJm or self.VVEHj0[i - 1] == self.VVJ0IY:
    name, tot = self.VVbdsm(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFx6I1(self, txt)
 def VVZVaS(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVxWgR(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVDgsH(self, newList, newTitle="", VVdy2vMsg=True):
  if newList:
   self.VVeBho = newList
   if self.VVhUO0 and self.VVpfJg == 0:
    self.VVeBho = sorted(self.VVeBho, key=lambda x: int(x[self.VVpfJg])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVeBho = sorted(self.VVeBho, key=lambda x: x[self.VVpfJg].lower(), reverse=self.lastSortModeIsReverese)
   if VVdy2vMsg : self.VVwf2y("Refreshing ...")
   else   : self.VV39O8()
   if newTitle:
    self.VVeZJv(newTitle)
  else:
   FF23yv(self, "Cannot refresh list")
   self.cancel()
 def VVJCuN(self, data):
  ndx = self.VVIxU2()
  newRow = self.VVPH0a(ndx, data, self.VVa4YU, self.VVTMiH, self.VVzW3E, self.VVeFdq, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVRBRl()
   return True
  else:
   return False
 def VVPRhs(self, colNum, textToFind, VVxzdz=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVRBRl()
    break
  else:
   if VVxzdz:
    FFU7uG(self, "Not found", 1000)
 def VVxwwa(self, colDict, VVxzdz=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVRBRl()
    return
  if VVxzdz:
   FFU7uG(self, "Not found", 1000)
 def VVxwwa_partial(self, colDict, VVxzdz=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVRBRl()
    return
  if VVxzdz:
   FFU7uG(self, "Not found", 1000)
 def VVqaMa(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVqwv9(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVpwrT:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVnSZ7(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV4j4G(self):
  if not self["keyMenu"].getVisible() or self.VVTqck:
   return
  VVWaOb = []
  VVWaOb.append(("Table Statistcis"             , "tableStat"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append((FFKY60("Export Table to .html"     , VVCyLg) , "VV3ZJu" ))
  VVWaOb.append((FFKY60("Export Table to .csv"     , VVCyLg) , "VVaK5c" ))
  VVWaOb.append((FFKY60("Export Table to .txt (Tab Separated)", VVCyLg) , "VVvA2f" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVEHj0[i] > 1 or self.VVEHj0[i] == self.VVzV1w:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVWaOb.append(VVIEqe)
   if tot == 1 : VVWaOb.append(("Sort", sList[0][1]))
   else  : VVWaOb += sList
  FFg6MQ(self, self.VVYv2l, VVWaOb=VVWaOb, title=self.VVfnQk())
 def VVYv2l(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVAM6U()
   elif item == "VV3ZJu": FFJ3IJ(self, self.VV3ZJu, title=title)
   elif item == "VVaK5c" : FFJ3IJ(self, self.VVaK5c , title=title)
   elif item == "VVvA2f" : FFJ3IJ(self, self.VVvA2f , title=title)
   else:
    isReversed = False
    if self.VVpfJg == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVhUO0 and item == 0:
     self.VVeBho = sorted(self.VVeBho, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVeBho = sorted(self.VVeBho, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVpfJg = item
    self.VVwf2y("Sorting ...")
 def VV6fbj(self):
  self["myTable"].up()
  self.VVRBRl()
 def VV28oe(self):
  self["myTable"].down()
  self.VVRBRl()
 def VVe8m4(self):
  self["myTable"].pageUp()
  self.VVRBRl()
 def VVNs4T(self):
  self["myTable"].pageDown()
  self.VVRBRl()
 def VVyqjt(self):
  self["myTable"].moveToIndex(0)
  self.VVRBRl()
 def VVmqK6(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVRBRl()
 def VVuEmH(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVRBRl()
 def VVvA2f(self):
  expFile = self.VVh6x3() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVBGVu()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVeBho:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVEHj0[ndx] > self.VVpczJ or self.VVEHj0[ndx] == self.VVJ0IY:
      col = self.VVUM3b(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVzI5J(expFile)
 def VVaK5c(self):
  expFile = self.VVh6x3() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVBGVu()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVeBho:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVEHj0[ndx] > self.VVpczJ or self.VVEHj0[ndx] == self.VVJ0IY:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVUM3b(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVzI5J(expFile)
 def VV3ZJu(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVfnQk(), PLUGIN_NAME, VVE71u)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVfnQk()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVBGVu()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVEHj0:
   colgroup += '   <colgroup>'
   for w in self.VVEHj0:
    if w > self.VVpczJ or w == self.VVJ0IY:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVh6x3() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVeBho:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVEHj0[ndx] > self.VVpczJ or self.VVEHj0[ndx] == self.VVJ0IY:
      col = self.VVUM3b(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVzI5J(expFile)
 def VVBGVu(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVEHj0[ndx] > self.VVpczJ or self.VVEHj0[ndx] == self.VVJ0IY:
     newRow.append(col.strip())
  return newRow
 def VVUM3b(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF0IQR(col)
 def VVh6x3(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVfnQk())
  fileName = fileName.replace("__", "_")
  path  = FFVqav(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFBQPI()
  return expFile
 def VVzI5J(self, expFile):
  FFuW4T(self, "File exported to:\n\n%s" % expFile, title=self.VVfnQk())
 def VVRBRl(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCGHol(Screen):
 def __init__(self, session, title="", VVl8kD=None, showGrnMsg=""):
  self.skin, self.skinParam = FFDOid(VV0eWr, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFBDfs(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVl8kD = VVl8kD
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  allOK = FFAVQ4(self["myLabel"], self.VVl8kD)
  if allOK:
   if self.showGrnMsg:
    FFU7uG(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF23yv(self, "Cannot view picture file:\n\n%s" % self.VVl8kD)
   self.close()
class CCiWF9(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFDOid(VVi3pc, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  FFBDfs(self)
  FFOV9c(self["keyGreen"], "Save")
  self.VVeBho = []
  self.VVeBho.append(getConfigListEntry("Show in Main Menu"          , CFG.showInMainMenu   ))
  self.VVeBho.append(getConfigListEntry("Show in Extensions Menu"         , CFG.showInExtensionMenu  ))
  self.VVeBho.append(getConfigListEntry("Show in Channel List Context Menu"      , CFG.showInChannelListMenu  ))
  self.VVeBho.append(getConfigListEntry("Show in Events Info Menu"        , CFG.EventsInfoMenu   ))
  self.VVeBho.append(getConfigListEntry("Input Type"            , CFG.keyboard     ))
  self.VVeBho.append(getConfigListEntry("Signal & Player Cotroller Hotkey"      , CFG.hotkey_signal    ))
  if VVBJBx:
   self.VVeBho.append(getConfigListEntry("EPG Translation Language"       , CFG.epgLanguage    ))
  self.VVeBho.append(getConfigListEntry(VVJwpo *2             ,         ))
  self.VVeBho.append(getConfigListEntry("Default IPTV Reference Type"        , CFG.iptvAddToBouquetRefType ))
  self.VVeBho.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"  , CFG.autoResetFrozenIptvChan ))
  self.VVeBho.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"     , CFG.hideIptvServerAdultWords ))
  self.VVeBho.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"  , CFG.hideIptvServerChannPrefix ))
  self.VVeBho.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"   , CFG.iptvHostsPath    ))
  self.VVeBho.append(getConfigListEntry("Movie/Series Download Path"        , CFG.MovieDownloadPath   ))
  self.VVeBho.append(getConfigListEntry(VVJwpo *2             ,         ))
  self.VVeBho.append(getConfigListEntry("PIcons Path"            , CFG.PIconsPath    ))
  self.VVeBho.append(getConfigListEntry(VVJwpo *2             ,         ))
  self.VVeBho.append(getConfigListEntry("Backup/Restore Path"          , CFG.backupPath    ))
  self.VVeBho.append(getConfigListEntry("Created Package Files (IPK/DEB)"       , CFG.packageOutputPath   ))
  self.VVeBho.append(getConfigListEntry("Downloaded Packages (from feeds)"      , CFG.downloadedPackagesPath ))
  self.VVeBho.append(getConfigListEntry("Exported Tables"           , CFG.exportedTablesPath  ))
  self.VVeBho.append(getConfigListEntry("Exported PIcons"           , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVeBho, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVAJFV   ,
   "OK"  : self.VVAJFV   ,
   "green"  : self.VV3LHg  ,
   "menu"  : self.VVoR8E ,
   "cancel" : self.VV4Mr6
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFrRM6(self)
  FF0JHQ(self["config"])
  FFeGgr(self,  self["config"])
  FFkJyH(self)
 def VVAJFV(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVink4()
   elif item == CFG.MovieDownloadPath   : self.VVxmgI(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVHMGj(item)
   elif item == CFG.backupPath    : self.VVHMGj(item)
   elif item == CFG.packageOutputPath  : self.VVHMGj(item)
   elif item == CFG.downloadedPackagesPath : self.VVHMGj(item)
   elif item == CFG.exportedTablesPath  : self.VVHMGj(item)
   elif item == CFG.exportedPIconsPath  : self.VVHMGj(item)
 def VVxmgI(self, item, title):
  tot = CCuRcG.VVMiyH()
  if tot : FF23yv(self, "Cannot change while downloading.", title=title)
  else : self.VVHMGj(item)
 def VVink4(self):
  VVWaOb = []
  VVWaOb.append(("Auto Find" , "auto"))
  VVWaOb.append(("Custom Path" , "path"))
  FFg6MQ(self, self.VVKDqm, VVWaOb=VVWaOb, title="IPTV Hosts Files Path")
 def VVKDqm(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVWnkq)
   elif item == "path": self.VVHMGj(CFG.iptvHostsPath)
 def VVHMGj(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVWnkq:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVwmkW, configObj)
         , boundFunction(CCpqJe, mode=CCpqJe.VVYZsL, VVM0xu=sDir))
 def VVwmkW(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV4Mr6(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.autoResetFrozenIptvChan.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.MovieDownloadPath.isChanged()   or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFyVJ3(self, self.VV3LHg, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VV3LHg(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVZ19k()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVoR8E(self):
  VVWaOb = []
  VVWaOb.append(("Use Backup directory in all other paths"      , "VVrzg6"   ))
  VVWaOb.append(("Reset all to default (including File Manager bookmarks)"  , "VVbBPk"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Backup %s Settings" % PLUGIN_NAME        , "VVAcP3"  ))
  VVWaOb.append(("Restore %s Settings" % PLUGIN_NAME       , "VVdcXE"  ))
  if fileExists(VVx8df + VVCqQX):
   VVWaOb.append(VVIEqe)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVWaOb.append(('%s Checking for Update' % txt1       , txt2     ))
   VVWaOb.append(("Reinstall %s" % PLUGIN_NAME        , "VVNmv6"  ))
   VVWaOb.append(("Update %s" % PLUGIN_NAME        , "VV4enJ"   ))
  FFg6MQ(self, self.VVb1Zn, VVWaOb=VVWaOb, title="Config. Options")
 def VVb1Zn(self, item=None):
  if item:
   if   item == "VVrzg6"  : FFyVJ3(self, self.VVrzg6 , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVbBPk"  : FFyVJ3(self, self.VVbBPk, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCY16h)
   elif item == "VVAcP3" : self.VVAcP3()
   elif item == "VVdcXE" : FFJ3IJ(self, self.VVdcXE, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVJuXC(True)
   elif item == "disableChkUpdate" : self.VVJuXC(False)
   elif item == "VVNmv6" : FFJ3IJ(self, self.VVNmv6 , "Checking Server ...")
   elif item == "VV4enJ"  : FFJ3IJ(self, self.VV4enJ  , "Checking Server ...")
 def VVAcP3(self):
  path = "%sajpanel_settings_%s" % (VVx8df, FFBQPI())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFuW4T(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVdcXE(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FF8xGt("find / %s -iname '%s*' | grep %s" % (FFcd50(1), name, name))
  if lines:
   lines.sort()
   VVWaOb = []
   for line in lines:
    VVWaOb.append((line, line))
   FFg6MQ(self, boundFunction(self.VVmmkm, title), title=title, VVWaOb=VVWaOb, width=1200)
  else:
   FF23yv(self, "No settings files found !", title=title)
 def VVmmkm(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFcG5u(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVZ19k()
    FFlr2o()
   else:
    FFl2xw(SELF, path, title=title)
 def VVJuXC(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVrzg6(self):
  newPath = FFVqav(VVx8df)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVZ19k()
 @staticmethod
 def VVbTow():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVbBPk(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(False)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVWnkq)
  CFG.MovieDownloadPath.setValue(CCuRcG.VVqbxo())
  CFG.PIconsPath.setValue(VVyTQa)
  CFG.backupPath.setValue(CCiWF9.VVbTow())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.autoResetFrozenIptvChan.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.MovieDownloadPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVZ19k()
  self.close()
 def VVZ19k(self):
  configfile.save()
  global VVx8df
  VVx8df = CFG.backupPath.getValue()
  FFC7fb()
 def VV4enJ(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVZfi0(title)
  if webVer:
   FFyVJ3(self, boundFunction(FFJ3IJ, self, boundFunction(self.VVByQh, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVNmv6(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVZfi0(title, True)
  if webVer:
   FFyVJ3(self, boundFunction(FFJ3IJ, self, boundFunction(self.VVByQh, webVer, title)), "Install and Restart ?", title=title)
 def VVByQh(self, webVer, title):
  url = self.VVCPAO(self, title)
  if url:
   VVC9Ss = FF3RNN() == "dpkg"
   if VVC9Ss == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVC9Ss else "ipk")
   path, err = FFmoGG(url + fName, fName, timeout=2)
   if path:
    cmd = FFNOBr(VV89BS, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFsUMt(self, cmd)
    else:
     FF5N91(self, title=title)
   else:
    FF23yv(self, err, title=title)
 def VVZfi0(self, title, anyVer=False):
  url = self.VVCPAO(self, title)
  if not url:
   return ""
  path, err = FFmoGG(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF23yv(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFGKC4(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF23yv(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVE71u.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FF8xGt(cmd)
   if list and curVer == list[0]:
    return webVer
  FFuW4T(self, FFKY60("No update required.", VVuV1K) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVCPAO(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVx8df + VVCqQX
  if fileExists(path):
   span = iSearch(r"(http.+)", FFGKC4(path), IGNORECASE)
   if span : url = FFVqav(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF23yv(SELF, err, title)
  return url
 @staticmethod
 def VVNGK5(url):
  path, err = FFmoGG(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFGKC4(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVE71u.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FF8xGt(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCY16h(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFDOid(VVxZAL, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVP5Kc
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFBDfs(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVlDQf("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVlDQf("\c00888888", i) + sp + "GREY\n"
   txt += self.VVlDQf("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVlDQf("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVlDQf("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVlDQf("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVlDQf("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVlDQf("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVlDQf("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVlDQf("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVlDQf("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVlDQf("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVAJFV ,
   "green"   : self.VVAJFV ,
   "left"   : self.VV2JtA ,
   "right"   : self.VVuZuU ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  self.VVOu6o()
 def VVAJFV(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFyVJ3(self, self.VVO9WP, "Change to : %s" % txt, title=self.Title)
 def VVO9WP(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVP5Kc
  VVP5Kc = self.cursorPos
  self.VV7S0a()
  self.close()
 def VV2JtA(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVOu6o()
 def VVuZuU(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVOu6o()
 def VVOu6o(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVlDQf(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVo19M(color):
  if VV106B: return "\\" + color
  else    : return ""
 @staticmethod
 def VV7S0a():
  global VVcP3M, VVLLOq, VVvqWy, VVCyLg, VVzNDT, VV4S6b, VVuV1K, VV106B, COLOR_CONS_BRIGHT_YELLOW, VV4E8E, VVhHzk, VVfDjZ, VVbwNy
  VVbwNy   = CCY16h.VVlDQf("\c00FFFFFF", VVP5Kc)
  VVLLOq    = CCY16h.VVlDQf("\c00888888", VVP5Kc)
  VVcP3M  = CCY16h.VVlDQf("\c005A5A5A", VVP5Kc)
  VV4S6b    = CCY16h.VVlDQf("\c00FF0000", VVP5Kc)
  VVvqWy   = CCY16h.VVlDQf("\c00FF5000", VVP5Kc)
  VV106B   = CCY16h.VVlDQf("\c00FFFF00", VVP5Kc)
  COLOR_CONS_BRIGHT_YELLOW = CCY16h.VVlDQf("\c00FFFFAA", VVP5Kc)
  VVuV1K   = CCY16h.VVlDQf("\c0000FF00", VVP5Kc)
  VVzNDT    = CCY16h.VVlDQf("\c000066FF", VVP5Kc)
  VV4E8E    = CCY16h.VVlDQf("\c0000FFFF", VVP5Kc)
  VVhHzk  = CCY16h.VVlDQf("\c00DSFFFF", VVP5Kc)  #
  VVfDjZ   = CCY16h.VVlDQf("\c00FA55E7", VVP5Kc)
  VVCyLg    = CCY16h.VVlDQf("\c00FF8F5F", VVP5Kc)
CCY16h.VV7S0a()
class CC8jHO(Screen):
 def __init__(self, session, path, VVC9Ss):
  self.skin, self.skinParam = FFDOid(VVEG99, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVTqGl   = path
  self.VVDCX8   = ""
  self.VV4ij6   = ""
  self.VVC9Ss    = VVC9Ss
  self.VVjpOj    = ""
  self.VV9xqK  = ""
  self.VVCycD    = False
  self.VVsSPN  = False
  self.postInstAcion   = 0
  self.VVG2E3  = "enigma2-plugin-extensions"
  self.VVWiQl  = "enigma2-plugin-systemplugins"
  self.VVfZby = "enigma2"
  self.VVxuEs  = 0
  self.VVUNJJ  = 1
  self.VVnN32  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVWqRF = "DEBIAN"
  else        : self.VVWqRF = "CONTROL"
  self.controlPath = self.Path + self.VVWqRF
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVC9Ss:
   self.packageExt  = ".deb"
   self.VVTMiH  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVTMiH  = "#11001020"
  FFBDfs(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFOV9c(self["keyRed"] , "Create")
  FFOV9c(self["keyGreen"] , "Post Install")
  FFOV9c(self["keyYellow"], "Installation Path")
  FFOV9c(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVgd5l  ,
   "green"   : self.VVAB4a ,
   "yellow"  : self.VVzjEh  ,
   "blue"   : self.VVXURi  ,
   "cancel"  : self.VVTlfv
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  FFkJyH(self)
  if self.VVTMiH:
   FFIRRt(self["myBody"], self.VVTMiH)
   FFIRRt(self["myLabel"], self.VVTMiH)
  self.VV27rZ(True)
  self.VVki2m(True)
 def VVki2m(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV2Hol()
  if isFirstTime:
   if   package.startswith(self.VVG2E3) : self.VVTqGl = VVy60U + self.VVjpOj + "/"
   elif package.startswith(self.VVWiQl) : self.VVTqGl = VVsxXY + self.VVjpOj + "/"
   else            : self.VVTqGl = self.Path
  if self.VVCycD : myColor = VVCyLg
  else    : myColor = VVbwNy
  txt  = ""
  txt += "Source Path\t: %s\n" % FFKY60(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFKY60(self.VVTqGl, VV106B)
  if self.VV4ij6 : txt += "Package File\t: %s\n" % FFKY60(self.VV4ij6, VVLLOq)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFKY60("Check Control File fields : %s" % errTxt, VVvqWy)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFKY60("Restart GUI", VVCyLg)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFKY60("Reboot Device", VVCyLg)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFKY60("Post Install", VVuV1K), act)
  if not errTxt and VVvqWy in controlInfo:
   txt += "Warning\t: %s\n" % FFKY60("Errors in control file may affect the result package.", VVvqWy)
  txt += "\nControl File\t: %s\n" % FFKY60(self.controlFile, VVLLOq)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVAB4a(self):
  VVWaOb = []
  VVWaOb.append(("No Action"    , "noAction"  ))
  VVWaOb.append(("Restart GUI"    , "VVQ59H"  ))
  VVWaOb.append(("Reboot Device"   , "rebootDev"  ))
  FFg6MQ(self, self.VVIk4a, title="Package Installation Option (after completing installation)", VVWaOb=VVWaOb)
 def VVIk4a(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVQ59H"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV27rZ(False)
   self.VVki2m()
 def VVzjEh(self):
  rootPath = FFKY60("/%s/" % self.VVjpOj, VVcP3M)
  VVWaOb = []
  VVWaOb.append(("Current Path"        , "toCurrent"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Extension Path"       , "toExtensions" ))
  VVWaOb.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVWaOb.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFg6MQ(self, self.VVjoIy, title="Installation Path", VVWaOb=VVWaOb)
 def VVjoIy(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVSMNG(FF86q9(self.Path, True))
   elif item == "toExtensions"  : self.VVSMNG(VVy60U)
   elif item == "toSystemPlugins" : self.VVSMNG(VVsxXY)
   elif item == "toRootPath"  : self.VVSMNG("/")
   elif item == "toRoot"   : self.VVSMNG("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVLHH3, boundFunction(CCpqJe, mode=CCpqJe.VVYZsL, VVM0xu=VVx8df))
 def VVLHH3(self, path):
  if len(path) > 0:
   self.VVSMNG(path)
 def VVSMNG(self, parent, withPackageName=True):
  if withPackageName : self.VVTqGl = parent + self.VVjpOj + "/"
  else    : self.VVTqGl = "/"
  mode = self.VV1Oke()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVylw2(mode), self.controlFile))
  self.VVki2m()
 def VVXURi(self):
  if fileExists(self.controlFile):
   lines = FFcG5u(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF3PZZ(self, self.VVVrVY, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF23yv(self, "Version not found or incorrectly set !")
  else:
   FFl2xw(self, self.controlFile)
 def VVVrVY(self, VVfP6g):
  if VVfP6g:
   version, color = self.VVnAZm(VVfP6g, False)
   if color == VV4E8E:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVfP6g, self.controlFile))
    self.VVki2m()
   else:
    FF23yv(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVTlfv(self):
  if self.newControlPath:
   if self.VVCycD:
    self.VVHIIs()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFKY60(self.newControlPath, VVLLOq)
    txt += FFKY60("Do you want to keep these files ?", VV106B)
    FFyVJ3(self, self.close, txt, callBack_No=self.VVHIIs, title="Create Package", VV29o7=True)
  else:
   self.close()
 def VVHIIs(self):
  os.system(FFFaNy("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVylw2(self, mode):
  if   mode == self.VVUNJJ : prefix = self.VVG2E3
  elif mode == self.VVnN32 : prefix = self.VVWiQl
  else        : prefix = self.VVfZby
  return prefix + "-" + self.VV9xqK
 def VV1Oke(self):
  if   self.VVTqGl.startswith(VVy60U) : return self.VVUNJJ
  elif self.VVTqGl.startswith(VVsxXY) : return self.VVnN32
  else            : return self.VVxuEs
 def VV27rZ(self, isFirstTime):
  self.VVjpOj   = os.path.basename(os.path.normpath(self.Path))
  self.VVjpOj   = "_".join(self.VVjpOj.split())
  self.VV9xqK = self.VVjpOj.lower()
  self.VVCycD = self.VV9xqK == VVd5St.lower()
  if self.VVCycD and self.VV9xqK.endswith("ajpan"):
   self.VV9xqK += "el"
  if self.VVCycD : self.VVDCX8 = VVx8df
  else    : self.VVDCX8 = CFG.packageOutputPath.getValue()
  self.VVDCX8 = FFVqav(self.VVDCX8)
  if not pathExists(self.controlPath):
   os.system(FFFaNy("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVCycD : t = PLUGIN_NAME
  else    : t = self.VVjpOj
  self.VVzMrn(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVYZN0.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVCycD : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVzMrn(self.postrmFile, txt)
  if self.VVCycD:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVE71u)
   self.VVzMrn(self.preinstFile, txt)
  else:
   self.VVzMrn(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVjpOj)
  mode = self.VV1Oke()
  if isFirstTime and not mode == self.VVxuEs:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVJwpo
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVzMrn(self.postinstFile, txt, VV30Nw=True)
  os.system(FFFaNy("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVCycD : version, descripton, maintainer = VVE71u , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVjpOj , self.VVjpOj
   txt = ""
   txt += "Package: %s\n"  % self.VVylw2(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVzMrn(self, path, lines, VV30Nw=False):
  if not fileExists(path) or VV30Nw:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV2Hol(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFcG5u(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFKY60(line, VVvqWy)
     elif not line.startswith(" ")    : line = FFKY60(line, VVvqWy)
     else          : line = FFKY60(line, VV4E8E)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV4E8E
   else   : color = VVvqWy
   descr = FFKY60(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVvqWy
     elif line.startswith((" ", "\t")) : color = VVvqWy
     elif line.startswith("#")   : color = VVLLOq
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVnAZm(val, True)
      elif key == "Version"  : version, color = self.VVnAZm(val, False)
      elif key == "Maintainer" : maint  , color = val, VV4E8E
      elif key == "Architecture" : arch  , color = val, VV4E8E
      else:
       color = VV4E8E
      if not key == "OE" and not key.istitle():
       color = VVvqWy
     else:
      color = VVCyLg
     txt += FFKY60(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV4ij6 = self.VVDCX8 + packageName
   self.VVsSPN = True
   errTxt = ""
  else:
   self.VV4ij6  = ""
   self.VVsSPN = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVnAZm(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV4E8E
  else          : return val, VVvqWy
 def VVgd5l(self):
  if not self.VVsSPN:
   FF23yv(self, "Please fix Control File errors first.")
   return
  if self.VVC9Ss: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF86q9(self.VVTqGl, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVjpOj
  symlinkTo  = FFMS0I(self.Path)
  dataDir   = self.VVTqGl.rstrip("/")
  removePorjDir = FFFaNy("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFFaNy("rm -f '%s'" % self.VV4ij6) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFS5rX()
  if self.VVC9Ss:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFBYZw("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVCycD:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVTqGl == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVWqRF)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV4ij6, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV4ij6
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV4ij6, FF8tq9(result  , VVuV1K))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVTqGl, FF8tq9(instPath, VV4E8E))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF8tq9(failed, VVvqWy))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFsUMt(self, cmd)
class CCpqJe(Screen):
 VVWj8g   = 0
 VVYZsL  = 1
 VV3TzZ = 20
 VVRNBC  = None
 def __init__(self, session, VVM0xu="/", mode=VVWj8g, VVd6jy="Select", VVZWCz=30, gotoMovie=False):
  self.skin, self.skinParam = FFDOid(VVxulX, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFBDfs(self)
  FFOV9c(self["keyRed"] , "Exit")
  FFOV9c(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVd6jy = VVd6jy
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCpqJe.VVRNBC = self
  if   self.gotoMovie        : VVgEtT, self.VVM0xu = True , CCpqJe.VVd6oA(self)[1] or "/"
  elif self.mode == self.VVWj8g  : VVgEtT, self.VVM0xu = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVYZsL : VVgEtT, self.VVM0xu = False, VVM0xu
  else           : VVgEtT, self.VVM0xu = True , VVM0xu
  self.VVM0xu = FFVqav(self.VVM0xu)
  self["myMenu"] = CCLB1K(  directory   = "/"
         , VVgEtT   = VVgEtT
         , VVsJNa = True
         , VVg2p6   = self.skinParam["width"]
         , VVZWCz   = self.skinParam["bodyFontSize"]
         , VVEvPQ  = self.skinParam["bodyLineH"]
         , VVFYF5  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVAJFV      ,
   "red"    : self.VVxmmO     ,
   "green"    : self.VVRn7o    ,
   "yellow"   : self.VVP8UK   ,
   "blue"    : self.VVeQu4   ,
   "menu"    : self.VV8170    ,
   "info"    : self.VVLs6Q    ,
   "cancel"   : self.VVsAL8     ,
   "pageUp"   : self.VVsAL8     ,
   "chanUp"   : self.VVsAL8
  }, -1)
  FFiDNM(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVtGp3)
 def onExit(self):
  CCpqJe.VVRNBC = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVtGp3)
  FFrRM6(self)
  FF0JHQ(self["myMenu"], bg="#06003333")
  FFkJyH(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVYZsL:
   FFOV9c(self["keyGreen"], self.VVd6jy)
   color = "#22000022"
   FFIRRt(self["myBody"], color)
   FFIRRt(self["myMenu"], color)
   color = "#22220000"
   FFIRRt(self["myTitle"], color)
   FFIRRt(self["myBar"], color)
  self.VVtGp3()
  if self.VVriSE(self.VVM0xu) > self.bigDirSize:
   FFU7uG(self, "Changing directory...")
   FFewwi(self.VVJXhE)
  else:
   self.VVJXhE()
 def VVJXhE(self):
  self["myMenu"].VVJr0e(self.VVM0xu)
  if self.gotoMovie:
   self.VVti7k(chDir=False)
 def VVuEmH(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVXnxq(self):
  self["myMenu"].refresh()
  FFMA4x()
 def VVriSE(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVAJFV(self):
  if self["myMenu"].VViAXS():
   path = self.VV8ev2(self.VVsszy())
   if self.VVriSE(path) > self.bigDirSize:
    FFU7uG(self, "Changing directory...")
    FFewwi(self.VV7Uqm)
   else:
    self.VV7Uqm()
  else:
   self.VVT8mr()
 def VV7Uqm(self):
  self["myMenu"].descent()
  self.VVtGp3()
 def VVsAL8(self):
  if self["myMenu"].VVSnHp():
   self["myMenu"].moveToIndex(0)
   self.VV7Uqm()
 def VVxmmO(self):
  if not FFJrZA(self):
   self.close("")
 def VVRn7o(self):
  if self.mode == self.VVYZsL:
   path = self.VV8ev2(self.VVsszy())
   self.close(path)
 def VVLs6Q(self):
  FFJ3IJ(self, self.VV6Nhf, title="Calculating size ...")
 def VV6Nhf(self):
  path = self.VV8ev2(self.VVsszy())
  param = self.VVVbPb(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFKH1d("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCpqJe.VVuG4J(path)
     freeSize = CCpqJe.VVx4F9(path)
     size = totSize - freeSize
     totSize  = CCpqJe.VVhdHk(totSize)
     freeSize = CCpqJe.VVhdHk(freeSize)
    else:
     size = FFKH1d("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCpqJe.VVhdHk(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFKY60(pathTxt, VVCyLg) + "\n"
   if slBroken : fileTime = self.VVSgoP(path)
   else  : fileTime = self.VVfElW(path)
   def VVCkU8(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVCkU8("Path"    , pathTxt)
   txt += VVCkU8("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVCkU8("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVCkU8("Total Size"   , "%s" % totSize)
    txt += VVCkU8("Used Size"   , "%s" % usedSize)
    txt += VVCkU8("Free Size"   , "%s" % freeSize)
   else:
    txt += VVCkU8("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVCkU8("Owner"    , owner)
   txt += VVCkU8("Group"    , group)
   txt += VVCkU8("Perm. (User)"  , permUser)
   txt += VVCkU8("Perm. (Group)"  , permGroup)
   txt += VVCkU8("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVCkU8("Perm. (Ext.)" , permExtra)
   txt += VVCkU8("iNode"    , iNode)
   txt += VVCkU8("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVJwpo, VVJwpo)
    txt += hLinkedFiles
   txt += self.VVqgP8(path)
  else:
   FF23yv(self, "Cannot access information !")
  if len(txt) > 0:
   FFx6I1(self, txt)
 def VVVbPb(self, path):
  path = path.strip()
  path = FFMS0I(path)
  result = FFKH1d("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV7l1v(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV7l1v(perm, 1, 4)
   permGroup = VV7l1v(perm, 4, 7)
   permOther = VV7l1v(perm, 7, 10)
   permExtra = VV7l1v(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFNh54("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVqgP8(self, path):
  txt  = ""
  res  = FFKH1d("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFKY60("File Attributes:", VVfDjZ), txt)
  return txt
 def VVfElW(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFv8BC(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFv8BC(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFv8BC(os.path.getctime(path))
  return txt
 def VVSgoP(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFKH1d("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFKH1d("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFKH1d("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV8ev2(self, currentSel):
  currentDir  = self["myMenu"].VVSnHp()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VViAXS():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVsszy(self):
  return self["myMenu"].getSelection()[0]
 def VVtGp3(self):
  FFU7uG(self)
  path = self.VV8ev2(self.VVsszy())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVeBho = self.VVRMpI()
  if VVeBho and len(VVeBho) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV1Ypw(path)
  if self.mode == self.VVWj8g and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VV1Ypw(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVdNLQ(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VV8170(self):
  if self.mode == self.VVWj8g:
   path  = self.VV8ev2(self.VVsszy())
   isDir  = os.path.isdir(path)
   VVWaOb = []
   VVWaOb.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVZS6P(path):
     sepShown = True
     VVWaOb.append(VVIEqe)
     VVWaOb.append( (VVCyLg + "Archiving / Packaging"      , "VVk6RD"  ))
    if self.VV7Dng(path):
     if not sepShown:
      VVWaOb.append(VVIEqe)
     VVWaOb.append( (VVCyLg + "Read Backup information"     , "VVWnh4"  ))
     VVWaOb.append( (VVCyLg + "Compress Octagon Image (to zip File)"  , "VVNExJ" ))
   elif os.path.isfile(path):
    selFile = self.VVsszy()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVWaOb.extend(self.VVCDHi(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVWaOb.extend(self.VVUd41(True))
    elif selFile.endswith(".m3u")              : VVWaOb.extend(self.VV3VZB(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFfihj(path):
     VVWaOb.append(VVIEqe)
     VVWaOb.append((VVCyLg + "View" , "text_View" ))
     VVWaOb.append((VVCyLg + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVWaOb.append(VVIEqe)
     VVWaOb.append(   (VVCyLg + txt      , "VVT8mr"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(     ("Create SymLink"       , "VVh6lC" ))
   if not self.VVZS6P(path):
    VVWaOb.append(   ("Rename"          , "VVUioR" ))
    VVWaOb.append(   ("Copy"           , "copyFileOrDir" ))
    VVWaOb.append(   ("Move"           , "moveFileOrDir" ))
    VVWaOb.append(   ("DELETE"          , "VVrDjZ" ))
    if fileExists(path):
     VVWaOb.append(VVIEqe)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVWaOb.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVWaOb.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVWaOb.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVWaOb.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCpqJe.VVd6oA(self)
   if fPath:
    VVWaOb.append(VVIEqe)
    VVWaOb.append(   (VV106B + "Go to current movie"  , "VVti7k"))
   VVWaOb.append(VVIEqe)
   VVWaOb.append(    ("Set current directory as \"Startup Path\"" , "VVktlk" ))
   FFg6MQ(self, self.VVtBtI, title="Options", VVWaOb=VVWaOb)
 def VVtBtI(self, item=None):
  if self.mode == self.VVWj8g:
   if item is not None:
    path = self.VV8ev2(self.VVsszy())
    selFile = self.VVsszy()
    if   item == "properties"    : self.VVLs6Q()
    elif item == "VVk6RD"  : self.VVk6RD(path)
    elif item == "VVWnh4"  : self.VVWnh4(path)
    elif item == "VVNExJ" : self.VVNExJ(path)
    elif item.startswith("extract_")  : self.VVHmRG(path, selFile, item)
    elif item.startswith("script_")   : self.VVnCZf(path, selFile, item)
    elif item.startswith("m3u_")   : self.VV31gbItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFpIfw(self, path)
    elif item.startswith("text_Edit")  : CCpY82(self, path)
    elif item == "chmod644"     : self.VVpuVa(path, selFile, "644")
    elif item == "chmod755"     : self.VVpuVa(path, selFile, "755")
    elif item == "chmod777"     : self.VVpuVa(path, selFile, "777")
    elif item == "VVh6lC"   : self.VVh6lC(path, selFile)
    elif item == "VVUioR"   : self.VVUioR(path, selFile)
    elif item == "copyFileOrDir"   : self.VVOIDm(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVOIDm(path, selFile, True)
    elif item == "VVrDjZ"   : self.VVrDjZ(path, selFile)
    elif item == "createNewFile"   : self.VV5smo(path, True)
    elif item == "createNewDir"    : self.VV5smo(path, False)
    elif item == "VVti7k"   : self.VVti7k()
    elif item == "VVktlk"   : self.VVktlk(path)
    elif item == "VVT8mr"    : self.VVT8mr()
    else         : self.close()
 def VVT8mr(self):
  selFile = self.VVsszy()
  path  = self.VV8ev2(selFile)
  if os.path.isfile(path):
   VVuqfs = []
   category = self["myMenu"].VVxEvH(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVcfKF(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFJYru(self, selFile, path)
   elif category == "txt"         : FFpIfw(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVhb43(path, selFile)
   elif category == "scr"         : self.VV5Jx5(path, selFile)
   elif category == "m3u"         : self.VV8eIS(path, selFile)
   elif category in ("ipk", "deb")       : self.VV0LYk(path, selFile)
   elif category == "mus"         : self.VVJMzy(self, path)
   elif category == "mov"         : self.VVJMzy(self, path)
   elif not FFfihj(path)        : FFpIfw(self, path)
 def VVP8UK(self):
  path = self.VV8ev2(self.VVsszy())
  action = self.VV1Ypw(path)
  if action == 1:
   self.VV4nbJ(path)
   FFU7uG(self, "Added", 500)
  elif action == -1:
   self.VVJI5x(path)
   FFU7uG(self, "Removed", 500)
  self.VV1Ypw(path)
 def VV4nbJ(self, path):
  VVeBho = self.VVRMpI()
  if not VVeBho:
   VVeBho = []
  if len(VVeBho) >= self.VV3TzZ:
   FF23yv(SELF, "Max bookmarks reached (max=%d)." % self.VV3TzZ)
  elif not path in VVeBho:
   VVeBho = [path] + VVeBho
   self.VVCl3a(VVeBho)
 def VVeQu4(self):
  VVeBho = self.VVRMpI()
  if VVeBho:
   newList = []
   for line in VVeBho:
    newList.append((line, line))
   VVinCp  = ("Delete"  , self.VVvagx )
   VVIAKx = ("Move Up"   , self.VV3AuP )
   VVFoGM  = ("Move Down" , self.VVsyLS )
   self.bookmarkMenu = FFg6MQ(self, self.VVlNO4, title="Bookmarks", VVWaOb=newList, VVinCp=VVinCp, VVIAKx=VVIAKx, VVFoGM=VVFoGM)
 def VVvagx(self, VVsszyObj, path):
  if self.bookmarkMenu:
   VVeBho = self.VVJI5x(path)
   self.bookmarkMenu.VVHYqW(VVeBho)
 def VV3AuP(self, VVsszyObj, path):
  if self.bookmarkMenu:
   VVeBho = self.bookmarkMenu.VVSJx2(True)
   if VVeBho:
    self.VVCl3a(VVeBho)
 def VVsyLS(self, VVsszyObj, path):
  if self.bookmarkMenu:
   VVeBho = self.bookmarkMenu.VVSJx2(False)
   if VVeBho:
    self.VVCl3a(VVeBho)
 def VVlNO4(self, folder=None):
  if folder:
   folder = FFVqav(folder)
   self["myMenu"].VVJr0e(folder)
   self["myMenu"].moveToIndex(0)
  self.VVtGp3()
 def VVRMpI(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVdNLQ(self, path):
  VVeBho = self.VVRMpI()
  if VVeBho and path in VVeBho:
   return True
  else:
   return False
 def VVi1Qa(self):
  if VVRMpI():
   return True
  else:
   return False
 def VVCl3a(self, VVeBho):
  line = ",".join(VVeBho)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVJI5x(self, path):
  VVeBho = self.VVRMpI()
  if VVeBho:
   while path in VVeBho:
    VVeBho.remove(path)
   self.VVCl3a(VVeBho)
   return VVeBho
 def VVti7k(self, chDir=True):
  fPath, fDir, fName = CCpqJe.VVd6oA(self)
  if fPath:
   if chDir:
    self["myMenu"].VVJr0e(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFU7uG(self, "Not found", 1000)
 def VVktlk(self, path):
  if not os.path.isdir(path):
   path = FF86q9(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVcfKF(self, selFile, VVB4L8, command):
  FFyVJ3(self, boundFunction(FFsUMt, self, command, VVsNdD=self.VVXnxq), "%s\n\n%s" % (VVB4L8, selFile))
 def VVCDHi(self, path, calledFromMenu):
  destPath = self.VVm73c(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVWaOb = []
  if calledFromMenu:
   VVWaOb.append(VVIEqe)
   color = VVCyLg
  else:
   color = ""
  VVWaOb.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVWaOb.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVWaOb.append((color + "Extract Here"            , "extract_here"  ))
  if VVt4jw and path.endswith(".tar.gz"):
   VVWaOb.append(VVIEqe)
   VVWaOb.append((color + 'Convert to ".ipk" Package' , "VV1Rte"  ))
   VVWaOb.append((color + 'Convert to ".deb" Package' , "VVL0db"  ))
  return VVWaOb
 def VVhb43(self, path, selFile):
  FFg6MQ(self, boundFunction(self.VVHmRG, path, selFile), title="Compressed File Options", VVWaOb=self.VVCDHi(path, False))
 def VVHmRG(self, path, selFile, item=None):
  if item is not None:
   parent  = FF86q9(path, False)
   destPath = self.VVm73c(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVJwpo
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFBYZw("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFBYZw("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVJwpo, VVJwpo)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFOKKC(self, cmd)
   elif path.endswith(".zip"):
    self.VVR7Wy(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV1PJf(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFFaNy("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVcfKF(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVcfKF(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FF86q9(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVcfKF(selFile, "Extract Here ?"      , cmd)
   elif item == "VV1Rte" : self.VV1Rte(path)
   elif item == "VVL0db" : self.VVL0db(path)
 def VVm73c(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVR7Wy(self, item, path, parent, destPath, VVB4L8):
  FFyVJ3(self, boundFunction(self.VVGti5, item, path, parent, destPath), VVB4L8)
 def VVGti5(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVJwpo
  cmd  = FFBYZw("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF8tq9(destPath, VVuV1K))
  cmd +=   sep
  cmd += "fi;"
  FFvO2C(self, cmd, VVsNdD=self.VVXnxq)
 def VV1PJf(self, item, path, parent, destPath, VVB4L8):
  FFyVJ3(self, boundFunction(self.VV8huy, item, path, parent, destPath), VVB4L8)
 def VV8huy(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFVqav(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVJwpo
  cmd  = FFBYZw("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF8tq9(destPath, VVuV1K))
  cmd +=   sep
  cmd += "fi;"
  FFvO2C(self, cmd, VVsNdD=self.VVXnxq)
 def VVUd41(self, addSep=False):
  VVWaOb = []
  if addSep:
   VVWaOb.append(VVIEqe)
  VVWaOb.append((VVCyLg + "View Script File"  , "script_View"  ))
  VVWaOb.append((VVCyLg + "Execute Script File" , "script_Execute" ))
  VVWaOb.append((VVCyLg + "Edit"     , "script_Edit" ))
  return VVWaOb
 def VV5Jx5(self, path, selFile):
  FFg6MQ(self, boundFunction(self.VVnCZf, path, selFile), title="Script File Options", VVWaOb=self.VVUd41())
 def VVnCZf(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFpIfw(self, path)
   elif item == "script_Execute" : self.VVcfKF(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCpY82(self, path)
 def VV3VZB(self, addSep=False):
  VVWaOb = []
  if addSep:
   VVWaOb.append(VVIEqe)
  VVWaOb.append((VVCyLg + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVWaOb.append((VVCyLg + "Edit"      , "m3u_Edit" ))
  VVWaOb.append((VVCyLg + "View"      , "m3u_View" ))
  return VVWaOb
 def VV8eIS(self, path, selFile):
  FFg6MQ(self, boundFunction(self.VV31gbItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVWaOb=self.VV3VZB())
 def VV31gbItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFJ3IJ(self, boundFunction(self.session.open, CCy3Ly, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCpY82(self, path)
   elif item == "m3u_View"  : FFpIfw(self, path)
 def VVpuVa(self, path, selFile, newChmod):
  FFyVJ3(self, boundFunction(self.VV9Agh, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV9Agh(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV2IM6)
  result = FFKH1d(cmd)
  if result == "Successful" : FFuW4T(self, result)
  else      : FF23yv(self, result)
 def VVh6lC(self, path, selFile):
  parent = FF86q9(path, False)
  self.session.openWithCallback(self.VVEUlC, boundFunction(CCpqJe, mode=CCpqJe.VVYZsL, VVM0xu=parent, VVd6jy="Create Symlink here"))
 def VVEUlC(self, newPath):
  if len(newPath) > 0:
   target = self.VV8ev2(self.VVsszy())
   target = FFMS0I(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFVqav(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF23yv(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFyVJ3(self, boundFunction(self.VVscRo, target, link), "Create Soft Link ?\n\n%s" % txt, VV29o7=True)
 def VVscRo(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV2IM6)
  result = FFKH1d(cmd)
  if result == "Successful" : FFuW4T(self, result)
  else      : FF23yv(self, result)
 def VVUioR(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FF3PZZ(self, boundFunction(self.VV5QMe, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV5QMe(self, path, selFile, VVfP6g):
  if VVfP6g:
   parent = FF86q9(path, True)
   if os.path.isdir(path):
    path = FFMS0I(path)
   newName = parent + VVfP6g
   cmd = "mv '%s' '%s' %s" % (path, newName, VV2IM6)
   if VVfP6g:
    if selFile != VVfP6g:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFyVJ3(self, boundFunction(self.VVtszR, cmd), message, title="Rename file?")
    else:
     FF23yv(self, "Cannot use same name!", title="Rename")
 def VVtszR(self, cmd):
  result = FFKH1d(cmd)
  if "Fail" in result:
   FF23yv(self, result)
  self.VVXnxq()
 def VVOIDm(self, path, selFile, isMove):
  if isMove : VVd6jy = "Move to here"
  else  : VVd6jy = "Copy to here"
  parent = FF86q9(path, False)
  self.session.openWithCallback(boundFunction(self.VVjbzF, isMove, path, selFile)
         , boundFunction(CCpqJe, mode=CCpqJe.VVYZsL, VVM0xu=parent, VVd6jy=VVd6jy))
 def VVjbzF(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFMS0I(path)
   newPath = FFVqav(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFyVJ3(self, boundFunction(FFfB0P, self, cmd, VVsNdD=self.VVXnxq), txt, VV29o7=True)
   else:
    FF23yv(self, "Cannot %s to same directory !" % action.lower())
 def VVrDjZ(self, path, fileName):
  path = FFMS0I(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFyVJ3(self, boundFunction(self.VVxvK3, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVxvK3(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVXnxq()
 def VVZS6P(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVkBs8 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV5smo(self, path, isFile):
  dirName = FFVqav(os.path.dirname(path))
  if isFile : objName, VVfP6g = "File"  , self.edited_newFile
  else  : objName, VVfP6g = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF3PZZ(self, boundFunction(self.VVPRbx, dirName, isFile, title), title=title, defaultText=VVfP6g, message="Enter %s Name:" % objName)
 def VVPRbx(self, dirName, isFile, title, VVfP6g):
  if VVfP6g:
   if isFile : self.edited_newFile = VVfP6g
   else  : self.edited_newDir  = VVfP6g
   path = dirName + VVfP6g
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV2IM6)
    else  : cmd = "mkdir '%s' %s" % (path, VV2IM6)
    result = FFKH1d(cmd)
    if "Fail" in result:
     FF23yv(self, result)
    self.VVXnxq()
   else:
    FF23yv(self, "Name already exists !\n\n%s" % path, title)
 def VV0LYk(self, path, selFile):
  VVWaOb = []
  VVWaOb.append(("List Package Files"          , "VVal27"     ))
  VVWaOb.append(("Package Information"          , "VVws4f"     ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Install Package"           , "VVHjEw_CheckVersion" ))
  VVWaOb.append(("Install Package (force reinstall)"      , "VVHjEw_ForceReinstall" ))
  VVWaOb.append(("Install Package (force overwrite)"      , "VVHjEw_ForceOverwrite" ))
  VVWaOb.append(("Install Package (force downgrade)"      , "VVHjEw_ForceDowngrade" ))
  VVWaOb.append(("Install Package (ignore failed dependencies)"    , "VVHjEw_IgnoreDepends" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Remove Related Package"         , "VVKmpL_ExistingPackage" ))
  VVWaOb.append(("Remove Related Package (force remove)"     , "VVKmpL_ForceRemove"  ))
  VVWaOb.append(("Remove Related Package (ignore failed dependencies)"  , "VVKmpL_IgnoreDepends" ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("Extract Files"           , "VVTUmY"     ))
  VVWaOb.append(("Unbuild Package"           , "VVjEoQ"     ))
  FFg6MQ(self, boundFunction(self.VVzLST, path, selFile), VVWaOb=VVWaOb)
 def VVzLST(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVal27"      : self.VVal27(path, selFile)
   elif item == "VVws4f"      : self.VVws4f(path)
   elif item == "VVHjEw_CheckVersion"  : self.VVHjEw(path, selFile, VVlyKc     )
   elif item == "VVHjEw_ForceReinstall" : self.VVHjEw(path, selFile, VV89BS )
   elif item == "VVHjEw_ForceOverwrite" : self.VVHjEw(path, selFile, VVs9RN )
   elif item == "VVHjEw_ForceDowngrade" : self.VVHjEw(path, selFile, VVq23Q )
   elif item == "VVHjEw_IgnoreDepends" : self.VVHjEw(path, selFile, VVqPlm )
   elif item == "VVKmpL_ExistingPackage" : self.VVKmpL(path, selFile, VVKAAT     )
   elif item == "VVKmpL_ForceRemove"  : self.VVKmpL(path, selFile, VVjkH2  )
   elif item == "VVKmpL_IgnoreDepends"  : self.VVKmpL(path, selFile, VVnwKT )
   elif item == "VVTUmY"     : self.VVTUmY(path, selFile)
   elif item == "VVjEoQ"     : self.VVjEoQ(path, selFile)
   else           : self.close()
 def VVal27(self, path, selFile):
  if FFLz4T("ar") : cmd = "allOK='1';"
  else    : cmd  = FFS5rX()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVJwpo, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVJwpo, VVJwpo)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFDb10(self, cmd, VVsNdD=self.VVXnxq)
 def VVTUmY(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FF86q9(path, True) + selFile[:-4]
  cmd  =  FFS5rX()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFFaNy("mkdir '%s'" % dest) + ";"
  cmd +=    FFFaNy("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF8tq9(dest, VVuV1K))
  cmd += "fi;"
  FFsUMt(self, cmd, VVsNdD=self.VVXnxq)
 def VVjEoQ(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVNE0V = os.path.splitext(path)[0]
  else        : VVNE0V = path + "_"
  if path.endswith(".deb")   : VVWqRF = "DEBIAN"
  else        : VVWqRF = "CONTROL"
  cmd  = FFS5rX()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVNE0V, FF35kh())
  cmd += "  mkdir '%s';"    % VVNE0V
  cmd += "  CONTPATH='%s/%s';"  % (VVNE0V, VVWqRF)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVNE0V
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVNE0V, VVNE0V)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVNE0V
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVNE0V, VVNE0V)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVNE0V
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVNE0V
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVNE0V, FF8tq9(VVNE0V, VVuV1K))
  cmd += "fi;"
  FFsUMt(self, cmd, VVsNdD=self.VVXnxq)
 def VVws4f(self, path):
  listCmd  = FFkwB2(VVoeQ8, "")
  infoCmd  = FFNOBr(VVKo8d , "")
  filesCmd = FFNOBr(VVB5Tr, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFaVi1(VV106B)
   notInst = "Package not installed."
   cmd  = FFaT5W("File Info", VV106B)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFaT5W("System Info", VV106B)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF8tq9(notInst, VVCyLg))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFaT5W("Related Files", VV106B)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFOKKC(self, cmd)
  else:
   FF5N91(self)
 def VVHjEw(self, path, selFile, cmdOpt):
  cmd = FFNOBr(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFyVJ3(self, boundFunction(FFsUMt, self, cmd, VVsNdD=FFMA4x), "Install Package ?\n\n%s" % selFile)
  else:
   FF5N91(self)
 def VVKmpL(self, path, selFile, cmdOpt):
  listCmd  = FFkwB2(VVoeQ8, "")
  infoCmd  = FFNOBr(VVKo8d, "")
  instRemCmd = FFNOBr(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF8tq9(errTxt, VVCyLg))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF8tq9(cannotTxt, VVCyLg))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF8tq9(tryTxt, VVCyLg))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFyVJ3(self, boundFunction(FFsUMt, self, cmd, VVsNdD=FFMA4x), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF5N91(self)
 def VVR44E(self, path):
  hostName = FFKH1d("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV7Dng(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVR44E(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVk6RD(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVWaOb = []
  VVWaOb.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVWaOb.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVWaOb.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVWaOb.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVWaOb.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVWaOb.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVWaOb.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVWaOb.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVWaOb.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVWaOb.append(VVIEqe)
  VVWaOb.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVWaOb.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFg6MQ(self, boundFunction(self.VVt8jp, path), VVWaOb=VVWaOb)
 def VVt8jp(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVzhET(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVzhET(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVzhET(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVzhET(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVzhET(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVzhET(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVzhET(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVzhET(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVzhET(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVzhET(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVgfaS(path, False)
   elif item == "convertDirToDeb"   : self.VVgfaS(path, True)
   else         : self.close()
 def VVgfaS(self, path, VVC9Ss):
  self.session.openWithCallback(self.VVXnxq, boundFunction(CC8jHO, path=path, VVC9Ss=VVC9Ss))
 def VVzhET(self, path, fileExt, preserveDirStruct):
  parent  = FF86q9(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFBYZw("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFBYZw("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFBYZw("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVJwpo
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFFaNy("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF8tq9(resultFile, VVuV1K))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF8tq9(failed, VVvqWy))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFDb10(self, cmd, VVsNdD=self.VVXnxq)
 def VVWnh4(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFpIfw(self, versionFile)
 def VVNExJ(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVR44E(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF23yv(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFcG5u(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FF86q9(path, False)
  VVNE0V = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF8tq9(errCmd, VVvqWy))
  installCmd = FFNOBr(VVlyKc , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVNE0V, VVNE0V)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVNE0V
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVNE0V
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVNE0V, VVNE0V)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFsUMt(self, cmd, VVsNdD=self.VVXnxq)
 def VV1Rte(self, path):
  FF23yv(self, "Under Construction.")
 def VVL0db(self, path):
  FF23yv(self, "Under Construction.")
 @staticmethod
 def VVJMzy(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCjjWk, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVd6oA(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFVqav(fDir), fName
  return "", "", ""
 @staticmethod
 def VVuG4J(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVx4F9(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVhdHk(size, mode=0):
  txt = CCpqJe.VVOSTe(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVOSTe(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCLB1K(MenuList):
 def __init__(self, VVsJNa=False, directory="/", VVkCAR=True, VVgEtT=True, VVxHmV=True, VVJNOj=None, VVgQx3=False, VVi7Ku=False, VVB4mW=False, isTop=False, VVOXkM=None, VVg2p6=1000, VVZWCz=30, VVEvPQ=30, VVFYF5="#00000000"):
  MenuList.__init__(self, list, VVsJNa, eListboxPythonMultiContent)
  self.VVkCAR  = VVkCAR
  self.VVgEtT    = VVgEtT
  self.VVxHmV  = VVxHmV
  self.VVJNOj  = VVJNOj
  self.VVgQx3   = VVgQx3
  self.VVi7Ku   = VVi7Ku or []
  self.VVB4mW   = VVB4mW or []
  self.isTop     = isTop
  self.additional_extensions = VVOXkM
  self.VVg2p6    = VVg2p6
  self.VVZWCz    = VVZWCz
  self.VVEvPQ    = VVEvPQ
  self.pngBGColor    = FFJrVj(VVFYF5)
  self.EXTENSIONS    = self.VVfxgL()
  self.VVmOHg   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVEixg, self.VVZWCz))
  self.l.setItemHeight(self.VVEvPQ)
  self.png_mem   = self.VViZlV("mem")
  self.png_usb   = self.VViZlV("usb")
  self.png_fil   = self.VViZlV("fil")
  self.png_dir   = self.VViZlV("dir")
  self.png_dirup   = self.VViZlV("dirup")
  self.png_srv   = self.VViZlV("srv")
  self.png_slwfil   = self.VViZlV("slwfil")
  self.png_slbfil   = self.VViZlV("slbfil")
  self.png_slwdir   = self.VViZlV("slwdir")
  self.VVL3oo()
  self.VVJr0e(directory)
 def VViZlV(self, category):
  return LoadPixmap("%s%s.png" % (VVGuqQ, category), getDesktop(0))
 def VVfxgL(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVrla7(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFMS0I(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFKY60(" -> " , VV106B) + FFKY60(os.readlink(path), VVuV1K)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVEvPQ + 10, 0, self.VVg2p6, self.VVEvPQ, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVgEBF: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVEvPQ-4, self.VVEvPQ-4, png, self.pngBGColor, self.pngBGColor, VVgEBF))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVEvPQ-4, self.VVEvPQ-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVxEvH(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVL3oo(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VV5LxI(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVGDOH(self, file):
  if os.path.realpath(file) == file:
   return self.VV5LxI(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV5LxI(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV5LxI(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVFqcj(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVmOHg.info(l[0][0]).getEvent(l[0][0])
 def VV1rQM(self):
  return self.list
 def VVtuVY(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVJr0e(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVxHmV:
    self.current_mountpoint = self.VVGDOH(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVxHmV:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVB4mW and not self.VVtuVY(path, self.VVi7Ku):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVrla7(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVgQx3:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVmOHg = eServiceCenter.getInstance()
   list = VVmOHg.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVkCAR and not self.isTop:
   if directory == self.current_mountpoint and self.VVxHmV:
    self.list.append(self.VVrla7(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVB4mW and self.VV5LxI(directory) in self.VVB4mW):
    self.list.append(self.VVrla7(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVkCAR:
   for x in directories:
    if not (self.VVB4mW and self.VV5LxI(x) in self.VVB4mW) and not self.VVtuVY(x, self.VVi7Ku):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVrla7(name = name, absolute = x, isDir = True, png = png))
  if self.VVgEtT:
   for x in files:
    if self.VVgQx3:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFKY60(" -> " , VV106B) + FFKY60(target, VVuV1K)
       else:
        png = self.png_slbfil
        name += FFKY60(" -> " , VV106B) + FFKY60(target, VVvqWy)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVxEvH(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVGuqQ, category))
    if (self.VVJNOj is None) or iCompile(self.VVJNOj).search(path):
     self.list.append(self.VVrla7(name = name, absolute = x , isDir = False, png = png))
  if self.VVxHmV and len(self.list) == 0:
   self.list.append(self.VVrla7(name = FFKY60("No USB connected", VVLLOq), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVSnHp(self):
  return self.current_directory
 def VViAXS(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVJr0e(self.getSelection()[0], select = self.current_directory)
 def VVAlJH(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVnDq1(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVqtkq)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVqtkq)
 def refresh(self):
  self.VVJr0e(self.current_directory, self.VVAlJH())
 def VVqtkq(self, action, device):
  self.VVL3oo()
  if self.current_directory is None:
   self.refresh()
class CCZebD(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFDOid(VVkeFs, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVeBho   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVTwy9(defFG, "#00FFFFFF")
  self.defBG   = self.VVTwy9(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFBDfs(self, self.Title)
  self["keyRed"].show()
  FFOV9c(self["keyGreen"] , "< > Transp.")
  FFOV9c(self["keyYellow"], "Foreground")
  FFOV9c(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVe22C        ,
   "yellow"   : boundFunction(self.VVWHpJ, False)  ,
   "blue"   : boundFunction(self.VVWHpJ, True)  ,
   "up"   : self.VVOGfJ          ,
   "down"   : self.VVXQkw         ,
   "left"   : self.VV2JtA         ,
   "right"   : self.VVuZuU         ,
   "last"   : boundFunction(self.VVSKnC, -5) ,
   "next"   : boundFunction(self.VVSKnC, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVKQSI)
 def VVKQSI(self):
  self.onShown.remove(self.VVKQSI)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFIRRt(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFIRRt(self["keyRed"] , c)
  FFIRRt(self["keyGreen"] , c)
  self.VVy4YJ()
  self.VVNFjz()
  FFnGw1(self["myColorTst"], self.defFG)
  FFIRRt(self["myColorTst"], self.defBG)
 def VVTwy9(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVNFjz(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVd6WS(0, 0)
     return
 def VVe22C(self):
  self.close(self.defFG, self.defBG)
 def VVOGfJ(self): self.VVd6WS(-1, 0)
 def VVXQkw(self): self.VVd6WS(1, 0)
 def VV2JtA(self): self.VVd6WS(0, -1)
 def VVuZuU(self): self.VVd6WS(0, 1)
 def VVd6WS(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVanwN()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVMtC5()
 def VVy4YJ(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVMtC5(self):
  color = self.VVanwN()
  if self.isBgMode: FFIRRt(self["myColorTst"], color)
  else   : FFnGw1(self["myColorTst"], color)
 def VVWHpJ(self, isBg):
  self.isBgMode = isBg
  self.VVy4YJ()
  self.VVNFjz()
 def VVSKnC(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVd6WS(0, 0)
 def VVhEqD(self):
  return hex(self.transp)[2:].zfill(2)
 def VVanwN(self):
  return ("#%s%s" % (self.VVhEqD(), self.colors[self.curRow][self.curCol])).upper()
class CCM8fv(ScrollLabel):
 def __init__(self, parentSELF, text="", VVcrQ0=True):
  ScrollLabel.__init__(self, text)
  self.VVcrQ0=VVcrQ0
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVaKaD  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVZWCz    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVvHjI   ,
   "green"   : self.VVLVuI  ,
   "yellow"  : self.VVAxty  ,
   "blue"   : self.VVqE6L  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVZJTl    ,
   "chanUp"  : self.VVZJTl    ,
   "pageDown"  : self.VV7gHf    ,
   "chanDown"  : self.VV7gHf
  }, -1)
 def VVqzy0(self, isResizable=True, VVMjH7=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFkJyH(self.parentSELF, True)
  self.isResizable = isResizable
  if VVMjH7:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVZWCz  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFIRRt(self, color)
 def FFIRRtColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVaKaD - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVrF9f()
 def pageUp(self):
  if self.VVaKaD > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVaKaD > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVZJTl(self):
  self.setPos(0)
 def VV7gHf(self):
  self.setPos(self.VVaKaD-self.pageHeight)
 def VVZV7i(self):
  return self.VVaKaD <= self.pageHeight or self.curPos == self.VVaKaD - self.pageHeight
 def VVrF9f(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVaKaD, 3))
   start = int((100 - vis) * self.curPos / (self.VVaKaD - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVJQke=VVLLcg):
  old_VVZV7i = self.VVZV7i()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVaKaD = self.long_text.calculateSize().height()
   if self.VVcrQ0 and self.VVaKaD > self.pageHeight:
    self.scrollbar.show()
    self.VVrF9f()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVaKaD))
   if   VVJQke == VVIFZO: self.setPos(0)
   elif VVJQke == VV3zRr : self.VV7gHf()
   elif old_VVZV7i    : self.VV7gHf()
 def appendText(self, text, VVJQke=VV3zRr):
  self.setText(self.message + str(text), VVJQke)
 def VVAxty(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVZODk(size)
 def VVqE6L(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVZODk(size)
 def VVLVuI(self):
  self.VVZODk(self.VVZWCz)
 def VVZODk(self, VVZWCz):
  self.long_text.setFont(gFont(self.fontFamily, VVZWCz))
  self.setText(self.message, VVJQke=VVLLcg)
  self.VVTNO5(calledFromFontSizer=True)
 def VVvHjI(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFVqav(expPath), self.textOutFile, FFBQPI())
    with open(outF, "w") as f:
     f.write(FF0IQR(self.message))
    FFuW4T(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF23yv(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVTNO5(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVaKaD > 0 and self.pageHeight > 0:
   if self.VVaKaD < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVaKaD
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
