import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, sleep as iSleep
from time      import time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVT4M3   = "v3.2.0"
VVQkCM    = "11-11-2021"
EASY_MODE    = 0
VV1sXI   = 0
VVJ3n6   = 0
VVqVzQ  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVtoxO  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VV2Mhn    = "/media/usb/"
VVDqhd    = "/usr/share/enigma2/picon/"
VVonVf   = "/etc/enigma2/"
VVZGB0  = "ajpanel_update_url"
VVtLz2   = "AJPan"
VVYka2    = ""
VVkLUF    = "Regular"
VVjtIv      = "-" * 80;
VVkUZg    = (VVjtIv, )
VVkEqR    = ""
VV2oWO   = " && echo 'Successful' || echo 'Failed!'"
VVOiWE    = []
VVG86Q     = 0
VVrutA    = ""
VVzipJ  = False
VVhYf3  = False
VVbI0H     = 0
VVfanr    = 1
VVUbU5    = 2
VVCv3m   = 3
VVZmTS    = 4
VV2L3D    = 5
VVxOjf = 6
VVp4lb = 7
VV7Jfd  = 8
VVtT2C   = 9
VVCHoD   = 10
VV4VuE   = 11
VVOzvB  = 12
VVFpVB  = 13
VVckBK    = 14
VVrSVt   = 15
VVY735   = 16
WINDOW_COLORS    = 17
WINDOW_DUMMY    = 18
VVcBqK  = 15
VV7TFL   = 0
VVifYP   = 1
VVHcSs   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.PIconsPath     = ConfigDirectory(default=VVDqhd, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VV2Mhn, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFA2fM():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVlhsI  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVuUKZ = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVlhsI  : return 0
  elif VVuUKZ : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVPcnb = FFA2fM()
VVzRfn = VVsWXS = VVZapb = VViuIz = VVpduW = VVIk8T = VVJH5T = VVEdAx = COLOR_CONS_BRIGHT_YELLOW = VV7ect = VV2SpG = VVVF41 = ""
def FF7iwx(FF7iwxText="", addSep=True):
 if VV1sXI:
  FF7iwxText = str(FF7iwxText)
  if "\n" in FF7iwxText: FF7iwxText = "\n" + FF7iwxText
  txt = VVjtIv + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FF7iwxText))
  os.system("cat << '_EOF' \n" + txt + "\n_EOF")
def FFkjmq(txt, isAppend=True, ignoreErr=False):
 if VV1sXI:
  tm = FFIDJA()
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF7iwx(err)
  FF7iwx("Output Log File : %s" % fileName)
VVOiWE = []
def FF7PNd(win):
 global VVOiWE
 if not win in VVOiWE:
  VVOiWE.append(win)
def FF2k7C(*args):
 global VVOiWE
 for win in VVOiWE:
  try:
   win.close()
  except:
   pass
 VVOiWE = []
def FF4HyG():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVUkce = FF4HyG()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFylbn()      : return getDescriptor(FFvMFs   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFkoeL()   : return getDescriptor(FFvMFs   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFtM9u()   : return getDescriptor(FF1oJW , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager")
def FF99EW()  : return getDescriptor(FF6i0J , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Live Log (OSCam/NCam)")
def FFTrgf(): return getDescriptor(FFKBIp , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player")
def FFHObi()       : return getDescriptor(FFrCfO  , [ PluginDescriptor.WHERE_MENU    ] )
def FF4xKW()     : return PluginDescriptor(fnc=FFehXB, where=[PluginDescriptor.WHERE_SESSIONSTART])
def Plugins(**kwargs):
 result = [ FFylbn() , FFHObi() , FF4xKW() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFkoeL())
  result.append(FFtM9u())
  result.append(FF99EW())
  result.append(FFTrgf())
 return result
def FFehXB(reason, **kwargs):
 if reason == 0:
  FFgN24()
  if "session" in kwargs:
   session = kwargs["session"]
   FFw2o4(session)
   CCgFHw(session)
def FFrCfO(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFvMFs, PLUGIN_NAME, 45)]
 else:
  return []
def FFvMFs(session, **kwargs):
 session.open(Main_Menu)
def FF1oJW(session, **kwargs):
 session.open(CCRH8h)
def FF6i0J(session, **kwargs):
 FFihKW(session, CCFHNo.VVa2K4)
def FFKBIp(session, **kwargs):
 FFQEia(session, isFromSession=True)
def FFAvT5():
 pluginList   = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel   = FFkoeL()
 descrFileMan  = FFtM9u()
 descrCamLog   = FF99EW()
 descrSignalPlayer = FFTrgf()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel in pluginList   : iPlugins.addPlugin(descrPanel)
   if not descrFileMan in pluginList  : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList  : iPlugins.addPlugin(descrCamLog)
   if not descrSignalPlayer in pluginList : iPlugins.addPlugin(descrSignalPlayer)
  else:
   if descrPanel in pluginList   : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList  : iPlugins.removePlugin(descrFileMan)
   if descrCamLog in pluginList  : iPlugins.removePlugin(descrCamLog)
   if descrSignalPlayer in pluginList : iPlugins.removePlugin(descrSignalPlayer)
 except:
  pass
VVMugq = None
def FFgN24():
 try:
  global VVMugq
  if VVMugq is None:
   VVMugq    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFo9lO
  ChannelContextMenu.FFcu6d = FFcu6d
 except:
  pass
def FFo9lO(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVMugq(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFcu6d, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFcu6d, title1, csel, isFind=True))))
def FFcu6d(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFFRn9(refCode)
 except:
  pass
 self.session.open(boundFunction(CCwZoR, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFw2o4(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFOyLT, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFOyLT, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFOyLT, session, "lred")
def FFOyLT(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFQEia(session, isFromSession=True)
def FFwrVg(SELF, title="", addLabel=False, addScrollLabel=False, VVpLvf=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FF7yjp()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC1bAh(SELF)
 if VVpLvf:
  SELF["myMenu"] = MenuList(VVpLvf)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVlsTV        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFBFJx(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFXMtJ, SELF, "0") ,
  "1"    : boundFunction(FFXMtJ, SELF, "1") ,
  "2"    : boundFunction(FFXMtJ, SELF, "2") ,
  "3"    : boundFunction(FFXMtJ, SELF, "3") ,
  "4"    : boundFunction(FFXMtJ, SELF, "4") ,
  "5"    : boundFunction(FFXMtJ, SELF, "5") ,
  "6"    : boundFunction(FFXMtJ, SELF, "6") ,
  "7"    : boundFunction(FFXMtJ, SELF, "7") ,
  "8"    : boundFunction(FFXMtJ, SELF, "8") ,
  "9"    : boundFunction(FFXMtJ, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFGTAN, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFXMtJ(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVVF41:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVVF41 + SELF.keyPressed + VVsWXS)
    txt = VVsWXS + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFngIP(SELF, txt)
def FFGTAN(SELF, tableObj, colNum):
 FFngIP(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVhcbc()
     break
 except:
  pass
def FFexYq(SELF, setMenuAction=True):
 if setMenuAction:
  global VVkEqR
  VVkEqR = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FF7yjp():
 return ("  %s" % VVkEqR)
def FFh33U(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFAwDH(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFJQUL(color):
 return parseColor(color).argb()
def FFwT6X(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF7zZI(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFwEzj(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFb5eo(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVVF41)
 else:
  return ""
def FFmD5M(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVjtIv, word, VVjtIv, VVVF41)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVjtIv, word, VVjtIv)
def FFXMyR(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVVF41
def FFgvYp(color):
 if color: return "echo -e '%s' %s;" % (VVjtIv, FFb5eo(VVjtIv, VVEdAx))
 else : return "echo -e '%s';" % VVjtIv
def FFcOuU(title, color):
 title = "%s\n%s\n%s\n" % (VVjtIv, title, VVjtIv)
 return FFXMyR(title, color)
def FFqSyv(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFQLuS(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFXHmb(callBackFunction):
 tCons = CCsT2Q()
 tCons.ePopen("echo", boundFunction(FFOP4f, callBackFunction))
def FFOP4f(callBackFunction, result, retval):
 callBackFunction()
def FFGw6o(SELF, fnc, title="Processing ...", clearMsg=True):
 FFngIP(SELF, title)
 tCons = CCsT2Q()
 tCons.ePopen("echo", boundFunction(FFZNgt, SELF, fnc, clearMsg))
def FFZNgt(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFngIP(SELF)
def FF1wdX(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFzFRs(cmd):
 txt = FF1wdX(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFeABk(cmd):
 lines = FFzFRs(cmd)
 if lines: return lines[0]
 else : return ""
def FFJglf(SELF, cmd):
 lines = FFzFRs(cmd)
 VVKPkH = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVKPkH.append((key, val))
  elif line:
   VVKPkH.append((line, ""))
 if VVKPkH:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF4eNC(SELF, None, header=header, VVcsAS=VVKPkH, VVgyfO=widths, VVvE6h=22)
 else:
  FFTQP2(SELF, cmd)
def FFTQP2(    SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, VVhRxE=True, VVJPTL=VVifYP, **kwargs)
def FFo8kY(  SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, **kwargs)
def FF1HQ0(   SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, VVVi8T=True, VVnENe=True, VVJPTL=VVifYP, **kwargs)
def FFleJp(  SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, VVVi8T=True, VVnENe=True, VVJPTL=VVHcSs, **kwargs)
def FF0xy0(  SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, VVnmqx=True , **kwargs)
def FFRZv3( SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, VVY6We=True   , **kwargs)
def FFI0Sl( SELF, cmd, **kwargs): SELF.session.open(CC5kDp, VV7ySt=cmd, VVhvP7=True  , **kwargs)
def FFfUI2(cmd):
 return cmd + " > /dev/null 2>&1"
def FFo2cU():
 return " > /dev/null 2>&1"
def FF8Snx(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFphRM(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFiS2t():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFeABk(cmd)
VVeME3     = 0
VVAvk3      = 1
VVKI1q   = 2
VVq5HK      = 3
VVCwg3      = 4
VV6Y77     = 5
VVL2aE     = 6
VVU4WP  = 7
VVZvVv = 8
VVv2YB  = 9
VVpb9g     = 10
VVOUmA  = 11
VVH1Wq  = 12
def FFVqya(parmNum, grepTxt):
 if   parmNum == VVeME3  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVAvk3   : param = ["list"   , "apt list" ]
 elif parmNum == VVKI1q: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFiS2t()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFHVrF(parmNum, package):
 if   parmNum == VVq5HK      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVCwg3      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VV6Y77     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVL2aE     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVU4WP  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVZvVv : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVv2YB  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVpb9g     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVOUmA  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVH1Wq  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFiS2t()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFLkHT():
 result = FFeABk("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFHVrF(VVL2aE , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFfUI2("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFfUI2("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFb5eo(failed1, VVEdAx))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFb5eo(failed2, VVEdAx))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFb5eo(failed3, VVZapb))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF2RkY(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFHVrF(VVL2aE , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFfUI2("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFb5eo(failed1, VVEdAx))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFb5eo(failed2, VVZapb))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFZ5eQ(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFfUI2('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFfUI2("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFItSN(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFawFw(path, keepends=False, maxSize=-1):
 lines = FFItSN(path, maxSize)
 return lines.splitlines(keepends)
def FF8Zbg(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFawFw(path, maxSize=maxSize)
  if lines: FFWUy2(SELF, lines, title=title, VVJPTL=VVifYP)
  else : FF4fts(SELF, path, title=title)
 else:
  FFurlj(SELF, path, title)
def FFkrGj(SELF, path, title):
 if fileExists(path):
  txt = FFItSN(path)
  txt = txt.replace("#W#", VVVF41)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVsWXS)
  txt = txt.replace("#C#", VV7ect)
  txt = txt.replace("#P#", VViuIz)
  FFWUy2(SELF, txt, title=title)
 else:
  FFurlj(SELF, path, title)
def FFTMQA(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF5dqf(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFtgjE(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFUUJW(parent)
 else    : return FF97nD(parent)
def FF7R0c(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFUUJW(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FF97nD(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFF8Uc():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVqVzQ)
 paths.append(VVqVzQ.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF5dqf(ba)
 for p in list:
  p = ba + p + VVqVzQ
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVtLz2, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVqVzQ, VVtLz2 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVjwdL, VVmF17 = FFF8Uc()
def FFk2O3():
 def VV0PVG(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVoGvk  = VV0PVG(CFG.backupPath, CCUKTK.VVXHYA())
 VVxURa  = VV0PVG(CFG.downloadedPackagesPath, t)
 VVqS5N = VV0PVG(CFG.exportedTablesPath, t)
 VVz9ad = VV0PVG(CFG.exportedPIconsPath, t)
 VVBTej  = VV0PVG(CFG.packageOutputPath, t)
 global VV2Mhn
 VV2Mhn = FFUUJW(CFG.backupPath.getValue())
 if VVoGvk or VVBTej or VVxURa or VVqS5N or VVz9ad:
  configfile.save()
 return VVoGvk, VVBTej, VVxURa, VVqS5N, VVz9ad
def FFpgzO(path):
 path = FF97nD(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFoZ5e(SELF, pathList, tarFileName, addTimeStamp=True):
 VVcsAS = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVcsAS.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVcsAS.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVcsAS.append(path)
 if not VVcsAS:
  FFCwHk(SELF, "Files not found!")
 elif not pathExists(VV2Mhn):
  FFCwHk(SELF, "Path not found!\n\n%s" % VV2Mhn)
 else:
  VV1PP7 = FFUUJW(VV2Mhn)
  tarFileName = "%s%s" % (VV1PP7, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFi9KP())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVcsAS:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVjtIv
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFb5eo(tarFileName, VVJH5T))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFb5eo(failed, VVJH5T))
  cmd += "fi;"
  cmd +=  sep
  FFo8kY(SELF, cmd)
def FF77Wz(SELF, title, VVbVuZ):
 SELF.session.open(boundFunction(CCf89k, Title=title, VVbVuZ=VVbVuZ))
def FFbnvf(labelObj, VVbVuZ):
 if VVbVuZ and fileExists(VVbVuZ):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVSEwK(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVSEwK)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVbVuZ)
   return True
  except:
   pass
 return False
def FFiKgb(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFkB7Z(satNum)
  return satName
def FFkB7Z(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFmWdo(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFiKgb(val)
  else  : sat = FFkB7Z(val)
 return sat
def FFIwV7(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFiKgb(num)
 except:
  pass
 return sat
def FFrrx4(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFMRZ5(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFJfd1(info, iServiceInformation.sServiceref)
   prov = FFJfd1(info, iServiceInformation.sProvider)
   state = str(FFJfd1(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFfXHu(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFvanf(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFJfd1(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFdy9m(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFFRn9(refCode):
 info = FFhNOJ(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFcRVw(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFtZ2p(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFhNOJ(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVUNsv = eServiceCenter.getInstance()
  if VVUNsv:
   info = VVUNsv.info(service)
 return info
def FFlnjO(SELF, refCode, VV9Blm=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFvLNC(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VV9Blm:
   FFQEia(SELF, isFromSession)
 try:
  VVymXU = InfoBar.instance
  if VVymXU:
   VV1fDc = VVymXU.servicelist
   if VV1fDc:
    servRef = eServiceReference(refCode)
    VV1fDc.saveChannel(servRef)
 except:
  pass
def FFvLNC(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCuTLY()
    if pr.VV70uK(refCode, chName, decodedUrl, iptvRef):
     pr.VVKs0E(SELF, isFromSession)
def FFfXHu(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFvanf(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFfGUi(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFwsb7(userBfile):
 txt = ""
 bFile = VVonVf + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVonVf + userBfile):
  fTxt = FFItSN(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFeABk('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFfGUi(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFGl0A(url):
 if iQuote : return iQuote(url)
 else  : return url
def FF1sXm(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFKrOM(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF6BxB(txt):
 try:
  return FF1sXm(FFKrOM(txt)) == txt
 except:
  return False
def FFQEia(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCwbgh)
 else      : FFEvYn(session, reopen=True)
def FFEvYn(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFEvYn, session), CCGRG9)
  except:
   try:
    FFKMyh(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFF8Oa(refCode):
 tp = CC2hod()
 if tp.VV7aJX(refCode) : return True
 else        : return False
def FFQWXD(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFNkRg():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF80rj():
 VVymXU = InfoBar.instance
 if VVymXU:
  VV1fDc = VVymXU.servicelist
  if VV1fDc:
   return VV1fDc.getBouquetList()
 return None
def FFqamm():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFhOZZ():
 path = FFqamm()
 if path:
  txt = FFItSN(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFXWZI(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVUNsv = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVUNsv.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FF1pIA():
 VV5RVA = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVKXvi = list(VV5RVA)
 return VVKXvi, VV5RVA
def FF9iJ5():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFihKW(session, VVuxCh):
 VVFBme, VVUD9R, VVbWjA, camCommand = FFW7TE()
 if VVUD9R:
  runLog = False
  if   VVuxCh == CCFHNo.VVDXV9 : runLog = True
  elif VVuxCh == CCFHNo.VVUcO6 : runLog = True
  elif not VVbWjA          : FFKMyh(session, message="SoftCam not started yet!")
  elif fileExists(VVbWjA)        : runLog = True
  else             : FFKMyh(session, message="File not found !\n\n%s" % VVbWjA)
  if runLog:
   session.open(boundFunction(CCFHNo, VVFBme=VVFBme, VVUD9R=VVUD9R, VVbWjA=VVbWjA, VVuxCh=VVuxCh))
 else:
  FFKMyh(session, message="No active OSCam/NCam found !", title="Live Log")
def FFW7TE():
 VVFBme = "/etc/tuxbox/config/"
 VVUD9R = None
 VVbWjA  = None
 camCommand = FFeABk("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVUD9R = "oscam"
 elif "ncam"  in camCommand : VVUD9R = "ncam"
 if VVUD9R:
  path = FFeABk(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFUUJW(path)
  if pathExists(path):
   VVFBme = path
  tFile = VVFBme + VVUD9R + ".conf"
  tFile = FFeABk("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVbWjA = tFile
 return VVFBme, VVUD9R, VVbWjA, camCommand
def FFSqAc(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFRY1H():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFi9KP():
 return FFRY1H().replace(" ", "_").replace("-", "").replace(":", "")
def FFP20u(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFIDJA():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FF3VVg(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCDch1.VVaZZX(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCDch1.VVUS5c(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFfUI2("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFczNY(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFsWbs(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFWU4Y():
 return int(FF1wdX("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFHfGb():
 global VVG86Q_TIME, VVrutA
 VVrutA  = int(FFWU4Y())
 VVG86Q_TIME = iTime()
def FFdUL0():
 elapsed = iTime() - VVG86Q_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFWU4Y() - VVrutA
 FF7iwx(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFGBS4(SELF, message, title=""):
 SELF.session.open(boundFunction(CC5cSz, title=title, message=message, VVdW3j=True))
def FFWUy2(SELF, message, title="", VVJPTL=VVifYP, **kwargs):
 SELF.session.open(boundFunction(CC5cSz, title=title, message=message, VVJPTL=VVJPTL, **kwargs))
def FFCwHk(SELF, message, title="")  : FFKMyh(SELF.session, message, title)
def FFurlj(SELF, path, title="") : FFKMyh(SELF.session, "File not found !\n\n%s" % path, title)
def FF4fts(SELF, path, title="") : FFKMyh(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFpJtk(SELF, title="")  : FFKMyh(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFKMyh(session, message, title="") : session.open(boundFunction(CCO5EH, title=title, message=message))
def FFQYeU(SELF, VVcWME, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVcWME, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVcWME, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVcWME, boundFunction(CCYylq, title=title, message=message, VV0ZSY=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFCwHk(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFRzxq(SELF, callBack_Yes, VVWKlK, callBack_No=None, title="", VVpF7d=False, VV4GnV=True):
 SELF.session.openWithCallback(boundFunction(FFip1b, callBack_Yes, callBack_No)
        , boundFunction(CC2eL4, title=title, VVWKlK=VVWKlK, VV4GnV=VV4GnV, VVpF7d=VVpF7d))
def FFip1b(callBack_Yes, callBack_No, FFRzxqed):
 if FFRzxqed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFngIP(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFEWGT(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFPiv5(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VV4sKp = eTimer()
def FFEWGT(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FF3ZE5, SELF))
 try:
  t = VV4sKp.timeout.connect(boundFunction(FF3ZE5, SELF))
 except:
  VV4sKp.callback.append(boundFunction(FF3ZE5, SELF))
 VV4sKp.start(milliSeconds, 1)
def FF3ZE5(SELF):
 VV4sKp.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FF4eNC(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCQ5mT, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCQ5mT, **kwargs))
  FF7PNd(win)
  return win
 except:
  return None
def FFBYrC(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCAZ66, **kwargs))
 FF7PNd(win)
 return win
def FFCpwr(SELF, **kwargs):
 SELF.session.open(CCzK25, **kwargs)
def FFgCHF(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFV5BX(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVkLUF, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFVqF1(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFV5BX(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFGYXd():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFH892(VVvE6h):
 screenSize  = FFGYXd()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVvE6h)
 return bodyFontSize
def FFyvNz(VVvE6h, extraSpace):
 font = gFont(VVkLUF, VVvE6h)
 VVfASw = fontRenderClass.getInstance().getLineHeight(font) or (VVvE6h * 1.25)
 return int(VVfASw + VVfASw * extraSpace)
def FF5ync(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVkLUF
def FFjy7Y(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFGYXd()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVcBqK)
 bodyFontStr  = 'font="%s;%d"' % (VVkLUF, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFyvNz(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVkLUF, titleFontSize, alignLeftCenter)
 if winType == VVbI0H or winType == VVfanr:
  if winType == VVfanr : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == WINDOW_DUMMY:
  pass
 elif winType == VVckBK:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.2)
  b2Left1 = marginLeft
  b2Left2 = b2Left1 + timeW + marginLeft
  b2Left3 = width - marginLeft - timeW
  infW = b2Left3 - b2Left2 - marginLeft
  tmp += '<widget name="myPlayBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="myPlayBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" />'   % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyColor)
  tmp += '<widget name="myPlayBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a005555" />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="myPlayBarM"  position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="myPlayVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="#0a002233" %s %s'   % (bodyFontStr, alignCenter)
  tmp += '<widget name="myPlayPos"  position="%d,%d" size="%d,%d" %s />' % (b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlayMsg"  position="%d,%d" size="%d,%d" %s />' % (b2Left2, b2Top, infW , barH, param)
  tmp += '<widget name="myPlayDur"  position="%d,%d" size="%d,%d" %s />' % (b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep"   position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  names = ["Jmp", "Skp", "Mrk", "Blu", "Inf"]
  b3W  = int((width - marginLeft * 6.0) / 5.0)
  left = marginLeft
  for i in range(5):
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" foregroundColor="#0affffff" backgroundColor="#11222222" %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter)
   left += b3W + marginLeft
 elif winType == VVrSVt:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVZmTS:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVUbU5:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVCv3m:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVkLUF, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVkLUF, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVCHoD:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFGBS4H = int(bodyH * 0.5)
  inpTop = bodyTop + FFGBS4H
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFGBS4H, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVkLUF, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVkLUF, mapF, alignCenter)
 elif winType == VV4VuE:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVOzvB:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVkLUF, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVY735:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVkLUF, fontH, alignCenter)
 elif winType == VVFpVB:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVkLUF, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVkLUF, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVkLUF, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == WINDOW_COLORS:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVp4lb : align = alignLeftCenter
  elif winType == VVxOjf : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVtT2C:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VV2L3D:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVxOjf:
    fontStr = 'font="%s;%d"' % (FF5ync("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVvE6h = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVkLUF, VVvE6h, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVkLUF, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVkLUF, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVrOep = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVkLUF, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVrOep[i], VVkLUF, barFont, alignCenter)
   left += btnW + gap
 if winType == VVxOjf:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVrOep = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVrOep[i], VVkLUF, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVpLvf = []
  if VVJ3n6:
   VVpLvf.append(("-- MY TEST --"    , "myTest"   ))
  VVpLvf.append(("  File Manager"     , "FileManager"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("  Services/Channels"    , "ChannelsTools" ))
  VVpLvf.append(("  IPTV"       , "IptvTools"  ))
  VVpLvf.append(("  PIcons"       , "PIconsTools"  ))
  VVpLvf.append(("  SoftCam"      , "SoftCam"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("  Plugins"      , "PluginsTools" ))
  VVpLvf.append(("  Terminal"      , "Terminal"  ))
  VVpLvf.append(("  Backup & Restore"    , "BackupRestore" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("  Date/Time"      , "Date_Time"  ))
  VVpLvf.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVpLvf)
  FFwrVg(self, VVpLvf=VVpLvf)
  FFh33U(self["keyRed"] , "Exit")
  FFh33U(self["keyGreen"] , "Settings")
  FFh33U(self["keyYellow"], "Dev. Info.")
  FFh33U(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VV2wIp       ,
   "yellow"  : self.VVvLLH       ,
   "blue"   : self.VVPLPo       ,
   "info"   : self.VVPLPo       ,
   "next"   : self.VVCYmK       ,
   "menu"   : self.VVYKTA     ,
   "0"    : boundFunction(self.VVKgPU, 0) ,
   "1"    : boundFunction(self.VVemKe, 1)   ,
   "2"    : boundFunction(self.VVemKe, 2)   ,
   "3"    : boundFunction(self.VVemKe, 3)   ,
   "4"    : boundFunction(self.VVemKe, 4)   ,
   "5"    : boundFunction(self.VVemKe, 5)   ,
   "6"    : boundFunction(self.VVemKe, 6)   ,
   "7"    : boundFunction(self.VVemKe, 7)   ,
   "8"    : boundFunction(self.VVemKe, 8)   ,
   "9"    : boundFunction(self.VVemKe, 9)
  })
  self.onShown.append(self.VVH8dW)
  self.onClose.append(self.onExit)
  global VVzipJ, VVhYf3
  VVzipJ = VVhYf3 = False
 def VVlsTV(self):
  item = FFexYq(self)
  self.VVemKe(item)
 def VVemKe(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVZlU7()
   elif item in ("FileManager"  , 1) : self.session.open(CCRH8h)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCUNoh)
   elif item in ("IptvTools"  , 3) : self.session.open(CCDch1)
   elif item in ("PIconsTools"  , 4) : self.VV3U7j()
   elif item in ("SoftCam"   , 5) : self.session.open(CCaVL3)
   elif item in ("PluginsTools" , 6) : self.session.open(CCzUIl)
   elif item in ("Terminal"  , 7) : self.session.open(CClxRh)
   elif item in ("BackupRestore" , 8) : self.session.open(CCdlXH)
   elif item in ("Date_Time"  , 9) : self.session.open(CC9eIE)
   elif item in ("CheckInternet" , 10) : self.session.open(CCFJhR)
   else         : self.close()
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
  FFgCHF(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVT4M3)
  self["myTitle"].setText(title)
  VVoGvk, VVBTej, VVxURa, VVqS5N, VVz9ad = FFk2O3()
  self.VV0CBP()
  if VVoGvk or VVBTej or VVxURa or VVqS5N or VVz9ad:
   VVC8uD = lambda path, subj: "%s:\n%s\n\n" % (subj, FFXMyR(path, VVZapb)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVC8uD(VVoGvk   , "Backup/Restore Path"    )
   txt += VVC8uD(VVBTej  , "Created Package Files (IPK/DEB)" )
   txt += VVC8uD(VVxURa  , "Download Packages (from feeds)" )
   txt += VVC8uD(VVqS5N , "Exported Tables"     )
   txt += VVC8uD(VVz9ad , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFWUy2(self, txt, title="Settings Paths")
  if (EASY_MODE or VV1sXI or VVJ3n6):
   FF7zZI(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFngIP(self, "Welcome", 300)
  FFXHmb(boundFunction(self.VVQYDP, title))
 def VVQYDP(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCUKTK.VVARki()
   if url:
    newWebVer = CCUKTK.VVM7AK(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFfUI2("rm /tmp/ajpanel*"))
 def VVKgPU(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVzipJ
    VVzipJ = True
    FF7zZI(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVCYmK(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VVhYf3
   VVhYf3 = True
   FF7zZI(self["myTitle"], "#dd5588")
 def VV3U7j(self):
  found = False
  pPath = CCivOr.VVHoxR()
  if pathExists(pPath):
   for fName, fType in CCivOr.VVXZs1(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCivOr)
  else:
   VVpLvf = []
   VVpLvf.append(("PIcons Manager" , "CCivOr" ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(CCivOr.VVSYjP())
   VVpLvf.append(VVkUZg)
   VVpLvf += CCivOr.VVw6pp()
   FFBYrC(self, self.VVCjq6, VVpLvf=VVpLvf)
 def VVCjq6(self, item=None):
  if item:
   if   item == "CCivOr"   : self.session.open(CCivOr)
   elif item == "VVwOwu"  : CCivOr.VVwOwu(self)
   elif item == "VVIJ88"  : CCivOr.VVIJ88(self)
   elif item == "findPiconBrokenSymLinks" : CCivOr.VVrLx7(self, True)
   elif item == "FindAllBrokenSymLinks" : CCivOr.VVrLx7(self, False)
 def VV2wIp(self):
  self.session.open(CCUKTK)
 def VVvLLH(self):
  self.session.open(CC5D8Y)
 def VVPLPo(self):
  changeLogFile = VVmF17 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFawFw(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFXMyR("\n%s\n%s\n%s" % (VVjtIv, line, VVjtIv), VViuIz, VVVF41)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFXMyR(line, VVsWXS, VVVF41)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFWUy2(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVT4M3), VVvE6h=26)
 def VVYKTA(self):
  VVpLvf = []
  VVpLvf.append(("Title Colors"   , "title" ))
  VVpLvf.append(("Menu Area Colors"  , "body" ))
  VVpLvf.append(("Menu Pointer Colors" , "cursor" ))
  VVpLvf.append(("Bottom Bar Colors" , "bar"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Reset"    , "reset" ))
  FFBYrC(self, self.VV84zN, VVpLvf=VVpLvf, width=500, title="Main Menu Colors")
 def VV84zN(self, item=None):
  if item:
   if item == "reset":
    os.system(FFfUI2("rm %s" % self.VVgtrJ()))
    self.close()
   else:
    tDict = self.VVrq1K()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVG6sb, tDict, item), CC89tO, defFG=fg, defBG=bg)
 def VVgtrJ(self):
  return VV2Mhn + "ajpanel_colors"
 def VVrq1K(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVgtrJ()
  if fileExists(p):
   txt = FFItSN(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVG6sb(self, tDict, item, fg, bg):
  if fg:
   self.VV7ahS(item, fg)
   self.VVKf6l(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVXAcS(tDict)
 def VVXAcS(self, tDict):
   p = self.VVgtrJ()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV7ahS(self, item, fg):
  if   item == "title" : FFwT6X(self["myTitle"], fg)
  elif item == "body"  :
   FFwT6X(self["myMenu"], fg)
   FFwT6X(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FF7zZI(self["myBar"], fg)
   FFwT6X(self["keyRed"], fg)
   FFwT6X(self["keyGreen"], fg)
   FFwT6X(self["keyYellow"], fg)
   FFwT6X(self["keyBlue"], fg)
 def VVKf6l(self, item, bg):
  if   item == "title" : FF7zZI(self["myTitle"], bg)
  elif item == "body"  :
   FF7zZI(self["myMenu"], bg)
   FF7zZI(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF7zZI(self["myBar"], bg)
 def VV0CBP(self):
  tDict = self.VVrq1K()
  self.VVgYRt(tDict, "title")
  self.VVgYRt(tDict, "body")
  self.VVgYRt(tDict, "cursor")
  self.VVgYRt(tDict, "bar")
 def VVgYRt(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV7ahS(name, fg)
  if bg: self.VVKf6l(name, bg)
 def VVZlU7(self):
  opt = 11
  if   opt ==  0 : FFGBS4(self, "This is My Message.", "Testing")
  elif opt == 11:
   pass
class CC5D8Y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVpLvf = []
  VVpLvf.append(("Settings File"        , "SettingsFile"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Box Info"          , "VVsuNE"    ))
  VVpLvf.append(("Tuners Info"         , "VVpsyX"   ))
  VVpLvf.append(("Python Version"        , "VVuhfD"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Screen Size"         , "ScreenSize"    ))
  VVpLvf.append(("Locale"          , "Locale"     ))
  VVpLvf.append(("Processor"         , "Processor"    ))
  VVpLvf.append(("Operating System"        , "OperatingSystem"   ))
  VVpLvf.append(("Drivers"          , "drivers"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("System Users"         , "SystemUsers"    ))
  VVpLvf.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVpLvf.append(("Uptime"          , "Uptime"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Host Name"         , "HostName"    ))
  VVpLvf.append(("MAC Address"         , "MACAddress"    ))
  VVpLvf.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVpLvf.append(("Network Status"        , "NetworkStatus"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Disk Usage"         , "VVxI4E"    ))
  VVpLvf.append(("Mount Points"         , "MountPoints"    ))
  VVpLvf.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVpLvf.append(("USB Devices"         , "USB_Devices"    ))
  VVpLvf.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVpLvf.append(("Directory Size"        , "DirectorySize"   ))
  VVpLvf.append(("Memory"          , "Memory"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVpLvf.append(("Running Processes"       , "RunningProcesses"  ))
  VVpLvf.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFwrVg(self, VVpLvf=VVpLvf, title="Device Information")
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC1Hzf)
   elif item == "VVsuNE"    : self.VVsuNE()
   elif item == "VVpsyX"   : self.VVpsyX()
   elif item == "VVuhfD"   : self.VVuhfD()
   elif item == "ScreenSize"    : FFWUy2(self, "Width\t: %s\nHeight\t: %s" % (FFGYXd()[0], FFGYXd()[1]))
   elif item == "Locale"     : self.VVperN()
   elif item == "Processor"    : self.VVQnJd()
   elif item == "OperatingSystem"   : FFTQP2(self, "uname -a"        )
   elif item == "drivers"     : self.VVWKEL()
   elif item == "SystemUsers"    : FFTQP2(self, "id"          )
   elif item == "LoggedInUsers"   : FFTQP2(self, "who -a"         )
   elif item == "Uptime"     : FFTQP2(self, "uptime"         )
   elif item == "HostName"     : FFTQP2(self, "hostname"        )
   elif item == "MACAddress"    : self.VVe16S()
   elif item == "NetworkConfiguration"  : FFTQP2(self, "ifconfig %s %s" % (FFb5eo("HWaddr", VV2SpG), FFb5eo("addr:", VVEdAx)))
   elif item == "NetworkStatus"   : FFTQP2(self, "netstat -tulpn"       )
   elif item == "VVxI4E"    : self.VVxI4E()
   elif item == "MountPoints"    : FFTQP2(self, "mount %s" % (FFb5eo(" on ", VVEdAx)))
   elif item == "FileSystemTable"   : FFTQP2(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFTQP2(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFTQP2(self, "blkid"         )
   elif item == "DirectorySize"   : FFTQP2(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVOfVR="Reading size ...")
   elif item == "Memory"     : FFTQP2(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVk1xQ()
   elif item == "RunningProcesses"   : FFTQP2(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFTQP2(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVI5XU()
   else         : self.close()
 def VVe16S(self):
  res = FF1wdX("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFWUy2(self, txt)
  else:
   FFTQP2(self, "ip link")
 def VVbCgQ(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFzFRs(cmd)
  return lines
 def VVQq5i(self, lines, headerRepl, widths, VVB5ih):
  VVKPkH = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVKPkH.append(parts)
  if VVKPkH and len(header) == len(widths):
   VVKPkH.sort(key=lambda x: x[0].lower())
   FF4eNC(self, None, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22, VVq8dH=True)
   return True
  else:
   return False
 def VVxI4E(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVbCgQ(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVB5ih = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVQq5i(lines, headerRepl, widths, VVB5ih)
  if not allOK:
   lines = FFzFRs(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FF97nD(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVJH5T:
     note = "\n%s" % FFXMyR("Green = Mounted Partitions", VVJH5T)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVEdAx
     elif line.endswith(mountList) : color = VVJH5T
     else       : color = VVsWXS
     txt += FFXMyR(line, color) + "\n"
    FFWUy2(self, txt + note)
   else:
    FFCwHk(self, "Not data from system !")
 def VVk1xQ(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVbCgQ(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVB5ih = (LEFT , CENTER, LEFT )
  allOK = self.VVQq5i(lines, headerRepl, widths, VVB5ih)
  if not allOK:
   FFTQP2(self, cmd)
 def VVperN(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFWUy2(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVWKEL(self):
  cmd = FFVqya(VVKI1q, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFTQP2(self, cmd)
  else : FFpJtk(self)
 def VVQnJd(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFTQP2(self, cmd)
 def VVI5XU(self):
  cmd = FFVqya(VVAvk3, "| grep secondstage")
  if cmd : FFTQP2(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFpJtk(self)
 def VVsuNE(self):
  c = VVJH5T
  VVcsAS = []
  VVcsAS.append((FFXMyR("Box Type"  , c), FFXMyR(self.VVixIr("boxtype").upper(), c)))
  VVcsAS.append((FFXMyR("Board Version", c), FFXMyR(self.VVixIr("board_revision") , c)))
  VVcsAS.append((FFXMyR("Chipset"  , c), FFXMyR(self.VVixIr("chipset")  , c)))
  VVcsAS.append((FFXMyR("S/N"   , c), FFXMyR(self.VVixIr("sn")    , c)))
  VVcsAS.append((FFXMyR("Version"  , c), FFXMyR(self.VVixIr("version")  , c)))
  VVsnDC   = []
  VVhiJx = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVhiJx = SystemInfo[key]
     else:
      VVsnDC.append((FFXMyR(str(key), VV7ect), FFXMyR(str(SystemInfo[key]), VV7ect)))
  except:
   pass
  if VVhiJx:
   VVmWe3 = self.VVtFKK(VVhiJx)
   if VVmWe3:
    VVmWe3.sort(key=lambda x: x[0].lower())
    VVcsAS += VVmWe3
  if VVsnDC:
   VVsnDC.sort(key=lambda x: x[0].lower())
   VVcsAS += VVsnDC
  if VVcsAS:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF4eNC(self, None, header=header, VVcsAS=VVcsAS, VVgyfO=widths, VVvE6h=22, VVq8dH=True)
  else:
   FFWUy2(self, "Could not read info!")
 def VVixIr(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFawFw(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVtFKK(self, mbDict):
  try:
   mbList = list(mbDict)
   VVcsAS = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVcsAS.append((FFXMyR(subject, VVEdAx), FFXMyR(value, VVEdAx)))
  except:
   pass
  return VVcsAS
 def VVpsyX(self):
  txt = self.VVxzc6("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVxzc6("/proc/bus/nim_sockets")
  if not txt: txt = self.VVCQt2()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFWUy2(self, txt)
 def VVCQt2(self):
  txt = ""
  VVC8uD = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVC8uD("Slot Name" , slot.getSlotName())
     txt += FFXMyR(slotName, VVEdAx)
     txt += VVC8uD("Description"  , slot.getFullDescription())
     txt += VVC8uD("Frontend ID"  , slot.frontend_id)
     txt += VVC8uD("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVxzc6(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFawFw(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFXMyR(line, VVEdAx)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVuhfD(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFWUy2(self, txt)
class CC1Hzf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVpLvf = []
  VVpLvf.append(("Settings (All)"   , "Settings_All"   ))
  VVpLvf.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVpLvf.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVpLvf.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVpLvf.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVpLvf.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVpLvf.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVpLvf.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFwrVg(self, VVpLvf=VVpLvf)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFTQP2(self, cmd                )
   elif item == "Settings_HotKeys"   : FFTQP2(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFTQP2(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFTQP2(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFTQP2(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFTQP2(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFTQP2(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFTQP2(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCaVL3(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVFBme, VVUD9R, VVbWjA, camCommand = FFW7TE()
  self.VVUD9R = VVUD9R
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVpLvf = []
  VVpLvf.append(("OSCam Files"        , "OSCamFiles"  ))
  VVpLvf.append(("NCam Files"        , "NCamFiles"  ))
  VVpLvf.append(("CCcam Files"        , "CCcamFiles"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVpLvf.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVpLvf.append(VVkUZg)
  if VVUD9R:
   if   "oscam" in VVUD9R : camName = "OSCam"
   elif "ncam"  in VVUD9R : camName = "NCam"
   VVpLvf.append((camName + " Info."      , "camInfo"   ))
   VVpLvf.append((camName + " Live Status"    , "camLiveStatus" ))
   VVpLvf.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVpLvf.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVpLvf.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFwrVg(self, VVpLvf=VVpLvf)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCok4x, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCok4x, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCok4x, "cccam"))
   elif item == "OSCamReaders"  : self.VVGUEz("os")
   elif item == "NSCamReaders"  : self.VVGUEz("n")
   elif item == "camInfo"   : FFJglf(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFihKW(self.session, CCFHNo.VVDXV9)
   elif item == "camLiveReaders" : FFihKW(self.session, CCFHNo.VVUcO6)
   elif item == "camLiveLog"  : FFihKW(self.session, CCFHNo.VVa2K4)
   else       : self.close()
 def VVGUEz(self, camPrefix):
  VVKPkH = self.VVQ8NL(camPrefix)
  if VVKPkH:
   VVKPkH.sort(key=lambda x: int(x[0]))
   if self.VVUD9R and self.VVUD9R.startswith(camPrefix):
    VVYVXl = ("Toggle State", self.VVbtgE, [camPrefix], "Changing State ...")
   else:
    VVYVXl = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVB5ih  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF4eNC(self, None, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22, VVYVXl=VVYVXl, VVO8ee=True)
 def VVQ8NL(self, camPrefix):
  readersFile = self.VVFBme + camPrefix + "cam.server"
  VVKPkH = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFawFw(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVKPkH.append((str(len(VVKPkH) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVKPkH:
    FFCwHk(self, "No readers found !")
  else:
   FFurlj(self, readersFile)
  return VVKPkH
 def VVbtgE(self, VVKvMM, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVFBme, camPrefix)
  readerState  = VVKvMM.VVtFdM(1)
  readerLabel  = VVKvMM.VVtFdM(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCaVL3.VVf1tq(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVKvMM.VV5aRa()
    FFCwHk(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVKPkH = self.VVQ8NL(camPrefix)
   if VVKPkH:
    VVKvMM.VV32hv(VVKPkH)
 @staticmethod
 def VVf1tq(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFawFw(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFCwHk(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFCwHk(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFurlj(SELF, confFile)
   return None
  if not iRequest:
   FFCwHk(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFCwHk(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFCwHk(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCok4x(Screen):
 def __init__(self, VVuL6k, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVFBme, VVUD9R, VVbWjA, camCommand = FFW7TE()
  if   VVuL6k == "ncam" : self.prefix = "n"
  elif VVuL6k == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVpLvf = []
  if self.prefix == "":
   VVpLvf.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVpLvf.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVpLvf.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVpLvf.append(("constant.cw"         , "x_constant_cw" ))
   VVpLvf.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVpLvf.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVpLvf.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVpLvf.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVpLvf.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVpLvf.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVpLvf.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVpLvf.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVpLvf.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVpLvf.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVpLvf.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFwrVg(self, VVpLvf=VVpLvf)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF8Zbg(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FF8Zbg(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FF8Zbg(self, self.VVFBme + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FF8Zbg(self, self.VVFBme + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVYgXE("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVYgXE("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVYgXE("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVYgXE("cam.provid"        )
   elif item == "x_cam_server"  : self.VVYgXE("cam.server"        )
   elif item == "x_cam_services" : self.VVYgXE("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVYgXE("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVYgXE("cam.user"        )
   elif item == "x_VVjtIv"   : pass
   elif item == "x_SoftCam_Key" : FF8Zbg(self, self.VVFBme + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FF8Zbg(self, self.VVFBme + "CCcam.cfg"    )
   elif item == "x_VVjtIv"   : pass
   elif item == "x_cam_log"  : FF8Zbg(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FF8Zbg(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FF8Zbg(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVYgXE(self, fileName):
  FF8Zbg(self, self.VVFBme + self.prefix + fileName)
class CCFHNo(Screen):
 VVDXV9  = 0
 VVUcO6 = 1
 VVa2K4 = 2
 def __init__(self, session, VVFBme="", VVUD9R="", VVbWjA="", VVuxCh=VVDXV9):
  self.skin, self.skinParam = FFjy7Y(VVxOjf, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVbWjA   = VVbWjA
  self.VVuxCh  = VVuxCh
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVFBme + VVUD9R + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVUD9R : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVFBme, self.camPrefix)
  if self.VVuxCh == self.VVDXV9:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVuxCh == self.VVUcO6:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFwrVg(self, self.Title, addScrollLabel=True)
  FFh33U(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVgdDB
  self.onShown.append(self.VVH8dW)
  self.onClose.append(self.onExit)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self["myLabel"].VVZF8s(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFgCHF(self)
  self.VVgdDB()
 def onExit(self):
  self.timer.stop()
 def VVcGA3(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVR7GN)
  except:
   self.timer.callback.append(self.VVR7GN)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFngIP(self, "Started", 1000)
 def VV4yxc(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVR7GN)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFngIP(self, "Stopped", 1000)
 def VVgdDB(self):
  if self.timerRunning:
   self.VV4yxc()
  else:
   self.VVcGA3()
   if self.VVuxCh == self.VVDXV9 or self.VVuxCh == self.VVUcO6:
    if self.VVuxCh == self.VVDXV9 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCaVL3.VVf1tq(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFXHmb(self.VVQsZO)
    else:
     self.close()
   else:
    self.VVXeRZ()
 def VVR7GN(self):
  if self.timerRunning:
   if   self.VVuxCh == self.VVDXV9 : self.VV3NcH()
   elif self.VVuxCh == self.VVUcO6 : self.VV3NcH()
   else            : self.VVXeRZ()
 def VVXeRZ(self):
  if fileExists(self.VVbWjA):
   fTime = FFSqAc(os.path.getmtime(self.VVbWjA))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVUIKF(), VVJPTL=VVHcSs)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVbWjA)
 def VVQsZO(self):
  self.VV3NcH()
 def VV3NcH(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFXMyR("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VViuIz))
   self.camWebIfErrorFound = True
   self.VV4yxc()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVuxCh == self.VVDXV9 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFXMyR("Error while parsing data elements !\n\nError = %s" % str(e), VVZapb)
   self.camWebIfErrorFound = True
   self.VV4yxc()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVHyZx(root)
  self["myLabel"].setText(txt, VVJPTL=VVHcSs)
  self["myBar"].setText("Last Update : %s" % FFRY1H())
 def VVHyZx(self, rootElement):
  def VVC8uD(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVuxCh == self.VVDXV9:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFXMyR(status, VVJH5T)
    else          : status = FFXMyR(status, VVZapb)
    txt += VVjtIv + "\n"
    txt += VVC8uD("Name"  , name)
    txt += VVC8uD("Description" , desc)
    txt += VVC8uD("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVC8uD("Protocol" , protocol)
    txt += VVC8uD("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFXMyR("Yes", VVJH5T)
    else    : enabTxt = FFXMyR("No", VVZapb)
    txt += VVjtIv + "\n"
    txt += VVC8uD("Label"  , label)
    txt += VVC8uD("Protocol" , protocol)
    txt += VVC8uD("Enabled" , enabTxt)
  return txt
 def VVUIKF(self):
  wordsDict = self.VV0kdb()
  color = [ VVEdAx, VV2SpG, VVJH5T, VVZapb, VV7ect, VVpduW]
  lines = FFzFRs("tail -n %d %s" % (100, self.VVbWjA))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VViuIz + line[:19] + VVsWXS + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVVF41 + line[ndx + 3:] + VVsWXS
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVEdAx + line[ndx + 8 : ndx1 + 4] + VVsWXS + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVsWXS)
   elif line.startswith("----") or ">>" in line:
    line = FFXMyR(line, VVEdAx)
   txt += line + "\n"
  return txt
 def VV0kdb(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFawFw(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCdlXH(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVpLvf = []
  VVpLvf.append(("Backup Channels"        , "VVzmxO"   ))
  VVpLvf.append(("Restore Channels"        , "Restore_Channels"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Backup SoftCAM Files"       , "VVQCKT" ))
  VVpLvf.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVpLvf.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVpLvf.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Backup Network Settings"      , "VViGZY"   ))
  VVpLvf.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVhYf3:
   VVpLvf.append(VVkUZg)
   VVpLvf.append((VViuIz + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVZaf1"   ))
   VVpLvf.append((VVJH5T + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVpLvf.append((VVJH5T + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVpLvf.append((VV7ect + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVpLvf.append((VV7ect + "Decode %s Crash Report"   % PLUGIN_NAME , "VVvn08" ))
  FFwrVg(self, VVpLvf=VVpLvf)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVzmxO"    : self.VVzmxO()
   elif item == "Restore_Channels"    : self.VVS0KF("channels_backup*.tar.gz", self.VVbzEd)
   elif item == "VVQCKT"   : self.VVQCKT()
   elif item == "Restore_SoftCAM_Files"  : self.VVS0KF("softcam_backup*.tar.gz", self.VVMzQa)
   elif item == "Backup_TunerDiSEqC"   : self.VV1pha("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVS0KF("tuner_backup*.backup", boundFunction(self.VVwkxS, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV1pha("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVS0KF("hotkey_fhdg17_backup*.backup", boundFunction(self.VVwkxS, "misc"))
   elif item == "VViGZY"    : self.VViGZY()
   elif item == "Restore_Network"    : self.VVS0KF("network_backup*.tar.gz", self.VV9I6a)
   elif item == "VVZaf1"     : FFRzxq(self, boundFunction(FFGw6o, self, boundFunction(CCdlXH.VVZaf1, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVGJaU(False)
   elif item == "createMyDeb"     : self.VVGJaU(True)
   elif item == "createMyTar"     : self.VVxS3S()
   elif item == "VVvn08"   : self.VVvn08()
 @staticmethod
 def VVZaf1(SELF):
  OBF_Path = VVjwdL + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVjwdL, VVT4M3, VVQkCM)
   if err : FFCwHk(SELF, err)
   else : FFWUy2(SELF, txt)
  else:
   FFurlj(SELF, OBF_Path)
 def VVGJaU(self, VVhHyb):
  OBF_Path = VVjwdL + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFCwHk(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVjwdL)
  os.system("mv -f %s %s" % (VVjwdL + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVjwdL + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVjwdL + "plugin.py"))
  self.session.openWithCallback(self.VVGJaU1, boundFunction(CCvBr3, path=VVjwdL, VVhHyb=VVhHyb))
 def VVGJaU1(self):
  os.system("mv -f %s %s" % (VVjwdL + "OBF/main.py"  , VVjwdL))
  os.system("mv -f %s %s" % (VVjwdL + "OBF/plugin.py" , VVjwdL))
 def VVvn08(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFCwHk(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFCwHk(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVPCtH("%s*.list" % path)
  if err:
   FFurlj(self, path + "*.list")
   return
  srcF, err = self.VVPCtH("%s*main_final.py" % path)
  if err:
   FFurlj(self, path + "*.final.py")
   return
  VVcsAS = []
  for f in files:
   f = os.path.basename(f)
   VVcsAS.append((f, f))
  FFBYrC(self, boundFunction(self.VVmv92, path, codF, srcF), VVpLvf=VVcsAS)
 def VVmv92(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFurlj(self, logF)
   else     : FFGw6o(self, boundFunction(self.VV0AKa, logF, codF, srcF))
 def VV0AKa(self, logF, codF, srcF):
  lst  = []
  lines = FFawFw(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFCwHk(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVF0HO(lst, logF, newLogF)
  totSrc  = self.VVF0HO(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFWUy2(self, txt)
 def VVPCtH(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVF0HO(self, lst, f1, f2):
  txt = FFItSN(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVxS3S(self):
  VVcsAS = []
  VVcsAS.append("%s%s" % (VVjwdL, "*.py"))
  VVcsAS.append("%s%s" % (VVjwdL, "*.png"))
  VVcsAS.append("%s%s" % (VVjwdL, "*.xml"))
  VVcsAS.append("%s"  % (VVmF17))
  FFoZ5e(self, VVcsAS, "%s_%s" % (PLUGIN_NAME, VVT4M3), addTimeStamp=False)
 def VVzmxO(self):
  path1 = VVonVf
  path2 = "/etc/tuxbox/"
  VVcsAS = []
  VVcsAS.append("%s%s" % (path1, "*.tv"))
  VVcsAS.append("%s%s" % (path1, "*.radio"))
  VVcsAS.append("%s%s" % (path1, "*list"))
  VVcsAS.append("%s%s" % (path1, "lamedb*"))
  VVcsAS.append("%s%s" % (path2, "*.xml"))
  FFoZ5e(self, VVcsAS, "channels_backup", addTimeStamp=True)
 def VVQCKT(self):
  VVcsAS = []
  VVcsAS.append("/etc/tuxbox/config/")
  VVcsAS.append("/usr/keys/")
  VVcsAS.append("/usr/scam/")
  VVcsAS.append("/etc/CCcam.cfg")
  FFoZ5e(self, VVcsAS, "softcam_backup", addTimeStamp=True)
 def VViGZY(self):
  VVcsAS = []
  VVcsAS.append("/etc/hostname")
  VVcsAS.append("/etc/default_gw")
  VVcsAS.append("/etc/resolv.conf")
  VVcsAS.append("/etc/wpa_supplicant*.conf")
  VVcsAS.append("/etc/network/interfaces")
  VVcsAS.append("/etc/enigma2/nameserversdns.conf")
  FFoZ5e(self, VVcsAS, "network_backup", addTimeStamp=True)
 def VVbzEd(self, fileName):
  if fileName:
   FFRzxq(self, boundFunction(self.VV4Q4p, fileName), "Overwrite current channels ?")
 def VV4Q4p(self, fileName):
  path = "%s%s" % (VV2Mhn, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCUNoh.VVRH5O()
   lamedb5File, diabled5File = CCUNoh.VV7Wpk()
   cmd = ""
   cmd += FFfUI2("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFfUI2("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFNkRg()
   if res == 0 : FFGBS4(self, "Channels Restored.")
   else  : FFCwHk(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFurlj(self, path)
 def VVMzQa(self, fileName):
  if fileName:
   FFRzxq(self, boundFunction(self.VVPwZy, fileName), "Overwrite SoftCAM files ?")
 def VVPwZy(self, fileName):
  fileName = "%s%s" % (VV2Mhn, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVjtIv
   note = "You may need to restart your SoftCAM."
   FFleJp(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFb5eo(note, VVEdAx), sep))
  else:
   FFurlj(self, fileName)
 def VV9I6a(self, fileName):
  if fileName:
   FFRzxq(self, boundFunction(self.VVwjcE, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVwjcE(self, fileName):
  fileName = "%s%s" % (VV2Mhn, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF0xy0(self,  cmd)
  else:
   FFurlj(self, fileName)
 def VVS0KF(self, pattern, callBackFunction, isTuner=False):
  title = FF7yjp()
  if pathExists(VV2Mhn):
   myFiles = iGlob("%s%s" % (VV2Mhn, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVcsAS = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVcsAS.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVgMyE = ("Sat. List", self.VVYTsR)
    else  : VVgMyE = None
    FFBYrC(self, callBackFunction, title=title, VVpLvf=VVcsAS, VVgMyE=VVgMyE)
   else:
    FFCwHk(self, "No files found in:\n\n%s" % VV2Mhn, title)
  else:
   FFCwHk(self, "Path not found:\n\n%s" % VV2Mhn, title)
 def VV1pha(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCsT2Q()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VV695b, filePrefix))
 def VV695b(self, filePrefix, result, retval):
  title = FF7yjp()
  if pathExists(VV2Mhn):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFCwHk(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VV2Mhn, filePrefix, FFi9KP())
    try:
     VVcsAS = str(result.strip()).split()
     if VVcsAS:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVcsAS:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVjtIv, FFXMyR(fName, VVEdAx), VVjtIv)
       FFWUy2(self, txt, title=title, VVJPTL=VVHcSs)
      else:
       FFCwHk(self, "File creation failed!", title)
     else:
      FFCwHk(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFfUI2("rm %s" % fName))
     FFCwHk(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFfUI2("rm %s" % fName))
     FFCwHk(self, "Error while writing file.")
  else:
   FFCwHk(self, "Path not found:\n\n%s" % VV2Mhn, title)
 def VVwkxS(self, mode, path):
  if path:
   path = "%s%s" % (VV2Mhn, path)
   if fileExists(path):
    lines = FFawFw(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFRzxq(self, boundFunction(self.VV7xJX, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF4fts(self, path, title=FF7yjp())
   else:
    FFurlj(self, path)
 def VV7xJX(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VV7ySt = []
  VV7ySt.append("echo -e 'Reading current settings ...'")
  VV7ySt.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VV7ySt.append("echo -e 'Preparing new settings ...'")
  VV7ySt.append(settingsLines)
  VV7ySt.append("echo -e 'Applying new settings ...'")
  VV7ySt.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFI0Sl(self, VV7ySt)
 def VVYTsR(self, VVupR7Obj, path):
  if not path:
   return
  path = VV2Mhn + path
  if not fileExists(path):
   FFurlj(self, path)
   return
  txt = FFItSN(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVcsAS  = []
   for item in satList:
    VVcsAS.append("%s\t%s" % (item[0], FFiKgb(item[1])))
   FFWUy2(self, VVcsAS, title="  Satellites List")
  else:
   FFCwHk(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCzUIl(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVpLvf = []
  VVpLvf.append(("Plugins Browser List"       , "VVYd1g"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVpLvf.append(("Remove Packages (show all)"     , "VVmTy9sAll"   ))
  VVpLvf.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Update List of Available Packages"   , "VVH6Ax"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Packaging Tool"        , "VVdbMh"    ))
  VVpLvf.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFwrVg(self, VVpLvf=VVpLvf)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVYd1g"   : self.VVYd1g()
   elif item == "pluginsDirList"    : self.VVpGmY()
   elif item == "downloadInstallPackages"  : FFGw6o(self, boundFunction(self.VVCRa1, 0, ""))
   elif item == "VVmTy9sAll"   : FFGw6o(self, boundFunction(self.VVCRa1, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFGw6o(self, boundFunction(self.VVCRa1, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVH6Ax"   : self.VVH6Ax()
   elif item == "VVdbMh"    : self.VVdbMh()
   elif item == "packagesFeeds"    : self.VVmflO()
   else          : self.close()
 def VVpGmY(self):
  extDirs  = FF5dqf(VVqVzQ)
  sysDirs  = FF5dqf(VVtoxO)
  VVcsAS  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVcsAS.append((item, VVqVzQ + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVcsAS.append((item, VVtoxO + item))
  if VVcsAS:
   VVcsAS = sorted(VVcsAS, key=lambda x: x[0].lower())
   VVGGJN = ("Package Info.", self.VViOZZ, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FF4eNC(self, None, header=header, VVcsAS=VVcsAS, VVgyfO=widths, VVvE6h=28, VVGGJN=VVGGJN)
  else:
   FFCwHk(self, "Nothing found!")
 def VViOZZ(self, VVKvMM, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVqVzQ) : loc = "extensions"
  elif path.startswith(VVtoxO) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVulJ9(package)
  else:
   FFCwHk(self, "No info!")
 def VVmflO(self):
  pkg = FFiS2t()
  if pkg : FFTQP2(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFpJtk(self)
 def VVYd1g(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVC8uD(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVjtIv + "\n"
    txt += VVC8uD("Number"   , str(c))
    txt += VVC8uD("Name"   , FFXMyR(str(p.name), VVEdAx))
    txt += VVC8uD("Path"  , p.path  )
    txt += VVC8uD("Description" , p.description )
    txt += VVC8uD("Icon"  , p.iconstr  )
    txt += VVC8uD("Wakeup Fnc" , p.wakeupfnc )
    txt += VVC8uD("NeedsRestart", p.needsRestart)
    txt += VVC8uD("Internal" , p.internal )
    txt += VVC8uD("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFWUy2(self, txt)
 def VVH6Ax(self):
  cmd = FFVqya(VVeME3, "")
  if cmd : FF0xy0(self, cmd, checkNetAccess=True)
  else : FFpJtk(self)
 def VVdbMh(self):
  pkg = FFiS2t()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFGBS4(self, txt)
 def VVCRa1(self, mode, grep, VVKvMM=None, title=""):
  if   mode == 0: cmd = FFVqya(VVAvk3    , grep)
  elif mode == 1: cmd = FFVqya(VVKI1q , grep)
  elif mode == 2: cmd = FFVqya(VVKI1q , grep)
  if not cmd:
   FFpJtk(self)
   return
  VVKPkH = FFzFRs(cmd)
  if not VVKPkH:
   if VVKvMM: VVKvMM.VV5aRa()
   FFCwHk(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVcsAS  = []
  for item in VVKPkH:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVcsAS.append((name, package, version))
  if mode > 0:
   extensions = FFzFRs("ls %s -l | grep '^d' | awk '{print $9}'" % VVqVzQ)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVcsAS:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVcsAS.append((name, VVqVzQ + item, "-"))
   systemPlugins = FFzFRs("ls %s -l | grep '^d' | awk '{print $9}'" % VVtoxO)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVcsAS:
      if item.lower() == row[0].lower():
       break
     else:
      VVcsAS.append((item, VVtoxO + item, "-"))
  if not VVcsAS:
   FFCwHk(self, "No packages found!")
   return
  if VVKvMM:
   VVcsAS.sort(key=lambda x: x[0].lower())
   VVKvMM.VV32hv(VVcsAS, title)
  else:
   widths = (20, 50, 30)
   VVYVXl = None
   VVmwc1 = None
   if mode == 0:
    VVKuXf = ("Install" , self.VVPvcd   , [])
    VVYVXl = ("Download" , self.VVf0Pi   , [])
    VVmwc1 = ("Filter"  , self.VVCjh3 , [])
   elif mode == 1:
    VVKuXf = ("Uninstall", self.VVmTy9, [])
   elif mode == 2:
    VVKuXf = ("Uninstall", self.VVmTy9, [])
    widths= (18, 57, 25)
   VVcsAS = sorted(VVcsAS, key=lambda x: x[0].lower())
   VVGGJN = ("Package Info.", self.VVLvlb, [])
   header   = ("Name" ,"Package" , "Version" )
   FF4eNC(self, None, header=header, VVcsAS=VVcsAS, VVgyfO=widths, VVvE6h=24, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVmwc1=VVmwc1, VVVkpg=self.lastSelectedRow
     , VVysAl="#22110011", VVkHTQ="#22191111", VVrOep="#22191111", VVjLvZ="#00003030", VV0jUQ="#00333333")
 def VVLvlb(self, VVKvMM, title, txt, colList):
  package = colList[1]
  self.VVulJ9(package)
 def VVCjh3(self, VVKvMM, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVpLvf = []
  VVpLvf.append(("All Packages", "all"))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVpLvf.append(VVkUZg)
  for word in words:
   VVpLvf.append((word, word))
  FFBYrC(self, boundFunction(self.VVQXqW, VVKvMM), VVpLvf=VVpLvf, title="Select Filter")
 def VVQXqW(self, VVKvMM, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFGw6o(VVKvMM, boundFunction(self.VVCRa1, 0, grep, VVKvMM, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVmTy9(self, VVKvMM, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVqVzQ, VVtoxO)):
   FFRzxq(self, boundFunction(self.VVXyy7, VVKvMM, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVpLvf = []
   VVpLvf.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVpLvf.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVpLvf.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFBYrC(self, boundFunction(self.VVnViT, VVKvMM, package), VVpLvf=VVpLvf)
 def VVXyy7(self, VVKvMM, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV2oWO)
  FF0xy0(self, cmd, VVfFKv=boundFunction(self.VV4MG3, VVKvMM))
 def VVnViT(self, VVKvMM, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVpb9g
   elif item == "remove_ForceRemove"  : cmdOpt = VVOUmA
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVH1Wq
   FFRzxq(self, boundFunction(self.VVZLrl, VVKvMM, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVZLrl(self, VVKvMM, package, cmdOpt):
  self.lastSelectedRow = VVKvMM.VVixla()
  cmd = FFHVrF(cmdOpt, package)
  if cmd : FF0xy0(self, cmd, VVfFKv=boundFunction(self.VV4MG3, VVKvMM))
  else : FFpJtk(self)
 def VV4MG3(self, VVKvMM):
  VVKvMM.cancel()
  FF9iJ5()
 def VVPvcd(self, VVKvMM, title, txt, colList):
  package  = colList[1]
  VVpLvf = []
  VVpLvf.append(("Install Package"         , "install_CheckVersion" ))
  VVpLvf.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVpLvf.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVpLvf.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFBYrC(self, boundFunction(self.VVRQHI, package), VVpLvf=VVpLvf)
 def VVRQHI(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVL2aE
   elif item == "install_ForceReinstall" : cmdOpt = VVU4WP
   elif item == "install_ForceDowngrade" : cmdOpt = VVZvVv
   elif item == "install_IgnoreDepends" : cmdOpt = VVv2YB
   FFRzxq(self, boundFunction(self.VVgA7T, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVgA7T(self, package, cmdOpt):
  cmd = FFHVrF(cmdOpt, package)
  if cmd : FF0xy0(self, cmd, VVfFKv=FF9iJ5, checkNetAccess=True)
  else : FFpJtk(self)
 def VVf0Pi(self, VVKvMM, title, txt, colList):
  package  = colList[1]
  FFRzxq(self, boundFunction(self.VV4Xzn, package), "Download Package ?\n\n%s" % package)
 def VV4Xzn(self, package):
  if FFZ5eQ():
   cmd = FFHVrF(VV6Y77, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFb5eo(success, VVJH5T))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFb5eo(fail, VVZapb))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF0xy0(self, cmd, VVBe0q=[VVZapb, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFpJtk(self)
  else:
   FFCwHk(self, "No internet connection !")
 def VVulJ9(self, package):
  infoCmd  = FFHVrF(VVq5HK, package)
  filesCmd = FFHVrF(VVCwg3, package)
  listInstCmd = FFVqya(VVKI1q, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFgvYp(VVEdAx)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFb5eo(notInst, VViuIz))
   cmd += "else "
   cmd +=   FFmD5M("System Info", VVEdAx)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFmD5M("Related Files", VVEdAx)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF1HQ0(self, cmd)
  else:
   FFpJtk(self)
class CCUNoh(Screen):
 VVEpjr  = 0
 VVnF5M = 1
 VVt9QQ  = 2
 VVleWL  = 3
 VVRg9n = 4
 VVpBvr = 5
 VVB61F = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV5GjJ = None
  self.lastfilterUsed  = None
  VVpLvf = self.VVeCy1()
  FFwrVg(self, VVpLvf=VVpLvf, title="Services/Channels")
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self["myMenu"].setList(self.VVeCy1())
  FFqSyv(self["myMenu"])
  FFVqF1(self)
 def VVeCy1(self):
  VVpLvf = []
  VVpLvf.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVpLvf.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVpLvf.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVpLvf.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVpLvf.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVpLvf.append(("Services with PIcons for the System"  , "VVNTP6"     ))
  VVpLvf.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVpLvf.append(VVkUZg)
  lamedbFile, disabledFile = CCUNoh.VVRH5O()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVpLvf.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVpLvf.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVpLvf.append(("Reset Parental Control Settings"   , "VVL54Q"    ))
  VVpLvf.append(("Delete Channels with no names"   , "VVANpO"    ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Reload Channels and Bouquets"    , "VVjxg3"      ))
  return VVpLvf
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFQEia(self)
   elif item == "currentServiceInfo"     : FFCpwr(self, fncMode=CCzK25.VVdY5Q)
   elif item == "TranspondersStats"     : FFGw6o(self, self.VVXUsy     )
   elif item == "lameDB_allChannels_with_refCode"  : FFGw6o(self, self.VVValQ )
   elif item == "lameDB_allChannels_with_tranaponder" : FFGw6o(self, self.VVaUnP)
   elif item == "lameDB_allChannels_with_details"  : FFGw6o(self, self.VVfhmL )
   elif item == "parentalControlChannels"    : FFGw6o(self, self.VV7Hni   )
   elif item == "showHiddenChannels"     : FFGw6o(self, self.VVlBMn     )
   elif item == "VVNTP6"     : FFGw6o(self, self.VVi1Fc     )
   elif item == "servicesWithMissingPIcons"   : FFGw6o(self, self.VVBp4C   )
   elif item == "enableHiddenChannels"     : self.VVMq6m(True)
   elif item == "disableHiddenChannels"    : self.VVMq6m(False)
   elif item == "VVL54Q"    : FFRzxq(self, self.VVL54Q, "Reset and Restart ?" )
   elif item == "VVANpO"    : FFGw6o(self, self.VVANpO)
   elif item == "VVjxg3"      : FFGw6o(self, boundFunction(CCUNoh.VVjxg3, self))
   else            : self.close()
 @staticmethod
 def VVjxg3(SELF):
  FFNkRg()
  FFGBS4(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVValQ(self):
  self.VV5GjJ = None
  self.lastfilterUsed  = None
  self.filterObj   = CCL9aY(self)
  VVKPkH = CCUNoh.VVFF4N(self, self.VVEpjr)
  if VVKPkH:
   VVKPkH.sort(key=lambda x: x[0].lower())
   VVUydg  = ("Zap"   , self.VVmF1r     , [])
   VVVLKj = (""    , self.VVaUrs   , [])
   VVGGJN = ("Options"  , self.VVznAB , [])
   VVYVXl = ("Current Service", self.VVz5c6 , [])
   VVmwc1 = ("Filter"   , self.VVnzoK  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVB5ih  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF4eNC(self, None, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22, VVUydg=VVUydg, VVVLKj=VVVLKj, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVmwc1=VVmwc1)
 def VVaUnP(self):
  self.VV5GjJ = None
  self.lastfilterUsed  = None
  self.filterObj   = CCL9aY(self)
  VVKPkH = CCUNoh.VVFF4N(self, self.VVnF5M)
  if VVKPkH:
   VVKPkH.sort(key=lambda x: x[0].lower())
   VVUydg  = ("Zap"   , self.VVmF1r      , [])
   VVVLKj = (""    , self.VVaUrs    , [])
   VVYVXl = ("Current Service", self.VVz5c6  , [])
   VVGGJN = ("Options"  , self.VVHrFn , [])
   VVmwc1 = ("Filter"   , self.VVD5fU  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVB5ih  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF4eNC(self, None, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22, VVUydg=VVUydg, VVVLKj=VVVLKj, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVmwc1=VVmwc1)
 def VVznAB(self, VVKvMM, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCmKBD(self, VVKvMM, 3)
  mSel.VVxiVU(servName, refCode, pcState, hidState)
 def VVHrFn(self, VVKvMM, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCmKBD(self, VVKvMM, 3)
  mSel.VVAT4S(servName, refCode)
 def VVLtwv(self, VVKvMM, refCode, isAddToBlackList):
  self.VV5GjJ = None
  self.lastfilterUsed  = None
  VVKvMM.VVfTev("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFGw6o(self, boundFunction(self.VVSpYX, VVKvMM, refCode))
  else:
   FFurlj(self, path)
 def VVBg7f(self, VVKvMM, refCode, isHide):
  self.VV5GjJ = None
  self.lastfilterUsed  = None
  VVKvMM.VVfTev("Changing state ...")
  if FFF8Oa(refCode):
   ret = FFQWXD(refCode, isHide)
   if ret : FFGw6o(self, boundFunction(self.VVSpYX, VVKvMM, refCode))
   else : FFCwHk(self, "Cannot Hide/Unhide this channel.")
  else:
   FFCwHk(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVSpYX(self, VVKvMM, refCode):
  VVKPkH = CCUNoh.VVFF4N(self, self.VVEpjr, VV1Pti=[3, [refCode], False])
  done = False
  if VVKPkH:
   data = VVKPkH[0]
   if data[3] == refCode:
    done = VVKvMM.VVbiRP(data)
  if not done:
   self.VV0Z69(VVKvMM, VVKvMM.VVuQPR(), self.VVEpjr)
  VVKvMM.VV5aRa()
 def VVnzoK(self, VVKvMM, title, txt, colList):
  self.filterObj.VV0aHE(1, VVKvMM, 2, boundFunction(self.VVMOKP, VVKvMM))
 def VVMOKP(self, VVKvMM, item):
  self.VVTag0(VVKvMM, item, 2, self.VVEpjr)
 def VVD5fU(self, VVKvMM, title, txt, colList):
  self.filterObj.VV0aHE(2, VVKvMM, 4, boundFunction(self.VVRL0U, VVKvMM))
 def VVRL0U(self, VVKvMM, item):
  self.VVTag0(VVKvMM, item, 4, self.VVnF5M)
 def VVnFIq(self, VVKvMM, title, txt, colList):
  self.filterObj.VV0aHE(0, VVKvMM, 4, boundFunction(self.VVeLIo, VVKvMM))
 def VVeLIo(self, VVKvMM, item):
  self.VVTag0(VVKvMM, item, 4, self.VVt9QQ)
 def VVTag0(self, VVKvMM, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVKvMM.VVtFdM(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV5GjJ = None
  else:
   words, asPrefix = CCL9aY.VVAGng(words)
   self.VV5GjJ = [col, words, asPrefix]
  if not words:
   FFngIP(VVKvMM, "Incorrect filter", 2000)
  else:
   VVKvMM.VVfTev("Reading Services ...")
   FFGw6o(self, boundFunction(self.VV0Z69, VVKvMM, title, mode))
 def VV0Z69(self, VVKvMM, title, mode):
  VVKPkH = CCUNoh.VVFF4N(self, mode, VV1Pti=self.VV5GjJ, VVC4in=False)
  if VVKPkH:
   VVKPkH.sort(key=lambda x: x[0].lower())
   VVKvMM.VV32hv(VVKPkH, title)
  else:
   VVKvMM.VV5aRa()
   FFngIP(VVKvMM, "Not found!", 1500)
 def VVDRjr(self, VVcsAS, VVUydg=None, VVVLKj=None, VVKuXf=None, VVYVXl=None, VVGGJN=None, VVmwc1=None):
  VVYVXl = ("Current Service", self.VVz5c6, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVB5ih = (LEFT  , LEFT  , CENTER, LEFT    )
  FF4eNC(self, None, header=header, VVcsAS=VVcsAS, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=24, VVUydg=VVUydg, VVVLKj=VVVLKj, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVmwc1=VVmwc1)
 def VVz5c6(self, VVKvMM, title, txt, colList):
  self.VVVGfe(VVKvMM)
 def VVZJEX(self, VVKvMM, title, txt, colList):
  self.VVVGfe(VVKvMM, True)
 def VVVGfe(self, VVKvMM, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVKvMM.VVQbQF(colDict, VVDTOG=True)
   else:
    VVKvMM.VVz9TN(3, refCode, True)
   return
  FFCwHk(self, "Colud not read current Reference Code !")
 def VVfhmL(self):
  self.VV5GjJ = None
  self.lastfilterUsed  = None
  self.filterObj   = CCL9aY(self)
  VVKPkH = CCUNoh.VVFF4N(self, self.VVt9QQ)
  if VVKPkH:
   VVKPkH.sort(key=lambda x: x[0].lower())
   VVVLKj = (""    , self.VVxALD , []      )
   VVYVXl = ("Current Service", self.VVZJEX  , []      )
   VVmwc1 = ("Filter"   , self.VVnFIq   , [], "Loading Filters ..." )
   VVUydg  = ("Zap"   , self.VVdLfK      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVB5ih  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF4eNC(self, None, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=24, VVUydg=VVUydg, VVVLKj=VVVLKj, VVYVXl=VVYVXl, VVmwc1=VVmwc1)
 def VVxALD(self, VVKvMM, title, txt, colList):
  refCode  = self.VVydWy(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFCpwr(self, fncMode=CCzK25.VVINNX, refCode=refCode, chName=chName, text=txt)
 def VVdLfK(self, VVKvMM, title, txt, colList):
  refCode = self.VVydWy(colList)
  FFlnjO(self, refCode)
 def VVmF1r(self, VVKvMM, title, txt, colList):
  FFlnjO(self, colList[3])
 def VVydWy(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVFF4N(SELF, mode, VV1Pti=None, VVC4in=True, VVwyJo=True):
  lamedbFile, disabledFile = CCUNoh.VVRH5O()
  if fileExists(lamedbFile):
   asPrefix = False
   if VV1Pti:
    filterCol = VV1Pti[0]
    filterWords = VV1Pti[1]
    asPrefix = VV1Pti[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCUNoh.VVEpjr:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFawFw(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCUNoh.VVnF5M:
    tp = CC2hod()
   VVKXvi, VV5RVA = FF1pIA()
   tagFound  = False
   if mode in (CCUNoh.VVpBvr, CCUNoh.VVB61F):
    VVKPkH = {}
   else:
    VVKPkH = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFPiv5(SELF):
      return None
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFkB7Z(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCUNoh.VVt9QQ:
        if sTypeInt in VVKXvi:
         STYPE = VV5RVA[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVKPkH.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVKPkH.append(tRow)
        else:
         VVKPkH.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCUNoh.VVpBvr:
         VVKPkH[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCUNoh.VVB61F:
         VVKPkH[chName] = refCode
        elif mode == CCUNoh.VVEpjr:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVKPkH.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVKPkH.append(tRow)
         else:
          VVKPkH.append(tRow)
        elif mode == CCUNoh.VVnF5M:
         if sTypeInt in VVKXvi:
          STYPE = VV5RVA[sTypeInt]
         freq, pol, fec, sr, syst = tp.VV6AfP(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVKPkH.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVKPkH.append(tRow)
         else:
          VVKPkH.append(tRow)
        elif mode == CCUNoh.VVleWL:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVKPkH.append((chName, chProv, sat, refCode))
        elif mode == CCUNoh.VVRg9n:
         VVKPkH.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVKPkH and VVC4in:
    FFCwHk(SELF, "No services found!")
   return VVKPkH
  else:
   if VVwyJo:
    FFurlj(SELF, lamedbFile)
   return None
 def VV7Hni(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFawFw(path)
   if lines:
    newRows  = []
    VVKPkH = CCUNoh.VVFF4N(self, self.VVRg9n)
    if VVKPkH:
     lines = set(lines)
     for item in VVKPkH:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVKPkH = newRows
      VVKPkH.sort(key=lambda x: x[0].lower())
      VVVLKj = ("", self.VVaUrs, [])
      VVUydg = ("Zap", self.VVmF1r, [])
      self.VVDRjr(VVcsAS=VVKPkH, VVUydg=VVUydg, VVVLKj=VVVLKj)
     else:
      FFWUy2(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVKPkH)))
   else:
    FFGBS4(self, "No hidden services.", FF7yjp())
  else:
   FFurlj(self, path)
 def VVlBMn(self):
  VVKPkH = CCUNoh.VVFF4N(self, self.VVleWL)
  if VVKPkH:
   if VVKPkH:
    VVKPkH.sort(key=lambda x: x[0].lower())
    VVVLKj = ("" , self.VVaUrs, [])
    VVUydg  = ("Zap", self.VVmF1r, [])
    self.VVDRjr(VVcsAS=VVKPkH, VVUydg=VVUydg, VVVLKj=VVVLKj)
   else:
    FFWUy2(self, "Lines\t: %d\nFound\t: %d\nLameDB\t: %d" % (len(lines), txt.count("\n"), len(VVKPkH)))
 def VVXUsy(self):
  totT, totC, totA, totS, totS2, satList = self.VVDT1h()
  txt = FFXMyR("Total Transponders:\n\n", VV7ect)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFXMyR("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV7ect)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFrrx4(item), satList.count(item))
  FFWUy2(self, txt)
 def VVDT1h(self):
  lamedbFile, disabledFile = CCUNoh.VVRH5O()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFPiv5(self):
      return 0, 0, 0, 0, 0, None
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFurlj(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVi1Fc(self):
  self.VVNTP6(True)
 def VVBp4C(self):
  self.VVNTP6(False)
 def VVNTP6(self, isWithPIcons):
  piconsPath = CCivOr.VVHoxR()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCivOr.VVXZs1(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVKPkH = CCUNoh.VVFF4N(self, self.VVRg9n)
    if VVKPkH:
     channels = []
     for (chName, chProv, sat, refCode) in VVKPkH:
      if not FFPiv5(self):
       return
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFtZ2p(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVKPkH)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVC8uD(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVC8uD("PIcons Path"  , piconsPath)
     txt += VVC8uD("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVC8uD("Total services" , totalServices)
     txt += VVC8uD("With PIcons"  , totalWithPIcons)
     txt += VVC8uD("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFWUy2(self, txt)
     else:
      VVVLKj     = (""      , self.VVaUrs , [])
      if isWithPIcons : VVmwc1 = ("Export Current PIcon", self.VVWBZY  , [])
      else   : VVmwc1 = None
      VVGGJN     = ("Statistics", FFWUy2, [txt])
      VVUydg      = ("Zap", self.VVmF1r, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVDRjr(VVcsAS=channels, VVUydg=VVUydg, VVVLKj=VVVLKj, VVGGJN=VVGGJN, VVmwc1=VVmwc1)
   else:
    FFCwHk(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFCwHk(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVaUrs(self, VVKvMM, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFCpwr(self, fncMode=CCzK25.VVINNX, refCode=refCode, chName=chName, text=txt)
 def VVWBZY(self, VVKvMM, title, txt, colList):
  png, path = CCivOr.VVdOMu(colList[3], colList[0])
  if path:
   CCivOr.VVC88Q(self, png, path)
 @staticmethod
 def VVRH5O():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VV7Wpk():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVMq6m(self, isEnable):
  lamedbFile, disabledFile = CCUNoh.VVRH5O()
  if isEnable and not fileExists(disabledFile):
   FFGBS4(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFCwHk(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFRzxq(self, boundFunction(self.VVLoNI, isEnable), "%s Hidden Channels ?" % word)
 def VVLoNI(self, isEnable):
  lamedbFile , disabledFile = CCUNoh.VVRH5O()
  lamedb5File, diabled5File = CCUNoh.VV7Wpk()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFNkRg()
  if res == 0 : FFGBS4(self, "Hidden List %s" % word)
  else  : FFCwHk(self, "Error while restoring:\n\n%s" % fileName)
 def VVL54Q(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFI0Sl(self, cmd)
 def VVANpO(self):
  lamedbFile, disabledFile = CCUNoh.VVRH5O()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFfUI2("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFawFw(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFfUI2("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFNkRg()
   FFWUy2(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFurlj(self, lamedbFile)
class CCzK25(Screen):
 VVdY5Q  = 0
 VVaUdk   = 1
 VVG8uG   = 2
 VVINNX    = 3
 VVNvcb    = 4
 VVnpVD   = 5
 VV6SoG   = 6
 VVcxY0    = 7
 VVnztO   = 8
 VV6jo5   = 9
 VVZUyY   = 10
 VVwhBy   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFjy7Y(VVxOjf, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVdY5Q)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFXMyR("%s\n", VVzRfn) % VVjtIv
  FFwrVg(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self["myLabel"].VVZF8s(textOutFile="chann_info")
  if   self.fncMode == self.VVdY5Q : fnc = self.VVNCHu_VVdY5Q
  elif self.fncMode == self.VVaUdk  : fnc = self.VVNCHu_VVdY5Q
  elif self.fncMode == self.VVG8uG  : fnc = self.VVNCHu_VVdY5Q
  elif self.fncMode == self.VVINNX  : fnc = self.VVNCHu_VVINNX
  elif self.fncMode == self.VVNvcb  : fnc = self.VVNCHu_VVNvcb
  elif self.fncMode == self.VVnpVD  : fnc = self.VVNCHu_VVnpVD
  elif self.fncMode == self.VV6SoG  : fnc = self.VVNCHu_VV6SoG
  elif self.fncMode == self.VVcxY0  : fnc = self.VVNCHu_VVcxY0
  elif self.fncMode == self.VVnztO  : fnc = self.VVNCHu_VVnztO
  elif self.fncMode == self.VV6jo5 : fnc = self.VVNCHu_VV6jo5
  elif self.fncMode == self.VVZUyY  : fnc = self.VVNCHu_VVZUyY
  elif self.fncMode == self.VVwhBy : fnc = self.VVNCHu_VVwhBy
  self["myLabel"].setText("\n   Reading Info ...")
  FFXHmb(fnc)
 def VVzDUm(self, err):
  self["myLabel"].setText(err)
  FF7zZI(self["myTitle"], "#22200000")
  FF7zZI(self["myBody"], "#22200000")
  self["myLabel"].FF7zZIColor("#22200000")
  self["myLabel"].VV5KUx()
 def VVNCHu_VVdY5Q(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  self.refCode = refCode
  self.VVm3EN(chName)
 def VVNCHu_VVINNX(self):
  self.VVm3EN(self.chName)
 def VVNCHu_VVNvcb(self):
  self.VVm3EN(self.chName)
 def VVNCHu_VVnpVD(self):
  self.VVm3EN(self.chName)
 def VVNCHu_VV6SoG(self):
  self.VVm3EN("Picon Info")
 def VVNCHu_VVcxY0(self):
  self.VVm3EN(self.chName)
 def VVNCHu_VVnztO(self):
  self.VVm3EN(self.chName)
 def VVNCHu_VV6jo5(self):
  self.VVm3EN(self.chName)
 def VVNCHu_VVZUyY(self):
  self.chUrl = self.refCode + self.callingSELF.VVqRzV(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVm3EN(self.chName)
 def VVNCHu_VVwhBy(self):
  self.VVm3EN(self.chName)
 def VVm3EN(self, title):
  self.VV54Zk(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVclU8(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFXMyR(self.VVKmN4(tUrl), VVsWXS)
  if not self.epg:
   epg = self.VVuL7n(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVUykE(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCivOr.VVdOMu(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVUykE(path)
  self.VVUAIA()
  self.VVXYWJ()
  self["myLabel"].setText(self.text, VVJPTL=VVifYP)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV5KUx(minHeight=minH)
 def VVXYWJ(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFfXHu(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVaC5X(FFfGUi(url))
  if epg:
   self.text += "\n" + FFcOuU("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVUAIA()
 def VVUAIA(self):
  if not self.piconShown and self.picUrl:
   path, err = FF3VVg(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VVUykE(path)
    if self.piconShown and self.refCode:
     self.VVsvtZ(path, self.refCode)
 def VVsvtZ(self, path, refCode):
  if path and fileExists(path) and os.system(FFfUI2("which ffmpeg")) == 0:
   pPath = CCivOr.VVHoxR()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFfUI2("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVUykE(self, path):
  if path and fileExists(path):
   err, w, h = self.VV6EfK(path)
   if not err:
    if h > w:
     self.VVldLz(self["myPicF"], w, h, True)
     self.VVldLz(self["myPic"] , w, h, False)
   allOK = FFbnvf(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVldLz(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VV6EfK(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFeABk(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV54Zk(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VVclU8(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFXMyR(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVC8uD(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFXMyR(state, VViuIz)
   txt += "State\t: %s\n" % state
  w = FFJfd1(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFJfd1(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = FFJfd1(info      , iServiceInformation.sAspect)
  if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : aspect = "4:3"
  else           : aspect = "16:9"
  txt += "Video Format\t: %s\n" % aspect
  txt += self.VVC8uD(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVC8uD(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVC8uD(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFXMyR("IPTV", VV7ect)
   txt += self.VVg88i(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVymsf(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CC2hod()
    tpTxt, namespace = tp.VVnW0N(refCode)
    del tp
    if tpTxt:
     txt += FFXMyR("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFXMyR("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVC8uD(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVC8uD(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVC8uD(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVC8uD(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVC8uD(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVC8uD(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVC8uD(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVC8uD(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVC8uD(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 def VVC8uD(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFJfd1(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVegD5(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVegD5(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVymsf(self, refCode, iptvRef, chName):
  refCode = FFdy9m(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFItSN(VVonVf + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFItSN(VVonVf + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVcsAS = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVonVf + item
   if fileExists(path):
    txt = FFItSN(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVcsAS.append(bName)
  txt = self.Sep
  if VVcsAS:
   if len(VVcsAS) == 1:
    txt += "%s\t: %s\n" % (FFXMyR("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVcsAS[0])
   else:
    txt += FFXMyR("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVcsAS):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVuL7n(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVoTKb(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVoTKb(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVoTKb(event, 0)
     except:
      pass
  return epg
 def VVoTKb(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FFXMyR(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FFSqAc(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFSqAc(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFP20u(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFP20u(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFP20u(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FFXMyR(evShort, VVsWXS)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFXMyR(evDesc , VVsWXS)
    if txt:
     txt = FFXMyR("\n%s\n%s Event:\n%s\n" % (VVjtIv, ("Current", "Next")[evNum], VVjtIv), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVg88i(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFvanf(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   txt += "\n"
   if not VVzipJ:
    decodedUrl = self.VVKmN4(decodedUrl)
   txt += FFXMyR("URL:", VV7ect) + "\n%s\n" % decodedUrl
  else:
   txt = "\n"
   txt += FFXMyR("Reference:", VV7ect) + "\n%s\n" % refCode
  return txt
 def VVKmN4(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url.replace("%3a", ":").strip()
 def VVaC5X(self, decodedUrl):
  if not FFZ5eQ():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCDch1.VVaZZX(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCDch1.VV4gvw(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVqMpd(tDict)
   elif uType == "movie" : epg, picUrl = self.VV5KQi(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVqMpd(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCDch1.VVdfFW(item, "title"    , is_base64=True )
     lang    = CCDch1.VVdfFW(item, "lang"         ).upper()
     description   = CCDch1.VVdfFW(item, "description"  , is_base64=True )
     start_timestamp  = CCDch1.VVdfFW(item, "start_timestamp" , isDate=True  )
     stop_timestamp  = CCDch1.VVdfFW(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCDch1.VVdfFW(item, "stop_timestamp"       )
     now_playing   = CCDch1.VVdfFW(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVVF41, ""
      else     : color, txt = VViuIz , "    (CURRENT EVENT)"
      epg += FFXMyR("_" * 32 + "\n", VVzRfn)
      epg += FFXMyR("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FFXMyR(description, VVsWXS)
      evNum += 1
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VV5KQi(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCDch1.VVdfFW(item, "movie_image" )
    genre  = CCDch1.VVdfFW(item, "genre"   ) or "-"
    plot  = CCDch1.VVdfFW(item, "plot"   ) or "-"
    cast  = CCDch1.VVdfFW(item, "cast"   ) or "-"
    rating  = CCDch1.VVdfFW(item, "rating"   ) or "-"
    director = CCDch1.VVdfFW(item, "director"  ) or "-"
    releasedate = CCDch1.VVdfFW(item, "releasedate" ) or "-"
    duration = CCDch1.VVdfFW(item, "duration"  ) or "-"
    try:
     lang = CCDch1.VVdfFW(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFXMyR(cast, VVsWXS)
    epg += "Plot:\n%s"    % FFXMyR(plot, VVsWXS)
   except:
    pass
  return epg, movie_image
class CCKib0():
 def __init__(self):
  self.VV2XAl  = ""
  self.VV3KFC   = ""
  self.VVbEeH  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV12Lj(self, url, mac, VVDTOG=True):
  self.VV2XAl = ""
  self.VV3KFC  = ""
  self.VVbEeH = ""
  host = self.VVut6X(url)
  if not host:
   if VVDTOG:
    self.VVDTOGor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVfapl(mac)
  if not host:
   if VVDTOG:
    self.VVDTOGor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VV2XAl = host
  self.VV3KFC  = mac
  self.VVbEeH = ""
  return True
 def VVUNic(self):
  res, err = self.VVIWbx(self.VV2XAl, useCookies=False)
  if err:
   self.VVDTOGor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVIWbx(newUrl, res.cookies)
   if err:
    self.VVDTOGor(err, "URL Redirection")
    return False
   else:
    host = self.VVut6X(newUrl)
    if not host:
     self.VVDTOGor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VV2XAl = host
  token, profile = self.VV7ERC()
  if not token:
   return False
  return True
 def VVut6X(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VVfapl(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV7ERC(self, VVDTOG=True):
  try:
   token = self.VVprPG()
   if token:
    self.VVbEeH = token
   else:
    if VVDTOG:
     self.VVDTOGor("Could not get Token from server !")
    return "", ""
   return token, self.VVWQUl()
  except:
   return "", ""
 def VVprPG(self):
  token  = ""
  res, err = self.VVIWbx(self.VVfvnt())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCDch1.VVdfFW(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVWQUl(self):
  res, err = self.VVIWbx(self.VVXYyn())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVYNil(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVwAvp()
  if len(rows) < 10:
   rows = self.VVFgzO()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VV2XAl ))
   rows.append(("MAC (from URL)" , self.VV3KFC ))
   rows.append(("Token"   , self.VVbEeH ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VV3KFC ))
   rows.append(("2", self.colored_server, "Host" , self.VV2XAl ))
   rows.append(("2", self.colored_server, "Token" , self.VVbEeH ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVnW7l(self):
  token, profile = self.VV7ERC()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVZjOd()
  res, err = self.VVIWbx(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCDch1.VVdfFW(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVwAvp(self):
  m3u_Url = self.VVnW7l()
  rows = []
  if m3u_Url:
   res, err = self.VVIWbx(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFSqAc(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFSqAc(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVFgzO(self):
  token, profile = self.VV7ERC()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF6BxB(val): val = FFKrOM(val.decode("UTF-8"))
     else     : val = self.VV3KFC
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFSqAc(int(parts[1]))
      if parts[2] : ends = FFSqAc(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFSqAc(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVqRzV(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VV9IIC(mode, chCm, epNum, epId)
  token, profile = self.VV7ERC(VVDTOG=False)
  if not token:
   return ""
  res, err = self.VVIWbx(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCDch1.VVdfFW(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVU8qO(self):
  return self.VV2XAl + "/server/load.php?"
 def VVfvnt(self):
  return self.VVU8qO() + "type=stb&action=handshake&token=&mac=%s" % self.VV3KFC
 def VVXYyn(self):
  return self.VVU8qO() + "type=stb&action=get_profile"
 def VVcAbu(self, mode):
  url = self.VVU8qO() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVgrKp(self, catID):
  return self.VVU8qO() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVDNHn(self, mode, catID, page):
  url = self.VVU8qO() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVZtcq(self, mode, searchName, page):
  return self.VVU8qO() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VV2bkP(self, mode, catID):
  return self.VVU8qO() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VV9IIC(self, mode, chCm, serCode, serId):
  url = self.VVU8qO() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVZjOd(self):
  return self.VVU8qO() + "type=itv&action=create_link"
 def VVR72M(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVnzNz(catID, stID, chNum)
  query = self.VVGMU3(mode, FF1sXm(host), FF1sXm(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVGMU3(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VViI3l(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVGMU3(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFKrOM(host)
  mac   = FFKrOM(mac)
  valid = False
  if self.VVut6X(playHost) and self.VVut6X(host) and self.VVut6X(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVIWbx(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VV3KFC, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVbEeH:
    headers["Authorization"] = "Bearer %s" % self.VVbEeH
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVMIai(host, mac, tType, action, keysList=[]):
  myPortal = CCKib0()
  ok = myPortal.VV12Lj(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VV7ERC()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVIWbx(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVbVZw(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVbVZw(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVDTOGor(self, err, title="Portal Browser"):
  FFCwHk(self, str(err), title=title)
 def VVg8wU(self, mode):
  if   mode in ("itv"  , CCDch1.VVh2Rm) : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCDch1.VVwZ3J) : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCDch1.VVkv9o): return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode == "series2"           : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else               : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVTi9b(self, mode):
  if   mode in ("itv"  , CCDch1.VVh2Rm , CCDch1.VVOqiS)  : return "Live"
  elif mode in ("vod"  , CCDch1.VVwZ3J , CCDch1.VVZ3z9)  : return "VOD"
  elif mode in ("series" , CCDch1.VVkv9o , CCDch1.VVN9eL) : return "Series"
  else                          : return "IPTV"
 def VVwbee(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVTi9b(mode), searchName)
 def VVbUIw(self):
  VVpLvf = []
  VVpLvf.append(("Live"    , "live"  ))
  VVpLvf.append(("VOD"    , "vod"   ))
  VVpLvf.append(("Series "   , "series"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Account Info." , "accountInfo" ))
  return VVpLvf
class CCuTLY(CCKib0):
 def __init__(self):
  CCKib0.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VV70uK(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VViI3l(decodedUrl)
  if valid:
   if self.VV12Lj(host, mac, VVDTOG=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVKs0E(self, passedSELF=None, isFromSession=False):
  chUrl = self.VVqRzV(self.mode, self.chCm, self.epNum, self.epId)
  if not chUrl:
   return
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVoPLq(self.iptvRef, newIptvRef)
   if passedSELF:
    FFlnjO(passedSELF, newIptvRef, VV9Blm=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFlnjO(self, newIptvRef, VV9Blm=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVoPLq(self, oldCode, newCode):
  bPath = FFqamm()
  if bPath:
   txt = FFItSN(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFNkRg()
    return True
  return False
class CCrPu7(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFjy7Y(WINDOW_DUMMY, 10, 10, 50, 30, 20, "#22002020", "#22001122", 30)
  self.session = session
  FFwrVg(self, "")
  self.close()
class CCgFHw(CCuTLY):
 def __init__(self, passedSession):
  CCuTLY.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={ iPlayableService.evEnd: self.VVZqgt})
  except:
   pass
 def VVZqgt(self):
  try:
   t = self.timer1.timeout.connect(self.VV5Eab)
  except:
   self.timer1.callback.append(self.VV5Eab)
  self.timer1.start(1000, True)
 def VV5Eab(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VV70uK(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCwbgh.PLAYER_INSTANCE:
       self.VVKs0E(self.passedSession, isFromSession=True)
class CCEiXp():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex" , "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
 def VVLgnx(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(r"(b[-]*e[-]*I[-]*N)", r"beIN", name, flags=IGNORECASE).strip()
  if CCDch1.VVSZN6(name):
   return CCDch1.VVPi7p(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVloRx(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VV3H72(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVju22(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCjino(CCKib0):
 def __init__(self):
  CCKib0.__init__(self)
 def VVrVGD(self):
  try:
   import requests
   FFGw6o(self, self.VVcyrR, title="Searching ...")
  except:
   FFRzxq(self, self.VVJ2ZK, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVo7lg(self, winSession, url, mac):
  if self.VV12Lj(url, mac):
   FFGw6o(winSession, self.VVUXdk, title="Checking Server ...")
  else:
   FFCwHk(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVJ2ZK(self):
  from sys import version_info
  cmdUpd = FFVqya(VVeME3, "")
  if cmdUpd:
   cmdInst = FFHVrF(VVL2aE, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FF0xy0(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFpJtk(self)
 def VVcyrR(self):
  lines = FFzFRs('find / %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % FFphRM(1))
  if lines:
   lines.sort()
   VVpLvf = []
   for line in lines:
    VVpLvf.append((line, line))
   OKBtnFnc = self.VVMAfb
   FFBYrC(self, None, title="Select Portals File", VVpLvf=VVpLvf, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFCwHk(self, "No portal files found\n\nFile example : portalxx.txt \n(separate URL and MAC with space/tab/comma)")
 def VVMAfb(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CCLTq8, barTheme=CCLTq8.VVq2B4
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVGgU7, path)
       , VVcWME = boundFunction(self.VVd9tb, menuInstance, path))
 def VVGgU7(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  lines  = FFawFw(path)
  progBarObj.VVINqi(len(lines))
  progBarObj.VVRQiU = []
  import time
  for lineNum, line in enumerate(lines, start=1):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVsgjw(1)
   iSleep(0.0001)
   line = line.strip()
   if not line or "password" in line:
    continue
   span = iSearch(urlMacPatt, line, IGNORECASE)
   if span:
    c  += 1
    subj = span.group(1).strip() or "-"
    url  = span.group(2).strip()
    mac  = span.group(3).strip().replace(" ", "").upper()
    info = span.group(4).strip() or "-"
    host = self.VVut6X(url)
    mac  = self.VVfapl(mac)
    if host and mac and progBarObj:
     progBarObj.VVRQiU.append((str(c), str(lineNum), subj, host, mac, info))
    url  = ""
    continue
   if not url:
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if not span:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
   else:
    span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     mac  = span.group(2).strip().replace(" ", "").upper()
     info = span.group(3).strip() or "-"
     host = self.VVut6X(url)
     mac  = self.VVfapl(mac)
     if host and mac and not mac.startswith("AC") and progBarObj:
      progBarObj.VVRQiU.append((str(c), str(lineNum), "-", host, mac, info))
    else:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1).split(" ")[0]
 def VVd9tb(self, menuInstance, path, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVRQiU:
   VVKuXf  = ("Home Menu", FF2k7C, [])
   VVmwc1  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVGGJN = ("Edit File" , boundFunction(self.VVMns9, path) , [])
   VVUydg  = ("Select"  , self.VVo7lg_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVB5ih  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVKvMM = FF4eNC(self, None, title=title, header=header, VVcsAS=VVRQiU, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22, VVUydg=VVUydg, VVKuXf=VVKuXf, VVGGJN=VVGGJN, VVmwc1=VVmwc1, VVysAl="#0a001111", VVkHTQ="#0a001122", VVrOep="#0a001122", VVjLvZ="#00000000", VVO8ee=True, searchCol=1)
   if not VVPNFn:
    FFngIP(VVKvMM, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVPNFn:
    FFCwHk(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVo7lg_fromMacFiles(self, VVKvMM, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVo7lg(VVKvMM, url, mac)
 def VVMns9(self, path, VVKvMM, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC9jZC(self, path, VVcWME=boundFunction(self.VVnu1D, VVKvMM), curRowNum=rowNum)
  else    : FFurlj(self, path)
 def VVnu1D(self, VVKvMM, fileChanged):
  if fileChanged:
   VVKvMM.cancel()
 def VVbakG(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFKrOM(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVUXdk(self):
  if self.VVUNic():
   VVpLvf  = self.VVbUIw()
   OKBtnFnc = self.VVwN7d
   VVFOel = ("Home Menu", FF2k7C)
   FFBYrC(self, None, title="Portal Resources (MAC=%s)" % self.VV3KFC, VVpLvf=VVpLvf, OKBtnFnc=OKBtnFnc, VVFOel=VVFOel)
 def VVwN7d(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFGw6o(menuInstance, boundFunction(self.VVFfDF, mode), title="Reading Categories ...")
   else : FFGw6o(menuInstance, boundFunction(self.VVUfx3, menuInstance, title), title="Reading Account ...")
 def VVUfx3(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVYNil(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV3KFC)
  VVKuXf  = ("Home Menu" , FF2k7C, [])
  if totCols == 2:
   VVmwc1 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVmwc1 = ("Other Info." , boundFunction(self.VVt9Gz, menuInstance) , [])
  FF4eNC(self, None, title=title, header=header, VVcsAS=rows, VVgyfO=widths, VVvE6h=26, VVKuXf=VVKuXf, VVmwc1=VVmwc1, VVysAl="#0a00292B", VVkHTQ="#0a002126", VVrOep="#0a002126", VVjLvZ="#00000000", searchCol=searchCol)
 def VVt9Gz(self, menuInstance, VVKvMM, title, txt, colList):
  VVKvMM.cancel()
  FFGw6o(menuInstance, boundFunction(self.VVUfx3, menuInstance, title, forceMoreInfo=True), title="Reading Account ...")
 def VVFfDF(self, mode):
  token, profile = self.VV7ERC()
  if not token:
   return
  res, err = self.VVIWbx(self.VVcAbu(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCEiXp()
     chList = tDict["js"]
     for item in chList:
      Id   = CCDch1.VVdfFW(item, "id"       )
      Title  = CCDch1.VVdfFW(item, "title"      )
      censored = CCDch1.VVdfFW(item, "censored"     )
      Title = processChanName.VVloRx(Title)
      if Title and not Title.strip().lower() == "all":
       list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVTi9b(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU(mode)
   mName = self.VVTi9b(mode)
   VVUydg   = ("Show Channels"  , boundFunction(self.VVYGdh, mode) , [])
   VVKuXf  = ("Home Menu"   , FF2k7C         , [])
   if mode in ("vod", "series"):
    VVGGJN = ("Find in %s" % mName , boundFunction(self.VVmu7w, mode), [])
   else:
    VVGGJN = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FF4eNC(self, None, title=title, header=header, VVcsAS=list, VVgyfO=widths, VVvE6h=30, VVKuXf=VVKuXf, VVGGJN=VVGGJN, VVUydg=VVUydg, VVysAl=VVysAl, VVkHTQ=VVkHTQ, VVrOep=VVrOep, VVjLvZ=VVjLvZ)
  else:
   FFCwHk(self, "Could not get Categories from server!", title=title)
 def VVisxv(self, mode, VVKvMM, title, txt, colList):
  FFGw6o(VVKvMM, boundFunction(self.VVzuaC, mode, VVKvMM, title, txt, colList), title="Downloading ...")
 def VVzuaC(self, mode, VVKvMM, title, txt, colList):
  token, profile = self.VV7ERC()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVIWbx(self.VVgrKp(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCDch1.VVdfFW(item, "id"    )
      actors   = CCDch1.VVdfFW(item, "actors"   )
      added   = CCDch1.VVdfFW(item, "added"   )
      age    = CCDch1.VVdfFW(item, "age"   )
      category_id  = CCDch1.VVdfFW(item, "category_id" )
      description  = CCDch1.VVdfFW(item, "description" )
      director  = CCDch1.VVdfFW(item, "director"  )
      genres_str  = CCDch1.VVdfFW(item, "genres_str"  )
      name   = CCDch1.VVdfFW(item, "name"   )
      path   = CCDch1.VVdfFW(item, "path"   )
      screenshot_uri = CCDch1.VVdfFW(item, "screenshot_uri" )
      series   = CCDch1.VVdfFW(item, "series"   )
      cmd    = CCDch1.VVdfFW(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVUydg  = ("Play"  , boundFunction(self.VVoPy9, mode, False)      , [])
   VVVLKj = (""   , boundFunction(self.VVFc72, mode)      , [])
   VVKuXf = ("Home Menu" , FF2k7C                , [])
   VVYVXl = ("Download PIcons" , boundFunction(self.VV11Qp, mode)      , [])
   VVGGJN = ("Add ALL to Bouquet" , boundFunction(self.VVEz9L, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVB5ih  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF4eNC(self, None, title=seriesName, header=header, VVcsAS=list, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=26, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVUydg=VVUydg, VVVLKj=VVVLKj, VVysAl="#0a00292B", VVkHTQ="#0a002126", VVrOep="#0a002126", VVjLvZ="#00000000")
  else:
   FFCwHk(self, "Could not get Episodes from server!", title=seriesName)
 def VVmu7w(self, mode, VVKvMM, title, txt, colList):
  VVpLvf = []
  VVpLvf.append(("Keyboard"  , "manualEntry"))
  VVpLvf.append(("From Filter" , "fromFilter"))
  FFBYrC(self, boundFunction(self.VVSdmP, VVKvMM, mode), title="Input Type", VVpLvf=VVpLvf, width=400)
 def VVSdmP(self, VVKvMM, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFQYeU(self, boundFunction(self.VV3smb, VVKvMM, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCL9aY(self)
    filterObj.VVjegd(boundFunction(self.VV3smb, VVKvMM, mode))
 def VV3smb(self, VVKvMM, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVwbee(mode, searchName)
   if len(searchName) < 3:
    FFCwHk(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCEiXp()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VV3H72([searchName]):
     FFCwHk(self, processChanName.VVju22(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVDvgF(mode, searchName, "", searchName)
 def VVYGdh(self, mode, VVKvMM, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVDvgF(mode, bName, catID, "")
 def VVDvgF(self, mode, bName, catID, searchName):
  self.session.open(CCLTq8, barTheme=CCLTq8.VVWaxI
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVrwGU, mode, bName, catID, searchName)
      , VVcWME = boundFunction(self.VV9dNk, mode, bName, catID, searchName))
 def VV9dNk(self, mode, bName, catID, searchName, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVwbee(mode, searchName)
  else   : title = "%s : %s" % (self.VVTi9b(mode), bName)
  if VVRQiU:
   if mode == "series":
    VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU("series2")
    VVUydg  = ("Episodes", boundFunction(self.VVisxv, mode) , [])
    VVYVXl = None
    VVGGJN = None
   else:
    VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU("")
    VVUydg  = ("Play"    , boundFunction(self.VVoPy9, mode, False)   , [])
    VVYVXl = ("Download PIcons" , boundFunction(self.VV11Qp, mode)     , [])
    VVGGJN = ("Add ALL to Bouquet" , boundFunction(self.VVEz9L, mode, bName) , [])
   VVVLKj = (""      , boundFunction(self.VVjeem, mode)    , [])
   VVKuXf = ("Home Menu"    , FF2k7C             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVB5ih  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVKvMM = FF4eNC(self, None, title=title, header=header, VVcsAS=VVRQiU, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=26, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVUydg=VVUydg, VVVLKj=VVVLKj, VVysAl=VVysAl, VVkHTQ=VVkHTQ, VVrOep=VVrOep, VVjLvZ=VVjLvZ, VVO8ee=True, searchCol=1)
   if not VVPNFn:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVKvMM.VVS9No(VVKvMM.VVuQPR() + tot)
    if threadErr: FFngIP(VVKvMM, "Error while reading !", 2000)
    else  : FFngIP(VVKvMM, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFCwHk(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFCwHk(self, "Could not get list from server !", title=title)
 def VVjeem(self, mode, VVKvMM, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFCpwr(self, fncMode=CCzK25.VVwhBy, portalHost=self.VV2XAl, portalMac=self.VV3KFC, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVCyC4(mode, VVKvMM, title, txt, colList)
 def VVFc72(self, mode, VVKvMM, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFXMyR(colList[10], VVsWXS)
  txt += "Description:\n%s" % FFXMyR(colList[11], VVsWXS)
  self.VVCyC4(mode, VVKvMM, title, txt, colList)
 def VVCyC4(self, mode, VVKvMM, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1NCU(mode, colList)
  refCode, chUrl = self.VVR72M(self.VV2XAl, self.VV3KFC, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFCpwr(self, fncMode=CCzK25.VVZUyY, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVrwGU(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VV7ERC()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVRQiU, total_items, max_page_items, err = self.VVeIst(mode, catID, 1, 1, searchName)
   progBarObj.VVsgjw(max_page_items)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVRQiU and total_items > -1 and max_page_items > -1:
    progBarObj.VVINqi(total_items)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVeIst(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VV102L()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVRQiU += list
      progBarObj.VVsgjw(len(list))
  except:
   pass
 def VVeIst(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url =self.VVZtcq(mode, searchName, page)
  else   : url =self.VVDNHn(mode, catID, page)
  res, err = self.VVIWbx(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVW4h2(CCDch1.VVdfFW(item, "total_items" ))
     max_page_items = self.VVW4h2(CCDch1.VVdfFW(item, "max_page_items" ))
     processChanName = CCEiXp()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCDch1.VVdfFW(item, "id"    )
      name   = CCDch1.VVdfFW(item, "name"   )
      tv_genre_id  = CCDch1.VVdfFW(item, "tv_genre_id" )
      number   = CCDch1.VVdfFW(item, "number"   ) or str(counter)
      logo   = CCDch1.VVdfFW(item, "logo"   )
      screenshot_uri = CCDch1.VVdfFW(item, "screenshot_uri" )
      cmd    = CCDch1.VVdfFW(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVLgnx(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVEz9L(self, mode, bName, VVKvMM, title, txt, colList):
  FFGw6o(VVKvMM, boundFunction(self.VV46gt, mode, bName, VVKvMM, title, txt, colList), title="Adding Channels ...")
 def VV46gt(self, mode, bName, VVKvMM, title, txt, colList):
  bNameFile = CCDch1.VVUS5c(bName)
  num  = 0
  path = VVonVf + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVonVf + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVKvMM.VV3tvF():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1NCU(mode, row)
    refCode, chUrl = self.VVR72M(self.VV2XAl, self.VV3KFC, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFwsb7(os.path.basename(path))
  self.VVKs6d(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVW4h2(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVoPy9(self, mode, fromPlayer, VVKvMM, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1NCU(mode, colList)
  refCode, chUrl = self.VVR72M(self.VV2XAl, self.VV3KFC, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VV10Ie(mode, VVKvMM, chUrl)
  elif self.VVSZN6(chName):
   FFngIP(VVKvMM, "This is a marker!", 300)
  else:
   FFGw6o(VVKvMM, boundFunction(self.VV10Ie, mode, VVKvMM, chUrl), title="Playing ...")
 def VV10Ie(self, mode, VVKvMM, chUrl):
  FFlnjO(self, chUrl, VV9Blm=False)
  self.session.open(CCwbgh, portalTableParam=(self, VVKvMM, mode))
 def VV1NCU(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCDch1(Screen, CCjino):
 VV1uhe = 0
 VVd55n = 1
 VVo5Vl = 2
 VV6O3N = 3
 VVi1pE  = 4
 VVWniL  = 5
 VV6SHX  = 6
 VVOXQG  = 7
 VVLiXC   = 8
 VVnaCh  = 9
 VVwlSH  = 10
 VVFnIO  = 11
 VVAZC0  = 12
 VVjcxo   = 13
 VVIWLp   = 14
 VVC1W3   = 15
 VVxdox   = 16
 VVtR11   = 17
 VVeCQk    = 0
 VVh2Rm   = 1
 VVwZ3J   = 2
 VVkv9o   = 3
 VVCojy  = 4
 VVOqiS   = 5
 VVZ3z9   = 6
 VVN9eL  = 7
 VVVShA  = 8
 VVqnlB   = 9
 VV7uHi = 10
 VVcfqt   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 1100, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVKvMM  = None
  self.tableTitle   = "IPTV Channels List"
  self.VV6sImData  = {}
  self.lastFindIptvName = ""
  CCjino.__init__(self)
  VVpLvf= self.VVOap3()
  FFwrVg(self, VVpLvf=VVpLvf)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
  FF7PNd(self)
 def VVOap3(self):
  files = self.VVlzvB()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VV6sIm_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VV6sIm_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VV6sIm_fromM3u"  ))
  qUrl, iptvRef = self.VV1vz4()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VV6sIm_fromCurrChan" ))
  VVpLvf = []
  if files:
   if self.VVKvMM:
    VVpLvf.append(("Add Current List to a New Bouquet"      , "VV4GZ6"  ))
    VVpLvf.append(VVkUZg)
    VVpLvf.append(("Change Current List References to Unique Codes"   , "VVKHWS"))
    VVpLvf.append(("Change Current List References to Identical Codes"  , "VVFyUW_rows" ))
    VVpLvf.append(VVkUZg)
    VVpLvf.append(("Share Reference with Satellite/C/T Channel"    , "VVuMaf" ))
   else:
    VVpLvf += tList
    VVpLvf.append(VVkUZg)
    VVpLvf.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    VVpLvf.append(VVkUZg)
    VVpLvf.append(("Count Available IPTV Channels"       , "VVt2HU"    ))
    VVpLvf.append(("Check Reference Codes Format"        , "VVVru6"   ))
    VVpLvf.append(("Check System Acceptable Reference Types"     , "VV8ME3"   ))
    VVpLvf.append(VVkUZg)
    VVpLvf.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VV9O1L"  ))
    VVpLvf.append(("Change ALL References to match existing Sat/C/T Channels" , "VVyKpr" ))
    VVpLvf.append(("Change ALL References to Unique Codes"     , "VVYmyS" ))
    VVpLvf.append(("Change ALL References to Identical Codes"     , "VVFyUW_all" ))
  if not self.VVKvMM:
   if not files:
    VVpLvf += tList
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Analyse m3u File"            , "VVERGS"   ))
   VVpLvf.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVQa3E" ))
   VVpLvf.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVit3l" ))
   VVpLvf.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVtBCA" ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Reload Channels and Bouquets"         , "VVjxg3"   ))
  return VVpLvf
 def VVemKe(self, item):
  if item is not None:
   if   item == "VV4GZ6"   : FFQYeU(self, self.VV4GZ6, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVKHWS" : FFRzxq(self, boundFunction(FFGw6o, self.VVKvMM, self.VVKHWS ), "Change Current List References to Unique Codes ?")
   elif item == "VVFyUW_rows" : FFRzxq(self, boundFunction(FFGw6o, self.VVKvMM, self.VVFyUW   ), "Change Current List References to Identical Codes ?")
   elif item == "VVuMaf" : self.VVuMaf()
   elif item == "VV6sIm_fromPlayList" : FFGw6o(self, boundFunction(self.VVqtT7, True), title="Searching ...")
   elif item == "VV6sIm_fromM3u"  : FFGw6o(self, boundFunction(self.VVTmT4, 0), title="Searching ...")
   elif item == "VV6sIm_fromMac"  : self.VVrVGD()
   elif item == "VV6sIm_fromCurrChan" : self.VVo7lg_fromCurrChan()
   elif item == "iptvTable_live"   : FFGw6o(self, boundFunction(self.VVCnlq, self.VVOXQG ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFGw6o(self, boundFunction(self.VVCnlq, self.VV1uhe) , title="Loading Channels ...")
   elif item == "VVt2HU"    : FFGw6o(self, self.VVt2HU)
   elif item == "VVVru6"    : FFGw6o(self, self.VVVru6)
   elif item == "VV8ME3"   : FFGw6o(self, self.VV8ME3)
   elif item == "VV9O1L"  : self.VV9O1L()
   elif item == "VVyKpr"  : FFRzxq(self, boundFunction(FFGw6o, self, self.VVyKpr ), "Copy from existing Sat. Channel" )
   elif item == "VVYmyS" : FFRzxq(self, boundFunction(FFGw6o, self, self.VVYmyS ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVFyUW_all" : FFRzxq(self, boundFunction(FFGw6o, self, self.VVFyUW  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVERGS"   : FFGw6o(self, boundFunction(self.VVTmT4, 1), title="Searching ...")
   elif item == "VVQa3E" : self.VVQa3E()
   elif item == "VVit3l" : FFGw6o(self, boundFunction(self.VVTmT4, 2), title="Searching ...")
   elif item == "VVtBCA" : FFGw6o(self, boundFunction(self.VVqtT7, False), title="Searching ...")
   elif item == "VVjxg3"   : FFGw6o(self, boundFunction(CCUNoh.VVjxg3, self))
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVemKe(item)
 def VVCnlq(self, mode):
  VVKPkH = self.VVz6ZB(mode)
  if VVKPkH:
   VVYVXl = ("Current Service", self.VVcWln    , [])
   VVGGJN = ("Options"  , self.VVifYF      , [])
   VVmwc1 = ("Filter"   , self.VV7Xk7       , [])
   VVUydg  = ("Play"   , boundFunction(self.VVudhA, False) , [])
   VVVLKj = (""    , self.VVkTDm       , [])
   VVbDGl = (""    , self.VVbVdw        , [])
   VV5NUw = (""    , self.VV4PJy       , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVB5ih  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FF4eNC(self, None, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22
     , VVUydg=VVUydg, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVmwc1=VVmwc1, VVVLKj=VVVLKj, VVbDGl=VVbDGl
     , VVysAl="#0a00292B", VVkHTQ="#0a002126", VVrOep="#0a002126", VVjLvZ="#00000000", VVO8ee=True, searchCol=1)
  else:
   if mode == self.VVOXQG: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFCwHk(self, err)
 def VVbVdw(self, VVKvMM, title, txt, colList):
  self.VVKvMM = VVKvMM
 def VV4PJy(self, VVKvMM):
  self.VVKvMM = None
 def VVifYF(self, VVKvMM, title, txt, colList):
  VVpLvf= self.VVOap3()
  FFBYrC(self, self.VVemKe, title="IPTV Tools", VVpLvf=VVpLvf)
 def VV7Xk7(self, VVKvMM, title, txt, colList):
  VVpLvf = []
  VVpLvf.append(("All"         , "all"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Prefix of Selected Channel"   , "sameName" ))
  VVpLvf.append(("Suggest Words from Selected Channel" , "partName" ))
  VVpLvf.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Live TV"        , "live"  ))
  VVpLvf.append(("VOD"         , "vod"   ))
  VVpLvf.append(("Series"        , "series"  ))
  VVpLvf.append(("Uncategorised"      , "uncat"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Video"        , "video"  ))
  VVpLvf.append(("Audio"        , "audio"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("MKV"         , "MKV"   ))
  VVpLvf.append(("MP4"         , "MP4"   ))
  VVpLvf.append(("MP3"         , "MP3"   ))
  VVpLvf.append(("AVI"         , "AVI"   ))
  VVpLvf.append(("FLV"         , "FLV"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVXIWl()
  if bNames:
   bNames.sort()
   VVpLvf.append(VVkUZg)
   for item in bNames:
    VVpLvf.append((item, "__b__" + item))
  filterObj = CCL9aY(self)
  filterObj.VVAl33(VVpLvf, VVpLvf, boundFunction(self.VVyMUq, VVKvMM))
 def VVyMUq(self, VVKvMM, item=None):
  prefix = VVKvMM.VVtFdM(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV1uhe, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVd55n , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVo5Vl , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV6O3N , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVOXQG  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVLiXC   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVnaCh  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVwlSH  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVFnIO  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVAZC0  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVjcxo   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVIWLp   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVC1W3   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVxdox   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVtR11   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VV6SHX  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVi1pE  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVWniL  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVo5Vl:
   VVpLvf = []
   chName = VVKvMM.VVtFdM(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVpLvf.append((item, item))
    if not VVpLvf and chName:
     VVpLvf.append((chName, chName))
    FFBYrC(self, boundFunction(self.VVURYc_partOfName, title), title="Words from Current Selection", VVpLvf=VVpLvf)
   else:
    VVKvMM.VVglk9("Invalid Channel Name")
  else:
   words, asPrefix = CCL9aY.VVAGng(words)
   if not words and mode in (self.VVi1pE, self.VVWniL):
    FFngIP(self.VVKvMM, "Incorrect filter", 2000)
   else:
    FFGw6o(self.VVKvMM, boundFunction(self.VVv8rL, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVURYc_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFGw6o(self.VVKvMM, boundFunction(self.VVv8rL, self.VVo5Vl, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVPi7p(txt):
  return "#f#11ffff00#" + txt
 def VVv8rL(self, mode, words, asPrefix, title):
  VVKPkH = self.VVz6ZB(mode=mode, words=words, asPrefix=asPrefix)
  if VVKPkH : self.VVKvMM.VV32hv(VVKPkH, title)
  else  : self.VVKvMM.VVglk9("Not found")
 def VVz6ZB(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVKPkH = []
  files  = self.VVlzvB()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFItSN(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVsOyw = span.group(1)
    else : VVsOyw = ""
    VVsOyw_lCase = VVsOyw.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVSZN6(chName): chNameMod = self.VVPi7p(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVsOyw, chType, refCode, url)
     ok = False
     tUrl = FFfGUi(url).lower()
     if mode == self.VV1uhe       : ok = True
     elif mode == self.VV6SHX       : ok = True
     elif mode == self.VVFnIO:
      if CCDch1.VVaZZX(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVAZC0:
      if CCDch1.VVaZZX(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVOXQG:
      if CCDch1.VVaZZX(tUrl, compareType="live")  : ok = True
     elif mode == self.VVLiXC:
      if CCDch1.VVaZZX(tUrl, compareType="movie") : ok = True
     elif mode == self.VVnaCh:
      if CCDch1.VVaZZX(tUrl, compareType="series") : ok = True
     elif mode == self.VVwlSH:
      if CCDch1.VVaZZX(tUrl, compareType="")   : ok = True
     elif mode == self.VVjcxo:
      if CCDch1.VVaZZX(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVIWLp:
      if CCDch1.VVaZZX(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVC1W3:
      if CCDch1.VVaZZX(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVxdox:
      if CCDch1.VVaZZX(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVtR11:
      if CCDch1.VVaZZX(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVd55n:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVo5Vl:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VV6O3N:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVi1pE:
      if words[0] == VVsOyw_lCase:
       ok = True
     elif mode == self.VVWniL:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVKPkH.append(row)
      chNum += 1
  if VVKPkH and mode == self.VV6SHX:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVKPkH)
   for item in VVKPkH:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVKPkH = newRows
  return VVKPkH
 def VV4GZ6(self, bName):
  if bName:
   FFGw6o(self.VVKvMM, boundFunction(self.VVxwtP, bName), title="Adding Channels ...")
 def VVxwtP(self, bName):
  num = 0
  path = VVonVf + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVonVf + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVKvMM.VV3tvF():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFAwDH(row[1]))
    totChange += 1
  FFwsb7(os.path.basename(path))
  self.VVKs6d(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV9O1L(self):
  txt = "Stream Type "
  VVpLvf = []
  VVpLvf.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVpLvf.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVpLvf.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVpLvf.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVpLvf.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVpLvf.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFBYrC(self, self.VVJW65, title="Change Reference Types to:", VVpLvf=VVpLvf)
 def VVJW65(self, item=None):
  if item:
   if   item == "RT_1"  : self.VV42Kj("1"   )
   elif item == "RT_4097" : self.VV42Kj("4097")
   elif item == "RT_5001" : self.VV42Kj("5001")
   elif item == "RT_5002" : self.VV42Kj("5002")
   elif item == "RT_8192" : self.VV42Kj("8192")
   elif item == "RT_8193" : self.VV42Kj("8193")
 def VV42Kj(self, rType):
  FFRzxq(self, boundFunction(FFGw6o, self, boundFunction(self.VVnReE, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVnReE(self, refType):
  totChange = 0
  files  = self.VVlzvB()
  if files:
   for path in files:
    txt = FFItSN(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFwsb7(os.path.basename(path))
  self.VVKs6d(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVt2HU(self):
  totFiles = 0
  files  = self.VVlzvB()
  if files:
   totFiles = len(files)
  totChans = 0
  VVKPkH = self.VVz6ZB()
  if VVKPkH:
   totChans = len(VVKPkH)
  FFWUy2(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVVru6(self):
  files  = self.VVlzvB()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFItSN(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVJH5T
   else    : color = VViuIz
   totInvalid = FFXMyR(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFXMyR("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFWUy2(self, txt, title="Check IPTV References")
 def VV8ME3(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVonVf + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFwsb7(os.path.basename(path))
  FFNkRg()
  acceptedList = []
  VVsraV = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVsraV:
   VVD8xW = FFXWZI(VVsraV)
   if VVD8xW:
    for service in VVD8xW:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVonVf + userBName
  bFile = VVonVf + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFfUI2("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFfUI2("rm -f '%s'" % path)
  os.system(cmd)
  FFNkRg()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVJH5T
    else     : res, color = "No" , VViuIz
    txt += "    %s\t: %s\n" % (item, FFXMyR(res, color))
   FFWUy2(self, txt, title=title)
  else:
   txt = FFCwHk(self, "Could not complete the test on your system!", title=title)
 def VVyKpr(self):
  lameDbChans = CCUNoh.VVFF4N(self, CCUNoh.VVB61F)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVlzvB():
    toSave = False
    txt = FFItSN(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVKs6d(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFCwHk(self, 'No channels in "lamedb" !')
 def VVYmyS(self):
  files  = self.VVlzvB()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFawFw(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVfx0s(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVKs6d(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVKHWS(self):
  iptvRefList = []
  files  = self.VVlzvB()
  if files:
   for path in files:
    txt = FFItSN(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVKvMM.VVnmq9(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVfx0s(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVlzvB()
  if files:
   for path in files:
    lines = FFawFw(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVKs6d(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVfx0s(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVFyUW(self):
  list = None
  if self.VVKvMM:
   list = []
   for row in self.VVKvMM.VV3tvF():
    list.append(row[4] + row[5])
  files  = self.VVlzvB()
  totChange = 0
  if files:
   for path in files:
    lines = FFawFw(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVKs6d(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVKs6d(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFNkRg()
   if refreshTable and self.VVKvMM:
    VVKPkH = self.VVz6ZB()
    if VVKPkH and self.VVKvMM:
     self.VVKvMM.VV32hv(VVKPkH, self.tableTitle)
     self.VVKvMM.VVglk9(txt)
   FFWUy2(self, txt, title=title)
  else:
   FFGBS4(self, "No changes.")
 def VVXIWl(self):
  files = self.VVlzvB()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVTCY9 = FF80rj()
    if VVTCY9:
     for b in VVTCY9:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVlzvB(self):
  return CCDch1.VVDEr7(self)
 @staticmethod
 def VVDEr7(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVonVf + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFItSN(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVkTDm(self, VVKvMM, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFfGUi(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("Ref.")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFCpwr(self, fncMode=CCzK25.VVcxY0, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVudhA(self, fromPlayer, VVKvMM, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVKytG(fromPlayer, VVKvMM, chName, chUrl, "localIptv")
 def VVfMp1(self, mode, fromPlayer, VVKvMM, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVKBJ7(mode, colList)
  self.VVKytG(fromPlayer, VVKvMM, chName, chUrl, mode)
 def VVKytG(self, fromPlayer, VVKvMM, chName, chUrl, playerFlag):
  chName = FFAwDH(chName)
  if fromPlayer:
   self.VVLAzn(VVKvMM, chUrl, playerFlag)
  elif self.VVSZN6(chName):
   FFngIP(VVKvMM, "This is a marker!", 300)
  else:
   FFGw6o(VVKvMM, boundFunction(self.VVLAzn, VVKvMM, chUrl, playerFlag), title="Playing ...")
 def VVLAzn(self, VVKvMM, chUrl, playerFlag):
  FFlnjO(self, chUrl, VV9Blm=False)
  self.session.open(CCwbgh, portalTableParam=(self, VVKvMM, playerFlag))
 @staticmethod
 def VVSZN6(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVcWln(self, VVKvMM, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  if refCode:
   bName = FFhOZZ()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFdy9m(refCode, origUrl, chName) }
   VVKvMM.VVQbQF_partial(colDict, VVDTOG=True)
 def VVQa3E(self):
  self.session.open(CCRH8h)
  self.close()
 def VVTmT4(self, m3uMode):
  lines = FFzFRs("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFphRM(1))
  if lines:
   lines.sort()
   VVpLvf = []
   for line in lines:
    VVpLvf.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVKjVK = ("All to Playlist", self.VVb6pK)
   else    : VVKjVK = None
   OKBtnFnc = boundFunction(self.VV4e8W, m3uMode, title)
   VVgMyE = ("Show Full Path", self.VV0egs)
   FFBYrC(self, None, title=title, VVpLvf=VVpLvf, OKBtnFnc=OKBtnFnc, VVgMyE=VVgMyE, VVKjVK=VVKjVK)
  else:
   FFCwHk(self, 'No "m3u" files found.')
 def VV0egs(self, VVupR7Obj, url):
  FFWUy2(self, url, title="Full Path")
 def VV4e8W(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFGw6o(menuInstance, boundFunction(self.VV1jli, title, path))
   elif m3uMode == 1 : self.VVERGS(title, path)
   else    : self.VVeKQQ(menuInstance, path)
 def VVb6pK(self, VVupR7Obj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVupR7Obj.VVpLvf):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVoDhc(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    pListF = "%sPlaylist_%s.txt" % (FFUUJW(CFG.exportedTablesPath.getValue()), FFi9KP())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVupR7Obj.VVpLvf)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFWUy2(self, txt, title=title)
   else:
    FFCwHk(self, "Could not obtain URLs from this file list !", title=title)
 def VVERGS(self, title, path):
  if fileExists(path):
   self.session.open(CCLTq8, barTheme=CCLTq8.VVq2B4
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVZ1Wy, path)
       , VVcWME = boundFunction(self.VVR71w, title, path))
  else:
   FFCwHk(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVR71w(self, title, path, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  if VVPNFn:
   FFWUy2(self, VVRQiU, title=title)
 def VVZ1Wy(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FFItSN(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVRQiU = ""
  progBarObj.VVINqi(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVsgjw(1)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FFfGUi(tUrl).lower()
   chType, host, username, password, streamId, chName = CCDch1.VVaZZX(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCDch1.VVaZZX(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FFXMyR("File:\n", VV7ect)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FFXMyR("Channels:\n", VV7ect)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFXMyR("Category:\n", VV7ect)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFXMyR("Content:\n", VV7ect)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    None channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VVRQiU = txt
 def VVqtT7(self, isBrowseServer):
  lines = FFzFRs('find / %s -iname "*playlist*" | grep -i ".txt"' % FFphRM(1))
  if lines:
   lines.sort()
   VVpLvf = []
   for line in lines:
    VVpLvf.append((line, line))
   OKBtnFnc = boundFunction(self.VVhEBm, isBrowseServer)
   FFBYrC(self, None, title="Select Playlist File", VVpLvf=VVpLvf, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFurlj(self, "( playlist.txt  or  playlists.txt )")
 def VVhEBm(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFGw6o(menuInstance, boundFunction(self.VVnzi8, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVnzi8(self, fileMenuInstance, path, isBrowseServer):
  VVpLvf = []
  lines = FFawFw(path)
  for line in lines:
   line = line.strip()
   span = iSearch(r"(http.+php.+username=.+password=.+)(?:[&]+)*", line, IGNORECASE)
   if span:
    VVpLvf.append((span.group(1), span.group(1)))
   else:
    span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
    if span:
     host = FFUUJW(span.group(1).strip())
     user1 = span.group(2).strip()
     pass1 = span.group(3).strip()
     line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
     VVpLvf.append((line, line))
  if VVpLvf:
   if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVpLvf)
   else    : title = "Convert to Bouquet"
   OKBtnFnc  = boundFunction(self.VVgdGE, isBrowseServer, title)
   VVFOel  = ("Home Menu"  , FF2k7C)
   VVgMyE  = ("Show URL"  , self.VVhYQk)
   VVKjVK   = ("Check & Filter" , boundFunction(self.VVsSEd, fileMenuInstance, path, isBrowseServer))
   FFBYrC(self, None, title=title, VVpLvf=VVpLvf, width=1200, OKBtnFnc=OKBtnFnc, VVFOel=VVFOel, VVgMyE=VVgMyE, VVKjVK=VVKjVK)
  else:
   FFCwHk(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVhYQk(self, VVupR7Obj, url):
  FFWUy2(self, url, title="URL")
 def VVgdGE(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFGw6o(menuInstance, boundFunction(self.VVPEPj, title, url), title="Checking Server ...")
   else:
    FFRzxq(self, boundFunction(FFGw6o, menuInstance, boundFunction(self.VVTu9X, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVTu9X(self, menuInstance, url):
  path, err = FF3VVg(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFCwHk(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFItSN(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFCwHk(self, "Unauthorized", title=title)
     os.system(FFfUI2("rm -f '%s'" % path))
     return
   self.VVeKQQ(menuInstance, path)
 def VVuMaf(self):
  self.session.open(CCLTq8, barTheme=CCLTq8.VVq2B4
      , titlePrefix = "Finding similar names"
      , fncToRun  = self.VVIlp0
      , VVcWME = self.VVoVtx)
 def VVIlp0(self, progBarObj):
  curChName = self.VVKvMM.VVtFdM(1)
  FFngIP(self, "Searching")
  lameDbChans = CCUNoh.VVFF4N(self, CCUNoh.VVpBvr, VVC4in=False, VVwyJo=False)
  FFngIP(self)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVRQiU = []
  progBarObj.VVINqi(len(lameDbChans))
  if lameDbChans:
   curCh = curChName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCivOr.VViQnn(chName.lower(), curCh)
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVsgjw(1)
    if ratio > 50:
     progBarObj.VVRQiU.append((chName, FFIwV7(sat), refCode.replace("_", ":")))
 def VVoVtx(self, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  if VVPNFn:
   curChName = self.VVKvMM.VVtFdM(1)
   curRefCode = self.VVKvMM.VVtFdM(4)
   curUrl  = self.VVKvMM.VVtFdM(5)
   title = "Share Reference with Satellite/C/T Channel"
   if VVRQiU:
    VVRQiU.sort(key=lambda x: x[0].lower())
    VVUydg  = ("Share Sat/C/T Ref.", boundFunction(self.VVBDnb, title, curChName, curRefCode, curUrl), [])
    header   = ("Name" , "Sat"  , "Reference" )
    widths   = (34  , 33  , 33   )
    FF4eNC(self, None, title=title, header=header, VVcsAS=VVRQiU, VVgyfO=widths, VVvE6h=24, VVUydg=VVUydg, VVysAl="#0a00112B", VVkHTQ="#0a001126", VVrOep="#0a001126", VVjLvZ="#00000000")
   else:
    FFCwHk(self, "No similar names found !", title)
 def VVBDnb(self, newtitle, curChName, curRefCode, curUrl, VVKvMM, title, txt, colList):
  VVKvMM.cancel()
  newChName = colList[0]
  newRefCode = colList[2]
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  FFGw6o(self.VVKvMM, boundFunction(self.VVgNhJ, data, ques, newtitle))
 def VVgNhJ(self, data, ques, title):
  FFRzxq(self.VVKvMM, boundFunction(FFGw6o, self.VVKvMM, boundFunction(self.VV39VD, data)), ques, title=title, VVpF7d=True)
 def VV39VD(self, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVlzvB():
    txt = FFItSN(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFNkRg()
    newRow = []
    for i in range(6):
     newRow.append(self.VVKvMM.VVtFdM(i))
    newRow[4] = newRefCode
    done = self.VVKvMM.VVbiRP(newRow)
    FFGBS4(self, "Done", title=title)
   else:
    FFCwHk(self, "Not found in IPTV files !", title=title)
  else:
   FFCwHk(self, "Could not read channel info !", title=title)
 def VVsSEd(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, item):
  self.session.open(CCLTq8, barTheme=CCLTq8.VVq2B4
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVPVDQ, urlMenuInstance)
      , VVcWME = boundFunction(self.VVFLbO, fileMenuInstance, path, isBrowseServer, urlMenuInstance))
 def VVPVDQ(self, urlMenuInstance, progBarObj):
  progBarObj.VVINqi(len(urlMenuInstance.VVpLvf))
  progBarObj.VVRQiU = []
  for ndx, item in enumerate(urlMenuInstance.VVpLvf):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVsgjw(1)
   qUrl = self.VVYUYd(self.VVeCQk, item[0])
   txt, err = self.VV4gvw(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVdfFW(item, "auth") == "0":
       progBarObj.VVRQiU.append(qUrl)
    except:
     pass
 def VVFLbO(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  if VVPNFn:
   list = VVRQiU
   title = "Authorized Servers"
   if list:
    totChk = len(urlMenuInstance.VVpLvf)
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFi9KP()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVqtT7(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFXMyR(str(totAuth), VVJH5T)
     txt += "%s\n\n%s"     %  (FFXMyR("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFWUy2(self, txt, title=title)
     urlMenuInstance.close()
     fileMenuInstance.close()
    else:
     FFGBS4(self, "All URLs are authorized.", title=title)
   else:
    FFCwHk(self, "No authorized URL found !", title=title)
 def VVeKQQ(self, parentInstant, path):
  files = CCDch1.VVDEr7(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCDch1.VV6MZj(parentInstant, path, exitCurWin)
 @staticmethod
 def VV6MZj(SELF, path, exitCurWin):
  FFRzxq(SELF, boundFunction(FFGw6o, SELF, boundFunction(CCDch1.VVmLhr, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVmLhr(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFCwHk(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCDch1.VVUS5c(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVonVf + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVonVf + bFileName):
     bName = tmpBName
     break
  txt = FFItSN(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVonVf + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFGl0A(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFwsb7(bFileName)
   FFNkRg()
   FFGBS4(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFCwHk(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VV4gvw(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVQ88h(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVaZZX(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVYUYd(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVQ88h(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVeCQk   : return "%s"            % url
  elif mode == self.VVh2Rm   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVwZ3J   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVkv9o  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVCojy : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVOqiS   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVZ3z9    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVN9eL  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVVShA  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVqnlB  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VV7uHi : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVcfqt   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVdfFW(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFSqAc(int(val))
    elif is_base64 : val = FFKrOM(val)
    elif isToHHMMSS : val = FFP20u(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV1jli(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVoDhc(line)
     if qUrl:
      break
   if qUrl : self.VVPEPj(title, qUrl)
   else : FFCwHk(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFCwHk(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVo7lg_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV1vz4()
  if qUrl:
   host, mac, isPortalUrl = self.VVbakG(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVo7lg(self, host, mac)
    else   : FFCwHk(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFGw6o(self, boundFunction(self.VVPEPj, title, qUrl), title="Checking Server ...")
  else:
   FFCwHk(self, "Error in current channel URL !", title=title)
 def VV1vz4(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  qUrl = self.VVoDhc(decodedUrl)
  return qUrl, iptvRef
 def VVoDhc(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVPEPj(self, title, url):
  self.VV6sImData = {}
  qUrl = self.VVYUYd(self.VVeCQk, url)
  txt, err = self.VV4gvw(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV6sImData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV6sImData["username"    ] = self.VVdfFW(item, "username"        )
    self.VV6sImData["password"    ] = self.VVdfFW(item, "password"        )
    self.VV6sImData["message"    ] = self.VVdfFW(item, "message"        )
    self.VV6sImData["auth"     ] = self.VVdfFW(item, "auth"         )
    self.VV6sImData["status"    ] = self.VVdfFW(item, "status"        )
    self.VV6sImData["exp_date"    ] = self.VVdfFW(item, "exp_date"    , isDate=True )
    self.VV6sImData["is_trial"    ] = self.VVdfFW(item, "is_trial"        )
    self.VV6sImData["active_cons"   ] = self.VVdfFW(item, "active_cons"       )
    self.VV6sImData["created_at"   ] = self.VVdfFW(item, "created_at"   , isDate=True )
    self.VV6sImData["max_connections"  ] = self.VVdfFW(item, "max_connections"      )
    self.VV6sImData["allowed_output_formats"] = self.VVdfFW(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VV6sImData[key] = lst
    item = tDict["server_info"]
    self.VV6sImData["url"    ] = self.VVdfFW(item, "url"        )
    self.VV6sImData["port"    ] = self.VVdfFW(item, "port"        )
    self.VV6sImData["https_port"  ] = self.VVdfFW(item, "https_port"      )
    self.VV6sImData["server_protocol" ] = self.VVdfFW(item, "server_protocol"     )
    self.VV6sImData["rtmp_port"   ] = self.VVdfFW(item, "rtmp_port"       )
    self.VV6sImData["timezone"   ] = self.VVdfFW(item, "timezone"       )
    self.VV6sImData["timestamp_now"  ] = self.VVdfFW(item, "timestamp_now"  , isDate=True )
    self.VV6sImData["time_now"   ] = self.VVdfFW(item, "time_now"       )
    VVpLvf  = self.VVbUIw()
    OKBtnFnc = self.VV6sImOptions
    VVFOel = ("Home Menu", FF2k7C)
    FFBYrC(self, None, title="IPTV Server Resources", VVpLvf=VVpLvf, OKBtnFnc=OKBtnFnc, VVFOel=VVFOel)
   else:
    err = "Could not get data from server !"
  if err:
   FFCwHk(self, err, title=title)
  FFngIP(self)
 def VV6sImOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFGw6o(menuInstance, boundFunction(self.VVZR4L, self.VVh2Rm , title=title), title=wTxt)
   elif ref == "vod"   : FFGw6o(menuInstance, boundFunction(self.VVZR4L, self.VVwZ3J , title=title), title=wTxt)
   elif ref == "series"  : FFGw6o(menuInstance, boundFunction(self.VVZR4L, self.VVkv9o, title=title), title=wTxt)
   elif ref == "accountInfo" : FFGw6o(menuInstance, boundFunction(self.VVh6WK          , title=title), title=wTxt)
 def VVh6WK(self, title):
  rows = []
  for key, val in self.VV6sImData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVKuXf = ("Home Menu", FF2k7C, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FF4eNC(self, None, title=title, header=header, VVcsAS=rows, VVgyfO=widths, VVvE6h=26, VVKuXf=VVKuXf, VVysAl="#0a00292B", VVkHTQ="#0a002126", VVrOep="#0a002126", VVjLvZ="#00000000", searchCol=2)
 def VV8ucf(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCEiXp()
    if mode == self.VVOqiS:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVdfFW(item, "num"         )
      name     = self.VVdfFW(item, "name"        )
      stream_id    = self.VVdfFW(item, "stream_id"       )
      stream_icon    = self.VVdfFW(item, "stream_icon"       )
      epg_channel_id   = self.VVdfFW(item, "epg_channel_id"      )
      added     = self.VVdfFW(item, "added"    , isDate=True )
      is_adult    = self.VVdfFW(item, "is_adult"       )
      category_id    = self.VVdfFW(item, "category_id"       )
      name = processChanName.VVLgnx(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVZ3z9:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVdfFW(item, "num"         )
      name    = self.VVdfFW(item, "name"        )
      stream_id   = self.VVdfFW(item, "stream_id"       )
      stream_icon   = self.VVdfFW(item, "stream_icon"       )
      added    = self.VVdfFW(item, "added"    , isDate=True )
      is_adult   = self.VVdfFW(item, "is_adult"       )
      category_id   = self.VVdfFW(item, "category_id"       )
      container_extension = self.VVdfFW(item, "container_extension"     ) or "mp4"
      name = processChanName.VVLgnx(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVN9eL:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVdfFW(item, "num"        )
      name    = self.VVdfFW(item, "name"       )
      series_id   = self.VVdfFW(item, "series_id"      )
      cover    = self.VVdfFW(item, "cover"       )
      genre    = self.VVdfFW(item, "genre"       )
      episode_run_time = self.VVdfFW(item, "episode_run_time"    )
      category_id   = self.VVdfFW(item, "category_id"      )
      container_extension = self.VVdfFW(item, "container_extension"    ) or "mp4"
      name = processChanName.VVLgnx(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVZR4L(self, mode, title):
  qUrl = self.VVYUYd(mode, self.VV6sImData["playListURL"])
  txt, err = self.VV4gvw(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    hideAdult = CFG.hideIptvServerAdultWords.getValue()
    tDict = jLoads(txt)
    if tDict:
     processChanName = CCEiXp()
     for item in tDict:
      category_id  = self.VVdfFW(item, "category_id"  )
      category_name = self.VVdfFW(item, "category_name" )
      parent_id  = self.VVdfFW(item, "parent_id"  )
      category_name = processChanName.VVloRx(category_name)
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   err = "Server Error:\n\n" + err
  if err:
   FFCwHk(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU(mode)
   mName = self.VVTi9b(mode)
   if   mode == self.VVh2Rm  : fMode, okTitle = self.VVOqiS , "Show Channels"
   elif mode == self.VVwZ3J  : fMode, okTitle = self.VVZ3z9 , "Show Channels"
   elif mode == self.VVkv9o : fMode, okTitle = self.VVN9eL, "Show List"
   VVGGJN = ("Find in %s" % mName , boundFunction(self.VVu5Vq, fMode) , [])
   VVUydg  = (okTitle    , boundFunction(self.VVX5us, mode) , [])
   VVKuXf = ("Home Menu"   , FF2k7C          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF4eNC(self, None, title=title, header=header, VVcsAS=list, VVgyfO=widths, VVvE6h=30, VVKuXf=VVKuXf, VVGGJN=VVGGJN, VVUydg=VVUydg, VVysAl=VVysAl, VVkHTQ=VVkHTQ, VVrOep=VVrOep, VVjLvZ=VVjLvZ)
  else:
   FFCwHk(self, "No list from server !", title=title)
  FFngIP(self)
 def VVX5us(self, mode, VVKvMM, title, txt, colList):
  title = colList[1]
  FFGw6o(VVKvMM, boundFunction(self.VVNXIN, mode, VVKvMM, title, txt, colList), title="Downloading ...")
 def VVNXIN(self, mode, VVKvMM, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVTi9b(mode) + " : "+ bName
  if   mode == self.VVh2Rm  : mode = self.VVOqiS
  elif mode == self.VVwZ3J  : mode = self.VVZ3z9
  elif mode == self.VVkv9o : mode = self.VVN9eL
  qUrl  = self.VVYUYd(mode, self.VV6sImData["playListURL"], catID)
  txt, err = self.VV4gvw(qUrl)
  list  = []
  if not err and mode in (self.VVOqiS, self.VVZ3z9, self.VVN9eL):
   list, err = self.VV8ucf(mode, txt)
  if err:
   FFCwHk(self, err, title=title)
  elif list:
   VVKuXf  = ("Home Menu"   , FF2k7C            , [])
   if mode == self.VVOqiS:
    VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU(mode)
    VVUydg  = ("Play"    , boundFunction(self.VVfMp1, mode, False)  , [])
    VVVLKj = (""     , boundFunction(self.VVTodH, mode)    , [])
    VVYVXl = ("Download PIcons" , boundFunction(self.VV11Qp, mode)    , [])
    VVGGJN = ("Add ALL to Bouquet" , boundFunction(self.VVzVU3, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVB5ih  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVZ3z9:
    VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU(mode)
    VVUydg  = ("Play"    , boundFunction(self.VVfMp1, mode, False)  , [])
    VVVLKj = (""     , boundFunction(self.VVTodH, mode)    , [])
    VVYVXl = ("Download PIcons" , boundFunction(self.VV11Qp, mode)    , [])
    VVGGJN = ("Add ALL to Bouquet" , boundFunction(self.VVzVU3, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVB5ih  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVN9eL:
    VVysAl, VVkHTQ, VVrOep, VVjLvZ = self.VVg8wU("series2")
    VVUydg  = ("Show Seasons", boundFunction(self.VV5Ipd, mode) , [])
    VVVLKj = ("", boundFunction(self.VV1fLY, mode)  , [])
    VVYVXl = None
    VVGGJN = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVB5ih  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FF4eNC(self, None, title=title, header=header, VVcsAS=list, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=26, VVUydg=VVUydg, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVVLKj=VVVLKj, VVysAl=VVysAl, VVkHTQ=VVkHTQ, VVrOep=VVrOep, VVjLvZ=VVjLvZ, VVO8ee=True, searchCol=1)
  else:
   FFCwHk(self, "No Channels found !", title=title)
  FFngIP(self)
 def VV5Ipd(self, mode, VVKvMM, title, txt, colList):
  title = colList[1]
  FFGw6o(VVKvMM, boundFunction(self.VVfdIS, mode, VVKvMM, title, txt, colList), title="Downloading ...")
 def VVfdIS(self, mode, VVKvMM, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVYUYd(self.VVCojy, self.VV6sImData["playListURL"], series_id)
  txt, err = self.VV4gvw(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVdfFW(tDict["info"], "name"   )
      category_id = self.VVdfFW(tDict["info"], "category_id" )
      icon  = self.VVdfFW(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVdfFW(EP, "id"     )
        episode_num   = self.VVdfFW(EP, "episode_num"   )
        epTitle    = self.VVdfFW(EP, "title"     )
        container_extension = self.VVdfFW(EP, "container_extension" )
        seasonNum   = self.VVdfFW(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFCwHk(self, err, title=title)
  elif list:
   VVKuXf = ("Home Menu"   , FF2k7C            , [])
   VVYVXl = ("Download PIcons" , boundFunction(self.VV11Qp , mode)   , [])
   VVGGJN = ("Add ALL to Bouquet" , boundFunction(self.VVzVU3, mode, title) , [])
   VVVLKj = (""     , boundFunction(self.VVTodH, mode)    , [])
   VVUydg  = ("Play"    , boundFunction(self.VVfMp1, mode, False)  , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVB5ih  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF4eNC(self, None, title=title, header=header, VVcsAS=list, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=26, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVUydg=VVUydg, VVVLKj=VVVLKj, VVGGJN=VVGGJN, VVysAl="#0a00292B", VVkHTQ="#0a002126", VVrOep="#0a002126", VVjLvZ="#00000000")
  else:
   FFCwHk(self, "No Channels found !", title=title)
  FFngIP(self)
 def VVu5Vq(self, mode, VVKvMM, title, txt, colList):
  VVpLvf = []
  VVpLvf.append(("Keyboard"  , "manualEntry"))
  VVpLvf.append(("From Filter" , "fromFilter"))
  FFBYrC(self, boundFunction(self.VVFl76, VVKvMM, mode), title="Input Type", VVpLvf=VVpLvf, width=400)
 def VVFl76(self, VVKvMM, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFQYeU(self, boundFunction(self.VVvipc, VVKvMM, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCL9aY(self)
    filterObj.VVjegd(boundFunction(self.VVvipc, VVKvMM, mode))
 def VVvipc(self, VVKvMM, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCEiXp()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VV3H72(words):
     FFCwHk(self, processChanName.VVju22(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCLTq8, barTheme=CCLTq8.VVq2B4
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VV0DJC, VVKvMM, mode, title, words, toFind, asPrefix, processChanName)
         , VVcWME = boundFunction(self.VVyVyw, mode, toFind, title))
   else:
    FFCwHk(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VV0DJC(self, VVKvMM, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVINqi(VVKvMM.VVajAt())
  progBarObj.VVRQiU = []
  for row in VVKvMM.VV3tvF():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVsgjw(1)
   progBarObj.VVS6ex("Found %d ... %s" % (len(progBarObj.VVRQiU), catName))
   qUrl  = self.VVYUYd(mode, self.VV6sImData["playListURL"], catID)
   txt, err = self.VV4gvw(qUrl)
   if not err:
    tList, err = self.VV8ucf(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVLgnx(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVOqiS:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVRQiU.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVZ3z9:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVRQiU.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVN9eL:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVRQiU.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVyVyw(self, mode, toFind, title, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  if VVRQiU:
   title = self.VVwbee(mode, toFind)
   if mode == self.VVOqiS or mode == self.VVZ3z9:
    bName   = CCDch1.VVUS5c(toFind)
    VVUydg  = ("Play"     , boundFunction(self.VVfMp1, mode, False)  , [])
    VVGGJN = ("Add ALL to Bouquet" , boundFunction(self.VVzVU3, mode, bName) , [])
    VVYVXl = ("Download PIcons" , boundFunction(self.VV11Qp, mode)    , [])
   elif mode == self.VVN9eL:
    VVUydg  = ("Show Seasons"  , boundFunction(self.VV5Ipd, mode)    , [])
    VVGGJN = None
    VVYVXl = None
   VVVLKj = (""   , boundFunction(self.VVTodH, mode) , [])
   VVKuXf = ("Home Menu" , FF2k7C         , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVB5ih  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVKvMM = FF4eNC(self, None, title=title, header=header, VVcsAS=VVRQiU, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=26, VVUydg=VVUydg, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVVLKj=VVVLKj, VVysAl="#0a00292B", VVkHTQ="#0a002126", VVrOep="#0a002126", VVjLvZ="#00000000", VVO8ee=True, searchCol=1)
   if not VVPNFn:
    FFngIP(VVKvMM, "Stopped" , 1000)
  else:
   if VVPNFn:
    FFCwHk(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVKBJ7(self, mode, colList):
  if mode == self.VVOqiS:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVZ3z9:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFAwDH(chName)
  url = self.VV6sImData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVQ88h(url)
  refCode = self.VVnzNz(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVTodH(self, mode, VVKvMM, title, txt, colList):
  FFGw6o(VVKvMM, boundFunction(self.VVliDG, mode, VVKvMM, title, txt, colList))
 def VVliDG(self, mode, VVKvMM, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVKBJ7(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFCpwr(self, fncMode=CCzK25.VVnztO, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VV1fLY(self, mode, VVKvMM, title, txt, colList):
  FFGw6o(VVKvMM, boundFunction(self.VVCy8b, mode, VVKvMM, title, txt, colList))
 def VVCy8b(self, mode, VVKvMM, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFCpwr(self, fncMode=CCzK25.VV6jo5, chName=name, text=txt, picUrl=Cover)
 def VVzVU3(self, mode, bName, VVKvMM, title, txt, colList):
  FFGw6o(VVKvMM, boundFunction(self.VVX3ph, mode, bName, VVKvMM, title, txt, colList), title="Adding Channels ...")
 def VVX3ph(self, mode, bName, VVKvMM, title, txt, colList):
  url = self.VV6sImData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVQ88h(url)
  bNameFile = CCDch1.VVUS5c(bName)
  num  = 0
  path = VVonVf + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVonVf + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVKvMM.VV3tvF():
    chName, chUrl, picUrl, refCode = self.VVKBJ7(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFwsb7(os.path.basename(path))
  self.VVKs6d(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV11Qp(self, mode, VVKvMM, title, txt, colList):
  if os.system(FFfUI2("which ffmpeg")) == 0:
   self.session.open(CCLTq8, barTheme=CCLTq8.VVaDMy
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVYJmZ, VVKvMM, mode)
       , VVcWME = self.VVzCWB)
  else:
   FFRzxq(self, self.VVSscH, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVzCWB(self, VVPNFn, VVRQiU, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVRQiU["proces"], VVRQiU["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVRQiU["ok"], VVRQiU["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVRQiU["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVRQiU["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVRQiU["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVRQiU["path"]
  if not VVPNFn  : color = "#11402000"
  elif VVRQiU["err"]: color = "#11201000"
  else     : color = None
  if VVRQiU["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVRQiU["err"], txt)
  title = "PIcons Download Result"
  if not VVPNFn:
   title += "  (cancelled)"
  FFWUy2(self, txt, title=title, VVrOep=color)
 def VVYJmZ(self, VVKvMM, mode, progBarObj):
  totRows = VVKvMM.VVajAt()
  progBarObj.VVINqi(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCivOr.VVHoxR()
  progBarObj.VVRQiU = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVKvMM.VV3tvF():
    if progBarObj.isCancelled:
     break
    progBarObj.VVRQiU["proces"] += 1
    progBarObj.VVsgjw(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1NCU(mode, row)
     refCode = CCDch1.VVnzNz(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVKBJ7(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVRQiU["attempt"] += 1
      path, err = FF3VVg(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVRQiU["ok"] += 1
       if FF7R0c(path) > 0:
        cmd = ""
        if not mode == CCDch1.VVOqiS:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFfUI2("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVRQiU["size0"] += 1
        os.system(FFfUI2("rm -f '%s'" % path))
      elif err:
       progBarObj.VVRQiU["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVRQiU["err"] = err.title()
        break
     else:
      progBarObj.VVRQiU["exist"] += 1
    else:
     progBarObj.VVRQiU["badURL"] += 1
  except:
   pass
 def VVSscH(self):
  cmd = FFHVrF(VVL2aE, "ffmpeg")
  if cmd : FF0xy0(self, cmd, title="Installing FFmpeg")
  else : FFpJtk(self)
 @staticmethod
 def VVnzNz(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCDch1.VVl6Bh(catID, MAX_4b)
  TSID = CCDch1.VVl6Bh(chNum, MAX_4b)
  ONID = CCDch1.VVl6Bh(chNum, MAX_4b)
  NS  = CCDch1.VVl6Bh(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVl6Bh(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVUS5c(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CCwZoR(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVFSTb  = 0
  self.VVnRow = 1
  self.VVXx1b  = 2
  VVpLvf = []
  VVpLvf.append(("Find All (from filter)"    , "VVLwlS" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Find All"        , "VVFy8j"    ))
  VVpLvf.append(("Find TV"        , "VV8lqt"    ))
  VVpLvf.append(("Find Radio"       , "VVyVWq"   ))
  if self.VVTPTV():
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Hide Channel: %s" % self.servName , "VVeulY"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Zap History"       , "VVDn1u"    ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("PIcons Tools"       , "PIconsTools"     ))
  VVpLvf.append(("Channels Tools"      , "ChannelsTools"    ))
  FFwrVg(self, VVpLvf=VVpLvf, title=title)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
  if self.isFindMode:
   self.VVoJzE(self.VVkiKO())
 def VVlsTV(self):
  global VVkEqR
  VVkEqR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVFy8j"    : self.VVFy8j()
   elif item == "VVLwlS" : self.VVLwlS()
   elif item == "VV8lqt"    : self.VV8lqt()
   elif item == "VVyVWq"   : self.VVyVWq()
   elif item == "VVeulY"   : self.VVeulY()
   elif item == "VVDn1u"    : self.VVDn1u()
   elif item == "PIconsTools"     : self.session.open(CCivOr)
   elif item == "ChannelsTools"    : self.session.open(CCUNoh)
 def VV8lqt(self) : self.VVoJzE(self.VVFSTb)
 def VVyVWq(self) : self.VVoJzE(self.VVnRow)
 def VVFy8j(self) : self.VVoJzE(self.VVXx1b)
 def VVoJzE(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFQYeU(self, boundFunction(self.VVAc5k, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVLwlS(self):
  filterObj = CCL9aY(self)
  filterObj.VVjegd(self.VV4nZF)
 def VV4nZF(self, item):
  self.VVAc5k(self.VVXx1b, item)
 def VVTPTV(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFfXHu(self.refCode)        : return False
  return True
 def VVAc5k(self, mode, VVtYvR):
  FFGw6o(self, boundFunction(self.VVgvy6, mode, VVtYvR), title="Searching ...")
 def VVgvy6(self, mode, VVtYvR):
  if VVtYvR:
   self.findTxt = VVtYvR
   if   mode == self.VVFSTb  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVnRow : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVtYvR)
   if len(title) > 55:
    title = title[:55] + ".."
   VVKPkH = self.VVkoTY(VVtYvR, servTypes)
   if self.isFindMode or mode == self.VVXx1b:
    VVKPkH += self.VVZQe9(VVtYvR)
   if VVKPkH:
    VVKPkH.sort(key=lambda x: x[0].lower())
    VV5NUw = self.VVHJ2o
    VVUydg  = ("Zap"   , self.VVBqTL    , [])
    VVYVXl = ("Current Service", self.VVsIvI , [])
    VVGGJN = ("Options"  , self.VV0xt1 , [])
    VVVLKj = (""    , self.VVslWe , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVB5ih  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF4eNC(self, None, title=title, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=25, VVUydg=VVUydg, VV5NUw=VV5NUw, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVVLKj=VVVLKj)
   else:
    self.VVoJzE(self.VVkiKO())
    FFGBS4(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVkoTY(self, VVtYvR, servTypes):
  VVUNsv  = eServiceCenter.getInstance()
  VVw5G9   = '%s ORDER BY name' % servTypes
  VVoYAl   = eServiceReference(VVw5G9)
  VViBwi = VVUNsv.list(VVoYAl)
  if VViBwi: VVcsAS = VViBwi.getContent("CN", False)
  else     : VVcsAS = None
  VVKPkH = []
  if VVcsAS:
   VVKXvi, VV5RVA = FF1pIA()
   tp   = CC2hod()
   words, asPrefix = CCL9aY.VVAGng(VVtYvR)
   colorYellow  = CCbagr.VVv8nt(VVEdAx)
   colorWhite  = CCbagr.VVv8nt(VVVF41)
   for s in VVcsAS:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFmWdo(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVKXvi:
        STYPE = VV5RVA[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV6AfP(refCode)
       if not "-S" in syst:
        sat = syst
       VVKPkH.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVKPkH
 def VVZQe9(self, VVtYvR):
  VVtYvR = VVtYvR.lower()
  VVTCY9 = FF80rj()
  VVKPkH = []
  colorYellow  = CCbagr.VVv8nt(VVEdAx)
  colorWhite  = CCbagr.VVv8nt(VVVF41)
  if VVTCY9:
   for b in VVTCY9:
    VVsOyw  = b[0]
    VVs3nl  = b[1].toString()
    VVsraV = eServiceReference(VVs3nl)
    VVD8xW = FFXWZI(VVsraV)
    for service in VVD8xW:
     refCode  = service[0]
     if FFfXHu(refCode):
      servName = service[1]
      if VVtYvR in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVtYvR), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVKPkH.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVKPkH
 def VVkiKO(self):
  VVymXU = InfoBar.instance
  if VVymXU:
   VV1fDc = VVymXU.servicelist
   if VV1fDc:
    return VV1fDc.mode == 1
  return self.VVXx1b
 def VVHJ2o(self, VVKvMM):
  self.close()
  VVKvMM.cancel()
 def VVBqTL(self, VVKvMM, title, txt, colList):
  FFlnjO(VVKvMM, colList[2], VV9Blm=False, checkParentalControl=True)
 def VVsIvI(self, VVKvMM, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(VVKvMM)
  if refCode:
   VVKvMM.VVz9TN(2, FFdy9m(refCode, iptvRef, chName), True)
 def VV0xt1(self, VVKvMM, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCmKBD(self, VVKvMM, 2)
  mSel.VVAT4S(servName, refCode)
 def VVslWe(self, VVKvMM, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFCpwr(self, fncMode=CCzK25.VVNvcb, refCode=refCode, chName=chName, text=txt)
 def VVeulY(self):
  FFRzxq(self, self.VV8JP2, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV8JP2(self):
  ret = FFQWXD(self.refCode, True)
  if ret:
   self.VVKPHs()
   self.close()
  else:
   FFngIP(self, "Cannot change state" , 1000)
 def VVKPHs(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV1W4V()
  except:
   self.VVx69V()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFvLNC(self, serviceRef)
 def VV8iNM(self):
  VVymXU = InfoBar.instance
  if VVymXU:
   VV1fDc = VVymXU.servicelist
   if VV1fDc:
    VV1fDc.setMode()
 def VV1W4V(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVymXU = InfoBar.instance
   if VVymXU:
    VV1fDc = VVymXU.servicelist
    if VV1fDc:
     hList = VV1fDc.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV1fDc.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV1fDc.history  = newList
       VV1fDc.history_pos = pos
 def VVx69V(self):
  VVymXU = InfoBar.instance
  if VVymXU:
   VV1fDc = VVymXU.servicelist
   if VV1fDc:
    VV1fDc.history  = []
    VV1fDc.history_pos = 0
 def VVDn1u(self):
  VVymXU = InfoBar.instance
  VVKPkH = []
  if VVymXU:
   VV1fDc = VVymXU.servicelist
   if VV1fDc:
    VVKXvi, VV5RVA = FF1pIA()
    for chParams in VV1fDc.history:
     refCode = chParams[-1].toString()
     chName = FFFRn9(refCode)
     isIptv = FFfXHu(refCode)
     if isIptv: sat = "-"
     else  : sat = FFmWdo(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVKXvi:
       STYPE = VV5RVA[sTypeInt]
     VVKPkH.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVKPkH:
   VVUydg  = ("Zap"   , self.VVyakT   , [])
   VVGGJN = ("Clear History" , self.VVTLhk   , [])
   VVVLKj = (""    , self.VVNCHuFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVB5ih  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF4eNC(self, None, title=title, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=23, VVUydg=VVUydg, VVGGJN=VVGGJN, VVVLKj=VVVLKj)
  else:
   FFGBS4(self, "Not found", title=title)
 def VVyakT(self, VVKvMM, title, txt, colList):
  FFlnjO(VVKvMM, colList[3], VV9Blm=False, checkParentalControl=True)
 def VVTLhk(self, VVKvMM, title, txt, colList):
  FFRzxq(self, boundFunction(self.VVnKXj, VVKvMM), "Clear Zap History ?")
 def VVnKXj(self, VVKvMM):
  self.VVx69V()
  VVKvMM.cancel()
 def VVNCHuFromZapHistory(self, VVKvMM, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFCpwr(self, fncMode=CCzK25.VVnpVD, refCode=refCode, chName=chName, text=txt)
class CCivOr(Screen):
 VVEzNW   = 0
 VVNRkw  = 1
 VVdSxt  = 2
 VVN4wk  = 3
 VVW6IH  = 4
 VVdPQ1  = 5
 VV9hQF  = 6
 VVRsh4  = 7
 VVcyd0 = 8
 VVAv3q = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFjy7Y(VVFpVB, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFwrVg(self, self.Title)
  FFh33U(self["keyRed"] , "OK = Zap")
  FFh33U(self["keyGreen"] , "Current Service")
  FFh33U(self["keyYellow"], "Page Options")
  FFh33U(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCivOr.VVHoxR()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVcsAS    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV8Ryj        ,
   "green"   : self.VVdpli       ,
   "yellow"  : self.VVJAqR        ,
   "blue"   : self.VVojue        ,
   "menu"   : self.VV6HeN        ,
   "info"   : self.VVNCHu         ,
   "up"   : self.VVZGKM          ,
   "down"   : self.VVYZh7         ,
   "left"   : self.VVzzRf         ,
   "right"   : self.VVmki0         ,
   "pageUp"  : boundFunction(self.VVuvJJ, True) ,
   "chanUp"  : boundFunction(self.VVuvJJ, True) ,
   "pageDown"  : boundFunction(self.VVuvJJ, False) ,
   "chanDown"  : boundFunction(self.VVuvJJ, False) ,
   "next"   : self.VVPDsT        ,
   "last"   : self.VVh2d1         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFgCHF(self)
  FF7zZI(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFGw6o(self, boundFunction(self.VVvt6R, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV6HeN(self):
  if not self.isBusy:
   VVpLvf = []
   VVpLvf.append(("Statistics"           , "VVwDNU"    ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Suggest PIcons for Current Channel"     , "VV1Faa"   ))
   VVpLvf.append(("Set to Current Channel (copy file)"     , "VVKxY6_file"  ))
   VVpLvf.append(("Set to Current Channel (as SymLink)"     , "VVKxY6_link"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(CCivOr.VVSYjP())
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVtgBq"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf += CCivOr.VVw6pp()
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("RCU Keys Help"          , "VVpeBV"    ))
   FFBYrC(self, self.VVemKe, title=self.Title, VVpLvf=VVpLvf)
 def VVemKe(self, item=None):
  if item is not None:
   if   item == "VVwDNU"     : self.VVwDNU()
   elif item == "VV1Faa"    : FFGw6o(self, self.VV1Faa, clearMsg=False)
   elif item == "VVKxY6_file"   : self.VVKxY6(0)
   elif item == "VVKxY6_link"   : self.VVKxY6(1)
   elif item == "VVSktL_file"  : self.VVSktL(0)
   elif item == "VVSktL_link"  : self.VVSktL(1)
   elif item == "VVXDtb"   : self.VVXDtb()
   elif item == "VVDMDY"  : self.VVDMDY()
   elif item == "VVbz87"   : self.VVbz87()
   elif item == "VVtgBq"   : self.VVtgBq()
   elif item == "VVwOwu"   : CCivOr.VVwOwu(self)
   elif item == "VVIJ88"   : CCivOr.VVIJ88(self)
   elif item == "findPiconBrokenSymLinks"  : CCivOr.VVrLx7(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCivOr.VVrLx7(self, False)
   elif item == "VVpeBV"      : self.VVpeBV()
 def VVJAqR(self):
  if not self.isBusy:
   VVpLvf = []
   VVpLvf.append(("Go to First PIcon"  , "VV6u7i"  ))
   VVpLvf.append(("Go to Last PIcon"   , "VV3zEI"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Sort by Channel Name"     , "sortByChan" ))
   VVpLvf.append(("Sort by File Name"  , "sortByFile" ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Find from File List .." , "VVCzkw" ))
   FFBYrC(self, self.VVRYu5, title=self.Title, VVpLvf=VVpLvf)
 def VVRYu5(self, item=None):
  if item is not None:
   if   item == "VV6u7i"   : self.VV6u7i()
   elif item == "VV3zEI"   : self.VV3zEI()
   elif item == "sortByChan"  : self.VVgNYI(2)
   elif item == "sortByFile"  : self.VVgNYI(0)
   elif item == "VVCzkw"  : self.VVCzkw()
 def VVpeBV(self):
  FFkrGj(self, VVmF17 + "_help_picons", "PIcons Manager (Keys Help)")
 def VVZGKM(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV3zEI()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVbhZH()
 def VVYZh7(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV6u7i()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVbhZH()
 def VVzzRf(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV3zEI()
  else:
   self.curCol -= 1
   self.VVbhZH()
 def VVmki0(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV6u7i()
  else:
   self.curCol += 1
   self.VVbhZH()
 def VVh2d1(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVbhZH(True)
 def VVPDsT(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVbhZH(True)
 def VV6u7i(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVbhZH(True)
 def VV3zEI(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVbhZH(True)
 def VVCzkw(self):
  VVpLvf = []
  for item in self.VVcsAS:
   VVpLvf.append((item[0], item[0]))
  FFBYrC(self, self.VVkqCZ, title='PIcons ".png" Files', VVpLvf=VVpLvf, VV8NFf=True)
 def VVkqCZ(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVsHui(ndx)
 def VV8Ryj(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVlBeS()
   if refCode:
    FFlnjO(self, refCode)
    self.VVVTwc()
    self.VV6l3z()
 def VVuvJJ(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVVTwc()
   self.VV6l3z()
  except:
   pass
 def VVdpli(self):
  if self["keyGreen"].getVisible():
   self.VVsHui(self.curChanIndex)
 def VVsHui(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVbhZH(True)
  else:
   FFngIP(self, "Not found", 1000)
 def VVgNYI(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFGw6o(self, boundFunction(self.VVvt6R, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVKxY6(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVlBeS()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVpLvf = []
     VVpLvf.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVpLvf.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFBYrC(self, boundFunction(self.VVy7t5, mode, curChF, selPiconF), VVpLvf=VVpLvf, title="Current Channel PIcon (already exists)")
    else:
     self.VVy7t5(mode, curChF, selPiconF, "overwrite")
   else:
    FFCwHk(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFCwHk(self, "Could not read current channel info. !", title=title)
 def VVy7t5(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFGw6o(self, boundFunction(self.VVvt6R, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVSktL(self, mode):
  pass
 def VVXDtb(self):
  pass
 def VVDMDY(self):
  pass
 def VVbz87(self):
  pass
 def VVtgBq(self):
  lines = FFzFRs("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFRzxq(self, boundFunction(self.VVXT3H, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVpF7d=True)
  else:
   FFGBS4(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVXT3H(self, fList):
  os.system(FFfUI2("find -L '%s' -type l -delete" % self.pPath))
  FFGBS4(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVNCHu(self):
  FFGw6o(self, self.VVbiGD)
 def VVbiGD(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVlBeS()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFXMyR("PIcon Directory:\n", VV7ect)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFpgzO(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFpgzO(path)
   txt += FFXMyR("PIcon File:\n", VV7ect)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFzFRs(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFXMyR("Found %d SymLink%s to this file from:\n" % (tot, s), VV7ect)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFFRn9(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFXMyR(tChName, VVJH5T)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFXMyR(line, VVsWXS), tChName)
    txt += "\n"
   if chName:
    txt += FFXMyR("Channel:\n", VV7ect)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFXMyR(chName, VVJH5T)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFXMyR("Remarks:\n", VV7ect)
    txt += "  %s\n" % FFXMyR("Unused", VViuIz)
  else:
   txt = "No info found"
  FFCpwr(self, fncMode=CCzK25.VV6SoG, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVlBeS(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVcsAS[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFIwV7(sat)
  return fName, refCode, chName, sat, inDB
 def VVVTwc(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVcsAS):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV6l3z(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVlBeS()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFXMyR("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV7ect))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVlBeS()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFXMyR(self.curChanName, VVEdAx)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVwDNU(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVcsAS:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFeABk("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFWUy2(self, txt, title=self.Title)
 def VVojue(self):
  if not self.isBusy:
   VVpLvf = []
   VVpLvf.append(("All"         , "all"   ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("Used by Channels"      , "used"  ))
   VVpLvf.append(("Unused PIcons"      , "unused"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("PIcons Files"       , "pFiles"  ))
   VVpLvf.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVpLvf.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVpLvf.append(VVkUZg)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFkB7Z(val)
      VVpLvf.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCL9aY(self)
   filterObj.VVuaom(VVpLvf, self.nsList, self.VVQ5gM)
 def VVQ5gM(self, item=None):
  if item is not None:
   self.VVURYc(item)
 def VVURYc(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVEzNW   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVNRkw   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVdSxt  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVN4wk  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVW6IH  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVdPQ1  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV9hQF   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVRsh4   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVcyd0 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVdPQ1:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFzFRs("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFngIP(self, "Not found", 1000)
     return
   elif mode == self.VVAv3q:
    return
   else:
    words, asPrefix = CCL9aY.VVAGng(words)
   if not words and mode in (self.VVRsh4, self.VVcyd0):
    FFngIP(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFGw6o(self, boundFunction(self.VVvt6R, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VV1Faa(self):
  FFngIP(self, "Loading Channels ...")
  lameDbChans = CCUNoh.VVFF4N(self, CCUNoh.VVpBvr, VVC4in=False, VVwyJo=False)
  files = []
  words = []
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCivOr.VViQnn(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCivOr.VVOA8c(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       words.append(f.replace(".png", ""))
  if words:
   FFGw6o(self, boundFunction(self.VVvt6R, mode=self.VVAv3q, words=words), title="Filtering ...", clearMsg=False)
  else:
   FFngIP(self, "Not found", 1000)
 def VVvt6R(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VV3p8e(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCUNoh.VVFF4N(self, CCUNoh.VVpBvr, VVC4in=False, VVwyJo=False)
  iptvRefList = self.VVeKBN()
  tList = []
  for fName, fType in CCivOr.VVXZs1(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVEzNW:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVNRkw  and chName         : isAdd = True
   elif mode == self.VVdSxt and not chName        : isAdd = True
   elif mode == self.VVN4wk  and fType == 0        : isAdd = True
   elif mode == self.VVW6IH  and fType == 1        : isAdd = True
   elif mode == self.VVdPQ1  and fName in words       : isAdd = True
   elif mode == self.VVAv3q and fName in words       : isAdd = True
   elif mode == self.VV9hQF  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVRsh4  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVcyd0:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVcsAS   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFngIP(self)
  else:
   self.isBusy = False
   FFngIP(self, "Not found", 1000)
   return
  self.VVcsAS.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVVTwc()
  self.totalPIcons = len(self.VVcsAS)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVbhZH(True)
 def VV3p8e(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCivOr.VVXZs1(self.pPath):
    if fName:
     return True
   if isFirstTime : FFCwHk(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFngIP(self, "Not found", 1000)
  else:
   FFCwHk(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVeKBN(self):
  VVKPkH = {}
  files  = CCDch1.VVDEr7(self)
  if files:
   for path in files:
    txt = FFItSN(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVKPkH[refCode] = item[1]
  return VVKPkH
 def VVbhZH(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVNA7i = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVNA7i: self.curPage = VVNA7i
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVePfR()
  if self.curPage == VVNA7i:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VV6l3z()
  filName, refCode, chName, sat, inDB = self.VVlBeS()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVePfR(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVcsAS[ndx]
   fName = self.VVcsAS[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFXMyR(chName, VVJH5T))
    else : lbl.setText("-")
   except:
    lbl.setText(FFXMyR(chName, VV2SpG))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VViQnn(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVSYjP():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVwOwu"   )
 @staticmethod
 def VVw6pp():
  VVpLvf = []
  VVpLvf.append(("Find SymLinks (to PIcon Directory)"   , "VVIJ88"   ))
  VVpLvf.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVpLvf.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVpLvf
 @staticmethod
 def VVwOwu(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(SELF)
  png, path = CCivOr.VVdOMu(refCode)
  if path : CCivOr.VVC88Q(SELF, png, path)
  else : FFCwHk(SELF, "No PIcon found for current channel in:\n\n%s" % CCivOr.VVHoxR())
 @staticmethod
 def VVIJ88(SELF):
  if VVEdAx:
   sed1 = FFb5eo("->", VVEdAx)
   sed2 = FFb5eo("picon", VViuIz)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV2SpG, VVVF41)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF1HQ0(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFphRM(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVrLx7(SELF, isPIcon):
  sed1 = FFb5eo("->", VV2SpG)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFb5eo("picon", VViuIz)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF1HQ0(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFphRM(), grep, sed1, sed2))
 @staticmethod
 def VVXZs1(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVHoxR():
  path = CFG.PIconsPath.getValue()
  return FFUUJW(path)
 @staticmethod
 def VVdOMu(refCode, chName=None):
  if FFfXHu(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFvanf(refCode)
  allPath, fName, refCodeFile, pList = CCivOr.VVOA8c(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVC88Q(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFb5eo("%s%s" % (dest, png), VVJH5T))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFb5eo(errTxt, VVZapb))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFTQP2(SELF, cmd)
 @staticmethod
 def VVOA8c(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCivOr.VVHoxR()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFAwDH(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CClwua():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVYpAN  = None
  self.VVvQrr = ""
  self.VVhAl3  = noService
  self.VVhdej = 0
  self.VVA7Xi  = noService
  self.VVaO5p = 0
  self.VVzNOU  = "-"
  self.VV9gY2 = 0
  self.VVF8NY  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVSGEO(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVYpAN = frontEndStatus
     self.VVioBp()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVioBp(self):
  if self.VVYpAN:
   val = self.VVYpAN.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVvQrr = "%3.02f dB" % (val / 100.0)
   else         : self.VVvQrr = ""
   val = self.VVYpAN.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVhdej = int(val)
   self.VVhAl3  = "%d%%" % val
   val = self.VVYpAN.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVaO5p = int(val)
   self.VVA7Xi  = "%d%%" % val
   val = self.VVYpAN.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVzNOU  = "%d" % val
   val = int(val * 100 / 500)
   self.VV9gY2 = min(500, val)
   val = self.VVYpAN.get("tuner_locked", 0)
   if val == 1 : self.VVF8NY = "Locked"
   else  : self.VVF8NY = "Not locked"
 def VVhbos(self)   : return self.VVvQrr
 def VVWfui(self)   : return self.VVhAl3
 def VVvQvf(self)  : return self.VVhdej
 def VV3V27(self)   : return self.VVA7Xi
 def VVaouH(self)  : return self.VVaO5p
 def VV5raA(self)   : return self.VVzNOU
 def VVtAoC(self)  : return self.VV9gY2
 def VVcvzL(self)   : return self.VVF8NY
 def VVSLhu(self) : return self.serviceName
class CC2hod():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVligN(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFcRVw(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV0JnS(self.ORPOS  , mod=1   )
      self.sat2  = self.VV0JnS(self.ORPOS  , mod=2   )
      self.freq  = self.VV0JnS(self.FREQ  , mod=3   )
      self.sr   = self.VV0JnS(self.SR   , mod=4   )
      self.inv  = self.VV0JnS(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV0JnS(self.POL  , self.D_POL )
      self.fec  = self.VV0JnS(self.FEC  , self.D_FEC )
      self.syst  = self.VV0JnS(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV0JnS("modulation" , self.D_MOD )
       self.rolof = self.VV0JnS("rolloff"  , self.D_ROLOF )
       self.pil = self.VV0JnS("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV0JnS("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV0JnS("pls_code"  )
       self.iStId = self.VV0JnS("is_id"   )
       self.t2PlId = self.VV0JnS("t2mi_plp_id" )
       self.t2PId = self.VV0JnS("t2mi_pid"  )
 def VV0JnS(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFkB7Z(val)
  elif mod == 2   : return FFiKgb(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVnW0N(self, refCode):
  txt = ""
  self.VVligN(refCode)
  if self.data:
   def VVC8uD(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVC8uD("System"   , self.syst)
    txt += VVC8uD("Satellite"  , self.sat2)
    txt += VVC8uD("Frequency"  , self.freq)
    txt += VVC8uD("Inversion"  , self.inv)
    txt += VVC8uD("Symbol Rate"  , self.sr)
    txt += VVC8uD("Polarization" , self.pol)
    txt += VVC8uD("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVC8uD("Modulation" , self.mod)
     txt += VVC8uD("Roll-Off" , self.rolof)
     txt += VVC8uD("Pilot"  , self.pil)
     txt += VVC8uD("Input Stream", self.iStId)
     txt += VVC8uD("T2MI PLP ID" , self.t2PlId)
     txt += VVC8uD("T2MI PID" , self.t2PId)
     txt += VVC8uD("PLS Mode" , self.plsMod)
     txt += VVC8uD("PLS Code" , self.plsCod)
   else:
    txt += VVC8uD("System"   , self.txMedia)
    txt += VVC8uD("Frequency"  , self.freq)
  return txt, self.namespace
 def VVU7EH(self, refCode):
  txt = "Transpoder : ?"
  self.VVligN(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV7ect + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VV6AfP(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFcRVw(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV0JnS(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV0JnS(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV0JnS(self.SYST, self.D_SYS_S)
     freq = self.VV0JnS(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV0JnS(self.POL , self.D_POL)
      fec = self.VV0JnS(self.FEC , self.D_FEC)
      sr = self.VV0JnS(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV7aJX(self, refCode):
  self.data = None
  self.VVligN(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC9jZC():
 def __init__(self, VVWx0O, path, VVcWME=None, curRowNum=-1):
  self.VVWx0O  = VVWx0O
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVcWME  = VVcWME
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFfUI2("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVlwu0(curRowNum)
  else:
   FFCwHk(self.VVWx0O, "Error while preparing edit!")
 def VVlwu0(self, curRowNum):
  VVKPkH = self.VVGw9I()
  VVKuXf = None #("Delete Line" , self.deleteLine  , [])
  VVYVXl = ("Save Changes" , self.VVvZU5   , [])
  VVUydg  = ("Edit Line"  , self.VVlD6a    , [])
  VVmwc1 = ("Line Options" , self.VVQmzD   , [])
  VVbDGl = (""    , self.VVqpaL , [])
  VV5NUw = self.VVbTfI
  VVtbiA  = self.VVSyOj
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVB5ih  = (CENTER  , LEFT  )
  VVKvMM = FF4eNC(self.VVWx0O, None, title=self.Title, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=24, VVKuXf=VVKuXf, VVYVXl=VVYVXl, VVUydg=VVUydg, VVmwc1=VVmwc1, VV5NUw=VV5NUw, VVtbiA=VVtbiA, VVbDGl=VVbDGl, VVO8ee=True
    , VVysAl   = "#11001111"
    , VVkHTQ   = "#11001111"
    , VVrOep   = "#11001111"
    , VVjLvZ  = "#05333333"
    , VV0jUQ  = "#00222222"
    , VVrGMe  = "#11331133"
    )
  VVKvMM.VV28DA(curRowNum)
 def VVQmzD(self, VVKvMM, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVKvMM.VVpmrk()
  VVpLvf = []
  VVpLvf.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVpLvf.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVV02y"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVYka2:
   VVpLvf.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(  ("Delete Line"         , "deleteLine"   ))
  FFBYrC(self.VVWx0O, boundFunction(self.VVK2Ww, VVKvMM, lineNum), VVpLvf=VVpLvf, title="Line Options")
 def VVK2Ww(self, VVKvMM, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVSlkv("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVKvMM)
   elif item == "VVV02y"  : self.VVV02y(VVKvMM, lineNum)
   elif item == "copyToClipboard"  : self.VV5sko(VVKvMM, lineNum)
   elif item == "pasteFromClipboard" : self.VVE2Dr(VVKvMM, lineNum)
   elif item == "deleteLine"   : self.VVSlkv("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVKvMM)
 def VVSyOj(self, VVKvMM):
  VVKvMM.VVvIxK()
 def VVqpaL(self, VVKvMM, title, txt, colList):
  if   self.insertMode == 1: VVKvMM.VVaPB8()
  elif self.insertMode == 2: VVKvMM.VVRHOy()
  self.insertMode = 0
 def VVV02y(self, VVKvMM, lineNum):
  if lineNum == VVKvMM.VVpmrk():
   self.insertMode = 1
   self.VVSlkv("echo '' >> '%s'" % self.tmpFile, VVKvMM)
  else:
   self.insertMode = 2
   self.VVSlkv("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVKvMM)
 def VV5sko(self, VVKvMM, lineNum):
  global VVYka2
  VVYka2 = FFeABk("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVKvMM.VVglk9("Copied to clipboard")
 def VVvZU5(self, VVKvMM, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFfUI2("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFfUI2("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVKvMM.VVglk9("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVKvMM.VVvIxK()
    else:
     FFCwHk(self.VVWx0O, "Cannot save file!")
   else:
    FFCwHk(self.VVWx0O, "Cannot create backup copy of original file!")
 def VVbTfI(self, VVKvMM):
  if self.fileChanged:
   FFRzxq(self.VVWx0O, boundFunction(self.VVnbsZ, VVKvMM), "Cancel changes ?")
  else:
   finalOK = os.system(FFfUI2("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVnbsZ(VVKvMM)
 def VVnbsZ(self, VVKvMM):
  VVKvMM.cancel()
  os.system(FFfUI2("rm -f '%s'" % self.tmpFile))
  if self.VVcWME:
   self.VVcWME(self.fileSaved)
 def VVlD6a(self, VVKvMM, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVVF41 + "ORIGINAL TEXT:\n" + VVsWXS + lineTxt
  FFQYeU(self.VVWx0O, boundFunction(self.VVxb6W, lineNum, VVKvMM), title="File Line", defaultText=lineTxt, message=message)
 def VVxb6W(self, lineNum, VVKvMM, VV0ZSY):
  if not VV0ZSY is None:
   if VVKvMM.VVpmrk() <= 1:
    self.VVSlkv("echo %s > '%s'" % (VV0ZSY, self.tmpFile), VVKvMM)
   else:
    self.VVsnJT(VVKvMM, lineNum, VV0ZSY)
 def VVE2Dr(self, VVKvMM, lineNum):
  if lineNum == VVKvMM.VVpmrk() and VVKvMM.VVpmrk() == 1:
   self.VVSlkv("echo %s >> '%s'" % (VVYka2, self.tmpFile), VVKvMM)
  else:
   self.VVsnJT(VVKvMM, lineNum, VVYka2)
 def VVsnJT(self, VVKvMM, lineNum, newTxt):
  VVKvMM.VVfTev("Saving ...")
  lines = FFawFw(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVKvMM.VV1XEK()
  VVKPkH = self.VVGw9I()
  VVKvMM.VV32hv(VVKPkH)
 def VVSlkv(self, cmd, VVKvMM):
  tCons = CCsT2Q()
  tCons.ePopen(cmd, boundFunction(self.VVV97H, VVKvMM))
  self.fileChanged = True
  VVKvMM.VV1XEK()
 def VVV97H(self, VVKvMM, result, retval):
  VVKPkH = self.VVGw9I()
  VVKvMM.VV32hv(VVKPkH)
 def VVGw9I(self):
  if fileExists(self.tmpFile):
   lines = FFawFw(self.tmpFile)
   VVKPkH = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVKPkH.append((str(ndx), line.strip()))
   if not VVKPkH:
    VVKPkH.append((str(1), ""))
   return VVKPkH
  else:
   FFurlj(self.VVWx0O, self.tmpFile)
class CCL9aY():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVpLvf   = []
  self.satList   = []
 def VVjegd(self, VVcWME):
  self.VVpLvf = []
  VVpLvf, VVCAwM = self.VVyAzT(False, True)
  if VVpLvf:
   self.VVpLvf += VVpLvf
   self.VVoODK(VVcWME, VVCAwM)
 def VV0aHE(self, mode, VVKvMM, satCol, VVcWME):
  VVKvMM.VVfTev("Loading Filters ...")
  self.VVpLvf = []
  self.VVpLvf.append(("All Services" , "all"))
  if mode == 1:
   self.VVpLvf.append(VVkUZg)
   self.VVpLvf.append(("Parental Control", "parentalControl"))
   self.VVpLvf.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVpLvf.append(VVkUZg)
   self.VVpLvf.append(("Selected Transponder"   , "selectedTP" ))
   self.VVpLvf.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVCnmo(VVKvMM, satCol)
  VVpLvf, VVCAwM = self.VVyAzT(True, False)
  if VVpLvf:
   VVpLvf.insert(0, VVkUZg)
   self.VVpLvf += VVpLvf
  VVKvMM.VV5aRa()
  self.VVoODK(VVcWME, VVCAwM)
 def VVuaom(self, VVpLvf, sats, VVcWME):
  self.VVpLvf = VVpLvf
  VVpLvf, VVCAwM = self.VVyAzT(True, False)
  if VVpLvf:
   self.VVpLvf.append(VVkUZg)
   self.VVpLvf += VVpLvf
  self.VVoODK(VVcWME, VVCAwM)
 def VVAl33(self, VVpLvf, sats, VVcWME):
  self.VVpLvf = VVpLvf
  VVpLvf, VVCAwM = self.VVyAzT(True, False)
  if VVpLvf:
   self.VVpLvf.append(VVkUZg)
   self.VVpLvf += VVpLvf
  self.VVoODK(VVcWME, VVCAwM)
 def VVoODK(self, VVcWME, VVCAwM):
  VVgMyE = ("Edit Filter", boundFunction(self.VVMQfu, VVCAwM))
  VVKjVK  = ("Filter Help", boundFunction(self.VVtmVy, VVCAwM))
  FFBYrC(self.callingSELF, boundFunction(self.VV13VI, VVcWME), VVpLvf=self.VVpLvf, title="Select Filter", VVgMyE=VVgMyE, VVKjVK=VVKjVK)
 def VV13VI(self, VVcWME, item):
  if item:
   VVcWME(item)
 def VVMQfu(self, VVCAwM, VVupR7Obj, sel):
  if fileExists(VVCAwM) : CC9jZC(self.callingSELF, VVCAwM, VVcWME=None)
  else       : FFurlj(self.callingSELF, VVCAwM)
  VVupR7Obj.cancel()
 def VVtmVy(self, VVCAwM, VVupR7Obj, sel):
  FFkrGj(self.callingSELF, VVmF17 + "_help_service_filter", "Service Filter")
 def VVCnmo(self, VVKvMM, satColNum):
  if not self.satList:
   satList = VVKvMM.VVnmq9(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFIwV7(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVkUZg)
  if self.VVpLvf:
   self.VVpLvf += self.satList
 def VVyAzT(self, addTag, VVDTOG):
  FFk2O3()
  fileName  = "ajpanel_services_filter"
  VVCAwM = VV2Mhn + fileName
  VVpLvf  = []
  if not fileExists(VVCAwM):
   os.system(FFfUI2("cp -f '%s' '%s'" % (VVmF17 + fileName, VVCAwM)))
  fileFound = False
  if fileExists(VVCAwM):
   fileFound = True
   lines = FFawFw(VVCAwM)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVpLvf.append((line, "__w__" + line))
       else  : VVpLvf.append((line, line))
  if VVDTOG:
   if   not fileFound : FFurlj(self.callingSELF , VVCAwM)
   elif not VVpLvf : FF4fts(self.callingSELF , VVCAwM)
  return VVpLvf, VVCAwM
 @staticmethod
 def VVAGng(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCmKBD():
 def __init__(self, callingSELF, VVKvMM, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVKvMM = VVKvMM
  self.refCodeColNum = refCodeColNum
  self.VVpLvf = []
  iMulSel = self.VVKvMM.VV1Kxv()
  if iMulSel : self.VVpLvf.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVpLvf.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVKvMM.VVHL4W()
  self.VVpLvf.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVpLvf.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVpLvf.append(VVkUZg)
 def VVAT4S(self, servName, refCode):
  tot = self.VVKvMM.VVHL4W()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVpLvf.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVpDjL_multi" ))
  else    : self.VVpLvf.append( ("Add to Bouquet : %s"      % servName , "VVpDjL_one" ))
  self.VVZNl8(servName, refCode)
 def VVxiVU(self, servName, refCode, pcState, hidState):
  self.VVpLvf = []
  if pcState == "No" : self.VVpLvf.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVpLvf.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVpLvf.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVpLvf.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVZNl8(servName, refCode)
 def VVZNl8(self, servName, refCode):
  FFBYrC(self.callingSELF, boundFunction(self.VV7OpD, servName, refCode), title="Options", VVpLvf=self.VVpLvf)
 def VV7OpD(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVKvMM.VViBLa(True)
   elif item == "MultSelDisab"    : self.VVKvMM.VViBLa(False)
   elif item == "selectAll"    : self.VVKvMM.VVBCuh()
   elif item == "unselectAll"    : self.VVKvMM.VVBo0O()
   elif item == "parentalControl_add"  : self.callingSELF.VVLtwv(self.VVKvMM, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVLtwv(self.VVKvMM, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVBg7f(self.VVKvMM, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVBg7f(self.VVKvMM, refCode, False)
   elif item == "VVpDjL_multi" : self.VVpDjL(refCode, True)
   elif item == "VVpDjL_one" : self.VVpDjL(refCode, False)
 def VVpDjL(self, refCode, isMulti):
  bouquets = FF80rj()
  if bouquets:
   VVpLvf = []
   for item in bouquets:
    VVpLvf.append((item[0], item[1].toString()))
   VVgMyE = ("Create New", boundFunction(self.VVg1Gz, refCode, isMulti))
   FFBYrC(self.callingSELF, boundFunction(self.VVZADu, refCode, isMulti), VVpLvf=VVpLvf, title="Add to Bouquet", VVgMyE=VVgMyE, VV8NFf=True, VVBCDk=True)
  else:
   FFRzxq(self.callingSELF, boundFunction(self.VVG3l3, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVZADu(self, refCode, isMulti, bName=None):
  if bName:
   FFGw6o(self.VVKvMM, boundFunction(self.VV1dlT, refCode, isMulti, bName), title="Adding Channels ...")
 def VV1dlT(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVMQyT(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVymXU = InfoBar.instance
    if VVymXU:
     VV1fDc = VVymXU.servicelist
     if VV1fDc:
      mutableList = VV1fDc.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVKvMM.VV5aRa()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFGBS4(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFCwHk(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVMQyT(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVKvMM.VVdgSJ(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVg1Gz(self, refCode, isMulti, VVupR7Obj, path):
  self.VVG3l3(refCode, isMulti)
 def VVG3l3(self, refCode, isMulti):
  FFQYeU(self.callingSELF, boundFunction(self.VVJmjj, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVJmjj(self, refCode, isMulti, name):
  if name:
   FFGw6o(self.VVKvMM, boundFunction(self.VV7SUE, refCode, isMulti, name), title="Adding Channels ...")
 def VV7SUE(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVMQyT(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVymXU = InfoBar.instance
    if VVymXU:
     VV1fDc = VVymXU.servicelist
     if VV1fDc:
      try:
       VV1fDc.addBouquet(name, services)
       allOK = True
      except:
       try:
        VV1fDc.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVKvMM.VV5aRa()
   title = "Add to Bouquet"
   if allOK: FFGBS4(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFCwHk(self.callingSELF, "Nothing added!", title=title)
class CC9eIE(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVCv3m, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFwrVg(self)
  FFh33U(self["keyRed"]  , "Exit")
  FFh33U(self["keyGreen"]  , "Save")
  FFh33U(self["keyYellow"] , "Refresh")
  FFh33U(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVf0I3  ,
   "green"   : self.VVFqUz ,
   "yellow"  : self.VVG1VA  ,
   "blue"   : self.VVFFZR   ,
   "up"   : self.VVZGKM    ,
   "down"   : self.VVYZh7   ,
   "left"   : self.VVzzRf   ,
   "right"   : self.VVmki0   ,
   "cancel"  : self.VVf0I3
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVG1VA()
  self.VVj6zG()
  FFgCHF(self)
 def VVf0I3(self) : self.close(True)
 def VV5jg5(self) : self.close(False)
 def VVFFZR(self):
  self.session.openWithCallback(self.VV3QJr, boundFunction(CC7avm))
 def VV3QJr(self, closeAll):
  if closeAll:
   self.close()
 def VVZGKM(self):
  self.VVekOF(1)
 def VVYZh7(self):
  self.VVekOF(-1)
 def VVzzRf(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVj6zG()
 def VVmki0(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVj6zG()
 def VVekOF(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV7Hn9(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV7Hn9(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV7Hn9(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVnibY(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVnibY(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVj6zG(self):
  for obj in self.list:
   FF7zZI(obj, "#11404040")
  FF7zZI(self.list[self.index], "#11ff8000")
 def VVG1VA(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVFqUz(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCsT2Q()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV67Ro)
 def VV67Ro(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFGBS4(self, "Nothing returned from the system!")
  else:
   FFGBS4(self, str(result))
class CC7avm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VVp4lb, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFwrVg(self, addLabel=True)
  FFh33U(self["keyRed"]  , "Exit")
  FFh33U(self["keyGreen"]  , "Sync")
  FFh33U(self["keyYellow"] , "Refresh")
  FFh33U(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVf0I3   ,
   "green"   : self.VVlEoi  ,
   "yellow"  : self.VVEEP9 ,
   "blue"   : self.VViNku  ,
   "cancel"  : self.VVf0I3
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVvugi()
  self.onShow.append(self.start)
 def start(self):
  FFXHmb(self.refresh)
  FFgCHF(self)
 def refresh(self):
  self.VVKeSe()
  self.VVsQAR(False)
 def VVf0I3(self)  : self.close(True)
 def VViNku(self) : self.close(False)
 def VVvugi(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVKeSe(self):
  self.VVStMF()
  self.VVnVyn()
  self.VV5pmy()
  self.VV7QGT()
 def VVEEP9(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVvugi()
   self.VVKeSe()
   FFXHmb(self.refresh)
 def VVlEoi(self):
  if len(self["keyGreen"].getText()) > 0:
   FFRzxq(self, self.VV42cm, "Synchronize with Internet Date/Time ?")
 def VV42cm(self):
  self.VVKeSe()
  FFXHmb(boundFunction(self.VVsQAR, True))
 def VVStMF(self)  : self["keyRed"].show()
 def VVtqlM(self)  : self["keyGreen"].show()
 def VVWMux(self) : self["keyYellow"].show()
 def VVgOfp(self)  : self["keyBlue"].show()
 def VVnVyn(self)  : self["keyGreen"].hide()
 def VV5pmy(self) : self["keyYellow"].hide()
 def VV7QGT(self)  : self["keyBlue"].hide()
 def VVsQAR(self, sync):
  localTime = FFRY1H()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVtOU0(server)
   if epoch_time is not None:
    ntpTime = FFSqAc(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCsT2Q()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VV67Ro, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVWMux()
  self.VVgOfp()
  if ok:
   self.VVtqlM()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV67Ro(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVsQAR(False)
  except:
   pass
 def VVtOU0(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFZ5eQ():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCFJhR(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFjy7Y(VV7Jfd, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFwrVg(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFXHmb(self.VVlHCi)
 def VVlHCi(self):
  if FFZ5eQ(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF7zZI(self["myBody"], color)
   FF7zZI(self["myLabel"], color)
  except:
   pass
class CCGRG9(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFGYXd()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFjy7Y(VVOzvB, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCYhhc(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCYhhc(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCYhhc(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CClwua()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFwrVg(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVZGKM          ,
   "down"  : self.VVYZh7         ,
   "left"  : self.VVzzRf         ,
   "right"  : self.VVmki0         ,
   "info"  : self.VV8LXo        ,
   "epg"  : self.VV8LXo        ,
   "menu"  : self.VVpeBV         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVJr92, -1)  ,
   "next"  : boundFunction(self.VVJr92, 1)  ,
   "pageUp" : boundFunction(self.VVqUeO, True) ,
   "chanUp" : boundFunction(self.VVqUeO, True) ,
   "pageDown" : boundFunction(self.VVqUeO, False) ,
   "chanDown" : boundFunction(self.VVqUeO, False) ,
   "0"   : boundFunction(self.VVJr92, 0)  ,
   "1"   : boundFunction(self.VVgoHD, pos=1) ,
   "2"   : boundFunction(self.VVgoHD, pos=2) ,
   "3"   : boundFunction(self.VVgoHD, pos=3) ,
   "4"   : boundFunction(self.VVgoHD, pos=4) ,
   "5"   : boundFunction(self.VVgoHD, pos=5) ,
   "6"   : boundFunction(self.VVgoHD, pos=6) ,
   "7"   : boundFunction(self.VVgoHD, pos=7) ,
   "8"   : boundFunction(self.VVgoHD, pos=8) ,
   "9"   : boundFunction(self.VVgoHD, pos=9) ,
  }, -1)
  self.onShown.append(self.VVH8dW)
  self.onClose.append(self.onExit)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self.sliderSNR.VVe4RB()
  self.sliderAGC.VVe4RB()
  self.sliderBER.VVe4RB(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVgoHD()
  self.VVr69lInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVr69l)
  except:
   self.timer.callback.append(self.VVr69l)
  self.timer.start(500, False)
 def VVr69lInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVSGEO(service)
  serviceName = self.tunerInfo.VVSLhu()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  tp = CC2hod()
  txt = tp.VVU7EH(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVr69l(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVSGEO(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVhbos())
   self["mySNR"].setText(self.tunerInfo.VVWfui())
   self["myAGC"].setText(self.tunerInfo.VV3V27())
   self["myBER"].setText(self.tunerInfo.VV5raA())
   self.sliderSNR.VVZxDr(self.tunerInfo.VVvQvf())
   self.sliderAGC.VVZxDr(self.tunerInfo.VVaouH())
   self.sliderBER.VVZxDr(self.tunerInfo.VVtAoC())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVZxDr(0)
   self.sliderAGC.VVZxDr(0)
   self.sliderBER.VVZxDr(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
    if state and not state == "Tuned":
     FFngIP(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VV8LXo(self):
  FFCpwr(self, fncMode=CCzK25.VVaUdk)
 def VVpeBV(self):
  FFkrGj(self, VVmF17 + "_help_signal", "Signal Monitor (Keys)")
 def VVZGKM(self)  : self.VVgoHD(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVYZh7(self) : self.VVgoHD(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVzzRf(self) : self.VVgoHD(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVmki0(self) : self.VVgoHD(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVgoHD(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVJr92(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFczNY(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVqUeO(self, isUp):
  FFngIP(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVr69lInfo()
  except:
   pass
class CCYhhc(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVe4RB(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF7zZI(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVmF17 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF7zZI(self.covObj, self.covColor)
   else:
    FF7zZI(self.covObj, "#00006688")
    self.isColormode = True
  self.VVZxDr(0)
 def VVZxDr(self, val):
  val  = FFczNY(val, self.minN, self.maxN)
  width = int(FFsWbs(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFczNY(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCLTq8(Screen):
 VVq2B4    = 0
 VVaDMy = 1
 VVWaxI = 2
 def __init__(self, session, titlePrefix="Processing", fncToRun=None, VVcWME=None, barTheme=VVq2B4):
  ratio = self.VV2E6s(barTheme)
  self.skin, self.skinParam = FFjy7Y(VVY735, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.fncToRun  = fncToRun
  self.VVcWME = VVcWME
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 1
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVRQiU = None
  self.isUpdTitle  = False
  self.timer   = eTimer()
  self.myThread  = None
  FFwrVg(self, title="Processing ...")
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVH8dW)
  self.onClose.append(self.onExit)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self.VVb18s()
  FF7zZI(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVn9CP()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVn9CP)
  except:
   self.timer.callback.append(self.VVn9CP)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="threadFnc", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVINqi(self, val):
  self.maxValue = val
  self.isUpdTitle = True
 def VVS6ex(self, title):
  self.isUpdTitle = False
  self["myTitle"].setText("  " + title + "  ")
 def VVsgjw(self, addVal):
  self.counter += addVal
 def VV102L(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFngIP(self, "Cancelling ...")
  self.isCancelled = True
  if self.VVcWME:
   self.VVcWME(False, self.VVRQiU, self.counter, self.maxValue, self.isError)
  self.close()
 def VVn9CP(self):
  val = FFczNY(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFsWbs(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if self.isUpdTitle:
    self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, val, self.maxValue))
  else:
   width = self.barWidth
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VVcWME and not self.isCancelled:
    self.VVcWME(True, self.VVRQiU, self.counter, self.maxValue, self.isError)
   self.close()
 def VVb18s(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme == self.VVaDMy:
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVWaxI:
   pass
 def VV2E6s(self, barTheme):
  if   barTheme == self.VVaDMy : return 0.8
  elif barTheme == self.VVWaxI : return 1
  else              : return 1
class CCsT2Q(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVcWME = {}
  self.commandRunning = False
  self.VVhHyb  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVcWME, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVcWME[name] = VVcWME
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVhHyb:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVsQso, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VV6Rkc , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVsQso, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VV6Rkc , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV6Rkc(name, retval)
  return True
 def VVsQso(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV6Rkc(self, name, retval):
  if not self.VVhHyb:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVcWME[name]:
   self.VVcWME[name](self.appResults[name], retval)
  del self.VVcWME[name]
 def VVJPEx(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CC5kDp(Screen):
 def __init__(self, session, title="", VV7ySt=None, VVhRxE=False, VVnENe=False, VVY6We=False, VVhvP7=False, VVVi8T=False, VVnmqx=False, VVJPTL=VV7TFL, VVfFKv=None, VVy3A0=False, VVBe0q=None, VVOfVR="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFjy7Y(VVxOjf, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFwrVg(self, addScrollLabel=True)
  if not VVOfVR:
   VVOfVR = "Processing ..."
  self["myLabel"].setText("   %s" % VVOfVR)
  self.VVhRxE   = VVhRxE
  self.VVnENe   = VVnENe
  self.VVY6We   = VVY6We
  self.VVhvP7  = VVhvP7
  self.VVVi8T = VVVi8T
  self.VVnmqx = VVnmqx
  self.VVJPTL   = VVJPTL
  self.VVfFKv = VVfFKv
  self.VVy3A0  = VVy3A0
  self.VVBe0q  = VVBe0q
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCsT2Q()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FF7yjp()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV7ySt, str):
   self.VV7ySt = [VV7ySt]
  else:
   self.VV7ySt = VV7ySt
  if self.VVY6We or self.VVhvP7:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVjtIv, VVjtIv)
   self.VV7ySt.append("echo -e '\n%s\n' %s" % (restartNote, FFb5eo(restartNote, VVEdAx)))
   if self.VVY6We:
    self.VV7ySt.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV7ySt.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVVi8T:
   FFngIP(self, "Processing ...")
  self.onLayoutFinish.append(self.VVsEHo)
  self.onClose.append(self.VVV88n)
 def VVsEHo(self):
  self["myLabel"].VVZF8s(textOutFile="console" if self.enableSaveRes else "")
  if self.VVhRxE:
   self["myLabel"].VV5KUx()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV28IE()
  else:
   self.VVvOON()
 def VV28IE(self):
  if FFZ5eQ():
   self["myLabel"].setText("Processing ...")
   self.VVvOON()
  else:
   self["myLabel"].setText(FFXMyR("\n   No connection to internet!", VViuIz))
 def VVvOON(self):
  allOK = self.container.ePopen(self.VV7ySt[0], self.VVwcdG, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVwcdG("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVnmqx or self.VVY6We or self.VVhvP7:
    self["myLabel"].setText(FFcOuU("STARTED", VVEdAx) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVBe0q:
   colorWhite = CCbagr.VVv8nt(VVVF41)
   color  = CCbagr.VVv8nt(self.VVBe0q[0])
   words  = self.VVBe0q[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVJPTL=self.VVJPTL)
 def VVwcdG(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV7ySt):
   allOK = self.container.ePopen(self.VV7ySt[self.cmdNum], self.VVwcdG, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVwcdG("Cannot connect to Console!", -1)
  else:
   if self.VVVi8T and FFPiv5(self):
    FFngIP(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVnmqx:
    self["myLabel"].appendText("\n" + FFcOuU("FINISHED", VVEdAx), self.VVJPTL)
   if self.VVhRxE or self.VVnENe:
    self["myLabel"].VV5KUx()
   if self.VVfFKv is not None:
    self.VVfFKv()
   if not retval and self.VVy3A0:
    self.VVV88n()
 def VVV88n(self):
  if self.container.VVJPEx():
   self.container.killAll()
class CClxRh(Screen):
 def __init__(self, session, VV7ySt=None, VVVi8T=False):
  self.skin, self.skinParam = FFjy7Y(VVxOjf, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VV2Mhn + "ajpanel_terminal.history"
  self.customCommandsFile = VV2Mhn + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFeABk("pwd") or "/home/root"
  self.container   = CCsT2Q()
  FFwrVg(self, addScrollLabel=True)
  FFh33U(self["keyRed"] , "Exit = Stop Command")
  FFh33U(self["keyGreen"] , "OK = History")
  FFh33U(self["keyYellow"], "Menu = Custom Cmds")
  FFh33U(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVucKt ,
   "cancel" : self.VVwF59  ,
   "menu"  : self.VV1Xou ,
   "last"  : self.VVAByK  ,
   "next"  : self.VVAByK  ,
   "1"   : self.VVAByK  ,
   "2"   : self.VVAByK  ,
   "3"   : self.VVAByK  ,
   "4"   : self.VVAByK  ,
   "5"   : self.VVAByK  ,
   "6"   : self.VVAByK  ,
   "7"   : self.VVAByK  ,
   "8"   : self.VVAByK  ,
   "9"   : self.VVAByK  ,
   "0"   : self.VVAByK
  })
  self.onLayoutFinish.append(self.VVH8dW)
  self.onClose.append(self.VVepAN)
 def VVH8dW(self):
  self["myLabel"].VVZF8s(isResizable=False, textOutFile="terminal")
  FFwT6X(self["keyRed"]  , "#00ff8000")
  FF7zZI(self["keyRed"]  , self.skinParam["titleColor"])
  FF7zZI(self["keyGreen"]  , self.skinParam["titleColor"])
  FF7zZI(self["keyYellow"] , self.skinParam["titleColor"])
  FF7zZI(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVzTv3(FFeABk("date"), 5)
  result = FFeABk("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVo65e()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVmF17 + "LinuxCommands.lst"
   newTemplate = VVmF17 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFfUI2("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFfUI2("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVepAN(self):
  if self.container.VVJPEx():
   self.container.killAll()
   self.VVzTv3("Process killed\n", 4)
   self.VVo65e()
 def VVwF59(self):
  if self.container.VVJPEx():
   self.VVepAN()
  else:
   FFRzxq(self, self.close, "Exit ?", VV4GnV=False)
 def VVo65e(self):
  self.VVzTv3(self.prompt, 1)
  self["keyRed"].hide()
 def VVzTv3(self, txt, mode):
  if   mode == 1 : color = VVEdAx
  elif mode == 2 : color = VV7ect
  elif mode == 3 : color = VVVF41
  elif mode == 4 : color = VViuIz
  elif mode == 5 : color = VVsWXS
  elif mode == 6 : color = VVzRfn
  else   : color = VVVF41
  try:
   self["myLabel"].appendText(FFXMyR(txt, color))
  except:
   pass
 def VV828b(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFXMyR(parts[0].strip(), VV7ect)
   right = FFXMyR("#" + parts[1].strip(), VVzRfn)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVzTv3(txt, 2)
  lastLine = self.VV9IlT()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVMaQO(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVwcdG, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FFCwHk(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVzTv3(data, 3)
 def VVwcdG(self, data, retval):
  if not retval == 0:
   self.VVzTv3("Exit Code : %d\n" % retval, 4)
  self.VVo65e()
 def VVucKt(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV9IlT() == "":
   self.VVMaQO("cd /tmp")
   self.VVMaQO("ls")
  VVKPkH = []
  if fileExists(self.commandHistoryFile):
   lines  = FFawFw(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVKPkH.append((str(c), line, str(lNum)))
   self.VV6ehd(VVKPkH, title, self.commandHistoryFile, isHistory=True)
  else:
   FFurlj(self, self.commandHistoryFile, title=title)
 def VV9IlT(self):
  lastLine = FFeABk("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVMaQO(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV1Xou(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFawFw(self.customCommandsFile)
   lastLineIsSep = False
   VVKPkH = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVKPkH.append((str(c), line, str(lNum)))
   self.VV6ehd(VVKPkH, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFurlj(self, self.customCommandsFile, title=title)
 def VV6ehd(self, VVKPkH, title, filePath=None, isHistory=False):
  if VVKPkH:
   VVjLvZ = "#05333333"
   if isHistory: VVysAl = VVkHTQ = VVrOep = "#11000020"
   else  : VVysAl = VVkHTQ = VVrOep = "#06002020"
   VVGGJN = VVmwc1 = None
   VVUydg   = ("Send"   , self.VVN9gY        , [])
   VVYVXl  = ("Modify & Send" , self.VVYYqQ        , [])
   if isHistory:
    VVGGJN = ("Clear History" , self.VVxkTL        , [])
   elif filePath:
    VVmwc1 = ("Edit File"  , boundFunction(self.VVqhbx, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVB5ih     = (CENTER  , LEFT   , CENTER )
   FF4eNC(self, None, title=title, header=header, VVcsAS=VVKPkH, VVB5ih=VVB5ih, VVgyfO=widths, VVvE6h=22, VVUydg=VVUydg, VVYVXl=VVYVXl, VVGGJN=VVGGJN, VVmwc1=VVmwc1, VVO8ee=True
     , VVysAl   = VVysAl
     , VVkHTQ   = VVkHTQ
     , VVrOep   = VVrOep
     , VVh15p  = "#05ffff00"
     , VVjLvZ  = VVjLvZ
    )
  else:
   FF4fts(self, filePath, title=title)
 def VVN9gY(self, VVKvMM, title, txt, colList):
  cmd = colList[1].strip()
  VVKvMM.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVzTv3("\n%s\n" % cmd, 6)
   self.VVzTv3(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVzTv3(cmd, 2)
    self.VVzTv3("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVzTv3(ch, 0)
    self.VVzTv3("\nor\n", 4)
    self.VVzTv3("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVo65e()
   else:
    self.VV828b(cmd)
 def VVYYqQ(self, VVKvMM, title, txt, colList):
  cmd = colList[1]
  self.VVty22(VVKvMM, cmd)
 def VVxkTL(self, VVKvMM, title, txt, colList):
  FFRzxq(self, boundFunction(self.VVzHBp, VVKvMM), "Reset History File ?", title="Command History")
 def VVzHBp(self, VVKvMM):
  os.system(FFfUI2("echo '' > %s" % self.commandHistoryFile))
  VVKvMM.cancel()
 def VVqhbx(self, filePath, VVKvMM, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC9jZC(self, filePath, VVcWME=boundFunction(self.VVEy4j, VVKvMM), curRowNum=rowNum)
  else     : FFurlj(self, filePath)
 def VVEy4j(self, VVKvMM, fileChanged):
  if fileChanged:
   VVKvMM.cancel()
   FFXHmb(self.VV1Xou)
 def VVAByK(self):
  self.VVty22(None, self.lastCommand)
 def VVty22(self, VVKvMM, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFQYeU(self, boundFunction(self.VVaN4e, VVKvMM), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVaN4e(self, VVKvMM, cmd):
  if cmd and len(cmd) > 0:
   self.VV828b(cmd)
   if VVKvMM:
    VVKvMM.cancel()
class CCYylq(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VV0ZSY="", VVwFHs=False, VV5xse=False, isTrimEnds=True):
  self.skin, self.skinParam = FFjy7Y(VVCHoD, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFwrVg(self, title, addLabel=True)
  FFh33U(self["keyRed"] , "Up/Down = Change")
  FFh33U(self["keyGreen"] , "Overwrite")
  FFh33U(self["keyYellow"], "Pick Key Map")
  FFh33U(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VV5xse   = VV5xse
  self.VVwFHs  = VVwFHs
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VV0ZSY, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVQywC      ,
   "green"    : self.VV0fMj    ,
   "yellow"   : self.VVeRKF      ,
   "blue"    : self.VVORdS     ,
   "menu"    : self.VVAEzH     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VV8zOh, True) ,
   "down"    : boundFunction(self.VV8zOh, False) ,
   "left"    : self.VVn1x1       ,
   "right"    : self.VVW8Zb       ,
   "home"    : self.VVz49l       ,
   "end"    : self.VVghIz       ,
   "next"    : self.VVKFCH      ,
   "last"    : self.VVfomY      ,
   "deleteForward"  : self.VVKFCH      ,
   "deleteBackward" : self.VVfomY      ,
   "tab"    : self.VVtTdT       ,
   "toggleOverwrite" : self.VV0fMj    ,
   "0"     : self.VVIFVa     ,
   "1"     : self.VVIFVa     ,
   "2"     : self.VVIFVa     ,
   "3"     : self.VVIFVa     ,
   "4"     : self.VVIFVa     ,
   "5"     : self.VVIFVa     ,
   "6"     : self.VVIFVa     ,
   "7"     : self.VVIFVa     ,
   "8"     : self.VVIFVa     ,
   "9"     : self.VVIFVa
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVgY9H()
  self.onShown.append(self.VVH8dW)
  self.onClose.append(self.onExit)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self["myLabel"].setText(self.message)
  self.VVmTZj()
  if self.VVwFHs : self.VV0fMj()
  else    : self.VV9a6M()
  FFgCHF(self)
  FF7zZI(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVV1ap)
  except:
   self.timer.callback.append(self.VVV1ap)
 def onExit(self):
  self.timer.stop()
 def VVQywC(self):
  self.VVu3zq()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVu3zq()
  self.close(None)
 def VVAEzH(self):
  VVpLvf = []
  VVpLvf.append(("Home"         , "home"    ))
  VVpLvf.append(("End"         , "end"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Clear All"       , "clearAll"   ))
  VVpLvf.append(("Clear To Home"      , "clearToHome"   ))
  VVpLvf.append(("Clear To End"       , "clearToEnd"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVYka2:
   VVpLvf.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("To Capital Letters"     , "toCapital"   ))
  VVpLvf.append(("To Small Letters"      , "toSmall"    ))
  FFBYrC(self, self.VV8NJn, title="Edit Options", VVpLvf=VVpLvf)
 def VV8NJn(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVz49l()
   elif item == "end"     : self.VVghIz()
   elif item == "clearAll"    : self.VVBORI()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVz49l()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVYka2
    VVYka2 = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVYka2)
    self.VVz49l()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVV1ap(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VV0fMj(self):
  self["myInput"].toggleOverwrite()
  self.VV9a6M()
 def VVeRKF(self):
  self.session.openWithCallback(self.VVUCE7, boundFunction(CCj2Vo, mode=self.charMode, VV5xse=self.VV5xse))
 def VVUCE7(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVmTZj()
 def VV9a6M(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVgY9H(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVu3zq(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVT1iH(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVn1x1(self)     : self.VVl3js(self["myInput"].left)
 def VVW8Zb(self)     : self.VVl3js(self["myInput"].right)
 def VVKFCH(self)     : self.VVl3js(self["myInput"].delete)
 def VVz49l(self)     : self.VVl3js(self["myInput"].home)
 def VVghIz(self)     : self.VVl3js(self["myInput"].end)
 def VVfomY(self)    : self.VVl3js(self["myInput"].deleteBackward)
 def VVtTdT(self)     : self.VVl3js(self["myInput"].tab)
 def VVBORI(self)     : self["myInput"].setText("")
 def VVl3js(self, fnc):
  fnc()
  self.VVV1ap()
 def VVIFVa(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVT1iH(newChar, overwrite)
   self.VV4zWO(newChar, self["myInput"].mapping[number])
 def VV8zOh(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCj2Vo.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCj2Vo.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVT1iH(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV4zWO(newChar, group)
     break
 def VV4zWO(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVVF41:
    group = VVsWXS + group.replace(newChar, FFXMyR(newChar, VVVF41, VVsWXS))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVORdS(self):
  if self.VV5xse : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVmTZj()
 def VVmTZj(self):
  self["myInput"].mapping = CCj2Vo.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCj2Vo.RCU_MAP_TITLES[self.charMode])
class CCj2Vo(Screen):
 VVAETG  = 0
 VV9EgH  = 1
 VVNQHy  = 2
 VVpczt  = 3
 VVQHOf = 4
 VVzsvi = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVAETG, VV5xse=False):
  self.skin, self.skinParam = FFjy7Y(VV4VuE, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VV5xse  = VV5xse
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFwrVg(self, title=self.Title)
  FFh33U(self["keyRed"] ,"OK = Select")
  FFh33U(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVbQ5f     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVYzFf, -1) ,
   "next"  : boundFunction(self.VVYzFf, +1) ,
   "left"  : boundFunction(self.VVYzFf, -1) ,
   "right"  : boundFunction(self.VVYzFf, +1) ,
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FF7zZI(self["keyRed"], "#11222222")
  FF7zZI(self["keyGreen"], "#11222222")
  self.VV7QQl()
 def VV7QQl(self):
  self.VVbT1X()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVbT1X(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVYzFf(self, direction):
  if self.VV5xse : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VV7QQl()
 def VVbQ5f(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CC5cSz(Screen):
 def __init__(self, session, title="", message="", VVJPTL=VV7TFL, VVdW3j=False, VVrOep=None, VVvE6h=30):
  self.skin, self.skinParam = FFjy7Y(VVxOjf, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVvE6h)
  self.session   = session
  FFwrVg(self, title, addScrollLabel=True)
  self.VVJPTL   = VVJPTL
  self.VVdW3j   = VVdW3j
  self.VVrOep   = VVrOep
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self["myLabel"].VVZF8s(VVdW3j=self.VVdW3j)
  self["myLabel"].setText(self.message, self.VVJPTL)
  if self.VVrOep:
   FF7zZI(self["myBody"], self.VVrOep)
   FF7zZI(self["myLabel"], self.VVrOep)
   FFwEzj(self["myLabel"], self.VVrOep)
  self["myLabel"].VV5KUx()
class CCO5EH(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFjy7Y(VVtT2C, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFwrVg(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  path = VVmF17 + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCwbgh(Screen, CCuTLY):
 PLAYER_INSTANCE = None
 def __init__(self, session, enableZapping=True, portalTableParam=None):
  self.skin, self.skinParam = FFjy7Y(VVckBK, 800, 170, 25, 10, 6, "#1100202a", "#1100202a", 20)
  CCuTLY.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.VVfSs1    = 0
  self.winHeight1    = 0
  self.winHeight2    = 0
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.cutListCounter   = 0
  self.isCutListFound   = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFwrVg(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayBarM"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayJmp"] = Label("Jump: %d m" % self.jumpMinutes)
  self["myPlaySkp"] = Label()
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayInf"] = Label("Info")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlsTV         ,
   "info"  : self.VV8LXo        ,
   "epg"  : self.VV8LXo        ,
   "menu"  : self.VVpeBV         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVfkBA        ,
   "green"  : boundFunction(self.VV5c1V, True),
   "play"  : self.VV4IDB        ,
   "pause"  : self.VV4IDB        ,
   "stop"  : self.VV4IDB        ,
   "left"  : boundFunction(self.VV1rAY, -1)   ,
   "right"  : boundFunction(self.VV1rAY,  1)   ,
   "rewind" : self.VVIdnu        ,
   "forward" : self.VVPf2S        ,
   "last"  : boundFunction(self.VV2aGK, 0)    ,
   "next"  : self.VV1iuY        ,
   "pageUp" : boundFunction(self.VVnevP, True) ,
   "pageDown" : boundFunction(self.VVnevP, False) ,
   "chanUp" : boundFunction(self.VVnevP, True) ,
   "chanDown" : boundFunction(self.VVnevP, False) ,
   "up"  : boundFunction(self.VVnevP, True) ,
   "down"  : boundFunction(self.VVnevP, False) ,
   "0"   : boundFunction(self.VVclaH , 10)  ,
   "1"   : boundFunction(self.VVclaH , 1)  ,
   "2"   : boundFunction(self.VVclaH , 2)  ,
   "3"   : boundFunction(self.VVclaH , 3)  ,
   "4"   : boundFunction(self.VVclaH , 4)  ,
   "5"   : boundFunction(self.VVclaH , 5)  ,
   "6"   : boundFunction(self.VVclaH , 6)  ,
   "7"   : boundFunction(self.VVclaH , 7)  ,
   "8"   : boundFunction(self.VVclaH , 8)  ,
   "9"   : boundFunction(self.VVclaH , 9)
  }, -1)
  self.onShown.append(self.VVH8dW)
  self.onClose.append(self.onExit)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  if not CCwbgh.PLAYER_INSTANCE or self.portalTableParam:
   CCwbgh.PLAYER_INSTANCE = self
  else:
   self.close()
  self.VVaOyu()
  self.instance.move(ePoint(40, 40))
  size = self.instance.size()
  self.VVfSs1 = int(size.width())
  self.winHeight1 = int(size.height())
  self.winHeight2 = int(self["myPlaySep"].getPosition()[1])
  FFwT6X(self["myPlayJmp"], "#0a666666")
  FFwT6X(self["myPlaySkp"], "#0affff00")
  FF7zZI(self["myPlayBlu"], "#1118188b")
  FF7zZI(self["myPlayInf"], "#11444444")
  self["myPlayBarM"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVuI6P)
  except:
   self.timer.callback.append(self.VVuI6P)
  self.timer.start(250, False)
  self.VVuI6P("Checking ...")
  self.VV5c1V()
 def onExit(self):
  self.timer.stop()
  CCwbgh.PLAYER_INSTANCE = None
 def VVaOyu(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl : color = "#1120002a"
  else     : color = "#1100202a"
  FF7zZI(self["myTitle"], color)
 def VVpeBV(self):
  FFkrGj(self, VVmF17 + "_help_player", "Player Controller (Keys)")
 def VVlsTV(self):
  if self.isManualSeek:
   self.VVGQUG()
   self.VV2aGK(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVGQUG()
  else:
   self.close()
 def VV8LXo(self):
  FFCpwr(self, fncMode=CCzK25.VVG8uG)
 def VV4IDB(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVuI6P("Toggling Play/Pause ...")
 def VVGQUG(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayBarM"].hide()
   self["myPlaySkp"].hide()
 def VV1rAY(self, direc):
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVBGRo()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayBarM"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFczNY(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayBarM"].instance.size().width() + 1
   left = int(FFsWbs(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayBarM"].instance.move(ePoint(left, int(self["myPlayBarM"].getPosition()[1])))
   self["myPlaySkp"].setText(FFP20u(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVclaH(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFh33U(self["myPlayJmp"], "Jump: %d m" % self.jumpMinutes)
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVuI6P("Changed Jump Minutes to : %d" % val)
 def VVuI6P(self, stateTxt=""):
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVBGRo()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(str(posTxt))
    self["myPlayVal"].setText(percTxt)
    val  = FFczNY(percVal, 0, 100)
    width = int(FFsWbs(val, 0, 100, 0, self.barWidth))
   if durTxt:
    self["myPlayDur"].setText(str(durTxt))
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if not self.isCutListFound and self.cutListCounter < 5:
   self.cutListCounter += 1
   if self.VVlslg():
    self["myPlayBlu"].show()
    self.isCutListFound
  winH = self.instance.size().height()
  if durTxt:
   if winH < self.winHeight1:
    self.instance.resize(eSize(*(self.VVfSs1, self.winHeight1)))
  else:
   self["myPlayVal"].setText("0 %")
   if winH > self.winHeight2:
    self.instance.resize(eSize(*(self.VVfSs1, self.winHeight2)))
  if stateTxt:
   FFwT6X(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   FFwT6X(self["myPlayMsg"], "#00ff8066")
   self["myPlayMsg"].setText("-")
   self["myPlayVal"].setText("0 %")
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVxYgH()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Unknown state"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VV2aGK(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VV9OcF()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFwT6X(self["myPlayMsg"], "#0000ff00")
  else     : FFwT6X(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVBGRo(self):
  percVal = durVal = posVal = seekable = 0
  percTxt = durTxt = posTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFP20u(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFP20u(posVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt
 def VVfkBA(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVlslg()
   if cList:
    VVpLvf = []
    for pts, what in cList:
     txt = FFP20u(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVpLvf.append((txt, pts))
    FFBYrC(self, self.VVcpQ4, VVpLvf=VVpLvf, title="Cut List")
   else:
    self.VVuI6P("No Cut-List for this channel !")
 def VVcpQ4(self, item=None):
  if item:
   self.VV2aGK(item)
 def VVlslg(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVPf2S(self) : self.VVe3Vj(self.jumpMinutes)
 def VVIdnu(self) : self.VVe3Vj(-self.jumpMinutes)
 def VVe3Vj(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVuI6P("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVuI6P("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVuI6P("Cannot jump")
 def VVFkqH(self):
  InfoBar.instance.VVFkqH()
 def VV2aGK(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVuI6P("Changing Time ...")
 def VV1iuY(self):
  try:
   seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVBGRo()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVuI6P("Jumping to end ...")
  except:
   pass
 def VVxYgH(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV9OcF(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVnevP(self, isUp):
  if self.enableZapping:
   self.VVuI6P("Zap %s ..." % ("Up" if isUp else "Down"))
   if self.portalTableParam:
    self.VVcR5c(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VVaOyu()
    self.VV5c1V()
 def VVcR5c(self, isUp):
  CCDch1_inatance, VVKvMM, mode = self.portalTableParam
  if isUp : VVKvMM.VVZIvj()
  else : VVKvMM.VV7sGi()
  FFGw6o(VVKvMM, boundFunction(self.VVsynM, mode, VVKvMM, CCDch1_inatance), title="Playing ...")
 def VVsynM(self, mode, VVKvMM, CCDch1_inatance):
  colList = VVKvMM.VVePo8()
  if mode == "localIptv":
   CCDch1_inatance.VVudhA(True, VVKvMM, "", "", colList)
  elif isinstance(mode, int):
   CCDch1_inatance.VVfMp1(mode, True, VVKvMM, "", "", colList)
  else:
   CCDch1_inatance.VVoPy9(mode, True, VVKvMM, "", "", colList)
  self.close()
 def VV5c1V(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVBGRo()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMRZ5(self)
   if not self.VV70uK(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVuI6P("Refreshing Portal")
   FFXHmb(self.VVvNZ1)
  except:
   pass
 def VVvNZ1(self):
  self.restoreLastPlayPos = self.VVKs0E()
class CC2eL4(Screen):
 def __init__(self, session, title="", VVWKlK="Continue?", VV4GnV=True, VVpF7d=False):
  self.skin, self.skinParam = FFjy7Y(VVZmTS, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVWKlK = VVWKlK
  self.VVpF7d = VVpF7d
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV4GnV : VVpLvf = [no , yes]
  else   : VVpLvf = [yes, no ]
  FFwrVg(self, title, VVpLvf=VVpLvf, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlsTV ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVWKlK)
  if self.VVpF7d:
   self["myLabel"].instance.setHAlign(0)
  self.VVoCkF()
  FFqSyv(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFQLuS(self["myMenu"])
  FFV5BX(self, self["myMenu"])
 def VVlsTV(self):
  item = FFexYq(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVoCkF(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCAZ66(Screen):
 def __init__(self, session, title="", VVpLvf=None, width=1000, OKBtnFnc=None, VVFOel=None, VVkP5H=None, VVgMyE=None, VVKjVK=None, VV8NFf=False, VVBCDk=False):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVpLvf   = VVpLvf
  self.OKBtnFnc   = OKBtnFnc
  self.VVFOel   = VVFOel
  self.VVkP5H  = VVkP5H
  self.VVgMyE  = VVgMyE
  self.VVKjVK   = VVKjVK
  self.VV8NFf  = VV8NFf
  self.VVBCDk  = VVBCDk
  FFwrVg(self, title, VVpLvf=VVpLvf)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVlsTV          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVpsBE         ,
   "green"  : self.VVxbP2         ,
   "yellow" : self.VVrORa         ,
   "blue"  : self.VVUW5K         ,
   "pageUp" : self.VVSiHF       ,
   "chanUp" : self.VVSiHF       ,
   "pageDown" : self.VV0T1s        ,
   "chanDown" : self.VV0T1s
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["myMenu"])
  FFVqF1(self)
  self.VVnVl6(self["keyRed"]  , self.VVFOel )
  self.VVnVl6(self["keyGreen"] , self.VVkP5H )
  self.VVnVl6(self["keyYellow"] , self.VVgMyE )
  self.VVnVl6(self["keyBlue"]  , self.VVKjVK )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFgCHF(self)
 def VVnVl6(self, btnObj, btnFnc):
  if btnFnc:
   FFh33U(btnObj, btnFnc[0])
 def VVlsTV(self):
  item = FFexYq(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV8NFf: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVpsBE(self)  : self.VVl3js(self.VVFOel)
 def VVxbP2(self) : self.VVl3js(self.VVkP5H)
 def VVrORa(self) : self.VVl3js(self.VVgMyE)
 def VVUW5K(self) : self.VVl3js(self.VVKjVK)
 def VVl3js(self, btnFnc):
  if btnFnc:
   item = FFexYq(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVBCDk:
    self.cancel()
 def VVyJKa(self, VVpLvf):
  if len(VVpLvf) > 0:
   newList = []
   for item in VVpLvf:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVydwe(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVSiHF(self):
  self["myMenu"].moveToIndex(0)
 def VV0T1s(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCQ5mT(Screen):
 def __init__(self, session, title="", header=None, VVcsAS=None, VVB5ih=None, VVgyfO=None, VVvE6h=24, VVO8ee=False, VVUydg=None, VVVLKj=None, VVKuXf=None, VVYVXl=None, VVGGJN=None, VVmwc1=None, VVtbiA=None, VVbDGl=None, VV5NUw=None, VVVkpg=-1, VVq8dH=False, searchCol=0, VVysAl=None, VVkHTQ=None, VV8wju="#00dddddd", VVrOep="#11002233", VVh15p="#00ff8833", VVjLvZ="#11111111", VV0jUQ="#0a555555", VVGZlJ="#0affffff", VVrGMe="#11552200", VV4PM4="#0055ff55"):
  self.skin, self.skinParam = FFjy7Y(VVUbU5, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFwrVg(self, title)
  self.header     = header
  self.VVcsAS     = VVcsAS
  self.totalCols    = len(VVcsAS[0])
  self.VV0VTW   = 0
  self.lastSortModeIsReverese = False
  self.VVO8ee   = VVO8ee
  self.VVousV   = 0.01
  self.VV0m5N   = 0.02
  self.VV7x2M  = 1
  self.VVgyfO = VVgyfO
  self.colWidthPixels   = []
  self.VVUydg   = VVUydg
  self.OKButtonObj   = None
  self.VVVLKj   = VVVLKj
  self.VVKuXf   = VVKuXf
  self.VVYVXl   = VVYVXl
  self.VVGGJN  = VVGGJN
  self.VVmwc1   = VVmwc1
  self.VVtbiA    = VVtbiA
  self.VVbDGl   = VVbDGl
  self.VV5NUw  = VV5NUw
  self.VVVkpg    = VVVkpg
  self.VVq8dH   = VVq8dH
  self.searchCol    = searchCol
  self.VVB5ih    = VVB5ih
  self.keyPressed    = -1
  self.VVvE6h    = FFH892(VVvE6h)
  self.VVfASw    = FFyvNz(self.VVvE6h, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVysAl    = VVysAl
  self.VVkHTQ      = VVkHTQ
  self.VV8wju    = FFJQUL(VV8wju)
  self.VVrOep    = FFJQUL(VVrOep)
  self.VVh15p    = FFJQUL(VVh15p)
  self.VVjLvZ    = FFJQUL(VVjLvZ)
  self.VV0jUQ   = FFJQUL(VV0jUQ)
  self.VVGZlJ    = FFJQUL(VVGZlJ)
  self.VVrGMe    = FFJQUL(VVrGMe)
  self.VV4PM4   = FFJQUL(VV4PM4)
  self.VVGfQV  = False
  self.selectedItems   = 0
  self.VVYUFY   = FFJQUL("#01fefe01")
  self.VVVJQR   = FFJQUL("#11400040")
  self.VVApBI  = self.VVYUFY
  self.VVWd9K  = self.VVjLvZ
  if self.VVq8dH:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVauEQ  ,
   "red"   : self.VVCz40  ,
   "green"   : self.VVU5De ,
   "yellow"  : self.VVrQoB ,
   "blue"   : self.VVdo5v  ,
   "menu"   : self.VVoNLI ,
   "info"   : self.VVfk7W  ,
   "cancel"  : self.VVRDO5  ,
   "up"   : self.VV7sGi    ,
   "down"   : self.VVZIvj  ,
   "left"   : self.VVh2d1   ,
   "right"   : self.VVPDsT  ,
   "pageUp"  : self.VVAV4Y  ,
   "chanUp"  : self.VVAV4Y  ,
   "pageDown"  : self.VVRHOy  ,
   "chanDown"  : self.VVRHOy
  }, -1)
  FFBFJx(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  try:
   self.VVws1P()
  except Exception as err:
   FFCwHk(self, str(err))
   self.close(None)
 def VVws1P(self):
  FFgCHF(self)
  if self.VVysAl:
   FF7zZI(self["myTitle"], self.VVysAl)
  if self.VVkHTQ:
   FF7zZI(self["myBody"] , self.VVkHTQ)
   FF7zZI(self["myTableH"] , self.VVkHTQ)
   FF7zZI(self["myTable"] , self.VVkHTQ)
   FF7zZI(self["myBar"]  , self.VVkHTQ)
  self.VVnVl6(self.VVKuXf  , self["keyRed"])
  self.VVnVl6(self.VVYVXl  , self["keyGreen"])
  self.VVnVl6(self.VVGGJN , self["keyYellow"])
  self.VVnVl6(self.VVmwc1  , self["keyBlue"])
  if self.VVUydg:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVUydg[0])
    FF7zZI(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVfASw)
  self["myTableH"].l.setFont(0, gFont(VVkLUF, self.VVvE6h))
  self["myTable"].l.setItemHeight(self.VVfASw)
  self["myTable"].l.setFont(0, gFont(VVkLUF, self.VVvE6h))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVfASw)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVfASw))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVfASw)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVfASw
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVfASw * len(self.VVcsAS) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVgyfO:
   self.VVgyfO = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVgyfO)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVB5ih:
   self.VVB5ih = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVB5ih
   self.VVB5ih = []
   for item in tmpList:
    self.VVB5ih.append(item | RT_VALIGN_CENTER)
  self.VVgxMN()
  if self.VVtbiA:
   self.VVtbiA(self)
 def VVnVl6(self, btnFnc, btn):
  if btnFnc : FFh33U(btn, btnFnc[0])
  else  : FFh33U(btn, "")
 def VVumsD(self, waitTxt):
  FFGw6o(self, self.VVgxMN, title=waitTxt)
 def VVgxMN(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVWFwZ(0, self.header, self.VVGZlJ, self.VVrGMe, self.VVGZlJ, self.VVrGMe, self.VV4PM4)])
   rows = []
   for c, row in enumerate(self.VVcsAS):
    rows.append(self.VVWFwZ(c, row, self.VV8wju, self.VVrOep, self.VVh15p, self.VVjLvZ, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVVkpg > -1:
    self["myTable"].moveToIndex(self.VVVkpg )
   self.VVhcbc()
   if self.VVq8dH:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVfASw * len(self.VVcsAS)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVbDGl:
    self.VVl3js(self.VVbDGl, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFCwHk(self, str(err))
    self.close()
   except:
    pass
 def VVWFwZ(self, keyIndex, columns, VV8wju, VVrOep, VVh15p, VVjLvZ, VV4PM4):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV4PM4 and ndx == self.VV0VTW : textColor = VV4PM4
   else           : textColor = VV8wju
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.+)", entry, IGNORECASE)
   if span:
    c = FFJQUL(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVrOep = c
    entry = span.group(3)
   if self.VVB5ih[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVfASw)
           , font   = 0
           , flags   = self.VVB5ih[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVrOep
           , color_sel  = VVh15p
           , backcolor_sel = VVjLvZ
           , border_width = 1
           , border_color = self.VV0jUQ
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVfk7W(self):
  rowData = self.VVyGnG()
  if rowData:
   title, txt, colList = rowData
   if self.VVVLKj:
    fnc  = self.VVVLKj[1]
    params = self.VVVLKj[2]
    fnc(self, title, txt, colList)
   else:
    FFWUy2(self, txt, title)
 def VVauEQ(self):
  if   self.VVGfQV : self.VVGnBO(self.VVixla(), mode=2)
  elif self.VVUydg  : self.VVl3js(self.VVUydg, None)
  else      : self.VVfk7W()
 def VVCz40(self) : self.VVl3js(self.VVKuXf , self["keyRed"])
 def VVU5De(self) : self.VVl3js(self.VVYVXl , self["keyGreen"])
 def VVrQoB(self): self.VVl3js(self.VVGGJN , self["keyYellow"])
 def VVdo5v(self) : self.VVl3js(self.VVmwc1 , self["keyBlue"])
 def VVl3js(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFngIP(self, buttonFnc[3])
    FFXHmb(boundFunction(self.VVZs08, buttonFnc))
   else:
    self.VVZs08(buttonFnc)
 def VVZs08(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVyGnG()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVGnBO(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVcsAS[ndx]
   isSelected = row[1][9] == self.VVYUFY
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVWFwZ(ndx, item, self.VV8wju, self.VVrOep, self.VVh15p, self.VVjLvZ, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVWFwZ(ndx, item, self.VVYUFY, self.VVVJQR, self.VVApBI, self.VVWd9K, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVhcbc()
 def VVBCuh(self):
  FFGw6o(self, self.VVOaCo, title="Selecting all ...")
 def VVOaCo(self):
  self.VViBLa(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVYUFY
   if not isSelected:
    item = self.VVcsAS[ndx]
    newRow = self.VVWFwZ(ndx, item, self.VVYUFY, self.VVVJQR, self.VVApBI, self.VVWd9K, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVhcbc()
  self.VVxcNC()
 def VVBo0O(self):
  FFGw6o(self, self.VVAf0i, title="Unselecting all ...")
 def VVAf0i(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVYUFY:
    item = self.VVcsAS[ndx]
    newRow = self.VVWFwZ(ndx, item, self.VV8wju, self.VVrOep, self.VVh15p, self.VVjLvZ, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVhcbc()
  self.VVxcNC()
 def VVyGnG(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVgyfO[i] > 1 or self.VVgyfO[i] == self.VVousV:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVcsAS))
   return rowNum, txt, colList
  else:
   return None
 def VVRDO5(self):
  if self.VV5NUw : self.VV5NUw(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVuQPR(self):
  return self["myTitle"].getText().strip()
 def VVS9No(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVfTev(self, txt):
  FFngIP(self, txt)
 def VVglk9(self, txt):
  FFngIP(self, txt, 1000)
 def VV5aRa(self):
  FFngIP(self)
 def VVpmrk(self):
  return len(self.VVcsAS)
 def VV1XEK(self): self["keyGreen"].show()
 def VVvIxK(self): self["keyGreen"].hide()
 def VVixla(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVajAt(self):
  return len(self["myTable"].list)
 def VViBLa(self, isOn):
  self.VVGfQV = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVmwc1: self["keyBlue"].hide()
   if self.VVUydg and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVmwc1: self["keyBlue"].show()
   if self.VVUydg and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVUydg[0])
   self.VVBo0O()
  FF7zZI(self["myTitle"], color)
  FF7zZI(self["myBar"]  , color)
 def VV1Kxv(self):
  return self.VVGfQV
 def VVHL4W(self):
  return self.selectedItems
 def VVxcNC(self):
  self.hide()
  self.show()
 def VV28DA(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVhcbc()
 def VVaPB8(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVhcbc()
 def VVpuMJ(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVcsAS:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVtQEP(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVpmrk()
  txt += FFcOuU("Total Unique Items", VViuIz)
  for i in range(self.totalCols):
   if self.VVgyfO[i - 1] > 1 or self.VVgyfO[i - 1] == self.VVousV:
    name, tot = self.VVpuMJ(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFWUy2(self, txt)
 def VVtFdM(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVePo8(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV32hv(self, newList, newTitle=""):
  if newList:
   self.VVcsAS = newList
   if self.VVO8ee and self.VV0VTW == 0:
    self.VVcsAS = sorted(self.VVcsAS, key=lambda x: int(x[self.VV0VTW])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVcsAS = sorted(self.VVcsAS, key=lambda x: x[self.VV0VTW].lower(), reverse=self.lastSortModeIsReverese)
   self.VVumsD("Refreshing ...")
   if newTitle:
    self.VVS9No(newTitle)
  else:
   FFCwHk(self, "Cannot refresh list")
   self.cancel()
 def VVbiRP(self, data):
  ndx = self.VVixla()
  newRow = self.VVWFwZ(ndx, data, self.VV8wju, self.VVrOep, self.VVh15p, self.VVjLvZ, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVxcNC()
   return True
  else:
   return False
 def VVz9TN(self, colNum, textToFind, VVDTOG=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVhcbc()
    break
  else:
   if VVDTOG:
    FFngIP(self, "Not found", 1000)
 def VVQbQF(self, colDict, VVDTOG=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVhcbc()
    return
  if VVDTOG:
   FFngIP(self, "Not found", 1000)
 def VVQbQF_partial(self, colDict, VVDTOG=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVhcbc()
    return
  if VVDTOG:
   FFngIP(self, "Not found", 1000)
 def VVnmq9(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVdgSJ(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVYUFY:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VV3tvF(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVoNLI(self):
  if not self["keyMenu2F"].getVisible() or self.VVq8dH:
   return
  VVpLvf = []
  VVpLvf.append(("Table Statistcis"             , "tableStat"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append((FFXMyR("Export Table to .html"     , VViuIz) , "VVMGry" ))
  VVpLvf.append((FFXMyR("Export Table to .csv"     , VViuIz) , "VVb72U" ))
  VVpLvf.append((FFXMyR("Export Table to .txt (Tab Separated)", VViuIz) , "VVjwed" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVgyfO[i] > 1 or self.VVgyfO[i] == self.VV0m5N:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVpLvf.append(VVkUZg)
   if tot == 1 : VVpLvf.append(("Sort", sList[0][1]))
   else  : VVpLvf += sList
  FFBYrC(self, self.VVauLu, VVpLvf=VVpLvf, title=self.VVuQPR())
 def VVauLu(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVtQEP()
   elif item == "VVMGry": FFGw6o(self, self.VVMGry, title=title)
   elif item == "VVb72U" : FFGw6o(self, self.VVb72U , title=title)
   elif item == "VVjwed" : FFGw6o(self, self.VVjwed , title=title)
   else:
    isReversed = False
    if self.VV0VTW == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVO8ee and item == 0:
     self.VVcsAS = sorted(self.VVcsAS, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVcsAS = sorted(self.VVcsAS, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VV0VTW = item
    self.VVumsD("Sorting ...")
 def VV7sGi(self):
  self["myTable"].up()
  self.VVhcbc()
 def VVZIvj(self):
  self["myTable"].down()
  self.VVhcbc()
 def VVh2d1(self):
  self["myTable"].pageUp()
  self.VVhcbc()
 def VVPDsT(self):
  self["myTable"].pageDown()
  self.VVhcbc()
 def VVAV4Y(self):
  self["myTable"].moveToIndex(0)
  self.VVhcbc()
 def VVRHOy(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVhcbc()
 def VVjwed(self):
  expFile = self.VVt2AA() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVBlGc()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVcsAS:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVgyfO[ndx] > self.VV7x2M:
      col = self.VV6aGe(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVjrfS(expFile)
 def VVb72U(self):
  expFile = self.VVt2AA() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVBlGc()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVcsAS:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVgyfO[ndx] > self.VV7x2M:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VV6aGe(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVjrfS(expFile)
 def VVMGry(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVuQPR(), PLUGIN_NAME, VVT4M3)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVuQPR()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVBlGc()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVgyfO:
   colgroup += '   <colgroup>'
   for w in self.VVgyfO:
    if w > self.VV7x2M:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVt2AA() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVcsAS:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVgyfO[ndx] > self.VV7x2M:
      col = self.VV6aGe(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVjrfS(expFile)
 def VVBlGc(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVgyfO[ndx] > self.VV7x2M:
     newRow.append(col.strip())
  return newRow
 def VV6aGe(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFAwDH(col)
 def VVt2AA(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVuQPR())
  fileName = fileName.replace("__", "_")
  path  = FFUUJW(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFi9KP()
  return expFile
 def VVjrfS(self, expFile):
  FFGBS4(self, "File exported to:\n\n%s" % expFile, title=self.VVuQPR())
 def VVhcbc(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCf89k(Screen):
 def __init__(self, session, Title="", VVbVuZ=None):
  self.skin, self.skinParam = FFjy7Y(VV2L3D, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFwrVg(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVbVuZ = VVbVuZ
  if len(Title) == 0 : Title = FF7yjp()
  else    : Title = "File : %s" % VVbVuZ
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  allOK = FFbnvf(self["myLabel"], self.VVbVuZ)
  if not allOK:
   FFCwHk(self, "Could not view this picture file")
   self.close()
class CCUKTK(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFjy7Y(VVfanr, 1400, 950, 50, 40, 40, "#11201010", "#11101010", 30, barHeight=40, topRightBtns=1)
  self.session  = session
  FFwrVg(self)
  FFh33U(self["keyGreen"], "Save")
  self.VVcsAS = []
  self.VVcsAS.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VVcsAS.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VVcsAS.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VVcsAS.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VVcsAS.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  self.VVcsAS.append(getConfigListEntry(VVjtIv *2            ,         ))
  self.VVcsAS.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VVcsAS.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VVcsAS.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VVcsAS.append(getConfigListEntry(VVjtIv *2            ,         ))
  self.VVcsAS.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VVcsAS.append(getConfigListEntry(VVjtIv *2            ,         ))
  self.VVcsAS.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VVcsAS.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VVcsAS.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VVcsAS.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VVcsAS.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVcsAS, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVlsTV   ,
   "OK"  : self.VVlsTV   ,
   "green"  : self.VVOeGV  ,
   "menu"  : self.VVDuoG ,
   "cancel" : self.VV5hYl
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFqSyv(self["config"])
  FFVqF1(self,  self["config"])
  FFgCHF(self)
 def VVlsTV(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VVcMUg(item)
   elif item == CFG.backupPath    : self.VVcMUg(item)
   elif item == CFG.packageOutputPath  : self.VVcMUg(item)
   elif item == CFG.downloadedPackagesPath : self.VVcMUg(item)
   elif item == CFG.exportedTablesPath  : self.VVcMUg(item)
   elif item == CFG.exportedPIconsPath  : self.VVcMUg(item)
 def VVcMUg(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VVsfI6, configObj)
         , boundFunction(CCRH8h, mode=CCRH8h.VVgIOf, VVWrT9=sDir))
 def VVsfI6(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV5hYl(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFRzxq(self, self.VVOeGV, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVOeGV(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV9U8P()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVDuoG(self):
  VVpLvf = []
  VVpLvf.append(("Use Backup directory in all other paths"      , "VVap4n"   ))
  VVpLvf.append(("Reset all to default (including File Manager bookmarks)"  , "VVurNl"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Backup %s Settings" % PLUGIN_NAME        , "VV9awz"  ))
  VVpLvf.append(("Restore %s Settings" % PLUGIN_NAME       , "VVfEDN"  ))
  if fileExists(VV2Mhn + VVZGB0):
   VVpLvf.append(VVkUZg)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVpLvf.append(('%s Checking for Update' % txt1       , txt2     ))
   VVpLvf.append(("Reinstall %s" % PLUGIN_NAME        , "VVWnNC"  ))
   VVpLvf.append(("Update %s" % PLUGIN_NAME        , "VVpc6U"   ))
  FFBYrC(self, self.VVvSm7, VVpLvf=VVpLvf, title="Config. Options")
 def VVvSm7(self, item=None):
  if item:
   if   item == "VVap4n"  : FFRzxq(self, self.VVap4n , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVurNl"  : FFRzxq(self, self.VVurNl, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCbagr)
   elif item == "VV9awz" : self.VV9awz()
   elif item == "VVfEDN" : FFGw6o(self, self.VVfEDN, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VV8WGq(True)
   elif item == "disableChkUpdate" : self.VV8WGq(False)
   elif item == "VVWnNC" : FFGw6o(self, self.VVWnNC , "Checking Server ...")
   elif item == "VVpc6U"  : FFGw6o(self, self.VVpc6U  , "Checking Server ...")
 def VV9awz(self):
  path = "%sajpanel_settings_%s" % (VV2Mhn, FFi9KP())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFGBS4(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVfEDN(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFzFRs("find / %s -iname '%s*' | grep %s" % (FFphRM(1), name, name))
  if lines:
   lines.sort()
   VVpLvf = []
   for line in lines:
    VVpLvf.append((line, line))
   FFBYrC(self, boundFunction(self.VV7JeY, title), title=title, VVpLvf=VVpLvf, width=1200)
  else:
   FFCwHk(self, "No settings files found !", title=title)
 def VV7JeY(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFawFw(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VV9U8P()
    FFk2O3()
   else:
    FFurlj(SELF, path, title=title)
 def VV8WGq(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVap4n(self):
  newPath = FFUUJW(VV2Mhn)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV9U8P()
 @staticmethod
 def VVXHYA():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVurNl(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.PIconsPath.setValue(VVDqhd)
  CFG.backupPath.setValue(CCUKTK.VVXHYA())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VV9U8P()
  self.close()
 def VV9U8P(self):
  configfile.save()
  global VV2Mhn
  VV2Mhn = CFG.backupPath.getValue()
  FFAvT5()
 def VVpc6U(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVw5pK(title)
  if webVer:
   FFRzxq(self, boundFunction(FFGw6o, self, boundFunction(self.VVdHRa, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVWnNC(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVw5pK(title, True)
  if webVer:
   FFRzxq(self, boundFunction(FFGw6o, self, boundFunction(self.VVdHRa, webVer, title)), "Install and Restart ?", title=title)
 def VVdHRa(self, webVer, title):
  url = self.VVARki(self, title)
  if url:
   VVhHyb = FFiS2t() == "dpkg"
   if VVhHyb == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVhHyb else "ipk")
   path, err = FF3VVg(url + fName, fName, timeout=2)
   if path:
    cmd = FFHVrF(VVU4WP, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FF0xy0(self, cmd)
    else:
     FFpJtk(self, title=title)
   else:
    FFCwHk(self, err, title=title)
 def VVw5pK(self, title, anyVer=False):
  url = self.VVARki(self, title)
  if not url:
   return ""
  path, err = FF3VVg(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFCwHk(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFItSN(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFCwHk(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVT4M3.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFzFRs(cmd)
   if list and curVer == list[0]:
    return webVer
  FFGBS4(self, FFXMyR("No update required.", VVJH5T) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVARki(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VV2Mhn + VVZGB0
  if fileExists(path):
   span = iSearch(r"(http.+)", FFItSN(path), IGNORECASE)
   if span : url = FFUUJW(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFCwHk(SELF, err, title)
  return url
 @staticmethod
 def VVM7AK(url):
  path, err = FF3VVg(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFItSN(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVT4M3.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFzFRs(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCbagr(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFjy7Y(VVrSVt, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVPcnb
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFwrVg(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVjmN0("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVjmN0("\c00888888", i) + sp + "GREY\n"
   txt += self.VVjmN0("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVjmN0("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVjmN0("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVjmN0("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVjmN0("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVjmN0("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVjmN0("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVjmN0("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVjmN0("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVjmN0("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVlsTV ,
   "green"   : self.VVlsTV ,
   "left"   : self.VVzzRf ,
   "right"   : self.VVmki0 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  self.VVL6lL()
 def VVlsTV(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFRzxq(self, self.VVQz8h, "Change to : %s" % txt, title=self.Title)
 def VVQz8h(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVPcnb
  VVPcnb = self.cursorPos
  self.VVsPkY()
  self.close()
 def VVzzRf(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVL6lL()
 def VVmki0(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVL6lL()
 def VVL6lL(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVjmN0(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVv8nt(color):
  if VVEdAx: return "\\" + color
  else    : return ""
 @staticmethod
 def VVsPkY():
  global VVzRfn, VVsWXS, VVZapb, VViuIz, VVpduW, VVIk8T, VVJH5T, VVEdAx, COLOR_CONS_BRIGHT_YELLOW, VV7ect, VV2SpG, VVVF41
  VVVF41   = CCbagr.VVjmN0("\c00FFFFFF", VVPcnb)
  VVsWXS    = CCbagr.VVjmN0("\c00888888", VVPcnb)
  VVzRfn  = CCbagr.VVjmN0("\c005A5A5A", VVPcnb)
  VVIk8T    = CCbagr.VVjmN0("\c00FF0000", VVPcnb)
  VVZapb   = CCbagr.VVjmN0("\c00FF5000", VVPcnb)
  VVEdAx   = CCbagr.VVjmN0("\c00FFFF00", VVPcnb)
  COLOR_CONS_BRIGHT_YELLOW = CCbagr.VVjmN0("\c00FFFFAA", VVPcnb)
  VVJH5T   = CCbagr.VVjmN0("\c0000FF00", VVPcnb)
  VVpduW    = CCbagr.VVjmN0("\c000066FF", VVPcnb)
  VV7ect    = CCbagr.VVjmN0("\c0000FFFF", VVPcnb)
  VV2SpG   = CCbagr.VVjmN0("\c00FA55E7", VVPcnb)
  VViuIz    = CCbagr.VVjmN0("\c00FF8F5F", VVPcnb)
CCbagr.VVsPkY()
class CCvBr3(Screen):
 def __init__(self, session, path, VVhHyb):
  self.skin, self.skinParam = FFjy7Y(VVp4lb, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVnUmY   = path
  self.VVBc8H   = ""
  self.VVwa4i   = ""
  self.VVhHyb    = VVhHyb
  self.VVNRh1    = ""
  self.VV8j9X  = ""
  self.VVxx8N    = False
  self.VVuuyE  = False
  self.postInstAcion   = 0
  self.VVncEp  = "enigma2-plugin-extensions"
  self.VVqtLe  = "enigma2-plugin-systemplugins"
  self.VVOpkS = "enigma2"
  self.VV5D7W  = 0
  self.VV9jV4  = 1
  self.VVhGUU  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVgJjH = "DEBIAN"
  else        : self.VVgJjH = "CONTROL"
  self.controlPath = self.Path + self.VVgJjH
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVhHyb:
   self.packageExt  = ".deb"
   self.VVrOep  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVrOep  = "#11001020"
  FFwrVg(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFh33U(self["keyRed"] , "Create")
  FFh33U(self["keyGreen"] , "Post Install")
  FFh33U(self["keyYellow"], "Installation Path")
  FFh33U(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVWTrP  ,
   "green"   : self.VVCY98 ,
   "yellow"  : self.VVaG7N  ,
   "blue"   : self.VVx6i2  ,
   "cancel"  : self.VVf0I3
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  FFgCHF(self)
  if self.VVrOep:
   FF7zZI(self["myBody"], self.VVrOep)
   FF7zZI(self["myLabel"], self.VVrOep)
  self.VV3sMX(True)
  self.VVNCHu(True)
 def VVNCHu(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV9PsS()
  if isFirstTime:
   if   package.startswith(self.VVncEp) : self.VVnUmY = VVqVzQ + self.VVNRh1 + "/"
   elif package.startswith(self.VVqtLe) : self.VVnUmY = VVtoxO + self.VVNRh1 + "/"
   else            : self.VVnUmY = self.Path
  if self.VVxx8N : myColor = VViuIz
  else    : myColor = VVVF41
  txt  = ""
  txt += "Source Path\t: %s\n" % FFXMyR(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFXMyR(self.VVnUmY, VVEdAx)
  if self.VVwa4i : txt += "Package File\t: %s\n" % FFXMyR(self.VVwa4i, VVsWXS)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFXMyR("Check Control File fields : %s" % errTxt, VVZapb)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFXMyR("Restart GUI", VViuIz)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFXMyR("Reboot Device", VViuIz)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFXMyR("Post Install", VVJH5T), act)
  if not errTxt and VVZapb in controlInfo:
   txt += "Warning\t: %s\n" % FFXMyR("Errors in control file may affect the result package.", VVZapb)
  txt += "\nControl File\t: %s\n" % FFXMyR(self.controlFile, VVsWXS)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVCY98(self):
  VVpLvf = []
  VVpLvf.append(("No Action"    , "noAction"  ))
  VVpLvf.append(("Restart GUI"    , "VVY6We"  ))
  VVpLvf.append(("Reboot Device"   , "rebootDev"  ))
  FFBYrC(self, self.VVk37q, title="Package Installation Option (after completing installation)", VVpLvf=VVpLvf)
 def VVk37q(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVY6We"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV3sMX(False)
   self.VVNCHu()
 def VVaG7N(self):
  rootPath = FFXMyR("/%s/" % self.VVNRh1, VVzRfn)
  VVpLvf = []
  VVpLvf.append(("Current Path"        , "toCurrent"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Extension Path"       , "toExtensions" ))
  VVpLvf.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVpLvf.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFBYrC(self, self.VVOjTP, title="Installation Path", VVpLvf=VVpLvf)
 def VVOjTP(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVR6ZD(FFtgjE(self.Path, True))
   elif item == "toExtensions"  : self.VVR6ZD(VVqVzQ)
   elif item == "toSystemPlugins" : self.VVR6ZD(VVtoxO)
   elif item == "toRootPath"  : self.VVR6ZD("/")
   elif item == "toRoot"   : self.VVR6ZD("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV11EG, boundFunction(CCRH8h, mode=CCRH8h.VVgIOf, VVWrT9=VV2Mhn))
 def VV11EG(self, path):
  if len(path) > 0:
   self.VVR6ZD(path)
 def VVR6ZD(self, parent, withPackageName=True):
  if withPackageName : self.VVnUmY = parent + self.VVNRh1 + "/"
  else    : self.VVnUmY = "/"
  mode = self.VVfKvQ()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVTJbJ(mode), self.controlFile))
  self.VVNCHu()
 def VVx6i2(self):
  if fileExists(self.controlFile):
   lines = FFawFw(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFQYeU(self, self.VVOLDz, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFCwHk(self, "Version not found or incorrectly set !")
  else:
   FFurlj(self, self.controlFile)
 def VVOLDz(self, VV0ZSY):
  if VV0ZSY:
   version, color = self.VVJCsz(VV0ZSY, False)
   if color == VV7ect:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VV0ZSY, self.controlFile))
    self.VVNCHu()
   else:
    FFCwHk(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVf0I3(self):
  if self.newControlPath:
   if self.VVxx8N:
    self.VVMFaW()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFXMyR(self.newControlPath, VVsWXS)
    txt += FFXMyR("Do you want to keep these files ?", VVEdAx)
    FFRzxq(self, self.close, txt, callBack_No=self.VVMFaW, title="Create Package", VVpF7d=True)
  else:
   self.close()
 def VVMFaW(self):
  os.system(FFfUI2("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVTJbJ(self, mode):
  if   mode == self.VV9jV4 : prefix = self.VVncEp
  elif mode == self.VVhGUU : prefix = self.VVqtLe
  else        : prefix = self.VVOpkS
  return prefix + "-" + self.VV8j9X
 def VVfKvQ(self):
  if   self.VVnUmY.startswith(VVqVzQ) : return self.VV9jV4
  elif self.VVnUmY.startswith(VVtoxO) : return self.VVhGUU
  else            : return self.VV5D7W
 def VV3sMX(self, isFirstTime):
  self.VVNRh1   = os.path.basename(os.path.normpath(self.Path))
  self.VVNRh1   = "_".join(self.VVNRh1.split())
  self.VV8j9X = self.VVNRh1.lower()
  self.VVxx8N = self.VV8j9X == VVtLz2.lower()
  if self.VVxx8N and self.VV8j9X.endswith("ajpan"):
   self.VV8j9X += "el"
  if self.VVxx8N : self.VVBc8H = VV2Mhn
  else    : self.VVBc8H = CFG.packageOutputPath.getValue()
  self.VVBc8H = FFUUJW(self.VVBc8H)
  if not pathExists(self.controlPath):
   os.system(FFfUI2("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVxx8N : t = PLUGIN_NAME
  else    : t = self.VVNRh1
  self.VV2tn0(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVjwdL.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVxx8N : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VV2tn0(self.postrmFile, txt)
  if self.VVxx8N:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVT4M3)
   self.VV2tn0(self.preinstFile, txt)
  else:
   self.VV2tn0(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVNRh1)
  mode = self.VVfKvQ()
  if isFirstTime and not mode == self.VV5D7W:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVjtIv
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VV2tn0(self.postinstFile, txt, VVwFHs=True)
  os.system(FFfUI2("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVxx8N : version, descripton, maintainer = VVT4M3 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVNRh1 , self.VVNRh1
   txt = ""
   txt += "Package: %s\n"  % self.VVTJbJ(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VV2tn0(self, path, lines, VVwFHs=False):
  if not fileExists(path) or VVwFHs:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV9PsS(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFawFw(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFXMyR(line, VVZapb)
     elif not line.startswith(" ")    : line = FFXMyR(line, VVZapb)
     else          : line = FFXMyR(line, VV7ect)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV7ect
   else   : color = VVZapb
   descr = FFXMyR(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVZapb
     elif line.startswith((" ", "\t")) : color = VVZapb
     elif line.startswith("#")   : color = VVsWXS
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVJCsz(val, True)
      elif key == "Version"  : version, color = self.VVJCsz(val, False)
      elif key == "Maintainer" : maint  , color = val, VV7ect
      elif key == "Architecture" : arch  , color = val, VV7ect
      else:
       color = VV7ect
      if not key == "OE" and not key.istitle():
       color = VVZapb
     else:
      color = VViuIz
     txt += FFXMyR(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVwa4i = self.VVBc8H + packageName
   self.VVuuyE = True
   errTxt = ""
  else:
   self.VVwa4i  = ""
   self.VVuuyE = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVJCsz(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV7ect
  else          : return val, VVZapb
 def VVWTrP(self):
  if not self.VVuuyE:
   FFCwHk(self, "Please fix Control File errors first.")
   return
  if self.VVhHyb: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFtgjE(self.VVnUmY, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVNRh1
  symlinkTo  = FF97nD(self.Path)
  dataDir   = self.VVnUmY.rstrip("/")
  removePorjDir = FFfUI2("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFfUI2("rm -f '%s'" % self.VVwa4i) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFLkHT()
  if self.VVhHyb:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF2RkY("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVxx8N:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVnUmY == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVgJjH)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVwa4i, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVwa4i
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVwa4i, FFb5eo(result  , VVJH5T))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVnUmY, FFb5eo(instPath, VV7ect))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFb5eo(failed, VVZapb))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF0xy0(self, cmd)
class CCRH8h(Screen):
 VVZrfT   = 0
 VVgIOf  = 1
 VVa2o5 = 20
 def __init__(self, session, VVWrT9="/", mode=VVZrfT, VV5rCQ="Select", VVvE6h=30):
  self.skin, self.skinParam = FFjy7Y(VVbI0H, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFwrVg(self)
  FFh33U(self["keyRed"] , "Exit")
  FFh33U(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV5rCQ = VV5rCQ
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVZrfT  : VVyshW, self.VVWrT9 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVgIOf : VVyshW, self.VVWrT9 = False, VVWrT9
  else           : VVyshW, self.VVWrT9 = True , VVWrT9
  VVWrT9 = FFUUJW(VVWrT9)
  self["myMenu"] = CC65fO(  directory   = "/"
         , VVyshW   = VVyshW
         , VVY8SD = True
         , VVfSs1   = self.skinParam["width"]
         , VVvE6h   = self.skinParam["bodyFontSize"]
         , VVfASw  = self.skinParam["bodyLineH"]
         , VVpzaX  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVlsTV      ,
   "red"    : self.cancel      ,
   "green"    : self.VVJsJD    ,
   "yellow"   : self.VVZ2vu   ,
   "blue"    : self.VVAgXH   ,
   "menu"    : self.VVDYuF    ,
   "info"    : self.VV4QoA    ,
   "cancel"   : self.VVfWfY     ,
   "pageUp"   : self.VVfWfY     ,
   "chanUp"   : self.VVfWfY
  }, -1)
  FFBFJx(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVj6zG)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVj6zG)
  FFqSyv(self["myMenu"], bg="#06003333")
  FFgCHF(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VVgIOf:
   FFh33U(self["keyGreen"], self.VV5rCQ)
   color = "#22000022"
   FF7zZI(self["myBody"], color)
   FF7zZI(self["myMenu"], color)
   color = "#22220000"
   FF7zZI(self["myTitle"], color)
   FF7zZI(self["myBar"], color)
  self.VVj6zG()
  if self.VVZuOr(self.VVWrT9) > self.bigDirSize:
   FFngIP(self, "Changing directory...")
   FFXHmb(self.VVfg73)
  else:
   self.VVfg73()
 def VVfg73(self):
  self["myMenu"].VVE2z5(self.VVWrT9)
 def VVfsZc(self):
  self["myMenu"].refresh()
  FF9iJ5()
 def VVZuOr(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVlsTV(self):
  if self["myMenu"].VVmjuS():
   path = self.VVrT7s(self.VVupR7())
   if self.VVZuOr(path) > self.bigDirSize:
    FFngIP(self, "Changing directory...")
    FFXHmb(self.VVjuYl)
   else:
    self.VVjuYl()
  else:
   self.VVt5vQ()
 def VVjuYl(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVj6zG()
 def VVfWfY(self):
  if self["myMenu"].VVGeSl():
   self["myMenu"].moveToIndex(0)
   self.VVjuYl()
 def cancel(self):
  if not FFPiv5(self):
   self.close("")
 def VVJsJD(self):
  if self.mode == self.VVgIOf:
   path = self.VVrT7s(self.VVupR7())
   self.close(path)
 def VV4QoA(self):
  FFGw6o(self, self.VVASWz, title="Calculating size ...")
 def VVASWz(self):
  path = self.VVrT7s(self.VVupR7())
  param = self.VVEjZh(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFeABk("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFeABk("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVrbTR(size), format(size, ',d'))
   else   : size = "%s" % self.VVrbTR(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFXMyR(pathTxt, VViuIz) + "\n"
   if slBroken : fileTime = self.VVsiUh(path)
   else  : fileTime = self.VVx0kO(path)
   def VVvXIj(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVvXIj("Path"    , pathTxt)
   txt += VVvXIj("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVvXIj("Target"   , slTarget)
   txt += VVvXIj("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVvXIj("Owner"    , owner)
   txt += VVvXIj("Group"    , group)
   txt += VVvXIj("Perm. (User)"  , permUser)
   txt += VVvXIj("Perm. (Group)"  , permGroup)
   txt += VVvXIj("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVvXIj("Perm. (Ext.)" , permExtra)
   txt += VVvXIj("iNode"    , iNode)
   txt += VVvXIj("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVjtIv, VVjtIv)
    txt += hLinkedFiles
  else:
   FFCwHk(self, "Cannot access information !")
  if len(txt) > 0:
   FFWUy2(self, txt)
 def VVEjZh(self, path):
  path = path.strip()
  path = FF97nD(path)
  result = FFeABk("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVPPQM(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVPPQM(perm, 1, 4)
   permGroup = VVPPQM(perm, 4, 7)
   permOther = VVPPQM(perm, 7, 10)
   permExtra = VVPPQM(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FF1wdX("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVx0kO(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFSqAc(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFSqAc(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFSqAc(os.path.getctime(path))
  return txt
 def VVsiUh(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFeABk("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFeABk("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFeABk("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVrbTR(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVrT7s(self, currentSel):
  currentDir  = self["myMenu"].VVGeSl()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVmjuS():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVupR7(self):
  return self["myMenu"].getSelection()[0]
 def VVj6zG(self):
  FFngIP(self)
  path = self.VVrT7s(self.VVupR7())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVcsAS = self.VV4WBp()
  if VVcsAS and len(VVcsAS) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVYmZN(path)
  if self.mode == self.VVZrfT and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVYmZN(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VViiGs(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVDYuF(self):
  if self.mode == self.VVZrfT:
   path  = self.VVrT7s(self.VVupR7())
   isDir  = os.path.isdir(path)
   VVpLvf = []
   VVpLvf.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVlzmL(path):
     sepShown = True
     VVpLvf.append(VVkUZg)
     VVpLvf.append( (VViuIz + "Archiving / Packaging"      , "VVBVlF"  ))
    if self.VVnvEa(path):
     if not sepShown:
      VVpLvf.append(VVkUZg)
     VVpLvf.append( (VViuIz + "Read Backup information"     , "VVNQXv"  ))
     VVpLvf.append( (VViuIz + "Compress Octagon Image (to zip File)"  , "VVI3LG" ))
   elif os.path.isfile(path):
    selFile = self.VVupR7()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVpLvf.extend(self.VVhlsA(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVpLvf.extend(self.VVkAhb(True))
    elif selFile.endswith(".m3u")              : VVpLvf.extend(self.VVFIz6(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFTMQA(path):
     VVpLvf.append(VVkUZg)
     VVpLvf.append((VViuIz + "View" , "text_View" ))
     VVpLvf.append((VViuIz + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVpLvf.append(VVkUZg)
     VVpLvf.append(   (VViuIz + txt      , "VVt5vQ"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(     ("Create SymLink"       , "VVv3MM" ))
   if not self.VVlzmL(path):
    VVpLvf.append(   ("Rename"          , "VVQTHu" ))
    VVpLvf.append(   ("Copy"           , "copyFileOrDir" ))
    VVpLvf.append(   ("Move"           , "moveFileOrDir" ))
    VVpLvf.append(   ("DELETE"          , "VVFejC" ))
    if fileExists(path):
     VVpLvf.append(VVkUZg)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVpLvf.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVpLvf.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVpLvf.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVpLvf.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVpLvf.append(VVkUZg)
   VVpLvf.append(    ("Set current directory as \"Startup Path\"" , "VVMwje" ))
   FFBYrC(self, self.VVLr4z, title="Options", VVpLvf=VVpLvf)
 def VVLr4z(self, item=None):
  if self.mode == self.VVZrfT:
   if item is not None:
    path = self.VVrT7s(self.VVupR7())
    selFile = self.VVupR7()
    if   item == "properties"    : self.VV4QoA()
    elif item == "VVBVlF"  : self.VVBVlF(path)
    elif item == "VVNQXv"  : self.VVNQXv(path)
    elif item == "VVI3LG" : self.VVI3LG(path)
    elif item.startswith("extract_")  : self.VVCL37(path, selFile, item)
    elif item.startswith("script_")   : self.VVbHAa(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVemKeItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FF8Zbg(self, path)
    elif item.startswith("text_Edit")  : CC9jZC(self, path)
    elif item == "chmod644"     : self.VV8ulJ(path, selFile, "644")
    elif item == "chmod755"     : self.VV8ulJ(path, selFile, "755")
    elif item == "chmod777"     : self.VV8ulJ(path, selFile, "777")
    elif item == "VVv3MM"   : self.VVv3MM(path, selFile)
    elif item == "VVQTHu"   : self.VVQTHu(path, selFile)
    elif item == "copyFileOrDir"   : self.VVzHGw(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVzHGw(path, selFile, True)
    elif item == "VVFejC"   : self.VVFejC(path, selFile)
    elif item == "createNewFile"   : self.VVjYjD(path, True)
    elif item == "createNewDir"    : self.VVjYjD(path, False)
    elif item == "VVMwje"   : self.VVMwje(path)
    elif item == "VVt5vQ"    : self.VVt5vQ()
    else         : self.close()
 def VVt5vQ(self):
  selFile = self.VVupR7()
  path  = self.VVrT7s(selFile)
  if os.path.isfile(path):
   VV7ySt = []
   category = self["myMenu"].VVQbsz(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VV5evc(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FF77Wz(self, selFile, path)
   elif category == "txt"         : FF8Zbg(self, path)
   elif category in ("tar", "zip")       : self.VVWf9k(path, selFile)
   elif category == "scr"         : self.VVK0i7(path, selFile)
   elif category == "m3u"         : self.VV0Cok(path, selFile)
   elif category in ("ipk", "deb")       : self.VVUOIn(path, selFile)
   elif category == "mus"         : self.VVAq5S(path)
   elif category == "mov"         : self.VVAq5S(path)
   elif not FFTMQA(path)        : FF8Zbg(self, path)
 def VVAq5S(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFlnjO(self, refCode)
  except:
   pass
 def VVZ2vu(self):
  path = self.VVrT7s(self.VVupR7())
  action = self.VVYmZN(path)
  if action == 1:
   self.VV17Ez(path)
   FFngIP(self, "Added", 500)
  elif action == -1:
   self.VVB1Qo(path)
   FFngIP(self, "Removed", 500)
  self.VVYmZN(path)
 def VV17Ez(self, path):
  VVcsAS = self.VV4WBp()
  if not VVcsAS:
   VVcsAS = []
  if len(VVcsAS) >= self.VVa2o5:
   FFCwHk(SELF, "Max bookmarks reached (max=%d)." % self.VVa2o5)
  elif not path in VVcsAS:
   VVcsAS = [path] + VVcsAS
   self.VVMHWd(VVcsAS)
 def VVAgXH(self):
  VVcsAS = self.VV4WBp()
  if VVcsAS:
   newList = []
   for line in VVcsAS:
    newList.append((line, line))
   VVFOel  = ("Delete"  , self.VV39oy )
   VVgMyE = ("Move Up"   , self.VV2DTp )
   VVKjVK  = ("Move Down" , self.VVHSEa )
   self.bookmarkMenu = FFBYrC(self, self.VVRUYQ, title="Bookmarks", VVpLvf=newList, VVFOel=VVFOel, VVgMyE=VVgMyE, VVKjVK=VVKjVK)
 def VV39oy(self, VVupR7Obj, path):
  if self.bookmarkMenu:
   VVcsAS = self.VVB1Qo(path)
   self.bookmarkMenu.VVyJKa(VVcsAS)
 def VV2DTp(self, VVupR7Obj, path):
  if self.bookmarkMenu:
   VVcsAS = self.bookmarkMenu.VVydwe(True)
   if VVcsAS:
    self.VVMHWd(VVcsAS)
 def VVHSEa(self, VVupR7Obj, path):
  if self.bookmarkMenu:
   VVcsAS = self.bookmarkMenu.VVydwe(False)
   if VVcsAS:
    self.VVMHWd(VVcsAS)
 def VVRUYQ(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVE2z5(folder)
   self["myMenu"].moveToIndex(0)
  self.VVj6zG()
 def VV4WBp(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VViiGs(self, path):
  VVcsAS = self.VV4WBp()
  if VVcsAS and path in VVcsAS:
   return True
  else:
   return False
 def VVL4l2(self):
  if VV4WBp():
   return True
  else:
   return False
 def VVMHWd(self, VVcsAS):
  line = ",".join(VVcsAS)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVB1Qo(self, path):
  VVcsAS = self.VV4WBp()
  if VVcsAS:
   while path in VVcsAS:
    VVcsAS.remove(path)
   self.VVMHWd(VVcsAS)
   return VVcsAS
 def VVMwje(self, path):
  if not os.path.isdir(path):
   path = FFtgjE(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VV5evc(self, selFile, VVWKlK, command):
  FFRzxq(self, boundFunction(FF0xy0, self, command, VVfFKv=self.VVfsZc), "%s\n\n%s" % (VVWKlK, selFile))
 def VVhlsA(self, path, calledFromMenu):
  destPath = self.VVoHbY(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVpLvf = []
  if calledFromMenu:
   VVpLvf.append(VVkUZg)
   color = VViuIz
  else:
   color = ""
  VVpLvf.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVpLvf.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVpLvf.append((color + "Extract Here"            , "extract_here"  ))
  if VVhYf3 and path.endswith(".tar.gz"):
   VVpLvf.append(VVkUZg)
   VVpLvf.append((color + 'Convert to ".ipk" Package' , "VVC2xb"  ))
   VVpLvf.append((color + 'Convert to ".deb" Package' , "VVtGk4"  ))
  return VVpLvf
 def VVWf9k(self, path, selFile):
  FFBYrC(self, boundFunction(self.VVCL37, path, selFile), title="Tar File Options", VVpLvf=self.VVhlsA(path, False))
 def VVCL37(self, path, selFile, item=None):
  if item is not None:
   parent  = FFtgjE(path, False)
   destPath = self.VVoHbY(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVjtIv
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVjtIv, VVjtIv)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FF1HQ0(self, cmd)
   elif path.endswith(".zip"):
    self.VVD6qf(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFfUI2("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV5evc(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV5evc(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFtgjE(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV5evc(selFile, "Extract Here ?"      , cmd)
   elif item == "VVC2xb" : self.VVC2xb(path)
   elif item == "VVtGk4" : self.VVtGk4(path)
 def VVoHbY(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVD6qf(self, item, path, parent, destPath, VVWKlK):
  FFRzxq(self, boundFunction(self.VV6w7Z, item, path, parent, destPath), VVWKlK)
 def VV6w7Z(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVjtIv
  cmd  = FF2RkY("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFb5eo(destPath, VVJH5T))
  cmd +=   sep
  cmd += "fi;"
  FFleJp(self, cmd, VVfFKv=self.VVfsZc)
 def VVkAhb(self, addSep=False):
  VVpLvf = []
  if addSep:
   VVpLvf.append(VVkUZg)
  VVpLvf.append((VViuIz + "View Script File"  , "script_View"  ))
  VVpLvf.append((VViuIz + "Execute Script File" , "script_Execute" ))
  VVpLvf.append((VViuIz + "Edit"     , "script_Edit" ))
  return VVpLvf
 def VVK0i7(self, path, selFile):
  FFBYrC(self, boundFunction(self.VVbHAa, path, selFile), title="Script File Options", VVpLvf=self.VVkAhb())
 def VVbHAa(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF8Zbg(self, path)
   elif item == "script_Execute" : self.VV5evc(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC9jZC(self, path)
 def VVFIz6(self, addSep=False):
  VVpLvf = []
  if addSep:
   VVpLvf.append(VVkUZg)
  VVpLvf.append((VViuIz + "View"      , "m3u_View" ))
  VVpLvf.append((VViuIz + "Edit"      , "m3u_Edit" ))
  VVpLvf.append((VViuIz + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVpLvf
 def VV0Cok(self, path, selFile):
  FFBYrC(self, boundFunction(self.VVemKeItem_m3u, path, selFile), title="M3U File Options", VVpLvf=self.VVFIz6())
 def VVemKeItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FF8Zbg(self, path)
   elif item == "m3u_Edit"  : CC9jZC(self, path)
   elif item == "m3u_Convert" : CCDch1.VV6MZj(self, path, False)
 def VV8ulJ(self, path, selFile, newChmod):
  FFRzxq(self, boundFunction(self.VV1Qhv, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV1Qhv(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV2oWO)
  result = FFeABk(cmd)
  if result == "Successful" : FFGBS4(self, result)
  else      : FFCwHk(self, result)
 def VVv3MM(self, path, selFile):
  parent = FFtgjE(path, False)
  self.session.openWithCallback(self.VVdXsB, boundFunction(CCRH8h, mode=CCRH8h.VVgIOf, VVWrT9=parent, VV5rCQ="Create Symlink here"))
 def VVdXsB(self, newPath):
  if len(newPath) > 0:
   target = self.VVrT7s(self.VVupR7())
   target = FF97nD(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFUUJW(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFCwHk(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFRzxq(self, boundFunction(self.VVuHey, target, link), "Create Soft Link ?\n\n%s" % txt, VVpF7d=True)
 def VVuHey(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV2oWO)
  result = FFeABk(cmd)
  if result == "Successful" : FFGBS4(self, result)
  else      : FFCwHk(self, result)
 def VVQTHu(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFQYeU(self, boundFunction(self.VVCQlC, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVCQlC(self, path, selFile, VV0ZSY):
  if VV0ZSY:
   parent = FFtgjE(path, True)
   if os.path.isdir(path):
    path = FF97nD(path)
   newName = parent + VV0ZSY
   cmd = "mv '%s' '%s' %s" % (path, newName, VV2oWO)
   if VV0ZSY:
    if selFile != VV0ZSY:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFRzxq(self, boundFunction(self.VVD4OX, cmd), message, title="Rename file?")
    else:
     FFCwHk(self, "Cannot use same name!", title="Rename")
 def VVD4OX(self, cmd):
  result = FFeABk(cmd)
  if "Fail" in result:
   FFCwHk(self, result)
  self.VVfsZc()
 def VVzHGw(self, path, selFile, isMove):
  if isMove : VV5rCQ = "Move to here"
  else  : VV5rCQ = "Copy to here"
  parent = FFtgjE(path, False)
  self.session.openWithCallback(boundFunction(self.VVheGu, isMove, path, selFile)
         , boundFunction(CCRH8h, mode=CCRH8h.VVgIOf, VVWrT9=parent, VV5rCQ=VV5rCQ))
 def VVheGu(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FF97nD(path)
   newPath = FFUUJW(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFRzxq(self, boundFunction(FFTQP2, self, cmd, VVfFKv=self.VVfsZc), txt, VVpF7d=True)
   else:
    FFCwHk(self, "Cannot %s to same directory !" % action.lower())
 def VVFejC(self, path, fileName):
  path = FF97nD(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFRzxq(self, boundFunction(self.VVbwun, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVbwun(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVfsZc()
 def VVlzmL(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVzipJ and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVjYjD(self, path, isFile):
  dirName = FFUUJW(os.path.dirname(path))
  if isFile : objName, VV0ZSY = "File"  , self.edited_newFile
  else  : objName, VV0ZSY = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFQYeU(self, boundFunction(self.VV78PI, dirName, isFile, title), title=title, defaultText=VV0ZSY, message="Enter %s Name:" % objName)
 def VV78PI(self, dirName, isFile, title, VV0ZSY):
  if VV0ZSY:
   if isFile : self.edited_newFile = VV0ZSY
   else  : self.edited_newDir  = VV0ZSY
   path = dirName + VV0ZSY
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV2oWO)
    else  : cmd = "mkdir '%s' %s" % (path, VV2oWO)
    result = FFeABk(cmd)
    if "Fail" in result:
     FFCwHk(self, result)
    self.VVfsZc()
   else:
    FFCwHk(self, "Name already exists !\n\n%s" % path, title)
 def VVUOIn(self, path, selFile):
  VVpLvf = []
  VVpLvf.append(("List Package Files"          , "VVabcS"     ))
  VVpLvf.append(("Package Information"          , "VVFhrt"     ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Install Package"           , "VVYMxp_CheckVersion" ))
  VVpLvf.append(("Install Package (force reinstall)"      , "VVYMxp_ForceReinstall" ))
  VVpLvf.append(("Install Package (force downgrade)"      , "VVYMxp_ForceDowngrade" ))
  VVpLvf.append(("Install Package (ignore failed dependencies)"    , "VVYMxp_IgnoreDepends" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Remove Related Package"         , "VV4V3M_ExistingPackage" ))
  VVpLvf.append(("Remove Related Package (force remove)"     , "VV4V3M_ForceRemove"  ))
  VVpLvf.append(("Remove Related Package (ignore failed dependencies)"  , "VV4V3M_IgnoreDepends" ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("Extract Files"           , "VVjToR"     ))
  VVpLvf.append(("Unbuild Package"           , "VV4fjD"     ))
  FFBYrC(self, boundFunction(self.VVrzU3, path, selFile), VVpLvf=VVpLvf)
 def VVrzU3(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVabcS"      : self.VVabcS(path, selFile)
   elif item == "VVFhrt"      : self.VVFhrt(path)
   elif item == "VVYMxp_CheckVersion"  : self.VVYMxp(path, selFile, VVL2aE     )
   elif item == "VVYMxp_ForceReinstall" : self.VVYMxp(path, selFile, VVU4WP )
   elif item == "VVYMxp_ForceDowngrade" : self.VVYMxp(path, selFile, VVZvVv )
   elif item == "VVYMxp_IgnoreDepends" : self.VVYMxp(path, selFile, VVv2YB )
   elif item == "VV4V3M_ExistingPackage" : self.VV4V3M(path, selFile, VVpb9g     )
   elif item == "VV4V3M_ForceRemove"  : self.VV4V3M(path, selFile, VVOUmA  )
   elif item == "VV4V3M_IgnoreDepends"  : self.VV4V3M(path, selFile, VVH1Wq )
   elif item == "VVjToR"     : self.VVjToR(path, selFile)
   elif item == "VV4fjD"     : self.VV4fjD(path, selFile)
   else           : self.close()
 def VVabcS(self, path, selFile):
  if FF8Snx("ar") : cmd = "allOK='1';"
  else    : cmd  = FFLkHT()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVjtIv, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVjtIv, VVjtIv)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFo8kY(self, cmd, VVfFKv=self.VVfsZc)
 def VVjToR(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFtgjE(path, True) + selFile[:-4]
  cmd  =  FFLkHT()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFfUI2("mkdir '%s'" % dest) + ";"
  cmd +=    FFfUI2("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFb5eo(dest, VVJH5T))
  cmd += "fi;"
  FF0xy0(self, cmd, VVfFKv=self.VVfsZc)
 def VV4fjD(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV1PP7 = os.path.splitext(path)[0]
  else        : VV1PP7 = path + "_"
  if path.endswith(".deb")   : VVgJjH = "DEBIAN"
  else        : VVgJjH = "CONTROL"
  cmd  = FFLkHT()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV1PP7, FFo2cU())
  cmd += "  mkdir '%s';"    % VV1PP7
  cmd += "  CONTPATH='%s/%s';"  % (VV1PP7, VVgJjH)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV1PP7
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV1PP7, VV1PP7)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV1PP7
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV1PP7, VV1PP7)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV1PP7
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV1PP7
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV1PP7, FFb5eo(VV1PP7, VVJH5T))
  cmd += "fi;"
  FF0xy0(self, cmd, VVfFKv=self.VVfsZc)
 def VVFhrt(self, path):
  listCmd  = FFVqya(VVKI1q, "")
  infoCmd  = FFHVrF(VVq5HK , "")
  filesCmd = FFHVrF(VVCwg3, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFgvYp(VVEdAx)
   notInst = "Package not installed."
   cmd  = FFmD5M("File Info", VVEdAx)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFmD5M("System Info", VVEdAx)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFb5eo(notInst, VViuIz))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFmD5M("Related Files", VVEdAx)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF1HQ0(self, cmd)
  else:
   FFpJtk(self)
 def VVYMxp(self, path, selFile, cmdOpt):
  cmd = FFHVrF(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFRzxq(self, boundFunction(FF0xy0, self, cmd, VVfFKv=FF9iJ5), "Install Package ?\n\n%s" % selFile)
  else:
   FFpJtk(self)
 def VV4V3M(self, path, selFile, cmdOpt):
  listCmd  = FFVqya(VVKI1q, "")
  infoCmd  = FFHVrF(VVq5HK, "")
  instRemCmd = FFHVrF(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFb5eo(errTxt, VViuIz))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFb5eo(cannotTxt, VViuIz))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFb5eo(tryTxt, VViuIz))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFRzxq(self, boundFunction(FF0xy0, self, cmd, VVfFKv=FF9iJ5), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFpJtk(self)
 def VVrhU5(self, path):
  hostName = FFeABk("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVnvEa(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVrhU5(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVBVlF(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVpLvf = []
  VVpLvf.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVpLvf.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVpLvf.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVpLvf.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVpLvf.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVpLvf.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVpLvf.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVpLvf.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVpLvf.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVpLvf.append(VVkUZg)
  VVpLvf.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVpLvf.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFBYrC(self, boundFunction(self.VVWaI6, path), VVpLvf=VVpLvf)
 def VVWaI6(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVKUgb(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVKUgb(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVKUgb(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVKUgb(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVKUgb(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVKUgb(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVKUgb(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVKUgb(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVKUgb(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVKUgb(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VV1cuP(path, False)
   elif item == "convertDirToDeb"   : self.VV1cuP(path, True)
   else         : self.close()
 def VV1cuP(self, path, VVhHyb):
  self.session.openWithCallback(self.VVfsZc, boundFunction(CCvBr3, path=path, VVhHyb=VVhHyb))
 def VVKUgb(self, path, fileExt, preserveDirStruct):
  parent  = FFtgjE(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF2RkY("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF2RkY("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF2RkY("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVjtIv
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFfUI2("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFb5eo(resultFile, VVJH5T))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFb5eo(failed, VVZapb))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFo8kY(self, cmd, VVfFKv=self.VVfsZc)
 def VVNQXv(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FF8Zbg(self, versionFile)
 def VVI3LG(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVrhU5(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFCwHk(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFawFw(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFtgjE(path, False)
  VV1PP7 = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFb5eo(errCmd, VVZapb))
  installCmd = FFHVrF(VVL2aE , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV1PP7, VV1PP7)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV1PP7
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV1PP7
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV1PP7, VV1PP7)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FF0xy0(self, cmd, VVfFKv=self.VVfsZc)
 def VVC2xb(self, path):
  FFCwHk(self, "Under Construction.")
 def VVtGk4(self, path):
  FFCwHk(self, "Under Construction.")
class CC65fO(MenuList):
 def __init__(self, VVY8SD=False, directory="/", VVehJT=True, VVyshW=True, VVfyrD=True, VV2poF=None, VVTAMh=False, VVxCgV=False, VVseGl=False, isTop=False, VVPweR=None, VVfSs1=1000, VVvE6h=30, VVfASw=30, VVpzaX="#00000000"):
  MenuList.__init__(self, list, VVY8SD, eListboxPythonMultiContent)
  self.VVehJT  = VVehJT
  self.VVyshW    = VVyshW
  self.VVfyrD  = VVfyrD
  self.VV2poF  = VV2poF
  self.VVTAMh   = VVTAMh
  self.VVxCgV   = VVxCgV or []
  self.VVseGl   = VVseGl or []
  self.isTop     = isTop
  self.additional_extensions = VVPweR
  self.VVfSs1    = VVfSs1
  self.VVvE6h    = VVvE6h
  self.VVfASw    = VVfASw
  self.pngBGColor    = FFJQUL(VVpzaX)
  self.EXTENSIONS    = self.VVb85B()
  self.VVUNsv   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVkLUF, self.VVvE6h))
  self.l.setItemHeight(self.VVfASw)
  self.png_mem   = self.VVSOkq("mem")
  self.png_usb   = self.VVSOkq("usb")
  self.png_fil   = self.VVSOkq("fil")
  self.png_dir   = self.VVSOkq("dir")
  self.png_dirup   = self.VVSOkq("dirup")
  self.png_srv   = self.VVSOkq("srv")
  self.png_slwfil   = self.VVSOkq("slwfil")
  self.png_slbfil   = self.VVSOkq("slbfil")
  self.png_slwdir   = self.VVSOkq("slwdir")
  self.VVyyBU()
  self.VVE2z5(directory)
 def VVSOkq(self, category):
  return LoadPixmap("%s%s.png" % (VVmF17, category), getDesktop(0))
 def VVb85B(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVaBUo(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FF97nD(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFXMyR(" -> " , VVEdAx) + FFXMyR(os.readlink(path), VVJH5T)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVfASw + 10, 0, self.VVfSs1, self.VVfASw, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVUkce: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVfASw-4, self.VVfASw-4, png, self.pngBGColor, self.pngBGColor, VVUkce))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVfASw-4, self.VVfASw-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVQbsz(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVyyBU(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVSKSS(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVve04(self, file):
  if os.path.realpath(file) == file:
   return self.VVSKSS(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVSKSS(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVSKSS(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVsxaM(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVUNsv.info(l[0][0]).getEvent(l[0][0])
 def VVHN5V(self):
  return self.list
 def VVYIoG(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVE2z5(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVfyrD:
    self.current_mountpoint = self.VVve04(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVfyrD:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVseGl and not self.VVYIoG(path, self.VVxCgV):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVaBUo(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVTAMh:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVUNsv = eServiceCenter.getInstance()
   list = VVUNsv.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVehJT and not self.isTop:
   if directory == self.current_mountpoint and self.VVfyrD:
    self.list.append(self.VVaBUo(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVseGl and self.VVSKSS(directory) in self.VVseGl):
    self.list.append(self.VVaBUo(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVehJT:
   for x in directories:
    if not (self.VVseGl and self.VVSKSS(x) in self.VVseGl) and not self.VVYIoG(x, self.VVxCgV):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVaBUo(name = name, absolute = x, isDir = True, png = png))
  if self.VVyshW:
   for x in files:
    if self.VVTAMh:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFXMyR(" -> " , VVEdAx) + FFXMyR(target, VVJH5T)
       else:
        png = self.png_slbfil
        name += FFXMyR(" -> " , VVEdAx) + FFXMyR(target, VVZapb)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVQbsz(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVmF17, category))
    if (self.VV2poF is None) or iCompile(self.VV2poF).search(path):
     self.list.append(self.VVaBUo(name = name, absolute = x , isDir = False, png = png))
  if self.VVfyrD and len(self.list) == 0:
   self.list.append(self.VVaBUo(name = FFXMyR("No USB connected", VVsWXS), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVGeSl(self):
  return self.current_directory
 def VVmjuS(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVE2z5(self.getSelection()[0], select = self.current_directory)
 def VV9boF(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVAWYV(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVFvzQ)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVFvzQ)
 def refresh(self):
  self.VVE2z5(self.current_directory, self.VV9boF())
 def VVFvzQ(self, action, device):
  self.VVyyBU()
  if self.current_directory is None:
   self.refresh()
class CC89tO(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFjy7Y(WINDOW_COLORS, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVcsAS   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVXeng(defFG, "#00FFFFFF")
  self.defBG   = self.VVXeng(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFwrVg(self, self.Title)
  self["keyRed"].show()
  FFh33U(self["keyGreen"] , "< > Transp.")
  FFh33U(self["keyYellow"], "Foreground")
  FFh33U(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVDdzA        ,
   "yellow"   : boundFunction(self.VVgqgR, False)  ,
   "blue"   : boundFunction(self.VVgqgR, True)  ,
   "up"   : self.VVZGKM          ,
   "down"   : self.VVYZh7         ,
   "left"   : self.VVzzRf         ,
   "right"   : self.VVmki0         ,
   "last"   : boundFunction(self.VVdHas, -5) ,
   "next"   : boundFunction(self.VVdHas, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVH8dW)
 def VVH8dW(self):
  self.onShown.remove(self.VVH8dW)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF7zZI(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF7zZI(self["keyRed"] , c)
  FF7zZI(self["keyGreen"] , c)
  self.VVnAxZ()
  self.VViYia()
  FFwT6X(self["myColorTst"], self.defFG)
  FF7zZI(self["myColorTst"], self.defBG)
 def VVXeng(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VViYia(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVV4k7(0, 0)
     return
 def VVDdzA(self):
  self.close(self.defFG, self.defBG)
 def VVZGKM(self): self.VVV4k7(-1, 0)
 def VVYZh7(self): self.VVV4k7(1, 0)
 def VVzzRf(self): self.VVV4k7(0, -1)
 def VVmki0(self): self.VVV4k7(0, 1)
 def VVV4k7(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVszyC()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVY33f()
 def VVnAxZ(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVY33f(self):
  color = self.VVszyC()
  if self.isBgMode: FF7zZI(self["myColorTst"], color)
  else   : FFwT6X(self["myColorTst"], color)
 def VVgqgR(self, isBg):
  self.isBgMode = isBg
  self.VVnAxZ()
  self.VViYia()
 def VVdHas(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVV4k7(0, 0)
 def VVBJ14(self):
  return hex(self.transp)[2:].zfill(2)
 def VVszyC(self):
  return ("#%s%s" % (self.VVBJ14(), self.colors[self.curRow][self.curCol])).upper()
class CC1bAh(ScrollLabel):
 def __init__(self, parentSELF, text="", VVGoOD=True):
  ScrollLabel.__init__(self, text)
  self.VVGoOD=VVGoOD
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVT61A  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVvE6h    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVnlPz   ,
   "green"   : self.VVoerQ  ,
   "yellow"  : self.VVojuJ  ,
   "blue"   : self.VVuwl9  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVrSuu    ,
   "chanUp"  : self.VVrSuu    ,
   "pageDown"  : self.VVNA7i    ,
   "chanDown"  : self.VVNA7i
  }, -1)
 def VVZF8s(self, isResizable=True, VVdW3j=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFgCHF(self.parentSELF, True)
  self.isResizable = isResizable
  if VVdW3j:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVvE6h  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF7zZI(self, color)
 def FF7zZIColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVT61A - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVCHuh()
 def pageUp(self):
  if self.VVT61A > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVT61A > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVrSuu(self):
  self.setPos(0)
 def VVNA7i(self):
  self.setPos(self.VVT61A-self.pageHeight)
 def VV7l5Q(self):
  return self.VVT61A <= self.pageHeight or self.curPos == self.VVT61A - self.pageHeight
 def VVCHuh(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVT61A, 3))
   start = int((100 - vis) * self.curPos / (self.VVT61A - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVJPTL=VV7TFL):
  old_VV7l5Q = self.VV7l5Q()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVT61A = self.long_text.calculateSize().height()
   if self.VVGoOD and self.VVT61A > self.pageHeight:
    self.scrollbar.show()
    self.VVCHuh()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVT61A))
   if   VVJPTL == VVifYP: self.setPos(0)
   elif VVJPTL == VVHcSs : self.VVNA7i()
   elif old_VV7l5Q    : self.VVNA7i()
 def appendText(self, text, VVJPTL=VVHcSs):
  self.setText(self.message + str(text), VVJPTL)
 def VVojuJ(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVMw5D(size)
 def VVuwl9(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVMw5D(size)
 def VVoerQ(self):
  self.VVMw5D(self.VVvE6h)
 def VVMw5D(self, VVvE6h):
  self.long_text.setFont(gFont(self.fontFamily, VVvE6h))
  self.setText(self.message, VVJPTL=VV7TFL)
  self.VV5KUx(calledFromFontSizer=True)
 def VVnlPz(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFUUJW(expPath), self.textOutFile, FFi9KP())
    with open(outF, "w") as f:
     f.write(FFAwDH(self.message))
    FFGBS4(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFCwHk(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV5KUx(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVT61A > 0 and self.pageHeight > 0:
   if self.VVT61A < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVT61A
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
