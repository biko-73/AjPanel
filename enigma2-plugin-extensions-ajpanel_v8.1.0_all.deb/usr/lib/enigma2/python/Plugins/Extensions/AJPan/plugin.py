import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVS3nw   = "v8.1.0"
VVBcwB    = "03-12-2022"
EASY_MODE    = 0
VV7z1t   = 0
VVMJ2u   = 0
VVP65U  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVXS9f  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VV4J76    = "/media/usb/"
VVqf27    = "/usr/share/enigma2/picon/"
VVp2o0 = "/etc/enigma2/blacklist"
VVmqmq   = "/etc/enigma2/"
VVqIfZ   = "AJPan"
VVh5ZI  = "AUTO FIND"
VVLwC1  = "Custom"
VVZDlR    = ""
VV8loG = "Regular"
VVD6qa = "Fixed"
VVRklX  = "AJP_Main"
VVIBYu = "AJP_Terminal"
VVDlhL = "AJP_System"
VVlQv4  = VV8loG
VVbL9B      = "-" * 80
VVNCuu    = ("-" * 100, )
VVhtbL    = ""
VV6BHw   = " && echo 'Successful' || echo 'Failed!'"
VV2xkj    = []
VVhfZS  = "Cannot continue (No Enough Memory) !"
VVttXz  = False
VVCvlJ  = False
VVilCV     = 0
VVCVur    = 1
VVAG6M    = 2
VVtcbV   = 3
VVamHR    = 4
VVQsOr    = 5
VV16CN = 6
VVrQkp = 7
VVeaJc  = 8
VVscCR   = 9
VVuk51  = 10
VVpxLn  = 11
VVO6R4 = 12
VVlugA    = 13
VVXLg7   = 14
VVxiVV   = 15
VVdUpq    = 16
VVzYQ4    = 17
VVeAgx  = 18
VVHX1w    = 19
VVdsyE   = 0
VVo3oH   = 1
VVlCEy   = 2
def FFfDUs():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVlQv4
  if VVRklX in lst and CFG.fontPathMain.getValue(): VVlQv4 = VVRklX
  else               : VVlQv4 = VV8loG
  return lst
 else:
  return [VV8loG]
def FFGPE5(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit File Manage")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVh5ZI, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVqf27, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VV4J76, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
tmp = [("srt", "FROM SRT FILE"),("#00FFFF", "Aqua"),("#000000", "Black"),("#0000FF", "Blue"),("#FF00FF", "Fuchsia"),("#808080", "Gray"),("#008000", "Green"),("#00FF00", "Lime"),("#800000", "Maroon"),("#000080", "Navy"),("#808000", "Olive"),("#800080", "Purple"),("#FF0000", "Red"),("#C0C0C0", "Silver"),("#008080", "Teal"),("#FFFFFF", "White"),("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVlQv4, choices=[(x,  x) for x in FFfDUs()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFD3BJ():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVFnGR  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV6HAy = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVFnGR  : return 0
  elif VV6HAy : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFD3BJ()
VV2vWn = VVekE1 = VVpiVU = VVHeSZ = VV0kWR = VVyuFD = VVjQpG = VVQtLp = VVs4yr = VVusL5 = VVsZ3Y = VVWFW6 = VVpihg = VVRK3s = VVpZn3 = VVBNow = ""
def FFFGaA()  : FF5KSU(FFtaB7())
def FF8SmQ()  : FF5KSU(FFxbh9())
def FFRiXu(tDict): FF5KSU(iDumps(tDict, indent=4, sort_keys=True))
def FFufJU(*args): FFdj1W(True, True, *args)
def FF5KSU(*args) : FFdj1W(True , False , *args)
def FFw9UA(*args): FFdj1W(False, False, *args)
def FFdj1W(addSep=True, isArray=True, *args):
 if VV7z1t:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(key.ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFSgsi(fnc):
 def VVRP5H(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FF5KSU(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVRP5H
def FFsWIM(*args):
 if VV7z1t:
  path = "/tmp/ajpanel_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFw9UA("Added to : %s" % path)
def FF6KDy(txt, isAppend=True, ignoreErr=False):
 if VV7z1t:
  tm = FFSngc()
  err = ""
  if not ignoreErr:
   err = FFxbh9()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF5KSU(err)
  FF5KSU("Output Log File : %s" % fileName)
def FFxbh9():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFSngc()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFtaB7():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVdeOB = 0
def FF1x37():
 global VVdeOB
 VVdeOB = iTime()
def FFb3fm(txt=""):
 FF5KSU(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVdeOB)).rstrip("0"), txt))
VV2xkj = []
def FFNMqr(win):
 global VV2xkj
 if not win in VV2xkj:
  VV2xkj.append(win)
def FFi0ku(*args):
 global VV2xkj
 for win in VV2xkj:
  try:
   win.close()
  except:
   pass
 VV2xkj = []
def FFrU8d():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV3xZT = FFrU8d()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFpVrF()    : return PluginDescriptor(fnc=FF4xPA, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFSRw7()      : return getDescriptor(FFNTk8 , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFPTEp()     : return getDescriptor(FFJNYK  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFPQCU()  : return getDescriptor(FFqFlL, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFNqaN() : return getDescriptor(FFlquV , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FF8PJd()  : return getDescriptor(FF1BWA , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFbqFe()  : return getDescriptor(FFajJJ  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFGO2T()    : return getDescriptor(FFlC2L, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFPTEp() , FFSRw7() , FFpVrF() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFPQCU())
  result.append(FFNqaN())
  result.append(FF8PJd())
  result.append(FFbqFe())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFGO2T())
 return result
def FF4xPA(reason, **kwargs):
 if reason == 0:
  FFOUth()
  if "session" in kwargs:
   session = kwargs["session"]
   FFVM5J(session)
   CCZuyK(session)
def FFNTk8(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFJNYK, PLUGIN_NAME, 45)]
 else:
  return []
def FFJNYK(session, **kwargs):
 session.open(Main_Menu)
def FFqFlL(session, **kwargs):
 session.open(CCk3u6)
def FFlquV(session, **kwargs):
 session.open(CCHF2n)
def FF1BWA(session, **kwargs):
 CCqzRz.VVfphk(session, isFromExternal=True)
def FFajJJ(session, **kwargs):
 FF0wqg(session, reopen=True)
def FFlC2L(session, **kwargs):
 session.open(CCfm5u, fncMode=CCfm5u.VVXXAh)
def FFu8f1():
 FFpcS2(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFPQCU(), FFNqaN(), FF8PJd(), FFbqFe() ])
 FFpcS2(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFGO2T() ])
def FFpcS2(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVEbrm = None
def FFOUth():
 try:
  global VVEbrm
  if VVEbrm is None:
   VVEbrm    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFoFJY
  ChannelContextMenu.FFUapf = FFUapf
 except:
  pass
def FFoFJY(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVEbrm(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFUapf, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFUapf, title1, csel, isFind=True))))
def FFUapf(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFyJel(refCode)
 except:
  pass
 self.session.open(BF(CCj1BH, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFVM5J(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFYnCe, session, "lok")
 hk.actions["longCancel"]= BF(FFYnCe, session, "lesc")
 hk.actions["longRed"] = BF(FFYnCe, session, "lred")
 for k in (CCxpGD.VVlvF8, CCxpGD.VV0kSk, CCxpGD.VVNoLN):
  hk.actions[k] = BF(CCxpGD.VVx1a3, session, k)
def FFYnCe(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCk768.VVXZMJ:
    CCk768.VVXZMJ.close()
   if not CCqzRz.VVRX23:
    CCqzRz.VVfphk(session, isFromExternal=True)
  except:
   pass
def FFWvPK(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFrOoX(SELF, title="", addLabel=False, addScrollLabel=False, VVd21k=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFphjG()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC5iEy(SELF)
 if VVd21k:
  SELF["myMenu"] = MenuList(VVd21k)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVw6vF ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFiLOZ(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FF2RYM, SELF, "0"),
  "1" : BF(FF2RYM, SELF, "1"),
  "2" : BF(FF2RYM, SELF, "2"),
  "3" : BF(FF2RYM, SELF, "3"),
  "4" : BF(FF2RYM, SELF, "4"),
  "5" : BF(FF2RYM, SELF, "5"),
  "6" : BF(FF2RYM, SELF, "6"),
  "7" : BF(FF2RYM, SELF, "7"),
  "8" : BF(FF2RYM, SELF, "8"),
  "9" : BF(FF2RYM, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFBK8I, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF2RYM(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVBNow:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVBNow + SELF.keyPressed + VVekE1)
    txt = VVekE1 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFkxeT(SELF, txt)
def FFBK8I(SELF, tableObj, colNum, isMenu):
 FFkxeT(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFFnqK(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVDB8c(i)
     else  : SELF.VVQ2AR(i)
     break
 except:
  pass
def FFphjG():
 return ("  %s" % VVhtbL)
def FFddoJ(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFFnqK(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFj7n6(color):
 return parseColor(color).argb()
def FFm6nb(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFrI2P(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF1h4U(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFDB5L(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVBNow)
 else:
  return ""
def FFofzq(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVbL9B, word, VVbL9B, VVBNow)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVbL9B, word, VVbL9B)
def FFHqZk(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVBNow
def FF95QJ(color):
 if color: return "echo -e '%s' %s;" % (VVbL9B, FFDB5L(VVbL9B, VVsZ3Y))
 else : return "echo -e '%s';" % VVbL9B
def FF8jk7(title, color):
 title = "%s\n%s\n%s\n" % (VVbL9B, title, VVbL9B)
 return FFHqZk(title, color)
def FFmysb(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFmGpj(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFnCJX(callBackFunction):
 tCons = CCN83i()
 tCons.ePopen("echo", BF(FFCE9n, callBackFunction))
def FFCE9n(callBackFunction, result, retval):
 callBackFunction()
def FFqcaP(SELF, fnc, title="Processing ...", clearMsg=True):
 FFkxeT(SELF, title)
 tCons = CCN83i()
 tCons.ePopen("echo", BF(FFVtnY, SELF, fnc, clearMsg))
def FFVtnY(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFkxeT(SELF)
def FFanF6(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVhfZS
  else       : return ""
def FFjUOl(cmd):
 txt = FFanF6(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFlcvI(cmd):
 lines = FFjUOl(cmd)
 if lines: return lines[0]
 else : return ""
def FFprqV(SELF, cmd):
 lines = FFjUOl(cmd)
 VVG5ES = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVG5ES.append((key, val))
  elif line:
   VVG5ES.append((line, ""))
 if VVG5ES:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF8dRU(SELF, None, header=header, VVHQsP=VVG5ES, VVje1O=widths, VVlvFD=28)
 else:
  FFVBAP(SELF, cmd)
def FFVBAP(    SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, VVnHHw=True, VVXwlZ=VVo3oH, **kwargs)
def FFhq9z(  SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, **kwargs)
def FF3Yso(   SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, VVQhFr=True, VVvdV2=True, VVXwlZ=VVo3oH, **kwargs)
def FFlE1p(  SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, VVQhFr=True, VVvdV2=True, VVXwlZ=VVlCEy, **kwargs)
def FFkyna(  SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, VVhJ5u=True , **kwargs)
def FF7GsE(  session, cmd, **kwargs):      session.open(CCuDOr, VV87m4=cmd, VVhJ5u=True , **kwargs)
def FFSR9Y( SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, VVlT6a=True   , **kwargs)
def FFXjds( SELF, cmd, **kwargs): SELF.session.open(CCuDOr, VV87m4=cmd, VV2DnN=True  , **kwargs)
def FFqAik(cmd):
 return cmd + " > /dev/null 2>&1"
def FF1vDA(cmd):
 return cmd + " 2> /dev/null"
def FFoWNF():
 return " > /dev/null 2>&1"
def FFXQIu(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFflDg(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFT9Rp():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFlcvI(cmd)
VVZEcr     = 0
VVEd4d      = 1
VVvIYW   = 2
VV1fea      = 3
VVcPSx      = 4
VVOqI4     = 5
VVQGHq     = 6
VVqGH2 = 7
VVXZJT = 8
VVAsra = 9
VVGYhV  = 10
VV9G95     = 11
VVoPbw  = 12
VVCn0U  = 13
def FF1WnD(parmNum, grepTxt):
 if   parmNum == VVZEcr  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVEd4d   : param = ["list"   , "apt list" ]
 elif parmNum == VVvIYW: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFT9Rp()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF5LxN(parmNum, package):
 if   parmNum == VV1fea      : param = ["info"      , "apt show"         ]
 elif parmNum == VVcPSx      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVOqI4     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVQGHq     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVqGH2 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVXZJT : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVAsra : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVGYhV  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV9G95     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVoPbw  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVCn0U  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFT9Rp()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFJLoq():
 result = FFlcvI("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF5LxN(VVQGHq , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFqAik("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFqAik("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFDB5L(failed1, VVsZ3Y))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFDB5L(failed2, VVsZ3Y))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFDB5L(failed3, VVpiVU))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFRWxt(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF5LxN(VVQGHq , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFqAik("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFDB5L(failed1, VVsZ3Y))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFDB5L(failed2, VVpiVU))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFLsnX(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFqAik('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFqAik("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFnMVE(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCtiVE.VVMfj1()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFwiKR(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFnMVE(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FF7vxf(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FF2oRJ(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFnMVE(path, maxSize=maxSize, encLst=encLst)
  if lines: FFX3Iv(SELF, lines, title=title, VVXwlZ=VVo3oH, width=1600, height=1000, titleFontSize=30)
  else : FFGQJR(SELF, path, title=title)
 else:
  FFr3Kr(SELF, path, title)
def FFkKs9(SELF, fName, title):
 path = VVrjWk + fName
 if fileExists(path):
  txt = FFnMVE(path)
  txt = txt.replace("#W#", VVBNow)
  txt = txt.replace("#Y#", VVWFW6)
  txt = txt.replace("#G#", VVekE1)
  txt = txt.replace("#C#", VVpihg)
  txt = txt.replace("#P#", VV0kWR)
  FFX3Iv(SELF, txt, title=title)
 else:
  FFr3Kr(SELF, path, title)
def FFsIfj(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFUdYG(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFjZE4(parent)
 else    : return FFjMQE(parent)
def FF4Cf3(path):
 return os.path.basename(os.path.normpath(path))
def FF2oRJ(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFC2Q5(path):
 try:
  os.remove(path)
 except:
  pass
def FFjZE4(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFjMQE(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFtCKU():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVP65U)
 paths.append(VVP65U.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFsIfj(ba)
 for p in list:
  p = ba + p + VVP65U
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVqIfZ, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVP65U, VVqIfZ , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVDznn, VVrjWk = FFtCKU()
def FFQRh2():
 def VVLF0r(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VV43hf   = VVLF0r(CFG.backupPath, CCgs0Z.VVhYws())
 VVsW1a   = VVLF0r(CFG.downloadedPackagesPath, t)
 VV3g1a  = VVLF0r(CFG.exportedTablesPath, t)
 VVgjDM  = VVLF0r(CFG.exportedPIconsPath, t)
 VVF5cu   = VVLF0r(CFG.packageOutputPath, t)
 global VV4J76
 VV4J76 = FFjZE4(CFG.backupPath.getValue())
 if VV43hf or VVF5cu or VVsW1a or VV3g1a or VVgjDM or oldMovieDownloadPath:
  configfile.save()
 return VV43hf, VVF5cu, VVsW1a, VV3g1a, VVgjDM, oldMovieDownloadPath
def FFZQBS(path):
 path = FFjMQE(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFbZBm(SELF, pathList, tarFileName, addTimeStamp=True):
 VVHQsP = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVHQsP.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVHQsP.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVHQsP.append(path)
 if not VVHQsP:
  FF1uaI(SELF, "Files not found!")
 elif not pathExists(VV4J76):
  FF1uaI(SELF, "Path not found!\n\n%s" % VV4J76)
 else:
  VVssNt = FFjZE4(VV4J76)
  tarFileName = "%s%s" % (VVssNt, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF5Vj3())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVHQsP:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVbL9B
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFDB5L(tarFileName, VVs4yr))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFDB5L(failed, VVs4yr))
  cmd += "fi;"
  cmd +=  sep
  FFhq9z(SELF, cmd)
def FFtTSm(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFVTEo(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFVTEo(SELF["keyInfo"], "info")
def FFVTEo(barObj, fName):
 path = "%s%s%s" % (VVrjWk, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFJASh(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFaiFy(satNum)
  return satName
def FFaiFy(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFkQZJ(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFJASh(val)
  else  : sat = FFaiFy(val)
 return sat
def FFx433(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFJASh(num)
 except:
  pass
 return sat
def FFGYOC(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF4ETG(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF7qij(info, iServiceInformation.sServiceref)
   prov = FF7qij(info, iServiceInformation.sProvider)
   state = str(FF7qij(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFkOAA(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFowN4(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF7qij(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFFxlH(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFyJel(refCode):
 info = FF4IwU(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFnNb7(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFPJ1E(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF4IwU(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVfpFz = eServiceCenter.getInstance()
  if VVfpFz:
   info = VVfpFz.info(service)
 return info
def FFxZcp(SELF, refCode, VVY2Q7=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFl4EX(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVY2Q7:
   FF1y8B(SELF, isFromSession)
 try:
  VV56ys = InfoBar.instance
  if VV56ys:
   VVd3D3 = VV56ys.servicelist
   if VVd3D3:
    servRef = eServiceReference(refCode)
    VVd3D3.saveChannel(servRef)
 except:
  pass
def FFl4EX(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCV4IB()
    if pr.VVjB8B(refCode, chName, decodedUrl, iptvRef):
     pr.VVHY8Q(SELF, isFromSession)
def FFkOAA(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFqc3z(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFcmN9(url): return FFJkN3(url) or FFbR9b(url)
def FFJkN3(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFbR9b(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFowN4(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFeHlW(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFeHlW(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFENC4(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFNINN(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFqnL0(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFsa5D(txt):
 try:
  return FFNINN(FFqnL0(txt)) == txt
 except:
  return False
def FF6jDI(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFjZE4(newPath), patt))
def FF1y8B(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCqzRz.VVfphk(session, isFromExternal=isFromSession)
 else      : FF0wqg(session, reopen=True)
def FF0wqg(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FF0wqg, session), CCk768)
  except:
   try:
    FF5tui(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFqjQ5(refCode):
 tp = CCaOWR()
 if tp.VV6SZn(refCode) : return True
 else        : return False
def FFUH03(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFG6ML(True)
     return True
 return False
def FFG6ML(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFn7vs()
def FFn7vs():
 VV56ys = InfoBar.instance
 if VV56ys:
  VVd3D3 = VV56ys.servicelist
  if VVd3D3:
   VVd3D3.setMode()
def FFWeHh(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVfpFz = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVfpFz.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFbUPg():
 VVJsi9 = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVs3cZ = list(VVJsi9)
 return VVs3cZ, VVJsi9
def FFi8dt():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFjBZO(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFeWDt(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFOV2D():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF5Vj3():
 return FFOV2D().replace(" ", "_").replace("-", "").replace(":", "")
def FF6f6P(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFSngc():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFR3XR(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCHF2n.VVPQqT(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCHF2n.VVKfmR(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFqAik("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFxOk9(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFwHmW(num):
 return "s" if num > 1 else ""
def FFK3ps(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFPwFt(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFLMO6(a, b):
 return (a > b) - (a < b)
def FFjKul(a, b):
 def VVrINZ(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVrINZ(a)
 b = VVrINZ(b)
 return (a > b) - (a < b)
def FFL1W9(mycmp):
 class CCl3vv(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCl3vv
def FFfF2j(SELF, message, title="", VVXlAY=None):
 SELF.session.openWithCallback(VVXlAY, CCFCBZ, title=title, message=message, VV0CQU=True)
def FFX3Iv(SELF, message, title="", VVXwlZ=VVo3oH, VVXlAY=None, **kwargs):
 SELF.session.openWithCallback(VVXlAY, CCFCBZ, title=title, message=message, VVXwlZ=VVXwlZ, **kwargs)
def FF1uaI(SELF, message, title="")  : FF5tui(SELF.session, message, title)
def FFr3Kr(SELF, path, title="") : FF5tui(SELF.session, "File not found !\n\n%s" % path, title)
def FFGQJR(SELF, path, title="") : FF5tui(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF3PaD(SELF, title="")  : FF5tui(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF5tui(session, message, title="") : session.open(BF(CC5Okd, title=title, message=message))
def FFX1El(SELF, VVXlAY, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVXlAY, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVXlAY, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF1uaI(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFWV4g(SELF, callBack_Yes, VVJpRC, callBack_No=None, title="", VVwjVK=False, VVvl21=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFr9Hj, callBack_Yes, callBack_No)
         , BF(CCrr7R, title=title, VVJpRC=VVJpRC, VVvl21=VVvl21, VVwjVK=VVwjVK))
def FFr9Hj(callBack_Yes, callBack_No, FFWV4ged):
 if FFWV4ged : callBack_Yes()
 elif callBack_No: callBack_No()
def FFkxeT(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFrI2P(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFRo07(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFLwRB(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVjVsT = eTimer()
def FFRo07(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FF2F71, SELF))
 fnc = BF(FF2F71, SELF)
 try:
  t = VVjVsT.timeout.connect(fnc)
 except:
  VVjVsT.callback.append(fnc)
 VVjVsT.start(milliSeconds, 1)
def FF2F71(SELF):
 VVjVsT.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FF8dRU(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCCXfc, **kwargs))
  else   : win = SELF.session.open(BF(CCCXfc, **kwargs))
  FFNMqr(win)
  return win
 except:
  return None
def FFxMT2(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCUwHt, **kwargs))
 FFNMqr(win)
 return win
def FFnwrX(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFdGDb(SELF, **kwargs):
 SELF.session.open(CCfm5u, **kwargs)
def FFnQcA(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFf3WT(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFf2Vt(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVlQv4, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFCRqe(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFf2Vt(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FF6ScH(SELF, winSize.width(), winSize.height())
def FF6ScH(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFJKbx():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF5ia4(VVlvFD):
 screenSize  = FFJKbx()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVlvFD)
 return bodyFontSize
def FF6lPQ(VVlvFD, extraSpace):
 font = gFont(VVlQv4, VVlvFD)
 VVGpoq = fontRenderClass.getInstance().getLineHeight(font) or (VVlvFD * 1.25)
 return int(VVGpoq + VVGpoq * extraSpace)
def FF1pMw(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0):
 screenSize = FFJKbx()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVlQv4, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FF6lPQ(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVlQv4, titleFontSize, alignLeftCenter)
 if winType in (VVilCV, VVCVur):
  if winType == VVCVur : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVeAgx:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVzYQ4:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVlQv4, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVlugA:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFfF2jL = b2Left2 + timeW + marginLeft
  FFfF2jW = b2Left3 - marginLeft - FFfF2jL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFfF2jL , b2Top, FFfF2jW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVXLg7:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVamHR:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVAG6M:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVtcbV:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVlQv4, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVlQv4, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVuk51:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVlQv4, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVxiVV:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVlQv4, fontH, alignCenter)
 elif winType in (VVpxLn, VVO6R4):
  if winType == VVpxLn: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int((width - vSliderW)  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVpxLn:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVlQv4, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVlQv4, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVlQv4, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVlQv4, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VVlQv4, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VVlQv4, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  extraPar = (boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVlQv4, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVdUpq:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVQsOr:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVrQkp : align = alignLeftCenter
  elif winType == VV16CN : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVscCR:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVlQv4
  if usefixedFont and winType == VV16CN:
   fLst = FFfDUs()
   if   VVIBYu in fLst and CFG.fontPathTerm.getValue(): fontName = VVIBYu
   elif VVD6qa in fLst         : fontName = VVD6qa
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVlvFD = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVlQv4, VVlvFD, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVHSOH = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVlQv4, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVHSOH[i], VVlQv4, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VV16CN:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVHSOH = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVHSOH[i], VVlQv4, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VV32AY = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVS3nw)
  VVd21k = []
  if VVMJ2u:
   VVd21k.append(("-- MY TEST --"  , "myTest" ))
  VVd21k.append(("File Manager"    , "fMan" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("IPTV"      , "iptv" ))
  VVd21k.append(("Movies Browser"   , "movie" ))
  VVd21k.append(("Services/Channels"  , "chan" ))
  VVd21k.append(("PIcons"     , "picon" ))
  VVd21k.append(("EPG"      , "epg"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Terminal"     , "term" ))
  VVd21k.append(("SoftCam"     , "soft" ))
  VVd21k.append(("Plugins"     , "plug" ))
  VVd21k.append(("Backup & Restore"   , "bakup" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Date/Time"    , "date" ))
  for ndx, item in enumerate(VVd21k):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVd21k[ndx] = tuple(item)
  FFrOoX(self, title=self.Title, VVd21k=VVd21k)
  FFddoJ(self["keyRed"] , "Exit")
  FFddoJ(self["keyGreen"] , "Settings")
  FFddoJ(self["keyYellow"], "Dev. Info.")
  FFddoJ(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVAX00      ,
   "yellow": self.VV3R9Y      ,
   "blue" : self.VVIzxn     ,
   "info" : BF(FFqcaP, self, self.VVgs7D) ,
   "text" : self.VV26WA      ,
   "menu" : self.VVZNKX    ,
   "0"  : BF(self.VVgOkZ, 0)   ,
   "1"  : BF(self.VVhF4L, "fMan")   ,
   "2"  : BF(self.VVhF4L, "iptv")   ,
   "3"  : BF(self.VVhF4L, "movie")   ,
   "4"  : BF(self.VVhF4L, "chan")   ,
   "5"  : BF(self.VVhF4L, "picon")   ,
   "6"  : BF(self.VVhF4L, "epg")   ,
   "7"  : BF(self.VVhF4L, "term")   ,
   "8"  : BF(self.VVhF4L, "soft")   ,
   "9"  : BF(self.VVhF4L, "plug")   ,
   "last" : BF(self.VVhF4L, "bakup")   ,
   "next" : BF(self.VVhF4L, "date")   ,
  })
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
  global VVttXz, VVCvlJ
  VVttXz = VVCvlJ = False
 def VVw6vF(self):
  self.VVhF4L(self["myMenu"].l.getCurrentSelection()[1])
 def VVhF4L(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVhtbL
   VVhtbL = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVYMSS()
   elif item == "fMan"  : self.session.open(CCk3u6)
   elif item == "iptv"  : self.session.open(CCHF2n)
   elif item == "movie" : FFqcaP(self, BF(CCCBh0.VVRBOY, self))
   elif item == "chan"  : self.session.open(CCDvzd)
   elif item == "picon" : self.VV8TfS()
   elif item == "epg"  : self.session.open(CCTkbp)
   elif item == "term"  : self.session.open(CCgwEi)
   elif item == "soft"  : self.session.open(CCNCRq)
   elif item == "plug"  : self.session.open(CCxMgL)
   elif item == "bakup" : self.session.open(CCceAZ)
   elif item == "date"  : self.session.open(CC0RHp)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
  FFnQcA(self)
  FFtTSm(self)
  VV43hf, VVF5cu, VVsW1a, VV3g1a, VVgjDM, oldMovieDownloadPath = FFQRh2()
  if VV43hf or VVF5cu or VVsW1a or VV3g1a or VVgjDM or oldMovieDownloadPath:
   VV0iDg = lambda path, subj: "%s:\n%s\n\n" % (subj, FFHqZk(path, VVHeSZ)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV0iDg(VV43hf   , "Backup/Restore Path"    )
   txt += VV0iDg(VVF5cu  , "Created Package Files (IPK/DEB)" )
   txt += VV0iDg(VVsW1a  , "Download Packages (from feeds)" )
   txt += VV0iDg(VV3g1a , "Exported Tables"     )
   txt += VV0iDg(VVgjDM , "Exported PIcons"     )
   txt += VV0iDg(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFX3Iv(self, txt, title="Settings Paths")
  self.VVsorR()
  if (EASY_MODE or VV7z1t or VVMJ2u):
   FFrI2P(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFkxeT(self, "Welcome", 300)
  FFnCJX(self.VVYVDq)
 def VVYVDq(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCgs0Z.VVlO1Z()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  os.system(FFqAik("rm /tmp/ajpanel*"))
  global VVttXz, VVCvlJ
  VVttXz = VVCvlJ = False
 def VVgOkZ(self, digit):
  self.VV32AY += str(digit)
  ln = len(self.VV32AY)
  global VVttXz
  if ln == 4:
   if self.VV32AY == "0" * ln:
    VVttXz = True
    FFrI2P(self["myTitle"], "#11805040")
   else:
    self.VV32AY = "x"
 def VV26WA(self):
  self.VV32AY += "t"
  if self.VV32AY == "0" * 4 + "t" * 2:
   global VVCvlJ
   VVCvlJ = True
   FFrI2P(self["myTitle"], "#dd5588")
 def VV8TfS(self):
  found = False
  pPath = CCodIm.VVt98d()
  if pathExists(pPath):
   for fName, fType in CCodIm.VVTSTs(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCodIm)
  else:
   VVd21k = []
   VVd21k.append(("PIcons Tools" , "CCodIm" ))
   VVd21k.append(VVNCuu)
   VVd21k.append(CCodIm.VV0AND())
   VVd21k.append(VVNCuu)
   VVd21k += CCodIm.VVhd6M()
   FFxMT2(self, self.VVpgf0, VVd21k=VVd21k)
 def VVpgf0(self, item=None):
  if item:
   if   item == "CCodIm"   : self.session.open(CCodIm)
   elif item == "VVTqX4"  : CCodIm.VVTqX4(self)
   elif item == "VVuZzW"  : CCodIm.VVuZzW(self)
   elif item == "findPiconBrokenSymLinks" : CCodIm.VVs1xD(self, True)
   elif item == "FindAllBrokenSymLinks" : CCodIm.VVs1xD(self, False)
 def VVgs7D(self):
  changeLogFile = VVrjWk + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFwiKR(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFHqZk("\n%s\n%s\n%s" % (VVbL9B, line, VVbL9B), VVsZ3Y, VVBNow)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFHqZk(line, VVekE1, VVBNow)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFX3Iv(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVS3nw, PLUGIN_DESCRIPTION), VVlvFD=28, width=1600, height=1000)
 def VVZNKX(self):
  VVd21k = []
  VVd21k.append(("Check Internet Connection" , "intr"))
  VVd21k.append(VVNCuu)
  VVd21k.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Keys Help"     , "hlp" ))
  FFxMT2(self, self.VV68uC, VVd21k=VVd21k, width=650, title="Options")
 def VV68uC(self, item=None):
  if item:
   if   item == "intr" : self.session.open(CCzlKd)
   elif item == "libr" : FFqcaP(self, BF(self.VVNy6Y))
   elif item == "hlp" : FFkKs9(self, "_help_main", "Main Page (Keys Help)")
 def VVAX00(self) : self.session.open(CCgs0Z)
 def VV3R9Y(self) : self.session.open(CC7eWy)
 def VVIzxn(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVusL5, VVHeSZ, VVWFW6, VVyuFD
  VVd21k = []
  VVd21k.append((c1 + "Change Title Colors"   , "title"  ))
  VVd21k.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVd21k.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVd21k.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVd21k.append((c2 + "Reset Colors"    , "resetColor" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVd21k.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c4 + "Change System Font"    , "sysFont"  ))
  FFxMT2(self, BF(self.VVoFiC, title), VVd21k=VVd21k, width=600, title=title)
 def VVoFiC(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV9Q3q()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVlM8B, tDict, item), CCytJU, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFWV4g(self, self.VVg0Kk, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVZwxe(VVRklX  )
   elif item == "termFont"  : self.VVZwxe(VVIBYu)
   elif item == "sysFont"  : self.VVZwxe(VVDlhL  )
 def VVNy6Y(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVG5ES, pkgs = self.VVl4Ev()
  VVZyxX = ("Install", BF(self.VVYZax, title, pkgs)  , [])
  VVOr9v  = ("Update Sys. Packages", self.VVUHzu , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VV4tj2 = (LEFT  , CENTER , LEFT  )
  VVc7Yu = FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, width=1350, VVZyxX=VVZyxX, VVOr9v=VVOr9v, VVNfgg="#00ffffaa", VVRqqp=1)
 def VVYZax(self, Title, pkgs, VVc7Yu, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVFkwk, VVc7Yu)
   item = colList[0]
   if   item == "requests" : CCr3lG.VV0eGg(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCxpGD.VVA6X2(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFkyna(self, FFJLoq(), VVHcKu=cbFnc)
   elif item in pkgs  : FFkyna(self, FFRWxt(item, item, item.capitalize()), VVHcKu=cbFnc)
  else:
   FFkxeT(VVc7Yu, "Already installed.", 700, isGrn=True)
 def VVUHzu(self, VVc7Yu, title, txt, colList):
  CCxMgL.VVtcYT(self)
 def VVFkwk(self, VVc7Yu):
  VVG5ES, pkgs = self.VVl4Ev()
  VVc7Yu.VV2PiO(VVG5ES[VVc7Yu.VVbJrA()])
 def VVl4Ev(self):
  tDict = {}
  path = VVrjWk + "_sup_lib"
  if fileExists(path):
   for line in FFwiKR(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VV0iDg(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFHqZk("Installed", VVs4yr), txt)
   else : return (lib, FFHqZk("Not installed", VVpiVU), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVG5ES = []
  VVG5ES.append(VV0iDg("requests", CCr3lG.VV0eGg(self, install=False)))
  VVG5ES.append(VV0iDg("Imaging" , CCxpGD.VVA6X2(self, "", False, install=False)))
  VVG5ES.append(VV0iDg("ar"   , os.system("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 1; else exit 0; fi")))
  for item in pkgs: VVG5ES.append(VV0iDg(item, FFXQIu(item)))
  VVG5ES.sort(key=lambda x: x[0].lower())
  return VVG5ES, pkgs
 def VVhQ8P(self):
  return VV4J76 + "ajpanel_colors"
 def VV9Q3q(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVhQ8P()
  if fileExists(p):
   txt = FFnMVE(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVlM8B(self, tDict, item, fg, bg):
  if fg:
   self.VVZ976(item, fg)
   self.VVLVNm(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVKDNn(tDict)
 def VVKDNn(self, tDict):
   p = self.VVhQ8P()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVZ976(self, item, fg):
  if   item == "title" : FFm6nb(self["myTitle"], fg)
  elif item == "body"  :
   FFm6nb(self["myMenu"], fg)
   FFm6nb(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFm6nb(self[item], fg)
 def VVLVNm(self, item, bg):
  if   item == "title" : FFrI2P(self["myTitle"], bg)
  elif item == "body"  :
   FFrI2P(self["myMenu"], bg)
   FFrI2P(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFrI2P(self["myBar"], bg)
 def VVg0Kk(self):
  os.system(FFqAik("rm %s" % self.VVhQ8P()))
  self.close()
 def VVsorR(self):
  tDict = self.VV9Q3q()
  for item in ("title", "body", "cursor", "bar"):
   self.VVDdNV(tDict, item)
 def VVDdNV(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVZ976(name, fg)
  if bg: self.VVLVNm(name, bg)
 def VVZwxe(self, which):
  if   which == VVRklX  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVIBYu : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVDlhL  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCW44Z.VV4xQ2(self, "Change %s Font" % title, defFnt, rest, BF(self.VVzGTA, which))
 def VVzGTA(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVRklX  : FFWvPK(CFG.fontPathMain, path)
   elif which == VVIBYu: FFWvPK(CFG.fontPathTerm, path)
   elif which == VVDlhL  : FFWvPK(CFG.fontPathSys , path)
   err = Main_Menu.VVE36p(which)
   if err          : FF1uaI(self, err, title=title)
   elif which == VVRklX   : self.close()
   elif which == VVIBYu  : FFkxeT(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVDlhL and path: FFkxeT(self, "System font applied", 1500, isGrn=True)
   elif which == VVDlhL   : FFWV4g(self, BF(Main_Menu.VVlT6a, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVlT6a(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVE36p(name):
  if   name == VVRklX : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVIBYu: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVDlhL : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFfDUs()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVDlhL:
   nameLst = []
   for nm in FFfDUs():
    if not nm in (VVRklX, VVIBYu):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFGPE5(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFfDUs()
  else    : return "Could not add font"
 def VVYMSS(self):
  CCqzRz.VVfphk(self.session)
class CCxpGD():
 VVlvF8  = "all"
 VV0kSk = "vid"
 VVNoLN  = "osd"
 @staticmethod
 def VVx1a3(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFXQIu("grab"):
    winShown = session.current_dialog.shown
    if k == CCxpGD.VV0kSk and winShown: session.current_dialog.hide()
    FFnCJX(BF(CCxpGD.VV3bv9, title, session, k, winShown))
   else:
    FF5tui(session, "No Grab command !", title=title)
 @staticmethod
 def VV3bv9(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCxpGD.VVNoLN:
   if not winShown:
    FF5tui(session, "No Window to capture !", title=title)
    return
   if not CCxpGD.VVA6X2(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCxpGD.VV2HWe(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FF5tui(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFjZE4(CFG.exportedPIconsPath.getValue()), fTitle, FF5Vj3(), ext)
  res = os.system(FF1vDA("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCxpGD.VV0kSk and winShown:
   session.current_dialog.show()
  elif k == CCxpGD.VVNoLN:
   ok = CCxpGD.VVnsYq(path, x, y, w, h)
   if not ok:
    FFC2Q5(path)
    FF5tui(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCpbjY, title=path, VVffaB=path))
  else       : FF5tui(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVA6X2(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFWV4g(SELF, BF(CCxpGD.VVCwDa, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVCwDa(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FF7GsE, VVHcKu=cbFnc)
  else    : fnc = BF(FFkyna , VVHcKu=cbFnc)
  fnc(SELF, FF5LxN(VVQGHq, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VV2HWe(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVnsYq(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFJKbx()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFPwFt(x , 0, scrW, 0, w)
     y  = FFPwFt(y , 0, scrH, 0, h)
     x1 = FFPwFt(x1, 0, scrW, 0, w)
     y1 = FFPwFt(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVeNP8(path):
  size = FF2oRJ(path)
  sizeTxt = CCk3u6.VVeQ5q(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCW44Z(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FF1pMw(VVilCV, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFHqZk(" (Requires GUI Restart)", VVyuFD) if withRestart else ""
  VVd21k = []
  for path in self.fontsList:
   VVd21k.append((os.path.splitext(os.path.basename(path))[0], path))
  VVd21k.sort(key=lambda x: x[0].lower())
  VVd21k.insert(0, VVNCuu)
  VVd21k.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVd21k):
    if len(item) == 2 and item[1] == self.defFnt:
     VVd21k[ndx] = (VVs4yr + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVd21k[curIndex] = (VVs4yr + VVd21k[curIndex][0], VVd21k[curIndex][1])
  FFrOoX(self, VVd21k=VVd21k, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
  self["myMenu"].onSelectionChanged.append(self.VVfC1H)
  self["myBar"].setText(self.VVQD4X())
  self["myBar"].instance.setHAlign(1)
  self.VVfC1H()
 def VVw6vF(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVfC1H(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFGPE5(path, fnt, isRepl=1)
  else:
   fnt = VV8loG
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVQD4X(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VV4xQ2(SELF, title, defFnt, rest, VVXlAY):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FF6jDI(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVXlAY, CCW44Z, title, fontsList, defFnt, rest)
  else  : FF1uaI(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCRqvz(Screen):
 def __init__(self, session, path, VVd21k, title):
  self.skin, self.skinParam = FF1pMw(VVilCV, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFrOoX(self, VVd21k=VVd21k, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVw6vF   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVbGeh,
   "chanUp" : self.VVbGeh,
   "pageDown" : self.VV4DAH ,
   "chanDown" : self.VV4DAH ,
  }, -1)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
  FFrI2P(self["myLabelFrm"], "#11110000")
  FFrI2P(self["myLabelTit"], "#11663322")
  FFrI2P(self["myLabelTxt"], "#11110000")
  self["myLabelTxt"].instance.setNoWrap(True)
  self["myMenu"].onSelectionChanged.append(self.VV5l0H)
  self.VV5l0H()
 def VV5l0H(self):
  if fileExists(self.path): txt = FFnMVE(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVw6vF(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVbGeh(self) : self["myMenu"].moveToIndex(0)
 def VV4DAH(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCtiVE():
 @staticmethod
 def VVMfj1():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVYf8b(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FF8dRU(SELF, None, VVHQsP=lst, VVlvFD=30, VVRqqp=1)
 @staticmethod
 def VVLoBC(path, SELF=None):
  for enc in CCtiVE.VVMfj1():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF1uaI(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVVTUQ(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFkxeT(SELF)
  lst = CCtiVE.VVVxwn(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVd21k = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFHqZk(txt, VVs4yr)
    VVd21k.append((txt, enc))
   if onlyWorkingEnc: SELF.session.openWithCallback(cbFnc, CCRqvz, path, VVd21k, title)
   else    : FFxMT2(SELF, cbFnc, title=title, VVd21k=VVd21k, width=900, VVW1CX="#22220000", VVLasp="#22220000")
  else:
   FFkxeT(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVVxwn(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVrjWk + "_sup_codecs"
  if fileExists(cPath):
   lines = FFwiKR(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCtiVE.VVMfj1())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CC7eWy(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVd21k = []
  VVd21k.append(("Settings File"        , "SettingsFile"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Box Info"          , "VVQEF0"    ))
  VVd21k.append(("Tuners Info"         , "VVw8Oo"   ))
  VVd21k.append(("Python Version"        , "VVMQEp"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Screen Size"         , "ScreenSize"    ))
  VVd21k.append(("Language/Locale"        , "Locale"     ))
  VVd21k.append(("Processor"         , "Processor"    ))
  VVd21k.append(("Operating System"        , "OperatingSystem"   ))
  VVd21k.append(("Drivers"          , "drivers"     ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("System Users"         , "SystemUsers"    ))
  VVd21k.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVd21k.append(("Uptime"          , "Uptime"     ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Host Name"         , "HostName"    ))
  VVd21k.append(("MAC Address"         , "MACAddress"    ))
  VVd21k.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVd21k.append(("Network Status"        , "NetworkStatus"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Disk Usage"         , "VVgU0o"    ))
  VVd21k.append(("Mount Points"         , "MountPoints"    ))
  VVd21k.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVd21k.append(("USB Devices"         , "USB_Devices"    ))
  VVd21k.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVd21k.append(("Directory Size"        , "DirectorySize"   ))
  VVd21k.append(("Memory"          , "Memory"     ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVd21k.append(("Running Processes"       , "RunningProcesses"  ))
  VVd21k.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFrOoX(self, VVd21k=VVd21k, title="Device Information")
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCJPGB)
   elif item == "VVQEF0"    : self.VVQEF0()
   elif item == "VVw8Oo"   : self.VVw8Oo()
   elif item == "VVMQEp"   : self.VVMQEp()
   elif item == "ScreenSize"    : FFX3Iv(self, "Width\t: %s\nHeight\t: %s" % (FFJKbx()[0], FFJKbx()[1]))
   elif item == "Locale"     : CCtiVE.VVYf8b(self)
   elif item == "Processor"    : self.VVt7WP()
   elif item == "OperatingSystem"   : FFVBAP(self, "uname -a"        )
   elif item == "drivers"     : self.VVWdoY()
   elif item == "SystemUsers"    : FFVBAP(self, "id"          )
   elif item == "LoggedInUsers"   : FFVBAP(self, "who -a"         )
   elif item == "Uptime"     : FFVBAP(self, "uptime"         )
   elif item == "HostName"     : FFVBAP(self, "hostname"        )
   elif item == "MACAddress"    : self.VVaDiB()
   elif item == "NetworkConfiguration"  : FFVBAP(self, "ifconfig %s %s" % (FFDB5L("HWaddr", VVpZn3), FFDB5L("addr:", VVsZ3Y)))
   elif item == "NetworkStatus"   : FFVBAP(self, "netstat -tulpn"       )
   elif item == "VVgU0o"    : self.VVgU0o()
   elif item == "MountPoints"    : FFVBAP(self, "mount %s" % (FFDB5L(" on ", VVsZ3Y)))
   elif item == "FileSystemTable"   : FFVBAP(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFVBAP(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFVBAP(self, "blkid"         )
   elif item == "DirectorySize"   : FFVBAP(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVcg8k="Reading size ...")
   elif item == "Memory"     : FFVBAP(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVbuEZ()
   elif item == "RunningProcesses"   : FFVBAP(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFVBAP(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVuG8v()
   else         : self.close()
 def VVaDiB(self):
  res = FFanF6("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFX3Iv(self, txt)
  else:
   FFVBAP(self, "ip link")
 def VVFHTA(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFjUOl(cmd)
  return lines
 def VVVzbH(self, lines, headerRepl, widths, VV4tj2):
  VVG5ES = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVG5ES.append(parts)
  if VVG5ES and len(header) == len(widths):
   VVG5ES.sort(key=lambda x: x[0].lower())
   FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, VVRqqp=1)
   return True
  else:
   return False
 def VVgU0o(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFanF6(cmd)
  if not "invalid option" in txt:
   lines  = self.VVFHTA(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV4tj2 = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVVzbH(lines, headerRepl, widths, VV4tj2)
  else:
   cmd = "df -h"
   lines  = self.VVFHTA(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV4tj2 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVVzbH(lines, headerRepl, widths, VV4tj2)
  if not allOK:
   lines = FFjUOl(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFjMQE(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVs4yr:
     note = "\n%s" % FFHqZk("Green = Mounted Partitions", VVs4yr)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVsZ3Y
     elif line.endswith(mountList) : color = VVs4yr
     else       : color = VVekE1
     txt += FFHqZk(line, color) + "\n"
    FFX3Iv(self, txt + note)
   else:
    FF1uaI(self, "Not data from system !")
 def VVbuEZ(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVFHTA(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV4tj2 = (LEFT , CENTER, LEFT )
  allOK = self.VVVzbH(lines, headerRepl, widths, VV4tj2)
  if not allOK:
   FFVBAP(self, cmd)
 def VVWdoY(self):
  cmd = FF1WnD(VVvIYW, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFVBAP(self, cmd)
  else : FF3PaD(self)
 def VVt7WP(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFVBAP(self, cmd)
 def VVuG8v(self):
  cmd = FF1WnD(VVEd4d, "| grep secondstage")
  if cmd : FFVBAP(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF3PaD(self)
 def VVQEF0(self):
  c = VVs4yr
  VVHQsP = []
  VVHQsP.append((FFHqZk("Box Type"  , c), FFHqZk(self.VVAQxd("boxtype").upper(), c)))
  VVHQsP.append((FFHqZk("Board Version", c), FFHqZk(self.VVAQxd("board_revision") , c)))
  VVHQsP.append((FFHqZk("Chipset"  , c), FFHqZk(self.VVAQxd("chipset")  , c)))
  VVHQsP.append((FFHqZk("S/N"   , c), FFHqZk(self.VVAQxd("sn")    , c)))
  VVHQsP.append((FFHqZk("Version"  , c), FFHqZk(self.VVAQxd("version")  , c)))
  VV1qv2   = []
  VVgl5k = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVgl5k = SystemInfo[key]
     else:
      VV1qv2.append((FFHqZk(str(key), VVpihg), FFHqZk(str(SystemInfo[key]), VVpihg)))
  except:
   pass
  if VVgl5k:
   VVOT94 = self.VVfy61(VVgl5k)
   if VVOT94:
    VVOT94.sort(key=lambda x: x[0].lower())
    VVHQsP += VVOT94
  if VV1qv2:
   VV1qv2.sort(key=lambda x: x[0].lower())
   VVHQsP += VV1qv2
  if VVHQsP:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF8dRU(self, None, header=header, VVHQsP=VVHQsP, VVje1O=widths, VVlvFD=28, VVRqqp=1)
  else:
   FFX3Iv(self, "Could not read info!")
 def VVAQxd(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFwiKR(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVfy61(self, mbDict):
  try:
   mbList = list(mbDict)
   VVHQsP = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVHQsP.append((FFHqZk(subject, VVsZ3Y), FFHqZk(value, VVsZ3Y)))
  except:
   pass
  return VVHQsP
 def VVw8Oo(self):
  txt = self.VVRHwE("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVRHwE("/proc/bus/nim_sockets")
  if not txt: txt = self.VV57IT()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFX3Iv(self, txt)
 def VV57IT(self):
  txt = ""
  VV0iDg = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV0iDg("Slot Name" , slot.getSlotName())
     txt += FFHqZk(slotName, VVsZ3Y)
     txt += VV0iDg("Description"  , slot.getFullDescription())
     txt += VV0iDg("Frontend ID"  , slot.frontend_id)
     txt += VV0iDg("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVRHwE(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFwiKR(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFHqZk(line, VVsZ3Y)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVMQEp(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFX3Iv(self, txt)
 @staticmethod
 def VVflFN():
  def VV0iDg(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VV0iDg(v,0), "/etc/issue.net": VV0iDg(v,1), "/etc/image-version": VV0iDg(v,2)}
  for p1, d in v.items():
   img = CC7eWy.VVxu9U(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VV0iDg(v,0), p + "Plugins/": VV0iDg(v,1), VVXS9f: VV0iDg(v,2), VVP65U: VV0iDg(v,3)}
  for p1, d in v.items():
   img = CC7eWy.VVaMf0(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVxu9U(path, d):
  if fileExists(path):
   txt = FFnMVE(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVaMf0(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCJPGB(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVd21k = []
  VVd21k.append(("Settings (All)"   , "Settings_All"   ))
  VVd21k.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVd21k.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVd21k.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVd21k.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVd21k.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVd21k.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVCvlJ:
   VVd21k.append(VVNCuu)
   VVd21k.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVd21k.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFrOoX(self, VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVmqmq
   grep = " | grep "
   if   item == "Settings_All"    : FFVBAP(self, cmd                )
   elif item == "Settings_HotKeys"   : FFVBAP(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_ajp"    : FFVBAP(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME     )
   elif item == "Settings_FHDG_17"   : FFVBAP(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFVBAP(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFVBAP(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFVBAP(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFVBAP(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFVBAP(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCNCRq(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV7fWb, VVBbEv, VVMrBI, camCommand = CCNCRq.VVskWY()
  self.VVBbEv = VVBbEv
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVBbEv:
   c = VVusL5 if VVMrBI else VVRK3s
   if   "oscam" in VVBbEv : camName, oC = "OSCam", c
   elif "ncam"  in VVBbEv : camName, nC = "NCam" , c
  VVd21k = []
  VVd21k.append(("OSCam Files" , "OSCamFiles"  ))
  VVd21k.append(("NCam Files" , "NCamFiles"  ))
  VVd21k.append(("CCcam Files" , "CCcamFiles"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append((VVWFW6 + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVYC3g" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVd21k.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVd21k.append(VVNCuu)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVBbEv: VVd21k.append((c + txt  , "camInfo" ))
  else  : VVd21k.append((txt  ,    ))
  VVd21k.append(VVNCuu)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVBbEv:
   for item in camLst: VVd21k.append(item)
  else:
   for item in camLst: VVd21k.append((item[0], ))
  FFrOoX(self, VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CC1LOa, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CC1LOa, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CC1LOa, "cccam"))
   elif item == "VVYC3g" : self.VVYC3g()
   elif item == "OSCamReaders"  : self.VVt4MR("os")
   elif item == "NSCamReaders"  : self.VVt4MR("n")
   elif item == "camInfo"   : FFprqV(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCNCRq.VVQDQb(self.session, CC6pHp.VVHP8N)
   elif item == "camLiveReaders" : CCNCRq.VVQDQb(self.session, CC6pHp.VViF0V)
   elif item == "camLiveLog"  : CCNCRq.VVQDQb(self.session, CC6pHp.VVcJyT)
   else       : self.close()
 def VVYC3g(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VV4J76, FF5Vj3())
  if fileExists(path):
   lines = FFwiKR("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VV0iDg = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VV0iDg("label"    , "CCcam-Line-%d" % ndx))
      f.write(VV0iDg("description"  , "CCcam-Line-%d" % ndx))
      f.write(VV0iDg("protocol"   , "cccam"))
      f.write(VV0iDg("device"    , "%s,%s" % (host, port)))
      f.write(VV0iDg("user"    , User))
      f.write(VV0iDg("password"   , Pass))
      f.write(VV0iDg("fallback"   , "1"))
      f.write(VV0iDg("group"    , "64"))
      f.write(VV0iDg("cccversion"   , "2.3.2"))
      f.write(VV0iDg("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFfF2j(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFwHmW(tot), outFile))
   else:
    FFkxeT(self, "No valid CCcam lines", 1500)
  else:
   FFkxeT(self, "%s not found" % path, 1500)
 def VVt4MR(self, camPrefix):
  VVG5ES = self.VVQ7vQ(camPrefix)
  if VVG5ES:
   VVG5ES.sort(key=lambda x: int(x[0]))
   if self.VVBbEv and self.VVBbEv.startswith(camPrefix):
    VVZyxX = ("Toggle State", self.VVL9NF, [camPrefix], "Changing State ...")
   else:
    VVZyxX = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV4tj2  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVZyxX=VVZyxX, VVDYPP=True)
 def VVQ7vQ(self, camPrefix):
  readersFile = self.VV7fWb + camPrefix + "cam.server"
  VVG5ES = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFwiKR(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVG5ES.append((str(len(VVG5ES) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVG5ES:
    FF1uaI(self, "No readers found !")
  else:
   FFr3Kr(self, readersFile)
  return VVG5ES
 def VVL9NF(self, VVc7Yu, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV7fWb, camPrefix)
  readerState  = VVc7Yu.VVGBYR(1)
  readerLabel  = VVc7Yu.VVGBYR(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCNCRq.VVH72S(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVc7Yu.VVSLMs()
    FF1uaI(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVG5ES = self.VVQ7vQ(camPrefix)
   if VVG5ES:
    VVc7Yu.VV4ZQl(VVG5ES)
  else:
   VVc7Yu.VVSLMs()
 @staticmethod
 def VVH72S(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFwiKR(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF1uaI(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF1uaI(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFr3Kr(SELF, confFile)
   return None
  if not iRequest:
   FF1uaI(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCNCRq.VVdet0(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FF1uaI(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVdet0(SELF):
  if iElem:
   return True
  else:
   FF1uaI(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVQDQb(session, VVxEK0):
  VV7fWb, VVBbEv, VVMrBI, camCommand = CCNCRq.VVskWY()
  if VVBbEv:
   runLog = False
   if   VVxEK0 == CC6pHp.VVHP8N : runLog = True
   elif VVxEK0 == CC6pHp.VViF0V : runLog = True
   elif not VVMrBI          : FF5tui(session, message="SoftCam not started yet!")
   elif fileExists(VVMrBI)        : runLog = True
   else             : FF5tui(session, message="File not found !\n\n%s" % VVMrBI)
   if runLog:
    session.open(BF(CC6pHp, VV7fWb=VV7fWb, VVBbEv=VVBbEv, VVMrBI=VVMrBI, VVxEK0=VVxEK0))
  else:
   FF5tui(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVskWY():
  VV7fWb = "/etc/tuxbox/config/"
  VVBbEv = None
  VVMrBI  = None
  camCommand = FFlcvI("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVBbEv = "oscam"
   elif camCmd.startswith("ncam") : VVBbEv = "ncam"
  if VVBbEv:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFnMVE(path), IGNORECASE)
     if span:
      VV7fWb = FFjZE4(span.group(1))
      break
   else:
    path = FFlcvI(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFjZE4(path)
    if pathExists(path):
     VV7fWb = path
   tFile = FFjZE4(VV7fWb) + VVBbEv + ".conf"
   tFile = FFlcvI("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVMrBI = tFile
  return VV7fWb, VVBbEv, VVMrBI, camCommand
class CC1LOa(Screen):
 def __init__(self, VVH8hh, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV7fWb, VVBbEv, VVMrBI, camCommand = CCNCRq.VVskWY()
  if   VVH8hh == "ncam" : self.prefix = "n"
  elif VVH8hh == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVd21k = []
  if self.prefix == "":
   VVd21k.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVd21k.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVd21k.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVd21k.append(("constant.cw"         , "x_constant_cw" ))
   VVd21k.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVd21k.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVd21k.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVd21k.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVd21k.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVd21k.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVd21k.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVd21k.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVd21k.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVd21k.append(VVNCuu)
   VVd21k.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVd21k.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVd21k.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFrOoX(self, VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF7vxf(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FF7vxf(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FF7vxf(self, self.VV7fWb + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FF7vxf(self, self.VV7fWb + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VV3PhA("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VV3PhA("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VV3PhA("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VV3PhA("cam.provid"        )
   elif item == "x_cam_server"  : self.VV3PhA("cam.server"        )
   elif item == "x_cam_services" : self.VV3PhA("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VV3PhA("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VV3PhA("cam.user"        )
   elif item == "x_VVbL9B"   : pass
   elif item == "x_SoftCam_Key" : self.VVwyfw()
   elif item == "x_CCcam_cfg"  : FF7vxf(self, self.VV7fWb + "CCcam.cfg"    )
   elif item == "x_VVbL9B"   : pass
   elif item == "x_cam_log"  : FF7vxf(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FF7vxf(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FF7vxf(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VV3PhA(self, fileName):
  FF7vxf(self, self.VV7fWb + self.prefix + fileName)
 def VVwyfw(self):
  path = self.VV7fWb + "SoftCam.Key"
  if fileExists(path) : FF7vxf(self, path)
  else    : FF7vxf(self, path.replace(".Key", ".key"))
class CC6pHp(Screen):
 VVHP8N  = 0
 VViF0V = 1
 VVcJyT = 2
 def __init__(self, session, VV7fWb="", VVBbEv="", VVMrBI="", VVxEK0=VVHP8N):
  self.skin, self.skinParam = FF1pMw(VV16CN, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVMrBI   = VVMrBI
  self.VVxEK0  = VVxEK0
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV7fWb + VVBbEv + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVBbEv : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV7fWb, self.camPrefix)
  if self.VVxEK0 == self.VVHP8N:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVxEK0 == self.VViF0V:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFrOoX(self, self.Title, addScrollLabel=True)
  FFddoJ(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVg05n
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self["myLabel"].VVuWLn(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFnQcA(self)
  self.VVg05n()
 def onExit(self):
  self.timer.stop()
 def VVXUOo(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVAI38)
  except:
   self.timer.callback.append(self.VVAI38)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFkxeT(self, "Started", 1000)
 def VVBFG6(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVAI38)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFkxeT(self, "Stopped", 1000)
 def VVg05n(self):
  if self.timerRunning:
   self.VVBFG6()
  else:
   self.VVXUOo()
   if self.VVxEK0 == self.VVHP8N or self.VVxEK0 == self.VViF0V:
    if self.VVxEK0 == self.VVHP8N : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCNCRq.VVH72S(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFnCJX(self.VVQBNf)
    else:
     self.close()
   else:
    self.VV8VQ5()
 def VVAI38(self):
  if self.timerRunning:
   if   self.VVxEK0 == self.VVHP8N : self.VVy6TW()
   elif self.VVxEK0 == self.VViF0V : self.VVy6TW()
   else            : self.VV8VQ5()
 def VV8VQ5(self):
  if fileExists(self.VVMrBI):
   fTime = FFeWDt(os.path.getmtime(self.VVMrBI))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVixgQ(), VVXwlZ=VVlCEy)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVMrBI)
 def VVQBNf(self):
  self.VVy6TW()
 def VVy6TW(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFHqZk("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VV0kWR))
   self.camWebIfErrorFound = True
   self.VVBFG6()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVxEK0 == self.VVHP8N : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFHqZk("Error while parsing data elements !\n\nError = %s" % str(e), VVpiVU)
   self.camWebIfErrorFound = True
   self.VVBFG6()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VV2kqo(root)
  self["myLabel"].setText(txt, VVXwlZ=VVlCEy)
  self["myBar"].setText("Last Update : %s" % FFOV2D())
 def VV2kqo(self, rootElement):
  def VV0iDg(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVxEK0 == self.VVHP8N:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFHqZk(status, VVs4yr)
    else          : status = FFHqZk(status, VVpiVU)
    txt += VVbL9B + "\n"
    txt += VV0iDg("Name"  , name)
    txt += VV0iDg("Description" , desc)
    txt += VV0iDg("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV0iDg("Protocol" , protocol)
    txt += VV0iDg("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFHqZk("Yes", VVs4yr)
    else    : enabTxt = FFHqZk("No", VVpiVU)
    txt += VVbL9B + "\n"
    txt += VV0iDg("Label"  , label)
    txt += VV0iDg("Protocol" , protocol)
    txt += VV0iDg("Enabled" , enabTxt)
  return txt
 def VVixgQ(self):
  lines = FFjUOl("tail -n %d %s" % (100, self.VVMrBI))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVyuFD + line[:19] + VVekE1 + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVjQpG + "WebIf" + VVekE1)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVpihg + h1 + h2 + VVekE1 + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVs4yr + span.group(2) + VVWFW6 + span.group(3) + VVekE1 + span.group(4)
    line = self.VV5nAd(line, VVWFW6, ("(webif)", ))
    line = self.VV5nAd(line, VVWFW6, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VV5nAd(line, VVs4yr, ("OSCam", "NCam", "log switched"))
    line = self.VV5nAd(line, VVHeSZ, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVsZ3Y + line[ndx + 3:] + VVekE1
   elif line.startswith("----") or ">>" in line:
    line = FFHqZk(line, VVBNow)
   txt += line + "\n"
  return txt
 def VV5nAd(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVekE1 + t3
  return line
class CCceAZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVd21k = []
  VVd21k.append(("Backup Channels"    , "VVaAYb"   ))
  VVd21k.append(("Restore Channels"    , "Restore_Channels"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Backup SoftCAM Files"   , "VVNY91" ))
  VVd21k.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVd21k.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVd21k.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Backup Network Settings"  , "VVS54J"   ))
  VVd21k.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVCvlJ:
   VVd21k.append(VVNCuu)
   VVd21k.append((VV0kWR + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVDqJ7"   ))
   VVd21k.append((VVs4yr + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVBcwB) , "createMyIpk"   ))
   VVd21k.append((VVs4yr + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVBcwB) , "createMyDeb"   ))
   VVd21k.append((VVpihg + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVd21k.append((VVpihg + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVikuq" ))
  FFrOoX(self, VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVaAYb"    : self.VVaAYb()
   elif item == "Restore_Channels"    : self.VVcT1Y("channels_backup*.tar.gz", self.VVar7y, isChan=True)
   elif item == "VVNY91"   : self.VVNY91()
   elif item == "Restore_SoftCAM_Files"  : self.VVcT1Y("softcam_backup*.tar.gz", self.VVoRGZ)
   elif item == "Backup_TunerDiSEqC"   : self.VVE7r7("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVcT1Y("tuner_backup*.backup", BF(self.VVMCQg, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVE7r7("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVcT1Y("hotkey_*backup*.backup", BF(self.VVMCQg, "misc"))
   elif item == "VVS54J"    : self.VVS54J()
   elif item == "Restore_Network"    : self.VVcT1Y("network_backup*.tar.gz", self.VVSnPE)
   elif item == "VVDqJ7"     : FFWV4g(self, BF(FFqcaP, self, BF(CCceAZ.VVDqJ7, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVYdl1(False)
   elif item == "createMyDeb"     : self.VVYdl1(True)
   elif item == "createMyTar"     : self.VVI2Ge()
   elif item == "VVikuq"   : self.VVikuq()
 @staticmethod
 def VVDqJ7(SELF):
  OBF_Path = VVDznn + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVDznn, VVS3nw, VVBcwB)
   if err : FF1uaI(SELF, err)
   else : FFX3Iv(SELF, txt)
  else:
   FFr3Kr(SELF, OBF_Path)
 def VVYdl1(self, VVjafw):
  OBF_Path = VVDznn + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF1uaI(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVDznn)
  os.system("mv -f %s %s" % (VVDznn + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVDznn + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVDznn + "plugin.py"))
  self.session.openWithCallback(self.VVTmbg, BF(CCuvFH, path=VVDznn, VVjafw=VVjafw))
 def VVTmbg(self):
  os.system("mv -f %s %s" % (VVDznn + "OBF/main.py"  , VVDznn))
  os.system("mv -f %s %s" % (VVDznn + "OBF/plugin.py" , VVDznn))
 def VVikuq(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF1uaI(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF1uaI(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVPtpK("%s*.list" % path)
  if err:
   FFr3Kr(self, path + "*.list")
   return
  srcF, err = self.VVPtpK("%s*main_final.py" % path)
  if err:
   FFr3Kr(self, path + "*.final.py")
   return
  VVHQsP = []
  for f in files:
   f = os.path.basename(f)
   VVHQsP.append((f, f))
  FFxMT2(self, BF(self.VVcRXJ, path, codF, srcF), VVd21k=VVHQsP)
 def VVcRXJ(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFr3Kr(self, logF)
   else     : FFqcaP(self, BF(self.VVXdoj, logF, codF, srcF))
 def VVXdoj(self, logF, codF, srcF):
  lst  = []
  lines = FFwiKR(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF1uaI(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV3osI(lst, logF, newLogF)
  totSrc  = self.VV3osI(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFX3Iv(self, txt)
 def VVPtpK(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV3osI(self, lst, f1, f2):
  txt = FFnMVE(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVI2Ge(self):
  VVHQsP = []
  VVHQsP.append("%s%s" % (VVDznn, "*.py"))
  VVHQsP.append("%s%s" % (VVDznn, "*.png"))
  VVHQsP.append("%s%s" % (VVDznn, "*.xml"))
  VVHQsP.append("%s"  % (VVrjWk))
  FFbZBm(self, VVHQsP, "%s_%s" % (PLUGIN_NAME, VVS3nw), addTimeStamp=False)
 def VVaAYb(self):
  path1 = VVmqmq
  path2 = "/etc/tuxbox/"
  VVHQsP = []
  VVHQsP.append("%s%s" % (path1, "*.tv"))
  VVHQsP.append("%s%s" % (path1, "*.radio"))
  VVHQsP.append("%s%s" % (path1, "*list"))
  VVHQsP.append("%s%s" % (path1, "lamedb*"))
  VVHQsP.append("%s%s" % (path2, "*.xml"))
  FFbZBm(self, VVHQsP, self.VV5vZP("channels_backup"), addTimeStamp=True)
 def VVNY91(self):
  VVHQsP = []
  VVHQsP.append("/etc/tuxbox/config/")
  VVHQsP.append("/usr/keys/")
  VVHQsP.append("/usr/scam/")
  VVHQsP.append("/etc/CCcam.cfg")
  FFbZBm(self, VVHQsP, self.VV5vZP("softcam_backup"), addTimeStamp=True)
 def VVS54J(self):
  VVHQsP = []
  VVHQsP.append("/etc/hostname")
  VVHQsP.append("/etc/default_gw")
  VVHQsP.append("/etc/resolv.conf")
  VVHQsP.append("/etc/wpa_supplicant*.conf")
  VVHQsP.append("/etc/network/interfaces")
  VVHQsP.append("%snameserversdns.conf" % VVmqmq)
  FFbZBm(self, VVHQsP, self.VV5vZP("network_backup"), addTimeStamp=True)
 def VV5vZP(self, fName):
  img = CC7eWy.VVflFN()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVar7y(self, fileName=None):
  if fileName:
   FFWV4g(self, BF(FFqcaP, self, BF(self.VVs6Jl, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVs6Jl(self, fileName):
  path = "%s%s" % (VV4J76, fileName)
  if fileExists(path):
   if CCk3u6.VV5fkt(path):
    VVfEtY , VV7mvy = CCDvzd.VVwWfa()
    VVJvwr, VVOcdR = CCDvzd.VVluJ5()
    cmd  = FFqAik("cd %s" % VVmqmq) + ";"
    cmd += FFqAik("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VV7mvy, VVOcdR))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFG6ML()
    if res == 0 : FFfF2j(self, "Channels Restored.")
    else  : FF1uaI(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FF1uaI(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFr3Kr(self, path)
 def VVoRGZ(self, fileName=None):
  if fileName:
   FFWV4g(self, BF(self.VVCYSv, fileName), "Overwrite SoftCAM files ?")
 def VVCYSv(self, fileName):
  fileName = "%s%s" % (VV4J76, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVbL9B
   note = "You may need to restart your SoftCAM."
   FFlE1p(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFDB5L(note, VVsZ3Y), sep))
  else:
   FFr3Kr(self, fileName)
 def VVSnPE(self, fileName=None):
  if fileName:
   FFWV4g(self, BF(self.VVGsVp, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVGsVp(self, fileName):
  fileName = "%s%s" % (VV4J76, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFkyna(self,  cmd)
  else:
   FFr3Kr(self, fileName)
 def VVcT1Y(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFphjG()
  if pathExists(VV4J76):
   myFiles = FF6jDI(VV4J76, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVHQsP = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVHQsP.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVQIvk = ("Sat. List", self.VVuMEf)
    elif isChan and iTar: VVQIvk = ("Bouquets Importer", CC1AZG.VVxpc7)
    else    : VVQIvk = None
    FFxMT2(self, callBackFunction, title=title, width=1200, VVd21k=VVHQsP, VVQIvk=VVQIvk, yellowBasePath=VV4J76)
   else:
    FF1uaI(self, "No files found in:\n\n%s" % VV4J76, title)
  else:
   FF1uaI(self, "Path not found:\n\n%s" % VV4J76, title)
 def VVE7r7(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVmqmq
  tCons = CCN83i()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVKfl7, filePrefix))
 def VVKfl7(self, filePrefix, result, retval):
  title = FFphjG()
  if pathExists(VV4J76):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF1uaI(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VV4J76, filePrefix, self.VV5vZP(""), FF5Vj3())
    try:
     VVHQsP = str(result.strip()).split()
     if VVHQsP:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVHQsP:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVbL9B, FFHqZk(fName, VVsZ3Y), VVbL9B)
       FFX3Iv(self, txt, title=title, VVXwlZ=VVlCEy)
      else:
       FF1uaI(self, "File creation failed!", title)
     else:
      FF1uaI(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFqAik("rm %s" % fName))
     FF1uaI(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFqAik("rm %s" % fName))
     FF1uaI(self, "Error while writing file.")
  else:
   FF1uaI(self, "Path not found:\n\n%s" % VV4J76, title)
 def VVMCQg(self, mode, path=None):
  if path:
   path = "%s%s" % (VV4J76, path)
   if fileExists(path):
    lines = FFwiKR(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFWV4g(self, BF(self.VVhxgj, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFGQJR(self, path, title=FFphjG())
   else:
    FFr3Kr(self, path)
 def VVhxgj(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  isVTi = pathExists(VVXS9f + "VTIPanel")
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    if isVTi and ".dvbs." in line: pass
    else       : finalList.append(line)
  VV87m4 = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajpanel_tmp"
  VV87m4.append("echo -e 'Reading current settings ...'")
  VV87m4.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VV87m4.append("echo -e 'Preparing new settings ...'")
  VV87m4.append(settingsLines)
  VV87m4.append("echo -e 'Applying new settings ...'")
  VV87m4.append("mv -f %s %s" % (tFile, sFile))
  FFXjds(self, VV87m4)
 def VVuMEf(self, VVFy7pObj, path):
  if not path:
   return
  path = VV4J76 + path
  if not fileExists(path):
   FFr3Kr(self, path)
   return
  txt = FFnMVE(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFJASh(item[1]))
   FFX3Iv(self, txt, title="Satellites List")
  else:
   FF1uaI(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC1AZG():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVxpc7(SELF, fName):
  bi = CC1AZG(SELF)
  bi.instance = bi
  bi.VVTS2E(SELF, fName)
 @staticmethod
 def VVDvoe(SELF):
  bi = CC1AZG(SELF)
  bi.instance = bi
  bi.VV9E8T()
 def VVTS2E(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VV4J76 + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFqcaP(waitObg, self.VV3FTH, title="Reading bouquets ...")
  else      : self.VVlh03(self.filePath)
 def VV1kxV(self, txt) : FF1uaI(self.SELF, txt, title=self.Title)
 def VV3KZ2(self, txt)  : FFkxeT(self, txt, 1500)
 def VVlh03(self, path) : FFr3Kr(self.SELF, path, title=self.Title)
 def VV9E8T(self):
  if pathExists(VV4J76):
   lst = FF6jDI(VV4J76, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VV9qg9())
   if len(lst) > 0:
    VVd21k = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFHqZk(item, VVWFW6) if item.endswith(".zip") else item
     VVd21k.append((txt, item))
    VVd21k.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVwhq0
    FFxMT2(self.SELF, self.VVQJCw, minRows=3, title=self.Title, width=1200, VVd21k=VVd21k, OKBtnFnc=OKBtnFnc, yellowBasePath=VV4J76, VVW1CX="#22111111", VVLasp="#22111111")
   else:
    self.VV1kxV("No valid backup files found in:\n\n%s" % VV4J76)
  else:
   self.VV1kxV("Backup Directory not found:\n\n%s" % VV4J76)
 def VVwhq0(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVTS2E(menuInstance, fName)
 def VVQJCw(self, item=None):
  if not item and self.instance:
   del self.instance
 def VV9qg9(self):
  files = FF6jDI(VV4J76, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VV3FTH(self):
  lines, err = CC1AZG.VVWNyD(self.filePath, "bouquets.tv")
  if err:
   self.VV1kxV(err)
   return
  bTvSortLst  = self.VVL9um(lines)
  lines, err = CC1AZG.VVWNyD(self.filePath, "bouquets.radio")
  if err:
   self.VV1kxV(err)
   return
  bRadSortLst = self.VVL9um(lines)
  VVG5ES = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVKXjx(f, mode, len(VVG5ES), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVG5ES.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVKXjx(f, mode, len(VVG5ES), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVKXjx(f, mode, len(VVG5ES), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVG5ES.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVKXjx(f, mode, len(VVG5ES), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVG5ES:
   VVG5ES.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVG5ES): VVG5ES[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVG5ES):
     if key == os.path.basename(row[9]):
      VVG5ES = VVG5ES[:ndx+1] + lst + VVG5ES[ndx+1:]
      break
   for ndx, item in enumerate(VVG5ES): VVG5ES[ndx][0] = str(ndx + 1)
   VVHSOH = "#11000600"
   VVmG3M  = ("Show Services" , self.VVFwfW  , [], "Reading ..." )
   VVAe4b = (""    , self.VVEPiN, [])
   VVQJvS = ("Options"  , self.VVYqu6, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VV4tj2  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FF8dRU(self.SELF, None, title=self.Title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=24, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVQJvS=VVQJvS, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVW1CX=VVHSOH, VVLasp=VVHSOH, VVHSOH=VVHSOH, VVNfgg="#11ffffff", VVJqmr="#00004455", VVFNoD="#0a282828")
  else:
   self.VV1kxV("No valid bouquets in:\n\n%s" % self.filePath)
 def VVL9um(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVEPiN(self, VVc7Yu, title, txt, colList):
  FFX3Iv(self.SELF, FFFnqK(txt), title=title)
 def VVYqu6(self, VVc7Yu, title, txt, colList):
  mSel = CC8qau(self.SELF, VVc7Yu)
  if VVc7Yu.VVh7FN:
   totSel = VVc7Yu.VVcONI()
   if totSel: VVd21k = [("Import %s Bouquet%s" % (FFHqZk(str(totSel), VVs4yr), FFwHmW(totSel)), "imp")]
   else  : VVd21k = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFHqZk(bName, VVs4yr)
   VVd21k = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFqcaP, VVc7Yu, BF(CC1AZG.VVoAmv, self.SELF, VVc7Yu, self.filePath))}
  mSel.VVyFGx(VVd21k, cbFncDict)
 def VVFwfW(self, VVc7Yu, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CC1AZG.VVWNyD(self.filePath, "lamedb")
   if err:
    self.VV1kxV(err)
    return
   dbServLst = CCDvzd.VVVsJj(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVc7Yu.VVDx8h()
   lines, err = CC1AZG.VVWNyD(self.filePath, os.path.basename(fName))
   if err:
    self.VV1kxV(err)
    return
   VVG5ES = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVG5ES.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVG5ES.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVG5ES.append((span.group(1).strip() or "-", "Stream Relay" if FFqc3z(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVG5ES.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVG5ES.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCDvzd.VVlShc(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVG5ES.append((name.strip() or "-", FFkQZJ(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVG5ES):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CC1AZG.VVWNyD(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVG5ES[ndx] = (bName, descr)
   if VVG5ES:
    VVHSOH = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VV4tj2 = (LEFT  , CENTER)
    FF8dRU(self.SELF, None, title="Services in : %s" % bName, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, VVW1CX=VVHSOH, VVLasp=VVHSOH, VVHSOH=VVHSOH, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFkxeT(VVc7Yu, err, 1500)
  else : VVc7Yu.VVSLMs()
 def VVKXjx(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VV1kxV("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFqc3z(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV8Y2s(var):
   return str(var) if var else VV2vWn + str(var)
  totItem = VVsZ3Y + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VV0kWR   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVWFW6, "Sub-B."
  else  : bColor, totBnb = ""      , VV8Y2s(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV8Y2s(totDVB), VV8Y2s(totIptv), VV8Y2s(totSRelay), VV8Y2s(totLoc), VV8Y2s(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVoAmv(SELF, VVc7Yu, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVmqmq + "bouquets.tv"
  radBouquetFile = VVmqmq + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFr3Kr(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFr3Kr(SELF, radBouquetFile, title=title)
   return
  isMulti = VVc7Yu.VVh7FN
  if isMulti : rows = VVc7Yu.VV6eMo()
  else  : rows = [VVc7Yu.VVDx8h()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FF1uaI(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFFnqK(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFFnqK(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVmqmq + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVmqmq + newFile
    CC1AZG.VVaNE9(archPath, fName, VVmqmq, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CCB8uV.VViwum(tvBouquetFile)
   CCB8uV.VViwum(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CC1AZG.VVRNAp(SELF, archPath, bList)
   FFG6ML()
  txt  = FFHqZk("Added:\n", VVWFW6)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFHqZk("Imported to lamedab:\n", VVWFW6)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFHqZk("Missing from archived lamedb:\n", VV0kWR)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFX3Iv(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVRNAp(SELF, archPath, bList):
  VVfEtY, err = CCDvzd.VVk7xD(SELF, VVFu5u=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCDvzd.VV8VXQ(VVfEtY, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFwiKR(VVmqmq + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCDvzd.VVlShc(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCDvzd.VVbixs(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CC1AZG.VVFb2M(archPath, dbName)
   CC1AZG.VVaNE9(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCDvzd.VV8VXQ(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCDvzd.VV8VXQ(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCDvzd.VV8VXQ(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCDvzd.VV8VXQ(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFC2Q5(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVfEtY + ".tmp"
   lines   = FFwiKR(VVfEtY)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFqAik("mv -f '%s' '%s'" % (tmpDbFile, VVfEtY)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVqbUb(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVFb2M(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVaNE9(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVWNyD(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCxMgL(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVilCV, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVd21k = []
  VVd21k.append(("Plugins Browser List"       , "VV1Fag"   ))
  VVd21k.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVd21k.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages"  ))
  VVd21k.append(("Remove Packages (show all)"     , "VVqgdLsAll"   ))
  VVd21k.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Update Packages List from Feed"    , "VVtcYT"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Packaging Tool"        , "VVmgU9"    ))
  VVd21k.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFrOoX(self, VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV1Fag"   : self.VV1Fag()
   elif item == "pluginsMenus"     : self.VVJ8ea(0)
   elif item == "pluginsStartup"    : self.VVJ8ea(1)
   elif item == "pluginsDirList"    : self.VVJpRV()
   elif item == "downloadInstallPackages"  : FFqcaP(self, BF(self.VVvfL7, 0, ""))
   elif item == "VVqgdLsAll"   : FFqcaP(self, BF(self.VVvfL7, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFqcaP(self, BF(self.VVvfL7, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVtcYT"   : CCxMgL.VVtcYT(self)
   elif item == "VVmgU9"    : self.VVmgU9()
   elif item == "packagesFeeds"    : self.VVtKxv()
   else          : self.close()
 def VVJpRV(self):
  extDirs  = FFsIfj(VVP65U)
  sysDirs  = FFsIfj(VVXS9f)
  VVHQsP  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVHQsP.append((item, VVP65U + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVHQsP.append((item, VVXS9f + item))
  if VVHQsP:
   VVHQsP.sort(key=lambda x: x[0].lower())
   VVQJvS = ("Package Info.", self.VV7Bvl, [])
   VVOr9v = ("Open in File Manager", BF(self.VVSUjE, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FF8dRU(self, None, header=header, VVHQsP=VVHQsP, VVje1O=widths, VVlvFD=28, VVQJvS=VVQJvS, VVOr9v=VVOr9v)
  else:
   FF1uaI(self, "Nothing found!")
 def VV7Bvl(self, VVc7Yu, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVP65U) : loc = "extensions"
  elif path.startswith(VVXS9f) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV20GE(package)
  else:
   FF1uaI(self, "No info!")
 def VVtKxv(self):
  pkg = FFT9Rp()
  if pkg : FFVBAP(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF3PaD(self)
 def VV1Fag(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV0iDg(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVbL9B + "\n"
    txt += VV0iDg("Number"   , str(c))
    txt += VV0iDg("Name"   , FFHqZk(str(p.name), VVsZ3Y))
    txt += VV0iDg("Path"  , p.path  )
    txt += VV0iDg("Description" , p.description )
    txt += VV0iDg("Icon"  , p.iconstr  )
    txt += VV0iDg("Wakeup Fnc" , p.wakeupfnc )
    txt += VV0iDg("NeedsRestart", p.needsRestart)
    txt += VV0iDg("Internal" , p.internal )
    txt += VV0iDg("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFX3Iv(self, txt)
 def VVJ8ea(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVHQsP = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVHQsP.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVHQsP:
   VVHQsP.sort(key=lambda x: x[0].lower())
   VVOr9v = ("Open in File Manager", BF(self.VVSUjE, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVHQsP, VVje1O=widths, VVlvFD=26, VVOr9v=VVOr9v)
  else:
   FF1uaI(self, "Nothing Found", title=title)
 def VVSUjE(self, pathColNum, VVc7Yu, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CCk3u6, mode=CCk3u6.VVr7yL, VVl4c7=path)
  else    : FFkxeT(VVc7Yu, "Path not found !", 1500)
 @staticmethod
 def VVtcYT(SELF):
  cmd = FF1WnD(VVZEcr, "")
  if cmd : FFkyna(SELF, cmd, checkNetAccess=True)
  else : FF3PaD(SELF)
 def VVmgU9(self):
  pkg = FFT9Rp()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFfF2j(self, txt)
 def VVvfL7(self, mode, grep, VVc7Yu=None, title=""):
  if   mode == 0: cmd = FF1WnD(VVEd4d    , grep)
  elif mode == 1: cmd = FF1WnD(VVvIYW , grep)
  elif mode == 2: cmd = FF1WnD(VVvIYW , grep)
  if not cmd:
   FF3PaD(self)
   return
  VVG5ES = FFjUOl(cmd)
  if not VVG5ES:
   if VVc7Yu: VVc7Yu.VVSLMs()
   FF1uaI(self, "No packages found!")
   return
  elif len(VVG5ES) == 1 and VVG5ES[0] == VVhfZS:
   FF1uaI(self, VVhfZS)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVHQsP  = []
  for item in VVG5ES:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVHQsP.append((name, package, version))
  if mode > 0:
   extensions = FFjUOl("ls %s -l | grep '^d' | awk '{print $9}'" % VVP65U)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVHQsP:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVHQsP.append((name, VVP65U + item, "-"))
   systemPlugins = FFjUOl("ls %s -l | grep '^d' | awk '{print $9}'" % VVXS9f)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVHQsP:
      if item.lower() == row[0].lower():
       break
     else:
      VVHQsP.append((item, VVXS9f + item, "-"))
  if not VVHQsP:
   FF1uaI(self, "No packages found!")
   return
  if VVc7Yu:
   VVHQsP.sort(key=lambda x: x[0].lower())
   VVc7Yu.VV4ZQl(VVHQsP, title)
  else:
   widths = (20, 50, 30)
   VVZyxX = None
   VVOr9v = None
   if mode == 0:
    VVDti0 = ("Install" , self.VV5FeR   , [])
    VVZyxX = ("Download" , self.VVySOE   , [])
    VVOr9v = ("Filter"  , self.VVejOV , [])
   elif mode == 1:
    VVDti0 = ("Uninstall", self.VVqgdL, [])
   elif mode == 2:
    VVDti0 = ("Uninstall", self.VVqgdL, [])
    widths= (18, 57, 25)
   VVHQsP.sort(key=lambda x: x[0].lower())
   VVQJvS = ("Package Info.", self.VVanwo, [])
   header   = ("Name" ,"Package" , "Version" )
   FF8dRU(self, None, header=header, VVHQsP=VVHQsP, VVje1O=widths, VVlvFD=28, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVmn6o=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVW1CX="#22110011", VVLasp="#22191111", VVHSOH="#22191111", VVJqmr="#00003030", VVFNoD="#00333333")
 def VVanwo(self, VVc7Yu, title, txt, colList):
  package = colList[1]
  self.VV20GE(package)
 def VVejOV(self, VVc7Yu, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVd21k = []
  VVd21k.append(("All Packages", "all"))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVd21k.append(VVNCuu)
  for word in words:
   VVd21k.append((word, word))
  FFxMT2(self, BF(self.VVZ4Jb, VVc7Yu), VVd21k=VVd21k, title="Select Filter")
 def VVZ4Jb(self, VVc7Yu, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFqcaP(VVc7Yu, BF(self.VVvfL7, 0, grep, VVc7Yu, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVqgdL(self, VVc7Yu, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVP65U, VVXS9f)):
   FFWV4g(self, BF(self.VVbnuO, VVc7Yu, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVd21k = []
   VVd21k.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVd21k.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVd21k.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFxMT2(self, BF(self.VV0nOs, VVc7Yu, package), VVd21k=VVd21k)
 def VVbnuO(self, VVc7Yu, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV6BHw)
  FFkyna(self, cmd, VVHcKu=BF(self.VVg6Ak, VVc7Yu))
 def VV0nOs(self, VVc7Yu, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV9G95
   elif item == "remove_ForceRemove"  : cmdOpt = VVoPbw
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVCn0U
   FFWV4g(self, BF(self.VVBrIg, VVc7Yu, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVBrIg(self, VVc7Yu, package, cmdOpt):
  self.lastSelectedRow = VVc7Yu.VVbJrA()
  cmd = FF5LxN(cmdOpt, package)
  if cmd : FFkyna(self, cmd, VVHcKu=BF(self.VVg6Ak, VVc7Yu))
  else : FF3PaD(self)
 def VVg6Ak(self, VVc7Yu):
  VVc7Yu.cancel()
  FFi8dt()
 def VV5FeR(self, VVc7Yu, title, txt, colList):
  package  = colList[1]
  VVd21k = []
  VVd21k.append(("Install Package"         , "install_CheckVersion" ))
  VVd21k.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVd21k.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVd21k.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVd21k.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFxMT2(self, BF(self.VV9GDE, package), VVd21k=VVd21k)
 def VV9GDE(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVQGHq
   elif item == "install_ForceReinstall" : cmdOpt = VVqGH2
   elif item == "install_ForceOverwrite" : cmdOpt = VVXZJT
   elif item == "install_ForceDowngrade" : cmdOpt = VVAsra
   elif item == "install_IgnoreDepends" : cmdOpt = VVGYhV
   FFWV4g(self, BF(self.VVAj0U, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVAj0U(self, package, cmdOpt):
  cmd = FF5LxN(cmdOpt, package)
  if cmd : FFkyna(self, cmd, VVHcKu=FFi8dt, checkNetAccess=True)
  else : FF3PaD(self)
 def VVySOE(self, VVc7Yu, title, txt, colList):
  package  = colList[1]
  FFWV4g(self, BF(self.VVHsra, package), "Download Package ?\n\n%s" % package)
 def VVHsra(self, package):
  if FFLsnX():
   cmd = FF5LxN(VVOqI4, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFDB5L(success, VVs4yr))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFDB5L(fail, VVpiVU))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFkyna(self, cmd, VVbBvt=[VVpiVU, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF3PaD(self)
  else:
   FF1uaI(self, "No internet connection !")
 def VV20GE(self, package):
  infoCmd  = FF5LxN(VV1fea, package)
  filesCmd = FF5LxN(VVcPSx, package)
  listInstCmd = FF1WnD(VVvIYW, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF95QJ(VVsZ3Y)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFDB5L(notInst, VV0kWR))
   cmd += "else "
   cmd +=   FFofzq("System Info", VVsZ3Y)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFofzq("Related Files", VVsZ3Y)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF3Yso(self, cmd)
  else:
   FF3PaD(self)
class CCbyck():
 def VVsf6x(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVmCrg()
 def VVmCrg(self):
  files = FF6jDI(VV4J76, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVd21k = []
   for fil in files:
    VVd21k.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVW1CX, VVLasp = "#22221133", "#22221133"
   else    : VVW1CX, VVLasp = "#22003344", "#22002233"
   VVQIvk  = ("Add new File", self.VVbvru)
   FFxMT2(self, self.VVPxeT, VVd21k=VVd21k, width=1100, VVQIvk=VVQIvk, yellowBasePath="", minRows=4, VVW1CX=VVW1CX, VVLasp=VVLasp)
  else:
   FFWV4g(self, self.VVSAf6, "No files found.\n\nCreate a new file ?")
 def VVSAf6(self):
  path = self.VVoWud()
  if fileExists(path) : self.VVmCrg()
  else    : FFkxeT(self, "Cannot create file", 1500)
 def VVbvru(self, menuInstance, path):
  path = self.VVoWud()
  menuInstance.VVTvQu((os.path.basename(path), path), isSort=True)
 def VVoWud(self):
  path = "%s%s%s.xml" % (VV4J76, self.shareFilePrefix, FF5Vj3())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVPxeT(self, path=None):
  if path:
   FFqcaP(self, BF(self.VVFuFJ, path))
 def VVFuFJ(self, path):
  if not fileExists(path):
   FFr3Kr(self, path)
   return
  elif not CCk3u6.VVsTOj(self, path, FFphjG()):
   return
  else:
   self.shareFilePath = path
  if not CCNCRq.VVdet0(self):
   return
  tree = CCDvzd.VV3zj6(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCB8uV.VVOlLm()
  def VV0iDg(refCode):
   if   FFqjQ5(refCode): return FFHqZk("DVB", VVusL5)
   elif refCode in refLst     : return FFHqZk("IPTV", VVusL5)
   else         : return ""
  VVG5ES= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVkmQc(ch)
   if ok:
    srcTxt = VV0iDg(srcRef)
    dstTxt = VV0iDg(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVG5ES:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVG5ES.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVG5ES:
   if self.shareIsRef : VVW1CX, VVLasp, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVW1CX, VVLasp, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVbNxw = (""    , BF(self.VVgLnq, dupl), [])
   VVAe4b = (""    , self.VV41Ni    , [])
   VVDti0 = ("Delete Entry" , self.VVj7cl   , [])
   VVZyxX = ("Add Entry"  , self.VVBvrN   , [])
   VVQJvS = (optTxt   , self.VV6cJA  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VV4tj2 = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVc7Yu = FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=24, VVbNxw=VVbNxw, VVAe4b=VVAe4b, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVDYPP=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVLasp, VVNfgg="#00ffffaa", VVJqmr="#0a000000")
  else:
   FF1uaI(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVgLnq(self, dupl, VVc7Yu, title, txt, colList):
  if dupl:
   VVc7Yu.VVdNoE("Skipped %d duplicate%s" % (dupl, FFwHmW(dupl)), 2000)
 def VV41Ni(self, VVc7Yu, title, txt, colList):
  def VV0iDg(key, val): return "%s\t: %s\n" % (key, val or FFHqZk("?", VVHeSZ))
  Keys = VVc7Yu.VVFjOt()
  Vals = VVc7Yu.VVDx8h()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VV0iDg(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVs4yr, VVHeSZ
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFX3Iv(self, txt + txt1, title=title)
 def VVkmQc(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVj7cl(self, VVc7Yu, title, txt, colList):
  if VVc7Yu.VVbJrA() == 0 and VVc7Yu.VVpm2D() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFWV4g(self, BF(self.VVgqKL, isLast, VVc7Yu), ques)
 def VVgqKL(self, isLast, VVc7Yu):
  if isLast:
   FFC2Q5(self.shareFilePath)
   VVc7Yu.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVc7Yu.VVDx8h()
   if self.VVGpLR(srcName, srcRef, dstName, dstRef):
    VVc7Yu.VVe4e7()
    VVc7Yu.VVTjqd()
    FFkxeT(VVc7Yu, "Deleted", 500, isGrn=True)
   else:
    FFkxeT(VVc7Yu, "Cannot delete from file", 2000)
 def VVBvrN(self, VVc7Yu, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVlKma(VVc7Yu, isDvb=True)
  else    : self.VVk2XP(VVc7Yu, "Source Channel", "#22003344", "#22002233")
 def VVk2XP(self, mainTableInst, title, VVW1CX, VVLasp):
  FFxMT2(self, BF(self.VVOQNV, mainTableInst, title), VVd21k=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVW1CX=VVW1CX, VVLasp=VVLasp)
 def VVOQNV(self, mainTableInst, title, item=None):
  if item:
   FFqcaP(mainTableInst, BF(self.VV0fJ2, mainTableInst, title, item), clearMsg=False)
 def VV0fJ2(self, mainTableInst, title, item):
  FFkxeT(mainTableInst)
  if item == "DVB": self.VVlKma(mainTableInst, isDvb=True)
  else   : self.VVlKma(mainTableInst, isDvb=False)
 def VVv9zr(self, mainTableInst, chType, VVc7Yu, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVc7Yu.VVbJrA()
  if   chType == "DVB" : FFWvPK(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFWvPK(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVgeCg()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FF1uaI(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VV0sYC(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVYxhd((str(mainTableInst.VVpm2D() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFkxeT(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFkxeT(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFkxeT(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVlKma(mainTableInst, isDvb=False)
   else    : FFnCJX(BF(self.VVk2XP, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVc7Yu.cancel()
 def VVH4iI(self, item, VVc7Yu, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVc7Yu.VVQ2AR(ndx)
 def VVlKma(self, VVc7Yu, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVv9zr, VVc7Yu, typ)
  doneFnc = BF(self.VVH4iI, typ)
  if isDvb: CCbyck.VVktVU(VVc7Yu , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCbyck.VVql5D(VVc7Yu, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVktVU(SELF, title, okFnc, doneFnc=None):
  FFqcaP(SELF, BF(CCbyck.VVQH2K, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVQH2K(SELF, title, okFnc, doneFnc=None):
  VVG5ES, err = CCDvzd.VVReux(SELF, CCDvzd.VVqKCi)
  if VVG5ES:
   color = "#0a000022"
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVmG3M = ("Select" , okFnc, [])
   VVbNxw= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VV4tj2 = (LEFT  , LEFT  , CENTER, LEFT    )
   FF8dRU(SELF, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVW1CX=color, VVLasp=color, VVHSOH=color, VVmG3M=VVmG3M, VVbNxw=VVbNxw, lastFindConfigObj=CFG.lastFindServices)
  else:
   FF1uaI(SELF, "No DVB Services !")
 @staticmethod
 def VVql5D(SELF, title, okFnc, doneFnc=None):
  FFqcaP(SELF, BF(CCbyck.VVCi74, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVCi74(SELF, title, okFnc, doneFnc=None):
  VVG5ES = CCbyck.VVIVod()
  if VVG5ES:
   color = "#0a112211"
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVmG3M = ("Select" , okFnc, [])
   VVbNxw= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FF8dRU(SELF, None, title=title, header=header, VVHQsP=VVG5ES, VVje1O=widths, VVlvFD=26, VVW1CX=color, VVLasp=color, VVHSOH=color, VVmG3M=VVmG3M, VVbNxw=VVbNxw, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF1uaI(SELF, "No IPTV Services !")
 @staticmethod
 def VVIVod():
  VVG5ES = []
  files  = CCHF2n.VVS8Qr()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFnMVE(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVurIH = span.group(1)
    else : VVurIH = ""
    VVurIH_lCase = VVurIH.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVG5ES.append((chName, VVurIH, url, refCode))
  return VVG5ES
 def VV0sYC(self, srcName, srcRef, dstName, dstRef):
  tree = CCDvzd.VV3zj6(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVP0m0(tree, root)
  return True
 def VVGpLR(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCDvzd.VV3zj6(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVkmQc(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVP0m0(tree, root)
  return found
 def VVP0m0(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCDvzd.VV1hIr(xmlTxt)
  parser = CCDvzd.CCk6P8()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VV6cJA(self, VVc7Yu, title, txt, colList):
  if self.onlyEpg:
   self.VVDrpO(VVc7Yu, "epg")
  else:
   if self.shareIsRef:
    FFWV4g(self, BF(FFqcaP, VVc7Yu, BF(self.VVXOBr, VVc7Yu)), "Copy all References from Source to Destination ?")
   else:
    VVd21k = []
    VVd21k.append(("Copy EPG\t (All List)" , "epg"  ))
    VVd21k.append(("Copy Picons\t (All List)" , "picon" ))
    FFxMT2(self, BF(self.VVDrpO, VVc7Yu), VVd21k=VVd21k, width=1000)
 def VVDrpO(self, VVc7Yu, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVc7jn  , "EPG"
   elif item == "picon": fnc, txt = self.VVwawl , "PIcons"
   title = "Copy %s" % txt
   tot   = VVc7Yu.VVpm2D()
   FFWV4g(self, BF(FFqcaP, VVc7Yu, BF(fnc, VVc7Yu, title)), "Overwrite %s for %d Service%s ?" % (FFHqZk(txt, VVsZ3Y), tot, FFwHmW(tot)), title=title)
 def VVXOBr(self, VVc7Yu):
  files = CCHF2n.VVS8Qr()
  totChange = 0
  if files:
   for path in files:
    txt = FFnMVE(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVc7Yu.VVgeCg():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFG6ML()
  tot = VVc7Yu.VVpm2D()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFX3Iv(self, txt)
 def VVwawl(self, VVc7Yu, title):
  if not iCopyfile:
   FF1uaI(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCodIm.VVt98d()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVc7Yu.VVgeCg():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVc7Yu.VVpm2D()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFX3Iv(self, txt, title=title)
 def VVc7jn(self, VVc7Yu, title):
  txt, err = CCTkbp.VVZFMB(VVc7Yu, title)
  if err : FF1uaI(self, err, title=title)
  else : FFX3Iv(self, txt, title=title)
 class CCk6P8(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VV3zj6(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCDvzd.CCk6P8())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFHqZk("XML Parse Error in:", VVHeSZ), path)
   txt += "%s\n%s\n\n" % (FFHqZk("Error:", VVHeSZ), str(e))
   FFX3Iv(SELF, txt, VVHSOH="#11220000", title=title)
   return None
 @staticmethod
 def VV1hIr(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCTkbp(Screen, CCbyck):
 VVM45T  = "BDTSE"
 VVsUyW   = "save"
 VVRBlb   = "load"
 VVrVxg  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FF1pMw(VVilCV, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCTkbp.VVoRZU()
  qUrl, iptvRef = CCHF2n.VVlKug(self)
  VVd21k = []
  VVd21k.append((VVusL5 + "Cache File Info." , "inf"))
  VVd21k.append(VVNCuu)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  t1 = "Save EPG to File%s" % fTxt
  t2 = "Load EPG from File%s" % fTxt
  if valid:
   VVd21k.append((t1, self.VVsUyW))
   VVd21k.append((t2, self.VVRBlb))
  else:
   VVd21k.append((t1, ))
   VVd21k.append((t2, ))
  VVd21k.append(VVNCuu)
  VVd21k.append((VV0kWR + "Delete EPG (from RAM only)", self.VVrVxg))
  VVd21k.append(VVNCuu)
  txt = "Update Current Bouquet EPG (from IPTV Server)"
  if qUrl or "chCode" in iptvRef: VVd21k.append((txt, "refreshIptvEPG" ))
  else        : VVd21k.append((txt,     ))
  VVd21k.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Translate Current Channel EPG %s(Experimental)" % VV0kWR, "VVSjuS"))
  FFrOoX(self, VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVFpQI()
   elif item in (self.VVsUyW, self.VVRBlb, self.VVrVxg):
    reset = item == self.VVRBlb
    FFWV4g(self, BF(FFqcaP, self, BF(self.VVQ5XZ, item, reset)), VVJpRC="Continue ?")
   elif item == "refreshIptvEPG"  : CCHF2n.VVjLFE(self)
   elif item == "VVSjuS" : self.VVSjuS()
   elif item == "copyEpg"    : self.VVsf6x(False, onlyEpg=True)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVQ5XZ(self, act, reset=False):
  ok = CCTkbp.VVIHuK(act)
  if ok:
   if reset:
    CCTkbp.VVADzq(self)
   FFfF2j(self, "Done")
  else:
   FFfF2j(self, "Failed!")
 def VVFpQI(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCTkbp.VVoRZU()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFHqZk("File not found (check System EPG settings).", VV0kWR))
   FFX3Iv(self, txt, title=title)
  else:
   FF1uaI(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVXbuI():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVSjuS(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVmG3M  = (""  , BF(self.VVi9Es, title, True) , [])
  VVZyxX = ("Start" , BF(self.VVi9Es, title, False), [])
  VVOr9v = ("Change Language", self.VVKNYL      , [])
  widths  = (70 , 30)
  VV4tj2 = (LEFT , CENTER)
  FF8dRU(self, None, title=title, VVHQsP=self.VVM9Ab(), VV4tj2=VV4tj2, VVje1O=widths, width=1200, vMargin=20, VVlvFD=30, VVmG3M=VVmG3M, VVZyxX=VVZyxX, VVOr9v=VVOr9v, VVRqqp=2
    , VVW1CX="#11201010", VVLasp=bg, VVHSOH=bg, VVNfgg="#00ffffaa", VVJqmr="#00004455", VVFNoD=bg)
 def VVM9Ab(self):
  Def, ch = "DISABLED", dict(CCTkbp.VVXbuI())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVHQsP = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVHQsP
 def VVKNYL(self, VVc7Yu, title, txt, colList):
  ndx = VVc7Yu.VVbJrA()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCgs0Z.VVcuOM(self, confItem, title, lst=CCTkbp.VVXbuI(), cbFnc=BF(self.VVdm3z, VVc7Yu))
 def VVdm3z(self, VVc7Yu):
  for ndx, row in enumerate(self.VVM9Ab()):
   VVc7Yu.VVENUj(ndx, row)
 def VVi9Es(self, Title, isAsk, VVc7Yu, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFkxeT(VVc7Yu, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
   refCode, evList, err = CCTkbp.VVIhua(refCode)
   fnc = BF(self.VVeUaQ, Title, refCode, evList, VVc7Yu)
   if   err : FF1uaI(self, err, title=Title)
   elif isAsk : FFWV4g(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVeUaQ(self, title, refCode, evList, VVc7Yu):
  self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVOPXS, evList)
      , VVXlAY = BF(self.VVfi8n, title, refCode))
  VVc7Yu.cancel()
 def VVOPXS(self, evList, VVTb2z):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVTb2z.VViTTm(totEv)
  VVTb2z.VVc1Ja = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCTkbp.VV28FD(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VV3VHc(1)
   VVTb2z.VVSR2F(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVTb2z.VVc1Ja = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVfi8n(self, title, refCode, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVc1Ja
  if newLst: totEv, totOK = CCTkbp.VVrWAC(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCTkbp.VVmAj4()
   CCTkbp.VVADzq(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFX3Iv(self, txt, title=title)
 @staticmethod
 def VV28FD(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VV0iDg(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCTkbp.VVhi5T(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VV0iDg, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVhi5T(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFENC4(txt))
   txt, err = CCHF2n.VVl3JC(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFeHlW(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCTkbp.VVwjJw(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVoRZU():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FF2oRJ(path)
   szTxt = CCk3u6.VVeQ5q(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVS40D():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVmAj4(): CCTkbp.VVIHuK(CCTkbp.VVsUyW)
 @staticmethod
 def VVIHuK(act):
  ec, inst = CCTkbp.VVS40D()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVADzq(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVIhua(refCode):
  ec, inst = CCTkbp.VVS40D()
  if inst:
   try:
    evList = inst.lookupEvent([CCTkbp.VVM45T, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVrWAC(refCode, events, longDescDays=0):
  ec, inst = CCTkbp.VVS40D()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVDSwc(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCTkbp.VVS40D()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCTkbp.VVAJkT(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCfm5u.CCTkbp(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVAJkT(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCTkbp.VVTArb(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVE7c4(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCTkbp.VVS40D()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCTkbp.VVAJkT(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFeWDt(evTime)
       evEndTxt  = FFeWDt(evEnd)
       evDurTxt  = FF6f6P(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FF6f6P(evPos)
        evRem = evEnd - now
        evRemTxt = FF6f6P(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FF6f6P(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVTArb(event):
  genre = PR = ""
  try:
   genre  = CCTkbp.VV1fhN(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCTkbp.VVqzO6(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVqzO6(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VV1fhN(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCTkbp.VVgxpr()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVgxpr():
  path = VVrjWk + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFnMVE(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFnMVE(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVZFMB(VVc7Yu, title):
  ec, inst = CCTkbp.VVS40D()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVc7Yu.VVgeCg():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCTkbp.VVM45T, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCTkbp.VVrWAC(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCTkbp.VVmAj4()
  txt  = "Services\t: %d\n"  % VVc7Yu.VVpm2D()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVlJ4H(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCTkbp.VV38El(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCTkbp.VV38El(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCTkbp.VV38El(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VV38El(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTkbp.VVAJkT(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCTkbp.VV28FD(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFHqZk(evName, VVWFW6)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFHqZk(evNameTransl, VVWFW6))
    if evTime           : txt += "Start Time\t: %s\n" % FFeWDt(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFeWDt(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF6f6P(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF6f6P(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF6f6P(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFHqZk(evShort, VVRK3s)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFHqZk(evDesc , VVRK3s)
    if txt:
     txt = FFHqZk("\n%s\n%s Event:\n%s\n" % (VVbL9B, ("Current", "Next")[evNum], VVbL9B), VVWFW6) + txt
  return txt
 @staticmethod
 def VVwjJw(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCDvzd(Screen, CCbyck):
 VVvEXZ  = 0
 VVeZiZ = 1
 VVqX6m  = 2
 VVEOtL  = 3
 VVhhhH = 4
 VVRKv2 = 5
 VVVwsH = 6
 VVqKCi   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FF1pMw(VVilCV, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVXgHo = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVd21k = self.VVCScn()
  FFrOoX(self, VVd21k=VVd21k, title="Services/Channels")
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self["myMenu"].setList(self.VVCScn())
  FFmysb(self["myMenu"])
  FFCRqe(self)
 def VVCScn(self):
  VVd21k = []
  c = VVusL5
  VVd21k.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVd21k.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVd21k.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVd21k.append(VVNCuu)
  c = VVWFW6
  VVd21k.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVd21k.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVd21k.append((VVHeSZ + "More tables ..."     , "VVfDgh"    ))
  c = VVRK3s
  VVd21k.append(VVNCuu)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVd21k.append((c + txt          , "VVDvoe"  ))
  else : VVd21k.append((txt           ,          ))
  VVd21k.append((c + 'Export Services to "channels.xml"'    , "VVP5xK"      ))
  VVd21k.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVyuFD
  VVd21k.append(VVNCuu)
  VVd21k.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVd21k.append((c + "Invalid Services Cleaner"       , "VVn9Vu"    ))
  c = VVyuFD
  VVd21k.append(VVNCuu)
  VVd21k.append((c + "Delete Channels with no names"     , "VVZDvd"    ))
  VVd21k.append((c + "Delete Empty Bouquets"       , "VVkSfu"     ))
  VVd21k.append(VVNCuu)
  VVfEtY, VV7mvy = CCDvzd.VVwWfa()
  if fileExists(VVfEtY):
   enab = fileExists(VV7mvy)
   if enab: VVd21k.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVd21k.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVd21k.append(("Reset Parental Control Settings"      , "VVeYyJ"    ))
  VVd21k.append(("Reload Channels and Bouquets"       , "VVfpr0"      ))
  return VVd21k
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCqzRz.VVfphk(self.session)
   elif item == "openSignal"       : FF0wqg(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFdGDb(self, fncMode=CCfm5u.VVXXAh)
   elif item == "lameDB_allChannels_with_refCode"  : FFqcaP(self, self.VVGAH5)
   elif item == "lameDB_allChannels_with_tranaponder" : FFqcaP(self, self.VVSepu)
   elif item == "VVfDgh"     : self.VVfDgh()
   elif item == "VVDvoe"  : CC1AZG.VVDvoe(self)
   elif item == "VVP5xK"      : self.VVP5xK()
   elif item == "copyEpgPicons"      : self.VVsf6x(False)
   elif item == "SatellitesCleaner"     : FFqcaP(self, self.FFqcaP_SatellitesCleaner)
   elif item == "VVn9Vu"    : FFqcaP(self, BF(self.VVn9Vu))
   elif item == "VVZDvd"    : FFqcaP(self, self.VVZDvd)
   elif item == "VVkSfu"     : self.VVkSfu(self)
   elif item == "enableHiddenChannels"     : self.VVK8ix(True)
   elif item == "disableHiddenChannels"    : self.VVK8ix(False)
   elif item == "VVeYyJ"    : FFWV4g(self, self.VVeYyJ, "Reset and Restart ?")
   elif item == "VVfpr0"      : FFqcaP(self, BF(CCDvzd.VVfpr0, self))
 def VVfDgh(self):
  VVd21k = []
  VVd21k.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVd21k.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVd21k.append(("Services with PIcons for the System"  , "VV4v3C"     ))
  VVd21k.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVd21k.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  FFxMT2(self, self.VVSrcC, VVd21k=VVd21k, title="Service Information", VVL2h3=True)
 def VVSrcC(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFqcaP(self, BF(self.VVdRrS, title))
   elif ref == "parentalControlChannels"   : FFqcaP(self, BF(self.VVVC8v, title))
   elif ref == "showHiddenChannels"    : FFqcaP(self, BF(self.VVCwaa, title))
   elif ref == "VV4v3C"    : FFqcaP(self, BF(self.VVEVJ5, title))
   elif ref == "servicesWithMissingPIcons"   : FFqcaP(self, BF(self.VVpXSN, title))
   elif ref == "TranspondersStats"     : FFqcaP(self, BF(self.VVaqMs, title))
   elif ref == "SatellitesXmlStats"    : FFqcaP(self, BF(self.VVScKj, title))
 def VVP5xK(self):
  VVd21k = []
  VVd21k.append(("All DVB-S/C/T Services", "all"))
  VVd21k.extend(CCB8uV.VVO48d())
  FFxMT2(self, self.VVbskR, VVd21k=VVd21k, title="", VVL2h3=True)
 def VVbskR(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCDvzd.VV5MIw("1:7:")
   else   : lst = FFWeHh(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFkQZJ(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFqc3z(r)  : sat = "Stream Relay"
       elif FFkOAA(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFjZE4(CFG.exportedTablesPath.getValue()), FF5Vj3())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFfF2j(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFkxeT(self, "No Services found !", 1500)
 @staticmethod
 def VVfpr0(SELF):
  FFG6ML()
  FFfF2j(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVGAH5(self):
  self.VVXgHo = None
  self.lastfilterUsed  = None
  self.filterObj   = CC4Wdl(self)
  VVG5ES, err = CCDvzd.VVReux(self, self.VVvEXZ)
  if VVG5ES:
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVmG3M  = ("Zap"   , self.VVuouj     , [])
   VVAe4b = (""    , self.VV1OXj   , [])
   VVQJvS = ("Options"  , self.VVhhui , [])
   VVZyxX = ("Current Service", self.VVNWWy , [])
   VVOr9v = ("Filter"   , self.VVmfjr  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV4tj2  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindServices)
 def VVSepu(self):
  self.VVXgHo = None
  self.lastfilterUsed  = None
  self.filterObj   = CC4Wdl(self)
  VVG5ES, err = CCDvzd.VVReux(self, self.VVeZiZ)
  if VVG5ES:
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVmG3M  = ("Zap"   , self.VVuouj      , [])
   VVAe4b = (""    , self.VV1OXj    , [])
   VVZyxX = ("Current Service", self.VVNWWy  , [])
   VVQJvS = ("Options"  , self.VVK32Q , [])
   VVOr9v = ("Filter"   , self.VVDczf  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV4tj2  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindServices)
 def VVhhui(self, VVc7Yu, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CC8qau(self, VVc7Yu)
  VVd21k = []
  isMulti = VVc7Yu.VVh7FN
  if isMulti:
   refCodeList = VVc7Yu.VVnygS(3)
   if refCodeList:
    VVd21k.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    VVd21k.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    VVd21k.append(VVNCuu)
    VVd21k.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    VVd21k.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
    VVd21k.append(VVNCuu)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVd21k.append((txt1, "parentalControl_add" ))
    VVd21k.append((txt2,       ))
   else:
    VVd21k.append((txt1,       ))
    VVd21k.append((txt2, "parentalControl_remove"))
   VVd21k.append(VVNCuu)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVd21k.append((txt1, "hiddenServices_add" ))
    VVd21k.append((txt2,       ))
   else:
    VVd21k.append((txt1,       ))
    VVd21k.append((txt2, "hiddenServices_remove" ))
   VVd21k.append(VVNCuu)
  cbFncDict = { "parentalControl_add"   : BF(self.VVd244, VVc7Yu, refCode, True)
     , "parentalControl_remove"  : BF(self.VVd244, VVc7Yu, refCode, False)
     , "hiddenServices_add"   : BF(self.VVSLw3, VVc7Yu, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVSLw3, VVc7Yu, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVVryh, VVc7Yu, True)
     , "parentalControl_sel_remove" : BF(self.VVVryh, VVc7Yu, False)
     , "hiddenServices_sel_add"  : BF(self.VVW8BW, VVc7Yu, True)
     , "hiddenServices_sel_remove" : BF(self.VVW8BW, VVc7Yu, False)
     }
  VVd21k1, cbFncDict1 = CCDvzd.VVzJBT(self, VVc7Yu, servName, 3)
  VVd21k.extend(VVd21k1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVyFGx(VVd21k, cbFncDict)
 def VVK32Q(self, VVc7Yu, title, txt, colList):
  servName = colList[0]
  mSel = CC8qau(self, VVc7Yu)
  VVd21k, cbFncDict = CCDvzd.VVzJBT(self, VVc7Yu, servName, 3)
  mSel.VVyFGx(VVd21k, cbFncDict)
 @staticmethod
 def VVzJBT(SELF, VVc7Yu, servName, refCodeCol):
  tot = VVc7Yu.VVcONI()
  if tot > 0:
   sTxt = FFHqZk("%d Service%s" % (tot, FFwHmW(tot)), VVWFW6)
   VVd21k = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFFnqK(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFHqZk(servName, VVWFW6)
   VVd21k = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCDvzd.VVvU1P, SELF, VVc7Yu, refCodeCol, True)
     , "addToBouquet_one" : BF(CCDvzd.VVvU1P, SELF, VVc7Yu, refCodeCol, False)
     }
  return VVd21k, cbFncDict
 @staticmethod
 def VVvU1P(SELF, VVc7Yu, refCodeCol, isMulti):
  picker = CCB8uV(SELF, VVc7Yu, "Add to Bouquet", BF(CCDvzd.VVJNby, VVc7Yu, refCodeCol, isMulti))
 @staticmethod
 def VVJNby(VVc7Yu, refCodeCol, isMulti):
  if isMulti : refCodeList = VVc7Yu.VVnygS(refCodeCol)
  else  : refCodeList = [VVc7Yu.VVDx8h()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVd244(self, VVc7Yu, refCode, isAddToBlackList):
  VVc7Yu.VV5Wyx("Processing ...")
  FFnCJX(BF(self.VVl9w0, VVc7Yu, [refCode], isAddToBlackList))
 def VVVryh(self, VVc7Yu, isAddToBlackList):
  refCodeList = VVc7Yu.VVnygS(3)
  if not refCodeList:
   FF1uaI(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVc7Yu.VV5Wyx("Processing ...")
  FFnCJX(BF(self.VVl9w0, VVc7Yu, refCodeList, isAddToBlackList))
 def VVl9w0(self, VVc7Yu, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVp2o0, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVp2o0):
   lines = FFwiKR(VVp2o0)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVp2o0, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVc7Yu.VVh7FN
   if isMulti:
    self.VVCOyy(VVc7Yu, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVyury(VVc7Yu, refCode)
    VVc7Yu.VVSLMs()
  else:
   VVc7Yu.VVdNoE("No changes")
 def VVSLw3(self, VVc7Yu, refCode, isHide):
  title = "Change Hidden State"
  if FFqjQ5(refCode):
   VVc7Yu.VV5Wyx("Processing ...")
   ret = FFUH03(refCode, isHide)
   if ret : FFqcaP(self, BF(self.VVyury, VVc7Yu, refCode))
   else : FF1uaI(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF1uaI(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVyury(self, VVc7Yu, refCode):
  VVG5ES, err = CCDvzd.VVReux(self, self.VVvEXZ, VVvt6U=[3, [refCode], False])
  done = False
  if VVG5ES:
   data = VVG5ES[0]
   if data[3] == refCode:
    done = VVc7Yu.VV2PiO(data)
  if not done:
   self.VVZa6C(VVc7Yu, VVc7Yu.VVZMUB(), self.VVvEXZ)
  VVc7Yu.VVSLMs()
 def VVCOyy(self, VVc7Yu, totRefCodes):
  VVG5ES, err = CCDvzd.VVReux(self, self.VVvEXZ, VVvt6U=self.VVXgHo)
  VVc7Yu.VV4ZQl(VVG5ES)
  VVc7Yu.VVVUw7(False)
  VVc7Yu.VVdNoE("%d Processed" % totRefCodes)
 def VVW8BW(self, VVc7Yu, isHide):
  refCodeList = VVc7Yu.VVnygS(3)
  if not refCodeList:
   FF1uaI(self, "Nothing selected", title="Change Hidden State")
   return
  VVc7Yu.VV5Wyx("Processing ...")
  FFnCJX(BF(self.VVrOMe, VVc7Yu, refCodeList, isHide))
 def VVrOMe(self, VVc7Yu, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFUH03(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFG6ML(True)
   self.VVCOyy(VVc7Yu, len(refCodeList))
  else:
   VVc7Yu.VVdNoE("No changes")
 def VVmfjr(self, VVc7Yu, title, txt, colList):
  inFilterFnc = BF(self.VVeREk, VVc7Yu) if self.VVXgHo else None
  self.filterObj.VVmycI(1, VVc7Yu, 2, BF(self.VVQxGL, VVc7Yu), inFilterFnc=inFilterFnc)
 def VVQxGL(self, VVc7Yu, item):
  self.VVWCPS(VVc7Yu, False, item, 2, self.VVvEXZ)
 def VVeREk(self, VVc7Yu, menuInstance, item):
  self.VVWCPS(VVc7Yu, True, item, 2, self.VVvEXZ)
 def VVDczf(self, VVc7Yu, title, txt, colList):
  inFilterFnc = BF(self.VVom8b, VVc7Yu) if self.VVXgHo else None
  self.filterObj.VVmycI(2, VVc7Yu, 4, BF(self.VVwnmn, VVc7Yu), inFilterFnc=inFilterFnc)
 def VVwnmn(self, VVc7Yu, item):
  self.VVWCPS(VVc7Yu, False, item, 4, self.VVeZiZ)
 def VVom8b(self, VVc7Yu, menuInstance, item):
  self.VVWCPS(VVc7Yu, True, item, 4, self.VVeZiZ)
 def VVS8YV(self, VVc7Yu, title, txt, colList):
  inFilterFnc = BF(self.VV94P7, VVc7Yu) if self.VVXgHo else None
  self.filterObj.VVmycI(0, VVc7Yu, 4, BF(self.VVxLrc, VVc7Yu), inFilterFnc=inFilterFnc)
 def VVxLrc(self, VVc7Yu, item):
  self.VVWCPS(VVc7Yu, False, item, 4, self.VVqX6m)
 def VV94P7(self, VVc7Yu, menuInstance, item):
  self.VVWCPS(VVc7Yu, True, item, 4, self.VVqX6m)
 def VVWCPS(self, VVc7Yu, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVc7Yu.VVGBYR(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVXgHo = None
  else:
   words, asPrefix = CC4Wdl.VV610T(words)
   self.VVXgHo = [col, words, asPrefix]
  if words: FFqcaP(VVc7Yu, BF(self.VVZa6C, VVc7Yu, title, mode), clearMsg=False)
  else : FFkxeT(VVc7Yu, "Incorrect filter", 2000)
 def VVZa6C(self, VVc7Yu, title, mode):
  VVG5ES, err = CCDvzd.VVReux(self, mode, VVvt6U=self.VVXgHo, VVp4O4=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVc7Yu.VVgeCg():
    try:
     ndx = VVG5ES.index(tuple(list(map(str.strip, row))))
     lst.append(VVG5ES[ndx])
    except:
     pass
   VVG5ES = lst
  if VVG5ES:
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVc7Yu.VV4ZQl(VVG5ES, title)
  else:
   FFkxeT(VVc7Yu, "Not found!", 1500)
 def VVbD3u(self, title, VVHQsP, VVmG3M=None, VVAe4b=None, VVDti0=None, VVZyxX=None, VVQJvS=None, VVOr9v=None):
  VVZyxX = ("Current Service", self.VVNWWy, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV4tj2 = (LEFT  , LEFT  , CENTER, LEFT    )
  FF8dRU(self, None, title=title, header=header, VVHQsP=VVHQsP, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindServices)
 def VVNWWy(self, VVc7Yu, title, txt, colList):
  self.VVuCGO(VVc7Yu)
 def VVesDn(self, VVc7Yu, title, txt, colList):
  self.VVuCGO(VVc7Yu, True)
 def VVuCGO(self, VVc7Yu, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVc7Yu.VVJePS(colDict, VV3KZ2=True)
   else:
    VVc7Yu.VVKO1o(3, refCode, True)
   return
  FF1uaI(self, "Cannot read current Reference Code !")
 def VVdRrS(self, title):
  self.VVXgHo = None
  self.lastfilterUsed  = None
  self.filterObj   = CC4Wdl(self)
  VVG5ES, err = CCDvzd.VVReux(self, self.VVqX6m)
  if VVG5ES:
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVAe4b = (""    , self.VV0JyN , []      )
   VVZyxX = ("Current Service", self.VVesDn  , []      )
   VVOr9v = ("Filter"   , self.VVS8YV   , [], "Loading Filters ..." )
   VVmG3M  = ("Zap"   , self.VVZiKY      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV4tj2  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVZyxX=VVZyxX, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindServices)
 def VV0JyN(self, VVc7Yu, title, txt, colList):
  refCode  = self.VVCo16(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFdGDb(self, fncMode=CCfm5u.VVNNpI, refCode=refCode, chName=chName, text=txt)
 def VVZiKY(self, VVc7Yu, title, txt, colList):
  refCode = self.VVCo16(colList)
  FFxZcp(self, refCode)
 def VVuouj(self, VVc7Yu, title, txt, colList):
  FFxZcp(self, colList[3])
 def VVCo16(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV8VXQ(VVfEtY, mode=0):
  lines = FFwiKR(VVfEtY, encLst=["UTF-8"])
  return CCDvzd.VVVsJj(lines, mode)
 @staticmethod
 def VVVsJj(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVReux(SELF, mode, VVvt6U=None, VVp4O4=True, VVFu5u=True):
  VVfEtY, err = CCDvzd.VVk7xD(SELF, VVFu5u)
  if err:
   return None, err
  asPrefix = False
  if VVvt6U:
   filterCol = VVvt6U[0]
   filterWords = VVvt6U[1]
   asPrefix = VVvt6U[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCDvzd.VVvEXZ:
   blackList = None
   if fileExists(VVp2o0):
    blackList = FFwiKR(VVp2o0)
    if blackList:
     blackList = set(blackList)
  elif mode == CCDvzd.VVeZiZ:
   tp = CCaOWR()
  VVs3cZ, VVJsi9 = FFbUPg()
  if mode in (CCDvzd.VVRKv2, CCDvzd.VVVwsH):
   VVG5ES = {}
  else:
   VVG5ES = []
  tagFound = False
  with ioOpen(VVfEtY, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFaiFy(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCDvzd.VVqX6m:
       if sTypeInt in VVs3cZ:
        STYPE = VVJsi9[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVG5ES.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVG5ES.append(tRow)
       else:
        VVG5ES.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCDvzd.VVqKCi:
        VVG5ES.append((chName, chProv, sat, refCode))
       elif mode == CCDvzd.VVRKv2:
        VVG5ES[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCDvzd.VVVwsH:
        VVG5ES[chName] = refCode
       elif mode == CCDvzd.VVvEXZ:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVG5ES.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVG5ES.append(tRow)
        else:
         VVG5ES.append(tRow)
       elif mode == CCDvzd.VVeZiZ:
        if sTypeInt in VVs3cZ:
         STYPE = VVJsi9[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVXUK2(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVG5ES.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVG5ES.append(tRow)
        else:
         VVG5ES.append(tRow)
       elif mode == CCDvzd.VVEOtL:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVG5ES.append((chName, chProv, sat, refCode))
       elif mode == CCDvzd.VVhhhH:
        VVG5ES.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVG5ES and VVp4O4:
   FF1uaI(SELF, "No services found!")
  return VVG5ES, ""
 def VVVC8v(self, title):
  if fileExists(VVp2o0):
   lines = FFwiKR(VVp2o0)
   if lines:
    newRows = []
    VVG5ES, err = CCDvzd.VVReux(self, self.VVhhhH)
    if VVG5ES:
     lines = set(lines)
     for item in VVG5ES:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVG5ES = newRows
      VVG5ES.sort(key=lambda x: x[0].lower())
      VVAe4b = ("", self.VV1OXj, [])
      VVmG3M = ("Zap", self.VVuouj, [])
      self.VVbD3u(title, VVG5ES, VVmG3M=VVmG3M, VVAe4b=VVAe4b)
     else:
      FFX3Iv(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVG5ES)))
   else:
    FFfF2j(self, "No active Parental Control services.", FFphjG())
  else:
   FFr3Kr(self, VVp2o0)
 def VVCwaa(self, title):
  VVG5ES, err = CCDvzd.VVReux(self, self.VVEOtL)
  if VVG5ES:
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVAe4b = ("" , self.VV1OXj, [])
   VVmG3M  = ("Zap", self.VVuouj, [])
   self.VVbD3u(title, VVG5ES, VVmG3M=VVmG3M, VVAe4b=VVAe4b)
  elif err:
   pass
  else:
   FFfF2j(self, "No hidden services.", FFphjG())
 def VVn9Vu(self):
  title = "Services unused in Tuner Configuration"
  VVfEtY, err = CCDvzd.VVk7xD(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCDvzd.VV5Eon()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVuK09(str(item[0]))
    nsLst.add(ns)
  sysLst = CCDvzd.VV5MIw("1:7:")
  tpLst  = CCDvzd.VV8VXQ(VVfEtY, mode=1)
  VVG5ES = []
  for refCode, chName in sysLst:
   servID = CCDvzd.VVlShc(refCode)
   tpID = CCDvzd.VVbixs(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVG5ES.append((chName, FFkQZJ(refCode, False), refCode, servID))
  if VVG5ES:
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVQJvS = ("Options"   , BF(self.VVC08e, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VV4tj2  = (LEFT  , CENTER , LEFT   , CENTER   )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVQJvS=VVQJvS, VVW1CX="#0a001122", VVLasp="#0a001122", VVHSOH="#0a001122", VVJqmr="#00004455", VVFNoD="#0a333333", VVcwBH="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFfF2j(self, "No invalid service found !", title=title)
 def VVC08e(self, Title, VVc7Yu, title, txt, colList):
  mSel = CC8qau(self, VVc7Yu)
  isMulti = VVc7Yu.VVh7FN
  if isMulti : txt = "Remove %s Services" % FFHqZk(str(VVc7Yu.VVcONI()), VVHeSZ)
  else  : txt = "Remove : %s" % FFHqZk(VVc7Yu.VVDx8h()[0], VVHeSZ)
  VVd21k = [(txt, "del")]
  cbFncDict = {"del": BF(FFqcaP, VVc7Yu, BF(self.VV7aS1, VVc7Yu, Title))}
  mSel.VVyFGx(VVd21k, cbFncDict)
 def VV7aS1(self, VVc7Yu, title):
  VVfEtY, err = CCDvzd.VVk7xD(self, title=title)
  if err:
   return
  isMulti = VVc7Yu.VVh7FN
  skipLst = []
  if isMulti : skipLst = VVc7Yu.VVnygS(3)
  else  : skipLst = [VVc7Yu.VVDx8h()[3]]
  tpLst = CCDvzd.VV8VXQ(VVfEtY, mode=0)
  servLst = CCDvzd.VV8VXQ(VVfEtY, mode=10)
  tmpDbFile = VVfEtY + ".tmp"
  lines   = FFwiKR(VVfEtY)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFqAik("mv -f '%s' '%s'" % (tmpDbFile, VVfEtY)))
  VVG5ES = []
  for row in VVc7Yu.VVgeCg():
   if not row[3] in skipLst:
    VVG5ES.append(row)
  FFG6ML()
  FFX3Iv(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVG5ES:
   VVc7Yu.VV4ZQl(VVG5ES, title)
   VVc7Yu.VVVUw7(False)
  else:
   VVc7Yu.cancel()
 def VVaqMs(self, title):
  VVfEtY, err = CCDvzd.VVk7xD(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVHHTP(VVfEtY)
  txt = FFHqZk("Total Transponders:\n\n", VVpihg)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFHqZk("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVpihg)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFGYOC(item), satList.count(item))
  FFX3Iv(self, txt, title)
 def VVHHTP(self, VVfEtY):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVfEtY, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVScKj(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFr3Kr(self, path, title=title)
   return
  elif not CCk3u6.VVsTOj(self, path, title):
   return
  if not CCNCRq.VVdet0(self):
   return
  tree = CCDvzd.VV3zj6(self, path, title=title)
  if not tree:
   return
  VVG5ES = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFaiFy(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVG5ES.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVG5ES:
   VVG5ES.sort(key=lambda x: int(x[1]))
   VVZyxX = ("Current Satellite", BF(self.VVkjyK, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VV4tj2  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=25, VV0rqo=1, VVZyxX=VVZyxX, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF1uaI(self, "No data found !", title=title)
 def VVkjyK(self, satCol, VVc7Yu, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  sat = FFkQZJ(refCode, False)
  for ndx, row in enumerate(VVc7Yu.VVgeCg()):
   if sat == row[satCol].strip():
    VVc7Yu.VVQ2AR(ndx)
    break
  else:
   FFkxeT(VVc7Yu, "No listed !", 1500)
 def FFqcaP_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FF1uaI(self, "No Satellites found !")
   return
  usedSats = CCDvzd.VV5Eon()
  VVG5ES = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVG5ES.append((sat[1], posTxt, FFaiFy(sat[0]), tuners, str(posVal)))
  if VVG5ES:
   VVHSOH = "#11222222"
   VVG5ES.sort(key=lambda x: int(x[1]))
   VVZyxX = ("Current Satellite" , BF(self.VVkjyK, 2) , [])
   VVQJvS = ("Options"   , self.VVuTLZ  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VV4tj2  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVW1CX=VVHSOH, VVLasp=VVHSOH, VVHSOH=VVHSOH, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FF1uaI(self, "No data found !")
 def VVuTLZ(self, VVc7Yu, title, txt, colList):
  mSel = CC8qau(self, VVc7Yu)
  isMulti = VVc7Yu.VVh7FN
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFHqZk(str(VVc7Yu.VVcONI()), VVHeSZ)
  else  : txt = "Remove ALL Services on : %s" % FFHqZk(VVc7Yu.VVDx8h()[0], VVHeSZ)
  VVd21k = []
  VVd21k.append((txt, "deleteSat"))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Delete Empty Bouquets", "VVkSfu"))
  cbFncDict = { "deleteSat"   : BF(FFqcaP, VVc7Yu, BF(self.VVzLrR, VVc7Yu))
     , "VVkSfu" : BF(self.VVkSfu, VVc7Yu)
     }
  mSel.VVyFGx(VVd21k, cbFncDict)
 def VVzLrR(self, VVc7Yu):
  posLst = []
  isMulti = VVc7Yu.VVh7FN
  posLst = []
  if isMulti : posLst = VVc7Yu.VVnygS(4)
  else  : posLst = [VVc7Yu.VVDx8h()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVuK09(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVmVDC(nsLst)
  FFG6ML(True)
  FFX3Iv(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVkSfu(self, winObj):
  title = "Delete Empty Bouquets"
  FFWV4g(self, BF(FFqcaP, winObj, BF(self.VVp8At, title)), "Delete bouquets with no services ?", title=title)
 def VVp8At(self, title):
  bList = CCB8uV.VVVU4c()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCB8uV.VVSN7x(bRef)
    bPath = VVmqmq + bFile
    FFC2Q5(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVmqmq + fil
     if fileExists(path):
      lines = FFwiKR(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFG6ML(True)
  if bNames: txt = "%s\n\n%s" % (FFHqZk("Deleted Bouquets:", VVWFW6), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFX3Iv(self, txt, title=title)
 def VVuK09(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVmVDC(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVmqmq)
  for srcF in files:
   if fileExists(srcF):
    lines = FFwiKR(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFnNb7(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVEVJ5(self, title)   : self.VV4v3C(title, True)
 def VVpXSN(self, title) : self.VV4v3C(title, False)
 def VV4v3C(self, title, isWithPIcons):
  piconsPath = CCodIm.VVt98d()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCodIm.VVTSTs(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVG5ES, err = CCDvzd.VVReux(self, self.VVhhhH)
    if VVG5ES:
     channels = []
     for (chName, chProv, sat, refCode) in VVG5ES:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFPJ1E(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVG5ES)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV0iDg(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV0iDg("PIcons Path"  , piconsPath)
     txt += VV0iDg("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV0iDg("Total services" , totalServices)
     txt += VV0iDg("With PIcons"  , totalWithPIcons)
     txt += VV0iDg("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFX3Iv(self, txt)
     else:
      VVAe4b     = (""      , self.VV1OXj , [])
      if isWithPIcons : VVOr9v = ("Export Current PIcon", self.VVUUIa  , [])
      else   : VVOr9v = None
      VVQJvS     = ("Statistics", FFX3Iv, [txt])
      VVmG3M      = ("Zap", self.VVuouj, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVbD3u(title, channels, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVQJvS=VVQJvS, VVOr9v=VVOr9v)
   else:
    FF1uaI(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF1uaI(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VV1OXj(self, VVc7Yu, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFdGDb(self, fncMode=CCfm5u.VVNNpI, refCode=refCode, chName=chName, text=txt)
 def VVUUIa(self, VVc7Yu, title, txt, colList):
  png, path = CCodIm.VV39mx(colList[3], colList[0])
  if path:
   CCodIm.VVZY35(self, png, path)
 @staticmethod
 def VVwWfa():
  VVfEtY  = "%slamedb" % VVmqmq
  VV7mvy = "%slamedb.disabled" % VVmqmq
  return VVfEtY, VV7mvy
 @staticmethod
 def VVluJ5():
  VVJvwr  = "%slamedb5" % VVmqmq
  VVOcdR = "%slamedb5.disabled" % VVmqmq
  return VVJvwr, VVOcdR
 def VVK8ix(self, isEnable):
  VVfEtY, VV7mvy = CCDvzd.VVwWfa()
  if isEnable and not fileExists(VV7mvy):
   FFfF2j(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVfEtY):
   FF1uaI(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFWV4g(self, BF(self.VVIoxr, isEnable), "%s Hidden Channels ?" % word)
 def VVIoxr(self, isEnable):
  VVfEtY , VV7mvy = CCDvzd.VVwWfa()
  VVJvwr, VVOcdR = CCDvzd.VVluJ5()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV7mvy, VV7mvy, VVfEtY)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVOcdR, VVOcdR, VVJvwr)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVfEtY  , VVfEtY , VV7mvy)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVJvwr , VVJvwr, VVOcdR)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV7mvy, VVfEtY )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVOcdR, VVJvwr)
  res = os.system(cmd)
  FFG6ML()
  if res == 0 : FFfF2j(self, "Hidden List %s" % word)
  else  : FF1uaI(self, "Error while restoring:\n\n%s" % fileName)
 def VVeYyJ(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVmqmq
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVmqmq
  FFXjds(self, cmd)
 def VVZDvd(self):
  VVfEtY, err = CCDvzd.VVk7xD(self)
  if err:
   return
  tmpFile = "/tmp/ajpanel_lamedb"
  FFC2Q5(tmpFile)
  totChan = totRemoved = 0
  lines = FFwiKR(VVfEtY, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFWV4g(self, BF(FFqcaP, self, BF(self.VVAFZK, tmpFile, VVfEtY, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFwHmW(totRemoved), totChan, FFwHmW(totChan))
      , callBack_No=BF(self.VVKIX8, tmpFile))
  else:
   FFX3Iv(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVAFZK(self, tmpFile, VVfEtY, totRemoved, totChan):
  os.system(FFqAik("mv -f '%s' '%s'" % (tmpFile, VVfEtY)))
  FFG6ML()
  FFX3Iv(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVKIX8(self, tmpFile):
  FFC2Q5(tmpFile)
 @staticmethod
 def VVk7xD(SELF, VVFu5u=True, title=""):
  VVfEtY, VV7mvy = CCDvzd.VVwWfa()
  if   not fileExists(VVfEtY)       : err = "File not found !\n\n%s" % VVfEtY
  elif not CCk3u6.VVsTOj(SELF, VVfEtY) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVFu5u:
   FF1uaI(SELF, err, title=title)
  return VVfEtY, err
 @staticmethod
 def VVbixs(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVlShc(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VV5MIw(servTypes):
  VVfpFz  = eServiceCenter.getInstance()
  VVmxE7   = '%s ORDER BY name' % servTypes
  VVbAWa   = eServiceReference(VVmxE7)
  VVXTXc = VVfpFz.list(VVbAWa)
  if VVXTXc: return VVXTXc.getContent("CN", False)
  else     : return []
 @staticmethod
 def VV5Eon():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCfm5u(Screen):
 VVXXAh  = 0
 VVMSfA   = 1
 VVRV7u   = 2
 VVNNpI    = 3
 VVMKs8    = 4
 VVaRGG   = 5
 VV9zVJ   = 6
 VVtlGR    = 7
 VVZf2X   = 8
 VVIQyr   = 9
 VVAw6j   = 10
 VVTvCn   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FF1pMw(VV16CN, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVXXAh)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFHqZk("%s\n", VV2vWn) % VVbL9B
  self.picViewer  = None
  FFrOoX(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVaHKy })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self["myLabel"].VVuWLn(outputFileToSave="chann_info")
  if   self.fncMode == self.VVXXAh : fnc = self.VVe19s
  elif self.fncMode == self.VVMSfA  : fnc = self.VVe19s
  elif self.fncMode == self.VVRV7u  : fnc = self.VVe19s
  elif self.fncMode == self.VVNNpI  : fnc = self.VVPr2l
  elif self.fncMode == self.VVMKs8  : fnc = self.VV9kDK
  elif self.fncMode == self.VVaRGG  : fnc = self.VVa0rL
  elif self.fncMode == self.VV9zVJ  : fnc = self.VVJ1h8
  elif self.fncMode == self.VVtlGR  : fnc = self.VVLQY7
  elif self.fncMode == self.VVZf2X  : fnc = self.VVTthY
  elif self.fncMode == self.VVIQyr : fnc = self.VVQoas
  elif self.fncMode == self.VVAw6j  : fnc = self.VVYTVf
  elif self.fncMode == self.VVTvCn : fnc = self.VVsTF7
  self["myLabel"].setText("\n   Reading Info ...")
  FFnCJX(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVobAr()
 def VVJkC1(self, err):
  self["myLabel"].setText(err)
  FFrI2P(self["myTitle"], "#22200000")
  FFrI2P(self["myBody"], "#22200000")
  self["myLabel"].VVQG1v("#22200000")
  self["myLabel"].VVeYTy()
 def VVe19s(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  self.refCode = refCode
  self.VVlm6H(chName)
 def VVPr2l(self):
  self.VVlm6H(self.chName)
 def VV9kDK(self):
  self.VVlm6H(self.chName)
 def VVa0rL(self):
  self.VVlm6H(self.chName)
 def VVJ1h8(self):
  self.VVlm6H("Picon Info")
 def VVLQY7(self):
  self.VVlm6H(self.chName)
 def VVTthY(self):
  self.VVlm6H(self.chName)
 def VVQoas(self):
  self.VVlm6H(self.chName)
 def VVYTVf(self):
  self.chUrl = self.refCode + self.callingSELF.VVVW0k(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVlm6H(self.chName)
 def VVsTF7(self):
  self.VVlm6H(self.chName)
 def VVlm6H(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF4ETG(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVug4g(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFHqZk(self.VVndQC(tUrl), VVekE1)
  if not self.epg:
   epg = CCTkbp.VVlJ4H(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVwFit(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCodIm.VV39mx(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVwFit(path)
  self.VVwuq9()
  self.VVeGpZ()
  self["myLabel"].setText(self.text or "   No active service", VVXwlZ=VVo3oH)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVeYTy(minHeight=minH)
 def VVeGpZ(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFkOAA(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVzCx6(FFeHlW(url))
  if epg:
   self.text += "\n" + FF8jk7("EPG:", VVWFW6) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVwuq9()
 def VVwuq9(self):
  if not self.piconShown and self.picUrl:
   path, err = FFR3XR(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVwFit(path)
    if self.piconShown and self.refCode:
     self.VVbdYO(path, self.refCode)
 def VVbdYO(self, path, refCode):
  if path and fileExists(path) and os.system(FFqAik("which ffmpeg")) == 0:
   pPath = CCodIm.VVt98d()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCfm5u.VVMfHN(path)
    cmd += FFqAik("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVwFit(self, path):
  if path and fileExists(path):
   err, w, h = self.VVFDgb(path)
   if not err:
    if h > w:
     self.VVmUB9(self["myPicF"], w, h, True)
     self.VVmUB9(self["myPicB"], w, h, False)
     self.VVmUB9(self["myPic"] , w, h, False)
   self.picViewer = CCd6Xx.VVztKX(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVmUB9(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVFDgb(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFlcvI(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVug4g(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFHqZk(chName, VVWFW6)
  txt += self.VV0iDg(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFHqZk(state, VV0kWR)
   txt += "State\t: %s\n" % state
  w = FF7qij(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF7qij(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVZtXd(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV0iDg(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV0iDg(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV0iDg(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVhbAp()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV4951()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCfm5u.VVqZnS(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFHqZk("Stream-Relay" if FFqc3z(decodedUrl) else "IPTV", VVpihg)
   txt += self.VVZRpK(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVNJlk(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCaOWR()
    tpTxt, namespace = tp.VVhwrs(refCode)
    if tpTxt:
     txt += FFHqZk("Tuner:\n", VVWFW6)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFHqZk("Codes:\n", VVWFW6)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV0iDg(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV0iDg(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV0iDg(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV0iDg(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV0iDg(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV0iDg(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV0iDg(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV0iDg(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV0iDg(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVZtXd(info):
  if info:
   aspect = FF7qij(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV0iDg(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF7qij(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVP3JF(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVP3JF(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVhbAp(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VV4951(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVNJlk(self, refCode, iptvRef, chName):
  refCode = FFFxlH(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFnMVE(VVmqmq + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFnMVE(VVmqmq + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVHQsP = []
  tmpRefCode = FFeHlW(refCode)
  for item in fList:
   path = VVmqmq + item
   if fileExists(path):
    txt = FFnMVE(path)
    if tmpRefCode in FFeHlW(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVHQsP.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVHQsP:
   if len(VVHQsP) == 1:
    txt += "%s\t: %s%s\n" % (FFHqZk("Bouquet", VVWFW6), VVHQsP[0][0], " (%s)" % VVHQsP[0][1] if VVttXz else "")
   else:
    txt += FFHqZk("Bouquets:\n", VVWFW6)
    for ndx, item in enumerate(VVHQsP):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVttXz else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVZRpK(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFowN4(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCTQO7()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVk5qZ(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFHqZk("URL:", VVpihg) + "\n%s\n" % self.VVndQC(decodedUrl)
  else:
   txt = "\n"
   txt += FFHqZk("Reference:", VVpihg) + "\n%s\n" % refCode
  return txt
 def VVndQC(self, url):
  if not FFqc3z(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVCvlJ:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFeHlW(url)
 def VVzCx6(self, decodedUrl):
  if not FFLsnX():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCHF2n.VVPQqT(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCHF2n.VVl3JC(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVKHGd(tDict)
   elif uType == "movie" : epg, picUrl = CCfm5u.VVtUkB(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVKHGd(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCHF2n.VVEbNz(item, "title"    , is_base64=True )
     lang    = CCHF2n.VVEbNz(item, "lang"         ).upper()
     description   = CCHF2n.VVEbNz(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCHF2n.VVEbNz(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCHF2n.VVEbNz(item, "start_timestamp"      )
     stop_timestamp  = CCHF2n.VVEbNz(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCHF2n.VVEbNz(item, "stop_timestamp"       )
     now_playing   = CCHF2n.VVEbNz(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVBNow, ""
      else     : color, txt = VV0kWR , "    (CURRENT EVENT)"
      epg += FFHqZk("_" * 32 + "\n", VV2vWn)
      epg += FFHqZk("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFHqZk(description, VVekE1)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = CCTkbp.VVrWAC(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVtUkB(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCHF2n.VVEbNz(item, "movie_image" )
    genre  = CCHF2n.VVEbNz(item, "genre"   ) or "-"
    plot  = CCHF2n.VVEbNz(item, "plot"   ) or "-"
    cast  = CCHF2n.VVEbNz(item, "cast"   ) or "-"
    rating  = CCHF2n.VVEbNz(item, "rating"   ) or "-"
    director = CCHF2n.VVEbNz(item, "director"  ) or "-"
    releasedate = CCHF2n.VVEbNz(item, "releasedate" ) or "-"
    duration = CCHF2n.VVEbNz(item, "duration"  ) or "-"
    try:
     lang = CCHF2n.VVEbNz(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFHqZk(cast, VVekE1)
    epg += "Plot:\n%s"    % FFHqZk(plot, VVekE1)
   except:
    pass
  return epg, movie_image
 def VVaHKy(self):
  if VVCvlJ:
   def VV0iDg(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV0iDg(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCTQO7()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVk5qZ(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV0iDg(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVbL9B, txt))
   FFkxeT(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVUXJW(SELF):
  if not CCr3lG.VV0eGg(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF)
  err = url =  fSize = resumable = ""
  if FFcmN9(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCTQO7.VVnvRd(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCTQO7.VV4LO2(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FF1uaI(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCk3u6.VVeQ5q(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFHqZk(" (M3U/M3U8 File)", VVekE1)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCEVEE.VVo07t(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV8Y2s(subj, val):
   return "%s\n%s\n\n" % (FFHqZk("%s:" % subj, VVWFW6), val)
  title = "File Size"
  txt  = VV8Y2s(title , fSize or "?")
  txt += VV8Y2s("Name" , chName)
  txt += VV8Y2s("URL" , url)
  if resumable: txt += VV8Y2s("Supports Download-Resume", resumable)
  if err  : txt += FFHqZk("Error:\n", VV0kWR) + err
  FFX3Iv(SELF, txt, title=title)
 @staticmethod
 def VVqZnS(SELF):
  fPath, fDir, fName = CCk3u6.VVURIr(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVMfHN(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVZ0vT(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCodIm.VVt98d() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVzkt5(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFkOAA(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFnNb7(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCTQO7():
 def __init__(self):
  self.VVinJa   = ""
  self.VV8nIm    = ""
  self.VVswNA   = ""
  self.VVnuLl = ""
  self.VVciZL  = ""
  self.VVpnkz = 0
  self.VVncsU    = ""
  self.VVKGlz   = "#f#11ffffaa#User"
  self.VVTXPD   = "#f#11aaffff#Server"
 def VVSecc(self, url, mac, ph1="", VV3KZ2=True):
  self.VVinJa   = ""
  self.VV8nIm    = ""
  self.VVswNA   = ""
  self.VVnuLl = ""
  self.VVciZL  = ""
  self.VVpnkz = 0
  self.VVncsU    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VV1tMD(url)
  if not host:
   if VV3KZ2:
    self.VV1kxV("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVJaoV(mac)
  if not host:
   if VV3KZ2:
    self.VV1kxV("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVinJa = host
  self.VV8nIm  = mac
  return True
 def VV1tMD(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVJaoV(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVCYUc(self):
  res, err = self.VV5lHh(self.VVYQjq())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVinJa:
   self.VVinJa = self.VVinJa.replace(urlPath, "")
   res, err = self.VV5lHh(self.VVYQjq())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCHF2n.VVEbNz(tDict["js"], "token")
    rand  = CCHF2n.VVEbNz(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVsmYK(self, VV3KZ2=True):
  if not self.VVncsU:
   self.VVncsU = self.VV08nP()
  err = blkMsg = FFfF2jTxt = ""
  try:
   token, rand, err = self.VVCYUc()
   if token:
    self.VVswNA = token
    self.VVnuLl = rand
    if rand:
     self.VVpnkz = 2
    prof, retTxt = self.VVkz7D(True)
    if prof:
     self.VVciZL = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVpnkz = 3
      prof, retTxt = self.VVkz7D(False)
      if retTxt:
       self.VVciZL = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFfF2jTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFfF2jTxt: tErr += "\n%s" % FFfF2jTxt
  if VV3KZ2:
   self.VV1kxV(tErr)
  return "", "", tErr
 def VV08nP(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVinJa, headers=CCTQO7.VV4LO2(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVkz7D(self, capMac):
  res, err = self.VV5lHh(self.VVWZK1(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCHF2n.VVEbNz(tDict["js"], "block_%s" % word)
    FFfF2jTxt = CCHF2n.VVEbNz(tDict["js"], word)
    return tDict, FFfF2jTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVWZK1(self, capMac):
  param = ""
  if self.VVciZL or self.VVnuLl:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VV8nIm.upper() if capMac else self.VV8nIm.lower(), self.VVnuLl))
  return self.VVLy0S() + "type=stb&action=get_profile" + param
 exec(FFqnL0("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVzQwD(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVL9gk()
  if len(rows) < 10:
   rows = self.VVJd43()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVinJa ))
   rows.append(("MAC (from URL)" , self.VV8nIm ))
   rows.append(("Token"   , self.VVswNA ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVKGlz  , "MAC" , self.VV8nIm ))
   rows.append(("2", self.VVTXPD, "Host" , self.VVinJa ))
   rows.append(("2", self.VVTXPD, "Token" , self.VVswNA ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVWhWq(self, isPhp=True, VV3KZ2=False):
  token, profile, tErr = self.VVsmYK(VV3KZ2)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVOBCq()
  res, err = self.VV5lHh(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCHF2n.VVEbNz(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFENC4(span.group(2))
     pass1 = FFENC4(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVL9gk(self):
  m3u_Url, host, user1, pass1, err = self.VVWhWq()
  rows = []
  if m3u_Url:
   res, err = self.VV5lHh(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFeWDt(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVKGlz, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFeWDt(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVTXPD, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVJd43(self):
  token, profile, tErr = self.VVsmYK()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFsa5D(val): val = FFqnL0(val.decode("UTF-8"))
     else     : val = self.VV8nIm
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFeWDt(int(parts[1]))
      if parts[2] : ends = FFeWDt(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFeWDt(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVVW0k(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVsmYK(VV3KZ2=False)
  if not token:
   return ""
  crLinkUrl = self.VVDRub(mode, chCm, epNum, epId)
  res, err = self.VV5lHh(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCHF2n.VVEbNz(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVLy0S(self):
  return self.VVinJa + (self.VVncsU or "/server/load.php") + "?"
 def VVYQjq(self):
  return self.VVLy0S() + "type=stb&action=handshake&token=&mac=%s" % self.VV8nIm
 def VV0ZdT(self, mode):
  url = self.VVLy0S() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVs3B0(self, catID):
  return self.VVLy0S() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV3Khw(self, mode, catID, page):
  url = self.VVLy0S() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVIF3c(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVLy0S() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVwKDO(self, mode, catID):
  return self.VVLy0S() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVDRub(self, mode, chCm, serCode, serId):
  url = self.VVLy0S() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVOBCq(self):
  return self.VVLy0S() + "type=itv&action=create_link"
 def VVvs8A(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVKGWh(catID, stID, chNum)
  query = self.VViFDP(mode, self.VVncsU[1:2], FFNINN(host), FFNINN(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VViFDP(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVk5qZ(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VViFDP(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFqnL0(host)
  mac   = FFqnL0(mac)
  valid = False
  if self.VV1tMD(playHost) and self.VV1tMD(host) and self.VV1tMD(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV5lHh(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCTQO7.VV4LO2()
   if self.VVswNA:
    headers["Authorization"] = "Bearer %s" % self.VVswNA
   if useCookies : cookies = {"mac": self.VV8nIm, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVYV6p(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCTQO7.VV4LO2(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VV4LO2():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVrwjS(host, mac, tType, action, keysList=None):
  myPortal = CCTQO7()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVSecc(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVsmYK(VV3KZ2=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VV5lHh(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVUbbz(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVUbbz(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VV1kxV(self, err, title="Portal Browser"):
  FF1uaI(self, str(err), title=title)
 def VVD4Dd(self, mode):
  if   mode in ("itv"  , CCHF2n.VVAupb , CCHF2n.VV3Rn0)  : return "Live"
  elif mode in ("vod"  , CCHF2n.VVMlZk , CCHF2n.VVnbf9)  : return "VOD"
  elif mode in ("series" , CCHF2n.VV1Yih , CCHF2n.VVseBO) : return "Series"
  else                          : return "IPTV"
 def VVwrOF(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVD4Dd(mode), FFHqZk(searchName, VVekE1))
 def VVaLqd(self, catchup=False):
  VVd21k = []
  VVd21k.append(("Live"    , "live"  ))
  VVd21k.append(("VOD"    , "vod"   ))
  VVd21k.append(("Series"   , "series"  ))
  if catchup:
   VVd21k.append(VVNCuu)
   VVd21k.append(("Catch-up TV" , "catchup"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Account Info." , "accountInfo" ))
  return VVd21k
 @staticmethod
 def VV18py(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCTQO7()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVk5qZ(decodedUrl)
  if valid:
   ok = p.VVSecc(host, mac, ph1, VV3KZ2=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVWhWq(isPhp=False, VV3KZ2=False)
    streamId = CCTQO7.VVLGvE(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVLGvE(decodedUrl):
  p = CCTQO7()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVk5qZ(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFqnL0(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVnvRd(decodedUrl):
  p = CCTQO7()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVk5qZ(decodedUrl)
  if valid:
   if CCTQO7.VVKCCq(chCm):
    return FFeHlW(chCm)
   else:
    ok = p.VVSecc(host, mac, ph1, VV3KZ2=False)
    if ok:
     try:
      chUrl = p.VVVW0k(mode, chCm, epNum, epId)
      return FFeHlW(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVKCCq(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCV4IB(CCTQO7):
 def __init__(self):
  CCTQO7.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVjB8B(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVk5qZ(decodedUrl)
  if valid:
   if self.VVSecc(host, mac, ph1, VV3KZ2=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVHY8Q(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVVW0k(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCTQO7.VVKCCq(self.chCm):
   chUrl = FFeHlW(self.chCm)
   chUrl = FFENC4(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVYGhp(chUrl)
  bPath = CCB8uV.VV7XjX()
  if newIptvRef:
   if passedSELF:
    FFxZcp(passedSELF, newIptvRef, VVY2Q7=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFxZcp(self, newIptvRef, VVY2Q7=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVgB8q(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVYGhp(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVgB8q(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFwiKR(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFG6ML()
class CCZuyK(CCV4IB):
 def __init__(self, passedSession):
  CCV4IB.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVE36p(VVRklX  )
  Main_Menu.VVE36p(VVIBYu)
  Main_Menu.VVE36p(VVDlhL  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVu9VP, iPlayableService.evEOF: self.VV868U, iPlayableService.evEnd: self.VVGPFF})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVY3JN)
  except:
   self.timer2.callback.append(self.VVY3JN)
  self.timer2.start(3000, False)
  self.VVY3JN()
 def VVY3JN(self):
  if not CFG.downloadMonitor.getValue():
   self.VVndi9()
   return
  lst = CCEVEE.VVanPw()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FF2oRJ(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCEVEE.VVL8I0(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCrCKC, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFf3WT(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVndi9()
 def VVndi9(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVu9VP(self):
  self.startTime = iTime()
 def VV868U(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self.passedSession, isFromSession=True)
    if iptvRef and not FFcmN9(decodedUrl):
     self.isFromEOF = True
     CC6BDM(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVGPFF(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVdIYX)
  except:
   self.timer1.callback.append(self.VVdIYX)
  self.timer1.start(100, True)
 def VVdIYX(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVjB8B(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCqzRz.VVRX23:
       self.isFromEOF = False
       self.VVHY8Q(self.passedSession, isFromSession=True)
class CCAOao():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVJBfo(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCHF2n.VVvpjr(name):
   return CCHF2n.VViOIM(name)
  name = self.VV4UGB(name)
  return name.strip() or name
 def VV4UGB(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VVHGDn(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VV4UGB(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV9VQZ(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVPCQa(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVD1ic(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCr3lG(CCTQO7):
 def __init__(self):
  CCTQO7.__init__(self)
 def VVtC3n(self):
  if CCr3lG.VV0eGg(self):
   FFqcaP(self, BF(self.VVRtds, 2), title="Searching ...")
 def VVbyYs(self, winSession, url, mac):
  self.curUrl = url
  if CCr3lG.VV0eGg(self):
   if self.VVSecc(url, mac):
    FFqcaP(winSession, self.VV0eaL, title="Checking Server ...")
   else:
    FF1uaI(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVx4tQ(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCtiVE.VVLoBC(path, self)
   if enc == -1:
    return
   self.session.open(CC8PiB, barTheme=CC8PiB.VVchq1
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVy3Hy, path, enc)
       , VVXlAY = BF(self.VVfnHm, menuInstance, path))
 def VVy3Hy(self, path, enc, VVTb2z):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVTb2z.VViTTm(totLines)
  VVTb2z.VVc1Ja = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVTb2z or VVTb2z.isCancelled:
     return
    VVTb2z.VV3VHc(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VV1tMD(url)
     mac  = self.VVJaoV(mac)
     if host and mac and VVTb2z:
      VVTb2z.VVc1Ja.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VV1tMD(url)
      mac  = self.VVJaoV(mac)
      if host and mac and not mac.startswith("AC") and VVTb2z:
       VVTb2z.VVc1Ja.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVfnHm(self, menuInstance, path, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVc1Ja:
   VVDti0  = ("Home Menu"  , FFi0ku            , [])
   VVQJvS = ("Edit File"  , BF(self.VVqdeS, path)       , [])
   VVZyxX = ("M3U Options" , self.VVaafu         , [])
   VVOr9v = ("Check & Filter" , BF(self.VV41Wv, menuInstance, path), [])
   VVmG3M  = ("Select"   , self.VVyaoQ      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV4tj2  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVc7Yu = FF8dRU(self, None, title=title, header=header, VVHQsP=VVc1Ja, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVW1CX="#0a001122", VVLasp="#0a001122", VVHSOH="#0a001122", VVJqmr="#00004455", VVFNoD="#0a333333", VVcwBH="#11331100", VVDYPP=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VV5vtH:
    FFkxeT(VVc7Yu, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV5vtH:
    FF1uaI(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVaafu(self, VVc7Yu, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVd21k = []
  VVd21k.append(("Browse as M3U"  , "browse"))
  VVd21k.append(("Download M3U File" , "downld"))
  FFxMT2(self, BF(self.VVr64O, VVc7Yu, host, mac), title=title, VVd21k=VVd21k, width=600, VVL2h3=True)
 def VVr64O(self, VVc7Yu, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFqcaP(VVc7Yu, BF(self.VVvPHZ, VVc7Yu, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFWV4g(self, BF(FFqcaP, VVc7Yu, BF(self.VVvPHZ, VVc7Yu, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVvPHZ(self, VVc7Yu, title, host, mac, item):
  p = CCTQO7()
  m3u_Url = ""
  ok = p.VVSecc(host, mac, VV3KZ2=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVWhWq(VV3KZ2=False)
  if m3u_Url:
   if   item == "browse": self.VVty48(title, m3u_Url)
   elif item == "downld": self.VVbjIj(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FF1uaI(self, err or "No response from Server !", title=title)
 def VVyaoQ(self, VVc7Yu, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVbyYs(VVc7Yu, url, mac)
 def VVqdeS(self, path, VVc7Yu, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCwq37(self, path, VVXlAY=BF(self.VVrjrT, VVc7Yu), curRowNum=rowNum)
  else    : FFr3Kr(self, path)
 def VV41Wv(self, menuInstance, path, VVc7Yu, title, txt, colList):
  self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVIc7L, VVc7Yu)
      , VVXlAY = BF(self.VVQJ95, menuInstance, VVc7Yu, path))
 def VVIc7L(self, VVc7Yu, VVTb2z):
  VVTb2z.VVc1Ja = []
  VVTb2z.VViTTm(VVc7Yu.VVpm2D())
  for row in VVc7Yu.VVgeCg():
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VV3VHc(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVSecc(host, mac, VV3KZ2=False):
    token, profile, tErr = self.VVsmYK(VV3KZ2=False)
    if token and VVTb2z and not VVTb2z.isCancelled:
     res, err = self.VV5lHh(self.VV0ZdT("itv"))
     if res and VVTb2z and not VVTb2z.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVTb2z.VV3VHc(0, showFound=True)
       VVTb2z.VVc1Ja.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVTb2z:
    return
 def VVQJ95(self, menuInstance, VVc7Yu, path, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if VVc1Ja:
   VVc7Yu.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FF5Vj3())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVc1Ja:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFHqZk(str(threadCounter), VV0kWR)
    skipped = FFHqZk(str(threadTotal - threadCounter), VV0kWR)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVc1Ja)
   txt += "%s\n\n%s"    %  (FFHqZk("Result File:", VVWFW6), newPath)
   FFX3Iv(self, txt, title="Accessible Portals")
  elif VV5vtH:
   FF1uaI(self, "No portal access found !", title="Accessible Portals")
 def VVYJBu(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFqnL0(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VV0eaL(self):
  token, profile, tErr = self.VVsmYK()
  if token:
   dots = "." * self.VVpnkz
   dots += "+" if self.VVncsU[1:2] == "p" else ""
   VVd21k  = self.VVaLqd()
   OKBtnFnc = self.VVAwNe
   infoBtnFnc = self.VV8g0K
   VVZms0 = ("Home Menu", FFi0ku)
   VVHLqw= ("Add to Menu", BF(CCHF2n.VVUX7I, self, True, self.VVinJa + "\t" + self.VV8nIm))
   VVldmG = ("Bookmark Server", BF(CCHF2n.VVEAtL, self, True, self.VVinJa + "\t" + self.VV8nIm))
   FFxMT2(self, None, title="Portal Resources (MAC=%s) %s" % (self.VV8nIm, dots), VVd21k=VVd21k, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVZms0=VVZms0, VVHLqw=VVHLqw, VVldmG=VVldmG)
 def VVAwNe(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFqcaP(menuInstance, BF(self.VV5LYo, mode), title="Reading Categories ...")
   else : FFqcaP(menuInstance, BF(self.VV1VPm, menuInstance, title), title="Reading Account ...")
 def VV1VPm(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVzQwD(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV8nIm)
  VVDti0  = ("Home Menu" , FFi0ku         , [])
  VVZyxX  = None
  if VVCvlJ:
   VVZyxX = ("Get JS"  , BF(self.VVxHVG, self.VVinJa), [])
  if totCols == 2:
   VVOr9v = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVOr9v = ("More Info.", BF(self.VVdfYR, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FF8dRU(self, None, title=title, width=1200, header=header, VVHQsP=rows, VVje1O=widths, VVlvFD=26, VVDti0=VVDti0, VVZyxX=VVZyxX, VVOr9v=VVOr9v, VVW1CX="#0a00292B", VVLasp="#0a002126", VVHSOH="#0a002126", VVJqmr="#00000000", searchCol=searchCol)
 def VVxHVG(self, url, VVc7Yu, title, txt, colList):
  FFqcaP(VVc7Yu, BF(self.VVY63B, url), title="Getting JS ...")
 def VVY63B(self, url):
  txt = "// Host\t: %s\n" % url
  verOK = False
  ver, err = self.VVynsl("%s/c/version.js" % url)
  if err:
   txt += err
  else:
   txt += "// Version\t: %s\n\n" % ver
   js, err = self.VVynsl("%s/c/xpcom.common.js" % url)
   if err: txt += err
   else  : txt += "%s" % js
  FFX3Iv(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVynsl(self, url):
  res, err = self.VV5lHh(url)
  if err:
   return "", "Error: %s" % err
  else:
   cont = res.headers.get("content-type")
   if "javascript" in cont : return res.text, ""
   else     : return "", "\nError: content-type = %s" % cont
 def VVdfYR(self, menuInstance, VVc7Yu, title, txt, colList):
  VVc7Yu.cancel()
  FFqcaP(menuInstance, BF(self.VV1VPm, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV5LYo(self, mode):
  token, profile, tErr = self.VVsmYK()
  if not token:
   return
  res, err = self.VV5lHh(self.VV0ZdT(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VV9ibt = CCAOao()
     chList = tDict["js"]
     for item in chList:
      Id   = CCHF2n.VVEbNz(item, "id"       )
      Title  = CCHF2n.VVEbNz(item, "title"      )
      censored = CCHF2n.VVEbNz(item, "censored"     )
      Title = VV9ibt.VV9VQZ(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVttXz:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVD4Dd(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km(mode)
   mName = self.VVD4Dd(mode)
   VVmG3M   = ("Show List"   , BF(self.VVTdZQ, mode)   , [])
   VVDti0  = ("Home Menu"   , FFi0ku        , [])
   if mode in ("vod", "series"):
    VVQJvS = ("Find in %s" % mName , BF(self.VVYD65, mode, False), [])
    VVOr9v = ("Find in Selected" , BF(self.VVYD65, mode, True) , [])
   else:
    VVQJvS = None
    VVOr9v = None
   header   = None
   widths   = (100   , 0  )
   FF8dRU(self, None, title=title, width=1200, header=header, VVHQsP=list, VVje1O=widths, VVlvFD=30, VVDti0=VVDti0, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVmG3M=VVmG3M, VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVHSOH, VVJqmr=VVJqmr, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVciZL:
     txt += "\n\n( %s )" % self.VVciZL
   else:
    txt = "Could not get Categories from server!"
   FF1uaI(self, txt, title=title)
 def VVXQj6(self, mode, VVc7Yu, title, txt, colList):
  FFqcaP(VVc7Yu, BF(self.VV4sCj, mode, VVc7Yu, title, txt, colList), title="Downloading ...")
 def VV4sCj(self, mode, VVc7Yu, title, txt, colList):
  token, profile, tErr = self.VVsmYK()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV5lHh(self.VVs3B0(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCHF2n.VVEbNz(item, "id"    )
      actors   = CCHF2n.VVEbNz(item, "actors"   )
      added   = CCHF2n.VVEbNz(item, "added"   )
      age    = CCHF2n.VVEbNz(item, "age"   )
      category_id  = CCHF2n.VVEbNz(item, "category_id" )
      description  = CCHF2n.VVEbNz(item, "description" )
      director  = CCHF2n.VVEbNz(item, "director"  )
      genres_str  = CCHF2n.VVEbNz(item, "genres_str"  )
      name   = CCHF2n.VVEbNz(item, "name"   )
      path   = CCHF2n.VVEbNz(item, "path"   )
      screenshot_uri = CCHF2n.VVEbNz(item, "screenshot_uri" )
      series   = CCHF2n.VVEbNz(item, "series"   )
      cmd    = CCHF2n.VVEbNz(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVmG3M  = ("Play"    , BF(self.VV32jH, mode)       , [])
   VVAe4b = (""     , BF(self.VVHEpT, mode)     , [])
   VVDti0 = ("Home Menu"   , FFi0ku            , [])
   VVZyxX = ("Download Options" , BF(self.VVZMcX, mode, "sp", seriesName) , [])
   VVQJvS = ("Options"   , BF(self.VVHBq0, "pEp", mode, seriesName) , [])
   VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV4tj2  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF8dRU(self, None, title=seriesName, width=1200, header=header, VVHQsP=list, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindIptv, VVW1CX="#0a00292B", VVLasp="#0a002126", VVHSOH="#0a002126", VVJqmr="#00000000")
  else:
   FF1uaI(self, "Could not get Episodes from server!", title=seriesName)
 def VVYD65(self, mode, searchInCat, VVc7Yu, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVd21k = []
  VVd21k.append(("Keyboard"  , "manualEntry"))
  VVd21k.append(("From Filter" , "fromFilter"))
  FFxMT2(self, BF(self.VVfDjR, VVc7Yu, mode, searchCatId), title="Input Type", VVd21k=VVd21k, width=400)
 def VVfDjR(self, VVc7Yu, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFX1El(self, BF(self.VV4yJf, VVc7Yu, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC4Wdl(self)
    filterObj.VVIRm0(BF(self.VV4yJf, VVc7Yu, mode, searchCatId))
 def VV4yJf(self, VVc7Yu, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFWvPK(CFG.lastFindIptv, searchName)
   title = self.VVwrOF(mode, searchName)
   if "," in searchName : FF1uaI(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FF1uaI(self, "Enter at least 3 characters.", title=title)
   else     :
    VV9ibt = CCAOao()
    if CFG.hideIptvServerAdultWords.getValue() and VV9ibt.VVPCQa([searchName]):
     FF1uaI(self, VV9ibt.VVD1ic(), title=title)
    else:
     self.VVbyRo(mode, searchName, "", searchName, searchCatId)
 def VVTdZQ(self, mode, VVc7Yu, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVbyRo(mode, bName, catID, "", "")
 def VVbyRo(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CC8PiB, barTheme=CC8PiB.VVchq1
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVC8sK, mode, bName, catID, searchName, searchCatId)
      , VVXlAY = BF(self.VVGVYE, mode, bName, catID, searchName, searchCatId))
 def VVGVYE(self, mode, bName, catID, searchName, searchCatId, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVwrOF(mode, searchName)
  else   : title = "%s : %s" % (self.VVD4Dd(mode), bName)
  if VVc1Ja:
   VVZyxX = None
   VVQJvS = None
   if mode == "series":
    VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km("series2")
    VVmG3M  = ("Episodes"   , BF(self.VVXQj6, mode)           , [])
   else:
    VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km("")
    VVmG3M  = ("Play"    , BF(self.VV32jH, mode)           , [])
    VVZyxX = ("Download Options" , BF(self.VVZMcX, mode, "vp" if mode == "vod" else "", "") , [])
    VVQJvS = ("Options"   , BF(self.VVHBq0, "pCh", mode, bName)      , [])
   VVAe4b = (""      , BF(self.VVflLD, mode)         , [])
   VVDti0 = ("Home Menu"    , FFi0ku                , [])
   VVOr9v = ("Posters Mode"   , BF(self.VV7pzA, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VV4tj2  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVc7Yu = FF8dRU(self, None, title=title, header=header, VVHQsP=VVc1Ja, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindIptv, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVHSOH, VVJqmr=VVJqmr, VVDYPP=True, searchCol=1)
   if not VV5vtH:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVc7Yu.VV8abG(VVc7Yu.VVZMUB() + tot)
    if threadErr: FFkxeT(VVc7Yu, "Error while reading !", 2000)
    else  : FFkxeT(VVc7Yu, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF1uaI(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF1uaI(self, "Could not get list from server !", title=title)
 def VVflLD(self, mode, VVc7Yu, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFdGDb(self, fncMode=CCfm5u.VVTvCn, portalHost=self.VVinJa, portalMac=self.VV8nIm, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVDL8J(mode, VVc7Yu, title, txt, colList)
 def VVHEpT(self, mode, VVc7Yu, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFHqZk(colList[10], VVekE1)
  txt += "Description:\n%s" % FFHqZk(colList[11], VVekE1)
  self.VVDL8J(mode, VVc7Yu, title, txt, colList)
 def VVDL8J(self, mode, VVc7Yu, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVuhC3(mode, colList)
  refCode, chUrl = self.VVvs8A(self.VVinJa, self.VV8nIm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFdGDb(self, fncMode=CCfm5u.VVAw6j, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVC8sK(self, mode, bName, catID, searchName, searchCatId, VVTb2z):
  try:
   token, profile, tErr = self.VVsmYK()
   if not token:
    return
   if VVTb2z.isCancelled:
    return
   VVTb2z.VVc1Ja, total_items, max_page_items, err = self.VVYVU5(mode, catID, 1, 1, searchName, searchCatId)
   if VVTb2z.isCancelled:
    return
   if VVTb2z.VVc1Ja and total_items > -1 and max_page_items > -1:
    VVTb2z.VViTTm(total_items)
    VVTb2z.VV3VHc(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVTb2z.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVYVU5(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVTb2z.VVb8zx()
     if VVTb2z.isCancelled:
      return
     if list:
      VVTb2z.VVc1Ja += list
      VVTb2z.VV3VHc(len(list), True)
  except:
   pass
 def VVYVU5(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVIF3c(mode, searchName, searchCatId, page)
  else   : url = self.VV3Khw(mode, catID, page)
  res, err = self.VV5lHh(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV58sB(CCHF2n.VVEbNz(item, "total_items" ))
     max_page_items = self.VV58sB(CCHF2n.VVEbNz(item, "max_page_items" ))
     VV9ibt = CCAOao()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCHF2n.VVEbNz(item, "id"    )
      name   = CCHF2n.VVEbNz(item, "name"   )
      o_name   = CCHF2n.VVEbNz(item, "o_name"   )
      tv_genre_id  = CCHF2n.VVEbNz(item, "tv_genre_id" )
      number   = CCHF2n.VVEbNz(item, "number"   ) or str(counter)
      logo   = CCHF2n.VVEbNz(item, "logo"   )
      screenshot_uri = CCHF2n.VVEbNz(item, "screenshot_uri" )
      cmd    = CCHF2n.VVEbNz(item, "cmd"   )
      censored  = CCHF2n.VVEbNz(item, "censored"  )
      genres_str  = CCHF2n.VVEbNz(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVinJa + picon).replace(sp * 2, sp)
      counter += 1
      name = VV9ibt.VVJBfo(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV58sB(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV32jH(self, mode, VVc7Yu, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVuhC3(mode, colList)
  refCode, chUrl = self.VVvs8A(self.VVinJa, self.VV8nIm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVvpjr(chName):
   FFkxeT(VVc7Yu, "This is a marker!", 300)
  else:
   FFqcaP(VVc7Yu, BF(self.VV0FwY, mode, VVc7Yu, chUrl), title="Playing ...")
 def VV0FwY(self, mode, VVc7Yu, chUrl):
  FFxZcp(self, chUrl, VVY2Q7=False)
  CCqzRz.VVfphk(self.session, iptvTableParams=(self, VVc7Yu, mode))
 def VV0phW(self, mode, VVc7Yu, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVuhC3(mode, colList)
  refCode, chUrl = self.VVvs8A(self.VVinJa, self.VV8nIm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVuhC3(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV0eGg(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVd21k = []
    VVd21k.append((title        , "inst" ))
    VVd21k.append(("Update Packages then %s" % title , "updInst" ))
    FFxMT2(SELF, BF(CCr3lG.VVrEAz, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVd21k=VVd21k)
   return False
 @staticmethod
 def VVrEAz(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FF1WnD(VVZEcr, "")
   if cmdUpd:
    cmdInst = FF5LxN(VVQGHq, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFkyna(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVHcKu=cbFnc)
   else:
    FF3PaD(SELF)
class CCHF2n(Screen, CCr3lG, CCbyck):
 VVr2xW    = 0
 VVbROq    = 1
 VVhkc9    = 2
 VVvAmR    = 3
 VVlgJC     = 4
 VVE2gD     = 5
 VVNoDl     = 6
 VV2NTn     = 7
 VVXlbK     = 8
 VV1Z6y     = 9
 VVzbk3      = 10
 VVWxVA     = 11
 VVzKhJ     = 12
 VVQKPh     = 13
 VV64l8     = 14
 VVS2PW      = 15
 VVa4Uf      = 16
 VVCOUU      = 17
 VVNLvK      = 18
 VV3Ppl      = 19
 VVt4MN    = 0
 VVAupb   = 1
 VVMlZk   = 2
 VV1Yih   = 3
 VVF2Xx  = 4
 VVN0H5  = 5
 VV3Rn0   = 6
 VVnbf9   = 7
 VVseBO  = 8
 VV2W68  = 9
 VVugDs  = 10
 VV5Qfb = 0
 VV4YCD = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FF1pMw(VVilCV, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVc7Yu    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVOsp7Data    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCHF2n.VVS8Qr(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCr3lG.__init__(self)
  VVd21k = self.VVCScn()
  FFrOoX(self, title="IPTV", VVd21k=VVd21k)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self["myMenu"].setList(self.VVCScn())
  FFCRqe(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFmysb(self["myMenu"])
   FFNMqr(self)
   if self.m3uOrM3u8File:
    self.VVrruY(self.m3uOrM3u8File, (0, (), False, ""))
 def VVCScn(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVyuFD
  VVd21k = []
  if isFav1: VVd21k.append((c +  "Favourite Playlist Server"   , "VV14Vy" ))
  if isFav2: VVd21k.append((c +  "Favourite Portal Server"    , "VVIVc2Portal" ))
  VVd21k.append(("IPTV Server Browser (from Playlists)"     , "VVOsp7_fromPlayList" ))
  VVd21k.append(("IPTV Server Browser (from Portal List)"    , "VVOsp7_fromMac"  ))
  VVd21k.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVOsp7_fromM3u"  ))
  qUrl, iptvRef = CCHF2n.VVlKug(self)
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVd21k.append((item     , "VVOsp7_fromCurrChan" ))
  else       : VVd21k.append((item     ,       ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("M3U/M3U8 File Browser"        , "VV17Ic"   ))
  if self.iptvFileAvailable:
   VVd21k.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVd21k.append(VVNCuu)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVd21k.append((item1            , "refreshIptvEPG"   ))
   VVd21k.append((item2            , "refreshIptvPicons"  ))
  else:
   VVd21k.append((item1            ,       ))
   VVd21k.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVd21k.append(VVNCuu)
   c1, c2 = VVRK3s, VVWFW6
   t1 = FFHqZk("auto-match names", VVyuFD)
   t2 = FFHqZk("from xml file"  , VVyuFD)
   VVd21k.append((c1 + "Count Available IPTV Channels"    , "VVYbLP"    ))
   VVd21k.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVd21k.append(VVNCuu)
   VVd21k.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVd21k.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVOqcA" ))
   VVd21k.append((VVHeSZ + "More Reference Tools ..."  , "VVZ6Vw"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Reload Channels and Bouquets"       , "VVfpr0"   ))
  VVd21k.append(VVNCuu)
  if not CCEVEE.VVBqxI():
   VVd21k.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVd21k.append(("Download Manager ... No donwloads"    ,       ))
  return VVd21k
 def VVhF4L(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVT882"   : self.VVT882()
   elif item == "VVAnwD" : FFWV4g(self, self.VVAnwD, "Change Current List References to Unique Codes ?")
   elif item == "VVhQJ1_rows" : FFWV4g(self, BF(FFqcaP, self.VVc7Yu, self.VVhQJ1), "Change Current List References to Identical Codes ?")
   elif item == "VVzBCr"   : self.VVzBCr(tTitle)
   elif item == "VVoJNc"   : self.VVoJNc(tTitle)
   elif item == "VV14Vy" : self.VVIVc2(False)
   elif item == "VVIVc2Portal" : self.VVIVc2(True)
   elif item == "VVOsp7_fromPlayList" : FFqcaP(self, BF(self.VVRtds, 1), title=title)
   elif item == "VVOsp7_fromM3u"  : FFqcaP(self, BF(self.VVRmJe, CCHF2n.VV5Qfb), title=title)
   elif item == "VVOsp7_fromMac"  : self.VVtC3n()
   elif item == "VVOsp7_fromCurrChan" : self.VVwSyH()
   elif item == "VV17Ic"   : self.VV17Ic()
   elif item == "iptvTable_all"   : FFqcaP(self, BF(self.VV9RuF, self.VVr2xW), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCHF2n.VVjLFE(self)
   elif item == "refreshIptvPicons"  : self.VVqe26()
   elif item == "VVYbLP"    : FFqcaP(self, self.VVYbLP)
   elif item == "copyEpgPicons"   : self.VVsf6x(False)
   elif item == "renumIptvRef_fromFile" : self.VVsf6x(True)
   elif item == "VVOqcA" : FFWV4g(self, BF(FFqcaP, self, self.VVOqcA), VVJpRC="Continue ?")
   elif item == "VVZ6Vw"    : self.VVZ6Vw()
   elif item == "VVfpr0"   : FFqcaP(self, BF(CCDvzd.VVfpr0, self))
   elif item == "dload_stat"    : CCEVEE.VVBiV1(self)
 def VV17Ic(self):
  if CCr3lG.VV0eGg(self):
   FFqcaP(self, BF(self.VVRmJe, CCHF2n.VV4YCD), title="Searching ...")
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVhF4L(item)
 def VV9RuF(self, mode):
  VVG5ES = self.VVFu9F(mode)
  if VVG5ES:
   VVZyxX = ("Current Service", self.VVz3Hp , [])
   VVQJvS = ("Options"  , self.VVSGoW   , [])
   VVOr9v = ("Filter"   , self.VVTeqA   , [])
   VVmG3M  = ("Play"   , BF(self.VVm8hG)  , [])
   VVAe4b = (""    , self.VV7XYi    , [])
   VVbNxw = (""    , self.VVq8Hs     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VV4tj2  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FF8dRU(self, None, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26
     , VVmG3M=VVmG3M, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVAe4b=VVAe4b, VVbNxw=VVbNxw
     , VVW1CX="#0a00292B", VVLasp="#0a002126", VVHSOH="#0a002126", VVJqmr="#00000000", VVDYPP=True, searchCol=1)
  else:
   if mode == self.VV1Z6y: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF1uaI(self, err)
 def VVq8Hs(self, VVc7Yu, title, txt, colList):
  self.VVc7Yu = VVc7Yu
 def VVSGoW(self, VVc7Yu, title, txt, colList):
  VVd21k = []
  VVd21k.append(("Add Current List to a New Bouquet"    , "VVT882"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Change Current List References to Unique Codes" , "VVAnwD"))
  VVd21k.append(("Change Current List References to Identical Codes", "VVhQJ1_rows" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Share Reference with DVB Service (manual entry)" , "VVzBCr"   ))
  VVd21k.append(("Share Reference with DVB Service (auto-find)"  , "VVoJNc"   ))
  FFxMT2(self, self.VVhF4L, title="IPTV Tools", VVd21k=VVd21k)
 def VVTeqA(self, VVc7Yu, title, txt, colList):
  VVd21k = []
  VVd21k.append(("All"         , "all"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Prefix of Selected Channel"   , "sameName" ))
  VVd21k.append(("Suggest Words from Selected Channel" , "partName" ))
  VVd21k.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVd21k.append(("Duplicate References"     , "depRef"  ))
  VVd21k.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVd21k.append(("Stream Relay"       , "SRelay"  ))
  VVd21k.append(FFnwrX("Category"))
  VVd21k.append(("Live TV"        , "live"  ))
  VVd21k.append(("VOD"         , "vod"   ))
  VVd21k.append(("Series"        , "series"  ))
  VVd21k.append(("Uncategorised"      , "uncat"  ))
  VVd21k.append(FFnwrX("Media"))
  VVd21k.append(("Video"        , "video"  ))
  VVd21k.append(("Audio"        , "audio"  ))
  VVd21k.append(FFnwrX("File Type"))
  VVd21k.append(("MKV"         , "MKV"   ))
  VVd21k.append(("MP4"         , "MP4"   ))
  VVd21k.append(("MP3"         , "MP3"   ))
  VVd21k.append(("AVI"         , "AVI"   ))
  VVd21k.append(("FLV"         , "FLV"   ))
  VVd21k.extend(CCB8uV.VVO48d(prefix="__b__"))
  inFilterFnc = BF(self.VVlb5g, VVc7Yu) if VVc7Yu.VVZMUB().startswith("IPTV Filter ") else None
  filterObj = CC4Wdl(self)
  filterObj.VVeblc(VVd21k, VVd21k, BF(self.VV7K0m, VVc7Yu, False), inFilterFnc=inFilterFnc)
 def VVlb5g(self, VVc7Yu, menuInstance, item):
  self.VV7K0m(VVc7Yu, True, item)
 def VV7K0m(self, VVc7Yu, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVc7Yu.VVGBYR(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVr2xW , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVbROq , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVhkc9 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVvAmR , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVNoDl  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV2NTn  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVXlbK  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VV1Z6y  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVzbk3   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVWxVA  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVzKhJ  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVQKPh  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV64l8  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVS2PW   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVa4Uf   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVCOUU   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVNLvK   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV3Ppl   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVlgJC  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVE2gD  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVhkc9:
   VVd21k = []
   chName = VVc7Yu.VVGBYR(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVd21k.append((item, item))
    if not VVd21k and chName:
     VVd21k.append((chName, chName))
    FFxMT2(self, BF(self.VVt8tm, title), title="Words from Current Selection", VVd21k=VVd21k)
   else:
    VVc7Yu.VVdNoE("Invalid Channel Name")
  else:
   words, asPrefix = CC4Wdl.VV610T(words)
   if not words and mode in (self.VVlgJC, self.VVE2gD):
    FFkxeT(self.VVc7Yu, "Incorrect filter", 2000)
   else:
    FFqcaP(self.VVc7Yu, BF(self.VV9iBD, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVt8tm(self, title, word=None):
  if word:
   words = [word.lower()]
   FFqcaP(self.VVc7Yu, BF(self.VV9iBD, self.VVhkc9, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VViOIM(txt):
  return "#f#11ffff00#" + txt
 def VV9iBD(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVG5ES = self.VVBcXM(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVG5ES = self.VVFu9F(mode=mode, words=words, asPrefix=asPrefix)
  if VVG5ES : self.VVc7Yu.VV4ZQl(VVG5ES, title)
  else  : self.VVc7Yu.VVdNoE("Not found")
 def VVBcXM(self, mode=0, words=None, asPrefix=False):
  VVG5ES = []
  for row in self.VVc7Yu.VVgeCg():
   row = list(map(str.strip, row))
   chNum, chName, VVurIH, chType, refCode, url = row
   if self.VVMQrH(mode, refCode, FFeHlW(url).lower(), chName, words, VVurIH.lower(), asPrefix):
    VVG5ES.append(row)
  VVG5ES = self.VVXFEB(mode, VVG5ES)
  return VVG5ES
 def VVFu9F(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVG5ES = []
  files  = self.VVbrgp()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFnMVE(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVurIH = span.group(1)
    else : VVurIH = ""
    VVurIH_lCase = VVurIH.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVvpjr(chName): chNameMod = self.VViOIM(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVurIH, chType + (" SRel" if FFqc3z(url) else ""), refCode, url)
     if self.VVMQrH(mode, refCode, FFeHlW(url).lower(), chName, words, VVurIH_lCase, asPrefix):
      VVG5ES.append(row)
      chNum += 1
  VVG5ES = self.VVXFEB(mode, VVG5ES)
  return VVG5ES
 def VVXFEB(self, mode, VVG5ES):
  newRows = []
  if VVG5ES and mode == self.VVNoDl:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVG5ES)
   for item in VVG5ES:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVG5ES
 def VVMQrH(self, mode, refCode, tUrl, chName, words, VVurIH_lCase, asPrefix):
  if   mode == self.VVr2xW : return True
  elif mode == self.VVNoDl : return True
  elif mode == self.VV2NTn  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVXlbK : return FFqc3z(tUrl)
  elif mode == self.VVQKPh  : return CCHF2n.VVPQqT(tUrl, getAudVid=True) == "vid"
  elif mode == self.VV64l8  : return CCHF2n.VVPQqT(tUrl, getAudVid=True) == "aud"
  elif mode == self.VV1Z6y  : return CCHF2n.VVPQqT(tUrl, compareType="live")
  elif mode == self.VVzbk3  : return CCHF2n.VVPQqT(tUrl, compareType="movie")
  elif mode == self.VVWxVA : return CCHF2n.VVPQqT(tUrl, compareType="series")
  elif mode == self.VVzKhJ  : return CCHF2n.VVPQqT(tUrl, compareType="")
  elif mode == self.VVS2PW  : return CCHF2n.VVPQqT(tUrl, compareExt="mkv")
  elif mode == self.VVa4Uf  : return CCHF2n.VVPQqT(tUrl, compareExt="mp4")
  elif mode == self.VVCOUU  : return CCHF2n.VVPQqT(tUrl, compareExt="mp3")
  elif mode == self.VVNLvK  : return CCHF2n.VVPQqT(tUrl, compareExt="avi")
  elif mode == self.VV3Ppl  : return CCHF2n.VVPQqT(tUrl, compareExt="flv")
  elif mode == self.VVbROq: return chName.lower().startswith(words[0])
  elif mode == self.VVhkc9: return words[0] in chName.lower()
  elif mode == self.VVvAmR: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVlgJC : return words[0] == VVurIH_lCase
  elif mode == self.VVE2gD :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVT882(self):
  picker = CCB8uV(self, self.VVc7Yu, "Add to Bouquet", self.VVBMnl)
 def VVBMnl(self):
  chUrlLst = []
  for row in self.VVc7Yu.VVgeCg():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVZ6Vw(self):
  c1 = VVusL5
  t1 = FFHqZk("Bouquet", VVyuFD)
  t2 = FFHqZk("ALL", VVyuFD)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVd21k = []
  VVd21k.append((c1 + "Check System Acceptable Reference Types" , "VVwHm8"    ))
  if self.iptvFileAvailable:
   VVd21k.append((c1 + "Check Reference Codes Format"  , "VVrvYf"    ))
  VVd21k.append(VVNCuu)
  VVd21k.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVAXL5" ))
  VVd21k.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVjXTE_all"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Change %s References to Unique Codes" % t2 , "VV3sDy"  ))
  VVd21k.append(("Change %s References to Identical Codes" % t2 , "VVhQJ1_all"  ))
  OKBtnFnc = self.VV1L3O
  FFxMT2(self, None, width=1200, title="Reference Tools", VVd21k=VVd21k, OKBtnFnc=OKBtnFnc)
 def VV1L3O(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVwHm8"    : FFqcaP(menuInstance, self.VVwHm8)
   elif item == "VVrvYf"     : FFqcaP(menuInstance, self.VVrvYf)
   elif item == "VVAXL5" : self.VVAXL5(menuInstance)
   elif item == "VVjXTE_all"  : self.VVMSo8(menuInstance, None, None)
   elif item == "VV3sDy"  : FFWV4g(self, BF(self.VV3sDy , menuInstance, txt), title=txt, VVJpRC=ques)
   elif item == "VVhQJ1_all"  : FFWV4g(self, BF(FFqcaP, menuInstance, self.VVhQJ1), title=txt, VVJpRC=ques)
 def VVMSo8(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVd21k = []
  VVd21k.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVd21k.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVd21k.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVd21k.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVd21k.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))  #
  VVd21k.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFxMT2(self, BF(self.VV6QHO, menuInstance, bName, bPath), VVd21k=VVd21k, width=750, title="Change Reference Types to:")
 def VV6QHO(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVHIKE(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVHIKE(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVHIKE(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVHIKE(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVHIKE(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVHIKE(menuInstance, bName, bPath, "8193")
 def VVAXL5(self, menuInstance):
  VVd21k = CCB8uV.VVO48d()
  if VVd21k:
   FFxMT2(self, BF(self.VVtqhD, menuInstance), VVd21k=VVd21k, title="IPTV Bouquets", VVL2h3=True)
  else:
   FFkxeT(menuInstance, "No bouquets Found !", 1500)
 def VVtqhD(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVmqmq + span.group(1)
    if fileExists(bPath): self.VVMSo8(menuInstance, bName, bPath)
    else    : FFkxeT(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFkxeT(menuInstance, "Cannot process bouquet !", 2000)
 def VVHIKE(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFHqZk(bName, VVsZ3Y)
  else : title = "Change for %s" % FFHqZk("All IPTV Services", VVsZ3Y)
  FFWV4g(self, BF(FFqcaP, menuInstance, BF(self.VVYpsI, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFHqZk(rType, VVsZ3Y), title=title)
 def VVYpsI(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVbrgp()
  if files:
   newRType = rType + ":"
   piconPath = CCodIm.VVt98d()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCk3u6.VVsTOj(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FF1uaI(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFqAik("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFqAik(cmd))
  self.VVDhWN(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVYbLP(self):
  totFiles = 0
  files  = self.VVbrgp()
  if files:
   totFiles = len(files)
  totChans = 0
  VVG5ES = self.VVFu9F()
  if VVG5ES:
   totChans = len(VVG5ES)
  FFX3Iv(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVrvYf(self):
  files  = self.VVbrgp()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFnMVE(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVs4yr
   else    : color = VV0kWR
   totInvalid = FFHqZk(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFHqZk("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFX3Iv(self, txt, title="Check IPTV References")
 def VVwHm8(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCB8uV.VVIyPW(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVKcnR = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVKcnR:
   VV9U4H = FFWeHh(VVKcnR)
   if VV9U4H:
    for service in VV9U4H:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVmqmq + userBName
  bFile = VVmqmq + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFqAik("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFqAik("rm -f '%s'" % path)
  os.system(cmd)
  FFG6ML()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVs4yr
    else     : res, color = "No" , VV0kWR
    txt += "    %s\t: %s\n" % (item, FFHqZk(res, color))
   FFX3Iv(self, txt, title=title)
  else:
   txt = FF1uaI(self, "Could not complete the test on your system!", title=title)
 def VVOqcA(self):
  VVQzz4, err = CCDvzd.VVReux(self, CCDvzd.VVVwsH)
  if VVQzz4:
   totChannels = 0
   totChange = 0
   for path in self.VVbrgp():
    toSave = False
    txt = FFnMVE(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVQzz4.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVDhWN(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF1uaI(self, 'No channels in "lamedb" !')
 def VV3sDy(self, menuInstance, title):
  bFiles = self.VVbrgp()
  if bFiles:
   self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVVelr, bFiles)
       , VVXlAY = BF(self.VVVdfi, title))
  else:
   FFkxeT(menuInstance, "No bouquets files !", 1500)
 def VVVelr(self, bFiles, VVTb2z):
  VVTb2z.VVc1Ja = ""
  VVTb2z.VVFOrd("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFwiKR(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVTb2z or VVTb2z.isCancelled:
   return
  elif not totLines:
   VVTb2z.VVc1Ja = "No IPTV Services !"
   return
  else:
   VVTb2z.VViTTm(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVTb2z or VVTb2z.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFwiKR(path)
    for ndx, line in enumerate(lines):
     if not VVTb2z or VVTb2z.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVTb2z:
       VVTb2z.VVFOrd("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVTb2z:
       VVTb2z.VV3VHc(1)
      refCode, startId, startNS = CCB8uV.VVKzbL(rType, CCB8uV.VVEQcF, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVTb2z:
        VVTb2z.VVc1Ja = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVVdfi(self, title, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVc1Ja:
   txt += "\n\n%s\n%s" % (FFHqZk("Ended with Error:", VV0kWR), VVc1Ja)
  self.VVDhWN(True, title, txt)
 def VVAnwD(self):
  bFiles = self.VVbrgp()
  if not bFiles:
   FFkxeT(self.VVc7Yu, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVc7Yu.VVgeCg():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFkxeT(self.VVc7Yu, "Cannot read list", 1500)
   return
  self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVrwik, bFiles, tableRefList)
      , VVXlAY = BF(self.VVVdfi, "Change Current List References to Unique Codes"))
 def VVrwik(self, bFiles, tableRefList, VVTb2z):
  VVTb2z.VVc1Ja = ""
  VVTb2z.VVFOrd("Reading System References ...")
  refLst = CCB8uV.VVCGvA(CCB8uV.VVEQcF, stripRType=True)
  if not VVTb2z or VVTb2z.isCancelled:
   return
  VVTb2z.VViTTm(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVTb2z or VVTb2z.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFnMVE(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVTb2z or VVTb2z.isCancelled:
     return
    VVTb2z.VVFOrd("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVTb2z or VVTb2z.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVTb2z.VV3VHc(1)
      refCode, startId, startNS = CCB8uV.VVKzbL(rType, CCB8uV.VVEQcF, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVTb2z:
        VVTb2z.VVc1Ja = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVhQJ1(self):
  list = None
  if self.VVc7Yu:
   list = []
   for row in self.VVc7Yu.VVgeCg():
    list.append(row[4] + row[5])
  files  = self.VVbrgp()
  totChange = 0
  if files:
   for path in files:
    lines = FFwiKR(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVDhWN(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVDhWN(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFG6ML()
   if refreshTable and self.VVc7Yu:
    VVG5ES = self.VVFu9F()
    if VVG5ES and self.VVc7Yu:
     self.VVc7Yu.VV4ZQl(VVG5ES, self.tableTitle)
     self.VVc7Yu.VVdNoE(txt)
   FFX3Iv(self, txt, title=title)
  else:
   FFfF2j(self, "No changes.")
 def VVbrgp(self):
  return CCHF2n.VVS8Qr()
 @staticmethod
 def VVS8Qr(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVmqmq + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFnMVE(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV7XYi(self, VVc7Yu, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFeHlW(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFdGDb(self, fncMode=CCfm5u.VVtlGR, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVSp2J(self, VVc7Yu, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVm8hG(self, VVc7Yu, title, txt, colList):
  chName, chUrl = self.VVSp2J(VVc7Yu, colList)
  self.VVytSr(VVc7Yu, chName, chUrl, "localIptv")
 def VV4LZv(self, mode, VVc7Yu, colList):
  chName, chUrl, picUrl, refCode = self.VVSoTS(mode, colList)
  return chName, chUrl
 def VVBEef(self, mode, VVc7Yu, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVSoTS(mode, colList)
  self.VVytSr(VVc7Yu, chName, chUrl, mode)
 def VVytSr(self, VVc7Yu, chName, chUrl, playerFlag):
  chName = FFFnqK(chName)
  if self.VVvpjr(chName):
   FFkxeT(VVc7Yu, "This is a marker!", 300)
  else:
   FFqcaP(VVc7Yu, BF(self.VV3Nbk, VVc7Yu, chUrl, playerFlag), title="Playing ...")
 def VV3Nbk(self, VVc7Yu, chUrl, playerFlag):
  FFxZcp(self, chUrl, VVY2Q7=False)
  CCqzRz.VVfphk(self.session, iptvTableParams=(self, VVc7Yu, playerFlag))
 @staticmethod
 def VVvpjr(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVz3Hp(self, VVc7Yu, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  if refCode:
   url1 = FFeHlW(origUrl.strip())
   for ndx, row in enumerate(VVc7Yu.VVgeCg()):
    if refCode in row[4]:
     tableRow = FFeHlW(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVc7Yu.VVQ2AR(ndx)
      break
   else:
    FFkxeT(VVc7Yu, "No found", 1000)
 def VVRmJe(self, m3uMode):
  lines = self.VVupuq(3)
  if lines:
   lines.sort()
   VVd21k = []
   for line in lines:
    VVd21k.append((line, line))
   if m3uMode == CCHF2n.VV5Qfb:
    title = "Browse Server from M3U URLs"
    VVldmG = ("All to Playlist", self.VVeWOE)
   else:
    title = "M3U/M3U8 File Browser"
    VVldmG = None
   OKBtnFnc = BF(self.VVuQWG, m3uMode, title)
   infoBtnFnc = self.VVTfJa
   FFxMT2(self, None, title=title, VVd21k=VVd21k, width=1200, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="", VVldmG=VVldmG, VVW1CX="#11221122", VVLasp="#11221122")
 def VVuQWG(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == CCHF2n.VV5Qfb:
    FFqcaP(menuInstance, BF(self.VViBnI, title, path))
   else:
    self.VVcN3X(menuInstance, path)
 def VVcN3X(self, menuInstance, path=None):
  if path:
   VVd21k = []
   VVd21k.append(("All"         , "all"   ))
   VVd21k.append(FFnwrX("Category"))
   VVd21k.append(("Live TV"        , "live"  ))
   VVd21k.append(("VOD"         , "vod"   ))
   VVd21k.append(("Series"        , "series"  ))
   VVd21k.append(("Uncategorised"      , "uncat"  ))
   VVd21k.append(FFnwrX("Media"))
   VVd21k.append(("Video"        , "video"  ))
   VVd21k.append(("Audio"        , "audio"  ))
   VVd21k.append(FFnwrX("File Type"))
   VVd21k.append(("MKV"         , "MKV"   ))
   VVd21k.append(("MP4"         , "MP4"   ))
   VVd21k.append(("MP3"         , "MP3"   ))
   VVd21k.append(("AVI"         , "AVI"   ))
   VVd21k.append(("FLV"         , "FLV"   ))
   filterObj = CC4Wdl(self, VVW1CX="#11552233", VVLasp="#11552233")
   filterObj.VVeblc(VVd21k, [], BF(self.VVyT7n, menuInstance, path), inFilterFnc=None)
 def VVyT7n(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVr2xW , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VV1Z6y  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVzbk3  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVWxVA  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVzKhJ  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVQKPh  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VV64l8  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVS2PW  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVa4Uf  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVCOUU  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVNLvK  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VV3Ppl  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVE2gD  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CC4Wdl.VV610T(words)
   if not mode == self.VVr2xW:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFHqZk(fTitle, VVekE1)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFqcaP(menuInstance, BF(self.VVrruY, path, m3uFilterParam))
 def VVrruY(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFnMVE(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VV9ibt = CCAOao()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VV61Kt(propLine, "group-title") or "-"
   if not group == "-" and VV9ibt.VVJBfo(group):
    groups.add(group)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  VVG5ES = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VVG5ES.append((group, group))
   VVG5ES.append(("ALL", ""))
   VVG5ES.sort(key=lambda x: x[0].lower())
   VVVD8O = self.VVoN5a
   VVmG3M  = ("Select" , BF(self.VVP8Ji, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VV4tj2  = (LEFT  , LEFT)
   FF8dRU(self, None, title=title, width= 1000, header=None, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=30, VVmG3M=VVmG3M, VVVD8O=VVVD8O, lastFindConfigObj=CFG.lastFindIptv
     , VVW1CX="#11110022", VVLasp="#11110022", VVHSOH="#11110022", VVJqmr="#00444400")
  else:
   txt = FFnMVE(srcPath)
   self.VVmL9t(txt, "", m3uFilterParam)
 def VVP8Ji(self, srcPath, m3uFilterParam, VVc7Yu, title, txt, colList):
  group = colList[1]
  txt = FFnMVE(srcPath)
  self.VVmL9t(txt, group, m3uFilterParam)
 def VVmL9t(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CC8PiB, barTheme=CC8PiB.VVchq1
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VV9HJn, lst, filterGroup, m3uFilterParam)
       , VVXlAY = BF(self.VVH3oI, title, bName))
  else:
   self.VVIHEu("Not valid lines found !", title)
 def VV9HJn(self, lst, filterGroup, m3uFilterParam, VVTb2z):
  VVTb2z.VVc1Ja = []
  VVTb2z.VViTTm(len(lst))
  VV9ibt = CCAOao()
  num = 0
  for cols in lst:
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VV3VHc(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VV61Kt(propLine, "tvg-logo")
   group = self.VV61Kt(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VV9ibt.VVJBfo(group) : skip = True
    elif chName and not VV9ibt.VVJBfo(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVMQrH(mode, "", FFeHlW(url).lower(), chName, words, "", asPrefix)
    if not skip and VVTb2z:
     num += 1
     VVTb2z.VVc1Ja.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVTb2z:
   VVTb2z.VVNE8d("Loading %d Channels" % len(VVTb2z.VVc1Ja))
 def VVH3oI(self, title, bName, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if VVc1Ja:
   VVVD8O = self.VVoN5a
   VVmG3M  = ("Select"   , BF(self.VVjmJv, title)   , [])
   VVAe4b = (""    , self.VV4lji        , [])
   VVZyxX = ("Download PIcons", self.VVU2z6       , [])
   VVQJvS = ("Options"  , BF(self.VVHBq0, "m3Ch", "", bName) , [])
   VVOr9v = ("Posters Mode" , BF(self.VV7pzA, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV4tj2  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVc1Ja, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, VVmG3M=VVmG3M, VVVD8O=VVVD8O, VVAe4b=VVAe4b, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindIptv, VVDYPP=True, searchCol=1
     , VVW1CX="#0a00192B", VVLasp="#0a00192B", VVHSOH="#0a00192B", VVJqmr="#00000000")
  else:
   self.VVIHEu("Not found !", title)
 def VVU2z6(self, VVc7Yu, title, txt, colList):
  self.VVGRA1(VVc7Yu, "m3u/m3u8")
 def VVWc70(self, rowNum, url, chName):
  refCode = self.VVrv3H(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFENC4(url), chName)
  return chUrl
 def VVrv3H(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVKGWh(catID, stID, chNum)
  return refCode
 def VV61Kt(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVjmJv(self, Title, VVc7Yu, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFqcaP(VVc7Yu, BF(self.VVHRGW, Title, VVc7Yu, colList), title="Checking Server ...")
  else:
   self.VVK4o1(VVc7Yu, url, chName)
 def VVHRGW(self, title, VVc7Yu, colList):
  if not CCr3lG.VV0eGg(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCTQO7.VVYV6p(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVd21k = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCHF2n.VV1eQd(url, fPath)
     VVd21k.append((resol, fullUrl))
    if VVd21k:
     if len(VVd21k) > 1:
      FFxMT2(self, BF(self.VVaSox, VVc7Yu, chName), VVd21k=VVd21k, title="Resolution", VVL2h3=True, VVP2Aq=True)
     else:
      self.VVK4o1(VVc7Yu, VVd21k[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVK4o1(VVc7Yu, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCHF2n.VV1eQd(url, span.group(1))
       self.VVK4o1(VVc7Yu, fullUrl, chName)
      else:
       self.VV1kxV("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVmL9t(txt, filterGroup="")
      return
    self.VVK4o1(VVc7Yu, url, chName)
   else:
    self.VVIHEu("Cannot process this channel !", title)
  else:
   self.VVIHEu(err, title)
 def VVaSox(self, VVc7Yu, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVK4o1(VVc7Yu, resolUrl, chName)
 def VVK4o1(self, VVc7Yu, url, chName):
  FFqcaP(VVc7Yu, BF(self.VVffhO, VVc7Yu, url, chName), title="Playing ...")
 def VVffhO(self, VVc7Yu, url, chName):
  chUrl = self.VVWc70(VVc7Yu.VVbJrA(), url, chName)
  FFxZcp(self, chUrl, VVY2Q7=False)
  CCqzRz.VVfphk(self.session, iptvTableParams=(self, VVc7Yu, "m3u/m3u8"))
 def VVAWte(self, VVc7Yu, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVWc70(VVc7Yu.VVbJrA(), url, chName)
  return chName, chUrl
 def VV4lji(self, VVc7Yu, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFdGDb(self, fncMode=CCfm5u.VVtlGR, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVIHEu(self, err, title):
  FF1uaI(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVoN5a(self, VVc7Yu):
  if self.m3uOrM3u8File:
   self.close()
  VVc7Yu.cancel()
 def VVeWOE(self, VVFy7pObj, item=None):
  FFqcaP(VVFy7pObj, BF(self.VV59nb, VVFy7pObj, item))
 def VV59nb(self, VVFy7pObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVFy7pObj.VVd21k):
    path = item[1]
    if fileExists(path):
     enc = CCtiVE.VVLoBC(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCHF2n.VVahHL(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCHF2n.VVbUJz()
    pListF = "%sPlaylist_%s.txt" % (path, FF5Vj3())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVFy7pObj.VVd21k)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFX3Iv(self, txt, title=title)
   else:
    FF1uaI(self, "Could not obtain URLs from this file list !", title=title)
 def VVRtds(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVvjnu
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVx4tQ
  lines = self.VVupuq(mode)
  if lines:
   lines.sort()
   VVd21k = []
   for line in lines:
    VVd21k.append((FFHqZk(line, VVWFW6) if "Bookmarks" in line else line, line))
   infoBtnFnc = self.VVTfJa
   FFxMT2(self, None, title=title, VVd21k=VVd21k, width=1200, OKBtnFnc=okFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="")
 def VVTfJa(self, menuInstance, txt, ref, ndx):
  txt = ref
  sz = FF2oRJ(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCk3u6.VVeQ5q(sz)
  FFX3Iv(self, txt, title="File Path")
 def VVvjnu(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFqcaP(menuInstance, BF(self.VVDVh6, menuInstance, path), title="Processing File ...")
 def VVDVh6(self, VVlDzT, path):
  enc = CCtiVE.VVLoBC(path, self)
  if enc == -1:
   return
  VVG5ES = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFjZE4(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCHF2n.VVh60f(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVG5ES:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVG5ES.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVG5ES:
   title = "Playlist File : %s" % os.path.basename(path)
   VVmG3M  = ("Start"    , BF(self.VViqJI, "Playlist File")      , [])
   VVDti0 = ("Home Menu"   , FFi0ku             , [])
   VVZyxX = ("Download M3U File" , self.VVBKf1         , [])
   VVQJvS = ("Edit File"   , BF(self.VVv7mM, path)        , [])
   VVOr9v = ("Check & Filter"  , BF(self.VVBRGz, VVlDzT, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV4tj2  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVDti0=VVDti0, VVOr9v=VVOr9v, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVW1CX="#11001116", VVLasp="#11001116", VVHSOH="#11001116", VVJqmr="#00003635", VVFNoD="#0a333333", VVcwBH="#11331100", VVDYPP=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FF1uaI(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVBKf1(self, VVc7Yu, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFWV4g(self, BF(FFqcaP, VVc7Yu, BF(self.VVbjIj, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVbjIj(self, title, url):
  path, err = FFR3XR(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF1uaI(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFnMVE(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFC2Q5(path)
    FF1uaI(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFC2Q5(path)
    FF1uaI(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCHF2n.VVbUJz() + fName
    os.system(FFqAik("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFfF2j(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF1uaI(self, "Could not download the M3U file!", title=errTitle)
 def VViqJI(self, Title, VVc7Yu, title, txt, colList):
  url = colList[6]
  FFqcaP(VVc7Yu, BF(self.VVty48, Title, url), title="Checking Server ...")
 def VVv7mM(self, path, VVc7Yu, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCwq37(self, path, VVXlAY=BF(self.VVrjrT, VVc7Yu), curRowNum=rowNum)
  else    : FFr3Kr(self, path)
 def VVrjrT(self, VVc7Yu, fileChanged):
  if fileChanged:
   VVc7Yu.cancel()
 def VVzBCr(self, title):
  curChName = self.VVc7Yu.VVGBYR(1)
  FFX1El(self, BF(self.VVTwbO, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVTwbO(self, title, name):
  if name:
   VVQzz4, err = CCDvzd.VVReux(self, CCDvzd.VVhhhH, VVp4O4=False, VVFu5u=False)
   list = []
   if VVQzz4:
    VV9ibt = CCAOao()
    name = VV9ibt.VVHGDn(name)
    ratio = "1"
    for item in VVQzz4:
     if name in item[0].lower():
      list.append((item[0], FFx433(item[2]), item[3], ratio))
   if list : self.VVAqvI(list, title)
   else : FF1uaI(self, "Not found:\n\n%s" % name, title=title)
 def VVoJNc(self, title):
  curChName = self.VVc7Yu.VVGBYR(1)
  self.session.open(CC8PiB, barTheme=CC8PiB.VVchq1
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VV1NPo
      , VVXlAY = BF(self.VVlksO, title, curChName))
 def VV1NPo(self, VVTb2z):
  curChName = self.VVc7Yu.VVGBYR(1)
  VVQzz4, err = CCDvzd.VVReux(self, CCDvzd.VVRKv2, VVp4O4=False, VVFu5u=False)
  if not VVQzz4 or not VVTb2z or VVTb2z.isCancelled:
   return
  VVTb2z.VVc1Ja = []
  VVTb2z.VViTTm(len(VVQzz4))
  VV9ibt = CCAOao()
  curCh = VV9ibt.VVHGDn(curChName)
  for refCode in VVQzz4:
   chName, sat, inDB = VVQzz4.get(refCode, ("", "", 0))
   ratio = CCodIm.VVJvTp(chName.lower(), curCh)
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VV3VHc(1, True)
   if VVTb2z and ratio > 50:
    VVTb2z.VVc1Ja.append((chName, FFx433(sat), refCode.replace("_", ":"), str(ratio)))
 def VVlksO(self, title, curChName, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if VVc1Ja: self.VVAqvI(VVc1Ja, title)
  elif VV5vtH: FF1uaI(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVAqvI(self, VVG5ES, title):
  curChName = self.VVc7Yu.VVGBYR(1)
  VV8C6T = self.VVc7Yu.VVGBYR(4)
  curUrl  = self.VVc7Yu.VVGBYR(5)
  VVG5ES.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVmG3M  = ("Share Sat/C/T Ref.", BF(self.VV73s7, title, curChName, VV8C6T, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVW1CX="#0a00112B", VVLasp="#0a001126", VVHSOH="#0a001126", VVJqmr="#00000000")
 def VV73s7(self, newtitle, curChName, VV8C6T, curUrl, VVc7Yu, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VV8C6T, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFWV4g(self.VVc7Yu, BF(FFqcaP, self.VVc7Yu, BF(self.VVG1ve, VVc7Yu, data)), ques, title=newtitle, VVwjVK=True)
 def VVG1ve(self, VVc7Yu, data):
  VVc7Yu.cancel()
  title, curChName, VV8C6T, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VV8C6T = VV8C6T.strip()
  newRefCode = newRefCode.strip()
  if not VV8C6T.endswith(":") : VV8C6T += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VV8C6T, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VV8C6T + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVbrgp():
    txt = FFnMVE(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFG6ML()
    newRow = []
    for i in range(6):
     newRow.append(self.VVc7Yu.VVGBYR(i))
    newRow[4] = newRefCode
    done = self.VVc7Yu.VV2PiO(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFnCJX(BF(FFfF2j , self, resTxt, title=title))
  elif resErr: FFnCJX(BF(FF1uaI, self, resErr, title=title))
 def VVBRGz(self, VVlDzT, path, VVc7Yu, title, txt, colList):
  self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVREkP, VVc7Yu)
      , VVXlAY = BF(self.VVmDmn, VVlDzT, path, VVc7Yu))
 def VVREkP(self, VVc7Yu, VVTb2z):
  VVTb2z.VViTTm(VVc7Yu.VVtZhN())
  VVTb2z.VVc1Ja = []
  for row in VVc7Yu.VVgeCg():
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VV3VHc(1, True)
   qUrl = self.VV8qh5(self.VVt4MN, row[6])
   txt, err = self.VVl3JC(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVEbNz(item, "auth") == "0":
       VVTb2z.VVc1Ja.append(qUrl)
    except:
     pass
 def VVmDmn(self, VVlDzT, path, VVc7Yu, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if VV5vtH:
   list = VVc1Ja
   title = "Authorized Servers"
   if list:
    totChk = VVc7Yu.VVtZhN()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF5Vj3()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVRtds(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFHqZk(str(totAuth), VVs4yr)
     txt += "%s\n\n%s"    %  (FFHqZk("Result File:", VVWFW6), newPath)
     FFX3Iv(self, txt, title=title)
     VVc7Yu.close()
     VVlDzT.close()
    else:
     FFfF2j(self, "All URLs are authorized.", title=title)
   else:
    FF1uaI(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVl3JC(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVh60f(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVPQqT(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CC9q9p.VVfYFN()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VV2NtU(decodedUrl):
  return CCHF2n.VVPQqT(decodedUrl, justRetDotExt=True)
 def VV8qh5(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVh60f(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVt4MN   : return "%s"            % url
  elif mode == self.VVAupb   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVMlZk   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV1Yih  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVF2Xx  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVN0H5 : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV3Rn0   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVnbf9    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVseBO  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVugDs : return "%s&action=get_live_streams"      % url
  elif mode == self.VV2W68  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVEbNz(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFeWDt(int(val))
    elif is_base64 : val = FFqnL0(val)
    elif isToHHMMSS : val = FF6f6P(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VViBnI(self, title, path):
  if fileExists(path):
   enc = CCtiVE.VVLoBC(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCHF2n.VVahHL(line)
     if qUrl:
      break
   if qUrl : self.VVty48(title, qUrl)
   else : FF1uaI(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF1uaI(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVwSyH(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCHF2n.VVlKug(self)
  if qUrl or "chCode" in iptvRef:
   p = CCTQO7()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVk5qZ(iptvRef)
   if valid:
    self.VVbyYs(self, host, mac)
    return
   elif qUrl:
    FFqcaP(self, BF(self.VVty48, title, qUrl), title="Checking Server ...")
    return
  FF1uaI(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVlKug(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF)
  qUrl = CCHF2n.VVahHL(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVahHL(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVty48(self, title, url):
  self.curUrl = url
  self.VVOsp7Data = {}
  qUrl = self.VV8qh5(self.VVt4MN, url)
  txt, err = self.VVl3JC(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVOsp7Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVOsp7Data["username"    ] = self.VVEbNz(item, "username"        )
    self.VVOsp7Data["password"    ] = self.VVEbNz(item, "password"        )
    self.VVOsp7Data["message"    ] = self.VVEbNz(item, "message"        )
    self.VVOsp7Data["auth"     ] = self.VVEbNz(item, "auth"         )
    self.VVOsp7Data["status"    ] = self.VVEbNz(item, "status"        )
    self.VVOsp7Data["exp_date"    ] = self.VVEbNz(item, "exp_date"    , isDate=True )
    self.VVOsp7Data["is_trial"    ] = self.VVEbNz(item, "is_trial"        )
    self.VVOsp7Data["active_cons"   ] = self.VVEbNz(item, "active_cons"       )
    self.VVOsp7Data["created_at"   ] = self.VVEbNz(item, "created_at"   , isDate=True )
    self.VVOsp7Data["max_connections"  ] = self.VVEbNz(item, "max_connections"      )
    self.VVOsp7Data["allowed_output_formats"] = self.VVEbNz(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVOsp7Data[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVOsp7Data["url"    ] = self.VVEbNz(item, "url"        )
    self.VVOsp7Data["port"    ] = self.VVEbNz(item, "port"        )
    self.VVOsp7Data["https_port"  ] = self.VVEbNz(item, "https_port"      )
    self.VVOsp7Data["server_protocol" ] = self.VVEbNz(item, "server_protocol"     )
    self.VVOsp7Data["rtmp_port"   ] = self.VVEbNz(item, "rtmp_port"       )
    self.VVOsp7Data["timezone"   ] = self.VVEbNz(item, "timezone"       )
    self.VVOsp7Data["timestamp_now"  ] = self.VVEbNz(item, "timestamp_now"  , isDate=True )
    self.VVOsp7Data["time_now"   ] = self.VVEbNz(item, "time_now"       )
    VVd21k  = self.VVaLqd(True)
    OKBtnFnc = self.VVd3Iw
    infoBtnFnc = self.VV8g0K
    VVZms0 = ("Home Menu", FFi0ku)
    VVHLqw= ("Add to Menu", BF(CCHF2n.VVUX7I, self, False, self.VVOsp7Data["playListURL"]))
    VVldmG = ("Bookmark Server", BF(CCHF2n.VVEAtL, self, False, self.VVOsp7Data["playListURL"]))
    FFxMT2(self, None, title="IPTV Server Resources", VVd21k=VVd21k, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVZms0=VVZms0, VVHLqw=VVHLqw, VVldmG=VVldmG)
   else:
    err = "Could not get data from server !"
  if err:
   FF1uaI(self, err, title=title)
  FFkxeT(self)
 def VVd3Iw(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFqcaP(menuInstance, BF(self.VVphy9, self.VVAupb  , title=title), title=wTxt)
   elif ref == "vod"   : FFqcaP(menuInstance, BF(self.VVphy9, self.VVMlZk  , title=title), title=wTxt)
   elif ref == "series"  : FFqcaP(menuInstance, BF(self.VVphy9, self.VV1Yih , title=title), title=wTxt)
   elif ref == "catchup"  : FFqcaP(menuInstance, BF(self.VVphy9, self.VVF2Xx , title=title), title=wTxt)
   elif ref == "accountInfo" : FFqcaP(menuInstance, BF(self.VVSgNz           , title=title), title=wTxt)
 def VV8g0K(self, menuInstance, txt, ref, ndx):
  FFX3Iv(self, self.curUrl + ("\n\n%s ... %s" % ({2:"Big", 3:"Sml"}.get(self.VVpnkz, ""), self.VVncsU) if VVCvlJ else ""), title="Current Server URL")
 def VVSgNz(self, title):
  rows = []
  for key, val in self.VVOsp7Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVTXPD
   else:
    num, part = "1", self.VVKGlz
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVDti0  = ("Home Menu", FFi0ku, [])
  VVZyxX  = None
  if VVCvlJ:
   VVZyxX = ("Get JS" , BF(self.VVxHVG, "/".join(self.VVOsp7Data["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FF8dRU(self, None, title=title, width=1200, header=header, VVHQsP=rows, VVje1O=widths, VVlvFD=26, VVDti0=VVDti0, VVZyxX=VVZyxX, VVW1CX="#0a00292B", VVLasp="#0a002126", VVHSOH="#0a002126", VVJqmr="#00000000", searchCol=2)
 def VVWIub(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VV9ibt = CCAOao()
    if mode in (self.VV3Rn0, self.VV2W68):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVEbNz(item, "num"         )
      name     = self.VVEbNz(item, "name"        )
      stream_id    = self.VVEbNz(item, "stream_id"       )
      stream_icon    = self.VVEbNz(item, "stream_icon"       )
      epg_channel_id   = self.VVEbNz(item, "epg_channel_id"      )
      added     = self.VVEbNz(item, "added"    , isDate=True )
      is_adult    = self.VVEbNz(item, "is_adult"       )
      category_id    = self.VVEbNz(item, "category_id"       )
      tv_archive    = self.VVEbNz(item, "tv_archive"       )
      direct_source   = self.VVEbNz(item, "direct_source"      )
      tv_archive_duration  = self.VVEbNz(item, "tv_archive_duration"     )
      name = VV9ibt.VVJBfo(name, is_adult)
      if name:
       if mode == self.VV3Rn0 or mode == self.VV2W68 and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVnbf9:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVEbNz(item, "num"         )
      name    = self.VVEbNz(item, "name"        )
      stream_id   = self.VVEbNz(item, "stream_id"       )
      stream_icon   = self.VVEbNz(item, "stream_icon"       )
      added    = self.VVEbNz(item, "added"    , isDate=True )
      is_adult   = self.VVEbNz(item, "is_adult"       )
      category_id   = self.VVEbNz(item, "category_id"       )
      container_extension = self.VVEbNz(item, "container_extension"     ) or "mp4"
      name = VV9ibt.VVJBfo(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVseBO:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVEbNz(item, "num"        )
      name    = self.VVEbNz(item, "name"       )
      series_id   = self.VVEbNz(item, "series_id"      )
      cover    = self.VVEbNz(item, "cover"       )
      genre    = self.VVEbNz(item, "genre"       )
      episode_run_time = self.VVEbNz(item, "episode_run_time"    )
      category_id   = self.VVEbNz(item, "category_id"      )
      container_extension = self.VVEbNz(item, "container_extension"    ) or "mp4"
      name = VV9ibt.VVJBfo(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVphy9(self, mode, title):
  cList, err = self.VVGzlD(mode)
  if cList and mode == self.VVF2Xx:
   cList = self.VVvhHY(cList)
  if err:
   FF1uaI(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km(mode)
   mName = self.VVD4Dd(mode)
   if   mode == self.VVAupb  : fMode = self.VV3Rn0
   elif mode == self.VVMlZk  : fMode = self.VVnbf9
   elif mode == self.VV1Yih : fMode = self.VVseBO
   elif mode == self.VVF2Xx : fMode = self.VV2W68
   if mode == self.VVF2Xx:
    VVQJvS = None
    VVOr9v = None
   else:
    VVQJvS = ("Find in %s" % mName , BF(self.VV31AQ, fMode, True) , [])
    VVOr9v = ("Find in Selected" , BF(self.VV31AQ, fMode, False) , [])
   VVmG3M   = ("Show List"   , BF(self.VV9cnm, mode)  , [])
   VVDti0  = ("Home Menu"   , FFi0ku         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF8dRU(self, None, title=title, width=1200, header=header, VVHQsP=cList, VVje1O=widths, VVlvFD=30, VVDti0=VVDti0, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVmG3M=VVmG3M, VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVHSOH, VVJqmr=VVJqmr, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FF1uaI(self, "No list from server !", title=title)
  FFkxeT(self)
 def VVGzlD(self, mode):
  qUrl  = self.VV8qh5(mode, self.VVOsp7Data["playListURL"])
  txt, err = self.VVl3JC(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VV9ibt = CCAOao()
    for item in tDict:
     category_id  = self.VVEbNz(item, "category_id"  )
     category_name = self.VVEbNz(item, "category_name" )
     parent_id  = self.VVEbNz(item, "parent_id"  )
     category_name = VV9ibt.VV9VQZ(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVvhHY(self, catList):
  mode  = self.VV2W68
  qUrl  = self.VV8qh5(mode, self.VVOsp7Data["playListURL"])
  txt, err = self.VVl3JC(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVWIub(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VV9cnm(self, mode, VVc7Yu, title, txt, colList):
  title = colList[1]
  FFqcaP(VVc7Yu, BF(self.VV0XDC, mode, VVc7Yu, title, txt, colList), title="Downloading ...")
 def VV0XDC(self, mode, VVc7Yu, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVD4Dd(mode) + " : "+ bName
  if   mode == self.VVAupb  : mode = self.VV3Rn0
  elif mode == self.VVMlZk  : mode = self.VVnbf9
  elif mode == self.VV1Yih : mode = self.VVseBO
  elif mode == self.VVF2Xx : mode = self.VV2W68
  qUrl  = self.VV8qh5(mode, self.VVOsp7Data["playListURL"], catID)
  txt, err = self.VVl3JC(qUrl)
  list  = []
  if not err and mode in (self.VV3Rn0, self.VVnbf9, self.VVseBO, self.VV2W68):
   list, err = self.VVWIub(mode, txt)
  if err:
   FF1uaI(self, err, title=title)
  elif list:
   VVDti0  = ("Home Menu"   , FFi0ku            , [])
   if mode in (self.VV3Rn0, self.VV2W68):
    VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km(mode)
    VVAe4b = (""     , BF(self.VVW2fZ, mode)      , [])
    VVZyxX = ("Download Options" , BF(self.VVZMcX, mode, "", "")   , [])
    VVQJvS = ("Options"   , BF(self.VVHBq0, "lv", mode, bName)   , [])
    VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, False)     , [])
    if mode == self.VV3Rn0:
     VVmG3M = ("Play"    , BF(self.VVBEef, mode)       , [])
    else:
     VVmG3M = ("Programs"   , BF(self.VVtcRm, mode, bName) , [])
   elif mode == self.VVnbf9:
    VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km(mode)
    VVmG3M  = ("Play"    , BF(self.VVBEef, mode)       , [])
    VVAe4b = (""     , BF(self.VVW2fZ, mode)      , [])
    VVZyxX = ("Download Options" , BF(self.VVZMcX, mode, "v", "")   , [])
    VVQJvS = ("Options"   , BF(self.VVHBq0, "v", mode, bName)   , [])
    VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, False)     , [])
   elif mode == self.VVseBO:
    VVW1CX, VVLasp, VVHSOH, VVJqmr = self.VV92km("series2")
    VVmG3M  = ("Show Seasons"  , BF(self.VVibdM, mode)       , [])
    VVAe4b = (""     , BF(self.VVB6wy, mode)     , [])
    VVZyxX = None
    VVQJvS = None
    VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, True)      , [])
   header, widths, VV4tj2 = self.VVLK66(mode)
   FF8dRU(self, None, title=title, header=header, VVHQsP=list, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindIptv, VVAe4b=VVAe4b, VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVHSOH, VVJqmr=VVJqmr, VVDYPP=True, searchCol=1)
  else:
   FF1uaI(self, "No Channels found !", title=title)
  FFkxeT(self)
 def VVLK66(self, mode):
  if mode in (self.VV3Rn0, self.VV2W68):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VV4tj2  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVnbf9:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VV4tj2  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVseBO:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VV4tj2  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VV4tj2
 def VVtcRm(self, mode, bName, VVc7Yu, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVOsp7Data["playListURL"]
  ok_fnc  = BF(self.VV2S0I, hostUrl, chName, catId, streamId)
  FFqcaP(VVc7Yu, BF(CCHF2n.VVpmY1, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VV2S0I(self, chUrl, chName, catId, streamId, VVc7Yu, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCHF2n.VVh60f(chUrl)
   chNum = "333"
   refCode = CCHF2n.VVKGWh(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFxZcp(self, chUrl, VVY2Q7=False)
   CCqzRz.VVfphk(self.session)
  else:
   FF1uaI(self, "Incorrect Timestamp", pTitle)
 def VVibdM(self, mode, VVc7Yu, title, txt, colList):
  title = colList[1]
  FFqcaP(VVc7Yu, BF(self.VVa2yt, mode, VVc7Yu, title, txt, colList), title="Downloading ...")
 def VVa2yt(self, mode, VVc7Yu, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV8qh5(self.VVN0H5, self.VVOsp7Data["playListURL"], series_id)
  txt, err = self.VVl3JC(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVEbNz(tDict["info"], "name"   )
      category_id = self.VVEbNz(tDict["info"], "category_id" )
      icon  = self.VVEbNz(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VV9ibt = CCAOao()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVEbNz(EP, "id"     )
        episode_num   = self.VVEbNz(EP, "episode_num"   )
        epTitle    = self.VVEbNz(EP, "title"     )
        container_extension = self.VVEbNz(EP, "container_extension" )
        seasonNum   = self.VVEbNz(EP, "season"    )
        epTitle = VV9ibt.VVJBfo(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF1uaI(self, err, title=title)
  elif list:
   VVDti0 = ("Home Menu"   , FFi0ku          , [])
   VVZyxX = ("Download Options" , BF(self.VVZMcX, mode, "s", title), [])
   VVQJvS = ("Options"   , BF(self.VVHBq0, "s", mode, title) , [])
   VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, False)   , [])
   VVAe4b = (""     , BF(self.VVW2fZ, mode)    , [])
   VVmG3M  = ("Play"    , BF(self.VVBEef, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV4tj2  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF8dRU(self, None, title=title, header=header, VVHQsP=list, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVDti0=VVDti0, VVZyxX=VVZyxX, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindIptv, VVW1CX="#0a00292B", VVLasp="#0a002126", VVHSOH="#0a002126", VVJqmr="#00000000")
  else:
   FF1uaI(self, "No Channels found !", title=title)
  FFkxeT(self)
 def VV31AQ(self, mode, isAll, VVc7Yu, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVd21k = []
  VVd21k.append(("Keyboard"  , "manualEntry"))
  VVd21k.append(("From Filter" , "fromFilter"))
  FFxMT2(self, BF(self.VVc6Yk, VVc7Yu, mode, onlyCatID), title="Input Type", VVd21k=VVd21k, width=400)
 def VVc6Yk(self, VVc7Yu, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFX1El(self, BF(self.VVFib4, VVc7Yu, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC4Wdl(self)
    filterObj.VVIRm0(BF(self.VVFib4, VVc7Yu, mode, onlyCatID))
 def VVFib4(self, VVc7Yu, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFWvPK(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CC4Wdl.VV610T(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FF1uaI(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FF1uaI(self, "All words must be at least 3 characters !", title=title)
        return
     VV9ibt = CCAOao()
     if CFG.hideIptvServerAdultWords.getValue() and VV9ibt.VVPCQa(words):
      FF1uaI(self, VV9ibt.VVD1ic(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CC8PiB, barTheme=CC8PiB.VVchq1
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVIWMP, VVc7Yu, mode, onlyCatID, title, words, toFind, asPrefix, VV9ibt)
          , VVXlAY = BF(self.VVzDqQ, mode, toFind, title))
   if not words:
    FFkxeT(VVc7Yu, "Nothing to find !", 1500)
 def VVIWMP(self, VVc7Yu, mode, onlyCatID, title, words, toFind, asPrefix, VV9ibt, VVTb2z):
  VVTb2z.VViTTm(VVc7Yu.VVpm2D() if onlyCatID is None else 1)
  VVTb2z.VVc1Ja = []
  for row in VVc7Yu.VVgeCg():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VV3VHc(1)
   VVTb2z.VVQToQ(catName)
   qUrl  = self.VV8qh5(mode, self.VVOsp7Data["playListURL"], catID)
   txt, err = self.VVl3JC(qUrl)
   if not err:
    tList, err = self.VVWIub(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VV9ibt.VVJBfo(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVTb2z.VVc1Ja.append(item)
 def VVzDqQ(self, mode, toFind, title, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if VVc1Ja:
   title = self.VVwrOF(mode, toFind)
   if mode == self.VV3Rn0 or mode == self.VVnbf9:
    if mode == self.VVnbf9 : typ = "v"
    else          : typ = ""
    bName   = CCHF2n.VVKfmR(toFind)
    VVmG3M  = ("Play"     , BF(self.VVBEef, mode)     , [])
    VVZyxX = ("Download Options" , BF(self.VVZMcX, mode, typ, "") , [])
    VVQJvS = ("Options"   , BF(self.VVHBq0, "fnd", mode, bName), [])
    VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, False)   , [])
    VVAe4b = (""     , BF(self.VVW2fZ, mode)    , [])
   elif mode == self.VVseBO:
    VVmG3M  = ("Show Seasons"  , BF(self.VVibdM, mode)     , [])
    VVQJvS = None
    VVZyxX = None
    VVOr9v = ("Posters Mode"  , BF(self.VV7pzA, mode, True)    , [])
    VVAe4b = (""     , BF(self.VVB6wy, mode)   , [])
   VVDti0  = ("Home Menu"   , FFi0ku          , [])
   header, widths, VV4tj2 = self.VVLK66(mode)
   VVc7Yu = FF8dRU(self, None, title=title, header=header, VVHQsP=VVc1Ja, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVAe4b=VVAe4b, VVW1CX="#0a00292B", VVLasp="#0a002126", VVHSOH="#0a002126", VVJqmr="#00000000", VVDYPP=True, searchCol=1)
   if not VV5vtH:
    FFkxeT(VVc7Yu, "Stopped" , 1000)
  else:
   if VV5vtH:
    FF1uaI(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVSoTS(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VV3Rn0, self.VV2W68):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVnbf9:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFFnqK(chName)
  url = self.VVOsp7Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVh60f(url)
  refCode = self.VVKGWh(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVW2fZ(self, mode, VVc7Yu, title, txt, colList):
  FFqcaP(VVc7Yu, BF(self.VVhUbz, mode, VVc7Yu, title, txt, colList))
 def VVhUbz(self, mode, VVc7Yu, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVSoTS(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFdGDb(self, fncMode=CCfm5u.VVZf2X, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVB6wy(self, mode, VVc7Yu, title, txt, colList):
  FFqcaP(VVc7Yu, BF(self.VVidZD, mode, VVc7Yu, title, txt, colList))
 def VVidZD(self, mode, VVc7Yu, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFdGDb(self, fncMode=CCfm5u.VVIQyr, chName=name, text=txt, picUrl=Cover)
 def VV7pzA(self, mode, isSerNames, VVc7Yu, title, txt, colList):
  if   mode in ("itv"  , CCHF2n.VV3Rn0, CCHF2n.VV2W68): category = "live"
  elif mode in ("vod"  , CCHF2n.VVnbf9 )          : category = "vod"
  elif mode in ("series" , CCHF2n.VVseBO)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VV3Rn0 : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV2W68 : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVnbf9  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVseBO : picCol, descCol, descTxt = 5, 0, "Season"
  FFqcaP(VVc7Yu, BF(self.session.open, CCj8jX, VVc7Yu, category, nameCol, picCol, descCol, descTxt))
 def VVZMcX(self, mode, typ, seriesName, VVc7Yu, title, txt, colList):
  VVd21k = []
  isMulti = VVc7Yu.VVh7FN
  tot  = VVc7Yu.VVcONI()
  if isMulti:
   if tot < 1:
    FFkxeT(VVc7Yu, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVd21k.append(("Download %s PIcon%s" % (name, FFwHmW(tot)), "dnldPicons" ))
  if typ:
   VVd21k.append(VVNCuu)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVd21k.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVd21k.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVd21k.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCEVEE.VVBqxI():
    VVd21k.append(VVNCuu)
    VVd21k.append(("Download Manager"      , "dload_stat" ))
  FFxMT2(self, BF(self.VVnzo4, VVc7Yu, mode, typ, seriesName, colList), title="Download Options", VVd21k=VVd21k)
 def VVnzo4(self, VVc7Yu, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVGRA1(VVc7Yu, mode)
   elif item == "dnldSel"  : self.VVXOkM(VVc7Yu, mode, typ, colList, True)
   elif item == "addSel"  : self.VVXOkM(VVc7Yu, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVDdoX(VVc7Yu, mode, typ, seriesName)
   elif item == "dload_stat" : CCEVEE.VVBiV1(self)
 def VVXOkM(self, VVc7Yu, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVPI61(mode, typ, colList)
  if startDnld:
   CCEVEE.VVY7ba(self, decodedUrl)
  else:
   self.VV1J5c(VVc7Yu, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVDdoX(self, VVc7Yu, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVc7Yu.VVgeCg():
   chName, decodedUrl = self.VVPI61(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VV1J5c(VVc7Yu, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VV1J5c(self, VVc7Yu, title, chName, decodedUrl_list, startDnld):
  FFWV4g(self, BF(self.VV0uyK, VVc7Yu, decodedUrl_list, startDnld), chName, title=title)
 def VV0uyK(self, VVc7Yu, decodedUrl_list, startDnld):
  added, skipped = CCEVEE.VVAPh7(decodedUrl_list)
  FFkxeT(VVc7Yu, "Added", 1000)
 def VVPI61(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVSoTS(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVuhC3(mode, colList)
   refCode, chUrl = self.VVvs8A(self.VVinJa, self.VV8nIm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFowN4(chUrl)
  return chName, decodedUrl
 def VVGRA1(self, VVc7Yu, mode):
  if os.system(FFqAik("which ffmpeg")) == 0:
   self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVtuFU, VVc7Yu, mode)
       , VVXlAY = self.VVoPgm)
  else:
   FFWV4g(self, BF(CCHF2n.VV86xP, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVoPgm(self, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVc1Ja["proces"], VVc1Ja["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVc1Ja["ok"], VVc1Ja["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVc1Ja["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVc1Ja["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVc1Ja["badURL"]
  txt += "Download Failure\t: %d\n"   % VVc1Ja["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVc1Ja["path"]
  if not VV5vtH  : color = "#11402000"
  elif VVc1Ja["err"]: color = "#11201000"
  else     : color = None
  if VVc1Ja["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVc1Ja["err"], txt)
  title = "PIcons Download Result"
  if not VV5vtH:
   title += "  (cancelled)"
  FFX3Iv(self, txt, title=title, VVHSOH=color)
 def VVtuFU(self, VVc7Yu, mode, VVTb2z):
  isMulti = VVc7Yu.VVh7FN
  if isMulti : totRows = VVc7Yu.VVcONI()
  else  : totRows = VVc7Yu.VVpm2D()
  VVTb2z.VViTTm(totRows)
  VVTb2z.VVAV0s(0)
  counter     = VVTb2z.counter
  maxValue    = VVTb2z.maxValue
  pPath     = CCodIm.VVt98d()
  VVTb2z.VVc1Ja = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVc7Yu.VVgeCg()):
    if VVTb2z.isCancelled:
     break
    if not isMulti or VVc7Yu.VV5ag5(rowNum):
     VVTb2z.VVc1Ja["proces"] += 1
     VVTb2z.VV3VHc(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVuhC3(mode, row)
      refCode = CCHF2n.VVKGWh(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVrv3H(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVSoTS(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVTb2z.VVc1Ja["attempt"] += 1
       path, err = FFR3XR(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVTb2z:
         VVTb2z.VVc1Ja["ok"] += 1
         VVTb2z.VVAV0s(VVTb2z.VVc1Ja["ok"])
        if FF2oRJ(path) > 0:
         cmd = CCfm5u.VVMfHN(path)
         cmd += FFqAik("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVTb2z:
          VVTb2z.VVc1Ja["size0"] += 1
         FFC2Q5(path)
       elif err:
        if VVTb2z:
         VVTb2z.VVc1Ja["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVTb2z:
          VVTb2z.VVc1Ja["err"] = err.title()
         break
      else:
       if VVTb2z:
        VVTb2z.VVc1Ja["exist"] += 1
     else:
      if VVTb2z:
       VVTb2z.VVc1Ja["badURL"] += 1
  except:
   pass
 def VVqe26(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFqAik("which ffmpeg")) == 0:
   self.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
       , titlePrefix = ""
       , fncToRun  = self.VV6IQi
       , VVXlAY = BF(self.VVVSCT, title))
  else:
   FFWV4g(self, BF(CCHF2n.VV86xP, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VV6IQi(self, VVTb2z):
  bName = CCB8uV.VV16yi()
  pPath = CCodIm.VVt98d()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVTb2z.VVc1Ja = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCB8uV.VVDwLM()
  if not VVTb2z or VVTb2z.isCancelled:
   return
  if not services or len(services) == 0:
   VVTb2z.VVc1Ja = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVTb2z.VViTTm(totCh)
  VVTb2z.VVAV0s(0)
  for serv in services:
   if not VVTb2z or VVTb2z.isCancelled:
    return
   VVTb2z.VVc1Ja = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVTb2z.VV3VHc(1)
   VVTb2z.VVAV0s(totPic)
   fullRef  = serv[0]
   if FFkOAA(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFowN4(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCTQO7.VV18py(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCHF2n.VVPQqT(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCHF2n.VVl3JC(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCfm5u.VVtUkB(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFR3XR(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVTb2z:
     VVTb2z.VVAV0s(totPic)
    if FF2oRJ(path) > 0:
     cmd = CCfm5u.VVMfHN(path)
     cmd += FFqAik("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFC2Q5(path)
  if VVTb2z:
   VVTb2z.VVc1Ja = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVVSCT(self, title, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVc1Ja
  if err:
   FF1uaI(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFHqZk(str(totExist)  , VV0kWR)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFHqZk(str(totNotIptv)  , VV0kWR)
    if totServErr : txt += "Server Errors\t: %s\n" % FFHqZk(str(totServErr) + t1, VV0kWR)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFHqZk(str(totParseErr) , VV0kWR)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFHqZk(str(totInvServ)  , VV0kWR)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFHqZk(str(totInvPicUrl) , VV0kWR)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFHqZk(str(totSize0)  , VV0kWR)
   if not VV5vtH:
    title += "  (stopped)"
   FFX3Iv(self, txt, title=title)
 @staticmethod
 def VV86xP(SELF):
  cmd = FF5LxN(VVQGHq, "ffmpeg")
  if cmd : FFkyna(SELF, cmd, title="Installing FFmpeg")
  else : FF3PaD(SELF)
 @staticmethod
 def VVjLFE(SELF):
  SELF.session.open(CC8PiB, barTheme=CC8PiB.VVuGmU
      , titlePrefix = ""
      , fncToRun  = CCHF2n.VVRjUm
      , VVXlAY = BF(CCHF2n.VVpRbT, SELF))
 @staticmethod
 def VVRjUm(VVTb2z):
  bName = CCB8uV.VV16yi()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVTb2z.VVc1Ja = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCB8uV.VVDwLM()
  if not VVTb2z or VVTb2z.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVTb2z.VViTTm(totCh)
   for serv in services:
    if not VVTb2z or VVTb2z.isCancelled:
     return
    VVTb2z.VV3VHc(1)
    fullRef = serv[0]
    if FFkOAA(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFowN4(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCTQO7.VV18py(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCHF2n.VVPQqT(m3u_Url)
     if VVTb2z:
      VVTb2z.VVf1Qk(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCHF2n.VVtNec(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCTkbp.VVrWAC(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVTb2z:
     VVTb2z.VVc1Ja = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVTb2z.VVc1Ja = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVpRbT(SELF, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVc1Ja
  title = "IPTV EPG Import"
  if err:
   FF1uaI(SELF, err, title=title)
  else:
   if VV5vtH and totEpgOK > 0:
    CCTkbp.VVmAj4()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFHqZk(str(totNotIptv), VV0kWR)
    if totServErr : txt += "Server Errors\t: %s\n" % FFHqZk(str(totServErr) + t1, VV0kWR)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFHqZk(str(totInv), VV0kWR)
   if not VV5vtH:
    title += "  (stopped)"
   FFX3Iv(SELF, txt, title=title)
 @staticmethod
 def VVtNec(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCHF2n.VVh60f(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCHF2n.VVl3JC(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCHF2n.VVEbNz(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCHF2n.VVEbNz(item, "lang"        ).upper()
    now_playing   = CCHF2n.VVEbNz(item, "now_playing"      )
    start    = CCHF2n.VVEbNz(item, "start"        )
    start_timestamp  = CCHF2n.VVEbNz(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCHF2n.VVEbNz(item, "start_timestamp"     )
    stop_timestamp  = CCHF2n.VVEbNz(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCHF2n.VVEbNz(item, "stop_timestamp"      )
    tTitle    = CCHF2n.VVEbNz(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVKGWh(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCHF2n.VVDQx6(catID, MAX_4b)
  TSID = CCHF2n.VVDQx6(chNum, MAX_4b)
  ONID = CCHF2n.VVDQx6(chNum, MAX_4b)
  NS  = CCHF2n.VVDQx6(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVDQx6(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVKfmR(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VV92km(mode):
  if   mode in ("itv"  , CCHF2n.VVAupb)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCHF2n.VVMlZk)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCHF2n.VV1Yih) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCHF2n.VVF2Xx) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCHF2n.VV2W68    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVupuq(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVh5ZI:
   excl = FFflDg(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FF1uaI(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFjUOl('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FF1uaI(self, err)
  elif len(files) == 1 and files[0] == VVhfZS:
   FF1uaI(self, VVhfZS)
  else:
   return files
 @staticmethod
 def VVbUJz():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFjZE4(path)
  return "/"
 @staticmethod
 def VVpmY1(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCHF2n.VVtNec(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FF1uaI(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVW1CX, VVLasp, VVHSOH, VVJqmr = CCHF2n.VV92km("")
   VVDti0 = ("Home Menu" , FFi0ku, [])
   VVmG3M  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV4tj2  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FF8dRU(SELF, None, title="Programs for : " + chName, header=header, VVHQsP=pList, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=24, VVmG3M=VVmG3M, VVDti0=VVDti0, VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVHSOH, VVJqmr=VVJqmr)
  else:
   FF1uaI(SELF, "No Programs from server", title=title)
 @staticmethod
 def VV1eQd(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVUX7I(self, isPortal, line, VVFy7pObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFWV4g(self, BF(self.VV9fHQ, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFWvPK(confItem, line)
   FFfF2j(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV9fHQ(self, title, confItem):
  FFWvPK(confItem, "")
  FFfF2j(self, "Removed from IPTV Menu.", title=title)
 def VVIVc2(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVbyYs(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFqcaP(self, BF(self.VVty48, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FF1uaI(self, "Incorrect server data !")
 @staticmethod
 def VVEAtL(SELF, isPortal, line, VVFy7pObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCHF2n.VVbUJz()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF1uaI(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFfF2j(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF1uaI(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVHBq0(self, source, mode, curBName, VVc7Yu, title, txt, colList):
  isMulti = VVc7Yu.VVh7FN
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVc7Yu.VVcONI()
   totTxt = "%d Service%s" % (tot, FFwHmW(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFHqZk(totTxt, VVWFW6)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CC8qau(self, VVc7Yu, addSep=False)
  thTxt = "Adding Services ..."
  VVd21k, cbFncDict = [], None
  VVd21k.append(VVNCuu)
  if itemsOK:
   VVd21k.append(("Add %s to New Bouquet : %s"    % (totTxt, FFHqZk(curBName , VVs4yr)), "addToCur1"))
   if curBName2: VVd21k.append(("Add %s to New Bouquet : %s" % (totTxt, FFHqZk(curBName2, VVpihg)) , "addToCur2"))
   VVd21k.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFqcaP, mSel.VVc7Yu, BF(self.VVcgfK,source, mode, curBName , VVc7Yu, title), title=thTxt)
      , "addToCur2": BF(FFqcaP, mSel.VVc7Yu, BF(self.VVcgfK,source, mode, curBName2, VVc7Yu, title), title=thTxt)
      , "addToNew" : BF(self.VV5V3Y, source, mode, curBName, VVc7Yu, title)
      }
  else:
   VVd21k.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVyFGx(VVd21k, cbFncDict, width=1200)
 def VVcgfK(self, source, mode, curBName, VVc7Yu, Title):
  chUrlLst = self.VVr2qq(source, mode, VVc7Yu)
  CCB8uV.VVIyPW(self, Title, curBName, "", chUrlLst)
 def VV5V3Y(self, source, mode, curBName, VVc7Yu, Title):
  picker = CCB8uV(self, VVc7Yu, Title, BF(self.VVr2qq, source, mode, VVc7Yu), defBName=curBName)
 def VVr2qq(self, source, mode, VVc7Yu):
  totChange = 0
  isMulti = VVc7Yu.VVh7FN
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVc7Yu.VVgeCg()):
   if not isMulti or VVc7Yu.VV5ag5(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVuhC3(mode, row)
     refCode, chUrl = self.VVvs8A(self.VVinJa, self.VV8nIm, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVWc70(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVSoTS(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCI3oS(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VV4n9c(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFrI2P(self.frm, frmColor)
  FFrI2P(self.bak, bakColor)
  FFrI2P(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVdHOB(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFPwFt(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CC8Dpc(CCI3oS):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCI3oS.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VV66ms   ,
   "down" : self.VVs4n9  ,
   "left" : self.VV0XiC  ,
   "right" : self.VV2FzN  ,
   "next" : self.VVrz2e ,
   "last" : self.VVMmw5
  }, -1)
 def VVFFFd(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VV4n9c(x, y, w, h)
  self.VVp2af()
 def VVRimK(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VV66ms(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVcyk1()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV8sAb()
 def VVs4n9(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVW1Ik()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV8sAb()
 def VV0XiC(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVcyk1()
  else:
   self.curCol -= 1
   self.VV8sAb()
 def VV2FzN(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVW1Ik()
  else:
   self.curCol += 1
   self.VV8sAb()
 def VVMmw5(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV8sAb(True)
 def VVrz2e(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV8sAb(True)
 def VVW1Ik(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV8sAb(True)
 def VVcyk1(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV8sAb(True)
 def VV8sAb(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVIuCX = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVIuCX: self.curPage = VVIuCX
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVSDf3()
  self.VVdHOB(self.curPage + 1, self.totalPages)
  FFnCJX(BF(self.VVxFnC, force or not oldPage == self.curPage, VVIuCX))
 def VVxFnC(self, force, VVIuCX):
  if force:
   self.VV1cpW()
  if self.curPage == VVIuCX:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVSDf3()
  boxT, boxW, boxH = self.skinParam["extraPar"]
  self["myPiconPtr"].instance.move(ePoint(int(boxW * self.curCol), int(boxT + boxH * self.curRow)))
  self["myPiconPtr"].show()
 def VVxjEJ(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV8sAb(True)
  else:
   FFkxeT(self, "Not found", 1000)
 def VV9aB6(self):
  self["myPiconPtr"].hide()
 def VVqlNj(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VV2FzE(self):
  fg = bg = self.colorCfg.getValue()
  self.session.openWithCallback(self.VVMu0H, CCytJU, defFG=fg, defBG=bg, onlyBG=True)
 def VVMu0H(self, fg, bg):
  if bg:
   FFWvPK(self.colorCfg, bg)
   self.VVp2af()
 def VVp2af(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFrI2P(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
class CCj8jX(Screen, CC8Dpc):
 def __init__(self, session, VVc7Yu, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FF1pMw(VVO6R4, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVc7Yu  = VVc7Yu
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVHQsP    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFrOoX(self, self.Title)
  CC8Dpc.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VV4J76, subPath)
  if not pathExists(self.pPath):
   os.system(FFqAik("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVw6vF   ,
   "cancel": self.close   ,
   "menu" : self.VVt8tc,
   "info" : self.VVmjrS
  })
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  FFnQcA(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVFFFd()
  self.VVJgjs()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVt8tc(self):
  chName, subj, desc, fName, picUrl = self.VVHQsP[self.curIndex]
  VVd21k = []
  txt1 = "Show Poster/PIcon"
  txt2 = "Copy Poster/PIcon to Export-Directory"
  if fName:
   VVd21k.append((txt1, "VV4aUG" ))
   VVd21k.append((txt2, "VVSdHo"))
  else:
   VVd21k.append((txt1, ))
   VVd21k.append((txt2, ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Cache details"       , "VVDLH0"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Change Poster/Picon Transparency Color" , "VV2FzE" ))
  FFxMT2(self, self.VV8qTw, title=self.Title, VVd21k=VVd21k)
 def VV8qTw(self, item=None):
  if item is not None:
   if   item == "VVSdHo"   : self.VVSdHo()
   elif item == "VV4aUG"   : self.VV4aUG()
   elif item == "VVDLH0"  : FFqcaP(self, self.VVDLH0, title="Calculating ...")
   elif item == "VV2FzE" : self.VV2FzE()
 def VVw6vF(self):
  self.VVc7Yu.VVQ2AR(self.curIndex)
  self.VVc7Yu.VVWSf1()
 def VVmjrS(self):
  self.VVc7Yu.VVQ2AR(self.curIndex)
  self.VVc7Yu.VVuwSL()
 def VVJgjs(self):
  for colList in self.VVc7Yu.VVgeCg():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVHQsP.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVHQsP)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVc7Yu.VVbJrA()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VV8sAb(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVPBIf)
  except:
   self.timer.callback.append(self.VVPBIf)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV01X5)
  self.myThread.start()
 def VV01X5(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVHQsP):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFR3XR(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFqAik("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVHQsP[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVPBIf(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVpiVU + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVHQsP[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVHQsP[ndx] = (chName, subj, desc, fName, "")
     try:
      CCCBh0.VV586e(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV1cpW(self):
  self.VVqlNj()
  f1, f2 = self.VVRimK()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVHQsP[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VVrjWk + "iptv.png"
   try:
    CCCBh0.VV586e(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVSDf3(self):
  chName, subj, desc, fName, picUrl = self.VVHQsP[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV4aUG(self):
  chName, subj, desc, fName, picUrl = self.VVHQsP[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCpbjY.VVBCwU(self, self.pPath + fName)
  else          : FFkxeT(self, "File not found", 1500)
 def VVSdHo(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVHQsP[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFqAik("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FFfF2j(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FF1uaI(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FF1uaI(self, "No Poster/PIcon found", title=title)
 def VVDLH0(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VV4J76, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFlcvI("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCk3u6.VVeQ5q(size)
   txt += "%s\n    %s\n\n" % (FFHqZk(path, VVWFW6), size)
  mainPath = "%sPosters" % VV4J76
  totFiles = FFlcvI("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFwHmW(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFHqZk("Total space used by Posters/PIcons%s:" % totFTxt, VVsZ3Y), CCk3u6.VVeQ5q(totSize))
  mountPath = CCk3u6.VVxP1G(mainPath)
  if pathExists(mountPath):
   totSize  = CCk3u6.VV42fk(mountPath)
   freeSize = CCk3u6.VViGlx(mountPath)
   usedSize = CCk3u6.VVeQ5q(totSize - freeSize)
   totSize  = CCk3u6.VVeQ5q(totSize)
   freeSize = CCk3u6.VVeQ5q(freeSize)
   txt += "%s\n" % VVbL9B
   txt += FFHqZk("Media Space:\n", VVyuFD)
   txt += "    Media Path\t: %s\n" % FFHqZk(mountPath, VVRK3s)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFX3Iv(self, txt, title="Cache Used Size", height=1000)
class CCCBh0(Screen, CC8Dpc):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FF1pMw(VVO6R4, 1870, 1030, 50, 10, 10, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVHQsP    = lst
  FFrOoX(self, self.Title)
  CC8Dpc.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVw6vF   ,
   "cancel": self.close   ,
   "menu" : self.VV7mhp,
   "info" : self.VVzuGN
  })
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  FFnQcA(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVFFFd()
  self.totalItems = len(self.VVHQsP)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VV8sAb(True)
 def VV1cpW(self):
  self.VVqlNj()
  f1, f2 = self.VVRimK()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVHQsP[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVrjWk + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(os.path.splitext(os.path.basename(path))[0])
   lbl.show()
   pic.show()
   try:
    self.VV586e(pic, poster)
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV2zpD(self):
  path, movie, poster = self.VVHQsP[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVSDf3(self):
  path, poster = self.VV2zpD()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV7mhp(self):
  path, poster = self.VV2zpD()
  VVd21k = []
  VVd21k.append(("Go to movie ...", "VVUUWH"))
  VVd21k.append(VVNCuu)
  txt1 = "Show Poster"
  txt2 = "Copy Poster to Export-Directory"
  if poster:
   VVd21k.append((txt1, "VV4aUG" ))
   VVd21k.append((txt2, "VVSdHo"))
  else:
   VVd21k.append((txt1, ))
   VVd21k.append((txt2, ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Change Poster/Picon Transparency Color"  , "VV2FzE" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Change Poster (from current movie path) ..." , "VVrUHT1"  ))
  VVd21k.append(("Change Poster (locate manually) ..."   , "VVrUHT2"  ))
  FFxMT2(self, self.VVTaxB, title=self.Title, VVd21k=VVd21k)
 def VVTaxB(self, item=None):
  if item is not None:
   if   item == "VVUUWH"    : self.VVUUWH()
   elif item == "VVSdHo"    : self.VVSdHo()
   elif item == "VV4aUG"    : self.VV4aUG()
   elif item == "VV2FzE" : self.VV2FzE()
   elif item == "VVrUHT1"  : self.VVrUHT()
   elif item == "VVrUHT2"  : self.VVrUHT(True)
 def VVUUWH(self):
  VVG5ES = []
  for ndx, item in enumerate(self.VVHQsP):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVG5ES.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVG5ES.sort(key=lambda x: x[0].lower())
  VVmG3M = ("Select" , self.VVxVp3, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FF8dRU(self, None, title="Select Movie", width=1800, height=1000, header=header, VVHQsP=VVG5ES, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, lastFindConfigObj=CFG.lastFindMovie)
 def VVxVp3(self, VVc7Yu, title, txt, colList):
  self.VVxjEJ(int(colList[2].strip()))
  VVc7Yu.cancel()
 def VVw6vF(self):
  path, poster = self.VV2zpD()
  FFqcaP(self, BF(CCk3u6.VVVJhr, self, path), title="Playing Media ...")
 def VVzuGN(self):
  path, poster = self.VV2zpD()
  txt = "%s:\n%s\n\n" % (FFHqZk("Path", VVWFW6), path)
  size = FF2oRJ(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFHqZk("File Size", VVWFW6), CCk3u6.VVeQ5q(size))
  if poster:
   txt += "%s:\n%s" % (FFHqZk("Poster", VVWFW6), poster)
  FFX3Iv(self, txt, title="Movie Information")
 def VV4aUG(self):
  path, poster = self.VV2zpD()
  if fileExists(poster): CCpbjY.VVBCwU(self, poster)
  else     : FFkxeT(self, "No Poster", 1500)
 def VVSdHo(self):
  title = "Copy Poster"
  path, poster = self.VV2zpD()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   res = os.system(FFqAik("cp -f '%s' '%s'" % (poster, dstF)))
   if res == 0 : FFfF2j(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FF1uaI(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFkxeT(self, "No Poster", 1500)
 def VVrUHT(self, isManual=False):
  path, poster = self.VV2zpD()
  sDir = FFjZE4(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVlYvb, sDir, path), BF(CCk3u6, patternMode="poster", VVl4c7=sDir))
  else:
   VVd21k = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVd21k.append((os.path.basename(item), sDir + item))
   if VVd21k:
    VVd21k.sort(key=lambda x: x[0].lower())
    infoBtnFnc = self.VVm7XS
    FFxMT2(self, BF(self.VVlYvb, sDir, path), VVd21k=VVd21k, title="Posters", infoBtnFnc=infoBtnFnc, yellowBasePath=sDir)
   else:
    FFkxeT(self, "No jpg/png in current dir", 1500)
 def VVm7XS(self, menuInstance, txt, ref, ndx):
  CCpbjY.VVBCwU(self, VVffaB=ref)
 def VVlYvb(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   res = os.system(FFqAik("cp -f '%s' '%s'" % (pPath, newPath)))
   if res == 0 :
    self.VVHQsP[self.curIndex] = (self.VVHQsP[self.curIndex][0], self.VVHQsP[self.curIndex][1], os.path.basename(newPath))
    FFqcaP(self, self.VV1cpW)
   else:
    FFkxeT(self, "Cannot copy file", 1000)
 @staticmethod
 def VV586e(pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 @staticmethod
 def VVRBOY(SELF):
  eLst = CC9q9p.VVfYFN()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCCBh0, title, lst)
  else  : FF1uaI(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCj1BH(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FF1pMw(VVilCV, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VViW4K  = 0
  self.VVI8J0 = 1
  self.VV4SzW  = 2
  VVd21k = []
  VVd21k.append(("Find in All Service (from filter)" , "VV31PS" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Find in All (Manual Entry)"   , "VVjr6l"    ))
  VVd21k.append(("Find in TV"       , "VVNXeT"    ))
  VVd21k.append(("Find in Radio"      , "VVeHzZ"   ))
  if self.VVNQbt():
   VVd21k.append(VVNCuu)
   VVd21k.append(("Hide Channel: %s" % self.servName , "VVF7cy"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Zap History"       , "VVlsO4"    ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("IPTV Tools"       , "iptv"      ))
  VVd21k.append(("PIcons Tools"       , "PIconsTools"     ))
  VVd21k.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVd21k.append(("EPG Tools"       , "epgTools"     ))
  FFrOoX(self, VVd21k=VVd21k, title=title)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self)
  if self.isFindMode:
   self.VVy2Yr(self.VVzhy5())
 def VVw6vF(self):
  global VVhtbL
  VVhtbL = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVjr6l"    : self.VVjr6l()
   elif item == "VV31PS" : self.VV31PS()
   elif item == "VVNXeT"    : self.VVNXeT()
   elif item == "VVeHzZ"   : self.VVeHzZ()
   elif item == "VVF7cy"   : self.VVF7cy()
   elif item == "VVlsO4"    : self.VVlsO4()
   elif item == "iptv"       : self.session.open(CCHF2n)
   elif item == "PIconsTools"     : self.session.open(CCodIm)
   elif item == "ChannelsTools"    : self.session.open(CCDvzd)
   elif item == "epgTools"      : self.session.open(CCTkbp)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVNXeT(self) : self.VVy2Yr(self.VViW4K)
 def VVeHzZ(self) : self.VVy2Yr(self.VVI8J0)
 def VVjr6l(self) : self.VVy2Yr(self.VV4SzW)
 def VVy2Yr(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFX1El(self, BF(self.VVWcq4, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VV31PS(self):
  filterObj = CC4Wdl(self)
  filterObj.VVIRm0(self.VVocN0)
 def VVocN0(self, item):
  self.VVWcq4(self.VV4SzW, item)
 def VVNQbt(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFkOAA(self.refCode)        : return False
  return True
 def VVWcq4(self, mode, VVVUxx):
  FFqcaP(self, BF(self.VVcpgD, mode, VVVUxx), title="Searching ...")
 def VVcpgD(self, mode, VVVUxx):
  if VVVUxx:
   VVVUxx = VVVUxx.strip()
  if VVVUxx:
   self.findTxt = VVVUxx
   CFG.lastFindContextFind.setValue(VVVUxx)
   if   mode == self.VViW4K  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVI8J0 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVVUxx)
   if len(title) > 55:
    title = title[:55] + ".."
   VVG5ES = self.VVoLIF(VVVUxx, servTypes)
   if self.isFindMode or mode == self.VV4SzW:
    VVG5ES += self.VVh9No(VVVUxx)
   if VVG5ES:
    VVG5ES.sort(key=lambda x: x[0].lower())
    VVVD8O = self.VVpg3r
    VVmG3M  = ("Zap"   , self.VVUL4u    , [])
    VVZyxX = ("Current Service", self.VVV2dD , [])
    VVQJvS = ("Options"  , self.VV1DTW , [])
    VVAe4b = (""    , self.VVgegw , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV4tj2  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVVD8O=VVVD8O, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVAe4b=VVAe4b, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVy2Yr(self.VVzhy5())
    FFfF2j(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVoLIF(self, VVVUxx, servTypes):
  VVHQsP = CCDvzd.VV5MIw(servTypes)
  VVG5ES = []
  if VVHQsP:
   VVs3cZ, VVJsi9 = FFbUPg()
   tp = CCaOWR()
   words, asPrefix = CC4Wdl.VV610T(VVVUxx)
   colorYellow  = CCYElQ.VVVD33(VVsZ3Y)
   colorWhite  = CCYElQ.VVVD33(VVBNow)
   for s in VVHQsP:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFkQZJ(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVs3cZ:
        STYPE = VVJsi9[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVXUK2(refCode)
       if not "-S" in syst:
        sat = syst
       VVG5ES.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVG5ES
 def VVh9No(self, VVVUxx):
  VVVUxx = VVVUxx.lower()
  VVG5ES = []
  colorYellow  = CCYElQ.VVVD33(VVsZ3Y)
  colorWhite  = CCYElQ.VVVD33(VVBNow)
  for b in CCB8uV.VV8E3L():
   VVurIH  = b[0]
   VVF80t  = b[1].toString()
   VVKcnR = eServiceReference(VVF80t)
   VV9U4H = FFWeHh(VVKcnR)
   for service in VV9U4H:
    refCode  = service[0]
    if FFkOAA(refCode):
     servName = service[1]
     if VVVUxx in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVVUxx), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVG5ES.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVG5ES
 def VVzhy5(self):
  VV56ys = InfoBar.instance
  if VV56ys:
   VVd3D3 = VV56ys.servicelist
   if VVd3D3:
    return VVd3D3.mode == 1
  return self.VV4SzW
 def VVpg3r(self, VVc7Yu):
  self.close()
  VVc7Yu.cancel()
 def VVUL4u(self, VVc7Yu, title, txt, colList):
  FFxZcp(VVc7Yu, colList[2], VVY2Q7=False, checkParentalControl=True)
 def VVV2dD(self, VVc7Yu, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(VVc7Yu)
  if refCode:
   VVc7Yu.VVKO1o(2, FFFxlH(refCode, iptvRef, chName), True)
 def VV1DTW(self, VVc7Yu, title, txt, colList):
  servName = colList[0]
  mSel = CC8qau(self, VVc7Yu)
  VVd21k, cbFncDict = CCDvzd.VVzJBT(self, VVc7Yu, servName, 2)
  mSel.VVyFGx(VVd21k, cbFncDict)
 def VVgegw(self, VVc7Yu, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFdGDb(self, fncMode=CCfm5u.VVMKs8, refCode=refCode, chName=chName, text=txt)
 def VVF7cy(self):
  FFWV4g(self, self.VVNsLg, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVNsLg(self):
  ret = FFUH03(self.refCode, True)
  if ret:
   self.VVXUM7()
   self.close()
  else:
   FFkxeT(self, "Cannot change state" , 1000)
 def VVXUM7(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVlqun()
  except:
   self.VVTKMG()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFl4EX(self, serviceRef)
 def VVlqun(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV56ys = InfoBar.instance
   if VV56ys:
    VVd3D3 = VV56ys.servicelist
    if VVd3D3:
     hList = VVd3D3.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVd3D3.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVd3D3.history  = newList
       VVd3D3.history_pos = pos
 def VVTKMG(self):
  VV56ys = InfoBar.instance
  if VV56ys:
   VVd3D3 = VV56ys.servicelist
   if VVd3D3:
    VVd3D3.history  = []
    VVd3D3.history_pos = 0
 def VVlsO4(self):
  VV56ys = InfoBar.instance
  VVG5ES = []
  if VV56ys:
   VVd3D3 = VV56ys.servicelist
   if VVd3D3:
    VVs3cZ, VVJsi9 = FFbUPg()
    for serv in VVd3D3.history:
     refCode = serv[-1].toString()
     chName = FFyJel(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFkOAA(refCode)
     isSRel = FFqc3z(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFkQZJ(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVs3cZ:
       STYPE = VVJsi9[sTypeInt]
     VVG5ES.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVG5ES:
   VVmG3M  = ("Zap"   , self.VVBWKV   , [])
   VVQJvS = ("Clear History" , self.VVOBXy   , [])
   VVAe4b = (""    , self.VV98zc , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV4tj2  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, VVmG3M=VVmG3M, VVQJvS=VVQJvS, VVAe4b=VVAe4b)
  else:
   FFfF2j(self, "Not found", title=title)
 def VVBWKV(self, VVc7Yu, title, txt, colList):
  FFxZcp(VVc7Yu, colList[3], VVY2Q7=False, checkParentalControl=True)
 def VVOBXy(self, VVc7Yu, title, txt, colList):
  FFWV4g(self, BF(self.VVg2do, VVc7Yu), "Clear Zap History ?")
 def VVg2do(self, VVc7Yu):
  self.VVTKMG()
  VVc7Yu.cancel()
 def VV98zc(self, VVc7Yu, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFdGDb(self, fncMode=CCfm5u.VVaRGG, refCode=refCode, chName=chName, text=txt)
class CCodIm(Screen, CC8Dpc):
 VVRGec   = 0
 VV12vB  = 1
 VVhWte  = 2
 VVOnSy  = 3
 VVivDt  = 4
 VV3dRb  = 5
 VVH49I  = 6
 VV9SoV  = 7
 VVahf9 = 8
 VVI8n6 = 9
 VV5Vrr = 10
 VV96Pg = 11
 def __init__(self, session):
  self.skin, self.skinParam = FF1pMw(VVpxLn, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCodIm.VVt98d()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVHQsP    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFrOoX(self, self.Title)
  FFddoJ(self["keyRed"] , "OK = Zap")
  FFddoJ(self["keyGreen"] , "Current Service")
  FFddoJ(self["keyYellow"], "Page Options")
  FFddoJ(self["keyBlue"] , "Filter")
  CC8Dpc.__init__(self, 5, 7, CFG.transpColorPicons)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVKSJN     ,
   "green"  : self.VVLUbE    ,
   "yellow" : self.VVF9fu     ,
   "blue"  : self.VVIpAi     ,
   "menu"  : self.VVgvRU     ,
   "info"  : self.VVVa0g    ,
   "pageUp" : BF(self.VVNSoH, True) ,
   "chanUp" : BF(self.VVNSoH, True) ,
   "pageDown" : BF(self.VVNSoH, False) ,
   "chanDown" : BF(self.VVNSoH, False) ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  FFnQcA(self)
  FFrI2P(self["keyRed"], "#0a333333")
  self.VVFFFd()
  self.VV9aB6()
  FFqcaP(self, BF(self.VVs3rH, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVgvRU(self):
  if not self.isBusy:
   VVd21k = []
   VVd21k.append(("Statistics"           , "VVdrDv"    ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Suggest PIcons for Current Channel"     , "VVZeVK"   ))
   VVd21k.append(("Set to Current Channel (copy file)"     , "VVOjEk_file"  ))
   VVd21k.append(("Set to Current Channel (as SymLink)"     , "VVOjEk_link"  ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Export Current File Names List"      , "VVU01A" ))
   VVd21k.append(CCodIm.VV0AND())
   VVd21k.append(VVNCuu)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVHeSZ
    VVd21k.append((c + movTxt           , "VVR9ne"  ))
    VVd21k.append((c + delTxt           , "VVQow3" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVd21k.append((movTxt + disTxt         ,       ))
    VVd21k.append((delTxt + disTxt         ,       ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVxt51"  ))
   VVd21k.append(VVNCuu)
   VVd21k += CCodIm.VVhd6M()
   VVd21k.append(VVNCuu)
   VVd21k.append(("Change Poster/Picon Transparency Color"    , "VV2FzE" ))
   VVd21k.append(("Keys Help"           , "VVcekz"    ))
   FFxMT2(self, self.VVhF4L, width=1100, height=1050, title=self.Title, VVd21k=VVd21k)
 def VVhF4L(self, item=None):
  if item is not None:
   if   item == "VVdrDv"     : self.VVdrDv()
   elif item == "VVZeVK"    : self.VVZeVK()
   elif item == "VVOjEk_file"   : self.VVOjEk(0)
   elif item == "VVOjEk_link"   : self.VVOjEk(1)
   elif item == "VVU01A"   : self.VVU01A()
   elif item == "VVTqX4"   : CCodIm.VVTqX4(self)
   elif item == "VVR9ne"    : self.VVR9ne()
   elif item == "VVQow3"   : self.VVQow3()
   elif item == "VVxt51"   : self.VVxt51()
   elif item == "VVuZzW"   : CCodIm.VVuZzW(self)
   elif item == "findPiconBrokenSymLinks"  : CCodIm.VVs1xD(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCodIm.VVs1xD(self, False)
   elif item == "VV2FzE"  : self.VV2FzE()
   elif item == "VVcekz"      : FFkKs9(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVF9fu(self):
  if not self.isBusy:
   VVd21k = []
   VVd21k.append(("Go to First PIcon"  , "VVW1Ik"  ))
   VVd21k.append(("Go to Last PIcon"   , "VVcyk1"  ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Sort by Channel Name"     , "sortByChan" ))
   VVd21k.append(("Sort by File Name"  , "sortByFile" ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Find from File List .." , "VVVt3i" ))
   FFxMT2(self, self.VViGH4, title=self.Title, VVd21k=VVd21k)
 def VViGH4(self, item=None):
  if item is not None:
   if   item == "VVW1Ik"   : self.VVW1Ik()
   elif item == "VVcyk1"   : self.VVcyk1()
   elif item == "sortByChan"  : self.VV8WRG(2)
   elif item == "sortByFile"  : self.VV8WRG(0)
   elif item == "VVVt3i"  : self.VVVt3i()
 def VVVt3i(self):
  VVd21k = []
  for item in self.VVHQsP:
   VVd21k.append((item[0], item[0]))
  FFxMT2(self, self.VVV8tf, title='PIcons ".png" Files', VVd21k=VVd21k, VVL2h3=True)
 def VVV8tf(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVxjEJ(ndx)
 def VVKSJN(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVI50w()
   if refCode:
    FFxZcp(self, refCode)
    self.VVm0cy()
    self.VVSDf3()
 def VVNSoH(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVm0cy()
   self.VVSDf3()
  except:
   pass
 def VVLUbE(self):
  if self["keyGreen"].getVisible():
   self.VVxjEJ(self.curChanIndex)
 def VV8WRG(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFqcaP(self, BF(self.VVs3rH, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVOjEk(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVI50w()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVd21k = []
     VVd21k.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVd21k.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFxMT2(self, BF(self.VVcev9, mode, curChF, selPiconF), VVd21k=VVd21k, title="Current Channel PIcon (already exists)")
    else:
     self.VVcev9(mode, curChF, selPiconF, "overwrite")
   else:
    FF1uaI(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF1uaI(self, "Could not read current channel info. !", title=title)
 def VVcev9(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFqcaP(self, BF(self.VVs3rH, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVR9ne(self):
  defDir = FFjZE4(CCodIm.VVt98d() + "picons_backup")
  os.system(FFqAik("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVy6Og, defDir), BF(CCk3u6
         , mode=CCk3u6.VV0IRk, VVl4c7=CCodIm.VVt98d()))
 def VVy6Og(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCodIm.VVt98d():
    FF1uaI(self, "Cannot move to same directory !", title=title)
   else:
    if not FFjZE4(path) == FFjZE4(defDir):
     self.VVoT9f(defDir)
    FFWV4g(self, BF(FFqcaP, self, BF(self.VV7HVa, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVHQsP), path), title=title)
  else:
   self.VVoT9f(defDir)
 def VV7HVa(self, title, defDir, toPath):
  if not iMove:
   self.VVoT9f(defDir)
   FF1uaI(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFjZE4(toPath)
  pPath = CCodIm.VVt98d()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVHQsP:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVHQsP)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFX3Iv(self, txt, title=title, VVHSOH="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VViHRJ("all")
 def VVoT9f(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVQow3(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVHQsP)
  FFWV4g(self, BF(FFqcaP, self, BF(self.VV0f66, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFwHmW(tot)), title=title)
 def VV0f66(self, title):
  pPath = CCodIm.VVt98d()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVHQsP:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVHQsP)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFHqZk(str(totErr), VV0kWR)
  FFX3Iv(self, txt, title=title)
 def VVxt51(self):
  lines = FFjUOl("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFWV4g(self, BF(self.VVcT63, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFwHmW(tot)), VVwjVK=True)
  else:
   FFfF2j(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVcT63(self, fList):
  os.system(FFqAik("find -L '%s' -type l -delete" % self.pPath))
  FFfF2j(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVVa0g(self):
  FFqcaP(self, self.VV25fZ)
 def VV25fZ(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVI50w()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFHqZk("PIcon Directory:\n", VVpihg)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFZQBS(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFZQBS(path)
   txt += FFHqZk("PIcon File:\n", VVpihg)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFHqZk("Found %d SymLink%s to this file from:\n" % (tot, FFwHmW(tot)), VVpihg)
     for fPath in slLst:
      txt += "  %s\n" % FFHqZk(fPath, VVekE1)
     txt += "\n"
   if chName:
    txt += FFHqZk("Channel:\n", VVpihg)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFHqZk(chName, VVs4yr)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFHqZk("Remarks:\n", VVpihg)
    txt += "  %s\n" % FFHqZk("Unused", VV0kWR)
  else:
   txt = "No info found"
  FFdGDb(self, fncMode=CCfm5u.VV9zVJ, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVI50w(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVHQsP[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFx433(sat)
  return fName, refCode, chName, sat, inDB
 def VVm0cy(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVHQsP):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVSDf3(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVI50w()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFHqZk("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVpihg))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVI50w()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFqc3z(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFHqZk(self.curChanName, VVsZ3Y)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVI50w()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVdrDv(self):
  VVs3cZ, VVJsi9 = FFbUPg()
  sTypeNameDict = {}
  for key, val in VVJsi9.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVHQsP:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVJsi9: sTypeDict[VVJsi9[stNum]] = sTypeDict.get(VVJsi9[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFlcvI("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVG5ES = []
  c = "#b#11003333#"
  VVG5ES.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVG5ES.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVG5ES.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVG5ES.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVG5ES.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVG5ES.append((c + "Satellites"    , str(len(self.nsList))))
  VVG5ES.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVG5ES.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVG5ES.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVG5ES.extend(sTypeRows)
  FF8dRU(self, None, title=self.Title, VVHQsP=VVG5ES, VVlvFD=28, VVJqmr="#00003333", VVFNoD="#00222222")
 def VVU01A(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFjZE4(CFG.exportedTablesPath.getValue()), txt, FF5Vj3())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVHQsP:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFfF2j(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVIpAi(self):
  if not self.isBusy:
   VVd21k = []
   VVd21k.append(("All"         , "all"   ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Used by Channels"      , "used"  ))
   VVd21k.append(("Unused PIcons"      , "unused"  ))
   VVd21k.append(("IPTV PIcons"       , "iptv"  ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("PIcons Files"       , "pFiles"  ))
   VVd21k.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVd21k.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVd21k.append(("By Files Date ..."     , "pDate"  ))
   VVd21k.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVd21k.append(FFnwrX("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFaiFy(val)
      VVd21k.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC4Wdl(self)
   filterObj.VVeblc(VVd21k, self.nsList, self.VV9EYM)
 def VV9EYM(self, item=None):
  if item is not None:
   self.VViHRJ(item)
 def VViHRJ(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVRGec   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV12vB   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVhWte  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVH49I   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVOnSy  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVivDt  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV3dRb  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV5Vrr , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VV96Pg , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VV9SoV   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVahf9 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV3dRb:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFjUOl("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FF4Cf3(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFkxeT(self, "Not found", 1000)
     return
   elif mode == self.VV5Vrr:
    self.VVbXGt(mode)
    return
   elif mode == self.VV96Pg:
    self.VVJLnm(mode)
    return
   elif mode == self.VVI8n6:
    return
   else:
    words, asPrefix = CC4Wdl.VV610T(words)
   if not words and mode in (self.VV9SoV, self.VVahf9):
    FFkxeT(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFqcaP(self, BF(self.VVs3rH, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVbXGt(self, mode):
  VVd21k = []
  VVd21k.append(("Today"   , "today" ))
  VVd21k.append(("Since Yesterday" , "yest" ))
  VVd21k.append(("Since 7 days"  , "week" ))
  FFxMT2(self, BF(self.VVcTQU, mode), VVd21k=VVd21k, title="Filter by Added/Modified Date")
 def VVcTQU(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFjBZO(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFjBZO(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFjBZO(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFqcaP(self, BF(self.VVs3rH, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVJLnm(self, mode):
  VVs3cZ, VVJsi9 = FFbUPg()
  lst = set()
  for key, val in VVJsi9.items():
   lst.add(val)
  VVd21k = []
  for item in lst:
   VVd21k.append((item, item))
  VVd21k.sort(key=lambda x: x[0])
  FFxMT2(self, BF(self.VVNCOL, mode), VVd21k=VVd21k, title="Filter by Service Type")
 def VVNCOL(self, mode, item=None):
  if item:
   VVs3cZ, VVJsi9 = FFbUPg()
   sTypeList = []
   for key, val in VVJsi9.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFqcaP(self, BF(self.VVs3rH, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVZeVK(self):
  self.session.open(CC8PiB, barTheme=CC8PiB.VVchq1
      , titlePrefix = ""
      , fncToRun  = self.VVHZ7y
      , VVXlAY = self.VVvYNk)
 def VVHZ7y(self, VVTb2z):
  VVQzz4, err = CCDvzd.VVReux(self, CCDvzd.VVRKv2, VVp4O4=False, VVFu5u=False)
  files = []
  words = []
  if not VVTb2z or VVTb2z.isCancelled:
   return
  VVTb2z.VVc1Ja = []
  VVTb2z.VViTTm(len(VVQzz4))
  if VVQzz4:
   VV9ibt = CCAOao()
   curCh = VV9ibt.VVHGDn(self.curChanName)
   for refCode in VVQzz4:
    if not VVTb2z or VVTb2z.isCancelled:
     return
    VVTb2z.VV3VHc(1, True)
    chName, sat, inDB = VVQzz4.get(refCode, ("", "", 0))
    ratio = CCodIm.VVJvTp(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCodIm.VV0Kqw(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FF4Cf3(f)
       fil = f.replace(".png", "")
       if not fil in VVTb2z.VVc1Ja:
        VVTb2z.VVc1Ja.append(fil)
 def VVvYNk(self, VV5vtH, VVc1Ja, threadCounter, threadTotal, threadErr):
  if VVc1Ja : FFqcaP(self, BF(self.VVs3rH, mode=self.VVI8n6, words=VVc1Ja), title="Loading ...")
  else   : FFkxeT(self, "Not found", 2000)
 def VVs3rH(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVm57l(isFirstTime):
   return
  self.isBusy = True
  VVFu5u = True if isFirstTime else False
  VVQzz4, err = CCDvzd.VVReux(self, CCDvzd.VVRKv2, VVp4O4=False, VVFu5u=VVFu5u)
  if err:
   self.close()
  iptvRefList = self.VVrjN8()
  tList = []
  for fName, fType in CCodIm.VVTSTs(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVQzz4:
    if fName in VVQzz4:
     chName, sat, inDB = VVQzz4.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVRGec:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV12vB  and chName         : isAdd = True
   elif mode == self.VVhWte and not chName        : isAdd = True
   elif mode == self.VVOnSy  and fType == 0        : isAdd = True
   elif mode == self.VVivDt  and fType == 1        : isAdd = True
   elif mode == self.VV3dRb  and fName in words       : isAdd = True
   elif mode == self.VVI8n6 and fName in words       : isAdd = True
   elif mode == self.VVH49I  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VV9SoV  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVahf9:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV5Vrr:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VV96Pg:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVHQsP   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFkxeT(self)
  else:
   self.isBusy = False
   FFkxeT(self, "Not found", 1000)
   return
  self.VVHQsP.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVm0cy()
  self.totalItems = len(self.VVHQsP)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VV8sAb(True)
 def VVm57l(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCodIm.VVTSTs(self.pPath):
    if fName:
     return True
   if isFirstTime : FF1uaI(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFkxeT(self, "Not found", 1000)
  else:
   FF1uaI(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVrjN8(self):
  VVG5ES = {}
  files  = CCHF2n.VVS8Qr()
  if files:
   for path in files:
    txt = FFnMVE(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVG5ES[refCode] = item[1]
  return VVG5ES
 def VV1cpW(self):
  self.VVqlNj()
  f1, f2 = self.VVRimK()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVHQsP[ndx]
   fName = self.VVHQsP[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFHqZk(chName, VVs4yr))
    else : lbl.setText("-")
   except:
    lbl.setText(FFHqZk(chName, VVpZn3))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVJvTp(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV0AND():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVTqX4"   )
 @staticmethod
 def VVhd6M():
  VVd21k = []
  VVd21k.append(("Find SymLinks (to PIcon Directory)"   , "VVuZzW"   ))
  VVd21k.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVd21k.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVd21k
 @staticmethod
 def VVTqX4(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF)
  png, path = CCodIm.VV39mx(refCode)
  if path : CCodIm.VVZY35(SELF, png, path)
  else : FF1uaI(SELF, "No PIcon found for current channel in:\n\n%s" % CCodIm.VVt98d())
 @staticmethod
 def VVuZzW(SELF):
  if VVsZ3Y:
   sed1 = FFDB5L("->", VVsZ3Y)
   sed2 = FFDB5L("picon", VV0kWR)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVpZn3, VVBNow)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF3Yso(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFflDg(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVs1xD(SELF, isPIcon):
  sed1 = FFDB5L("->", VVpZn3)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFDB5L("picon", VV0kWR)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF3Yso(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFflDg(), grep, sed1, sed2))
 @staticmethod
 def VVTSTs(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVt98d():
  path = CFG.PIconsPath.getValue()
  return FFjZE4(path)
 @staticmethod
 def VV39mx(refCode, chName=None):
  if FFkOAA(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFowN4(refCode)
  allPath, fName, refCodeFile, pList = CCodIm.VV0Kqw(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVZY35(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFDB5L("%s%s" % (dest, png), VVs4yr))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFDB5L(errTxt, VVpiVU))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFVBAP(SELF, cmd)
 @staticmethod
 def VV0Kqw(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCodIm.VVt98d()
   pList = []
   lst = FF6jDI(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFFnqK(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FF4Cf3(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCu6cR():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVZ3n5  = None
  self.VViGn5 = ""
  self.VVDxDf  = noService
  self.VVKIoZ = 0
  self.VVhHEi  = noService
  self.VVQ7pb = 0
  self.VV24rg  = "-"
  self.VVKZp3 = 0
  self.VVVMp5  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVnKaY(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVZ3n5 = frontEndStatus
     self.VVbnLV()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVbnLV(self):
  if self.VVZ3n5:
   val = self.VVZ3n5.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VViGn5 = "%3.02f dB" % (val / 100.0)
   else         : self.VViGn5 = ""
   val = self.VVZ3n5.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVKIoZ = int(val)
   self.VVDxDf  = "%d%%" % val
   val = self.VVZ3n5.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVQ7pb = int(val)
   self.VVhHEi  = "%d%%" % val
   val = self.VVZ3n5.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV24rg  = "%d" % val
   val = int(val * 100 / 500)
   self.VVKZp3 = min(500, val)
   val = self.VVZ3n5.get("tuner_locked", 0)
   if val == 1 : self.VVVMp5 = "Locked"
   else  : self.VVVMp5 = "Not locked"
 def VV7uOC(self)   : return self.VViGn5
 def VVhdJp(self)   : return self.VVDxDf
 def VVKOyn(self)  : return self.VVKIoZ
 def VVJIyp(self)   : return self.VVhHEi
 def VVOR4f(self)  : return self.VVQ7pb
 def VVlik0(self)   : return self.VV24rg
 def VVDCOH(self)  : return self.VVKZp3
 def VVEegB(self)   : return self.VVVMp5
 def VVIeEz(self) : return self.serviceName
class CCaOWR():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVi24o(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFnNb7(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVRr5h(self.ORPOS  , mod=1   )
      self.sat2  = self.VVRr5h(self.ORPOS  , mod=2   )
      self.freq  = self.VVRr5h(self.FREQ  , mod=3   )
      self.sr   = self.VVRr5h(self.SR   , mod=4   )
      self.inv  = self.VVRr5h(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVRr5h(self.POL  , self.D_POL )
      self.fec  = self.VVRr5h(self.FEC  , self.D_FEC )
      self.syst  = self.VVRr5h(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVRr5h("modulation" , self.D_MOD )
       self.rolof = self.VVRr5h("rolloff"  , self.D_ROLOF )
       self.pil = self.VVRr5h("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVRr5h("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVRr5h("pls_code"  )
       self.iStId = self.VVRr5h("is_id"   )
       self.t2PlId = self.VVRr5h("t2mi_plp_id" )
       self.t2PId = self.VVRr5h("t2mi_pid"  )
 def VVRr5h(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFaiFy(val)
  elif mod == 2   : return FFJASh(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVhwrs(self, refCode):
  txt = ""
  self.VVi24o(refCode)
  if self.data:
   def VV0iDg(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV0iDg("System"   , self.syst)
    txt += VV0iDg("Satellite"  , self.sat2)
    txt += VV0iDg("Frequency"  , self.freq)
    txt += VV0iDg("Inversion"  , self.inv)
    txt += VV0iDg("Symbol Rate"  , self.sr)
    txt += VV0iDg("Polarization" , self.pol)
    txt += VV0iDg("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV0iDg("Modulation" , self.mod)
     txt += VV0iDg("Roll-Off" , self.rolof)
     txt += VV0iDg("Pilot"  , self.pil)
     txt += VV0iDg("Input Stream", self.iStId)
     txt += VV0iDg("T2MI PLP ID" , self.t2PlId)
     txt += VV0iDg("T2MI PID" , self.t2PId)
     txt += VV0iDg("PLS Mode" , self.plsMod)
     txt += VV0iDg("PLS Code" , self.plsCod)
   else:
    txt += VV0iDg("System"   , self.txMedia)
    txt += VV0iDg("Frequency"  , self.freq)
  return txt, self.namespace
 def VVGlqs(self, refCode):
  txt = "Transpoder : ?"
  self.VVi24o(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVXUK2(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFnNb7(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVRr5h(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVRr5h(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVRr5h(self.SYST, self.D_SYS_S)
     freq = self.VVRr5h(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVRr5h(self.POL , self.D_POL)
      fec = self.VVRr5h(self.FEC , self.D_FEC)
      sr = self.VVRr5h(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV6SZn(self, refCode):
  self.data = None
  self.VVi24o(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCwq37():
 def __init__(self, VVd8jA, path, VVXlAY=None, curRowNum=-1):
  self.VVd8jA  = VVd8jA
  self.origFile   = path
  self.Title    = "File Editor: " + FF4Cf3(path)
  self.VVXlAY  = VVXlAY
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFqAik("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVJSMP(curRowNum)
  else:
   FF1uaI(self.VVd8jA, "Error while preparing edit!")
 def VVJSMP(self, curRowNum):
  VVG5ES = self.VVIJiv()
  VVZyxX = ("Save Changes" , self.VVMM5J   , [])
  VVmG3M  = ("Edit Line"  , self.VVrnTk    , [])
  VVQJvS = ("Go to Line Num" , self.VVUEDV   , [])
  VVOr9v = ("Line Options" , self.VVuURQ   , [])
  VVbNxw = (""    , self.VVWIcd , [])
  VVVD8O = self.VVaKL8
  VV1jVB  = self.VVN2Cj
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV4tj2  = (CENTER  , LEFT  )
  VVc7Yu = FF8dRU(self.VVd8jA, None, title=self.Title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVZyxX=VVZyxX, VVmG3M=VVmG3M, VVQJvS=VVQJvS, VVOr9v=VVOr9v, VVVD8O=VVVD8O, VV1jVB=VV1jVB, VVbNxw=VVbNxw, VVDYPP=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVW1CX   = "#11001111"
    , VVLasp   = "#11001111"
    , VVHSOH   = "#11001111"
    , VVJqmr  = "#05333333"
    , VVFNoD  = "#00222222"
    , VVcwBH  = "#11331133"
    )
  VVc7Yu.VVQ2AR(curRowNum)
 def VVUEDV(self, VVc7Yu, title, txt, colList):
  totRows = VVc7Yu.VVpm2D()
  lineNum = VVc7Yu.VVbJrA() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFX1El(self.VVd8jA, BF(self.VV2zpb, VVc7Yu, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VV2zpb(self, VVc7Yu, lineNum, totRows, VVouBA):
  if VVouBA:
   VVouBA = VVouBA.strip()
   if VVouBA.isdigit():
    num = FFK3ps(int(VVouBA) - 1, 0, totRows)
    VVc7Yu.VVQ2AR(num)
    self.lastLineNum = num + 1
   else:
    FFkxeT(VVc7Yu, "Incorrect number", 1500)
 def VVuURQ(self, VVc7Yu, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVc7Yu.VVtZhN()
  VVd21k = []
  VVd21k.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVd21k.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVcD7w"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVZDlR:
   VVd21k.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(  ("Delete Line"         , "deleteLine"   ))
  FFxMT2(self.VVd8jA, BF(self.VVYAuD, VVc7Yu, lineNum), VVd21k=VVd21k, title="Line Options")
 def VVYAuD(self, VVc7Yu, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVk6us("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVc7Yu)
   elif item == "VVcD7w"  : self.VVcD7w(VVc7Yu, lineNum)
   elif item == "copyToClipboard"  : self.VVbaNB(VVc7Yu, lineNum)
   elif item == "pasteFromClipboard" : self.VVSaRv(VVc7Yu, lineNum)
   elif item == "deleteLine"   : self.VVk6us("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVc7Yu)
 def VVN2Cj(self, VVc7Yu):
  VVc7Yu.VVOwuz()
 def VVWIcd(self, VVc7Yu, title, txt, colList):
  if   self.insertMode == 1: VVc7Yu.VVlpBm()
  elif self.insertMode == 2: VVc7Yu.VVKZI8()
  self.insertMode = 0
 def VVcD7w(self, VVc7Yu, lineNum):
  if lineNum == VVc7Yu.VVtZhN():
   self.insertMode = 1
   self.VVk6us("echo '' >> '%s'" % self.tmpFile, VVc7Yu)
  else:
   self.insertMode = 2
   self.VVk6us("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVc7Yu)
 def VVbaNB(self, VVc7Yu, lineNum):
  global VVZDlR
  VVZDlR = FFlcvI("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVc7Yu.VVdNoE("Copied to clipboard")
 def VVMM5J(self, VVc7Yu, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFqAik("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFqAik("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVc7Yu.VVdNoE("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVc7Yu.VVOwuz()
    else:
     FF1uaI(self.VVd8jA, "Cannot save file!")
   else:
    FF1uaI(self.VVd8jA, "Cannot create backup copy of original file!")
 def VVaKL8(self, VVc7Yu):
  if self.fileChanged:
   FFWV4g(self.VVd8jA, BF(self.VVZSqE, VVc7Yu), "Cancel changes ?")
  else:
   finalOK = os.system(FFqAik("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVZSqE(VVc7Yu)
 def VVZSqE(self, VVc7Yu):
  VVc7Yu.cancel()
  FFC2Q5(self.tmpFile)
  if self.VVXlAY:
   self.VVXlAY(self.fileSaved)
 def VVrnTk(self, VVc7Yu, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVBNow + "ORIGINAL TEXT:\n" + VVekE1 + lineTxt
  FFX1El(self.VVd8jA, BF(self.VV7bhu, lineNum, VVc7Yu), title="File Line", defaultText=lineTxt, message=message)
 def VV7bhu(self, lineNum, VVc7Yu, VVouBA):
  if not VVouBA is None:
   if VVc7Yu.VVtZhN() <= 1:
    self.VVk6us("echo %s > '%s'" % (VVouBA, self.tmpFile), VVc7Yu)
   else:
    self.VVxE6x(VVc7Yu, lineNum, VVouBA)
 def VVSaRv(self, VVc7Yu, lineNum):
  if lineNum == VVc7Yu.VVtZhN() and VVc7Yu.VVtZhN() == 1:
   self.VVk6us("echo %s >> '%s'" % (VVZDlR, self.tmpFile), VVc7Yu)
  else:
   self.VVxE6x(VVc7Yu, lineNum, VVZDlR)
 def VVxE6x(self, VVc7Yu, lineNum, newTxt):
  VVc7Yu.VV5Wyx("Saving ...")
  lines = FFwiKR(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVc7Yu.VVKYNy()
  VVG5ES = self.VVIJiv()
  VVc7Yu.VV4ZQl(VVG5ES)
 def VVk6us(self, cmd, VVc7Yu):
  tCons = CCN83i()
  tCons.ePopen(cmd, BF(self.VVgPgZ, VVc7Yu))
  self.fileChanged = True
  VVc7Yu.VVKYNy()
 def VVgPgZ(self, VVc7Yu, result, retval):
  VVG5ES = self.VVIJiv()
  VVc7Yu.VV4ZQl(VVG5ES)
 def VVIJiv(self):
  if fileExists(self.tmpFile):
   lines = FFwiKR(self.tmpFile)
   VVG5ES = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVG5ES.append((str(ndx), line.strip()))
   if not VVG5ES:
    VVG5ES.append((str(1), ""))
   return VVG5ES
  else:
   FFr3Kr(self.VVd8jA, self.tmpFile)
class CC4Wdl():
 def __init__(self, callingSELF, VVW1CX="#22003344", VVLasp="#22002233"):
  self.callingSELF = callingSELF
  self.VVd21k  = []
  self.satList  = []
  self.VVW1CX  = VVW1CX
  self.VVLasp   = VVLasp
 def VVIRm0(self, VVXlAY):
  self.VVd21k = []
  VVd21k, VVKaUh = CC4Wdl.VVVpFG(self.callingSELF, False, True)
  if VVd21k:
   self.VVd21k += VVd21k
   self.VVtwfN(VVXlAY, VVKaUh)
 def VVmycI(self, mode, VVc7Yu, satCol, VVXlAY, inFilterFnc=None):
  VVc7Yu.VV5Wyx("Loading Filters ...")
  self.VVd21k = []
  self.VVd21k.append(("All Services" , "all"))
  if mode == 1:
   self.VVd21k.append(VVNCuu)
   self.VVd21k.append(("Parental Control", "parentalControl"))
   self.VVd21k.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVd21k.append(VVNCuu)
   self.VVd21k.append(("Selected Transponder"   , "selectedTP" ))
   self.VVd21k.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVUlvk(VVc7Yu, satCol)
  VVd21k, VVKaUh = CC4Wdl.VVVpFG(self.callingSELF, True, False)
  if VVd21k:
   VVd21k.insert(0, FFnwrX("Custom Words"))
   self.VVd21k += VVd21k
  VVc7Yu.VVSLMs()
  self.VVtwfN(VVXlAY, VVKaUh, inFilterFnc)
 def VVeblc(self, VVd21k, sats, VVXlAY, inFilterFnc=None):
  self.VVd21k = VVd21k
  VVd21k, VVKaUh = CC4Wdl.VVVpFG(self.callingSELF, True, False)
  if VVd21k:
   self.VVd21k.append(FFnwrX("Custom Words"))
   self.VVd21k += VVd21k
  self.VVtwfN(VVXlAY, VVKaUh, inFilterFnc)
 def VVtwfN(self, VVXlAY, VVKaUh, inFilterFnc=None):
  VVQIvk  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVHLqw = ("Edit Filter"  , BF(self.VVJqhd, VVKaUh))
  VVldmG  = ("Filter Help"  , BF(self.VVorD2, VVKaUh))
  FFxMT2(self.callingSELF, BF(self.VVpLUQ, VVXlAY), VVd21k=self.VVd21k, title="Select Filter", VVQIvk=VVQIvk, VVHLqw=VVHLqw, VVldmG=VVldmG, VVP2Aq=True, VVW1CX=self.VVW1CX, VVLasp=self.VVLasp)
 def VVpLUQ(self, VVXlAY, item):
  if item:
   VVXlAY(item)
 def VVJqhd(self, VVKaUh, VVFy7pObj, sel):
  if fileExists(VVKaUh) : CCwq37(self.callingSELF, VVKaUh, VVXlAY=None)
  else       : FFr3Kr(self.callingSELF, VVKaUh)
  VVFy7pObj.cancel()
 def VVorD2(self, VVKaUh, VVFy7pObj, sel):
  FFkKs9(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVUlvk(self, VVc7Yu, satColNum):
  if not self.satList:
   satList = VVc7Yu.VVZS7p(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFx433(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFnwrX("Satellites"))
  if self.VVd21k:
   self.VVd21k += self.satList
 @staticmethod
 def VVVpFG(SELF, addTag, VV3KZ2):
  FFQRh2()
  fileName  = "ajpanel_services_filter"
  VVKaUh = VV4J76 + fileName
  VVd21k  = []
  if not fileExists(VVKaUh):
   os.system(FFqAik("cp -f '%s' '%s'" % (VVrjWk + fileName, VVKaUh)))
  fileFound = False
  if fileExists(VVKaUh):
   fileFound = True
   lines = FFwiKR(VVKaUh)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVd21k.append((line, "__w__" + line))
       else  : VVd21k.append((line, line))
  if VV3KZ2:
   if   not fileFound : FFr3Kr(SELF, VVKaUh)
   elif not VVd21k : FFGQJR(SELF, VVKaUh)
  return VVd21k, VVKaUh
 @staticmethod
 def VV610T(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CC8qau():
 def __init__(self, callingSELF, VVc7Yu, addSep=True):
  self.callingSELF = callingSELF
  self.VVc7Yu = VVc7Yu
  self.VVd21k = []
  iMulSel = self.VVc7Yu.VVCSth()
  if iMulSel : self.VVd21k.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVd21k.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVc7Yu.VVcONI()
  self.VVd21k.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVd21k.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVd21k.append(VVNCuu)
 def VVyFGx(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVd21k.extend(extraMenu)
  FFxMT2(self.callingSELF, BF(self.VVoYxF, cbFncDict, okFnc), width=width, title="Options", VVd21k=self.VVd21k)
 def VVoYxF(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVc7Yu.VVVUw7(True)
   elif item == "MultSelDisab" : self.VVc7Yu.VVVUw7(False)
   elif item == "selectAll" : self.VVc7Yu.VVwMcz()
   elif item == "unselectAll" : self.VVc7Yu.VVQprB()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CC0RHp(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVtcbV, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFrOoX(self)
  FFddoJ(self["keyRed"]  , "Exit")
  FFddoJ(self["keyGreen"]  , "Save")
  FFddoJ(self["keyYellow"] , "Refresh")
  FFddoJ(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVWfk2  ,
   "green" : self.VVZmrg ,
   "yellow": self.VVsHVw  ,
   "blue" : self.VVkpit   ,
   "up" : self.VV66ms    ,
   "down" : self.VVs4n9   ,
   "left" : self.VV0XiC   ,
   "right" : self.VV2FzN   ,
   "cancel": self.VVWfk2
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self.VVsHVw()
  self.VVBX9x()
  FFnQcA(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVJfun)
  except:
   self.timer.callback.append(self.VVJfun)
  self.timer.start(1000, False)
  self.VVJfun()
 def onExit(self):
  self.timer.stop()
 def VVWfk2(self) : self.close(True)
 def VVEWYw(self) : self.close(False)
 def VVkpit(self):
  self.session.openWithCallback(self.VVIXUh, BF(CCCxRq))
 def VVIXUh(self, closeAll):
  if closeAll:
   self.close()
 def VVJfun(self):
  self["curTime"].setText(str(FFeWDt(iTime())))
 def VV66ms(self):
  self.VVBiHs(1)
 def VVs4n9(self):
  self.VVBiHs(-1)
 def VV0XiC(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVBX9x()
 def VV2FzN(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVBX9x()
 def VVBiHs(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVWFKz(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVWFKz(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVWFKz(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVyPF2(year)):
   days += 1
  return days
 def VVyPF2(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVBX9x(self):
  for obj in self.list:
   FFrI2P(obj, "#11404040")
  FFrI2P(self.list[self.index], "#11ff8000")
 def VVsHVw(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVZmrg(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCN83i()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VV6jf4)
 def VV6jf4(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFfF2j(self, "Nothing returned from the system!")
  else:
   FFfF2j(self, str(result))
class CCCxRq(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVrQkp, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFrOoX(self, addLabel=True)
  FFddoJ(self["keyRed"]  , "Exit")
  FFddoJ(self["keyGreen"]  , "Sync")
  FFddoJ(self["keyYellow"] , "Refresh")
  FFddoJ(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVWfk2   ,
   "green" : self.VVyR0r  ,
   "yellow": self.VVgSka ,
   "blue" : self.VVdMXl  ,
   "cancel": self.VVWfk2
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVvu5o()
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  FFnQcA(self)
  FFnCJX(self.refresh)
 def refresh(self):
  self.VVvQUS()
  self.VV44Pm(False)
 def VVWfk2(self)  : self.close(True)
 def VVdMXl(self) : self.close(False)
 def VVvu5o(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVvQUS(self):
  self.VViNeH()
  self.VVnn7j()
  self.VVJNmq()
  self.VVbRg6()
 def VVgSka(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVvu5o()
   self.VVvQUS()
   FFnCJX(self.refresh)
 def VVyR0r(self):
  if len(self["keyGreen"].getText()) > 0:
   FFWV4g(self, self.VVJrLt, "Synchronize with Internet Date/Time ?")
 def VVJrLt(self):
  self.VVvQUS()
  FFnCJX(BF(self.VV44Pm, True))
 def VViNeH(self)  : self["keyRed"].show()
 def VVKlN2(self)  : self["keyGreen"].show()
 def VV2q38(self) : self["keyYellow"].show()
 def VVCdR8(self)  : self["keyBlue"].show()
 def VVnn7j(self)  : self["keyGreen"].hide()
 def VVJNmq(self) : self["keyYellow"].hide()
 def VVbRg6(self)  : self["keyBlue"].hide()
 def VV44Pm(self, sync):
  localTime = FFOV2D()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVB05D(server)
   if epoch_time is not None:
    ntpTime = FFeWDt(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCN83i()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VV6jf4, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VV2q38()
  self.VVCdR8()
  if ok:
   self.VVKlN2()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VV6jf4(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VV44Pm(False)
  except:
   pass
 def VVB05D(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFLsnX():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCzlKd(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF1pMw(VVeaJc, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFrOoX(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFnCJX(self.VV6J29)
 def VV6J29(self):
  if FFLsnX(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFrI2P(self["myBody"], color)
   FFrI2P(self["myLabel"], color)
  except:
   pass
class CCk768(Screen):
 VVXZMJ = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFJKbx()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF1pMw(VVuk51, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCkZ30(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCkZ30(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCkZ30(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCu6cR()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFrOoX(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VV66ms       ,
   "down"  : self.VVs4n9      ,
   "left"  : self.VV0XiC      ,
   "right"  : self.VV2FzN      ,
   "info"  : self.VVvoLM     ,
   "epg"  : self.VVvoLM     ,
   "menu"  : self.VVcekz      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VV2BNb, -1)  ,
   "next"  : BF(self.VV2BNb, 1)  ,
   "pageUp" : BF(self.VVGWyW, True) ,
   "chanUp" : BF(self.VVGWyW, True) ,
   "pageDown" : BF(self.VVGWyW, False) ,
   "chanDown" : BF(self.VVGWyW, False) ,
   "0"   : BF(self.VV2BNb, 0)  ,
   "1"   : BF(self.VV75vL, pos=1) ,
   "2"   : BF(self.VV75vL, pos=2) ,
   "3"   : BF(self.VV75vL, pos=3) ,
   "4"   : BF(self.VV75vL, pos=4) ,
   "5"   : BF(self.VV75vL, pos=5) ,
   "6"   : BF(self.VV75vL, pos=6) ,
   "7"   : BF(self.VV75vL, pos=7) ,
   "8"   : BF(self.VV75vL, pos=8) ,
   "9"   : BF(self.VV75vL, pos=9) ,
  }, -1)
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  if not CCk768.VVXZMJ:
   CCk768.VVXZMJ = self
  self.sliderSNR.VVYcQ8()
  self.sliderAGC.VVYcQ8()
  self.sliderBER.VVYcQ8(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV75vL()
  self.VVuPqf()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVF4KX)
  except:
   self.timer.callback.append(self.VVF4KX)
  self.timer.start(500, False)
 def VVuPqf(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVnKaY(service)
  serviceName = self.tunerInfo.VVIeEz()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  tp = CCaOWR()
  tpTxt, satTxt = tp.VVGlqs(refCode)
  if tpTxt == "?" :
   tpTxt = FFHqZk("NO SIGNAL", VVHeSZ)
  self["myTPInfo"].setText(tpTxt + "  " + FFHqZk(satTxt, VVWFW6))
 def VVF4KX(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVnKaY(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV7uOC())
   self["mySNR"].setText(self.tunerInfo.VVhdJp())
   self["myAGC"].setText(self.tunerInfo.VVJIyp())
   self["myBER"].setText(self.tunerInfo.VVlik0())
   self.sliderSNR.VVY0wh(self.tunerInfo.VVKOyn())
   self.sliderAGC.VVY0wh(self.tunerInfo.VVOR4f())
   self.sliderBER.VVY0wh(self.tunerInfo.VVDCOH())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVY0wh(0)
   self.sliderAGC.VVY0wh(0)
   self.sliderBER.VVY0wh(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
    if state and not state == "Tuned":
     FFkxeT(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVvoLM(self):
  FFdGDb(self, fncMode=CCfm5u.VVMSfA)
 def VVcekz(self):
  FFkKs9(self, "_help_signal", "Signal Monitor (Keys)")
 def VV66ms(self)  : self.VV75vL(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVs4n9(self) : self.VV75vL(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV0XiC(self) : self.VV75vL(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VV2FzN(self) : self.VV75vL(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV75vL(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFWvPK(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV2BNb(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFK3ps(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFWvPK(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCk768.VVXZMJ = None
 def VVGWyW(self, isUp):
  FFkxeT(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVuPqf()
  except:
   pass
class CCkZ30(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVYcQ8(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFrI2P(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVrjWk +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFrI2P(self.covObj, self.covColor)
   else:
    FFrI2P(self.covObj, "#00006688")
    self.isColormode = True
  self.VVY0wh(0)
 def VVY0wh(self, val):
  val  = FFK3ps(val, self.minN, self.maxN)
  width = int(FFPwFt(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFK3ps(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC8PiB(Screen):
 VVchq1    = 0
 VVuGmU = 1
 VVXczk = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVXlAY=None, barTheme=VVchq1, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VV6rsL(barTheme)
  self.skin, self.skinParam = FF1pMw(VVxiVV, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVXlAY = VVXlAY
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVc1Ja = None
  self.timer   = eTimer()
  self.myThread  = None
  FFrOoX(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self.VV86r4()
  self["myProgBarVal"].setText("0%")
  FFrI2P(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVCeOV()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCeOV)
  except:
   self.timer.callback.append(self.VVCeOV)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VViTTm(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVQToQ(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVc1Ja), self.counter, self.maxValue, catName)
 def VVf1Qk(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVAV0s(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVSR2F(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVNE8d(self, title):
  self.newTitle = title
  try:
   self.VVCeOV()
  except:
   pass
 def VVFOrd(self, txt):
  self.newTitle = txt
 def VV3VHc(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVc1Ja), self.counter, self.maxValue)
  except:
   pass
 def VVfn6j(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVXNQ3(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVb8zx(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFkxeT(self, "Cancelling ...")
  self.isCancelled = True
  self.VV0GmG(False)
 def VV0GmG(self, isDone):
  if self.VVXlAY:
   self.VVXlAY(isDone, self.VVc1Ja, self.counter, self.maxValue, self.isError)
  self.close()
 def VVCeOV(self):
  val = FFK3ps(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFPwFt(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VV0GmG(True)
 def VV86r4(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVuGmU, self.VVXczk):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VV6rsL(self, barTheme):
  if   barTheme == self.VVuGmU : return 0.7
  if   barTheme == self.VVXczk : return 0.5
  else             : return 1
class CCN83i(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVXlAY = {}
  self.commandRunning = False
  self.VVjafw  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVXlAY, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVXlAY[name] = VVXlAY
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVjafw:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVlOWJ, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVzIS1 , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVlOWJ, name))
    self.appContainers[name].appClosed.append(BF(self.VVzIS1 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVzIS1(name, retval)
  return True
 def VVlOWJ(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFHqZk("[UN-DECODED STRING]", VVHeSZ))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVzIS1(self, name, retval):
  if not self.VVjafw:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVXlAY[name]:
   self.VVXlAY[name](self.appResults[name], retval)
  del self.VVXlAY[name]
 def VVo9o9(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCuDOr(Screen):
 def __init__(self, session, title="", VV87m4=None, VVnHHw=False, VVvdV2=False, VVlT6a=False, VV2DnN=False, VVQhFr=False, VVhJ5u=False, VVXwlZ=VVdsyE, VVHcKu=None, VVbwYM=False, VVbBvt=None, VVcg8k="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FF1pMw(VV16CN, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFrOoX(self, addScrollLabel=True)
  if not VVcg8k:
   VVcg8k = "Processing ..."
  self["myLabel"].setText("   %s" % VVcg8k)
  self.VVnHHw   = VVnHHw
  self.VVvdV2   = VVvdV2
  self.VVlT6a   = VVlT6a
  self.VV2DnN  = VV2DnN
  self.VVQhFr = VVQhFr
  self.VVhJ5u = VVhJ5u
  self.VVXwlZ   = VVXwlZ
  self.VVHcKu = VVHcKu
  self.VVbwYM  = VVbwYM
  self.VVbBvt  = VVbBvt
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCN83i()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFphjG()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV87m4, str):
   self.VV87m4 = [VV87m4]
  else:
   self.VV87m4 = VV87m4
  if self.VVlT6a or self.VV2DnN:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVbL9B, VVbL9B)
   self.VV87m4.append("echo -e '\n%s\n' %s" % (restartNote, FFDB5L(restartNote, VVsZ3Y)))
   if self.VVlT6a:
    self.VV87m4.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV87m4.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVQhFr:
   FFkxeT(self, "Processing ...")
  self.onLayoutFinish.append(self.VVVHkg)
  self.onClose.append(self.VV46if)
 def VVVHkg(self):
  self["myLabel"].VVuWLn(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVnHHw:
   self["myLabel"].VVeYTy()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVgLrj()
  else:
   self.VVR3Bm()
 def VVgLrj(self):
  if FFLsnX():
   self["myLabel"].setText("Processing ...")
   self.VVR3Bm()
  else:
   self["myLabel"].setText(FFHqZk("\n   No connection to internet!", VV0kWR))
 def VVR3Bm(self):
  allOK = self.container.ePopen(self.VV87m4[0], self.VVKt6a, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVKt6a("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVhJ5u or self.VVlT6a or self.VV2DnN:
    self["myLabel"].setText(FF8jk7("STARTED", VVsZ3Y) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVbBvt:
   colorWhite = CCYElQ.VVVD33(VVBNow)
   color  = CCYElQ.VVVD33(self.VVbBvt[0])
   words  = self.VVbBvt[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVXwlZ=self.VVXwlZ)
 def VVKt6a(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV87m4):
   allOK = self.container.ePopen(self.VV87m4[self.cmdNum], self.VVKt6a, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVKt6a("Cannot connect to Console!", -1)
  else:
   if self.VVQhFr and FFLwRB(self):
    FFkxeT(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVhJ5u:
    self["myLabel"].appendText("\n" + FF8jk7("FINISHED", VVsZ3Y), self.VVXwlZ)
   if self.VVnHHw or self.VVvdV2:
    self["myLabel"].VVeYTy()
   if self.VVHcKu is not None:
    self.VVHcKu()
   if not retval and self.VVbwYM:
    self.VV46if()
 def VV46if(self):
  if self.container.VVo9o9():
   self.container.killAll()
class CCgwEi(Screen):
 def __init__(self, session, VV87m4=None, VVQhFr=False):
  self.skin, self.skinParam = FF1pMw(VV16CN, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VV4J76 + "ajpanel_terminal.history"
  self.customCommandsFile = VV4J76 + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFlcvI("pwd") or "/home/root"
  self.container   = CCN83i()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFrOoX(self, title="Terminal", addScrollLabel=True)
  FFddoJ(self["keyRed"] , self.exitBtnText)
  FFddoJ(self["keyGreen"] , "OK = History")
  FFddoJ(self["keyYellow"], "Menu = Custom Cmds")
  FFddoJ(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVgByC ,
   "cancel": self.VVeXwZ  ,
   "menu" : self.VViyTM ,
   "last" : self.VVKbmj  ,
   "next" : self.VVKbmj  ,
   "1"  : self.VVKbmj  ,
   "2"  : self.VVKbmj  ,
   "3"  : self.VVKbmj  ,
   "4"  : self.VVKbmj  ,
   "5"  : self.VVKbmj  ,
   "6"  : self.VVKbmj  ,
   "7"  : self.VVKbmj  ,
   "8"  : self.VVKbmj  ,
   "9"  : self.VVKbmj  ,
   "0"  : self.VVKbmj
  })
  self.onLayoutFinish.append(self.VVOOZO)
  self.onClose.append(self.VVIeUQ)
 def VVOOZO(self):
  self["myLabel"].VVuWLn(isResizable=False, outputFileToSave="terminal")
  FFm6nb(self["keyRed"]  , "#00ff8000")
  FFrI2P(self["keyRed"]  , self.skinParam["titleColor"])
  FFrI2P(self["keyGreen"]  , self.skinParam["titleColor"])
  FFrI2P(self["keyYellow"] , self.skinParam["titleColor"])
  FFrI2P(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVJogk(FFlcvI("date"), 5)
  result = FFlcvI("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVuNUs()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVrjWk + "LinuxCommands.lst"
   newTemplate = VVrjWk + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFqAik("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFqAik("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVIeUQ(self):
  if self.container.VVo9o9():
   self.container.killAll()
   self.VVJogk("Process killed\n", 4)
   self.VVuNUs()
 def VVeXwZ(self):
  if self.container.VVo9o9():
   self.VVIeUQ()
  else:
   FFWV4g(self, self.close, "Exit ?", VVvl21=False)
 def VVuNUs(self):
  self.VVJogk(self.prompt, 1)
  self["keyRed"].hide()
 def VVJogk(self, txt, mode):
  if   mode == 1 : color = VVsZ3Y
  elif mode == 2 : color = VVpihg
  elif mode == 3 : color = VVBNow
  elif mode == 4 : color = VV0kWR
  elif mode == 5 : color = VVekE1
  elif mode == 6 : color = VV2vWn
  else   : color = VVBNow
  try:
   self["myLabel"].appendText(FFHqZk(txt, color))
  except:
   pass
 def VVgByC(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVn2qn() == "":
   self.VVBML6("cd /tmp")
   self.VVBML6("ls")
  VVG5ES = []
  if fileExists(self.commandHistoryFile):
   lines  = FFwiKR(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVG5ES.append((str(c), line, str(lNum)))
   self.VVn1G7(VVG5ES, title, self.commandHistoryFile, isHistory=True)
  else:
   FFr3Kr(self, self.commandHistoryFile, title=title)
 def VVn2qn(self):
  lastLine = FFlcvI("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVBML6(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VViyTM(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFwiKR(self.customCommandsFile)
   lastLineIsSep = False
   VVG5ES = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVG5ES.append((str(c), line, str(lNum)))
   self.VVn1G7(VVG5ES, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFr3Kr(self, self.customCommandsFile, title=title)
 def VVn1G7(self, VVG5ES, title, filePath=None, isHistory=False):
  if VVG5ES:
   VVJqmr = "#05333333"
   if isHistory: VVW1CX = VVLasp = VVHSOH = "#11000020"
   else  : VVW1CX = VVLasp = VVHSOH = "#06002020"
   VVmG3M   = ("Send"   , BF(self.VV6Z2Y, isHistory)  , [])
   VVZyxX  = ("Modify & Send" , self.VV1har     , [])
   if isHistory:
    VVQJvS = ("Clear History" , self.VVQp8v     , [])
    VVOr9v = None
   elif filePath:
    VVQJvS = ("Options"  , self.VVIleH      , [])
    VVOr9v = ("Edit File"  , BF(self.VVZbHv, filePath) , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VV4tj2 = (CENTER , LEFT   , CENTER )
   VVc7Yu = FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v, lastFindConfigObj=CFG.lastFindTerminal, VVDYPP=True, searchCol=1
         , VVW1CX=VVW1CX, VVLasp=VVLasp, VVHSOH=VVHSOH, VVNfgg="#05ffff00", VVJqmr=VVJqmr)
   if not isHistory:
    VVc7Yu.VVQ2AR(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFGQJR(self, filePath, title=title)
 def VVIleH(self, VVc7Yu, title, txt, colList):
  mSel = CC8qau(self, VVc7Yu)
  if VVc7Yu.VVh7FN:
   totSel = VVc7Yu.VVcONI()
   totTxt = str(totSel)
   txt = "Send %s Command%s" % (FFHqZk(totTxt, VVsZ3Y) if totSel else totTxt, FFwHmW(totSel))
   VVd21k = [(txt, "send")] if totSel else [(txt,)]
  else:
   VVd21k = [("Send current line", "send")]
  cbFncDict = {"send": BF(self.VV6Z2Y, False, VVc7Yu, title, txt, colList)}
  mSel.VVyFGx(VVd21k, cbFncDict, okFnc=BF(self.VVaMMZ, VVc7Yu))
 def VVaMMZ(self, VVc7Yu):
  if VVc7Yu.VVh7FN : VVc7Yu.VVOwuz()
  else        : VVc7Yu.VVKYNy()
 def VV6Z2Y(self, isHistory, VVc7Yu, title, txt, colList):
  if VVc7Yu.VVh7FN:
   lst = VVc7Yu.VVnygS(1)
   curNdx = VVc7Yu.VVTo2y()
  else:
   lst = [colList[1]]
   curNdx = VVc7Yu.VVbJrA()
  if not isHistory:
   FFWvPK(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVc7Yu.cancel()
  FFnCJX(self.VV4Sys)
 def VV4Sys(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVJogk("\n%s\n" % cmd, 6)
    self.VVJogk(self.prompt, 1)
    self.VV4Sys()
   else:
    self.VVqYCE(cmd)
 def VVqYCE(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVJogk(cmd, 2)
   self.VVJogk("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVJogk(ch, 0)
   self.VVJogk("\nor\n", 4)
   self.VVJogk("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVuNUs()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFHqZk(parts[0].strip(), VVpihg)
    right = FFHqZk("#" + parts[1].strip(), VV2vWn)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVJogk(txt, 2)
   lastLine = self.VVn2qn()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVBML6(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVKt6a, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF1uaI(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVJogk(data, 3)
 def VVKt6a(self, data, retval):
  if not retval == 0:
   self.VVJogk("Exit Code : %d\n" % retval, 4)
  self.VVuNUs()
  if self.commandsList:
   self.VV4Sys()
 def VV1har(self, VVc7Yu, title, txt, colList):
  if VVc7Yu.VV4ccy():
   cmd = colList[1]
   self.VVPDaN(VVc7Yu, cmd)
 def VVQp8v(self, VVc7Yu, title, txt, colList):
  FFWV4g(self, BF(self.VVCNrB, VVc7Yu), "Reset History File ?", title="Command History")
 def VVCNrB(self, VVc7Yu):
  os.system(FFqAik("echo '' > %s" % self.commandHistoryFile))
  VVc7Yu.cancel()
 def VVZbHv(self, filePath, VVc7Yu, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCwq37(self, filePath, VVXlAY=BF(self.VVczDe, VVc7Yu), curRowNum=rowNum)
  else     : FFr3Kr(self, filePath)
 def VVczDe(self, VVc7Yu, fileChanged):
  if fileChanged:
   VVc7Yu.cancel()
   FFnCJX(self.VViyTM)
 def VVKbmj(self):
  self.VVPDaN(None, self.lastCommand)
 def VVPDaN(self, VVc7Yu, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFX1El(self, BF(self.VVIKhd, VVc7Yu), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVIKhd(self, VVc7Yu, cmd):
  if cmd and len(cmd) > 0:
   self.VVqYCE(cmd)
   if VVc7Yu:
    VVc7Yu.cancel()
class CCFCBZ(Screen):
 def __init__(self, session, title="", message="", VVXwlZ=VVdsyE, width=1400, height=800, VV0CQU=False, VVHSOH=None, VVlvFD=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FF1pMw(VV16CN, width, height, titleFontSize, 30, 20, "#22002020", "#22001122", VVlvFD)
  self.session   = session
  FFrOoX(self, title, addScrollLabel=True)
  self.VVXwlZ   = VVXwlZ
  self.VV0CQU   = VV0CQU
  self.VVHSOH   = VVHSOH
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self["myLabel"].VVuWLn(VV0CQU=self.VV0CQU, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVXwlZ)
  if self.VVHSOH:
   FFrI2P(self["myBody"], self.VVHSOH)
   FFrI2P(self["myLabel"], self.VVHSOH)
   FF1h4U(self["myLabel"], self.VVHSOH)
  self["myLabel"].VVeYTy()
class CC5Okd(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF1pMw(VVscCR, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFrOoX(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFVTEo(self["errPic"], "err")
class CCrCKC(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FF1pMw(VVeAgx, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFrOoX(self, " ", addCloser=True)
class CC6BDM():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCrCKC, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFf3WT(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV3GAf)
  except:
   self.timer.callback.append(self.VV3GAf)
  self.timer.start(timeout, True)
 def VV3GAf(self):
  self.session.deleteDialog(self.win)
class CCEVEE():
 VVZyAI    = 0
 VVVant  = 1
 VVfnIA   = ""
 VVVrBm    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVc7Yu   = None
  self.timer     = eTimer()
  self.VVDSd7   = 0
  self.VVxwiT  = 1
  self.VVGta7  = 2
  self.VVBPdD   = 3
  self.VVci5d   = 4
  VVG5ES = self.VVZnsN()
  if VVG5ES:
   self.VVc7Yu = self.VVIxKl(VVG5ES)
  if not VVG5ES and mode == self.VVZyAI:
   self.VV1kxV("Download list is empty !")
   self.cancel()
  if mode == self.VVVant:
   FFqcaP(self.VVc7Yu or self.SELF, BF(self.VVOcCk, startDnld, decodedUrl), title="Checking Server ...")
  self.VVB8DO(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVB8DO)
  except:
   self.timer.callback.append(self.VVB8DO)
  self.timer.start(1000, False)
 def VVIxKl(self, VVG5ES):
  VVG5ES.sort(key=lambda x: int(x[0]))
  VVVD8O = self.VVYbA6
  VVmG3M  = ("Play"  , self.VVO2PA , [])
  VVAe4b = (""   , self.VVNZlP  , [])
  VVDti0 = ("Stop"  , self.VVqFsl  , [])
  VVZyxX = ("Resume"  , self.VVZJuU , [])
  VVQJvS = ("Options" , self.VVgvRU  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV4tj2  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FF8dRU(self.SELF, None, title=self.Title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVmG3M=VVmG3M, VVAe4b=VVAe4b, VVVD8O=VVVD8O, VVDti0=VVDti0, VVZyxX=VVZyxX, VVQJvS=VVQJvS, lastFindConfigObj=CFG.lastFindIptv, VVW1CX="#11220022", VVLasp="#11110011", VVHSOH="#11110011", VVNfgg="#00ffff00", VVJqmr="#00223025", VVFNoD="#0a333333", VVcwBH="#0a400040", VVDYPP=True, searchCol=1)
 def VVZnsN(self):
  lines = CCEVEE.VVjgfC()
  VVG5ES = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVsbVV(decodedUrl)
      if fName:
       if   FFJkN3(decodedUrl) : sType = "Movie"
       elif FFbR9b(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VV685O(decodedUrl, fName)
       if size > -1: sizeTxt = CCk3u6.VVeQ5q(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVG5ES.append((str(len(VVG5ES) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVG5ES
 def VVEVTy(self):
  VVG5ES = self.VVZnsN()
  if VVG5ES:
   if self.VVc7Yu : self.VVc7Yu.VV4ZQl(VVG5ES, VVvu5oMsg=False)
   else     : self.VVc7Yu = self.VVIxKl(VVG5ES)
  else:
   self.cancel()
 def VVB8DO(self, force=False):
  if self.VVc7Yu:
   thrListUrls = self.VVsiXb()
   VVG5ES = []
   changed = False
   for ndx, row in enumerate(self.VVc7Yu.VVgeCg()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVDSd7
    if m3u8Log:
     percent = CCEVEE.VVL8I0(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVBPdD , "%.2f %%" % percent
      else   : flag, progr = self.VVci5d , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FF2oRJ(mPath)
     if curSize > -1:
      fSize = CCk3u6.VVeQ5q(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCk3u6.VVeQ5q(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FF2oRJ(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVBPdD , "%.2f %%" % percent
       else   : flag, progr = self.VVci5d , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCk3u6.VVeQ5q(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVGta7
     if m3u8Log :
      if not speed and not force : flag = self.VVxwiT
      elif curSize == -1   : self.VV7GWK(False)
    elif flag == self.VVDSd7  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVDSd7  : color2 = "#f#00555555#"
    elif flag == self.VVxwiT : color2 = "#f#0000FFFF#"
    elif flag == self.VVGta7 : color2 = "#f#0000FFFF#"
    elif flag == self.VVBPdD  : color2 = "#f#00FF8000#"
    elif flag == self.VVci5d  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVOOVu(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVG5ES.append(row)
   if changed or force:
    self.VVc7Yu.VV4ZQl(VVG5ES, VVvu5oMsg=False)
 def VVOOVu(self, flag):
  tDict = self.VVsPdE()
  return tDict.get(flag, "?")
 def VV1JEl(self, state):
  for flag, txt in self.VVsPdE().items():
   if txt == state:
    return flag
  return -1
 def VVsPdE(self):
  return { self.VVDSd7: "Not started", self.VVxwiT: "Connecting", self.VVGta7: "Downloading", self.VVBPdD: "Stopped", self.VVci5d: "Completed" }
 def VVRPZT(self, title):
  colList = self.VVc7Yu.VVDx8h()
  path = colList[6]
  url  = colList[8]
  if self.VV1Pyb() : self.VV1kxV("Cannot delete !\n\nFile is downloading.")
  else      : FFWV4g(self.SELF, BF(self.VVQ9Fa, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVQ9Fa(self, path, url):
  m3u8Log = self.VVc7Yu.VVDx8h()[12]
  if m3u8Log : os.system(FFqAik("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFqAik("rm -r '%s'" % path))
  self.VVnf0T(False)
  self.VVEVTy()
 def VVnf0T(self, VV3KZ2=True):
  if self.VV1Pyb():
   FFkxeT(self.VVc7Yu, self.VVOOVu(self.VVGta7), 500)
  else:
   colList  = self.VVc7Yu.VVDx8h()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VV1JEl(state) in (self.VVDSd7, self.VVci5d, self.VVBPdD):
    lines = CCEVEE.VVjgfC()
    newLines = []
    found = False
    for line in lines:
     if CCEVEE.VV42rc(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVufWJ(newLines)
     self.VVEVTy()
     FFkxeT(self.VVc7Yu, "Removed.", 1000)
    else:
     FFkxeT(self.VVc7Yu, "Not found.", 1000)
   elif VV3KZ2:
    self.VV1kxV("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVv3Ck(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFWV4g(self.SELF, BF(self.VVobrE, flag), ques, title=title)
 def VVobrE(self, flag):
  list = []
  for ndx, row in enumerate(self.VVc7Yu.VVgeCg()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VV1JEl(state)
   if   flag == flagVal == self.VVci5d: list.append(decodedUrl)
   elif flag == flagVal == self.VVDSd7 : list.append(decodedUrl)
  lines = CCEVEE.VVjgfC()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVufWJ(newLines)
   self.VVEVTy()
   FFkxeT(self.VVc7Yu, "%d removed." % totRem, 1000)
  else:
   FFkxeT(self.VVc7Yu, "Not found.", 1000)
 def VVs77x(self):
  colList  = self.VVc7Yu.VVDx8h()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFkxeT(self.VVc7Yu, "Poster exists", 1500)
  else    : FFqcaP(self.VVc7Yu, BF(self.VV2Hz8, decodedUrl, path, png), title="Checking Server ...")
 def VV2Hz8(self, decodedUrl, path, png):
  err = self.VVS7gi(decodedUrl, path, png)
  if err:
   FF1uaI(self.SELF, err, title="Poster Download")
 def VVS7gi(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCTQO7.VVnvRd(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCHF2n.VVPQqT(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCHF2n.VVl3JC(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCHF2n.VVEbNz(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFR3XR(pUrl, "ajpanel_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFqAik("mv -f '%s' '%s'" % (tPath, png)))
   CCpbjY.VVBCwU(self.SELF, VVffaB=png, showGrnMsg="Downloaded")
   return ""
 def VVNZlP(self, VVc7Yu, title, txt, colList):
  def VV8Y2s(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV0iDg(key, val) : return "\n%s:\n%s\n" % (FFHqZk(key, VVWFW6), val.strip())
  heads  = self.VVc7Yu.VVFjOt()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV8Y2s(heads[i]  , CCk3u6.VVeQ5q(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV8Y2s("Downloaded" , CCk3u6.VVeQ5q(int(curSize), mode=0))
   else:
    txt += VV8Y2s(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV0iDg(heads[i], colList[i])
  FFX3Iv(self.SELF, txt, title=title)
 def VVO2PA(self, VVc7Yu, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCk3u6.VVVJhr(self.SELF, path)
  else    : FFkxeT(self.VVc7Yu, "File not found", 1000)
 def VVYbA6(self, VVc7Yu):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVc7Yu:
   self.VVc7Yu.cancel()
  del self
 def VVgvRU(self, VVc7Yu, title, txt, colList):
  c1, c2, c3 = VVyuFD, VV0kWR, VVWFW6
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVd21k = []
  VVd21k.append((c1 + "Remove current row"       , "VVnf0T" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVd21k.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c2 + "Delete the file (and remove from list)"  , "VVRPZT"))
  VVd21k.append(VVNCuu)
  VVd21k.append((resumeTxt + " Auto Resume"       , "VVfMWu" ))
  VVd21k.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVd21k.append(VVNCuu)
  t = "Download Movie Poster "
  if FFJkN3(decodedUrl): VVd21k.append((c3 + "%s(from server)" % t , "VVs77x"  ))
  else      : VVd21k.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVd21k.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVd21k.append(("Open in File Manager"  ,      ))
  FFxMT2(self.SELF, BF(self.VVIdg0, VVc7Yu), VVd21k=VVd21k, title=self.Title, VVL2h3=True, width=800, VVP2Aq=True, VVW1CX="#1a001122", VVLasp="#1a001122")
 def VVIdg0(self, VVc7Yu, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVnf0T"  : self.VVnf0T()
   elif ref == "remFinished"   : self.VVv3Ck(self.VVci5d, txt)
   elif ref == "remPending"   : self.VVv3Ck(self.VVDSd7, txt)
   elif ref == "VVRPZT" : self.VVRPZT(txt)
   elif ref == "VVs77x"  : self.VVs77x()
   elif ref == "VVfMWu"  : FFWvPK(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFWvPK(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCk3u6, mode=CCk3u6.VVtRZy, jumpToFile=path)
    else    : FFkxeT(VVc7Yu, "Path not found !", 1500)
 def VVOcCk(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCTQO7.VVnvRd(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VV1kxV("Could not get download link !\n\nTry again later.")
     return
  for line in CCEVEE.VVjgfC():
   if CCEVEE.VV42rc(decodedUrl, line):
    if self.VVc7Yu:
     self.VVxacX(decodedUrl)
     FFnCJX(BF(FFkxeT, self.VVc7Yu, "Already listed !", 2000))
    break
  else:
   params = self.VVnISW(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VV1kxV(params[0])
   elif len(params) == 2:
    FFWV4g(self.SELF, BF(self.VVWAJG, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCk3u6.VVeQ5q(fSize)
    FFWV4g(self.SELF, BF(self.VVd1Pi, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVd1Pi(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCEVEE.VVMrun(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVEVTy()
  if self.VVc7Yu:
   self.VVc7Yu.VVKZI8()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCEVEE.VVVrBm, path, decodedUrl)
   self.VVIyM4(threadName, url, decodedUrl, path, resp)
 def VVxacX(self, decodedUrl):
  if self.VVc7Yu:
   for ndx, row in enumerate(self.VVc7Yu.VVgeCg()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVc7Yu:
     self.VVc7Yu.VVQ2AR(ndx)
     break
 def VVnISW(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVsbVV(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VV685O(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCTQO7.VVnvRd(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCTQO7.VV4LO2()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCEVEE.VVo07t(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCEVEE.VVblHR(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVWAJG(self, resp, decodedUrl):
  if not os.system(FFqAik("which ffmpeg")) == 0:
   FFWV4g(self.SELF, BF(CCHF2n.VV86xP, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVsbVV(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVV9Bo(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFWV4g(self.SELF, BF(self.VVuWsE, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVuWsE(rTxt, rUrl)
  else:
   self.VV1kxV("Cannot process m3u8 file !")
 def VVV9Bo(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVd21k = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCHF2n.VV1eQd(rUrl, fPath)
   VVd21k.append((resol, fullUrl))
  if VVd21k:
   FFxMT2(self.SELF, self.VVeX6v, VVd21k=VVd21k, title="Resolution", VVL2h3=True, VVP2Aq=True)
  else:
   self.VV1kxV("Cannot get Resolutions list from server !")
 def VVeX6v(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFWV4g(self.SELF, BF(FFnCJX, BF(self.VVmm8W, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFnCJX(BF(self.VVmm8W, resolUrl))
 def VVmm8W(self, resolUrl):
  txt, err = CCTQO7.VVYV6p(resolUrl)
  if err : self.VV1kxV(err)
  else : self.VVuWsE(txt, resolUrl)
 def VVINIs(self, logF, decodedUrl):
  found = False
  lines = CCEVEE.VVjgfC()
  with open(CCEVEE.VVMrun(), "w") as f:
   for line in lines:
    if CCEVEE.VV42rc(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCEVEE.VVMrun(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVEVTy()
  if self.VVc7Yu:
   self.VVc7Yu.VVKZI8()
 def VVuWsE(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCHF2n.VV1eQd(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VV1kxV("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVINIs(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFqAik("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCEVEE.VVVrBm, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVL8I0(dnldLog):
  if fileExists(dnldLog):
   dur = CCEVEE.VVWQD7(dnldLog)
   if dur > -1:
    tim = CCEVEE.VVYobW(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVWQD7(dnldLog):
  lines = FFjUOl("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVYobW(dnldLog):
  lines = FFjUOl("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV685O(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFbR9b(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFqAik("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVIyM4(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVc7Yu.VVDx8h()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VV9Ldt, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV9Ldt(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVfnIA == path:
       break
     else:
      break
  except:
   return
  if CCEVEE.VVfnIA:
   CCEVEE.VVfnIA = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FF2oRJ(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVnISW(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV9Ldt(url, decodedUrl, path, resp, totFileSize, True)
 def VVqFsl(self, VVc7Yu, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVtxVU() : FFkxeT(self.VVc7Yu, self.VVOOVu(self.VVci5d), 500)
  elif not self.VV1Pyb() : FFkxeT(self.VVc7Yu, self.VVOOVu(self.VVBPdD), 500)
  elif m3u8Log      : FFWV4g(self.SELF, self.VV7GWK, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVsiXb():
    CCEVEE.VVfnIA = colList[6]
    FFkxeT(self.VVc7Yu, "Stopping ...", 1000)
   else:
    FFkxeT(self.VVc7Yu, "Stopped", 500)
 def VV7GWK(self, withMsg=True):
  if withMsg:
   FFkxeT(self.VVc7Yu, "Stopping ...", 1000)
  os.system(FFqAik("killall -INT ffmpeg"))
 def VVZJuU(self, *args):
  if   self.VVtxVU() : FFkxeT(self.VVc7Yu, self.VVOOVu(self.VVci5d) , 500)
  elif self.VV1Pyb() : FFkxeT(self.VVc7Yu, self.VVOOVu(self.VVGta7), 500)
  else:
   resume = False
   m3u8Log = self.VVc7Yu.VVDx8h()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFWV4g(self.SELF, BF(self.VVOSZh, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV9nim():
    resume = True
   if resume: FFqcaP(self.VVc7Yu, BF(self.VVzeF7), title="Checking Server ...")
   else  : FFkxeT(self.VVc7Yu, "Cannot resume !", 500)
 def VVOSZh(self, m3u8Log):
  os.system(FFqAik("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFqcaP(self.VVc7Yu, BF(self.VVzeF7), title="Checking Server ...")
 def VVzeF7(self):
  colList  = self.VVc7Yu.VVDx8h()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCTQO7.VVnvRd(decodedUrl)
   if url:
    decodedUrl = self.VVnc3t(decodedUrl, url)
   else:
    self.VV1kxV("Could not get download link !\n\nTry again later.")
    return
  curSize = FF2oRJ(path)
  params = self.VVnISW(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VV1kxV(params[0])
   return
  elif len(params) == 2:
   self.VVWAJG(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVnc3t(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCEVEE.VVVrBm, path, decodedUrl)
  if resumable: self.VVIyM4(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VV1kxV("Cannot resume from server !")
 def VVsbVV(self, decodedUrl):
  fileExt = CCHF2n.VV2NtU(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFcmN9(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VV1kxV(self, txt):
  FF1uaI(self.SELF, txt, title=self.Title)
 def VVsiXb(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCEVEE.VVVrBm, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VV1Pyb(self):
  decodedUrl = self.VVc7Yu.VVDx8h()[9]
  return decodedUrl in self.VVsiXb()
 def VVtxVU(self):
  colList = self.VVc7Yu.VVDx8h()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FF2oRJ(path)) == size
 def VV9nim(self):
  colList = self.VVc7Yu.VVDx8h()
  path = colList[6]
  size = int(colList[7])
  curSize = FF2oRJ(path)
  if curSize > -1:
   size -= curSize
  err = CCEVEE.VVblHR(size)
  if err:
   FF1uaI(self.SELF, err, title=self.Title)
   return False
  return True
 def VVufWJ(self, list):
  with open(CCEVEE.VVMrun(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVnc3t(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCEVEE.VVjgfC()
  url = decodedUrl
  with open(CCEVEE.VVMrun(), "w") as f:
   for line in lines:
    if CCEVEE.VV42rc(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVEVTy()
  return url
 @staticmethod
 def VVjgfC():
  list = []
  if fileExists(CCEVEE.VVMrun()):
   for line in FFwiKR(CCEVEE.VVMrun()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VV42rc(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVblHR(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCk3u6.VViGlx(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCk3u6.VVeQ5q(size), CCk3u6.VVeQ5q(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVMTps(SELF):
  tot = CCEVEE.VVRphd()
  if tot:
   FF1uaI(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVRphd():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCEVEE.VVVrBm):
    c += 1
  return c
 @staticmethod
 def VVanPw():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCEVEE.VVVrBm, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVBqxI():
  return len(CCEVEE.VVjgfC()) == 0
 @staticmethod
 def VVLeOz():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVbUBs():
  mPoints = CCEVEE.VVLeOz()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFqAik("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVMrun():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVBiV1(SELF):
  CCEVEE.VVS8HW(SELF, CCEVEE.VVZyAI)
 @staticmethod
 def VV4RWm(SELF):
  CCEVEE.VVS8HW(SELF, CCEVEE.VVVant, startDnld=True)
 @staticmethod
 def VVY7ba(SELF, url):
  CCEVEE.VVS8HW(SELF, CCEVEE.VVVant, startDnld=True, decodedUrl=url)
 @staticmethod
 def VV1Nac(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF)
  added, skipped = CCEVEE.VVAPh7([decodedUrl])
  FFkxeT(SELF, "Added", 1000)
 @staticmethod
 def VVAPh7(list):
  added = skipped = 0
  for line in CCEVEE.VVjgfC():
   for ndx, url in enumerate(list):
    if url and CCEVEE.VV42rc(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCEVEE.VVMrun(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVS8HW(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCr3lG.VV0eGg(SELF):
   return
  if mode == CCEVEE.VVZyAI and CCEVEE.VVBqxI():
   FF1uaI(SELF, "Download list is empty !", title=title)
  else:
   inst = CCEVEE(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVo07t(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCqzRz(Screen, CCV4IB):
 VVRX23 = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FF1pMw(VVlugA, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCV4IB.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFrOoX(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVjpAa())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVw6vF       ,
   "info"  : self.VVvoLM      ,
   "epg"  : self.VVvoLM      ,
   "menu"  : self.VVYub6     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVs6ld   ,
   "green"  : self.VV2cTJ  ,
   "blue"  : self.VVjgjR      ,
   "yellow" : self.VVE4Fx ,
   "left"  : BF(self.VVxIpO, -1)    ,
   "right"  : BF(self.VVxIpO,  1)    ,
   "play"  : self.VVvqfq      ,
   "pause"  : self.VVvqfq      ,
   "playPause" : self.VVvqfq      ,
   "stop"  : self.VVvqfq      ,
   "rewind" : self.VVz2dF      ,
   "forward" : self.VVus9j      ,
   "rewindDm" : self.VVz2dF      ,
   "forwardDm" : self.VVus9j      ,
   "last"  : self.VVt3UN      ,
   "next"  : self.VVOZTz      ,
   "pageUp" : BF(self.VVYM08, True)  ,
   "pageDown" : BF(self.VVYM08, False)  ,
   "chanUp" : BF(self.VVYM08, True)  ,
   "chanDown" : BF(self.VVYM08, False)  ,
   "up"  : BF(self.VVYM08, True)  ,
   "down"  : BF(self.VVYM08, False)  ,
   "audio"  : BF(self.VViTMC, True)  ,
   "subtitle" : BF(self.VViTMC, False)  ,
   "text"  : self.VVcTr4  ,
   "0"   : BF(self.VVJm5m , 10)   ,
   "1"   : BF(self.VVJm5m , 1)   ,
   "2"   : BF(self.VVJm5m , 2)   ,
   "3"   : BF(self.VVJm5m , 3)   ,
   "4"   : BF(self.VVJm5m , 4)   ,
   "5"   : BF(self.VVJm5m , 5)   ,
   "6"   : BF(self.VVJm5m , 6)   ,
   "7"   : BF(self.VVJm5m , 7)   ,
   "8"   : BF(self.VVJm5m , 8)   ,
   "9"   : BF(self.VVJm5m , 9)
  }, -1)
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  if not CCqzRz.VVRX23:
   CCqzRz.VVRX23 = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFVTEo(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFVTEo(self["myPlayRpt"], "rpt")
  self.VVDxQp()
  self.instance.move(ePoint(40, 40))
  self.VVGiBq(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVODiK)
  except:
   self.timer.callback.append(self.VVODiK)
  self.timer.start(250, False)
  self.VVODiK("Checking ...")
  self.VVXUZO()
 def VV2cTJ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  self.lastSubtitle = CCHCsp.VVZCyS()
  if "chCode" in iptvRef:
   if CCr3lG.VV0eGg(self):
    self.VVXUZO(True)
  else:
   self.VVODiK("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVDxQp(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VV68Ou()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVHeSZ + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFrI2P(self["myTitle"], tColor)
  FFrI2P(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFrI2P(self["myPlay%s" % item], tColor)
  picFile = CCfm5u.VVZ0vT(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCfm5u.VVqZnS(self)
  cl = CCd6Xx.VVztKX(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVODiK(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCEVEE.VVRphd()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VV68Ou()
  if evName:
   evName = "    %s    " % FFHqZk(evName, VVekE1)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVeQjQ():
   FFm6nb(self["myPlayBlu"], "#00FFFFFF")
   FFrI2P(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFm6nb(self["myPlayBlu"], "#00FFFF88")
   FFrI2P(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFrI2P(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFK3ps(percVal, 0, 100)
   width = int(FFPwFt(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFrI2P(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFm6nb(self["myPlayMsg"], "#0000ffff")
   else  : FFm6nb(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFm6nb(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFm6nb(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVFyXm()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VV9lB8(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCHCsp.VVgUDO(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVt3UN()
  state = self.VVtqPz()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFm6nb(self["myPlayMsg"], "#0000ff00")
  else     : FFm6nb(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VV68Ou(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF4ETG(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCfm5u.VVzkt5(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCaOWR()
   tpTxt, satTxt = tp.VVGlqs(refCode)
   self.satInfo_TP = tpTxt + "  " + FFHqZk(satTxt, VVRK3s)
  evName = evNameNext = ""
  evLst = CCTkbp.VVE7c4(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FF7qij(info, iServiceInformation.sVideoWidth) or -1
   h = FF7qij(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FF7qij(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCfm5u.VVZtXd(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VV52Xv(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF6f6P(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF6f6P(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FF6f6P(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVYub6(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VV68Ou()
  FFJkN3Series = FFcmN9(decodedUrl)
  VVd21k = []
  if self.isFromExternal:
   VVd21k.append((VVRK3s + "IPTV Menu", "iptv"))
   VVd21k.append(VVNCuu)
  if isIptv and not "&end=" in decodedUrl and not FFJkN3Series:
   uType, uHost, uUser, uPass, uId, uChName = CCHF2n.VVPQqT(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVd21k.append((VVRK3s + "Catchup Programs", "catchup" ))
    VVd21k.append(VVNCuu)
  if refCode:
   c = VVHeSZ
   VVd21k.append((c + "Stop Current Service"  , "stop"  ))
   VVd21k.append((c + "Restart Current Service" , "restart"  ))
   txt = "Replay with ..."
   if isDvb: VVd21k.append((txt     ,    ))
   else : VVd21k.append((c + txt    , "replayWith" ))
   VVd21k.append(VVNCuu)
  if FFJkN3Series:
   VVd21k.append((VVRK3s + "File Size (on server)", "fileSize" ))
   VVd21k.append(VVNCuu)
  if self.enableDownloadMenu:
   c = VVRK3s
   addSep = False
   if isIptv and FFJkN3Series:
    VVd21k.append((c + "Start Download"   , "dload_cur" ))
    VVd21k.append((c + "Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCEVEE.VVBqxI():
    VVd21k.append((VVRK3s + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVd21k.append(VVNCuu)
  fPath, fDir, fName = CCk3u6.VVURIr(self)
  if fPath:
   c = VVusL5
   if self.enableOpenInFMan and not CCk3u6.VVlW72:
    VVd21k.append((c + "Open path in File Manager", "VVs72a"))
   VVd21k.append((c + "Add to Bouquet"             , "VVYvod" ))
   VVd21k.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVSVew"  ))
   VVd21k.append(VVNCuu)
  if isDvb:
   VVd21k.append((VVRK3s + "Signal Monitor", "sigMon"   ))
  if posTxt and durTxt:
   VVd21k.append((VVWFW6 + "Start Subtitle", "VVnQgi"))
   VVd21k.append(VVNCuu)
  if CFG.playerPos.getValue() : VVd21k.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVd21k.append(("Move Bar to Top"  , "top"     ))
  VVd21k.append(("Help"             , "help"    ))
  FFxMT2(self, self.VVLar3, VVd21k=VVd21k, width=600, title="Options")
 def VVLar3(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVE4Fx()
   elif item == "stop"     : self.VVWmZU(0)
   elif item == "restart"    : self.VVWmZU(1)
   elif item == "replayWith"   : self.VVfu5l()
   elif item == "fileSize"    : FFqcaP(self, BF(CCfm5u.VVUXJW, self), title="Checking Server")
   elif item == "dload_cur"   : CCEVEE.VV4RWm(self)
   elif item == "addToDload"   : CCEVEE.VV1Nac(self)
   elif item == "dload_stat"   : CCEVEE.VVBiV1(self)
   elif item == "VVs72a" : self.close("close_openInFileMan")
   elif item == "VVYvod" : self.VVYvod()
   elif item == "VVnQgi"  : self.VVBHU7()
   elif item == "VVSVew"  : self.VVSVew()
   elif item == "botm"     : self.VVGiBq(0)
   elif item == "top"     : self.VVGiBq(1)
   elif item == "sigMon"    : self.VVs6ld()
   elif item == "help"     : FFkKs9(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCqzRz.VVRX23 = None
 def VVWmZU(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVDxQp()
   elif typ == 1:
    self.VVODiK("Restarting Service ...")
    FFnCJX(BF(self.VVkzTq, serv))
 def VVkzTq(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  if "&end=" in decodedUrl: BF(self.VVXUZO, True)
  else     : self.session.nav.playService(serv)
 def VVfu5l(self):
  FFxMT2(self, self.VVzRYJ, VVd21k=CCk3u6.VVR8LJ(), width=650, title="Select Player", VVW1CX="#11220000", VVLasp="#11220000")
 def VVzRYJ(self, rType=None):
  if rType:
   FFl4EX(self, eServiceReference(rType + ":" + self.session.nav.getCurrentlyPlayingServiceReference().toString().split(":", 1)[1]))
 def VVYvod(self):
  fPath, fDir, fName = CCk3u6.VVURIr(self)
  if fPath: picker = CCB8uV(self, self, "Add Current Movie to a Bouquet", BF(self.VVlIEf, [fPath]))
  else : FFkxeT(self, "Path not found !", 1500)
 def VVlIEf(self, pathLst):
  return CCB8uV.VVnOLT(pathLst)
 def VVSVew(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVODiK(txt, highlight=ok)
 def VVGiBq(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFWvPK(CFG.playerPos, pos)
 def VVs6ld(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCfm5u.VVzkt5(serv)
   if isDvb: self.close("close_sig")
   else : self.VVODiK("No Signal for Current Service")
 def VVBHU7(self):
  self.session.openWithCallback(self.VVYxbJ, BF(CCHCsp))
 def VVcTr4(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VV68Ou()
   if posTxt and durTxt: self.VVBHU7()
   else    : self.VVODiK("No duration Info. !")
 def VVYxbJ(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVYM08(True)
  elif reason == "subtZapDn" : self.VVYM08(False)
  elif reason == "pause"  : self.VVvqfq()
  elif reason == "audio"  : self.VViTMC(True)
  elif reason == "subtitle" : self.VViTMC(False)
  elif reason == "rewind"     : self.VVz2dF()
  elif reason == "forward" : self.VVus9j()
  elif reason == "rewindDm" : self.VVz2dF()
  elif reason == "forwardDm" : self.VVus9j()
  else      : txt = reason
  if txt:
   FFkxeT(self, txt, 2000)
 def VVw6vF(self):
  if self.isManualSeek:
   self.VVCHAy()
   self.VV9lB8(self.manualSeekPts)
  elif self.shown:
   if CCHCsp.VVLL4r(self): self.VVBHU7()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVCHAy()
  else    : self.close()
 def VVvoLM(self):
  FFdGDb(self, fncMode=CCfm5u.VVRV7u)
 def VVvqfq(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVODiK("Toggling Play/Pause ...")
 def VVCHAy(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVxIpO(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVLHRd()
   else:
    self.manualSeekSec += direc * self.VVLHRd()
    self.manualSeekSec = FFK3ps(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFPwFt(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FF6f6P(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVJm5m(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVjpAa())
   FFWvPK(CFG.playerJumpMin, self.jumpMinutes)
  self.VVODiK("Changed Seek Time to : %d%s" % (val, self.VVOOZ7()))
 def VVjpAa(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVOOZ7())
 def VVOOZ7(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVaIoH(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVLHRd(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVFyXm(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVjgjR(self):
  cList = self.VVeQjQ()
  if cList:
   VVd21k = []
   for pts, what in cList:
    txt = FF6f6P(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVd21k.append((txt, pts))
   FFxMT2(self, self.VV7Kb7, VVd21k=VVd21k, title="Cut List")
  else:
   self.VVODiK("No Cut-List for this channel !")
 def VV7Kb7(self, item=None):
  if item:
   self.VV9lB8(item)
 def VVeQjQ(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVus9j(self) : self.VVMBkn(1)
 def VVz2dF(self) : self.VVMBkn(-1)
 def VVMBkn(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVLHRd() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVaIoH())
    self.VVODiK(txt)
  except:
   self.VVODiK("Cannot jump")
 def VV9lB8(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVODiK("Changing Time ...")
 def VVt3UN(self):
  self.VVWmZU(1)
  self.VVODiK("Replaying ...")
  self.VVCHAy()
 def VVOZTz(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVODiK("Jumping to end ...")
  except:
   pass
 def VVtqPz(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVYM08(self, isUp):
  if self.enableZapping:
   self.VVODiK("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVCHAy()
   if self.iptvTableParams:
    FFnCJX(BF(self.VVwfl4, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
    if "/timeshift/" in decodedUrl:
     self.VVODiK("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVHev8()
  else:
   self.VVODiK("Zap Disabled !")
 def VVHev8(self):
  self.lastPlayPos = 0
  self.VVDxQp()
  self.VVXUZO()
 def VVwfl4(self, isUp):
  CCHF2n_inatance, VVc7Yu, mode = self.iptvTableParams
  if isUp : VVc7Yu.VVTS9W()
  else : VVc7Yu.VV9spY()
  colList = VVc7Yu.VVDx8h()
  if mode == "localIptv":
   chName, chUrl = CCHF2n_inatance.VVSp2J(VVc7Yu, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCHF2n_inatance.VVAWte(VVc7Yu, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCHF2n_inatance.VV4LZv(mode, VVc7Yu, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCHF2n_inatance.VV0phW(mode, VVc7Yu, colList)
  else:
   self.VVODiK("Cannot Zap")
   return
  FFxZcp(self, chUrl, VVY2Q7=False)
  self.VVHev8()
 def VVXUZO(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
   if not self.VVjB8B(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVODiK("Refreshing Portal")
   FFnCJX(self.VVkedb)
  except:
   pass
 def VVkedb(self):
  self.restoreLastPlayPos = self.VVHY8Q()
 def VVE4Fx(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
  if not decodedUrl or FFcmN9(decodedUrl):
   self.VVODiK("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCHF2n.VVPQqT(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVODiK("Reading Program List ...")
   ok_fnc = BF(self.VVTsOt, refCode, chName, streamId, uHost, uUser, uPass)
   FFnCJX(BF(CCHF2n.VVpmY1, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVODiK("Cannot process this channel")
 def VVTsOt(self, refCode, chName, streamId, uHost, uUser, uPass, VVc7Yu, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVc7Yu.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVODiK("Changing Program ...")
   FFnCJX(BF(self.VV4cex, chUrl))
  else:
   self.VVODiK("Incorrect Timestamp !")
 def VV4cex(self, chUrl):
  FFxZcp(self, chUrl, VVY2Q7=False)
  self.lastPlayPos = 0
  self.VVDxQp()
 def VViTMC(self, isAudio):
  try:
   VV56ys = InfoBar.instance
   if VV56ys:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV56ys)
    else  : self.session.open(SubtitleSelection, VV56ys)
  except:
   pass
 @staticmethod
 def VVTJ9Z(session, mode=None):
  if   mode == "close_sig"   : FF0wqg(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCHF2n)
  elif mode == "close_openInFileMan" : session.open(CCk3u6, gotoMovie=True)
 @staticmethod
 def VVfphk(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCqzRz.VVTJ9Z, session), CCqzRz, isFromExternal=isFromExternal, **kwargs)
class CCrr7R(Screen):
 def __init__(self, session, title="", VVJpRC="Continue?", VVvl21=True, VVwjVK=False):
  self.skin, self.skinParam = FF1pMw(VVamHR, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVJpRC = VVJpRC
  self.VVwjVK = VVwjVK
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVvl21 : VVd21k = [no , yes]
  else   : VVd21k = [yes, no ]
  FFrOoX(self, title, VVd21k=VVd21k, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVw6vF ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVJpRC)
  if self.VVwjVK:
   self["myLabel"].instance.setHAlign(0)
  self.VVSqNk()
  FFmysb(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFmGpj(self["myMenu"])
  FFf2Vt(self, self["myMenu"])
 def VVw6vF(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVSqNk(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCUwHt(Screen):
 def __init__(self, session, title="", VVd21k=None, width=1000, height=850, VVlvFD=30, barText="", minRows=1, OKBtnFnc=None, infoBtnFnc=None, VVZms0=None, VVQIvk=None, VVHLqw=None, VVldmG=None, VVL2h3=False, VVP2Aq=False, yellowBasePath=None, VVW1CX="#22003344", VVLasp="#22002233"):
  self.skin, self.skinParam = FF1pMw(VVilCV, width, height, 50, 40, 30, VVW1CX, VVLasp, VVlvFD, barHeight=40, topRightBtns=3 if infoBtnFnc else 0)
  self.session   = session
  self.VVd21k   = VVd21k
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.infoBtnFnc   = infoBtnFnc
  self.VVZms0   = VVZms0
  self.VVQIvk  = VVQIvk
  self.VVHLqw  = ("Delete File", BF(self.VVhSBH, yellowBasePath)) if not yellowBasePath is None else VVHLqw
  self.VVldmG   = VVldmG
  self.VVL2h3  = VVL2h3
  self.VVP2Aq  = VVP2Aq
  self.Title    = title
  FFrOoX(self, title, VVd21k=VVd21k)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVw6vF    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVFK7n   ,
   "red"  : self.VV0pBc   ,
   "green"  : self.VVYydp   ,
   "yellow" : self.VVUDDq   ,
   "blue"  : self.VVMw6Q   ,
   "pageUp" : self.VVbGeh ,
   "chanUp" : self.VVbGeh ,
   "pageDown" : self.VV4DAH  ,
   "chanDown" : self.VV4DAH  ,
   "0"   : BF(self.VVBpC2, 0) ,
   "1"   : BF(self.VVBpC2, 1) ,
   "2"   : BF(self.VVBpC2, 2) ,
   "3"   : BF(self.VVBpC2, 3) ,
   "4"   : BF(self.VVBpC2, 4) ,
   "5"   : BF(self.VVBpC2, 5) ,
   "6"   : BF(self.VVBpC2, 6) ,
   "7"   : BF(self.VVBpC2, 7) ,
   "8"   : BF(self.VVBpC2, 8) ,
   "9"   : BF(self.VVBpC2, 9)
  }, -1)
  FFiLOZ(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFmysb(self["myMenu"])
  FFCRqe(self, minRows=self.minRows)
  FFtTSm(self)
  self.VV9OTt(self["keyRed"]  , self.VVZms0 )
  self.VV9OTt(self["keyGreen"] , self.VVQIvk )
  self.VV9OTt(self["keyYellow"] , self.VVHLqw )
  self.VV9OTt(self["keyBlue"]  , self.VVldmG )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFnQcA(self)
 def VV9OTt(self, btnObj, btnFnc):
  if btnFnc:
   FFddoJ(btnObj, btnFnc[0])
 def VVPXAG(self, fnc=None):
  self.VVQIvk = fnc
  if fnc : self.VV9OTt(self["keyGreen"], self.VVQIvk)
  else : self["keyGreen"].hide()
 def VVBpC2(self, digit):
  digit = str(digit)
  VVd21k = self["myMenu"].list
  for ndx, item in enumerate(VVd21k):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFFnqK(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVDB8c(ndx)
     self.VVw6vF()
     break
 def VVw6vF(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVL2h3: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVFK7n(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.infoBtnFnc and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.infoBtnFnc(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VV0pBc(self)  : self.VVmQTl(self.VVZms0)
 def VVYydp(self) : self.VVmQTl(self.VVQIvk)
 def VVUDDq(self) : self.VVmQTl(self.VVHLqw)
 def VVMw6Q(self) : self.VVmQTl(self.VVldmG)
 def VVmQTl(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVP2Aq:
    self.cancel()
 def VVDB8c(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVpI48(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVd21k = self["myMenu"].list
  VVd21k.pop(ndx)
  if len(VVd21k) > 0: self["myMenu"].setList(VVd21k)
  else    : self.close()
 def VVhSBH(self, basePath, menuObj, fName):
  FFWV4g(self, BF(self.VVjTdw, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVjTdw(self, path):
  FFC2Q5(path)
  if fileExists(path) : FFkxeT(self, "Not deleted", 1000)
  else    : self.VVpI48()
 def VV6wRf(self, VVd21k):
  if len(VVd21k) > 0:
   newList = []
   for item in VVd21k:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFCRqe(self, minRows=self.minRows)
  else:
   self.close("")
 def VVTvQu(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFCRqe(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVKQFA(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVbGeh(self) : self["myMenu"].moveToIndex(0)
 def VV4DAH(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCCXfc(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVHQsP=None, VV4tj2=None, VVje1O=None, VVlvFD=26, VVDYPP=False, VV0rqo=0, VVmG3M=None, VVAe4b=None, VVDti0=None, VVZyxX=None, VVQJvS=None, VVOr9v=None, VV1jVB=None, VVbNxw=None, VVVD8O=None, VVmn6o=-1, VVRqqp=0, searchCol=0, lastFindConfigObj=None, VVW1CX=None, VVLasp=None, VV9atA="#00dddddd", VVHSOH="#11002233", VVNfgg="#00ff8833", VVJqmr="#11111111", VVFNoD="#0a555555", VVVIOU="#0affffff", VVcwBH="#11552200", VVufHs="#0055ff55"):
  self.skin, self.skinParam = FF1pMw(VVAG6M, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFrOoX(self, title)
  self.Title     = title
  self.header     = header
  self.VVHQsP     = VVHQsP
  self.totalCols    = len(VVHQsP[0])
  self.VV0rqo   = VV0rqo
  self.lastSortModeIsReverese = False
  self.VVDYPP   = VVDYPP
  self.VVVM8I   = 0.01
  self.VViZAL   = 0.02
  self.VVzDqM = 0.03
  self.VVFlGs  = 1
  self.VVje1O = VVje1O
  self.colWidthPixels   = []
  self.VVmG3M   = VVmG3M
  self.OKButtonObj   = None
  self.VVAe4b   = VVAe4b
  self.VVDti0   = VVDti0
  self.VVZyxX   = VVZyxX
  self.VVQJvS  = VVQJvS
  self.VVOr9v   = VVOr9v
  self.VV1jVB    = VV1jVB
  self.VVbNxw   = VVbNxw
  self.tableRefreshCB   = None
  self.VVVD8O  = VVVD8O
  self.VVmn6o    = VVmn6o
  self.VVRqqp   = VVRqqp
  self.searchCol    = searchCol
  self.VV4tj2    = VV4tj2
  self.keyPressed    = -1
  self.VVlvFD    = FF5ia4(VVlvFD)
  self.VVGpoq    = FF6lPQ(self.VVlvFD, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVW1CX    = VVW1CX
  self.VVLasp      = VVLasp
  self.VV9atA    = FFj7n6(VV9atA)
  self.VVHSOH    = FFj7n6(VVHSOH)
  self.VVNfgg    = FFj7n6(VVNfgg)
  self.VVJqmr    = FFj7n6(VVJqmr)
  self.VVFNoD   = FFj7n6(VVFNoD)
  self.VVVIOU    = FFj7n6(VVVIOU)
  self.VVcwBH    = FFj7n6(VVcwBH)
  self.VVufHs   = FFj7n6(VVufHs)
  self.VVh7FN  = False
  self.selectedItems   = 0
  self.VVGfs3   = FFj7n6("#01fefe01")
  self.VVuGLY   = FFj7n6("#11400040")
  self.VVLzfg  = self.VVGfs3
  self.VV9RCu  = self.VVJqmr
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVRqqp:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVRqqp == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVWSf1  ,
   "red"  : self.VVLa87  ,
   "green"  : self.VVJbRf ,
   "yellow" : self.VVnLIp ,
   "blue"  : self.VVvlLo  ,
   "menu"  : self.VV2DiP ,
   "info"  : self.VVuwSL  ,
   "cancel" : self.VViHnX  ,
   "up"  : self.VV9spY    ,
   "down"  : self.VVTS9W  ,
   "left"  : self.VVMmw5   ,
   "right"  : self.VVrz2e  ,
   "next"  : self.VVa4AL  ,
   "last"  : self.VVDuVX  ,
   "home"  : self.VVEWia  ,
   "pageUp" : self.VVEWia  ,
   "chanUp" : self.VVEWia  ,
   "end"  : self.VVKZI8  ,
   "pageDown" : self.VVKZI8  ,
   "chanDown" : self.VVKZI8
  }, -1)
  FFiLOZ(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  try:
   self.VVDPOI()
  except Exception as e:
   FF1uaI(self, str(e), title=self.Title)
   self.close(None)
 def VVDPOI(self):
  FFnQcA(self)
  if self.VVW1CX:
   FFrI2P(self["myTitle"], self.VVW1CX)
  if self.VVLasp:
   FFrI2P(self["myBody"] , self.VVLasp)
   FFrI2P(self["myTableH"] , self.VVLasp)
   FFrI2P(self["myTable"] , self.VVLasp)
   FFrI2P(self["myBar"]  , self.VVLasp)
  self.VV9OTt(self.VVDti0  , self["keyRed"])
  self.VV9OTt(self.VVZyxX  , self["keyGreen"])
  self.VV9OTt(self.VVQJvS , self["keyYellow"])
  self.VV9OTt(self.VVOr9v  , self["keyBlue"])
  if self.VVmG3M:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVmG3M[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVmG3M[0])
    FFrI2P(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVGpoq)
  self["myTableH"].l.setFont(0, gFont(VVlQv4, self.VVlvFD))
  self["myTable"].l.setItemHeight(self.VVGpoq)
  self["myTable"].l.setFont(0, gFont(VVlQv4, self.VVlvFD))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVGpoq)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVGpoq))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVGpoq)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVGpoq
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVGpoq * len(self.VVHQsP) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVje1O:
   self.VVje1O = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVje1O)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV4tj2:
   self.VV4tj2 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV4tj2
   self.VV4tj2 = []
   for item in tmpList:
    self.VV4tj2.append(item | RT_VALIGN_CENTER)
  self.VVm1LJ()
  if self.VV1jVB:
   self.VV1jVB(self)
 def VV9OTt(self, btnFnc, btn):
  if btnFnc : FFddoJ(btn, btnFnc[0])
  else  : FFddoJ(btn, "")
 def VVFkG5(self, waitTxt):
  FFqcaP(self, self.VVm1LJ, title=waitTxt)
 def VVm1LJ(self, onlyHeader=False):
  try:
   if self.header:
    self["myTableH"].setList([self.VVrDR1(0, self.header, self.VVVIOU, self.VVcwBH, self.VVVIOU, self.VVcwBH, self.VVufHs)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVHQsP):
    self["myTable"].list.append(self.VVrDR1(c, row, self.VV9atA, self.VVHSOH, self.VVNfgg, self.VVJqmr, None))
   self.VVHQsP = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVmn6o > -1:
    self["myTable"].moveToIndex(self.VVmn6o )
   self.VVss21()
   if self.VVRqqp:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVGpoq * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FF6ScH(self, width, newH)
   if self.VVbNxw:
    self.VVmQTl(self.VVbNxw, None)
   if self.tableRefreshCB:
    self.VVmQTl(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FF1uaI(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVrDR1(self, keyIndex, columns, VV9atA, VVHSOH, VVNfgg, VVJqmr, VVufHs):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVufHs and ndx == self.VV0rqo : textColor = VVufHs
   else           : textColor = VV9atA
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFj7n6(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVHSOH = c
    entry = span.group(3)
   if self.VV4tj2[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVGpoq)
           , font   = 0
           , flags   = self.VV4tj2[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVHSOH
           , color_sel  = VVNfgg
           , backcolor_sel = VVJqmr
           , border_width = 1
           , border_color = self.VVFNoD
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVuwSL(self):
  rowData = self.VVv6lH()
  if rowData:
   title, txt, colList = rowData
   if self.VVAe4b:
    fnc  = self.VVAe4b[1]
    params = self.VVAe4b[2]
    fnc(self, title, txt, colList)
   else:
    FFX3Iv(self, txt, title)
 def VVWSf1(self):
  if   self.VVh7FN : self.VVgsLJ(self.VVbJrA(), mode=2)
  elif self.VVmG3M  : self.VVmQTl(self.VVmG3M, None)
  else      : self.VVuwSL()
 def VVLa87(self) : self.VVmQTl(self.VVDti0 , self["keyRed"])
 def VVJbRf(self) : self.VVmQTl(self.VVZyxX , self["keyGreen"])
 def VVnLIp(self): self.VVmQTl(self.VVQJvS , self["keyYellow"])
 def VVvlLo(self) : self.VVmQTl(self.VVOr9v , self["keyBlue"])
 def VVmQTl(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFkxeT(self, buttonFnc[3])
    FFnCJX(BF(self.VVzA8G, buttonFnc))
   else:
    self.VVzA8G(buttonFnc)
 def VVzA8G(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVv6lH()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVgsLJ(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVGfs3
   newRow = self.VVDx8h()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVrDR1(ndx, newRow, self.VV9atA, self.VVHSOH, self.VVNfgg, self.VVJqmr, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVrDR1(ndx, newRow, self.VVGfs3, self.VVuGLY, self.VVLzfg, self.VV9RCu, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVbJrA() < len(self["myTable"].list) - 1:
    self.VVTS9W()
   else:
    self.VVss21()
 def VVwMcz(self)  : FFqcaP(self, BF(self.VVKpl2, True ), title="Selecting all ..."  )
 def VVQprB(self) : FFqcaP(self, BF(self.VVKpl2, False), title="Unselecting all ...")
 def VVKpl2(self, isSel=True):
  if isSel:
   fg, bg = self.VVGfs3, self.VVuGLY
   self.selectedItems = len(self["myTable"].list)
   self.VVVUw7(True)
  else:
   fg, bg = self.VV9atA, self.VVHSOH
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVGfs3
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVv6lH(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVje1O[i] > 1 or self.VVje1O[i] == self.VVVM8I or self.VVje1O[i] == self.VVzDqM:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VViHnX(self):
  if self.VVVD8O : self.VVVD8O(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVZMUB(self):
  return self["myTitle"].getText().strip()
 def VVFjOt(self):
  return self.header
 def VV8abG(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVRoRr(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFm6nb(self["myBar"], color)
 def VV5Wyx(self, txt):
  FFkxeT(self, txt)
 def VVdNoE(self, txt, Time=1000):
  FFkxeT(self, txt, Time)
 def VVKYNy(self): self["keyGreen"].show()
 def VVOwuz(self): self["keyGreen"].hide()
 def VV4ccy(self): return self["keyGreen"].visible
 def VVSLMs(self):
  FFkxeT(self)
 def VVTbDK(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVtZhN(self):
  return len(self["myTable"].list)
 def VVbJrA(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVpm2D(self):
  return len(self["myTable"].list)
 def VVVUw7(self, isOn):
  self.VVh7FN = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVOr9v: self["keyBlue"].hide()
   if self.VVmG3M and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVOr9v: self["keyBlue"].show()
   if self.VVmG3M and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVmG3M[0])
   self.VVQprB()
  FFrI2P(self["myTitle"], color)
  FFrI2P(self["myBar"]  , color)
 def VVCSth(self):
  return self.VVh7FN
 def VVcONI(self):
  return self.selectedItems
 def VVlpBm(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVss21()
 def VVa3tc(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVAXCn(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVtZhN()
  txt += FF8jk7("Total Unique Items", VV0kWR)
  for i in range(self.totalCols):
   if self.VVje1O[i - 1] > 1 or self.VVje1O[i - 1] == self.VVVM8I or self.VVje1O[i - 1] == self.VVzDqM:
    name, tot = self.VVa3tc(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFX3Iv(self, txt)
 def VVGBYR(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVDx8h(self):
  return self.VVDV9v(self["myTable"].l.getCurrentSelectionIndex())
 def VVDV9v(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV4ZQl(self, newList, newTitle="", VVvu5oMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VV8abG(newTitle)
  if newList:
   self.VVHQsP = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVDYPP and self.VV0rqo == 0:
    isNum = True
   else:
    for cols in self.VVHQsP:
     if not FFxOk9(cols[self.VV0rqo]): break
    else:
     isNum = True
   if isNum: self.VVHQsP.sort(key=lambda x: int(x[self.VV0rqo])  , reverse=self.lastSortModeIsReverese)
   else : self.VVHQsP.sort(key=lambda x: x[self.VV0rqo].lower() , reverse=self.lastSortModeIsReverese)
   if VVvu5oMsg : self.VVFkG5("Refreshing ...")
   else   : self.VVm1LJ()
  else:
   FF1uaI(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVYxhd(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVrDR1(self.VVpm2D(), row, self.VV9atA, self.VVHSOH, self.VVNfgg, self.VVJqmr, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVKZI8()
 def VVe4e7(self):
  self["myTable"].list.pop(self.VVbJrA())
  self["myTable"].l.setList(self["myTable"].list)
 def VV2PiO(self, data):
  ndx = self.VVbJrA()
  newRow = self.VVrDR1(ndx, data, self.VV9atA, self.VVHSOH, self.VVNfgg, self.VVJqmr, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVss21()
   return True
  else:
   return False
 def VVENUj(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVrDR1(ndx, data, self.VV9atA, self.VVHSOH, self.VVNfgg, self.VVJqmr, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VV8moO()
 def VV8moO(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVTjqd(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVKO1o(self, colNum, textToFind, VV3KZ2=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVss21()
    break
  else:
   if VV3KZ2:
    FFkxeT(self, "Not found", 1000)
 def VVJePS(self, colDict, VV3KZ2=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVss21()
    return
  if VV3KZ2:
   FFkxeT(self, "Not found", 1000)
 def VVZS7p(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVJUx9(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFxOk9(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVnygS(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVGfs3:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVTo2y(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVGfs3:
     return ndx
  return -1
 def VV6eMo(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVGfs3:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VV5ag5(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVGfs3: return True
  else        : return False
 def VVgeCg(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV2DiP(self):
  if not self["keyMenu"].getVisible() or self.VVRqqp:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVbJrA()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVd21k1, VVKaUh = CC4Wdl.VVVpFG(self, False, False)
  VVd21k = []
  VVd21k.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVd21k.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVd21k.append(("Find ...\t\t%s" % (FFHqZk(txt, VVpihg) if txt else ""), "findNew"   ))
  VVd21k.append(itemOf(bool(VVd21k1)    , "Find (from Filter) ..."   , "filter"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Table Statistcis"             , "tableStat"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append((FFHqZk("Export Table to .html"     , VV0kWR) , "VVxk1g" ))
  VVd21k.append((FFHqZk("Export Table to .csv"     , VV0kWR) , "VVaUPp" ))
  VVd21k.append((FFHqZk("Export Table to .txt (Tab Separated)", VV0kWR) , "VVCekz" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVje1O[i] > 1 or self.VVje1O[i] == self.VViZAL:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVd21k.append(VVNCuu)
   if tot == 1 : VVd21k.append(("Sort", sList[0][1]))
   else  : VVd21k += sList
  VVldmG = ("Keys Help", self.FF8dRUHelp)
  FFxMT2(self, self.VVyJvT, VVd21k=VVd21k, title=self.VVZMUB(), VVldmG=VVldmG)
 def VVyJvT(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVv5c7()
   elif item == "findPrev"  : self.VVv5c7(isPrev=True)
   elif item == "findNew"  : self.VV9PoX()
   elif item == "filter"  : self.VVf1EL()
   elif item == "tableStat" : self.VVAXCn()
   elif item == "VVxk1g": FFqcaP(self, self.VVxk1g, title=title)
   elif item == "VVaUPp" : FFqcaP(self, self.VVaUPp , title=title)
   elif item == "VVCekz" : FFqcaP(self, self.VVCekz , title=title)
   else:
    self.lastSortModeIsReverese = False
    if self.VV0rqo == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VV0rqo = item
    if self.VVDYPP and self.VV0rqo == 0 or self.VVJUx9(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVm1LJ(onlyHeader=True)
 def FF8dRUHelp(self, menuInstance, path):
  FFkKs9(self, "_help_table", "Table (Keys Help)")
 def VV9spY(self):
  self["myTable"].up()
  self.VVss21()
 def VVTS9W(self):
  self["myTable"].down()
  self.VVss21()
 def VVMmw5(self):
  self["myTable"].pageUp()
  self.VVss21()
 def VVrz2e(self):
  self["myTable"].pageDown()
  self.VVss21()
 def VVEWia(self):
  self["myTable"].moveToIndex(0)
  self.VVss21()
 def VVKZI8(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVss21()
 def VVQ2AR(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVss21()
 def VVa4AL(self):
  if self.lastFindConfigObj.getValue():
   if self.VVbJrA() == len(self["myTable"].list) - 1 : FFkxeT(self, "End reached", 1000)
   else              : self.VVv5c7()
  else:
   FFkxeT(self, 'Set "Find" in Menu', 1500)
 def VVDuVX(self):
  if self.lastFindConfigObj.getValue():
   if self.VVbJrA() == 0 : FFkxeT(self, "Top reached", 1000)
   else       : self.VVv5c7(isPrev=True)
  else:
   FFkxeT(self, 'Set "Find" in Menu', 1500)
 def VVuenS(self, txt):
  FFWvPK(self.lastFindConfigObj, txt)
 def VV9PoX(self):
  FFX1El(self, self.VVZWPO, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVZWPO(self, VVouBA):
  if not VVouBA is None:
   txt = VVouBA.strip()
   self.VVuenS(txt)
   if VVouBA: self.VVv5c7(reset=True)
   else  : FFkxeT(self, "Nothing to find !", 1500)
 def VVf1EL(self):
  VVd21k, VVKaUh = CC4Wdl.VVVpFG(self, False, False)
  VVHLqw = ("Edit Filter", BF(self.VV1aBK, VVKaUh))
  if VVd21k : FFxMT2(self, self.VVF3nC, VVd21k=VVd21k, VVHLqw=VVHLqw, title="Find from Filter")
  else  : FFkxeT(self, "Filter Error !", 1500)
 def VVF3nC(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVuenS(txt)
    self.VVv5c7(reset=True)
   else:
    FFkxeT(self, "No entry !", 1500)
 def VV1aBK(self, VVKaUh, VVFy7pObj, sel):
  if fileExists(VVKaUh) : CCwq37(self, VVKaUh, VVXlAY=None)
  else       : FFr3Kr(self, VVKaUh)
  VVFy7pObj.cancel()
 def VVv5c7(self, reset=False, isPrev=False):
  curRow = self.VVbJrA()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CC4Wdl.VV610T(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVQ2AR(i)
      break
    elif any(x in line for x in tupl):
     self.VVQ2AR(i)
     break
   else:
    FFkxeT(self, "Not found", 1000)
  else:
   FFkxeT(self, "Check your query", 1500)
 def VVCekz(self):
  expFile = self.VVTXMd() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVuL6g()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVDV9v(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVje1O[ndx] > self.VVFlGs or self.VVje1O[ndx] == self.VVzDqM:
      col = self.VVFNUK(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVLbDR(expFile)
 def VVaUPp(self):
  expFile = self.VVTXMd() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVuL6g()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVDV9v(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVje1O[ndx] > self.VVFlGs or self.VVje1O[ndx] == self.VVzDqM:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVFNUK(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVLbDR(expFile)
 def VVxk1g(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVZMUB(), PLUGIN_NAME, VVS3nw)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVZMUB()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVuL6g()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVje1O:
   colgroup += '   <colgroup>'
   for w in self.VVje1O:
    if w > self.VVFlGs or w == self.VVzDqM:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVTXMd() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVDV9v(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVje1O[ndx] > self.VVFlGs or self.VVje1O[ndx] == self.VVzDqM:
      col = self.VVFNUK(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVLbDR(expFile)
 def VVuL6g(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVje1O[ndx] > self.VVFlGs or self.VVje1O[ndx] == self.VVzDqM:
     newRow.append(col.strip())
  return newRow
 def VVFNUK(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFFnqK(col)
 def VVTXMd(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVZMUB())
  fileName = fileName.replace("__", "_")
  path  = FFjZE4(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF5Vj3()
  return expFile
 def VVLbDR(self, expFile):
  FFfF2j(self, "File exported to:\n\n%s" % expFile, title=self.VVZMUB())
 def VVss21(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCd6Xx():
 def __init__(self, pixmapObj, picPath, VVHSOH=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVHSOH  = VVHSOH or "#2200002a"
 def VVWzXC(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVgXBY)
    except:
     self.picLoad.PictureData.get().append(self.VVgXBY)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVHSOH])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVgXBY(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVobAr(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVztKX(pixmapObj, path, VVHSOH=None):
  cl = CCd6Xx(pixmapObj, path, VVHSOH)
  ok = cl.VVWzXC()
  if ok: return cl
  else : return None
class CCpbjY(Screen):
 def __init__(self, session, title="", VVffaB=None, showGrnMsg="", fileList=None, curIndex=0, cbFnc=None):
  scrW, scrH = FFJKbx()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FF1pMw(VVQsOr, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVffaB = VVffaB
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFrOoX(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVQ3lw  ,
   "up" : BF(self.VVzi36, -1),
   "down" : BF(self.VVzi36,  1),
   "left" : BF(self.VVzi36, -1),
   "right" : BF(self.VVzi36,  1)
  }, -1)
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  self.VVwp2r()
  self.picViewer = CCd6Xx.VVztKX(self["myPic"], self.VVffaB)
  if self.picViewer:
   if self.showGrnMsg:
    FFkxeT(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF1uaI(self, "Cannot view picture file:\n\n%s" % self.VVffaB)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVobAr()
  if self.cbFnc: self.cbFnc(self.VVffaB)
 def VVzi36(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVffaB = FFjZE4(os.path.dirname(self.VVffaB)) + fName
    self.picViewer.picPath = self.VVffaB
    self.picViewer.VVWzXC()
    self.VVwp2r()
 def VVQ3lw(self):
  txt = "%s:\n  %s" % (FFHqZk("Path", VVWFW6), self.VVffaB)
  size, sizeTxt, resTxt, form, mode = CCxpGD.VVeNP8(self.VVffaB)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFHqZk("Properties", VVWFW6)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFX3Iv(self, txt, title="File Information")
 def VVwp2r(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVffaB)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVBCwU(SELF, VVffaB, title="", showGrnMsg="", fileList=None, curIndex=0, cbFnc=None):
  SELF.session.open(BF(CCpbjY, title=title, VVffaB=VVffaB, showGrnMsg=showGrnMsg, fileList=fileList, curIndex=curIndex, cbFnc=cbFnc))
class CCTQSn(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FF1pMw(VVHX1w, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFrOoX(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.onExit)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFqAik("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVtZ8s(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCTQSn.VVfAq9, SELF), CCTQSn, mviFile)
 @staticmethod
 def VVfAq9(SELF, reason=None):
  if reason == -1: FF1uaI(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCgs0Z(Screen, ConfigListScreen):
 VVveMg = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FF1pMw(VVCVur, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFrOoX(self, title=self.Title)
  FFddoJ(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry(VVbL9B *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVbL9B *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVbL9B *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVdCiI()
  self.onShown.append(self.VVOOZO)
 def VVdCiI(self):
  kList = {
    "ok" : self.VVw6vF   ,
    "green" : self.VVCOue ,
    "menu" : self.VVPLR6 ,
    "cancel": self.VVpE4x ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VV5uEX, 0)
     kList["chanDown"] = BF(self["config"].VV5uEX, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFtTSm(self)
  FFmysb(self["config"])
  FFCRqe(self, self["config"])
  FFnQcA(self)
  self["config"].onSelectionChanged.append(self.VVXAI5)
  FFrI2P(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VVXAI5()
 def VVXAI5(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVw6vF(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVHAIm()
   elif item == CFG.MovieDownloadPath   : self.VVg378(item, self["config"].getCurrent()[0])
   elif isinstance(item, ConfigDirectory) : self.VVVUr7(item)
   else         : CCgs0Z.VVcuOM(self, item, title)
 @staticmethod
 def VVcuOM(SELF, confItem, title, lst=None, cbFnc=None):
  isBool = isinstance(confItem, ConfigYesNo)
  isLst  = isinstance(confItem, ConfigSelection)
  isTxt  = isinstance(confItem, ConfigText)
  if not lst:
   if   isBool : lst = [(True, "ON"), (False, "OFF")]
   elif isLst : lst = confItem.choices.choices
   else  : return
  curNdx = defNdx = -1
  VVd21k = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",VVbL9B)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVpihg + txt
    elif val == confItem.default: defNdx, txt = ndx, VVsZ3Y + txt
   VVd21k.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVldmG  = ("Current", BF(CCgs0Z.VVaXht, curNdx))
  VVHLqw = ("Default", BF(CCgs0Z.VVaXht, defNdx))
  menuInstance = FFxMT2(SELF, BF(CCgs0Z.VVt1m9, confItem, cbFnc), VVd21k=VVd21k, width=1200, VVHLqw=VVHLqw, VVldmG=VVldmG, title=title, VVW1CX="#33221111", VVLasp="#33110011")
  menuInstance.VVDB8c(curNdx)
 @staticmethod
 def VVt1m9(confItem, cbFnc, item=None):
  if not item is None:
   FFWvPK(confItem, item)
   if cbFnc:
    cbFnc()
 @staticmethod
 def VVaXht(ndx, VVFy7pObj, item):
  VVFy7pObj.VVDB8c(ndx)
 @staticmethod
 def VVj4kz(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVg378(self, item, title):
  tot = CCEVEE.VVRphd()
  if tot : FF1uaI(self, "Cannot change while downloading.", title=title)
  else : self.VVVUr7(item)
 def VVHAIm(self):
  VVd21k = []
  VVd21k.append(("Auto Find" , "auto"))
  VVd21k.append(("Custom Path" , "cust"))
  FFxMT2(self, self.VV9mk0, VVd21k=VVd21k, title="IPTV Hosts Files Path")
 def VV9mk0(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVh5ZI)
   elif item == "cust":
    VVG5ES = self.VVPHuV()
    if VVG5ES : self.VVYY3M(VVG5ES)
    else  : self.session.openWithCallback(self.VVQ68q, BF(CCk3u6, mode=CCk3u6.VV0IRk, VVl4c7="/"))
 def VVYY3M(self, VVG5ES):
  VVVD8O = self.VV1pC5
  VVDti0 = ("Remove"  , self.VVfyvf , [])
  VVQJvS = ("Add "  , self.VVrXlK, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VV4tj2  = (LEFT   , LEFT  )
  FF8dRU(self, None, title="IPTV Hosts Search Paths", header=header, VVHQsP=VVG5ES, width=1200, height=700, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=26, VVVD8O=VVVD8O, VVDti0=VVDti0, VVQJvS=VVQJvS
    , VVW1CX="#11220000", VVLasp="#11110000", VVHSOH="#11110011", VVNfgg="#00ffff00", VVJqmr="#00223025", VVFNoD="#0a333333", VVcwBH="#0a400040")
 def VV1pC5(self, VVc7Yu):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVLwC1)
  VVc7Yu.cancel()
 def VVQ68q(self, path):
  if path:
   FFWvPK(CFG.iptvHostsDirs, FFjZE4(path.strip()))
   VVG5ES = self.VVPHuV()
   if VVG5ES : self.VVYY3M(VVG5ES)
   else  : FFkxeT(self, "Cannot add dir", 1500)
 def VVKhid(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVh5ZI:
   return []
  return lst
 def VVPHuV(self):
  lst = self.VVKhid()
  if lst:
   VVG5ES = []
   for Dir in lst:
    VVG5ES.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVG5ES.sort(key=lambda x: x[0].lower())
   return VVG5ES
  else:
   return []
 def VVrXlK(self, VVc7Yu, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVIpvs, VVc7Yu)
         , BF(CCk3u6, mode=CCk3u6.VV0IRk, VVl4c7=sDir))
 def VVIpvs(self, VVc7Yu, path):
  if path:
   path = FFjZE4(path.strip())
   if self.VVlfO2(VVc7Yu, path):
    FFkxeT(VVc7Yu, "Already added", 1500)
   else:
    lst = self.VVKhid()
    lst.append(path)
    FFWvPK(CFG.iptvHostsDirs, ",".join(lst))
    VVG5ES = self.VVPHuV()
    VVc7Yu.VV4ZQl(VVG5ES, tableRefreshCB=BF(self.VVIJ2W, path))
 def VVIJ2W(self, path, VVc7Yu, title, txt, colList):
  self.VVlfO2(VVc7Yu, path)
 def VVlfO2(self, VVc7Yu, path):
  for ndx, row in enumerate(VVc7Yu.VVgeCg()):
   if row[0].strip() == path.strip():
    VVc7Yu.VVQ2AR(ndx)
    return True
  return False
 def VVfyvf(self, VVc7Yu, title, txt, colList):
  path = colList[0]
  FFWV4g(self, BF(self.VVhRJw, VVc7Yu), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVhRJw(self, VVc7Yu):
  row = VVc7Yu.VVDx8h()
  path, rem = row[0], row[1]
  VVG5ES = []
  lst = []
  for ndx, row in enumerate(VVc7Yu.VVgeCg()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVG5ES.append((tPath, tRem))
  if len(VVG5ES) > 0:
   FFWvPK(CFG.iptvHostsDirs, ",".join(lst))
   VVc7Yu.VV4ZQl(VVG5ES)
   FFkxeT(VVc7Yu, "Deleted", 1500)
  else:
   FFWvPK(CFG.iptvHostsMode, VVh5ZI)
   FFWvPK(CFG.iptvHostsDirs, "")
   VVc7Yu.cancel()
   FFnCJX(BF(FFkxeT, self, "Changed to Auto-Find", 1500))
 def VVVUr7(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVUKHp, configObj)
         , BF(CCk3u6, mode=CCk3u6.VV0IRk, VVl4c7=sDir))
 def VVUKHp(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVpE4x(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFWV4g(self, self.VVCOue, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVCOue(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVp2hV()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVPLR6(self):
  VVd21k = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVd21k.append((txt    , "VVldbL"   ))
  else        : VVd21k.append((txt    ,       ))
  VVd21k.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Reset %s Settings" % PLUGIN_NAME      , "VV8beX"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Backup %s Settings" % PLUGIN_NAME      , "VV5NHf"  ))
  VVd21k.append(("Restore %s Settings" % PLUGIN_NAME     , "VVt508"  ))
  if fileExists(VV4J76 + CCgs0Z.VVveMg):
   VVd21k.append(VVNCuu)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVd21k.append(('%s Checking for Update' % txt1     , txt2     ))
   VVd21k.append(("Reinstall %s" % PLUGIN_NAME      , "VVMhgr"  ))
   VVd21k.append(("Update %s" % PLUGIN_NAME      , "VVkoku"   ))
  FFxMT2(self, self.VVt4ng, VVd21k=VVd21k, title="Config. Options")
 def VVt4ng(self, item=None):
  if item:
   if   item == "VVldbL"  : FFWV4g(self, self.VVldbL , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCYElQ)
   elif item == "VV8beX"  : FFWV4g(self, BF(self.VV8beX, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VV5NHf" : self.VV5NHf()
   elif item == "VVt508" : FFqcaP(self, self.VVt508, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFWvPK(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFWvPK(CFG.checkForUpdateAtStartup, False)
   elif item == "VVMhgr" : FFqcaP(self, BF(self.VVwmqN, True ), "Checking Server ...")
   elif item == "VVkoku"  : FFqcaP(self, BF(self.VVwmqN, False), "Checking Server ...")
 def VV5NHf(self):
  path = "%sajpanel_settings_%s" % (VV4J76, FF5Vj3())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVmqmq, path))
  FFfF2j(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVt508(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFjUOl("find / %s -iname '%s*' | grep %s" % (FFflDg(1), name, name))
  if files:
   for line in files:
    if not fileExists(line):
     FFWV4g(self, BF(self.VVJ4ij, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
     break
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVd21k = []
    for line in files:
     VVd21k.append((line, line))
    FFxMT2(self, BF(self.VVuyLy, title), title=title, VVd21k=VVd21k, width=1200, yellowBasePath="")
  else:
   FF1uaI(self, "No settings files found !", title=title)
 def VVJ4ij(self, title, path=None):
  sDir = "/"
  for path in (VV4J76, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVuyLy, title), BF(CCk3u6, patternMode="ajpSet", VVl4c7=sDir))
 def VVuyLy(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFwiKR(path)
    self.VV8beX()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVp2hV()
    FFQRh2()
    FFkxeT(self, "Apllied", 1500, isGrn=True)
   else:
    FFr3Kr(self, path, title=title)
 def VVldbL(self):
  newPath = FFjZE4(VV4J76)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVp2hV()
 @staticmethod
 def VVhYws():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VV8beX(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVp2hV()
  if exit:
   self.close()
 def VVp2hV(self):
  configfile.save()
  global VV4J76
  VV4J76 = CFG.backupPath.getValue()
  FFu8f1()
 def VVwmqN(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCgs0Z.VVlO1Z()
  if   err    : FF1uaI(self, err, title)
  elif isHigher or force : FFWV4g(self, BF(FFqcaP, self, BF(self.VV6DP6, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFfF2j(self, FFHqZk("No update required.", VVs4yr) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VV6DP6(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFT9Rp() == "dpkg" else "ipk")
  path, err = FFR3XR(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FF5LxN(VVqGH2, path)
   else : cmd = FF5LxN(VVXZJT, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
    FFkyna(self, cmd, title=title)
   else:
    FF3PaD(self, title=title)
  else:
   FF1uaI(self, err, title=title)
 @staticmethod
 def VVlO1Z():
  span = iSearch(r"v*(\d.\d.\d)", VVS3nw, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VV4J76 + CCgs0Z.VVveMg
  if fileExists(path):
   span = iSearch(r"(http.+)", FFnMVE(path), IGNORECASE)
   if span : url = FFjZE4(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFR3XR(url + "version", "ajpanel_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFnMVE(path).strip().replace(" ", "")
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, True if webTup > curTup else False, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCYElQ(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF1pMw(VVXLg7, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFrOoX(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVNE1F("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVNE1F("\c00888888", i) + sp + "GREY\n"
   txt += self.VVNE1F("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVNE1F("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVNE1F("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVNE1F("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVNE1F("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVNE1F("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVNE1F("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVNE1F("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVNE1F("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVNE1F("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVw6vF ,
   "green" : self.VVw6vF ,
   "left" : self.VV0XiC ,
   "right" : self.VV2FzN ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  self.VVTRo9()
 def VVw6vF(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFWV4g(self, self.VVo6m5, "Change to : %s" % txt, title=self.Title)
 def VVo6m5(self):
  FFWvPK(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVssvP()
  self.close()
 def VV0XiC(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVTRo9()
 def VV2FzN(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVTRo9()
 def VVTRo9(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVNE1F(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVVD33(color):
  if VVsZ3Y: return "\\" + color
  else    : return ""
 @staticmethod
 def VVssvP():
  global VV2vWn, VVekE1, VVpiVU, VVHeSZ, VV0kWR, VVyuFD, VVjQpG, VVQtLp, VVs4yr, VVusL5, VVsZ3Y, VVWFW6, VVpihg, VVRK3s, VVpZn3, VVBNow
  VVBNow   = CCYElQ.VVNE1F("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVekE1    = CCYElQ.VVNE1F("\c00888888", COLOR_SCHEME_NUM)
  VV2vWn  = CCYElQ.VVNE1F("\c005A5A5A", COLOR_SCHEME_NUM)
  VVQtLp    = CCYElQ.VVNE1F("\c00FF0000", COLOR_SCHEME_NUM)
  VVpiVU   = CCYElQ.VVNE1F("\c00FF5000", COLOR_SCHEME_NUM)
  VVHeSZ   = CCYElQ.VVNE1F("\c00FFBB66", COLOR_SCHEME_NUM)
  VVsZ3Y   = CCYElQ.VVNE1F("\c00FFFF00", COLOR_SCHEME_NUM)
  VVWFW6 = CCYElQ.VVNE1F("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVs4yr   = CCYElQ.VVNE1F("\c0000FF00", COLOR_SCHEME_NUM)
  VVusL5  = CCYElQ.VVNE1F("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVjQpG    = CCYElQ.VVNE1F("\c000066FF", COLOR_SCHEME_NUM)
  VVpihg    = CCYElQ.VVNE1F("\c0000FFFF", COLOR_SCHEME_NUM)
  VVRK3s  = CCYElQ.VVNE1F("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVpZn3   = CCYElQ.VVNE1F("\c00FA55E7", COLOR_SCHEME_NUM)
  VV0kWR    = CCYElQ.VVNE1F("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVyuFD  = CCYElQ.VVNE1F("\c00FFC0C0", COLOR_SCHEME_NUM)
CCYElQ.VVssvP()
class CCuvFH(Screen):
 def __init__(self, session, path, VVjafw):
  self.skin, self.skinParam = FF1pMw(VVrQkp, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVTvnF   = path
  self.VVPqUT   = ""
  self.VVLjwZ   = ""
  self.VVjafw    = VVjafw
  self.VVdwlW    = ""
  self.VVLX6E  = ""
  self.VVhfD2    = False
  self.VVL2gM  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VV7EBP  = "enigma2-plugin-extensions-"
  self.VV3m6u  = "enigma2-plugin-systemplugins-"
  self.VVoMzL = "enigma2-"
  self.VV382D  = 0
  self.VVPOSb  = 1
  self.VVpqpj  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVwIsk = "DEBIAN"
  else        : self.VVwIsk = "CONTROL"
  self.controlPath = self.Path + self.VVwIsk
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVjafw:
   self.packageExt  = ".deb"
   self.VVHSOH  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVHSOH  = "#11001020"
  FFrOoX(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFddoJ(self["keyRed"] , "Create")
  FFddoJ(self["keyGreen"] , "Post Install")
  FFddoJ(self["keyYellow"], "Installation Path")
  FFddoJ(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV4L4J  ,
   "green"   : self.VVXUUL ,
   "yellow"  : self.VVQAWF  ,
   "blue"   : self.VVv0Mv  ,
   "cancel"  : self.VVWfk2
  }, -1)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFnQcA(self)
  if self.VVHSOH:
   FFrI2P(self["myBody"], self.VVHSOH)
   FFrI2P(self["myLabel"], self.VVHSOH)
  self.VV9cBM(True)
  self.VVhgL1(True)
 def VVhgL1(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VViyO6()
  if isFirstTime:
   if   package.startswith(self.VV7EBP) : self.VVTvnF = VVP65U + self.VVdwlW + "/"
   elif package.startswith(self.VV3m6u) : self.VVTvnF = VVXS9f + self.VVdwlW + "/"
   else            : self.VVTvnF = self.Path
  if self.VVhfD2 : myColor = VV0kWR
  else    : myColor = VVBNow
  txt  = ""
  txt += "Source Path\t: %s\n" % FFHqZk(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFHqZk(self.VVTvnF, VVsZ3Y)
  if self.VVLjwZ : txt += "Package File\t: %s\n" % FFHqZk(self.VVLjwZ, VVekE1)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFHqZk("Check Control File fields : %s" % errTxt, VVpiVU)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFHqZk("Restart GUI", VV0kWR)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFHqZk("Reboot Device", VV0kWR)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFHqZk("Post Install", VVs4yr), act)
  if not errTxt and VVpiVU in controlInfo:
   txt += "Warning\t: %s\n" % FFHqZk("Errors in control file may affect the result package.", VVpiVU)
  txt += "\nControl File\t: %s\n" % FFHqZk(self.controlFile, VVekE1)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVXUUL(self):
  if self["keyGreen"].getVisible():
   VVd21k = []
   VVd21k.append(("No Action"    , "noAction"  ))
   VVd21k.append(("Restart GUI"    , "VVlT6a"  ))
   VVd21k.append(("Reboot Device"   , "rebootDev"  ))
   FFxMT2(self, self.VVWpjW, title="Package Installation Option (after completing installation)", VVd21k=VVd21k)
 def VVWpjW(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVlT6a"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV9cBM(False)
   self.VVhgL1()
 def VVQAWF(self):
  rootPath = FFHqZk("/%s/" % self.VVdwlW, VVWFW6)
  VVd21k = []
  VVd21k.append(("Current Path"        , "toCurrent"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Extension Path"       , "toExtensions" ))
  VVd21k.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVd21k.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFxMT2(self, self.VVgvb5, title="Installation Path", VVd21k=VVd21k)
 def VVgvb5(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVvcIj(FFUdYG(self.Path, True))
   elif item == "toExtensions"  : self.VVvcIj(VVP65U)
   elif item == "toSystemPlugins" : self.VVvcIj(VVXS9f)
   elif item == "toRootPath"  : self.VVvcIj("/")
   elif item == "toRoot"   : self.VVvcIj("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVd4nA, BF(CCk3u6, mode=CCk3u6.VV0IRk, VVl4c7=VV4J76))
 def VVd4nA(self, path):
  if len(path) > 0:
   self.VVvcIj(path)
 def VVvcIj(self, parent, withPackageName=True):
  if withPackageName : self.VVTvnF = parent + self.VVdwlW + "/"
  else    : self.VVTvnF = "/"
  mode = self.VV8kxA()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVKtSK(mode), self.controlFile))
  self.VVhgL1()
 def VVv0Mv(self):
  if fileExists(self.controlFile):
   lines = FFwiKR(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFX1El(self, self.VVQ4DO, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF1uaI(self, "Version not found or incorrectly set !")
  else:
   FFr3Kr(self, self.controlFile)
 def VVQ4DO(self, VVouBA):
  if VVouBA:
   version, color = self.VVRMvC(VVouBA, False)
   if color == VVpihg:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVouBA, self.controlFile))
    self.VVhgL1()
   else:
    FF1uaI(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVWfk2(self):
  if self.newControlPath:
   if self.VVhfD2:
    self.VV5lD1()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFHqZk(self.newControlPath, VVekE1)
    txt += FFHqZk("Do you want to keep these files ?", VVsZ3Y)
    FFWV4g(self, self.close, txt, callBack_No=self.VV5lD1, title="Create Package", VVwjVK=True)
  else:
   self.close()
 def VV5lD1(self):
  os.system(FFqAik("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVKtSK(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVLX6E
  if package.startswith(self.VVoMzL):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVoMzL, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVPOSb : prefix = self.VV7EBP
  elif mode == self.VVpqpj : prefix = self.VV3m6u
  return (prefix + name).lower()
 def VV8kxA(self):
  if   self.VVTvnF.startswith(VVP65U) : return self.VVPOSb
  elif self.VVTvnF.startswith(VVXS9f) : return self.VVpqpj
  else            : return self.VV382D
 def VV9cBM(self, isFirstTime):
  self.VVdwlW   = FF4Cf3(self.Path)
  self.VVdwlW   = "_".join(self.VVdwlW.split())
  self.VVLX6E = self.VVdwlW.lower()
  self.VVhfD2 = self.VVLX6E == VVqIfZ.lower()
  if self.VVhfD2 and self.VVLX6E.endswith("ajpan"):
   self.VVLX6E += "el"
  if self.VVhfD2 : self.VVPqUT = VV4J76
  else    : self.VVPqUT = CFG.packageOutputPath.getValue()
  self.VVPqUT = FFjZE4(self.VVPqUT)
  if not pathExists(self.controlPath):
   os.system(FFqAik("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VV8kxA()
  if fileExists(self.controlFile):
   lines = FFwiKR(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVhfD2 : version, descripton, maintainer = VVS3nw , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVdwlW , self.VVdwlW
   txt = ""
   txt += "Package: %s\n"  % self.VVKtSK(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVhfD2 : t = PLUGIN_NAME
  else    : t = self.VVdwlW
  self.VVkE0X(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVkE0X(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVhfD2 : self.VVkE0X(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVS3nw))
  else    : self.VVkE0X(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVdwlW)
  if isFirstTime and not mode == self.VV382D:
   self.postInstAcion = 1
  txt = self.VVin5X(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFnMVE(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVin5X(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFqAik("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVkE0X(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVin5X(self, action):
  sep  = "echo '%s'\n" % VVbL9B
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VViyO6(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFwiKR(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFHqZk(line, VVpiVU)
     elif not line.startswith(" ")    : line = FFHqZk(line, VVpiVU)
     else          : line = FFHqZk(line, VVpihg)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVpihg
   else   : color = VVpiVU
   descr = FFHqZk(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVpiVU
     elif line.startswith((" ", "\t")) : color = VVpiVU
     elif line.startswith("#")   : color = VVekE1
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVRMvC(val, True)
      elif key == "Version"  : version, color = self.VVRMvC(val, False)
      elif key == "Maintainer" : maint  , color = val, VVpihg
      elif key == "Architecture" : arch  , color = val, VVpihg
      else:
       color = VVpihg
      if not key == "OE" and not key.istitle():
       color = VVpiVU
     else:
      color = VV0kWR
     txt += FFHqZk(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVLjwZ = self.VVPqUT + packageName
   self.VVL2gM = True
   errTxt = ""
  else:
   self.VVLjwZ  = ""
   self.VVL2gM = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVRMvC(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVpihg
  else          : return val, VVpiVU
 def VV4L4J(self):
  if not self.VVL2gM:
   FF1uaI(self, "Please fix Control File errors first.")
   return
  if self.VVjafw: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFUdYG(self.VVTvnF, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVdwlW
  symlinkTo  = FFjMQE(self.Path)
  dataDir   = self.VVTvnF.rstrip("/")
  removePorjDir = FFqAik("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFqAik("rm -f '%s'" % self.VVLjwZ) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFJLoq()
  if self.VVjafw:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFRWxt("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVhfD2:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVTvnF == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVwIsk)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVLjwZ, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVLjwZ
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVLjwZ, FFDB5L(result  , VVs4yr))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVTvnF, FFDB5L(instPath, VVpihg))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFDB5L(failed, VVpiVU))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFkyna(self, cmd)
class CCB8uV():
 VVQo5X  = "666"
 VVEQcF   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VVTBIw()
 def VVTBIw(self):
  VVd21k = CCB8uV.VVO48d()
  if VVd21k:
   VVHLqw = ("Create New", self.VVLaMt)
   self.menuInstance = FFxMT2(self.SELF, self.VVdwaL, VVd21k=VVd21k, title=self.Title, VVHLqw=VVHLqw, VVL2h3=True, VVW1CX="#22222233", VVLasp="#22222233")
  else:
   self.VVLaMt()
 def VVdwaL(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV6nv3(bName, bRef)
  else:
   CCB8uV.VVYimo(self)
 def VVLaMt(self, VVFy7pObj=None, item=None):
  FFX1El(self.SELF, BF(self.VVi8Rj), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVi8Rj(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VV6nv3(bName, "")
   else:
    FFkxeT(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CCB8uV.VVYimo(self)
 def VV6nv3(self, bName, bRef):
  FFqcaP(self.waitMsgSELF, BF(self.VV78hz, bName, bRef), title="Adding Services ...")
 def VV78hz(self, bName, bRef):
  CCB8uV.VVIyPW(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVYimo(classObj):
  del classObj
 @staticmethod
 def VVIyPW(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FF1uaI(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVmqmq + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFr3Kr(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCB8uV.VVSN7x(bRef)
   bPath = VVmqmq + bFile
  else:
   fName = CCHF2n.VVKfmR(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVmqmq + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVmqmq + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CCB8uV.VViwum(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CCB8uV.VViwum(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCodIm.VVt98d()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFqAik("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CCfm5u.VVMfHN(picon))
       break
  FFG6ML()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFX3Iv(SELF, txt, title=title)
 @staticmethod
 def VVO48d(mode=2, showTitle=True, prefix=""):
  VVd21k = []
  if mode in (0, 2): VVd21k.extend(CCB8uV.VVQT0L(0, showTitle, prefix))
  if mode in (1, 2): VVd21k.extend(CCB8uV.VVQT0L(1, showTitle, prefix))
  return VVd21k
 @staticmethod
 def VVQT0L(mode, showTitle, prefix):
  VVd21k = []
  lst = CCB8uV.VVuQgm(mode)
  if lst:
   if showTitle:
    VVd21k.append(FFnwrX("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVd21k.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVd21k.append((item[0], item[1].toString()))
  return VVd21k
 @staticmethod
 def VV8E3L():
  bLise = CCB8uV.VVuQgm(0)
  bLise.extend(CCB8uV.VVuQgm(1))
  return bLise
 @staticmethod
 def VVuQgm(mode=0):
  bList = []
  VV56ys = InfoBar.instance
  VVd3D3 = VV56ys and VV56ys.servicelist
  if VVd3D3:
   curMode = VVd3D3.mode
   CCB8uV.VVqQEW(VVd3D3, mode)
   bList.extend(VVd3D3.getBouquetList() or [])
   CCB8uV.VVqQEW(VVd3D3, curMode)
  return bList
 @staticmethod
 def VVqQEW(VVd3D3, mode):
  if not mode == VVd3D3.mode:
   if   mode == 0: VVd3D3.setModeTv()
   elif mode == 1: VVd3D3.setModeRadio()
 @staticmethod
 def VViwum(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVSN7x(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VV7XjX():
  try:
   fName = CCB8uV.VVSN7x(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVmqmq, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VV16yi():
  path = CCB8uV.VV7XjX()
  if path:
   txt = FFnMVE(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVDwLM():
  return FFWeHh(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVVU4c():
  lst = []
  for b in CCB8uV.VV8E3L():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVmqmq + CCB8uV.VVSN7x(bRef)
   if fileExists(path):
    lines = FFwiKR(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVJzpr(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVCGvA(SID="", stripRType=False):
  if SID : patt = CCB8uV.VVJzpr(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCB8uV.VV8E3L():
   for service in FFWeHh(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVOlLm():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCB8uV.VV8E3L():
   for service in FFWeHh(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVKzbL(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVnOLT(pathLst):
  refLst = CCB8uV.VVCGvA(CCB8uV.VVQo5X, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCB8uV.VVKzbL(rType, CCB8uV.VVQo5X, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCk3u6(Screen):
 VVtRZy   = 0
 VVr7yL  = 1
 VV0IRk  = 2
 VVPOrM = 3
 VVTjWG    = 20
 VVlW72  = None
 def __init__(self, session, VVl4c7="/", mode=VVtRZy, VVSbtJ="Select", height=920, VVlvFD=30, gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FF1pMw(VVilCV, 1400, height, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFrOoX(self)
  FFddoJ(self["keyRed"] , "Exit")
  FFddoJ(self["keyYellow"], "More Options")
  FFddoJ(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVSbtJ = VVSbtJ
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = "#06003333"
  CCk3u6.VVlW72 = self
  VVwFro = None
  if patternMode:
   self.mode = self.VVPOrM
   FFddoJ(self["keyRed"], "Cancel")
   if   patternMode == "srt"   : VVwFro = ("^.*\.srt"     , IGNORECASE)
   elif patternMode == "ajpSet": VVwFro = ("^.*\/ajpanel_settings_", 0   )
   elif patternMode == "poster": VVwFro = ("^.*\.(jpg|png)"   , IGNORECASE)
   else      : VVwFro = None
  if   self.jumpToFile       : VVslIc, self.VVl4c7 = True , FFUdYG(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVslIc, self.VVl4c7 = True , CCk3u6.VVURIr(self)[1] or "/"
  elif self.mode == self.VVtRZy  : VVslIc, self.VVl4c7 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VV0IRk : VVslIc, self.VVl4c7 = False, VVl4c7
  elif self.mode == self.VVPOrM : VVslIc, self.VVl4c7 = True , VVl4c7
  else           : VVslIc, self.VVl4c7 = True , VVl4c7
  self.VVl4c7 = FFjZE4(self.VVl4c7)
  self["myMenu"] = CC9q9p(  directory   = None
         , VVwFro = VVwFro
         , VVslIc   = VVslIc
         , VVqH1u = True
         , VVBPaW = True
         , VVPjIc   = self.skinParam["width"]
         , VVlvFD   = self.skinParam["bodyFontSize"]
         , VVGpoq  = self.skinParam["bodyLineH"]
         , VVg7vT  = self.skinParam["bodyColor"]
         , pngBGColorSelStr = self.cursorBG)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVw6vF    ,
   "red" : self.VVY7Rz   ,
   "green" : self.VV3FQ9,
   "yellow": self.VVMV0N  ,
   "blue" : self.VVUUqw ,
   "menu" : self.VVfJBz  ,
   "info" : self.VVka3v  ,
   "cancel": self.VVPSxC    ,
   "pageUp": self.VV4wqK   ,
   "chanUp": self.VV4wqK
  }, -1)
  FFiLOZ(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVBX9x)
 def onExit(self):
  CCk3u6.VVlW72 = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVBX9x)
  FFtTSm(self)
  FFmysb(self["myMenu"], bg=self.cursorBG)
  FFnQcA(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VV0IRk, self.VVPOrM):
   FFddoJ(self["keyGreen"], self.VVSbtJ)
   color = "#22000022"
   FFrI2P(self["myBody"], color)
   FFrI2P(self["myMenu"], color)
   color = "#22220000"
   FFrI2P(self["myTitle"], color)
   FFrI2P(self["myBar"], color)
  self.VVBX9x()
  if self.VVam2H(self.VVl4c7) > self.bigDirSize: FFqcaP(self, self.VVeCj3, title="Changing directory...")
  else              : self.VVeCj3()
 def VVeCj3(self):
  if self.jumpToFile : self.VV4rz1(self.jumpToFile)
  elif self.gotoMovie : self.VVZqwz(chDir=False)
  else    : self["myMenu"].VVo9GD(self.VVl4c7)
 def VVQ2AR(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVxmXE(self):
  self["myMenu"].refresh()
  FFi8dt()
 def VVam2H(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVw6vF(self):
  if self["myMenu"].VVTpbp() : self.VVstv4()
  else       : self.VVZzSR()
 def VV4wqK(self):
  self["myMenu"].moveToIndex(0)
  if self["myMenu"].VVo3wO():
   self.VVstv4()
 def VVstv4(self, isDirUp=False):
  if self["myMenu"].VVTpbp():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVureF(self.VVFy7p())
   if self.VVam2H(path) > self.bigDirSize : FFqcaP(self, self.VVf6w3, title="Changing directory...")
   else           : self.VVf6w3()
 def VVf6w3(self):
  self["myMenu"].descent()
  self.VVBX9x()
 def VVPSxC(self):
  if CFG.FileManagerExit.getValue() == "e": self.VVY7Rz()
  else         : self.VV4wqK()
 def VVY7Rz(self):
  if not FFLwRB(self):
   self.close("")
 def VV3FQ9(self):
  path = self.VVureF(self.VVFy7p())
  if self.mode == self.VV0IRk:
   self.close(path)
  elif self.mode == self.VVPOrM:
   if os.path.isfile(path) : self.close(path)
   else     : FFkxeT(self, "Cannot access this file", 1000)
 def VVka3v(self):
  FFqcaP(self, self.VVVmFH, title="Calculating size ...")
 def VVVmFH(self):
  path = self.VVureF(self.VVFy7p())
  param = self.VVu0BV(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFlcvI("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCk3u6.VV42fk(path)
     freeSize = CCk3u6.VViGlx(path)
     size = totSize - freeSize
     totSize  = CCk3u6.VVeQ5q(totSize)
     freeSize = CCk3u6.VVeQ5q(freeSize)
    else:
     size = FFlcvI("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCk3u6.VVeQ5q(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFHqZk(pathTxt, VV0kWR) + "\n"
   if slBroken : fileTime = self.VVkST8(path)
   else  : fileTime = self.VV731N(path)
   def VV8Y2s(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV8Y2s("Path"    , pathTxt)
   txt += VV8Y2s("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV8Y2s("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV8Y2s("Total Size"   , "%s" % totSize)
    txt += VV8Y2s("Used Size"   , "%s" % usedSize)
    txt += VV8Y2s("Free Size"   , "%s" % freeSize)
   else:
    txt += VV8Y2s("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV8Y2s("Owner"    , owner)
   txt += VV8Y2s("Group"    , group)
   txt += VV8Y2s("Perm. (User)"  , permUser)
   txt += VV8Y2s("Perm. (Group)"  , permGroup)
   txt += VV8Y2s("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV8Y2s("Perm. (Ext.)" , permExtra)
   txt += VV8Y2s("iNode"    , iNode)
   txt += VV8Y2s("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVbL9B, VVbL9B)
    txt += hLinkedFiles
   txt += self.VVKdfE(path)
  else:
   FF1uaI(self, "Cannot access information !")
  if len(txt) > 0:
   FFX3Iv(self, txt)
 def VVu0BV(self, path):
  path = path.strip()
  path = FFjMQE(path)
  result = FFlcvI("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV6Byx(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV6Byx(perm, 1, 4)
   permGroup = VV6Byx(perm, 4, 7)
   permOther = VV6Byx(perm, 7, 10)
   permExtra = VV6Byx(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFanF6("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVKdfE(self, path):
  txt  = ""
  res  = FFlcvI("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFHqZk("File Attributes:", VVpZn3), txt)
  return txt
 def VV731N(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFeWDt(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFeWDt(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFeWDt(os.path.getctime(path))
  return txt
 def VVkST8(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFlcvI("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFlcvI("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFlcvI("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVureF(self, currentSel):
  currentDir  = self["myMenu"].VVcgUy()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVTpbp():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVFy7p(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVBX9x(self):
  path = self.VVureF(self.VVFy7p())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VV19EU()
  if self.mode == self.VVtRZy and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
  if self.mode == self.VVPOrM and len(path) > 0 : self["keyInfo"].hide()
  else               : self["keyInfo"].show()
  if self.mode == self.VVPOrM:
   path = self.VVureF(self.VVFy7p())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VV19EU(self):
  if self.VV3PrW() : self["keyBlue"].show()
  else      : self["keyBlue"].hide()
 def VVfJBz(self):
  if self.mode == self.VVtRZy:
   color1  = VVyuFD
   color2  = VVWFW6
   path  = self.VVureF(self.VVFy7p())
   VVd21k = []
   VVd21k.append(("Properties", "properties"))
   if os.path.isdir(path):
    if not self.VVIFwJ(path):
     VVd21k.append(VVNCuu)
     VVd21k.append((color1 + "Archiving / Packaging", "VV2bWt_dir"))
   elif os.path.isfile(path):
    selFile = self.VVFy7p()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVd21k.append((color1 + "Archive ...", "VV2bWt_file"))
    isText = False
    txt = ""
    if   isArch            : VVd21k.extend(self.VV3jMz(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVd21k.extend(self.VVGoT2(True))
    elif selFile.endswith(".sh"):
     VVd21k.extend(self.VVh0Y8(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCk3u6.VV64Qa(path):
     VVd21k.append(VVNCuu)
     VVd21k.append((color2 + "View"     , "textView_def"))
     VVd21k.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVd21k.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVoMIF(path) == "pic":
     VVd21k.append(VVNCuu)
     VVd21k.append((color2 + "Set as PIcon for current channel" , "VVLNjx" ))
     if FFXQIu("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVd21k.append(VVNCuu)
      VVd21k.append((color2 + "Convert to MVI (1280 x 720 )" , "VVoTbRHd"   ))
      VVd21k.append((color2 + "Convert to MVI (1920 x 1080)" , "VVoTbRFhd"   ))
    elif selFile.endswith(CCk3u6.VV7EkE()):
     if selFile.endswith(".mvi"):
      if FFXQIu("showiframe"):
       VVd21k.append(VVNCuu)
       VVd21k.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVd21k.append(VVNCuu)
      VVd21k.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVd21k.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVd21k.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVd21k.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVd21k.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVd21k.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVY198" ))
    if len(txt) > 0:
     VVd21k.append(VVNCuu)
     VVd21k.append((color1 + txt, "VVZzSR"))
   VVd21k.append(VVNCuu)
   VVd21k.append(("[4] Create SymLink", "VVOJy8"))
   if not self.VVIFwJ(path):
    VVd21k.append(("[5] Rename"      , "VVt2Wo" ))
    VVd21k.append(("[6] Copy"       , "copyFileOrDir" ))
    VVd21k.append(("[7] Move"       , "moveFileOrDir" ))
    VVd21k.append(("[8] %sDELETE" % VV0kWR , "VV45XF" ))
    if fileExists(path):
     VVd21k.append(VVNCuu)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVd21k.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVd21k.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVd21k.append((chmodTxt + "777)", "chmod777"))
   c = VVRK3s
   VVd21k.append(VVNCuu)
   VVd21k.append((c + "Create New File (in current directory)"  , "createNewFile" ))
   VVd21k.append((c + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCk3u6.VVURIr(self)
   if fPath:
    VVd21k.append(VVNCuu)
    VVd21k.append((color2 + "Go to Current Movie Dir", "VVZqwz"))
   FFxMT2(self, self.VVQHPE, height=1050, title="Options", VVd21k=VVd21k, VVW1CX="#00101020", VVLasp="#00101A2A")
 def VVQHPE(self, item=None):
  if self.mode == self.VVtRZy:
   if item is not None:
    path = self.VVureF(self.VVFy7p())
    selFile = self.VVFy7p()
    if   item == "properties"    : self.VVka3v()
    elif item == "VV2bWt_dir" : self.VV2bWt(path, True)
    elif item == "VV2bWt_file" : self.VV2bWt(path, False)
    elif item == "VVSwnj"  : self.VVSwnj(path)
    elif item == "VVFQBG"  : self.VVFQBG(path)
    elif item.startswith("extract_")  : self.VVe6GI(path, selFile, item)
    elif item.startswith("script_")   : self.VV97zI(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVUTOM(path, selFile, item)
    elif item.startswith("textView_def") : FF7vxf(self, path)
    elif item.startswith("textView_enc") : self.VVobKp(path)
    elif item.startswith("text_Edit")  : FFqcaP(self, BF(CCwq37, self, path), title="Opening File ...")
    elif item.startswith("textSave_encUtf8"): self.VVAc85(path, "Save as UTF-8"   , True)
    elif item.startswith("textSave_encOthr"): self.VVAc85(path, "Save as Other Encoding", False)
    elif item.startswith("VVY198") : self.VVY198(path)
    elif item == "viewAsBootlogo"   : self.VViqd5(path, True)
    elif item == "addMovieToBouquet"  : self.VVcSoP(path, False)
    elif item == "addAllMoviesToBouquet" : self.VVcSoP(path, True)
    elif item == "playWith"     : self.VVCNAO(path)
    elif item == "VVLNjx" : self.VVLNjx(path)
    elif item == "VVoTbRHd"   : FFqcaP(self, BF(self.VVoTbR, path, False))
    elif item == "VVoTbRFhd"   : FFqcaP(self, BF(self.VVoTbR, path, True))
    elif item == "VVOJy8"   : self.VVOJy8(path, selFile)
    elif item == "VVt2Wo"   : self.VVt2Wo(path, selFile)
    elif item == "copyFileOrDir"   : self.VVX1Cv(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVX1Cv(path, selFile, True)
    elif item == "VV45XF"   : self.VV45XF(path, selFile)
    elif item == "chmod644"     : self.VV7jHR(path, selFile, "644")
    elif item == "chmod755"     : self.VV7jHR(path, selFile, "755")
    elif item == "chmod777"     : self.VV7jHR(path, selFile, "777")
    elif item == "createNewFile"   : self.VVS5JU(path, True)
    elif item == "createNewDir"    : self.VVS5JU(path, False)
    elif item == "VVZqwz"   : self.VVZqwz()
    elif item == "VVZzSR"    : self.VVZzSR()
 def VVZzSR(self):
  if self.mode == self.VVPOrM and not self.patternMode == "poster":
   return
  selFile = self.VVFy7p()
  path  = self.VVureF(selFile)
  if os.path.isfile(path):
   VV87m4  = []
   category = self["myMenu"].VVoMIF(path)
   if   category == "pic"      : self.VVdLXV(path)
   elif category == "txt"      : FF7vxf(self, path)
   elif category in ("tar", "zip", "rar")  : self.VVkBOq(path, selFile)
   elif category == "scr"      : self.VVyzME(path, selFile)
   elif category == "m3u"      : self.VVtXKu(path, selFile)
   elif category in ("ipk", "deb")    : self.VVDhZ7(path, selFile)
   elif category in ("mov", "mus")    : self.VViqd5(path)
   elif not CCk3u6.VV64Qa(path) : FF7vxf(self, path)
 def VVdLXV(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVoMIF(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCpbjY.VVBCwU(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVBqsW)
 def VVBqsW(self, path):
  self.VV4rz1(path)
 def VViqd5(self, path, asLogo=False):
  if asLogo : CCTQSn.VVtZ8s(self, path)
  else  : FFqcaP(self, BF(self.VVVJhr, self, path), title="Playing Media ...")
 def VVUUqw(self):
  if self["keyBlue"].getVisible():
   VVHQsP = self.VV3PrW()
   if VVHQsP:
    path = self.VVureF(self.VVFy7p())
    enableGreenBtn = False if path in self.VV3PrW() else True
    newList = []
    for line in VVHQsP:
     newList.append((line, line))
    VVZms0  = ("Delete"    , self.VV1luW    )
    VVQIvk  = ("Add Current Dir"   , BF(self.VVjDWA, path) ) if enableGreenBtn else None
    VVHLqw = ("Move Up"     , self.VVxpsN    )
    VVldmG  = ("Move Down"   , self.VVgu82    )
    self.bookmarkMenu = FFxMT2(self, self.VVo51X, width=1200, title="Bookmarks", VVd21k=newList, minRows=10 ,VVZms0=VVZms0, VVQIvk=VVQIvk, VVHLqw=VVHLqw, VVldmG=VVldmG, VVW1CX="#00000022", VVLasp="#00000022")
 def VV1luW(self, menuInstance=None, path=None):
  VVHQsP = self.VV3PrW()
  if VVHQsP:
   while path in VVHQsP:
    VVHQsP.remove(path)
   self.VVNFAr(VVHQsP)
  if self.bookmarkMenu:
   self.bookmarkMenu.VV6wRf(VVHQsP)
   self.bookmarkMenu.VVPXAG(("Add Current Dir", BF(self.VVjDWA, path)))
  else:
   FFkxeT(self, "Removed", 800)
  self.VV19EU()
 def VVjDWA(self, path, menuInstance=None, item=None):
  VVHQsP = self.VV3PrW()
  if len(VVHQsP) >= self.VVTjWG:
   FF1uaI(SELF, "Max bookmarks reached (max=%d)." % self.VVTjWG)
  elif not path in VVHQsP:
   newList = [path] + VVHQsP
   self.VVNFAr(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VV6wRf(newList)
    self.bookmarkMenu.VVPXAG()
   else:
    FFkxeT(self, "Added", 800)
  self.VV19EU()
 def VVxpsN(self, VVFy7pObj, path):
  if self.bookmarkMenu:
   VVHQsP = self.bookmarkMenu.VVKQFA(True)
   if VVHQsP:
    self.VVNFAr(VVHQsP)
 def VVgu82(self, VVFy7pObj, path):
  if self.bookmarkMenu:
   VVHQsP = self.bookmarkMenu.VVKQFA(False)
   if VVHQsP:
    self.VVNFAr(VVHQsP)
 def VVo51X(self, folder=None):
  if folder:
   folder = FFjZE4(folder)
   self["myMenu"].VVo9GD(folder)
   self["myMenu"].moveToIndex(0)
  self.VVBX9x()
 def VV3PrW(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVPc2o(self):
  return True if VV3PrW() else False
 def VVNFAr(self, VVHQsP):
  line = ",".join(VVHQsP)
  FFWvPK(CFG.browserBookmarks, line)
 def VV4rz1(self, path):
  if fileExists(path):
   fDir  = FFjZE4(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVo9GD(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFkxeT(self, "Not found", 1000)
 def VVZqwz(self, chDir=True):
  fPath, fDir, fName = CCk3u6.VVURIr(self)
  self.VV4rz1(fPath)
 def VVMV0N(self):
  path = self.VVureF(self.VVFy7p())
  isAdd = False if path in self.VV3PrW() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  VVd21k = []
  VVd21k.append(   ("Find Files ..."      , "find" ))
  VVd21k.append(   ("Sort ..."        , "sort" ))
  VVd21k.append(VVNCuu)
  if isAdd: VVd21k.append( ("Add %s Dir to Bookmarks" % dirTxt  , "addBM" ))
  else : VVd21k.append( ("Remove %s Dir from Bookmarks" % dirTxt, "remBM" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(   ('Set %s Dir as "Startup Dir"' % dirTxt , "start" ))
  FFxMT2(self, BF(self.VVXxkX, path), width=750, title="More Options", VVd21k=VVd21k, VVW1CX="#00221111", VVLasp="#00221111")
 def VVXxkX(self, path, item):
  if item:
   if   item == "find" : self.VV0EsL(path)
   elif item == "sort" : self.VVtG1j()
   elif item == "addBM": self.VVjDWA(path)
   elif item == "remBM": self.VV1luW(None, path)
   elif item == "start": self.VVP5ze(path)
 def VV0EsL(self, path):
  VVd21k = []
  VVd21k.append(("Find in Current Directory"    , "findCur"  ))
  VVd21k.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVd21k.append(("Find in all Storage Systems"    , "findAll"  ))
  FFxMT2(self, BF(self.VVtu8F, path), width=700, title="Find File/Pattern", VVd21k=VVd21k, VVL2h3=True, VVP2Aq=True, VVW1CX="#00221111", VVLasp="#00221111")
 def VVtu8F(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVla3B(0, path, title)
   elif item == "findCurR" : self.VVla3B(1, path, title)
   elif item == "findAll" : self.VVla3B(2, path, title)
 def VVla3B(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFX1El(self, BF(self.VVV6rP, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVV6rP(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFWvPK(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFkxeT(self, "No entery", 1500)
   elif badLst  : FFkxeT(self, "Too many file !", 1500)
   else   : FFqcaP(self, BF(self.VVK369, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVK369(self, mode, path, title, filePatt):
  FFkxeT(self)
  lst = FFjUOl(FF1vDA("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   if len(lst) == 1 and lst[0] == VVhfZS:
    FF1uaI(self, VVhfZS)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVAe4b = (""     , self.VV4RRN , [])
    VVZyxX = ("Go to File Location", self.VV17PS  , [])
    FF8dRU(self, None, title="%s : %s" % (title, filePatt), header=header, VVHQsP=lst, VVje1O=widths, VVlvFD=26, VVAe4b=VVAe4b, VVZyxX=VVZyxX)
  else:
   FFkxeT(self, "Not found !", 2000)
 def VV17PS(self, VVc7Yu, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVc7Yu.cancel()
   self.VV4rz1(path)
  else:
   FFkxeT(VVc7Yu, "Path not found !", 1000)
 def VV4RRN(self, VVc7Yu, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFHqZk("File:"  , VVWFW6), colList[0])
  txt += "%s\n%s"  % (FFHqZk("Directory:", VVWFW6), FFjZE4(colList[1]))
  FFX3Iv(VVc7Yu, txt, title=title)
 def VVtG1j(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVLiZL()
  VVd21k = []
  VVd21k.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVd21k.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVd21k.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVd21k.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVldmG = ("Mix", BF(self.VVzFO4, True))
  FFxMT2(self, BF(self.VVEltF, False), barText=txt, width=650, title="Sort Options", VVd21k=VVd21k, VVldmG=VVldmG, VVP2Aq=True, VVW1CX="#00221111", VVLasp="#00221111")
 def VVzFO4(self, isMix, menuInstance, item):
  self.VVEltF(True, item)
 def VVEltF(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVLiZL()
   title = "Sorting ... "
   if   item == "nameAlp": FFqcaP(self, BF(self["myMenu"].VVHiEt, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFqcaP(self, BF(self["myMenu"].VVHiEt, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFqcaP(self, BF(self["myMenu"].VVHiEt, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFqcaP(self, BF(self["myMenu"].VVHiEt, typeMode , isMix, False), title=title)
 def VVP5ze(self, path):
  if not os.path.isdir(path):
   path = FFUdYG(path, True)
  FFWvPK(CFG.browserStartPath, path)
  FFkxeT(self, "Done", 500)
 def VVdO7q(self, selFile, VVJpRC, command):
  FFWV4g(self, BF(FFkyna, self, command, VVHcKu=self.VVxmXE), "%s\n\n%s" % (VVJpRC, selFile))
 def VV3jMz(self, path, calledFromMenu):
  destPath = self.VVfvPq(path)
  lastPart = FF4Cf3(destPath)
  VVd21k = []
  if calledFromMenu:
   VVd21k.append(VVNCuu)
   color = VVWFW6
  else:
   color = ""
  VVd21k.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVd21k.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVd21k.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVd21k.append(VVNCuu)
    VVd21k.append((color + "Convert .zip to .tar.gz"       , "VVSwnj" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVd21k.append(VVNCuu)
    VVd21k.append((color + "Convert .tar.gz to .zip"       , "VVFQBG" ))
  return VVd21k
 def VVkBOq(self, path, selFile):
  FFxMT2(self, BF(self.VVe6GI, path, selFile), title="Compressed File Options", VVd21k=self.VV3jMz(path, False))
 def VVe6GI(self, path, selFile, item=None):
  if item is not None:
   parent  = FFUdYG(path, False)
   destPath = self.VVfvPq(path)
   lastPart = FF4Cf3(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVbL9B
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFRWxt("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFRWxt("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVbL9B, VVbL9B)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FF3Yso(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVSwnj" : self.VVSwnj(path)
    else       : self.VVbfAO(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVFQBG" and path.endswith(".tar.gz"):
    self.VVFQBG(path)
   elif path.endswith(".rar"):
    self.VVj3VC(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFqAik("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVdO7q(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVdO7q(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFUdYG(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVdO7q(selFile, "Extract Here ?"      , cmd)
 def VVfvPq(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVbfAO(self, item, path, parent, destPath, VVJpRC):
  FFWV4g(self, BF(self.VVTp9M, item, path, parent, destPath), VVJpRC)
 def VVTp9M(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVbL9B
  cmd  = FFRWxt("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFDB5L(destPath, VVs4yr))
  cmd +=   sep
  cmd += "fi;"
  FFlE1p(self, cmd, VVHcKu=self.VVxmXE)
 def VVj3VC(self, item, path, parent, destPath, VVJpRC):
  FFWV4g(self, BF(self.VVW9ZH, item, path, parent, destPath), VVJpRC)
 def VVW9ZH(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFjZE4(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVbL9B
  cmd  = FFRWxt("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFDB5L(destPath, VVs4yr))
  cmd +=   sep
  cmd += "fi;"
  FFlE1p(self, cmd, VVHcKu=self.VVxmXE)
 def VVh0Y8(self, addSep=False):
  VVd21k = []
  if addSep:
   VVd21k.append(VVNCuu)
  VVd21k.append((VVWFW6 + "View Script File"  , "script_View"  ))
  VVd21k.append((VVWFW6 + "Execute Script File" , "script_Execute" ))
  VVd21k.append((VVWFW6 + "Edit"     , "script_Edit" ))
  return VVd21k
 def VVyzME(self, path, selFile):
  FFxMT2(self, BF(self.VV97zI, path, selFile), title="Script File Options", VVd21k=self.VVh0Y8())
 def VV97zI(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF7vxf(self, path)
   elif item == "script_Execute" : self.VVdO7q(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCwq37(self, path)
 def VVGoT2(self, addSep=False):
  VVd21k = []
  if addSep:
   VVd21k.append(VVNCuu)
  VVd21k.append((VVWFW6 + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVd21k.append((VVWFW6 + "Edit"      , "m3u_Edit" ))
  VVd21k.append((VVWFW6 + "View"      , "m3u_View" ))
  return VVd21k
 def VVtXKu(self, path, selFile):
  FFxMT2(self, BF(self.VVUTOM, path, selFile), title="M3U/M3U8 File Options", VVd21k=self.VVGoT2())
 def VVUTOM(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFqcaP(self, BF(self.session.open, CCHF2n, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCwq37(self, path)
   elif item == "m3u_View"  : FF7vxf(self, path)
 def VVobKp(self, path):
  if fileExists(path) : FFqcaP(self, BF(CCtiVE.VVVTUQ, self, path, BF(self.VV1ig8, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFr3Kr(self, path)
 def VV1ig8(self, path, item=None):
  if item:
   FF7vxf(self, path, encLst=item)
 def VVAc85(self, path, title, asUtf8):
  if fileExists(path) : FFqcaP(self, BF(CCtiVE.VVVTUQ, self, path, BF(self.VV3e7N, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFr3Kr(self, path)
 def VV3e7N(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVigGM(path, title, fromEnc, "UTF-8")
   else  : CCtiVE.VVVTUQ(self, path,  BF(self.VVigGM, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVigGM(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFHqZk("Successful\n\n", VVs4yr)
      txt += FFHqZk("From Encoding (%s):\n" % fromEnc, VVsZ3Y)
      txt += "%s\n\n" % path
      txt += FFHqZk("To Encoding (%s):\n" % toEnc, VVsZ3Y)
      txt += "%s\n\n" % outFile
      FFX3Iv(self, txt, title=title)
    except:
     FF1uaI(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFkxeT(self, "Cannot open file", 2000)
  self.VVxmXE()
 def VVY198(self, path):
  title = "File Line-Break Conversion"
  FFWV4g(self, BF(self.VVEc4G, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVEc4G(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFHqZk("File converted:", VVs4yr), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFfF2j(self, txt, title=title)
  else:
   FFr3Kr(self, path, title=title)
 def VV7jHR(self, path, selFile, newChmod):
  FFWV4g(self, BF(self.VVORYC, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVORYC(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV6BHw)
  result = FFlcvI(cmd)
  if result == "Successful" : FFfF2j(self, result)
  else      : FF1uaI(self, result)
 def VVOJy8(self, path, selFile):
  parent = FFUdYG(path, False)
  self.session.openWithCallback(self.VVK6oI, BF(CCk3u6, mode=CCk3u6.VV0IRk, VVl4c7=parent, VVSbtJ="Create Symlink here"))
 def VVK6oI(self, newPath):
  if len(newPath) > 0:
   target = self.VVureF(self.VVFy7p())
   target = FFjMQE(target)
   linkName = FF4Cf3(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFjZE4(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF1uaI(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFWV4g(self, BF(self.VVBtpp, target, link), "Create Soft Link ?\n\n%s" % txt, VVwjVK=True)
 def VVBtpp(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV6BHw)
  result = FFlcvI(cmd)
  if result == "Successful" : FFfF2j(self, result)
  else      : FF1uaI(self, result)
 def VVt2Wo(self, path, selFile):
  lastPart = FF4Cf3(path)
  FFX1El(self, BF(self.VVwXT1, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVwXT1(self, path, selFile, VVouBA):
  if VVouBA:
   parent = FFUdYG(path, True)
   if os.path.isdir(path):
    path = FFjMQE(path)
   newName = parent + VVouBA
   cmd = "mv '%s' '%s' %s" % (path, newName, VV6BHw)
   if VVouBA:
    if selFile != VVouBA:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFWV4g(self, BF(self.VVBtky, cmd), message, title="Rename file?")
    else:
     FF1uaI(self, "Cannot use same name!", title="Rename")
 def VVBtky(self, cmd):
  result = FFlcvI(cmd)
  if "Fail" in result:
   FF1uaI(self, result)
  self.VVxmXE()
 def VVX1Cv(self, path, selFile, isMove):
  if isMove : VVSbtJ = "Move to here"
  else  : VVSbtJ = "Paste here"
  parent = FFUdYG(path, False)
  self.session.openWithCallback(BF(self.VVco2R, isMove, path, selFile)
         , BF(CCk3u6, mode=CCk3u6.VV0IRk, VVl4c7=parent, VVSbtJ=VVSbtJ))
 def VVco2R(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = FF4Cf3(path)
   if os.path.isdir(path):
    path = FFjMQE(path)
   newPath = FFjZE4(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FF1uaI(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFWV4g(self, BF(FFVBAP, self, cmd, VVHcKu=self.VVxmXE), txt, VVwjVK=True)
   else:
    FF1uaI(self, "Cannot %s to same directory !" % action.lower())
 def VV45XF(self, path, fileName):
  path = FFjMQE(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFWV4g(self, BF(self.VVqVI8, path), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVqVI8(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVxmXE()
 def VVIFwJ(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVttXz and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVS5JU(self, path, isFile):
  dirName = FFjZE4(os.path.dirname(path))
  if isFile : objName, VVouBA = "File"  , self.edited_newFile
  else  : objName, VVouBA = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFX1El(self, BF(self.VVpu4r, dirName, isFile, title), title=title, defaultText=VVouBA, message="Enter %s Name:" % objName)
 def VVpu4r(self, dirName, isFile, title, VVouBA):
  if VVouBA:
   if isFile : self.edited_newFile = VVouBA
   else  : self.edited_newDir  = VVouBA
   path = dirName + VVouBA
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV6BHw)
    else  : cmd = "mkdir '%s' %s" % (path, VV6BHw)
    result = FFlcvI(cmd)
    if "Fail" in result:
     FF1uaI(self, result)
    self.VVxmXE()
   else:
    FF1uaI(self, "Name already exists !\n\n%s" % path, title)
 def VVDhZ7(self, path, selFile):
  c1, c2, c3 = VVusL5, VVWFW6, VVyuFD
  VVd21k = []
  VVd21k.append((c1 + "List Package Files"         , "VVGkuK"     ))
  VVd21k.append((c1 + "Package Information"         , "VVenEx"     ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c2 + "Install Package"          , "VV9V5y_CheckVersion" ))
  VVd21k.append((c2 + "Install Package (force reinstall)"     , "VV9V5y_ForceReinstall" ))
  VVd21k.append((c2 + "Install Package (force overwrite)"     , "VV9V5y_ForceOverwrite" ))
  VVd21k.append((c2 + "Install Package (force downgrade)"     , "VV9V5y_ForceDowngrade" ))
  VVd21k.append((c2 + "Install Package (ignore failed dependencies)"  , "VV9V5y_IgnoreDepends" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c3 + "Remove Related Package"        , "VVZgN8_ExistingPackage" ))
  VVd21k.append((c3 + "Remove Related Package (force remove)"    , "VVZgN8_ForceRemove"  ))
  VVd21k.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVZgN8_IgnoreDepends" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Extract Files"           , "VVIWbG"     ))
  VVd21k.append(("Unbuild Package"           , "VVulef"     ))
  FFxMT2(self, BF(self.VVEDio, path, selFile), VVd21k=VVd21k)
 def VVEDio(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVGkuK"      : self.VVGkuK(path, selFile)
   elif item == "VVenEx"      : self.VVenEx(path)
   elif item == "VV9V5y_CheckVersion"  : self.VV9V5y(path, selFile, VVQGHq     )
   elif item == "VV9V5y_ForceReinstall" : self.VV9V5y(path, selFile, VVqGH2 )
   elif item == "VV9V5y_ForceOverwrite" : self.VV9V5y(path, selFile, VVXZJT )
   elif item == "VV9V5y_ForceDowngrade" : self.VV9V5y(path, selFile, VVAsra )
   elif item == "VV9V5y_IgnoreDepends" : self.VV9V5y(path, selFile, VVGYhV )
   elif item == "VVZgN8_ExistingPackage" : self.VVZgN8(path, selFile, VV9G95     )
   elif item == "VVZgN8_ForceRemove"  : self.VVZgN8(path, selFile, VVoPbw  )
   elif item == "VVZgN8_IgnoreDepends"  : self.VVZgN8(path, selFile, VVCn0U )
   elif item == "VVIWbG"     : self.VVIWbG(path, selFile)
   elif item == "VVulef"     : self.VVulef(path, selFile)
   else           : self.close()
 def VVGkuK(self, path, selFile):
  if FFXQIu("ar") : cmd = "allOK='1';"
  else    : cmd  = FFJLoq()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVbL9B, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVbL9B, VVbL9B)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFhq9z(self, cmd, VVHcKu=self.VVxmXE)
 def VVIWbG(self, path, selFile):
  lastPart = FF4Cf3(path)
  dest  = FFUdYG(path, True) + selFile[:-4]
  cmd  =  FFJLoq()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFqAik("mkdir '%s'" % dest) + ";"
  cmd +=    FFqAik("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFDB5L(dest, VVs4yr))
  cmd += "fi;"
  FFkyna(self, cmd, VVHcKu=self.VVxmXE)
 def VVulef(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVssNt = os.path.splitext(path)[0]
  else        : VVssNt = path + "_"
  if path.endswith(".deb")   : VVwIsk = "DEBIAN"
  else        : VVwIsk = "CONTROL"
  cmd  = FFJLoq()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVssNt, FFoWNF())
  cmd += "  mkdir '%s';"    % VVssNt
  cmd += "  CONTPATH='%s/%s';"  % (VVssNt, VVwIsk)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVssNt
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVssNt, VVssNt)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVssNt
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVssNt, VVssNt)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVssNt
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVssNt
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVssNt, FFDB5L(VVssNt, VVs4yr))
  cmd += "fi;"
  FFkyna(self, cmd, VVHcKu=self.VVxmXE)
 def VVenEx(self, path):
  listCmd  = FF1WnD(VVvIYW, "")
  infoCmd  = FF5LxN(VV1fea , "")
  filesCmd = FF5LxN(VVcPSx, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF95QJ(VVsZ3Y)
   notInst = "Package not installed."
   cmd  = FFofzq("File Info", VVsZ3Y)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFofzq("System Info", VVsZ3Y)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFDB5L(notInst, VV0kWR))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFofzq("Related Files", VVsZ3Y)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF3Yso(self, cmd)
  else:
   FF3PaD(self)
 def VV9V5y(self, path, selFile, cmdOpt):
  cmd = FF5LxN(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFWV4g(self, BF(FFkyna, self, cmd, VVHcKu=FFi8dt), "Install Package ?\n\n%s" % selFile)
  else:
   FF3PaD(self)
 def VVZgN8(self, path, selFile, cmdOpt):
  listCmd  = FF1WnD(VVvIYW, "")
  infoCmd  = FF5LxN(VV1fea, "")
  instRemCmd = FF5LxN(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFDB5L(errTxt, VV0kWR))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFDB5L(cannotTxt, VV0kWR))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFDB5L(tryTxt, VV0kWR))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFWV4g(self, BF(FFkyna, self, cmd, VVHcKu=FFi8dt), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF3PaD(self)
 def VVtrd5(self, path):
  hostName = FFlcvI("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VV2bWt(self, path, isDir):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVd21k = []
  VVd21k.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVd21k.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVd21k.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVd21k.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVd21k.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVd21k.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVd21k.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVd21k.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVd21k.append(("%s.zip"  % Path   , "archPath_zip"  ))
  if isDir:
   VVd21k.append(VVNCuu)
   VVd21k.append(('Convert to ".ipk" Package' , "convertDirToIpk" ))
   VVd21k.append(('Convert to ".deb" Package' , "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFxMT2(self, BF(self.VV8oP2, path, isDir, title), VVd21k=VVd21k, title=title, VVW1CX=c1, VVLasp=c2)
 def VV8oP2(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV30aF(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz"   : self.VV30aF(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV30aF(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV30aF(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"    : self.VV30aF(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"    : self.VV30aF(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz"   : self.VV30aF(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV30aF(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV30aF(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"    : self.VV30aF(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk"   : self.VVp4MF(path, False)
   elif item == "convertDirToDeb"   : self.VVp4MF(path, True)
   else         : self.close()
 def VVp4MF(self, path, VVjafw):
  self.session.openWithCallback(self.VVxmXE, BF(CCuvFH, path=path, VVjafw=VVjafw))
 def VV30aF(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFUdYG(path, True)
  lastPart = FF4Cf3(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFRWxt("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFRWxt("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFRWxt("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVbL9B
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFqAik("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFDB5L(failed, VVHeSZ))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFDB5L(srcTxt, VVpihg))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFDB5L("Output", VVs4yr))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFDB5L(failed, VVpiVU))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFhq9z(self, cmd, VVHcKu=self.VVxmXE, title=title)
 def VVcSoP(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCk3u6.VVbdIh(FFUdYG(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCB8uV(self, self, title, BF(self.VVlIEf, pathLst))
 def VVlIEf(self, pathLst):
  return CCB8uV.VVnOLT(pathLst)
 def VVSwnj(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VV1qh7, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFWV4g(self, BF(FFqcaP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFqcaP(self, fnc, title=txt)
  else:
   FF1uaI(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VV1qh7(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, 'w:gz') as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFX3Iv(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVxmXE()
  else:
   FFC2Q5(tarPath)
   FF1uaI(self, "Error while converting.", title=title)
 def VVFQBG(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVo1rx, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFWV4g(self, BF(FFqcaP, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFqcaP(self, fnc, title=txt)
  else:
   FF1uaI(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVo1rx(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFX3Iv(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVxmXE()
  else:
   FFC2Q5(zipPath)
   FF1uaI(self, "Error while converting.", title=title)
 def VVoTbR(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFjZE4(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFqAik("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFqAik("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFqAik("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VVxmXE()
   FFfF2j(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FF1uaI(self, "Cannot convert this file !", title=title)
 def VVLNjx(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCodIm.VVt98d()
  if pathExists(pPath):
   if CCxpGD.VVA6X2(self, title, False, cbFnc=BF(self.VVLNjx, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVd21k = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVd21k.append(("%d x %d" % (item), item))
    infoBtnFnc = self.VVQfWQ
    VVldmG = ("Stretch", BF(self.VVSzhc, title, path, picon))
    menuInstance = FFxMT2(self, BF(self.VVS9Fu, title, path, picon, False), VVd21k=VVd21k, width=700, title='PIcon Max. Size', infoBtnFnc=infoBtnFnc, VVldmG=VVldmG, barText="OK = Fit within size")
    menuInstance.VVDB8c(3)
  else:
   FF1uaI(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVSzhc(self, title, path, picon, VVFy7pObj, item):
  self.VVS9Fu(title, path, picon, True, item)
  VVFy7pObj.cancel()
 def VVS9Fu(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFdGDb(self, fncMode=CCfm5u.VVXXAh)
   except Exception as e:
    FF1uaI(self, "Image Processing error:\n\n%s" % e)
 def VVQfWQ(self, menuInstance, txt, ref, ndx):
  FFkKs9(self, "_help_resize", "Picture File Resizing")
 @staticmethod
 def VVR8LJ():
  lst = (("1"  , "DVB Stream"  , True)
   , ("4097", "servicemp3"  , True)
   , ("5001", "GST Player"  , os.path.exists("/usr/bin/gstplayer"))
   , ("5002", "Ext-3 EPlayer" , os.path.exists("/usr/bin/exteplayer3"))
   , ("8193", "eServiceUri" , os.path.exists("/usr/bin/apt-get")))
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVd21k = []
  for ndx, (rt, txt, ok) in enumerate(lst):
   txt = "%s\t... %s" % ((VVusL5 if rt == defRt else "") + txt, rt)
   if ok: VVd21k.append((txt, rt))
   else : VVd21k.append((txt, ))
   if ndx < 4 and ndx % 2: VVd21k.append(VVNCuu)
  return VVd21k
 def VVCNAO(self, path):
  FFxMT2(self, BF(self.VVF9fn, path), VVd21k=CCk3u6.VVR8LJ(), width=650, title="Select Player", VVW1CX="#11220000", VVLasp="#11220000")
 def VVF9fn(self, path, rType=None):
  if rType:
   FFqcaP(self, BF(self.VVVJhr, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVVJhr(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCqzRz.VVfphk(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVURIr(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFjZE4(fDir), fName
  return "", "", ""
 @staticmethod
 def VV42fk(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VViGlx(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVeQ5q(size, mode=0):
  txt = CCk3u6.VViX4a(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VViX4a(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VV64Qa(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVsTOj(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FF1uaI(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV7EkE():
  tDict = CC9q9p.VVfYFN()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVbdIh(path):
  lst = []
  for ext in CCk3u6.VV7EkE():
   lst.extend(FF6jDI(path, "*.%s" % ext))
  return sorted(lst, key=FFL1W9(FFjKul))
 @staticmethod
 def VV5fkt(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVxP1G(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
class CC9q9p(MenuList):
 VVO33A  = 0
 VVVuro  = 1
 VVaIKk  = 2
 VVFQBp  = 3
 VVTNCu  = 4
 VVBNv3  = 5
 VVg0a7  = 6
 VVodIj  = 7
 VV4mQB  = "<List of Storage Devices>"
 VVNqcr = "<Parent Directory>"
 def __init__(self, VVBPaW=False, directory="/", VVQhVW=True, VVslIc=True, VVqH1u=True, VVwFro=None, VVobUN=False, VVg4GY=False, VVwngx=False, isTop=False, VVuC03=None, VVPjIc=1000, VVlvFD=30, VVGpoq=30, VVg7vT="#00000000", pngBGColorSelStr="#06003333"):
  MenuList.__init__(self, list, VVBPaW, eListboxPythonMultiContent)
  self.VVQhVW  = VVQhVW
  self.VVslIc    = VVslIc
  self.VVqH1u  = VVqH1u
  self.VVwFro  = VVwFro
  self.VVobUN   = VVobUN
  self.VVg4GY   = VVg4GY or []
  self.VVwngx   = VVwngx or []
  self.isTop     = isTop
  self.additional_extensions = VVuC03
  self.VVPjIc    = VVPjIc
  self.VVlvFD    = VVlvFD
  self.VVGpoq    = VVGpoq
  self.pngBGColor    = FFj7n6(VVg7vT)
  self.pngBGColorSel   = FFj7n6(pngBGColorSelStr)
  self.EXTENSIONS    = CC9q9p.VVfYFN()
  self.VVfpFz   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.l.setFont(0, gFont(VVlQv4, self.VVlvFD))
  self.l.setItemHeight(self.VVGpoq)
  self.png_mem   = self.VVXaFq("mem")
  self.png_usb   = self.VVXaFq("usb")
  self.png_fil   = self.VVXaFq("fil")
  self.png_dir   = self.VVXaFq("dir")
  self.png_dirup   = self.VVXaFq("dirup")
  self.png_srv   = self.VVXaFq("srv")
  self.png_slwfil   = self.VVXaFq("slwfil")
  self.png_slbfil   = self.VVXaFq("slbfil")
  self.png_slwdir   = self.VVXaFq("slwdir")
  self.VVH40c()
  self.VVo9GD(directory)
 def VVXaFq(self, category):
  return LoadPixmap("%s%s.png" % (VVrjWk, category), getDesktop(0))
 @staticmethod
 def VVfYFN():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVlgJk(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFjMQE(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFHqZk(" -> " , VVsZ3Y) + FFHqZk(os.readlink(path), VVs4yr)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVGpoq + 10, 0, self.VVPjIc, self.VVGpoq, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV3xZT: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVGpoq-4, self.VVGpoq-4, png, self.pngBGColor, self.pngBGColorSel, VV3xZT))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVGpoq-4, self.VVGpoq-4, png, self.pngBGColor, self.pngBGColorSel))
  return tableRow
 def VVoMIF(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVH40c(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVGFd1(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV4TXx(self, file):
  if os.path.realpath(file) == file:
   return self.VVGFd1(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVGFd1(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVGFd1(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVj6xu(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVfpFz.info(l[0][0]).getEvent(l[0][0])
 def VV3MgL(self):
  return self.list
 def VVZ2GU(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVo9GD(self, directory, select = None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVqH1u:
    self.current_mountpoint = self.VV4TXx(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVqH1u:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVwngx and not self.VVZ2GU(path, self.VVg4GY):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVlgJk(name=p.description, absolute=path, isDir=True, png=png))
    path = "/"
    if path not in self.VVwngx and not self.VVZ2GU(path, self.VVg4GY):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVlgJk(name="INTERNAL FLASH", absolute="/", isDir=True, png=self.png_mem))
  elif self.VVobUN:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVfpFz = eServiceCenter.getInstance()
   list = VVfpFz.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVQhVW and not self.isTop:
   if directory == self.current_mountpoint and self.VVqH1u:
    self.list.append(self.VVlgJk(name=self.VV4mQB, absolute=None, isDir=True, png=self.png_dirup))
   elif (directory != "/") and not (self.VVwngx and self.VVGFd1(directory) in self.VVwngx):
    self.list.append(self.VVlgJk(name=self.VVNqcr, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, png=self.png_dirup))
  if self.VVQhVW:
   for x in directories:
    if not (self.VVwngx and self.VVGFd1(x) in self.VVwngx) and not self.VVZ2GU(x, self.VVg4GY):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVlgJk(name=name, absolute=x, isDir=True, png=png))
  if self.VVslIc:
   for x in files:
    if self.VVobUN:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFHqZk(" -> " , VVsZ3Y) + FFHqZk(target, VVs4yr)
       else:
        png = self.png_slbfil
        name += FFHqZk(" -> " , VVsZ3Y) + FFHqZk(target, VVpiVU)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVoMIF(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVrjWk, category))
    if (self.VVwFro is None) or iCompile(self.VVwFro[0], flags=self.VVwFro[1]).search(path):
     self.list.append(self.VVlgJk(name=name, absolute=x , isDir=False, png=png))
  if self.VVqH1u and len(self.list) == 0:
   self.list.append(self.VVlgJk(name=FFHqZk("No USB connected", VVekE1), absolute=None, isDir=False, png=self.png_usb))
  self.l.setList(self.list)
  self.VVHiEt()
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVcgUy(self):
  return self.current_directory
 def VVTpbp(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVo3wO(self):
  return self.VV0a5F() and self.VVcgUy()
 def VV0a5F(self):
  return self.list[0][1][7] in (self.VV4mQB, self.VVNqcr)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVo9GD(self.getSelection()[0], select = self.current_directory)
 def VVKjPN(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV40AW(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VViSY7)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VViSY7)
 def refresh(self):
  self.VVo9GD(self.current_directory, self.VVKjPN())
 def VViSY7(self, action, device):
  self.VVH40c()
  if self.current_directory is None:
   self.refresh()
 def VVLiZL(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVO33A : nameAlpMode, nameAlpTxt = self.VVVuro, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVO33A, sAZ
  if mode == self.VVaIKk : nameNumMode, nameNumTxt = self.VVFQBp, s90
  else       : nameNumMode, nameNumTxt = self.VVaIKk, s09
  if mode == self.VVTNCu : dateMode, dateTxt = self.VVBNv3, sON
  else       : dateMode, dateTxt = self.VVTNCu, sNO
  if mode == self.VVg0a7 : typeMode, typeTxt = self.VVodIj, sZA
  else       : typeMode, typeTxt = self.VVg0a7, sAZ
  if   mode in (self.VVO33A, self.VVVuro): txt = "Name (%s)" % (sAZ if mode == self.VVO33A else sZA)
  elif mode in (self.VVaIKk, self.VVFQBp): txt = "Name (%s)" % (s09 if mode == self.VVO33A else s90)
  elif mode in (self.VVTNCu, self.VVBNv3): txt = "Date (%s)" % (sNO if mode == self.VVTNCu else sON)
  elif mode in (self.VVg0a7, self.VVodIj): txt = "Type (%s)" % (sAZ if mode == self.VVg0a7 else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVHiEt(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFWvPK(CFG.browserSortMode, mode)
   FFWvPK(CFG.browserSortMix, isMix)
  if self.list:
   if self.VV0a5F() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVO33A, self.VVVuro):
    rev = True if mode == self.VVVuro else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVaIKk, self.VVFQBp):
    rev = True if mode == self.VVFQBp else False
    self.list = sorted(self.list[item0:], key=FFL1W9(BF(self.VV6zFH, isMix, rev)), reverse=rev)
   elif mode in (self.VVTNCu, self.VVBNv3):
    rev = True if mode == self.VVBNv3 else False
    self.list = sorted(self.list[item0:], key=FFL1W9(BF(self.VV3007, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVodIj else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VV6zFH(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFjKul(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFLMO6(dir2, dir1) or FFjKul(name1, name2)
 def VV3007(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFLMO6(stat2.st_ctime, stat1.st_ctime)
    else : return FFLMO6(dir2, dir1) or FFLMO6(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCytJU(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FF1pMw(VVdUpq, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVHQsP   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVc7LH(defFG, "#00FFFFFF")
  self.defBG   = self.VVc7LH(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFrOoX(self, self.Title)
  self["keyRed"].show()
  FFddoJ(self["keyGreen"] , "< > Transp.")
  FFddoJ(self["keyYellow"], "Foreground")
  FFddoJ(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVtBNM     ,
   "green"   : self.VVtBNM     ,
   "yellow"  : BF(self.VV5eUs, False)  ,
   "blue"   : BF(self.VV5eUs, True)  ,
   "up"   : self.VV66ms       ,
   "down"   : self.VVs4n9      ,
   "left"   : self.VV0XiC      ,
   "right"   : self.VV2FzN      ,
   "last"   : BF(self.VVWvlE, -5) ,
   "next"   : BF(self.VVWvlE, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVOOZO)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFrI2P(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFrI2P(self["keyRed"] , c)
  FFrI2P(self["keyGreen"] , c)
  self.VVhfPl()
  self.VVov0d()
  FFm6nb(self["myColorTst"], self.defFG)
  FFrI2P(self["myColorTst"], self.defBG)
 def VVc7LH(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVov0d(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV0fH5(0, 0)
     return
 def VVtBNM(self):
  self.close(self.defFG, self.defBG)
 def VV66ms(self): self.VV0fH5(-1, 0)
 def VVs4n9(self): self.VV0fH5(1, 0)
 def VV0XiC(self): self.VV0fH5(0, -1)
 def VV2FzN(self): self.VV0fH5(0, 1)
 def VV0fH5(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVD2d2()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVCsrn()
 def VVhfPl(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVCsrn(self):
  color = self.VVD2d2()
  if self.isBgMode: FFrI2P(self["myColorTst"], color)
  else   : FFm6nb(self["myColorTst"], color)
 def VV5eUs(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVhfPl()
   self.VVov0d()
 def VVWvlE(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV0fH5(0, 0)
 def VVfczU(self):
  return hex(self.transp)[2:].zfill(2)
 def VVD2d2(self):
  return ("#%s%s" % (self.VVfczU(), self.colors[self.curRow][self.curCol])).upper()
class CCHCsp(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF1pMw(VVzYQ4, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFrOoX(self, title="%s%s%s" % (self.Title, " " * 10, FFHqZk("Change values with Up , Down, < , 0 , >", VVekE1)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVw6vF      ,
   "cancel" : self.VVOpp1      ,
   "info"  : self.VVmoiF    ,
   "red"  : self.VVohxT  ,
   "green"  : self.VVD0dR   ,
   "yellow" : BF(self.VV35ie, 0)  ,
   "blue"  : self.VVSwHq    ,
   "menu"  : self.VVdXBm      ,
   "left"  : self.VV0XiC      ,
   "right"  : self.VV2FzN      ,
   "last"  : self.VVW3ny     ,
   "next"  : self.VVPbdz     ,
   "0"   : self.VVzIpV    ,
   "up"  : self.VV66ms       ,
   "down"  : self.VVs4n9      ,
   "pageUp" : BF(self.VVxnFb, True) ,
   "pageDown" : BF(self.VVxnFb, False) ,
   "chanUp" : BF(self.VVxnFb, True) ,
   "chanDown" : BF(self.VVxnFb, False) ,
   "play"  : BF(self.VVHpHl, "pause")  ,
   "pause"  : BF(self.VVHpHl, "pause")  ,
   "playPause" : BF(self.VVHpHl, "pause")  ,
   "stop"  : BF(self.VVHpHl, "pause")  ,
   "audio"  : BF(self.VVHpHl, "audio")  ,
   "subtitle" : BF(self.VVHpHl, "subtitle") ,
   "rewind" : BF(self.VVHpHl, "rewind" ) ,
   "forward" : BF(self.VVHpHl, "forward" ) ,
   "rewindDm" : BF(self.VVHpHl, "rewindDm") ,
   "forwardDm" : BF(self.VVHpHl, "forwardDm")
  }, -1)
  self.VVrwNG()
  self.onShown.append(self.VVOOZO)
  self.onClose.append(self.VVysXt)
 def VVrwNG(self):
  lst = []
  for fil in FF6jDI(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VV8loG:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVOOZO(self):
  self.onShown.remove(self.VVOOZO)
  FFnQcA(self)
  FFtTSm(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VV9poF()
  self.VV3Gua()
  self.VVnQgi()
 def VVysXt(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVfrRm(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFrI2P(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVZWSh()
 def VV9poF(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFrI2P(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVw6vF(self):
  if self.settingShown:
   confItem = self.VVc1Sq()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVd21k = []
   if isinstance(lst[0], tuple):
    for item in lst: VVd21k.append((item[1], item[0]))
   else:
    for item in lst: VVd21k.append((item, item))
   menuInstance = FFxMT2(self, self.VViDwB, VVd21k=VVd21k, width=700, title=title, VVW1CX="#33221111", VVLasp="#33110011")
   menuInstance.VVDB8c(confItem.getIndex())
  else:
   self.close("subtExit")
 def VViDwB(self, item=None):
  if item:
   self.VVc1Sq()[self.CursorPos].setValue(item)
   self.VVZWSh()
   self.VV3Gua()
   self.VVLUMB(True)
 def VVOpp1(self):
  for confItem in self.VVc1Sq():
   if confItem.isChanged():
    FFWV4g(self, self.VVzDgc, "Save Changes ?", callBack_No=self.VVgLAI, title=self.Title)
    break
  else:
   if self.settingShown: self.VV9poF()
   else    : self.close("subtExit")
 def VVdXBm(self):
  if self.settingShown: self.VVXV62()
  else    : self.VVfrRm()
 def VV0XiC(self): self.VVtn3r(-1)
 def VV2FzN(self): self.VVtn3r(1)
 def VVtn3r(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVk1gI()
   if pos == -1: ndx = self.VVpeWG(posVal)
   else  : ndx = self.VVrmlv(posVal)
   if   ndx < 0      : FFkxeT(self, "Not found" , 500)
   elif ndx == 0      : FFkxeT(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFkxeT(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVuGgC(frmSec)
    if allow:
     self.VV35ie(delay, True)
     self.VVLUMB(force=True)
    else:
     FFkxeT(self, "Delay out of range", 800)
 def VVxnFb(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVHpHl(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVW3ny(self) : self.VVEwMv(5)
 def VVPbdz(self) : self.VVEwMv(6)
 def VVzIpV(self) : self.VVEwMv(-1)
 def VV66ms(self):
  if self.settingShown: self.VVEwMv(1)
  else    : self.VVxnFb(True)
 def VVs4n9(self):
  if self.settingShown: self.VVEwMv(0)
  else    : self.VVxnFb(False)
 def VVEwMv(self, direction):
  if self.settingShown:
   confItem = self.VVc1Sq()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVZWSh()
   self.VV3Gua()
   self.VVLUMB(True)
 def VVc1Sq(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVgLAI(self):
  for confItem in self.VVc1Sq(): confItem.cancel()
  self.VVZWSh()
  self.VV3Gua()
  self.VV9poF()
 def VVohxT(self):
  if self.settingShown:
   FFWV4g(self, self.VVodt5, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVodt5(self):
  for confItem in self.VVc1Sq(): confItem.setValue(confItem.default)
  self.VVzDgc()
  self.VVZWSh()
  self.VV3Gua()
 def VV35ie(self, delay, force=False):
  if self.settingShown or force:
   FFWvPK(CFG.subtDelaySec, delay)
   self.VV968v()
   self.VVZWSh()
   self.VV3Gua()
   if self.settingShown:
    FFkxeT(self, 'Reset to "0"', 800, isGrn=True)
 def VVD0dR(self):
  if self.settingShown:
   self.VVzDgc()
   self.VV9poF()
 def VVzDgc(self):
  for confItem in self.VVc1Sq(): confItem.save()
  configfile.save()
  self.VV968v()
  FFkxeT(self, "Saved", 1000, isGrn=True)
 def VVZWSh(self):
  cfgLst = self.VVc1Sq()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VV3Gua(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFGPE5(path, fnt, isRepl=1)
  else:
   fnt = VVlQv4
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFPwFt(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFm6nb(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFrI2P(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FF6lPQ(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFPwFt(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFJKbx()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FF6ScH(self, winW, winH)
 def VVmoiF(self):
  sp = "    "
  txt  = "%s\n"   % FFHqZk("Subtitle File:", VVWFW6)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFHqZk("Subtitle Settings:", VVWFW6)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVk1gI()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FF6f6P(frmSec1)
   time2 = FF6f6P(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFHqZk("Timing:", VVWFW6)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FF6f6P(durVal)
   txt += sp + "Progress\t: %s\n" % FF6f6P(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFHqZk("Subtitle end reached.", VVHeSZ)
  FFX3Iv(self, txt, title="Current Subtitle")
 def VVnQgi(self, path="", delay=0, enc=""):
  FFqcaP(self, BF(self.VVnSex, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVnSex(self, path="", delay=0, enc=""):
  FFkxeT(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVfG0Q(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVZWSh()
     self.VVpwEM()
   else:
    path, delay, enc = CCHCsp.VVoZUO(self)
    if path:
     self.VVnQgi(path=path, delay=delay, enc=enc)
    else:
     self.VVXV62()
  except:
   pass
 def VVpwEM(self):
  posVal, durVal = self.VVk1gI()
  if self.VVzVii(posVal):
   return
  CCHCsp.VVgUDO(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVLUMB)
  except:
   self.timerUpdate.callback.append(self.VVLUMB)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVe3VX)
  except:
   self.timerEndText.callback.append(self.VVe3VX)
  FFkxeT(self, "Subtitle started", 700, isGrn=True)
 def VVzVii(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCHCsp.VVfRvc(self)
   FFC2Q5(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVXV62(self):
  c1, c2, c3, c4, c5 = "", VVWFW6, VVRK3s, VVyuFD, VVHeSZ
  VVd21k = []
  VVd21k.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVd21k.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVd21k.append(VVNCuu)
  VVd21k.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVd21k.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVd21k.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVd21k.append(VVNCuu)
   VVd21k.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVd21k.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVd21k.append(VVNCuu)
   VVd21k.append(("Help (Keys)"        , "help"  ))
  FFxMT2(self, self.VVej0t, VVd21k=VVd21k, width=700, title='Find Subtitle ".srt" File', VVW1CX="#33221111", VVLasp="#33110011")
 def VVej0t(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVr5G8(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVr5G8(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVBjIf, BF(CCk3u6, patternMode="srt", VVl4c7=sDir))
   elif item.startswith("sugSrt") : self.VVr5G8(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFqcaP(self, BF(CCtiVE.VVVTUQ, self, self.lastSubtFile, self.VVEfRd, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFkxeT(self, "SRT File error", 1000)
   elif item == "disab":
    FFC2Q5(CCHCsp.VVfRvc(self))
    self.close("subtExit")
   elif item == "help"    : FFkKs9(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVEfRd(self, item=None):
  if item:
   FFqcaP(self, BF(self.VVnQgi, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVBjIf(self, path):
  if path:
   FFWvPK(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVnQgi(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVr5G8(self, defSrt="", mode=0, coeff=0.25):
  FFqcaP(self, BF(self.VVW0Dq, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVW0Dq(self, defSrt="", mode=0, coeff=0.25):
  FFkxeT(self)
  if mode == 1:
   srtList = CCHCsp.VVnKIS(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFjUOl('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFflDg(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVav3l(srtList, coeff)
     if err:
      if self.settingShown: FFkxeT(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVG5ES = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFjZE4(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVG5ES.append((fName, Dir))
   VVmG3M  = ("Select"    , self.VVINMK     , [])
   VVVD8O = self.VVvaQH
   VVAe4b = (""     , self.VVuVyG       , [])
   VVbNxw = (""     , BF(self.VVcBJz, defSrt, False) , [])
   VVZyxX = ("Find Current File" , BF(self.VVcBJz, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VVje1O=widths, VVlvFD=28, VVmG3M=VVmG3M, VVVD8O=VVVD8O, VVAe4b=VVAe4b, VVbNxw=VVbNxw, VVZyxX=VVZyxX, lastFindConfigObj=CFG.lastFindSubtitle
     , VVW1CX="#11002222", VVLasp="#33001111", VVHSOH="#33001111", VVNfgg="#11ffff00", VVJqmr="#11445544", VVFNoD="#22222222", VVcwBH="#11002233")
  elif self.settingShown : FFkxeT(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVvaQH(self, VVc7Yu):
  VVc7Yu.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVuVyG(self, VVc7Yu, title, txt, colList):
  fName, Dir = colList
  FFX3Iv(VVc7Yu, "%s\n\n%s%s" % (FFHqZk("Path:", VVWFW6), Dir, fName), title=title)
 def VVcBJz(self, path, VV3KZ2, VVc7Yu, title, txt, colList):
  for ndx, row in enumerate(VVc7Yu.VVgeCg()):
   if path == row[1].strip() + row[0].strip():
    VVc7Yu.VVQ2AR(ndx)
    break
  else:
   if VV3KZ2:
    FFkxeT(VVc7Yu, "Not in list !", 1000)
 def VVINMK(self, VVc7Yu, title, txt, colList):
  VVc7Yu.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVnQgi(path=path)
 def VVav3l(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTkbp.VVDSwc(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCTkbp.VVhi5T(evName, "en")[0] or evName
   lst, err = CCHCsp.VVEory(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVfG0Q(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FF2oRJ(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFwiKR(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VV3InM(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVHpKI(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV968v()
  return subtList, ""
 def VVHpKI(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VV3InM(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV968v(self):
  path = CCHCsp.VVfRvc(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVLUMB(self, force=False):
  posVal, durVal = self.VVk1gI()
  if self.VVzVii(posVal):
   return
  curIndex = self.VVUY54(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVe3VX()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFm6nb(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVk1gI(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCqzRz.VV52Xv(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTkbp.VVDSwc(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVUY54(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVpeWG(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVrmlv(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVe3VX(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFm6nb(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVSwHq(self):
  FFqcaP(self, self.VVaXsw, title="Loading Lines ...", clearMsg=False)
 def VVaXsw(self):
  FFkxeT(self)
  VVG5ES = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVG5ES.append((cap, FF6f6P(frm), str(frm), firstLine))
  if VVG5ES:
   title = "Select Current Subtitle Line"
   VV1jVB  = self.VVQcC7
   VVVD8O = self.VVQvep
   VVmG3M  = ("Select"   , self.VV9veG , [title])
   VVZyxX = ("Current Line" , self.VVABPf , [True])
   VVQJvS = ("Reset Delay" , self.VVgCZ9 , [])
   VVOr9v = ("New Delay"  , self.VVV9zd   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VV4tj2  = (CENTER , CENTER, CENTER , LEFT    )
   VVc7Yu = FF8dRU(self, None, title=title, header=header, VVHQsP=VVG5ES, VV4tj2=VV4tj2, VVje1O=widths, VVlvFD=28, VV1jVB=VV1jVB, VVVD8O=VVVD8O, VVmG3M=VVmG3M, VVZyxX=VVZyxX, VVQJvS=VVQJvS, VVOr9v=VVOr9v
          , VVW1CX="#33002222", VVLasp="#33001111", VVHSOH="#33110011", VVNfgg="#11ffff00", VVJqmr="#0a334455", VVFNoD="#22222222", VVcwBH="#33002233")
  else:
   FFkxeT(self, "Cannot read lines !", 2000)
 def VVQcC7(self, VVc7Yu):
  self.subtLinesTable = VVc7Yu
  if CFG.subtDelaySec.getValue():
   VVc7Yu["keyYellow"].show()
   VVc7Yu["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVc7Yu["keyYellow"].hide()
  VVc7Yu["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFrI2P(VVc7Yu["keyBlue"], "#22222222")
  VVc7Yu.VVTbDK(BF(self.VVhNu0, VVc7Yu))
  self.VVABPf(VVc7Yu, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVlU5h)
  except:
   self.timerSubtLines.callback.append(self.VVlU5h)
  self.timerSubtLines.start(1000, False)
 def VVQvep(self, VVc7Yu):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVc7Yu.cancel()
 def VVlU5h(self):
  if self.subtLinesTable:
   VVc7Yu = self.subtLinesTable
   posVal, durVal = self.VVk1gI()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVUY54(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVc7Yu.VVDV9v(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVc7Yu.VVENUj(self.subtLinesTableNdx, row)
     row = VVc7Yu.VVDV9v(curIndex)
     row[0] = color + row[0]
     VVc7Yu.VVENUj(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VV9veG(self, VVc7Yu, Title):
  delay, color, allow = self.VVl84t(VVc7Yu)
  if allow:
   self.VVQvep(VVc7Yu)
   self.VV35ie(delay, True)
  else:
   FFkxeT(VVc7Yu, "Delay out of range", 1500)
 def VVABPf(self, VVc7Yu, VV3KZ2, onlyColor=False):
  if VVc7Yu:
   posVal, durVal = self.VVk1gI()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVUY54(posVal)
    if curIndex > -1:
     VVc7Yu.VVQ2AR(curIndex)
    else:
     ndx = self.VVpeWG(posVal)
     if ndx > -1:
      VVc7Yu.VVQ2AR(ndx)
 def VVgCZ9(self, VVc7Yu, title, txt, colList):
  if VVc7Yu["keyYellow"].getVisible():
   self.VV35ie(0, True)
   VVc7Yu["keyYellow"].hide()
   self.VVABPf(VVc7Yu, False)
 def VVhNu0(self, VVc7Yu):
  delay, color, allow = self.VVl84t(VVc7Yu)
  VVc7Yu["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVl84t(self, VVc7Yu):
  lineTime = float(VVc7Yu.VVDx8h()[2].strip())
  return self.VVuGgC(lineTime)
 def VVuGgC(self, lineTime):
  posVal, durVal = self.VVk1gI()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVusL5
   else     : allow, color = False, VVHeSZ
   delay = FFK3ps(val, -600, 600)
  return delay, color, allow
 def VVV9zd(self, VVc7Yu, title, txt, colList):
  pass
 @staticmethod
 def VVLL4r(SELF):
  path, delay, enc = CCHCsp.VVoZUO(SELF)
  return True if path else False
 @staticmethod
 def VVoZUO(SELF):
  path, delay, enc = CCHCsp.VVQ39O(SELF)
  if not path:
   path = CCHCsp.VVbV4q(SELF)
  return path, delay, enc
 @staticmethod
 def VVQ39O(SELF):
  srtCfgPath = CCHCsp.VVfRvc(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFwiKR(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVfRvc(SELF):
  fPath, fDir, fName = CCk3u6.VVURIr(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCTkbp.VVDSwc(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF4ETG(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVbV4q(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCk3u6.VVURIr(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCHCsp.VVnKIS(SELF)
    bLst, err = CCHCsp.VVEory(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVnKIS(SELF):
  fPath, fDir, fName = CCk3u6.VVURIr(SELF)
  if pathExists(fDir):
   files = FF6jDI(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVEory(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVZCyS():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVgUDO(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCHCsp.VV1otj()
 @staticmethod
 def VV1otj():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CC5iEy(ScrollLabel):
 def __init__(self, parentSELF, text="", VVkL22=True):
  ScrollLabel.__init__(self, text)
  self.VVkL22   = VVkL22
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VV2a9V  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVlvFD    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVPuPN ,
   "green"   : self.VVeK4q ,
   "yellow"  : self.VVeTf3 ,
   "blue"   : self.VV8s86 ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VV6hwf, 0) ,
   "0"    : BF(self.VV6hwf, 1) ,
   "next"   : BF(self.VV6hwf, 2) ,
   "pageUp"  : self.VV0mT7   ,
   "chanUp"  : self.VV0mT7   ,
   "pageDown"  : self.VVIuCX   ,
   "chanDown"  : self.VVIuCX
  }, -1)
 def VVuWLn(self, isResizable=True, VV0CQU=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFm6nb(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFrI2P(self.parentSELF["keyRedTop"], "#113A5365")
  FFnQcA(self.parentSELF, True)
  self.isResizable = isResizable
  if VV0CQU:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVlvFD  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFrI2P(self, color)
 def VVQG1v(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV2a9V - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVrlyi()
 def pageUp(self):
  if self.VV2a9V > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV2a9V > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV0mT7(self):
  self.setPos(0)
 def VVIuCX(self):
  self.setPos(self.VV2a9V-self.pageHeight)
 def VVqhbl(self):
  return self.VV2a9V <= self.pageHeight or self.curPos == self.VV2a9V - self.pageHeight
 def getText(self):
  return self.message
 def VVrlyi(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV2a9V, 3))
   start = int((100 - vis) * self.curPos / (self.VV2a9V - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVXwlZ=VVdsyE):
  old_VVqhbl = self.VVqhbl()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   h = self.parentSELF.skinParam["bodyLineH"] * (len(self.message.splitlines()) + 1) - self.parentSELF.skinParam["marginTop"]
   h = max(h, self.long_text.calculateSize().height())
   self.VV2a9V = h if h > 0 else self.pageHeight
   if self.VVkL22 and self.VV2a9V > self.pageHeight:
    self.scrollbar.show()
    self.VVrlyi()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV2a9V))
   if   VVXwlZ == VVo3oH: self.setPos(0)
   elif VVXwlZ == VVlCEy : self.VVIuCX()
   elif old_VVqhbl    : self.VVIuCX()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVXwlZ=VVXwlZ)
 def appendText(self, text, VVXwlZ=VVlCEy):
  self.setText(self.message + str(text), VVXwlZ=VVXwlZ)
 def VVeTf3(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVgLSl(size)
 def VV8s86(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVgLSl(size)
 def VVeK4q(self):
  self.VVgLSl(self.VVlvFD)
 def VVgLSl(self, VVlvFD):
  self.long_text.setFont(gFont(self.fontFamily, VVlvFD))
  self.setText(self.message, VVXwlZ=VVdsyE)
  self.VVeYTy(calledFromFontSizer=True)
 def VV6hwf(self, align):
  self.long_text.setHAlign(align)
 def VVPuPN(self):
  VVd21k = []
  VVd21k.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Align Left"  , "left" ))
  VVd21k.append(("Align Center"  , "center" ))
  VVd21k.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVd21k.append(VVNCuu)
   VVd21k.append((FFHqZk("Save to File", VVWFW6), "save" ))
  VVd21k.append(VVNCuu)
  VVd21k.append(("Keys (Shortcuts)" , "help" ))
  FFxMT2(self.parentSELF, self.VVXJ6I, VVd21k=VVd21k, title="Text Option", width=500)
 def VVXJ6I(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VV6hwf(0)
   elif item == "center" : self.VV6hwf(1)
   elif item == "right" : self.VV6hwf(2)
   elif item == "save"  : self.VVjBXa()
   elif item == "help"  : FFkKs9(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVjBXa(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFjZE4(expPath), self.outputFileToSave, FF5Vj3())
   with open(outF, "w") as f:
    f.write(FFFnqK(self.message))
   FFfF2j(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FF1uaI(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVeYTy(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV2a9V > 0 and self.pageHeight > 0:
   if self.VV2a9V < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV2a9V
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
