import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger, ConfigSubList
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VV96cs   = "v4.2.0"
VVcPf3    = "17-03-2022"
EASY_MODE    = 0
VVXDdI   = 0
VVknG2   = 0
VVbBic  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVm7l9  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVvHG2    = "/media/usb/"
VVgOqp    = "/usr/share/enigma2/picon/"
VV9m85   = "/etc/enigma2/"
VVxv1o  = "ajpanel_update_url"
VViplk   = "AJPan"
VVZnKC    = "AUTO FIND"
VVZVvC    = ""
VV55z0    = "Regular"
VVS5oR      = "-" * 80
VV9e5C    = ("-" * 100, )
VVXkf5    = ""
VVuFH5   = " && echo 'Successful' || echo 'Failed!'"
VVinSX    = []
VVJ2Pf  = "Cannot continue (No Enough Memory) !"
VVEDT5   = (None, "utf-8", "ISO8859-15", "ISO8859-7", "ISO8859-5", "ISO6937", "windows-1250", "windows-1252", "unicode_escape")
VV5ZBQ  = False
VVWfYG  = False
VVjdSQ = False
VVEShK     = 0
VVQTx4    = 1
VVA30l    = 2
VVQ70f   = 3
VVrNoE    = 4
VVb7Jj    = 5
VVI14G = 6
VVyduo = 7
VVEEKb  = 8
VV5s3X   = 9
VVed3u   = 10
VVbMYa   = 11
VVrpQE  = 12
VVHHzS  = 13
VVhiru    = 14
VVIVwd   = 15
VVpQQK   = 16
VVom0v    = 17
VV9isB  = 18
VVu5hn  = 15
VVsWwL   = 0
VVOJfg   = 1
VVpkLV   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=False)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVZnKC, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVgOqp, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVvHG2, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
def FF6BPo():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVZG72  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV9KRr = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVZG72  : return 0
  elif VV9KRr : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VV8qMu = FF6BPo()
VVfjTY = VVLchc = VVFT40 = VVtUnE = VVzCLY = VVwwQa = VVfxXg = VVYPWI = COLOR_CONS_BRIGHT_YELLOW = VVy6YC = VVakPb = VV0cUe = VVB0Ol = ""
def FFTLJ6()  : return FF7nAu()
def FFam4Q(*args) : FFHlfr(True , *args)
def FF8tAW(*args): FFHlfr(False, *args)
def FFHlfr(addSep=True, *args):
 if VVXDdI:
  txt  = (">>>> %s\n" % VVS5oR) if addSep else ""
  txt += ">>>> %s" % " , ".join(map(str, args))
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFg58v(txt, isAppend=True, ignoreErr=False):
 if VVXDdI:
  tm = FFnxHX()
  err = ""
  if not ignoreErr:
   err = FF7nAu()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFam4Q(err)
  FFam4Q("Output Log File : %s" % fileName)
def FF7nAu():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFnxHX()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFyYR7():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVinSX = []
def FFUfvu(win):
 global VVinSX
 if not win in VVinSX:
  VVinSX.append(win)
def FFfnA1(*args):
 global VVinSX
 for win in VVinSX:
  try:
   win.close()
  except:
   pass
 VVinSX = []
def FFAoqj():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVsviS = FFAoqj()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFDGoc()     : return PluginDescriptor(fnc=FFFO7f, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFNKF1()      : return getDescriptor(FFljp7   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFxBU6()       : return getDescriptor(FFT0Gm  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFEqWw()   : return getDescriptor(FFhffJ , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFFaMB(): return getDescriptor(FFvMx7 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFG204()  : return getDescriptor(FFv1aw  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFwxwE()     : return getDescriptor(FFUdqw , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFNKF1() , FFxBU6() , FFDGoc() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFEqWw())
  result.append(FFFaMB())
  result.append(FFG204())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFwxwE())
 return result
def FFFO7f(reason, **kwargs):
 if reason == 0:
  FFqNi8()
  if "session" in kwargs:
   session = kwargs["session"]
   FFfVLw(session)
   CCbK7L(session)
def FFT0Gm(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFljp7, PLUGIN_NAME, 45)]
 else:
  return []
def FFljp7(session, **kwargs):
 session.open(Main_Menu)
def FFhffJ(session, **kwargs):
 session.open(CCWnyZ)
def FFvMx7(session, **kwargs):
 FFYawX(session, isFromSession=True)
def FFv1aw(session, **kwargs):
 session.open(CCNqVt)
def FFUdqw(session, **kwargs):
 session.open(CCPltO, fncMode=CCPltO.VVZJlx)
def FFtFJf():
 FFgV0T(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFEqWw(), FFFaMB(), FFG204() ])
 FFgV0T(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFwxwE() ])
def FFgV0T(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVBemF = None
def FFqNi8():
 try:
  global VVBemF
  if VVBemF is None:
   VVBemF    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FF4tKc
  ChannelContextMenu.FF04vi = FF04vi
 except:
  pass
def FF4tKc(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVBemF(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FF04vi, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FF04vi, title1, csel, isFind=True))))
def FF04vi(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFMgu7(refCode)
 except:
  pass
 self.session.open(boundFunction(CCD9yx, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFfVLw(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFmUL2, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFmUL2, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFmUL2, session, "lred")
def FFmUL2(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFYawX(session, isFromSession=True)
def FFSF9U(SELF, title="", addLabel=False, addScrollLabel=False, VVw8eP=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFSUtV()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCxBZn(SELF)
 if VVw8eP:
  SELF["myMenu"] = MenuList(VVw8eP)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVhKHG        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFGWyw(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFSLXO, SELF, "0") ,
  "1"    : boundFunction(FFSLXO, SELF, "1") ,
  "2"    : boundFunction(FFSLXO, SELF, "2") ,
  "3"    : boundFunction(FFSLXO, SELF, "3") ,
  "4"    : boundFunction(FFSLXO, SELF, "4") ,
  "5"    : boundFunction(FFSLXO, SELF, "5") ,
  "6"    : boundFunction(FFSLXO, SELF, "6") ,
  "7"    : boundFunction(FFSLXO, SELF, "7") ,
  "8"    : boundFunction(FFSLXO, SELF, "8") ,
  "9"    : boundFunction(FFSLXO, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFO0eY, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFSLXO(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVB0Ol:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVB0Ol + SELF.keyPressed + VVLchc)
    txt = VVLchc + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF4n96(SELF, txt)
def FFO0eY(SELF, tableObj, colNum):
 FF4n96(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVINep(i)
     break
 except:
  pass
def FFPRHj(SELF, setMenuAction=True):
 if setMenuAction:
  global VVXkf5
  VVXkf5 = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFSUtV():
 return ("  %s" % VVXkf5)
def FFw7jX(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFtG6X(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFKiR0(color):
 return parseColor(color).argb()
def FFLdCa(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFtJEw(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFm7Uq(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF6sH0(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVB0Ol)
 else:
  return ""
def FFdbLX(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVS5oR, word, VVS5oR, VVB0Ol)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVS5oR, word, VVS5oR)
def FFkGYB(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVB0Ol
def FFEtzo(color):
 if color: return "echo -e '%s' %s;" % (VVS5oR, FF6sH0(VVS5oR, VVYPWI))
 else : return "echo -e '%s';" % VVS5oR
def FFGsc3(title, color):
 title = "%s\n%s\n%s\n" % (VVS5oR, title, VVS5oR)
 return FFkGYB(title, color)
def FFAblH(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFv5ve(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFlxSW(callBackFunction):
 tCons = CCPn4h()
 tCons.ePopen("echo", boundFunction(FFzRKI, callBackFunction))
def FFzRKI(callBackFunction, result, retval):
 callBackFunction()
def FFKl3w(SELF, fnc, title="Processing ...", clearMsg=True):
 FF4n96(SELF, title)
 tCons = CCPn4h()
 tCons.ePopen("echo", boundFunction(FF9Mol, SELF, fnc, clearMsg))
def FF9Mol(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF4n96(SELF)
def FF9r0n(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVJ2Pf
  else       : return ""
def FFgPQo(cmd):
 txt = FF9r0n(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFla3R(cmd):
 lines = FFgPQo(cmd)
 if lines: return lines[0]
 else : return ""
def FFy1CT(SELF, cmd):
 lines = FFgPQo(cmd)
 VV5w32 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV5w32.append((key, val))
  elif line:
   VV5w32.append((line, ""))
 if VV5w32:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFS01Q(SELF, None, header=header, VVNz0H=VV5w32, VVTy8n=widths, VVjgTX=28)
 else:
  FFelLa(SELF, cmd)
def FFelLa(    SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, VVCSrv=True, VVMBud=VVOJfg, **kwargs)
def FFoSpn(  SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, **kwargs)
def FFZust(   SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, VVACcx=True, VVojAp=True, VVMBud=VVOJfg, **kwargs)
def FF34xz(  SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, VVACcx=True, VVojAp=True, VVMBud=VVpkLV, **kwargs)
def FFypV6(  SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, VVmTcl=True , **kwargs)
def FFTxfy( SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, VVB3GY=True   , **kwargs)
def FF1obA( SELF, cmd, **kwargs): SELF.session.open(CCA4uq, VVA6hv=cmd, VV4Zoh=True  , **kwargs)
def FFK72g(cmd):
 return cmd + " > /dev/null 2>&1"
def FFahWw():
 return " > /dev/null 2>&1"
def FFGzR8(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFYGMZ(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFFQGA():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFla3R(cmd)
VVcIup     = 0
VVUOoZ      = 1
VVryhT   = 2
VVV9W2      = 3
VVHJAK      = 4
VVS6fG     = 5
VVggHo     = 6
VV0Gj2 = 7
VVSKZV = 8
VVyV6h = 9
VVmetP  = 10
VVr4M9     = 11
VV8CGQ  = 12
VV4urB  = 13
def FFZsGt(parmNum, grepTxt):
 if   parmNum == VVcIup  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVUOoZ   : param = ["list"   , "apt list" ]
 elif parmNum == VVryhT: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFFQGA()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFp0JH(parmNum, package):
 if   parmNum == VVV9W2      : param = ["info"      , "apt show"         ]
 elif parmNum == VVHJAK      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVS6fG     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVggHo     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VV0Gj2 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVSKZV : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVyV6h : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVmetP  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVr4M9     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV8CGQ  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV4urB  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFFQGA()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFsXZx():
 result = FFla3R("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFp0JH(VVggHo , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFK72g("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFK72g("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF6sH0(failed1, VVYPWI))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF6sH0(failed2, VVYPWI))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF6sH0(failed3, VVFT40))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFQAHp(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFp0JH(VVggHo , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFK72g("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF6sH0(failed1, VVYPWI))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF6sH0(failed2, VVFT40))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFyisd(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFK72g('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFK72g("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFzVLg(path, maxSize=-1):
 txt = ""
 for enc in VVEDT5:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFg2eB(path, keepends=False, maxSize=-1):
 lines = FFzVLg(path, maxSize)
 return lines.splitlines(keepends)
def FFTDoH(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFCOks(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFg2eB(path, maxSize=maxSize)
  if lines: FFVxvP(SELF, lines, title=title, VVMBud=VVOJfg)
  else : FFfN7q(SELF, path, title=title)
 else:
  FFOr2O(SELF, path, title)
def FF47lG(SELF, path, title):
 if fileExists(path):
  txt = FFzVLg(path)
  txt = txt.replace("#W#", VVB0Ol)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVLchc)
  txt = txt.replace("#C#", VVy6YC)
  txt = txt.replace("#P#", VVtUnE)
  FFVxvP(SELF, txt, title=title)
 else:
  FFOr2O(SELF, path, title)
def FFPUkJ(path, SELF=None):
 txt = ""
 for enc in VVEDT5:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return enc
  except:
   pass
 if SELF:
  FFc88f(SELF, "Cannot detect file encoding for:\n\n%s" % path)
 return -1
def FF6Jad(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFaVZl(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFxq1R(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF1ZUc(parent)
 else    : return FFh7YC(parent)
def FFCOks(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FF1ZUc(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFh7YC(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFYpV4():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVbBic)
 paths.append(VVbBic.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFaVZl(ba)
 for p in list:
  p = ba + p + VVbBic
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VViplk, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVbBic, VViplk , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVTTSd, VVAwa9 = FFYpV4()
def FFwRBd():
 def VVsdAW(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVZnKC and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVZnKC)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVZnKC
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVsdAW(CFG.MovieDownloadPath, CCaDOu.VVFpZ8())
 VV6g3V   = VVsdAW(CFG.backupPath, CCFOfb.VVPLGT())
 VV30pe   = VVsdAW(CFG.downloadedPackagesPath, t)
 VVeg1k  = VVsdAW(CFG.exportedTablesPath, t)
 VVwhRo  = VVsdAW(CFG.exportedPIconsPath, t)
 VVTVPz   = VVsdAW(CFG.packageOutputPath, t)
 global VVvHG2
 VVvHG2 = FF1ZUc(CFG.backupPath.getValue())
 if VV6g3V or VVTVPz or VV30pe or VVeg1k or VVwhRo or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VV6g3V, VVTVPz, VV30pe, VVeg1k, VVwhRo, oldIptvHostsPath, oldMovieDownloadPath
def FF61bG(path):
 path = FFh7YC(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FF0zXt(SELF, pathList, tarFileName, addTimeStamp=True):
 VVNz0H = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVNz0H.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVNz0H.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVNz0H.append(path)
 if not VVNz0H:
  FFc88f(SELF, "Files not found!")
 elif not pathExists(VVvHG2):
  FFc88f(SELF, "Path not found!\n\n%s" % VVvHG2)
 else:
  VVqRpK = FF1ZUc(VVvHG2)
  tarFileName = "%s%s" % (VVqRpK, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFnEIN())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVNz0H:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVS5oR
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF6sH0(tarFileName, VVfxXg))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF6sH0(failed, VVfxXg))
  cmd += "fi;"
  cmd +=  sep
  FFoSpn(SELF, cmd)
def FFzPkO(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFOx42(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFOx42(SELF["keyInfo"], "info")
def FFOx42(barObj, fName):
 path = "%s%s%s" % (VVAwa9, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFWcKR(SELF, title, VVk9uz, showGrnMsg=""):
 SELF.session.open(boundFunction(CC8A64, title=title, VVk9uz=VVk9uz, showGrnMsg=showGrnMsg))
def FFfb15(labelObj, VVk9uz):
 if VVk9uz and fileExists(VVk9uz):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVJuIG(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVJuIG)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVk9uz)
   return True
  except:
   pass
 return False
def FF9joe(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFcRp5(satNum)
  return satName
def FFcRp5(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFCJvX(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF9joe(val)
  else  : sat = FFcRp5(val)
 return sat
def FFJJD0(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF9joe(num)
 except:
  pass
 return sat
def FFARL6(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFEnco(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF9E9G(info, iServiceInformation.sServiceref)
   prov = FF9E9G(info, iServiceInformation.sProvider)
   state = str(FF9E9G(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF7z8Z(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFCoVU(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF9E9G(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFw2pT(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFMgu7(refCode):
 info = FF4lgs(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FF2vrH(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFYtZj(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF4lgs(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVNfWS = eServiceCenter.getInstance()
  if VVNfWS:
   info = VVNfWS.info(service)
 return info
def FFaA9c(SELF, refCode, VVNAZj=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFycMY(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVNAZj:
   FFYawX(SELF, isFromSession)
 try:
  VV0Hqr = InfoBar.instance
  if VV0Hqr:
   VVtLl0 = VV0Hqr.servicelist
   if VVtLl0:
    servRef = eServiceReference(refCode)
    VVtLl0.saveChannel(servRef)
 except:
  pass
def FFycMY(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCKMVs()
    if pr.VVozjw(refCode, chName, decodedUrl, iptvRef):
     pr.VVvO6l(SELF, isFromSession)
def FF7z8Z(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFzavm(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFjwaX(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFknMo(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFCoVU(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFWpIM(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFjfIu(userBfile):
 txt = ""
 bFile = VV9m85 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VV9m85 + userBfile):
  fTxt = FFzVLg(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFla3R('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFWpIM(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFtKtF(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFrLOq(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFrGRP(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFiCfS(txt):
 try:
  return FFrLOq(FFrGRP(txt)) == txt
 except:
  return False
def FFYawX(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CC9DjN, isFromExternal=isFromSession)
 else      : FFHS7R(session, reopen=True, isFromExternal=isFromSession)
def FFHS7R(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFHS7R, session, isFromExternal=isFromExternal), boundFunction(CC2IIP, isFromExternal=isFromExternal))
  except:
   try:
    FF3woz(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFgVxg(refCode):
 tp = CCriLw()
 if tp.VVj4p1(refCode) : return True
 else        : return False
def FFOcmO(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFikPN():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFcqwa():
 VV0Hqr = InfoBar.instance
 if VV0Hqr:
  VVtLl0 = VV0Hqr.servicelist
  if VVtLl0:
   return VVtLl0.getBouquetList()
 return None
def FFbvLj():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFkzXS():
 path = FFbvLj()
 if path:
  txt = FFzVLg(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFtBXK():
 return FF2rc7(InfoBar.instance.servicelist.getRoot())
def FF2rc7(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVNfWS = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVNfWS.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FF8cJh():
 VVEX0Z = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVO0bf = list(VVEX0Z)
 return VVO0bf, VVEX0Z
def FFSY53():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFqhrZ(session, VVJ1Ve):
 VVlMOw, VVzn1Y, VVaTxy, camCommand = FFlLsd()
 if VVzn1Y:
  runLog = False
  if   VVJ1Ve == CCC73f.VVTQSE : runLog = True
  elif VVJ1Ve == CCC73f.VVwm5N : runLog = True
  elif not VVaTxy          : FF3woz(session, message="SoftCam not started yet!")
  elif fileExists(VVaTxy)        : runLog = True
  else             : FF3woz(session, message="File not found !\n\n%s" % VVaTxy)
  if runLog:
   session.open(boundFunction(CCC73f, VVlMOw=VVlMOw, VVzn1Y=VVzn1Y, VVaTxy=VVaTxy, VVJ1Ve=VVJ1Ve))
 else:
  FF3woz(session, message="No active OSCam/NCam found !", title="Live Log")
def FFlLsd():
 VVlMOw = "/etc/tuxbox/config/"
 VVzn1Y = None
 VVaTxy  = None
 camCommand = FFla3R("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVzn1Y = "oscam"
 elif "ncam"  in camCommand : VVzn1Y = "ncam"
 if VVzn1Y:
  path = FFla3R(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FF1ZUc(path)
  if pathExists(path):
   VVlMOw = path
  tFile = VVlMOw + VVzn1Y + ".conf"
  tFile = FFla3R("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVaTxy = tFile
 return VVlMOw, VVzn1Y, VVaTxy, camCommand
def FF7tZn(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFe93I():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFnEIN():
 return FFe93I().replace(" ", "_").replace("-", "").replace(":", "")
def FFcGNd(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFnxHX():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFPEOO(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCNqVt.VVXjzP(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCNqVt.VVK2Qy_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFK72g("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFpr4w(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FF4FJG(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVEixX = 0
def FF5qtD():
 global VVEixX
 VVEixX = iTime()
def FFn4Zc():
 FFam4Q(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVEixX).rstrip("0").rstrip("."))
def FF1ATN(SELF, message, title=""):
 SELF.session.open(boundFunction(CCdr9C, title=title, message=message, VVIekL=True))
def FFVxvP(SELF, message, title="", VVMBud=VVOJfg, **kwargs):
 SELF.session.open(boundFunction(CCdr9C, title=title, message=message, VVMBud=VVMBud, **kwargs))
def FFc88f(SELF, message, title="")  : FF3woz(SELF.session, message, title)
def FFOr2O(SELF, path, title="") : FF3woz(SELF.session, "File not found !\n\n%s" % path, title)
def FFfN7q(SELF, path, title="") : FF3woz(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFdCT7(SELF, title="")  : FF3woz(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF3woz(session, message, title="") : session.open(boundFunction(CC8DfR, title=title, message=message))
def FFTT6y(SELF, VVOm4z, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVOm4z, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVOm4z, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVOm4z, boundFunction(CCPuvC, title=title, message=message, VVIh6s=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFc88f(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFfK5z(SELF, callBack_Yes, VVffrf, callBack_No=None, title="", VVPjh4=False, VVyivk=True):
 SELF.session.openWithCallback(boundFunction(FFclG3, callBack_Yes, callBack_No)
        , boundFunction(CCcMPQ, title=title, VVffrf=VVffrf, VVyivk=VVyivk, VVPjh4=VVPjh4))
def FFclG3(callBack_Yes, callBack_No, FFfK5zed):
 if FFfK5zed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF4n96(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFtJEw(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFvCPp(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFAkF7(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVbN0w = eTimer()
def FFvCPp(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFAxXo, SELF))
 fnc = boundFunction(FFAxXo, SELF)
 try:
  t = VVbN0w.timeout.connect(fnc)
 except:
  VVbN0w.callback.append(fnc)
 VVbN0w.start(milliSeconds, 1)
def FFAxXo(SELF):
 VVbN0w.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFS01Q(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCMmmJ, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCMmmJ, **kwargs))
  FFUfvu(win)
  return win
 except:
  return None
def FF7Bt5(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC6E4v, **kwargs))
 FFUfvu(win)
 return win
def FFgbQa(SELF, **kwargs):
 SELF.session.open(CCPltO, **kwargs)
def FFEgCR(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFV5n0(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV55z0, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFoJNI(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFV5n0(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFAghz():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFjMIC(VVjgTX):
 screenSize  = FFAghz()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVjgTX)
 return bodyFontSize
def FF6bag(VVjgTX, extraSpace):
 font = gFont(VV55z0, VVjgTX)
 VVOJXs = fontRenderClass.getInstance().getLineHeight(font) or (VVjgTX * 1.25)
 return int(VVOJXs + VVOJXs * extraSpace)
def FF56fW(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VV55z0
def FFAEOm(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFAghz()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVu5hn)
 bodyFontStr  = 'font="%s;%d"' % (VV55z0, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FF6bag(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VV55z0, titleFontSize, alignLeftCenter)
 if winType == VVEShK or winType == VVQTx4:
  if winType == VVQTx4 : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VV9isB:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVhiru:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FF1ATNL = b2Left2 + timeW + marginLeft
  FF1ATNW = b2Left3 - marginLeft - FF1ATNL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FF1ATNL  , b2Top, FF1ATNW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="1000" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVIVwd:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVrNoE:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVA30l:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVQ70f:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV55z0, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV55z0, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVed3u:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FF1ATNH = int(bodyH * 0.5)
  inpTop = bodyTop + FF1ATNH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FF1ATNH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VV55z0, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VV55z0, mapF, alignCenter)
 elif winType == VVbMYa:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVrpQE:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV55z0, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVpQQK:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV55z0, fontH, alignCenter)
 elif winType == VVHHzS:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VV55z0, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VV55z0, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VV55z0, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVom0v:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVyduo : align = alignLeftCenter
  elif winType == VVI14G : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV5s3X:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVb7Jj:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVI14G:
    fontStr = 'font="%s;%d"' % (FF56fW("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVjgTX = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV55z0, VVjgTX, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVYhbt = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV55z0, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVYhbt[i], VV55z0, barFont, alignCenter)
   left += btnW + gap
 if winType == VVI14G:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVYhbt = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVYhbt[i], VV55z0, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVw8eP = []
  if VVknG2:
   VVw8eP.append(("-- MY TEST --"    , "myTest"   ))
  VVw8eP.append(("  File Manager"     , "FileManager"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("  Services/Channels"    , "ChannelsTools" ))
  VVw8eP.append(("  IPTV"       , "IptvTools"  ))
  VVw8eP.append(("  PIcons"       , "PIconsTools"  ))
  VVw8eP.append(("  SoftCam"      , "SoftCam"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("  Plugins"      , "PluginsTools" ))
  VVw8eP.append(("  Terminal"      , "Terminal"  ))
  VVw8eP.append(("  Backup & Restore"    , "BackupRestore" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("  Date/Time"      , "Date_Time"  ))
  VVw8eP.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVw8eP)
  FFSF9U(self, VVw8eP=VVw8eP)
  FFw7jX(self["keyRed"] , "Exit")
  FFw7jX(self["keyGreen"] , "Settings")
  FFw7jX(self["keyYellow"], "Dev. Info.")
  FFw7jX(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVDt8j       ,
   "yellow"  : self.VVWzHJ       ,
   "blue"   : self.VVCkKv       ,
   "info"   : self.VVCkKv       ,
   "last"   : self.VVDw5b      ,
   "next"   : self.VV2dEU       ,
   "menu"   : self.VVtc2i     ,
   "0"    : boundFunction(self.VVgeJA, 0) ,
   "1"    : boundFunction(self.VVZSWM, 1)   ,
   "2"    : boundFunction(self.VVZSWM, 2)   ,
   "3"    : boundFunction(self.VVZSWM, 3)   ,
   "4"    : boundFunction(self.VVZSWM, 4)   ,
   "5"    : boundFunction(self.VVZSWM, 5)   ,
   "6"    : boundFunction(self.VVZSWM, 6)   ,
   "7"    : boundFunction(self.VVZSWM, 7)   ,
   "8"    : boundFunction(self.VVZSWM, 8)   ,
   "9"    : boundFunction(self.VVZSWM, 9)
  })
  self.onShown.append(self.VVscXX)
  self.onClose.append(self.onExit)
  global VV5ZBQ, VVWfYG, VVjdSQ
  VV5ZBQ = VVWfYG = VVjdSQ = False
 def VVhKHG(self):
  item = FFPRHj(self)
  self.VVZSWM(item)
 def VVZSWM(self, item):
  if item is not None:
   if   item == "myTest"     : self.VV4BRU()
   elif item in ("FileManager"  , 1) : self.session.open(CCWnyZ)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCUJnZ)
   elif item in ("IptvTools"  , 3) : self.session.open(CCNqVt)
   elif item in ("PIconsTools"  , 4) : self.VVCBq6()
   elif item in ("SoftCam"   , 5) : self.session.open(CCec5Y)
   elif item in ("PluginsTools" , 6) : self.session.open(CCZOdM)
   elif item in ("Terminal"  , 7) : self.session.open(CC7tIZ)
   elif item in ("BackupRestore" , 8) : self.session.open(CCTQIh)
   elif item in ("Date_Time"  , 9) : self.session.open(CCIdMG)
   elif item in ("CheckInternet" , 10) : self.session.open(CCkgBk)
   else         : self.close()
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
  FFEgCR(self)
  title = "  %s - %s" % (PLUGIN_NAME, VV96cs)
  self["myTitle"].setText(title)
  VV6g3V, VVTVPz, VV30pe, VVeg1k, VVwhRo, oldIptvHostsPath, oldMovieDownloadPath = FFwRBd()
  self.VVGYeS()
  if VV6g3V or VVTVPz or VV30pe or VVeg1k or VVwhRo or oldIptvHostsPath or oldMovieDownloadPath:
   VVtmK4 = lambda path, subj: "%s:\n%s\n\n" % (subj, FFkGYB(path, VVFT40)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVtmK4(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVtmK4(VV6g3V   , "Backup/Restore Path"    )
   txt += VVtmK4(VVTVPz  , "Created Package Files (IPK/DEB)" )
   txt += VVtmK4(VV30pe  , "Download Packages (from feeds)" )
   txt += VVtmK4(VVeg1k , "Exported Tables"     )
   txt += VVtmK4(VVwhRo , "Exported PIcons"     )
   txt += VVtmK4(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFVxvP(self, txt, title="Settings Paths")
  if (EASY_MODE or VVXDdI or VVknG2):
   FFtJEw(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF4n96(self, "Welcome", 300)
  FFlxSW(boundFunction(self.VVON74, title))
 def VVON74(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCFOfb.VVExh4()
   if url:
    newWebVer = CCFOfb.VVSTiY(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFK72g("rm /tmp/ajpanel*"))
  global VV5ZBQ, VVWfYG, VVjdSQ
  VV5ZBQ = VVWfYG = VVjdSQ = False
 def VVgeJA(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VV5ZBQ, VVjdSQ
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VV5ZBQ = True
    FFtJEw(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVjdSQ = True
 def VV2dEU(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVWfYG
   VVWfYG = True
   FFtJEw(self["myTitle"], "#dd5588")
 def VVDw5b(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FF4n96(self, txt, 2000, isGrn=ok)
 def VVCBq6(self):
  found = False
  pPath = CCvG1x.VVulgY()
  if pathExists(pPath):
   for fName, fType in CCvG1x.VV2BGS(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCvG1x)
  else:
   VVw8eP = []
   VVw8eP.append(("PIcons Manager" , "CCvG1x" ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(CCvG1x.VV4P4T())
   VVw8eP.append(VV9e5C)
   VVw8eP += CCvG1x.VVZ3mw()
   FF7Bt5(self, self.VV6pOa, VVw8eP=VVw8eP)
 def VV6pOa(self, item=None):
  if item:
   if   item == "CCvG1x"   : self.session.open(CCvG1x)
   elif item == "VVThyJ"  : CCvG1x.VVThyJ(self)
   elif item == "VVo46b"  : CCvG1x.VVo46b(self)
   elif item == "findPiconBrokenSymLinks" : CCvG1x.VVFDyp(self, True)
   elif item == "FindAllBrokenSymLinks" : CCvG1x.VVFDyp(self, False)
 def VVDt8j(self):
  self.session.open(CCFOfb)
 def VVWzHJ(self):
  self.session.open(CC9zVf)
 def VVCkKv(self):
  changeLogFile = VVAwa9 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFg2eB(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFkGYB("\n%s\n%s\n%s" % (VVS5oR, line, VVS5oR), VVtUnE, VVB0Ol)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFkGYB(line, VVLchc, VVB0Ol)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFVxvP(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VV96cs), VVjgTX=26)
 def VVtc2i(self):
  VVw8eP = []
  VVw8eP.append(("Title Colors"   , "title" ))
  VVw8eP.append(("Menu Area Colors"  , "body" ))
  VVw8eP.append(("Menu Pointer Colors" , "cursor" ))
  VVw8eP.append(("Bottom Bar Colors" , "bar"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FF7Bt5(self, boundFunction(self.VVG1wy, title), VVw8eP=VVw8eP, width=500, title=title)
 def VVG1wy(self, title, item=None):
  if item:
   if item == "reset":
    FFfK5z(self, self.VVH5aq, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV32xH()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VV8kie, tDict, item), CC9lYb, defFG=fg, defBG=bg)
 def VVGBn1(self):
  return VVvHG2 + "ajpanel_colors"
 def VV32xH(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVGBn1()
  if fileExists(p):
   txt = FFzVLg(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VV8kie(self, tDict, item, fg, bg):
  if fg:
   self.VVNXJm(item, fg)
   self.VVnA95(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVLKnU(tDict)
 def VVLKnU(self, tDict):
   p = self.VVGBn1()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVNXJm(self, item, fg):
  if   item == "title" : FFLdCa(self["myTitle"], fg)
  elif item == "body"  :
   FFLdCa(self["myMenu"], fg)
   FFLdCa(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFtJEw(self["myBar"], fg)
   FFLdCa(self["keyRed"], fg)
   FFLdCa(self["keyGreen"], fg)
   FFLdCa(self["keyYellow"], fg)
   FFLdCa(self["keyBlue"], fg)
 def VVnA95(self, item, bg):
  if   item == "title" : FFtJEw(self["myTitle"], bg)
  elif item == "body"  :
   FFtJEw(self["myMenu"], bg)
   FFtJEw(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFtJEw(self["myBar"], bg)
 def VVH5aq(self):
  os.system(FFK72g("rm %s" % self.VVGBn1()))
  self.close()
 def VVGYeS(self):
  tDict = self.VV32xH()
  self.VV8LaD(tDict, "title")
  self.VV8LaD(tDict, "body")
  self.VV8LaD(tDict, "cursor")
  self.VV8LaD(tDict, "bar")
 def VV8LaD(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVNXJm(name, fg)
  if bg: self.VVnA95(name, bg)
 def VV4BRU(self):
  FFYawX(self)
class CC9zVf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVw8eP = []
  VVw8eP.append(("Settings File"        , "SettingsFile"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Box Info"          , "VVQ1IJ"    ))
  VVw8eP.append(("Tuners Info"         , "VVwj13"   ))
  VVw8eP.append(("Python Version"        , "VVk3L0"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Screen Size"         , "ScreenSize"    ))
  VVw8eP.append(("Locale"          , "Locale"     ))
  VVw8eP.append(("Processor"         , "Processor"    ))
  VVw8eP.append(("Operating System"        , "OperatingSystem"   ))
  VVw8eP.append(("Drivers"          , "drivers"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("System Users"         , "SystemUsers"    ))
  VVw8eP.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVw8eP.append(("Uptime"          , "Uptime"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Host Name"         , "HostName"    ))
  VVw8eP.append(("MAC Address"         , "MACAddress"    ))
  VVw8eP.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVw8eP.append(("Network Status"        , "NetworkStatus"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Disk Usage"         , "VV4y8P"    ))
  VVw8eP.append(("Mount Points"         , "MountPoints"    ))
  VVw8eP.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVw8eP.append(("USB Devices"         , "USB_Devices"    ))
  VVw8eP.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVw8eP.append(("Directory Size"        , "DirectorySize"   ))
  VVw8eP.append(("Memory"          , "Memory"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVw8eP.append(("Running Processes"       , "RunningProcesses"  ))
  VVw8eP.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFSF9U(self, VVw8eP=VVw8eP, title="Device Information")
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCwS2K)
   elif item == "VVQ1IJ"    : self.VVQ1IJ()
   elif item == "VVwj13"   : self.VVwj13()
   elif item == "VVk3L0"   : self.VVk3L0()
   elif item == "ScreenSize"    : FFVxvP(self, "Width\t: %s\nHeight\t: %s" % (FFAghz()[0], FFAghz()[1]))
   elif item == "Locale"     : self.VVWlLA()
   elif item == "Processor"    : self.VVwR0e()
   elif item == "OperatingSystem"   : FFelLa(self, "uname -a"        )
   elif item == "drivers"     : self.VV4GGT()
   elif item == "SystemUsers"    : FFelLa(self, "id"          )
   elif item == "LoggedInUsers"   : FFelLa(self, "who -a"         )
   elif item == "Uptime"     : FFelLa(self, "uptime"         )
   elif item == "HostName"     : FFelLa(self, "hostname"        )
   elif item == "MACAddress"    : self.VV8cf3()
   elif item == "NetworkConfiguration"  : FFelLa(self, "ifconfig %s %s" % (FF6sH0("HWaddr", VV0cUe), FF6sH0("addr:", VVYPWI)))
   elif item == "NetworkStatus"   : FFelLa(self, "netstat -tulpn"       )
   elif item == "VV4y8P"    : self.VV4y8P()
   elif item == "MountPoints"    : FFelLa(self, "mount %s" % (FF6sH0(" on ", VVYPWI)))
   elif item == "FileSystemTable"   : FFelLa(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFelLa(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFelLa(self, "blkid"         )
   elif item == "DirectorySize"   : FFelLa(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVjkt0="Reading size ...")
   elif item == "Memory"     : FFelLa(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVT8Yn()
   elif item == "RunningProcesses"   : FFelLa(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFelLa(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVvpca()
   else         : self.close()
 def VV8cf3(self):
  res = FF9r0n("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFVxvP(self, txt)
  else:
   FFelLa(self, "ip link")
 def VVlvYL(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFgPQo(cmd)
  return lines
 def VVzRNZ(self, lines, headerRepl, widths, VVSgvw):
  VV5w32 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV5w32.append(parts)
  if VV5w32 and len(header) == len(widths):
   VV5w32.sort(key=lambda x: x[0].lower())
   FFS01Q(self, None, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=28, VVHESo=True)
   return True
  else:
   return False
 def VV4y8P(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVlvYL(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVSgvw = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVzRNZ(lines, headerRepl, widths, VVSgvw)
  if not allOK:
   lines = FFgPQo(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFh7YC(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVfxXg:
     note = "\n%s" % FFkGYB("Green = Mounted Partitions", VVfxXg)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVYPWI
     elif line.endswith(mountList) : color = VVfxXg
     else       : color = VVLchc
     txt += FFkGYB(line, color) + "\n"
    FFVxvP(self, txt + note)
   else:
    FFc88f(self, "Not data from system !")
 def VVT8Yn(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVlvYL(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVSgvw = (LEFT , CENTER, LEFT )
  allOK = self.VVzRNZ(lines, headerRepl, widths, VVSgvw)
  if not allOK:
   FFelLa(self, cmd)
 def VVWlLA(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFVxvP(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VV4GGT(self):
  cmd = FFZsGt(VVryhT, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFelLa(self, cmd)
  else : FFdCT7(self)
 def VVwR0e(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFelLa(self, cmd)
 def VVvpca(self):
  cmd = FFZsGt(VVUOoZ, "| grep secondstage")
  if cmd : FFelLa(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFdCT7(self)
 def VVQ1IJ(self):
  c = VVfxXg
  VVNz0H = []
  VVNz0H.append((FFkGYB("Box Type"  , c), FFkGYB(self.VVg82d("boxtype").upper(), c)))
  VVNz0H.append((FFkGYB("Board Version", c), FFkGYB(self.VVg82d("board_revision") , c)))
  VVNz0H.append((FFkGYB("Chipset"  , c), FFkGYB(self.VVg82d("chipset")  , c)))
  VVNz0H.append((FFkGYB("S/N"   , c), FFkGYB(self.VVg82d("sn")    , c)))
  VVNz0H.append((FFkGYB("Version"  , c), FFkGYB(self.VVg82d("version")  , c)))
  VVGE9b   = []
  VVtrX3 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVtrX3 = SystemInfo[key]
     else:
      VVGE9b.append((FFkGYB(str(key), VVy6YC), FFkGYB(str(SystemInfo[key]), VVy6YC)))
  except:
   pass
  if VVtrX3:
   VVy7x6 = self.VVKTrw(VVtrX3)
   if VVy7x6:
    VVy7x6.sort(key=lambda x: x[0].lower())
    VVNz0H += VVy7x6
  if VVGE9b:
   VVGE9b.sort(key=lambda x: x[0].lower())
   VVNz0H += VVGE9b
  if VVNz0H:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFS01Q(self, None, header=header, VVNz0H=VVNz0H, VVTy8n=widths, VVjgTX=28, VVHESo=True)
  else:
   FFVxvP(self, "Could not read info!")
 def VVg82d(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFg2eB(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVKTrw(self, mbDict):
  try:
   mbList = list(mbDict)
   VVNz0H = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVNz0H.append((FFkGYB(subject, VVYPWI), FFkGYB(value, VVYPWI)))
  except:
   pass
  return VVNz0H
 def VVwj13(self):
  txt = self.VVQIYJ("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVQIYJ("/proc/bus/nim_sockets")
  if not txt: txt = self.VVJ77d()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFVxvP(self, txt)
 def VVJ77d(self):
  txt = ""
  VVtmK4 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVtmK4("Slot Name" , slot.getSlotName())
     txt += FFkGYB(slotName, VVYPWI)
     txt += VVtmK4("Description"  , slot.getFullDescription())
     txt += VVtmK4("Frontend ID"  , slot.frontend_id)
     txt += VVtmK4("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVQIYJ(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFg2eB(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFkGYB(line, VVYPWI)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVk3L0(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFVxvP(self, txt)
class CCwS2K(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVw8eP = []
  VVw8eP.append(("Settings (All)"   , "Settings_All"   ))
  VVw8eP.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVWfYG:
   VVw8eP.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVw8eP.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVw8eP.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVw8eP.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVw8eP.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVw8eP.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFSF9U(self, VVw8eP=VVw8eP)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFelLa(self, cmd                )
   elif item == "Settings_HotKeys"   : FFelLa(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFelLa(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFelLa(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFelLa(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFelLa(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFelLa(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFelLa(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCec5Y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVlMOw, VVzn1Y, VVaTxy, camCommand = FFlLsd()
  self.VVzn1Y = VVzn1Y
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVw8eP = []
  VVw8eP.append(("OSCam Files"        , "OSCamFiles"  ))
  VVw8eP.append(("NCam Files"        , "NCamFiles"  ))
  VVw8eP.append(("CCcam Files"        , "CCcamFiles"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVw8eP.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVw8eP.append(VV9e5C)
  if VVzn1Y:
   if   "oscam" in VVzn1Y : camName = "OSCam"
   elif "ncam"  in VVzn1Y : camName = "NCam"
   VVw8eP.append((camName + " Info."      , "camInfo"   ))
   VVw8eP.append((camName + " Live Status"    , "camLiveStatus" ))
   VVw8eP.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVw8eP.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVw8eP.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFSF9U(self, VVw8eP=VVw8eP)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CC2JF6, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CC2JF6, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CC2JF6, "cccam"))
   elif item == "OSCamReaders"  : self.VV7ybq("os")
   elif item == "NSCamReaders"  : self.VV7ybq("n")
   elif item == "camInfo"   : FFy1CT(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFqhrZ(self.session, CCC73f.VVTQSE)
   elif item == "camLiveReaders" : FFqhrZ(self.session, CCC73f.VVwm5N)
   elif item == "camLiveLog"  : FFqhrZ(self.session, CCC73f.VVaPMq)
   else       : self.close()
 def VV7ybq(self, camPrefix):
  VV5w32 = self.VV2Ny1(camPrefix)
  if VV5w32:
   VV5w32.sort(key=lambda x: int(x[0]))
   if self.VVzn1Y and self.VVzn1Y.startswith(camPrefix):
    VVicyB = ("Toggle State", self.VVucpN, [camPrefix], "Changing State ...")
   else:
    VVicyB = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVSgvw  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFS01Q(self, None, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VVicyB=VVicyB, VVjrzO=True)
 def VV2Ny1(self, camPrefix):
  readersFile = self.VVlMOw + camPrefix + "cam.server"
  VV5w32 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFg2eB(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV5w32.append((str(len(VV5w32) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV5w32:
    FFc88f(self, "No readers found !")
  else:
   FFOr2O(self, readersFile)
  return VV5w32
 def VVucpN(self, VVDhXw, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVlMOw, camPrefix)
  readerState  = VVDhXw.VVLIgd(1)
  readerLabel  = VVDhXw.VVLIgd(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCec5Y.VV0TZh(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVDhXw.VVdfHL()
    FFc88f(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV5w32 = self.VV2Ny1(camPrefix)
   if VV5w32:
    VVDhXw.VVC9qg(VV5w32)
 @staticmethod
 def VV0TZh(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFg2eB(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFc88f(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFc88f(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFOr2O(SELF, confFile)
   return None
  if not iRequest:
   FFc88f(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFc88f(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFc88f(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CC2JF6(Screen):
 def __init__(self, VVcm8D, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVlMOw, VVzn1Y, VVaTxy, camCommand = FFlLsd()
  if   VVcm8D == "ncam" : self.prefix = "n"
  elif VVcm8D == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVw8eP = []
  if self.prefix == "":
   VVw8eP.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVw8eP.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVw8eP.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVw8eP.append(("constant.cw"         , "x_constant_cw" ))
   VVw8eP.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVw8eP.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVw8eP.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVw8eP.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVw8eP.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVw8eP.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVw8eP.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVw8eP.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVw8eP.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVw8eP.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVw8eP.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFSF9U(self, VVw8eP=VVw8eP)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFTDoH(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFTDoH(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFTDoH(self, self.VVlMOw + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFTDoH(self, self.VVlMOw + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVcMt1("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVcMt1("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVcMt1("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVcMt1("cam.provid"        )
   elif item == "x_cam_server"  : self.VVcMt1("cam.server"        )
   elif item == "x_cam_services" : self.VVcMt1("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVcMt1("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVcMt1("cam.user"        )
   elif item == "x_VVS5oR"   : pass
   elif item == "x_SoftCam_Key" : FFTDoH(self, self.VVlMOw + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFTDoH(self, self.VVlMOw + "CCcam.cfg"    )
   elif item == "x_VVS5oR"   : pass
   elif item == "x_cam_log"  : FFTDoH(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFTDoH(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFTDoH(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVcMt1(self, fileName):
  FFTDoH(self, self.VVlMOw + self.prefix + fileName)
class CCC73f(Screen):
 VVTQSE  = 0
 VVwm5N = 1
 VVaPMq = 2
 def __init__(self, session, VVlMOw="", VVzn1Y="", VVaTxy="", VVJ1Ve=VVTQSE):
  self.skin, self.skinParam = FFAEOm(VVI14G, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVaTxy   = VVaTxy
  self.VVJ1Ve  = VVJ1Ve
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVlMOw + VVzn1Y + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVzn1Y : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVlMOw, self.camPrefix)
  if self.VVJ1Ve == self.VVTQSE:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVJ1Ve == self.VVwm5N:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFSF9U(self, self.Title, addScrollLabel=True)
  FFw7jX(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVaJOo
  self.onShown.append(self.VVscXX)
  self.onClose.append(self.onExit)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self["myLabel"].VVe9VI(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFEgCR(self)
  self.VVaJOo()
 def onExit(self):
  self.timer.stop()
 def VV7uHD(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVF3vN)
  except:
   self.timer.callback.append(self.VVF3vN)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF4n96(self, "Started", 1000)
 def VVmzxM(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVF3vN)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF4n96(self, "Stopped", 1000)
 def VVaJOo(self):
  if self.timerRunning:
   self.VVmzxM()
  else:
   self.VV7uHD()
   if self.VVJ1Ve == self.VVTQSE or self.VVJ1Ve == self.VVwm5N:
    if self.VVJ1Ve == self.VVTQSE : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCec5Y.VV0TZh(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFlxSW(self.VVhJjW)
    else:
     self.close()
   else:
    self.VVzcN0()
 def VVF3vN(self):
  if self.timerRunning:
   if   self.VVJ1Ve == self.VVTQSE : self.VVW9Vt()
   elif self.VVJ1Ve == self.VVwm5N : self.VVW9Vt()
   else            : self.VVzcN0()
 def VVzcN0(self):
  if fileExists(self.VVaTxy):
   fTime = FF7tZn(os.path.getmtime(self.VVaTxy))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVl1Ta(), VVMBud=VVpkLV)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVaTxy)
 def VVhJjW(self):
  self.VVW9Vt()
 def VVW9Vt(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFkGYB("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVtUnE))
   self.camWebIfErrorFound = True
   self.VVmzxM()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVJ1Ve == self.VVTQSE : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFkGYB("Error while parsing data elements !\n\nError = %s" % str(e), VVFT40)
   self.camWebIfErrorFound = True
   self.VVmzxM()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVvOXx(root)
  self["myLabel"].setText(txt, VVMBud=VVpkLV)
  self["myBar"].setText("Last Update : %s" % FFe93I())
 def VVvOXx(self, rootElement):
  def VVtmK4(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVJ1Ve == self.VVTQSE:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFkGYB(status, VVfxXg)
    else          : status = FFkGYB(status, VVFT40)
    txt += VVS5oR + "\n"
    txt += VVtmK4("Name"  , name)
    txt += VVtmK4("Description" , desc)
    txt += VVtmK4("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVtmK4("Protocol" , protocol)
    txt += VVtmK4("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFkGYB("Yes", VVfxXg)
    else    : enabTxt = FFkGYB("No", VVFT40)
    txt += VVS5oR + "\n"
    txt += VVtmK4("Label"  , label)
    txt += VVtmK4("Protocol" , protocol)
    txt += VVtmK4("Enabled" , enabTxt)
  return txt
 def VVl1Ta(self):
  wordsDict = self.VVZHYN()
  color = [ VVYPWI, VV0cUe, VVfxXg, VVFT40, VVy6YC, VVzCLY]
  lines = FFgPQo("tail -n %d %s" % (100, self.VVaTxy))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVtUnE + line[:19] + VVLchc + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVB0Ol + line[ndx + 3:] + VVLchc
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVYPWI + line[ndx + 8 : ndx1 + 4] + VVLchc + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVLchc)
   elif line.startswith("----") or ">>" in line:
    line = FFkGYB(line, VVYPWI)
   txt += line + "\n"
  return txt
 def VVZHYN(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFg2eB(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCTQIh(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVw8eP = []
  VVw8eP.append(("Backup Channels"    , "VVtWuw"   ))
  VVw8eP.append(("Restore Channels"    , "Restore_Channels"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Backup SoftCAM Files"   , "VVBNih" ))
  VVw8eP.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVw8eP.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVw8eP.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Backup Network Settings"  , "VVC1cp"   ))
  VVw8eP.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVWfYG:
   VVw8eP.append(VV9e5C)
   VVw8eP.append((VVtUnE + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVJHzg"   ))
   VVw8eP.append((VVfxXg + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVcPf3) , "createMyIpk"   ))
   VVw8eP.append((VVfxXg + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVcPf3) , "createMyDeb"   ))
   VVw8eP.append((VVy6YC + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVw8eP.append((VVy6YC + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVkryH" ))
  FFSF9U(self, VVw8eP=VVw8eP)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVtWuw"    : self.VVtWuw()
   elif item == "Restore_Channels"    : self.VVi6XN("channels_backup*.tar.gz", self.VVm3WJ)
   elif item == "VVBNih"   : self.VVBNih()
   elif item == "Restore_SoftCAM_Files"  : self.VVi6XN("softcam_backup*.tar.gz", self.VVvCGX)
   elif item == "Backup_TunerDiSEqC"   : self.VVA726("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVi6XN("tuner_backup*.backup", boundFunction(self.VVnW4d, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVA726("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVi6XN("hotkey_*backup*.backup", boundFunction(self.VVnW4d, "misc"))
   elif item == "VVC1cp"    : self.VVC1cp()
   elif item == "Restore_Network"    : self.VVi6XN("network_backup*.tar.gz", self.VV1aN2)
   elif item == "VVJHzg"     : FFfK5z(self, boundFunction(FFKl3w, self, boundFunction(CCTQIh.VVJHzg, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVNGyL(False)
   elif item == "createMyDeb"     : self.VVNGyL(True)
   elif item == "createMyTar"     : self.VV2YNH()
   elif item == "VVkryH"   : self.VVkryH()
 @staticmethod
 def VVJHzg(SELF):
  OBF_Path = VVTTSd + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVTTSd, VV96cs, VVcPf3)
   if err : FFc88f(SELF, err)
   else : FFVxvP(SELF, txt)
  else:
   FFOr2O(SELF, OBF_Path)
 def VVNGyL(self, VViYVL):
  OBF_Path = VVTTSd + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFc88f(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVTTSd)
  os.system("mv -f %s %s" % (VVTTSd + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVTTSd + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVTTSd + "plugin.py"))
  self.session.openWithCallback(self.VVNGyL1, boundFunction(CCMmad, path=VVTTSd, VViYVL=VViYVL))
 def VVNGyL1(self):
  os.system("mv -f %s %s" % (VVTTSd + "OBF/main.py"  , VVTTSd))
  os.system("mv -f %s %s" % (VVTTSd + "OBF/plugin.py" , VVTTSd))
 def VVkryH(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFc88f(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFc88f(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VV7tnb("%s*.list" % path)
  if err:
   FFOr2O(self, path + "*.list")
   return
  srcF, err = self.VV7tnb("%s*main_final.py" % path)
  if err:
   FFOr2O(self, path + "*.final.py")
   return
  VVNz0H = []
  for f in files:
   f = os.path.basename(f)
   VVNz0H.append((f, f))
  FF7Bt5(self, boundFunction(self.VVHDnM, path, codF, srcF), VVw8eP=VVNz0H)
 def VVHDnM(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFOr2O(self, logF)
   else     : FFKl3w(self, boundFunction(self.VV8yzT, logF, codF, srcF))
 def VV8yzT(self, logF, codF, srcF):
  lst  = []
  lines = FFg2eB(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFc88f(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVjVAq(lst, logF, newLogF)
  totSrc  = self.VVjVAq(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFVxvP(self, txt)
 def VV7tnb(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVjVAq(self, lst, f1, f2):
  txt = FFzVLg(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VV2YNH(self):
  VVNz0H = []
  VVNz0H.append("%s%s" % (VVTTSd, "*.py"))
  VVNz0H.append("%s%s" % (VVTTSd, "*.png"))
  VVNz0H.append("%s%s" % (VVTTSd, "*.xml"))
  VVNz0H.append("%s"  % (VVAwa9))
  FF0zXt(self, VVNz0H, "%s_%s" % (PLUGIN_NAME, VV96cs), addTimeStamp=False)
 def VVtWuw(self):
  path1 = VV9m85
  path2 = "/etc/tuxbox/"
  VVNz0H = []
  VVNz0H.append("%s%s" % (path1, "*.tv"))
  VVNz0H.append("%s%s" % (path1, "*.radio"))
  VVNz0H.append("%s%s" % (path1, "*list"))
  VVNz0H.append("%s%s" % (path1, "lamedb*"))
  VVNz0H.append("%s%s" % (path2, "*.xml"))
  FF0zXt(self, VVNz0H, "channels_backup", addTimeStamp=True)
 def VVBNih(self):
  VVNz0H = []
  VVNz0H.append("/etc/tuxbox/config/")
  VVNz0H.append("/usr/keys/")
  VVNz0H.append("/usr/scam/")
  VVNz0H.append("/etc/CCcam.cfg")
  FF0zXt(self, VVNz0H, "softcam_backup", addTimeStamp=True)
 def VVC1cp(self):
  VVNz0H = []
  VVNz0H.append("/etc/hostname")
  VVNz0H.append("/etc/default_gw")
  VVNz0H.append("/etc/resolv.conf")
  VVNz0H.append("/etc/wpa_supplicant*.conf")
  VVNz0H.append("/etc/network/interfaces")
  VVNz0H.append("/etc/enigma2/nameserversdns.conf")
  FF0zXt(self, VVNz0H, "network_backup", addTimeStamp=True)
 def VVm3WJ(self, fileName):
  if fileName:
   FFfK5z(self, boundFunction(self.VVW9uz, fileName), "Overwrite current channels ?")
 def VVW9uz(self, fileName):
  path = "%s%s" % (VVvHG2, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCUJnZ.VVBtQQ()
   lamedb5File, diabled5File = CCUJnZ.VVyh5K()
   cmd = ""
   cmd += FFK72g("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFK72g("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFikPN()
   if res == 0 : FF1ATN(self, "Channels Restored.")
   else  : FFc88f(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFOr2O(self, path)
 def VVvCGX(self, fileName):
  if fileName:
   FFfK5z(self, boundFunction(self.VVH6ex, fileName), "Overwrite SoftCAM files ?")
 def VVH6ex(self, fileName):
  fileName = "%s%s" % (VVvHG2, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVS5oR
   note = "You may need to restart your SoftCAM."
   FF34xz(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF6sH0(note, VVYPWI), sep))
  else:
   FFOr2O(self, fileName)
 def VV1aN2(self, fileName):
  if fileName:
   FFfK5z(self, boundFunction(self.VV5Mzl, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV5Mzl(self, fileName):
  fileName = "%s%s" % (VVvHG2, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFypV6(self,  cmd)
  else:
   FFOr2O(self, fileName)
 def VVi6XN(self, pattern, callBackFunction, isTuner=False):
  title = FFSUtV()
  if pathExists(VVvHG2):
   myFiles = iGlob("%s%s" % (VVvHG2, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVNz0H = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVNz0H.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVvKTv = ("Sat. List", self.VVeAji)
    else  : VVvKTv = None
    VVjOnb = ("Delete File", boundFunction(self.VVAzE9, boundFunction(self.VVi6XN, pattern, callBackFunction, isTuner)))
    FF7Bt5(self, callBackFunction, title=title, VVw8eP=VVNz0H, VVvKTv=VVvKTv, VVjOnb=VVjOnb)
   else:
    FFc88f(self, "No files found in:\n\n%s" % VVvHG2, title)
  else:
   FFc88f(self, "Path not found:\n\n%s" % VVvHG2, title)
 def VVAzE9(self, cbFnc, VVWZQiObj, path):
  FFfK5z(self, boundFunction(self.VV1Ays, cbFnc, VVWZQiObj, path), "Delete this file ?\n\n%s" % path)
 def VV1Ays(self, cbFnc, VVWZQiObj, path):
  os.system(FFK72g("rm -f '%s%s'" % (VVvHG2, path)))
  cbFnc()
  VVWZQiObj.cancel()
 def VVA726(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCPn4h()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VV4vNE, filePrefix))
 def VV4vNE(self, filePrefix, result, retval):
  title = FFSUtV()
  if pathExists(VVvHG2):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFc88f(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVvHG2, filePrefix, FFnEIN())
    try:
     VVNz0H = str(result.strip()).split()
     if VVNz0H:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVNz0H:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVS5oR, FFkGYB(fName, VVYPWI), VVS5oR)
       FFVxvP(self, txt, title=title, VVMBud=VVpkLV)
      else:
       FFc88f(self, "File creation failed!", title)
     else:
      FFc88f(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFK72g("rm %s" % fName))
     FFc88f(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFK72g("rm %s" % fName))
     FFc88f(self, "Error while writing file.")
  else:
   FFc88f(self, "Path not found:\n\n%s" % VVvHG2, title)
 def VVnW4d(self, mode, path):
  if path:
   path = "%s%s" % (VVvHG2, path)
   if fileExists(path):
    lines = FFg2eB(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFfK5z(self, boundFunction(self.VVsmzT, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFfN7q(self, path, title=FFSUtV())
   else:
    FFOr2O(self, path)
 def VVsmzT(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVA6hv = []
  VVA6hv.append("echo -e 'Reading current settings ...'")
  VVA6hv.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVA6hv.append("echo -e 'Preparing new settings ...'")
  VVA6hv.append(settingsLines)
  VVA6hv.append("echo -e 'Applying new settings ...'")
  VVA6hv.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FF1obA(self, VVA6hv)
 def VVeAji(self, VVWZQiObj, path):
  if not path:
   return
  path = VVvHG2 + path
  if not fileExists(path):
   FFOr2O(self, path)
   return
  txt = FFzVLg(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVNz0H  = []
   for item in satList:
    VVNz0H.append("%s\t%s" % (item[0], FF9joe(item[1])))
   FFVxvP(self, VVNz0H, title="  Satellites List")
  else:
   FFc88f(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCZOdM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEShK, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVw8eP = []
  VVw8eP.append(("Plugins Browser List"       , "VVI0x2"   ))
  VVw8eP.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVw8eP.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVw8eP.append(("Remove Packages (show all)"     , "VVI4ozsAll"   ))
  VVw8eP.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Update List of Available Packages"   , "VVmISK"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Packaging Tool"        , "VVtzwN"    ))
  VVw8eP.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFSF9U(self, VVw8eP=VVw8eP)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVI0x2"   : self.VVI0x2()
   elif item == "pluginsMenus"     : self.VV2ITY(0)
   elif item == "pluginsStartup"    : self.VV2ITY(1)
   elif item == "pluginsDirList"    : self.VVaA9n()
   elif item == "downloadInstallPackages"  : FFKl3w(self, boundFunction(self.VVvMol, 0, ""))
   elif item == "VVI4ozsAll"   : FFKl3w(self, boundFunction(self.VVvMol, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFKl3w(self, boundFunction(self.VVvMol, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVmISK"   : self.VVmISK()
   elif item == "VVtzwN"    : self.VVtzwN()
   elif item == "packagesFeeds"    : self.VVXxb2()
   else          : self.close()
 def VVaA9n(self):
  extDirs  = FFaVZl(VVbBic)
  sysDirs  = FFaVZl(VVm7l9)
  VVNz0H  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVNz0H.append((item, VVbBic + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVNz0H.append((item, VVm7l9 + item))
  if VVNz0H:
   VVNz0H = sorted(VVNz0H, key=lambda x: x[0].lower())
   VV6rfs = ("Package Info.", self.VVUllw, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFS01Q(self, None, header=header, VVNz0H=VVNz0H, VVTy8n=widths, VVjgTX=28, VV6rfs=VV6rfs)
  else:
   FFc88f(self, "Nothing found!")
 def VVUllw(self, VVDhXw, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVbBic) : loc = "extensions"
  elif path.startswith(VVm7l9) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVk4o2(package)
  else:
   FFc88f(self, "No info!")
 def VVXxb2(self):
  pkg = FFFQGA()
  if pkg : FFelLa(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFdCT7(self)
 def VVI0x2(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVtmK4(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVS5oR + "\n"
    txt += VVtmK4("Number"   , str(c))
    txt += VVtmK4("Name"   , FFkGYB(str(p.name), VVYPWI))
    txt += VVtmK4("Path"  , p.path  )
    txt += VVtmK4("Description" , p.description )
    txt += VVtmK4("Icon"  , p.iconstr  )
    txt += VVtmK4("Wakeup Fnc" , p.wakeupfnc )
    txt += VVtmK4("NeedsRestart", p.needsRestart)
    txt += VVtmK4("Internal" , p.internal )
    txt += VVtmK4("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFVxvP(self, txt)
 def VV2ITY(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVNz0H = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVNz0H.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVNz0H:
   VVNz0H.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFS01Q(self, None, title=title, header=header, VVNz0H=VVNz0H, VVTy8n=widths, VVjgTX=26)
  else:
   FFc88f(self, "Nothing Found", title=title)
 def VVmISK(self):
  cmd = FFZsGt(VVcIup, "")
  if cmd : FFypV6(self, cmd, checkNetAccess=True)
  else : FFdCT7(self)
 def VVtzwN(self):
  pkg = FFFQGA()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF1ATN(self, txt)
 def VVvMol(self, mode, grep, VVDhXw=None, title=""):
  if   mode == 0: cmd = FFZsGt(VVUOoZ    , grep)
  elif mode == 1: cmd = FFZsGt(VVryhT , grep)
  elif mode == 2: cmd = FFZsGt(VVryhT , grep)
  if not cmd:
   FFdCT7(self)
   return
  VV5w32 = FFgPQo(cmd)
  if not VV5w32:
   if VVDhXw: VVDhXw.VVdfHL()
   FFc88f(self, "No packages found!")
   return
  elif len(VV5w32) == 1 and VV5w32[0] == VVJ2Pf:
   FFc88f(self, VVJ2Pf)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVNz0H  = []
  for item in VV5w32:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVNz0H.append((name, package, version))
  if mode > 0:
   extensions = FFgPQo("ls %s -l | grep '^d' | awk '{print $9}'" % VVbBic)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVNz0H:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVNz0H.append((name, VVbBic + item, "-"))
   systemPlugins = FFgPQo("ls %s -l | grep '^d' | awk '{print $9}'" % VVm7l9)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVNz0H:
      if item.lower() == row[0].lower():
       break
     else:
      VVNz0H.append((item, VVm7l9 + item, "-"))
  if not VVNz0H:
   FFc88f(self, "No packages found!")
   return
  if VVDhXw:
   VVNz0H.sort(key=lambda x: x[0].lower())
   VVDhXw.VVC9qg(VVNz0H, title)
  else:
   widths = (20, 50, 30)
   VVicyB = None
   VVtvPm = None
   if mode == 0:
    VVJGeM = ("Install" , self.VVF4OR   , [])
    VVicyB = ("Download" , self.VVhMIr   , [])
    VVtvPm = ("Filter"  , self.VV7W4Z , [])
   elif mode == 1:
    VVJGeM = ("Uninstall", self.VVI4oz, [])
   elif mode == 2:
    VVJGeM = ("Uninstall", self.VVI4oz, [])
    widths= (18, 57, 25)
   VVNz0H = sorted(VVNz0H, key=lambda x: x[0].lower())
   VV6rfs = ("Package Info.", self.VVFu9r, [])
   header   = ("Name" ,"Package" , "Version" )
   FFS01Q(self, None, header=header, VVNz0H=VVNz0H, VVTy8n=widths, VVjgTX=28, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm, VVweEQ=self.lastSelectedRow
     , VVRFto="#22110011", VVHhCo="#22191111", VVYhbt="#22191111", VVOU5Z="#00003030", VVD2dA="#00333333")
 def VVFu9r(self, VVDhXw, title, txt, colList):
  package = colList[1]
  self.VVk4o2(package)
 def VV7W4Z(self, VVDhXw, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVw8eP = []
  VVw8eP.append(("All Packages", "all"))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVw8eP.append(VV9e5C)
  for word in words:
   VVw8eP.append((word, word))
  FF7Bt5(self, boundFunction(self.VVQH2W, VVDhXw), VVw8eP=VVw8eP, title="Select Filter")
 def VVQH2W(self, VVDhXw, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFKl3w(VVDhXw, boundFunction(self.VVvMol, 0, grep, VVDhXw, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVI4oz(self, VVDhXw, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVbBic, VVm7l9)):
   FFfK5z(self, boundFunction(self.VVgXGR, VVDhXw, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVw8eP = []
   VVw8eP.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVw8eP.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVw8eP.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF7Bt5(self, boundFunction(self.VVj9pl, VVDhXw, package), VVw8eP=VVw8eP)
 def VVgXGR(self, VVDhXw, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVuFH5)
  FFypV6(self, cmd, VVpEG3=boundFunction(self.VVS8Mq, VVDhXw))
 def VVj9pl(self, VVDhXw, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVr4M9
   elif item == "remove_ForceRemove"  : cmdOpt = VV8CGQ
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV4urB
   FFfK5z(self, boundFunction(self.VV5sfx, VVDhXw, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV5sfx(self, VVDhXw, package, cmdOpt):
  self.lastSelectedRow = VVDhXw.VVynuF()
  cmd = FFp0JH(cmdOpt, package)
  if cmd : FFypV6(self, cmd, VVpEG3=boundFunction(self.VVS8Mq, VVDhXw))
  else : FFdCT7(self)
 def VVS8Mq(self, VVDhXw):
  VVDhXw.cancel()
  FFSY53()
 def VVF4OR(self, VVDhXw, title, txt, colList):
  package  = colList[1]
  VVw8eP = []
  VVw8eP.append(("Install Package"         , "install_CheckVersion" ))
  VVw8eP.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVw8eP.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVw8eP.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVw8eP.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF7Bt5(self, boundFunction(self.VVbavq, package), VVw8eP=VVw8eP)
 def VVbavq(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVggHo
   elif item == "install_ForceReinstall" : cmdOpt = VV0Gj2
   elif item == "install_ForceOverwrite" : cmdOpt = VVSKZV
   elif item == "install_ForceDowngrade" : cmdOpt = VVyV6h
   elif item == "install_IgnoreDepends" : cmdOpt = VVmetP
   FFfK5z(self, boundFunction(self.VVaufQ, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVaufQ(self, package, cmdOpt):
  cmd = FFp0JH(cmdOpt, package)
  if cmd : FFypV6(self, cmd, VVpEG3=FFSY53, checkNetAccess=True)
  else : FFdCT7(self)
 def VVhMIr(self, VVDhXw, title, txt, colList):
  package  = colList[1]
  FFfK5z(self, boundFunction(self.VVYUji, package), "Download Package ?\n\n%s" % package)
 def VVYUji(self, package):
  if FFyisd():
   cmd = FFp0JH(VVS6fG, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF6sH0(success, VVfxXg))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF6sH0(fail, VVFT40))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFypV6(self, cmd, VVi2Cw=[VVFT40, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFdCT7(self)
  else:
   FFc88f(self, "No internet connection !")
 def VVk4o2(self, package):
  infoCmd  = FFp0JH(VVV9W2, package)
  filesCmd = FFp0JH(VVHJAK, package)
  listInstCmd = FFZsGt(VVryhT, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFEtzo(VVYPWI)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF6sH0(notInst, VVtUnE))
   cmd += "else "
   cmd +=   FFdbLX("System Info", VVYPWI)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFdbLX("Related Files", VVYPWI)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFZust(self, cmd)
  else:
   FFdCT7(self)
class CCUJnZ(Screen):
 VVL30c  = 0
 VVzQXx = 1
 VV0tVB  = 2
 VVxt3R  = 3
 VVqD2E = 4
 VVVYOT = 5
 VVkdIi = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFAEOm(VVEShK, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV1Am8 = None
  self.lastfilterUsed  = None
  VVw8eP = self.VVdKJ3()
  FFSF9U(self, VVw8eP=VVw8eP, title="Services/Channels")
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self["myMenu"].setList(self.VVdKJ3())
  FFAblH(self["myMenu"])
  FFoJNI(self)
 def VVdKJ3(self):
  VVw8eP = []
  VVw8eP.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVw8eP.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVw8eP.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVw8eP.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVw8eP.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVw8eP.append(("Services with PIcons for the System"  , "VVzbIR"     ))
  VVw8eP.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVw8eP.append(VV9e5C)
  lamedbFile, disabledFile = CCUJnZ.VVBtQQ()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVw8eP.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVw8eP.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVw8eP.append(("Reset Parental Control Settings"   , "VVlBrU"    ))
  VVw8eP.append(("Delete Channels with no names"   , "VVtoM8"    ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Reload Channels and Bouquets"    , "VV2pB2"      ))
  return VVw8eP
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFYawX(self)
   elif item == "currentServiceInfo"     : FFgbQa(self, fncMode=CCPltO.VVZJlx)
   elif item == "TranspondersStats"     : FFKl3w(self, self.VVveax     )
   elif item == "lameDB_allChannels_with_refCode"  : FFKl3w(self, self.VV6WFJ )
   elif item == "lameDB_allChannels_with_tranaponder" : FFKl3w(self, self.VVJ9m0)
   elif item == "lameDB_allChannels_with_details"  : FFKl3w(self, self.VVwmcy )
   elif item == "parentalControlChannels"    : FFKl3w(self, self.VVAZf8   )
   elif item == "showHiddenChannels"     : FFKl3w(self, self.VV52yA     )
   elif item == "VVzbIR"     : FFKl3w(self, self.VVYq7p     )
   elif item == "servicesWithMissingPIcons"   : FFKl3w(self, self.VVaZTM   )
   elif item == "enableHiddenChannels"     : self.VVi5Xs(True)
   elif item == "disableHiddenChannels"    : self.VVi5Xs(False)
   elif item == "VVlBrU"    : FFfK5z(self, self.VVlBrU, "Reset and Restart ?" )
   elif item == "VVtoM8"    : FFKl3w(self, self.VVtoM8)
   elif item == "VV2pB2"      : FFKl3w(self, boundFunction(CCUJnZ.VV2pB2, self))
   else            : self.close()
 @staticmethod
 def VV2pB2(SELF):
  FFikPN()
  FF1ATN(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV6WFJ(self):
  self.VV1Am8 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC09mD(self)
  VV5w32 = CCUJnZ.VVBpsi(self, self.VVL30c)
  if VV5w32:
   VV5w32.sort(key=lambda x: x[0].lower())
   VV2zCi  = ("Zap"   , self.VVOQHC     , [])
   VV2kYm = (""    , self.VVw9zH   , [])
   VV6rfs = ("Options"  , self.VV3B7p , [])
   VVicyB = ("Current Service", self.VVDhSx , [])
   VVtvPm = ("Filter"   , self.VV6au8  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVSgvw  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFS01Q(self, None, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm)
 def VVJ9m0(self):
  self.VV1Am8 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC09mD(self)
  VV5w32 = CCUJnZ.VVBpsi(self, self.VVzQXx)
  if VV5w32:
   VV5w32.sort(key=lambda x: x[0].lower())
   VV2zCi  = ("Zap"   , self.VVOQHC      , [])
   VV2kYm = (""    , self.VVw9zH    , [])
   VVicyB = ("Current Service", self.VVDhSx  , [])
   VV6rfs = ("Options"  , self.VVjxmR , [])
   VVtvPm = ("Filter"   , self.VVGS2I  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVSgvw  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFS01Q(self, None, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm)
 def VV3B7p(self, VVDhXw, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCtEJp(self, VVDhXw, 3)
  mSel.VVw2wc(servName, refCode, pcState, hidState)
 def VVjxmR(self, VVDhXw, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCtEJp(self, VVDhXw, 3)
  mSel.VVnlEa(servName, refCode)
 def VV26yO(self, VVDhXw, refCode, isAddToBlackList):
  self.VV1Am8 = None
  self.lastfilterUsed  = None
  VVDhXw.VVjyHB("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFKl3w(self, boundFunction(self.VVD3dC, VVDhXw, refCode))
  else:
   FFOr2O(self, path)
 def VVDyVS(self, VVDhXw, refCode, isHide):
  self.VV1Am8 = None
  self.lastfilterUsed  = None
  VVDhXw.VVjyHB("Changing state ...")
  if FFgVxg(refCode):
   ret = FFOcmO(refCode, isHide)
   if ret : FFKl3w(self, boundFunction(self.VVD3dC, VVDhXw, refCode))
   else : FFc88f(self, "Cannot Hide/Unhide this channel.")
  else:
   FFc88f(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVD3dC(self, VVDhXw, refCode):
  VV5w32 = CCUJnZ.VVBpsi(self, self.VVL30c, VVtuz1=[3, [refCode], False])
  done = False
  if VV5w32:
   data = VV5w32[0]
   if data[3] == refCode:
    done = VVDhXw.VV9aPB(data)
  if not done:
   self.VV1Cjt(VVDhXw, VVDhXw.VV1toc(), self.VVL30c)
  VVDhXw.VVdfHL()
 def VV6au8(self, VVDhXw, title, txt, colList):
  self.filterObj.VVQLQs(1, VVDhXw, 2, boundFunction(self.VVVARF, VVDhXw))
 def VVVARF(self, VVDhXw, item):
  self.VVthAZ(VVDhXw, item, 2, self.VVL30c)
 def VVGS2I(self, VVDhXw, title, txt, colList):
  self.filterObj.VVQLQs(2, VVDhXw, 4, boundFunction(self.VVf0ni, VVDhXw))
 def VVf0ni(self, VVDhXw, item):
  self.VVthAZ(VVDhXw, item, 4, self.VVzQXx)
 def VVT4jG(self, VVDhXw, title, txt, colList):
  self.filterObj.VVQLQs(0, VVDhXw, 4, boundFunction(self.VVRL60, VVDhXw))
 def VVRL60(self, VVDhXw, item):
  self.VVthAZ(VVDhXw, item, 4, self.VV0tVB)
 def VVthAZ(self, VVDhXw, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVDhXw.VVLIgd(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV1Am8 = None
  else:
   words, asPrefix = CC09mD.VVl1Dd(words)
   self.VV1Am8 = [col, words, asPrefix]
  if words: FFKl3w(self, boundFunction(self.VV1Cjt, VVDhXw, title, mode), title="Reading Services ...")
  else : FF4n96(VVDhXw, "Incorrect filter", 2000)
 def VV1Cjt(self, VVDhXw, title, mode):
  VV5w32 = CCUJnZ.VVBpsi(self, mode, VVtuz1=self.VV1Am8, VVtrf6=False)
  if VV5w32:
   VV5w32.sort(key=lambda x: x[0].lower())
   VVDhXw.VVC9qg(VV5w32, title)
  else:
   VVDhXw.VVdfHL()
   FF4n96(VVDhXw, "Not found!", 1500)
 def VVLhJI(self, VVNz0H, VV2zCi=None, VV2kYm=None, VVJGeM=None, VVicyB=None, VV6rfs=None, VVtvPm=None):
  VVicyB = ("Current Service", self.VVDhSx, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVSgvw = (LEFT  , LEFT  , CENTER, LEFT    )
  FFS01Q(self, None, header=header, VVNz0H=VVNz0H, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm)
 def VVDhSx(self, VVDhXw, title, txt, colList):
  self.VVtCma(VVDhXw)
 def VVxgaL(self, VVDhXw, title, txt, colList):
  self.VVtCma(VVDhXw, True)
 def VVtCma(self, VVDhXw, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVDhXw.VV9BEJ(colDict, VVoTpo=True)
   else:
    VVDhXw.VV0DkM(3, refCode, True)
   return
  FFc88f(self, "Colud not read current Reference Code !")
 def VVwmcy(self):
  self.VV1Am8 = None
  self.lastfilterUsed  = None
  self.filterObj   = CC09mD(self)
  VV5w32 = CCUJnZ.VVBpsi(self, self.VV0tVB)
  if VV5w32:
   VV5w32.sort(key=lambda x: x[0].lower())
   VV2kYm = (""    , self.VVkPCn , []      )
   VVicyB = ("Current Service", self.VVxgaL  , []      )
   VVtvPm = ("Filter"   , self.VVT4jG   , [], "Loading Filters ..." )
   VV2zCi  = ("Zap"   , self.VVcUpZ      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVSgvw  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFS01Q(self, None, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VVicyB=VVicyB, VVtvPm=VVtvPm)
 def VVkPCn(self, VVDhXw, title, txt, colList):
  refCode  = self.VVqRPv(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFgbQa(self, fncMode=CCPltO.VVriCP, refCode=refCode, chName=chName, text=txt)
 def VVcUpZ(self, VVDhXw, title, txt, colList):
  refCode = self.VVqRPv(colList)
  FFaA9c(self, refCode)
 def VVOQHC(self, VVDhXw, title, txt, colList):
  FFaA9c(self, colList[3])
 def VVqRPv(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVBpsi(SELF, mode, VVtuz1=None, VVtrf6=True, VV5UFy=True):
  lamedbFile, disabledFile = CCUJnZ.VVBtQQ()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVtuz1:
    filterCol = VVtuz1[0]
    filterWords = VVtuz1[1]
    asPrefix = VVtuz1[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCUJnZ.VVL30c:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFg2eB(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCUJnZ.VVzQXx:
    tp = CCriLw()
   VVO0bf, VVEX0Z = FF8cJh()
   tagFound  = False
   if mode in (CCUJnZ.VVVYOT, CCUJnZ.VVkdIi):
    VV5w32 = {}
   else:
    VV5w32 = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFcRp5(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCUJnZ.VV0tVB:
        if sTypeInt in VVO0bf:
         STYPE = VVEX0Z[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV5w32.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV5w32.append(tRow)
        else:
         VV5w32.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCUJnZ.VVVYOT:
         VV5w32[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCUJnZ.VVkdIi:
         VV5w32[chName] = refCode
        elif mode == CCUJnZ.VVL30c:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV5w32.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV5w32.append(tRow)
         else:
          VV5w32.append(tRow)
        elif mode == CCUJnZ.VVzQXx:
         if sTypeInt in VVO0bf:
          STYPE = VVEX0Z[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVTBFi(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV5w32.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV5w32.append(tRow)
         else:
          VV5w32.append(tRow)
        elif mode == CCUJnZ.VVxt3R:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV5w32.append((chName, chProv, sat, refCode))
        elif mode == CCUJnZ.VVqD2E:
         VV5w32.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV5w32 and VVtrf6:
    FFc88f(SELF, "No services found!")
   return VV5w32
  else:
   if VV5UFy:
    FFOr2O(SELF, lamedbFile)
   return None
 def VVAZf8(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFg2eB(path)
   if lines:
    newRows  = []
    VV5w32 = CCUJnZ.VVBpsi(self, self.VVqD2E)
    if VV5w32:
     lines = set(lines)
     for item in VV5w32:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV5w32 = newRows
      VV5w32.sort(key=lambda x: x[0].lower())
      VV2kYm = ("", self.VVw9zH, [])
      VV2zCi = ("Zap", self.VVOQHC, [])
      self.VVLhJI(VVNz0H=VV5w32, VV2zCi=VV2zCi, VV2kYm=VV2kYm)
     else:
      FFVxvP(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV5w32)))
   else:
    FF1ATN(self, "No active Parental Control services.", FFSUtV())
  else:
   FFOr2O(self, path)
 def VV52yA(self):
  VV5w32 = CCUJnZ.VVBpsi(self, self.VVxt3R)
  if VV5w32:
   VV5w32.sort(key=lambda x: x[0].lower())
   VV2kYm = ("" , self.VVw9zH, [])
   VV2zCi  = ("Zap", self.VVOQHC, [])
   self.VVLhJI(VVNz0H=VV5w32, VV2zCi=VV2zCi, VV2kYm=VV2kYm)
  else:
   FF1ATN(self, "No hidden services.", FFSUtV())
 def VVveax(self):
  totT, totC, totA, totS, totS2, satList = self.VVNogZ()
  txt = FFkGYB("Total Transponders:\n\n", VVy6YC)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFkGYB("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVy6YC)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFARL6(item), satList.count(item))
  FFVxvP(self, txt)
 def VVNogZ(self):
  lamedbFile, disabledFile = CCUJnZ.VVBtQQ()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFOr2O(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVYq7p(self)   : self.VVzbIR(True)
 def VVaZTM(self) : self.VVzbIR(False)
 def VVzbIR(self, isWithPIcons):
  piconsPath = CCvG1x.VVulgY()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCvG1x.VV2BGS(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV5w32 = CCUJnZ.VVBpsi(self, self.VVqD2E)
    if VV5w32:
     channels = []
     for (chName, chProv, sat, refCode) in VV5w32:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFYtZj(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV5w32)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVtmK4(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVtmK4("PIcons Path"  , piconsPath)
     txt += VVtmK4("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVtmK4("Total services" , totalServices)
     txt += VVtmK4("With PIcons"  , totalWithPIcons)
     txt += VVtmK4("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFVxvP(self, txt)
     else:
      VV2kYm     = (""      , self.VVw9zH , [])
      if isWithPIcons : VVtvPm = ("Export Current PIcon", self.VVDS0x  , [])
      else   : VVtvPm = None
      VV6rfs     = ("Statistics", FFVxvP, [txt])
      VV2zCi      = ("Zap", self.VVOQHC, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVLhJI(VVNz0H=channels, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VV6rfs=VV6rfs, VVtvPm=VVtvPm)
   else:
    FFc88f(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFc88f(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVw9zH(self, VVDhXw, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFgbQa(self, fncMode=CCPltO.VVriCP, refCode=refCode, chName=chName, text=txt)
 def VVDS0x(self, VVDhXw, title, txt, colList):
  png, path = CCvG1x.VVkDWS(colList[3], colList[0])
  if path:
   CCvG1x.VVakhe(self, png, path)
 @staticmethod
 def VVBtQQ():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVyh5K():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVi5Xs(self, isEnable):
  lamedbFile, disabledFile = CCUJnZ.VVBtQQ()
  if isEnable and not fileExists(disabledFile):
   FF1ATN(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFc88f(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFfK5z(self, boundFunction(self.VVANxT, isEnable), "%s Hidden Channels ?" % word)
 def VVANxT(self, isEnable):
  lamedbFile , disabledFile = CCUJnZ.VVBtQQ()
  lamedb5File, diabled5File = CCUJnZ.VVyh5K()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFikPN()
  if res == 0 : FF1ATN(self, "Hidden List %s" % word)
  else  : FFc88f(self, "Error while restoring:\n\n%s" % fileName)
 def VVlBrU(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FF1obA(self, cmd)
 def VVtoM8(self):
  lamedbFile, disabledFile = CCUJnZ.VVBtQQ()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFK72g("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFg2eB(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFK72g("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFikPN()
   FFVxvP(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFOr2O(self, lamedbFile)
class CCPltO(Screen):
 VVZJlx  = 0
 VVryMn   = 1
 VVWrw3   = 2
 VVriCP    = 3
 VVydv4    = 4
 VVZUZl   = 5
 VVH57h   = 6
 VVmzK6    = 7
 VVwf5n   = 8
 VVCWsd   = 9
 VVu5LF   = 10
 VV9VdH   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFAEOm(VVI14G, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVZJlx)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFkGYB("%s\n", VVfjTY) % VVS5oR
  FFSF9U(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVCOFQ })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self["myLabel"].VVe9VI(textOutFile="chann_info")
  if   self.fncMode == self.VVZJlx : fnc = self.VVTiiH_VVZJlx
  elif self.fncMode == self.VVryMn  : fnc = self.VVTiiH_VVZJlx
  elif self.fncMode == self.VVWrw3  : fnc = self.VVTiiH_VVZJlx
  elif self.fncMode == self.VVriCP  : fnc = self.VVTiiH_VVriCP
  elif self.fncMode == self.VVydv4  : fnc = self.VVTiiH_VVydv4
  elif self.fncMode == self.VVZUZl  : fnc = self.VVTiiH_VVZUZl
  elif self.fncMode == self.VVH57h  : fnc = self.VVTiiH_VVH57h
  elif self.fncMode == self.VVmzK6  : fnc = self.VVTiiH_VVmzK6
  elif self.fncMode == self.VVwf5n  : fnc = self.VVTiiH_VVwf5n
  elif self.fncMode == self.VVCWsd : fnc = self.VVTiiH_VVCWsd
  elif self.fncMode == self.VVu5LF  : fnc = self.VVTiiH_VVu5LF
  elif self.fncMode == self.VV9VdH : fnc = self.VVTiiH_VV9VdH
  self["myLabel"].setText("\n   Reading Info ...")
  FFlxSW(fnc)
 def VVMklD(self, err):
  self["myLabel"].setText(err)
  FFtJEw(self["myTitle"], "#22200000")
  FFtJEw(self["myBody"], "#22200000")
  self["myLabel"].FFtJEwColor("#22200000")
  self["myLabel"].VVKCBq()
 def VVTiiH_VVZJlx(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  self.refCode = refCode
  self.VVeRA7(chName)
 def VVTiiH_VVriCP(self):
  self.VVeRA7(self.chName)
 def VVTiiH_VVydv4(self):
  self.VVeRA7(self.chName)
 def VVTiiH_VVZUZl(self):
  self.VVeRA7(self.chName)
 def VVTiiH_VVH57h(self):
  self.VVeRA7("Picon Info")
 def VVTiiH_VVmzK6(self):
  self.VVeRA7(self.chName)
 def VVTiiH_VVwf5n(self):
  self.VVeRA7(self.chName)
 def VVTiiH_VVCWsd(self):
  self.VVeRA7(self.chName)
 def VVTiiH_VVu5LF(self):
  self.chUrl = self.refCode + self.callingSELF.VVzMa0(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVeRA7(self.chName)
 def VVTiiH_VV9VdH(self):
  self.VVeRA7(self.chName)
 def VVeRA7(self, title):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVgMjz(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFkGYB(self.VVp8uf(tUrl), VVLchc)
  if not self.epg:
   epg = self.VVzPB9(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVBsnt(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCvG1x.VVkDWS(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVBsnt(path)
  self.VVQML8()
  self.VVc5Ue()
  self["myLabel"].setText(self.text, VVMBud=VVOJfg)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVKCBq(minHeight=minH)
 def VVc5Ue(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF7z8Z(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVXeo3(FFWpIM(url))
  if epg:
   self.text += "\n" + FFGsc3("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVQML8()
 def VVQML8(self):
  if not self.piconShown and self.picUrl:
   path, err = FFPEOO(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVBsnt(path)
    if self.piconShown and self.refCode:
     self.VVHHKc(path, self.refCode)
 def VVHHKc(self, path, refCode):
  if path and fileExists(path) and os.system(FFK72g("which ffmpeg")) == 0:
   pPath = CCvG1x.VVulgY()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFK72g("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVBsnt(self, path):
  if path and fileExists(path):
   err, w, h = self.VVsr9i(path)
   if not err:
    if h > w:
     self.VV2E8O(self["myPicF"], w, h, True)
     self.VV2E8O(self["myPic"] , w, h, False)
   allOK = FFfb15(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VV2E8O(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVsr9i(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFla3R(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVgMjz(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFkGYB(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVtmK4(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFkGYB(state, VVtUnE)
   txt += "State\t: %s\n" % state
  w = FF9E9G(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF9E9G(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVv2fa(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVtmK4(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVtmK4(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVtmK4(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVRrRw()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVp5Pq()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCPltO.VVMKAP(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFkGYB("IPTV", VVy6YC)
   txt += self.VVa168(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVm8Cx(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCriLw()
    tpTxt, namespace = tp.VVeMDR(refCode)
    del tp
    if tpTxt:
     txt += FFkGYB("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFkGYB("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVtmK4(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVtmK4(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVtmK4(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVtmK4(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVtmK4(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVtmK4(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVtmK4(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVtmK4(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVtmK4(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVv2fa(info):
  if info:
   aspect = FF9E9G(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVtmK4(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF9E9G(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV7pcc(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV7pcc(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVRrRw(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVp5Pq(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVm8Cx(self, refCode, iptvRef, chName):
  refCode = FFw2pT(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFzVLg(VV9m85 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFzVLg(VV9m85 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVNz0H = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VV9m85 + item
   if fileExists(path):
    txt = FFzVLg(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVNz0H.append(bName)
  txt = self.Sep
  if VVNz0H:
   if len(VVNz0H) == 1:
    txt += "%s\t: %s\n" % (FFkGYB("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVNz0H[0])
   else:
    txt += FFkGYB("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVNz0H):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVzPB9(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVM0Be(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVM0Be(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVM0Be(event, 0)
     except:
      pass
  return epg
 def VVM0Be(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVtlma(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFkGYB(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFkGYB(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FF7tZn(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF7tZn(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFcGNd(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFcGNd(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFcGNd(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFkGYB(evShort, VVakPb)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFkGYB(evDesc , VVakPb)
    if txt:
     txt = FFkGYB("\n%s\n%s Event:\n%s\n" % (VVS5oR, ("Current", "Next")[evNum], VVS5oR), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVa168(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFCoVU(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCr6oH()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVFxES(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFkGYB("URL:", VVy6YC) + "\n%s\n" % self.VVp8uf(decodedUrl)
  else:
   txt = "\n"
   txt += FFkGYB("Reference:", VVy6YC) + "\n%s\n" % refCode
  return txt
 def VVp8uf(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVWfYG:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVXeo3(self, decodedUrl):
  if not FFyisd():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCNqVt.VVXjzP(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCNqVt.VVcc2w(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVU3o8(tDict)
   elif uType == "movie" : epg, picUrl = self.VVKfFj(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVU3o8(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCNqVt.VVU0Bn(item, "title"    , is_base64=True )
     lang    = CCNqVt.VVU0Bn(item, "lang"         ).upper()
     description   = CCNqVt.VVU0Bn(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCNqVt.VVU0Bn(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCNqVt.VVU0Bn(item, "start_timestamp"      )
     stop_timestamp  = CCNqVt.VVU0Bn(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCNqVt.VVU0Bn(item, "stop_timestamp"       )
     now_playing   = CCNqVt.VVU0Bn(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVB0Ol, ""
      else     : color, txt = VVtUnE , "    (CURRENT EVENT)"
      epg += FFkGYB("_" * 32 + "\n", VVfjTY)
      epg += FFkGYB("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFkGYB(description, VVLchc)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVcHJh(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVKfFj(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCNqVt.VVU0Bn(item, "movie_image" )
    genre  = CCNqVt.VVU0Bn(item, "genre"   ) or "-"
    plot  = CCNqVt.VVU0Bn(item, "plot"   ) or "-"
    cast  = CCNqVt.VVU0Bn(item, "cast"   ) or "-"
    rating  = CCNqVt.VVU0Bn(item, "rating"   ) or "-"
    director = CCNqVt.VVU0Bn(item, "director"  ) or "-"
    releasedate = CCNqVt.VVU0Bn(item, "releasedate" ) or "-"
    duration = CCNqVt.VVU0Bn(item, "duration"  ) or "-"
    try:
     lang = CCNqVt.VVU0Bn(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFkGYB(cast, VVLchc)
    epg += "Plot:\n%s"    % FFkGYB(self.VVtlma(plot), VVLchc)
   except:
    pass
  return epg, movie_image
 def VVtlma(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVZkRL(evTxt, lang)
   return CCPltO.VV5Zdw(txt).strip() or evTxt
 @staticmethod
 def VV5Zdw(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVZkRL(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFtKtF(txt))
   txt, err = CCNqVt.VVcc2w(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFWpIM(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVcHJh(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVqt48(SELF):
  if not CCIF1Z.VV4mkm(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(SELF)
  err = url =  fSize = resumable = ""
  if FFzavm(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCr6oH.VV9UBg(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCr6oH.VVnwvpHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFc88f(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCWnyZ.VVDyPC(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFkGYB(" (M3U/M3U8 File)", VVLchc)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVwkbi(subj, val):
   return "%s\n%s\n\n" % (FFkGYB("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVwkbi(title , fSize or "?")
  txt += VVwkbi("Name" , chName)
  txt += VVwkbi("URL" , url)
  if resumable: txt += VVwkbi("Supports Download-Resume", resumable)
  if err  : txt += FFkGYB("Error:\n", VVtUnE) + err
  FFVxvP(SELF, txt, title=title)
 @staticmethod
 def VVMKAP(SELF):
  fPath, fDir, fName = CCWnyZ.VVQPBU(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVCOFQ(self):
  if VVWfYG:
   def VVtmK4(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
   n = ("info" , "refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (info , refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVtmK4(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCr6oH()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVFxES(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVtmK4(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVS5oR, txt))
   FF4n96(self, "Saved to:", 1000)
class CCr6oH():
 def __init__(self):
  self.VVvtDi  = ""
  self.VVXVNc   = ""
  self.VVkTWK  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVsw65(self, url, mac, VVoTpo=True):
  self.VVvtDi  = ""
  self.VVXVNc   = ""
  self.VVkTWK  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  host = self.VVEZ35(url)
  if not host:
   if VVoTpo:
    self.VVoTpoor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VV1gjt(mac)
  if not host:
   if VVoTpo:
    self.VVoTpoor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVvtDi = host
  self.VVXVNc  = mac
  return True
 def VVEZ35(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VV1gjt(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVZT2m(self, VVoTpo=True):
  err = blkMsg = FF1ATNTxt = ""
  try:
   token, rand, err = self.VVc9TZ()
   if token:
    self.VVkTWK = token
    self.portal_rand  = rand
    prof = self.VVo7zK()
    if prof:
     word = "m" + "sg"
     blkMsg = CCNqVt.VVU0Bn(prof["js"], "block_%s" % word)
     FF1ATNTxt = CCNqVt.VVU0Bn(prof["js"], word)
     if blkMsg or FF1ATNTxt:
      self.portal_moreAuth = True
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF1ATNTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF1ATNTxt: tErr += "\n%s" % FF1ATNTxt
  if VVoTpo:
   self.VVoTpoor(tErr)
  return "", "", tErr
 def VVc9TZ(self):
  res, err = self.VVOKmd(self.VVyN9o())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVvtDi:
   self.VVvtDi = self.VVvtDi.replace(urlPath, "")
   res, err = self.VVOKmd(self.VVyN9o())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCNqVt.VVU0Bn(tDict["js"], "token")
    rand  = CCNqVt.VVU0Bn(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVo7zK(self):
  res, err = self.VVOKmd(self.VVi6ca())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVUzjr(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVQpJa()
  if len(rows) < 10:
   rows = self.VVA99I()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVvtDi ))
   rows.append(("MAC (from URL)" , self.VVXVNc ))
   rows.append(("Token"   , self.VVkTWK ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVXVNc ))
   rows.append(("2", self.colored_server, "Host" , self.VVvtDi ))
   rows.append(("2", self.colored_server, "Token" , self.VVkTWK ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVOHvT(self, isPhp=True, VVoTpo=False):
  token, profile, tErr = self.VVZT2m(VVoTpo)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVvjfF()
  res, err = self.VVOKmd(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCNqVt.VVU0Bn(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFtKtF(span.group(2))
     pass1 = FFtKtF(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVQpJa(self):
  m3u_Url, err = self.VVOHvT()
  rows = []
  if m3u_Url:
   res, err = self.VVOKmd(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF7tZn(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF7tZn(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVA99I(self):
  token, profile, tErr = self.VVZT2m()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFiCfS(val): val = FFrGRP(val.decode("UTF-8"))
     else     : val = self.VVXVNc
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF7tZn(int(parts[1]))
      if parts[2] : ends = FF7tZn(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF7tZn(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVzMa0(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVlpcS(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVZT2m(VVoTpo=False)
  if not token:
   return ""
  res, err = self.VVOKmd(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCNqVt.VVU0Bn(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVZl6u(self):
  return self.VVvtDi + "/server/load.php?"
 def VVyN9o(self):
  return self.VVZl6u() + "type=stb&action=handshake&token=&mac=%s" % self.VVXVNc
 def VVi6ca(self):
  if self.portal_moreAuth:
   import hashlib
   sn    = hashlib.md5(self.VVXVNc).hexdigest().upper()[:13]
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % hashlib.sha256(sn).hexdigest().upper()
   param += "&device_id2=%s" % hashlib.sha256(self.VVXVNc).hexdigest().upper()
   param += "&signature=%s" % hashlib.sha256(sn + self.VVXVNc).hexdigest().upper()
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVXVNc, sn, self.portal_rand)
  else:
   param = ""
  return self.VVZl6u() + "type=stb&action=get_profile" + param
 def VVaCuJ(self, mode):
  url = self.VVZl6u() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVstEc(self, catID):
  return self.VVZl6u() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV3YSA(self, mode, catID, page):
  url = self.VVZl6u() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVJ7wv(self, mode, searchName, page):
  return self.VVZl6u() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVZPHV(self, mode, catID):
  return self.VVZl6u() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVlpcS(self, mode, chCm, serCode, serId):
  url = self.VVZl6u() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVvjfF(self):
  return self.VVZl6u() + "type=itv&action=create_link"
 def VVI7mj(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVuoRh(catID, stID, chNum)
  query = self.VVpo58(mode, FFrLOq(host), FFrLOq(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVpo58(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVFxES(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVpo58(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFrGRP(host)
  mac   = FFrGRP(mac)
  valid = False
  if self.VVEZ35(playHost) and self.VVEZ35(host) and self.VVEZ35(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVOKmd(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCr6oH.VVnwvpHeader()
   if self.VVkTWK:
    headers["Authorization"] = "Bearer %s" % self.VVkTWK
   if useCookies : cookies = {"mac": self.VVXVNc, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVIqlT(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCr6oH.VVnwvpHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVnwvpHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVZXjI(host, mac, tType, action, keysList=[]):
  myPortal = CCr6oH()
  ok = myPortal.VVsw65(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVZT2m(VVoTpo=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVOKmd(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVr4Vw(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVr4Vw(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVoTpoor(self, err, title="Portal Browser"):
  FFc88f(self, str(err), title=title)
 def VVxS4B(self, mode):
  if   mode in ("itv"  , CCNqVt.VVP9Iw , CCNqVt.VVBrrs)  : return "Live"
  elif mode in ("vod"  , CCNqVt.VVPvM2 , CCNqVt.VVd1oR)  : return "VOD"
  elif mode in ("series" , CCNqVt.VVaG6v , CCNqVt.VVzCE5) : return "Series"
  else                          : return "IPTV"
 def VVSS12(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVxS4B(mode), searchName)
 def VVStsI(self, catchup=False):
  VVw8eP = []
  VVw8eP.append(("Live"    , "live"  ))
  VVw8eP.append(("VOD"    , "vod"   ))
  VVw8eP.append(("Series"   , "series"  ))
  if catchup:
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Catchup TV" , "catchup"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Account Info." , "accountInfo" ))
  return VVw8eP
 @staticmethod
 def VVSgRo(decodedUrl):
  m3u_Url = ""
  p = CCr6oH()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVFxES(decodedUrl)
  if valid:
   ok = p.VVsw65(host, mac, VVoTpo=False)
   if ok:
    m3u_Url, err = p.VVOHvT(isPhp=False, VVoTpo=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VV9UBg(decodedUrl):
  p = CCr6oH()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVFxES(decodedUrl)
  if valid:
   ok = p.VVsw65(host, mac, VVoTpo=False)
   if ok:
    try:
     chUrl = p.VVzMa0(mode, chCm, epNum, epId)
     return FFWpIM(chUrl)
    except Exception as e:
     pass
  return ""
class CCKMVs(CCr6oH):
 def __init__(self):
  CCr6oH.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVozjw(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVFxES(decodedUrl)
  if valid:
   if self.VVsw65(host, mac, VVoTpo=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVvO6l(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVzMa0(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VVbxJx(chUrl)
  if newIptvRef:
   success = self.VVrNVF(self.iptvRef, newIptvRef)
   if passedSELF:
    FFaA9c(passedSELF, newIptvRef, VVNAZj=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFaA9c(self, newIptvRef, VVNAZj=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVbxJx(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVrNVF(self, oldCode, newCode):
  bPath = FFbvLj()
  if bPath:
   txt = FFzVLg(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFikPN()
    return True
  return False
class CCbK7L(CCKMVs):
 def __init__(self, passedSession):
  CCKMVs.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVvigm, iPlayableService.evEOF: self.VVn7Og, iPlayableService.evEnd: self.VV5Kk3})
  except:
   pass
 def VVvigm(self):
  self.starttime = iTime()
 def VVn7Og(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self.passedSession, isFromSession=True)
    if iptvRef and not FFzavm(decodedUrl):
     CCR0jD(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VV5Kk3(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVVAId)
  except:
   self.timer1.callback.append(self.VVVAId)
  self.timer1.start(100, True)
 def VVVAId(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVozjw(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CC9DjN.VVtJSD:
       self.VVvO6l(self.passedSession, isFromSession=True)
class CC3a1j():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVHFwm(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCNqVt.VVINkt(name):
   return CCNqVt.VV5iHK(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVjp79(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVnjxC(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VV60KL(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VV5Zs5(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCIF1Z(CCr6oH):
 def __init__(self):
  CCr6oH.__init__(self)
 def VVtnZN(self):
  if CCIF1Z.VV4mkm(self):
   FFKl3w(self, self.VVOgXA, title="Searching ...")
 def VVSHzp(self, winSession, url, mac):
  if CCIF1Z.VV4mkm(self):
   if self.VVsw65(url, mac):
    FFKl3w(winSession, self.VVBDCx, title="Checking Server ...")
   else:
    FFc88f(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVOgXA(self):
  path = CCNqVt.VVrNii()
  lines = FFgPQo('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFYGMZ(1)))
  if lines:
   lines.sort()
   VVw8eP = []
   for line in lines:
    VVw8eP.append((line, line))
   OKBtnFnc = self.VVNJsw
   VVjOnb = ("Delete File", boundFunction(self.VVTSpW, boundFunction(FFKl3w, self, self.VVOgXA, title="Searching ...")))
   FF7Bt5(self, None, title="Select Portals File", VVw8eP=VVw8eP, width=1200, OKBtnFnc=OKBtnFnc, VVjOnb=VVjOnb)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFc88f(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVTSpW(self, cbFnc, VVWZQiObj, path):
  FFfK5z(self, boundFunction(self.VVJvhV, cbFnc, VVWZQiObj, path), "Delete this file ?\n\n%s" % path)
 def VVJvhV(self, cbFnc, VVWZQiObj, path):
  os.system(FFK72g("rm -f '%s'" % path))
  VVWZQiObj.cancel()
  FFlxSW(cbFnc)
 def VVNJsw(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = FFPUkJ(path, self)
   if enc == -1:
    return
   self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVovVG, path, enc)
       , VVOm4z = boundFunction(self.VVmH6D, menuInstance, path))
 def VVovVG(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVQ1QY(totLines)
  progBarObj.VVwCH6 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVUkc0(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVEZ35(url)
     mac  = self.VV1gjt(mac)
     if host and mac and progBarObj:
      progBarObj.VVwCH6.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVEZ35(url)
      mac  = self.VV1gjt(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVwCH6.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVmH6D(self, menuInstance, path, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVwCH6:
   VVJGeM  = ("Home Menu", FFfnA1, [])
   VVtvPm  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VV6rfs = ("Edit File" , boundFunction(self.VVsfcy, path) , [])
   VVicyB = ("Open as M3U", self.VVQ6wV     , [])
   VV2zCi  = ("Select"  , self.VVSHzp_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVSgvw  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVDhXw = FFS01Q(self, None, title=title, header=header, VVNz0H=VVwCH6, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm, VVRFto="#0a001122", VVHhCo="#0a001122", VVYhbt="#0a001122", VVOU5Z="#00004455", VVD2dA="#0a333333", VVw0pN="#11331100", VVjrzO=True, searchCol=1)
   if not VVxVJy:
    FF4n96(VVDhXw, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVxVJy:
    FFc88f(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVQ6wV(self, VVDhXw, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFKl3w(VVDhXw, boundFunction(self.VVP5Jx, VVDhXw, host, mac), title="Checking Server ...")
 def VVP5Jx(self, VVDhXw, host, mac):
  p = CCr6oH()
  m3u_Url = ""
  ok = p.VVsw65(host, mac, VVoTpo=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVOHvT(VVoTpo=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVfiIq(title, m3u_Url)
  else:
   FFc88f(self, err or "No response from Server !", title=title)
 def VVSHzp_fromMacFiles(self, VVDhXw, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVSHzp(VVDhXw, url, mac)
 def VVsfcy(self, path, VVDhXw, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCFIrc(self, path, VVOm4z=boundFunction(self.VV13n1, VVDhXw), curRowNum=rowNum)
  else    : FFOr2O(self, path)
 def VVohA1(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFrGRP(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVBDCx(self):
  token, profile, tErr = self.VVZT2m()
  if token:
   VVw8eP  = self.VVStsI()
   OKBtnFnc = self.VVuKw8
   VVjOJ6 = ("Home Menu", FFfnA1)
   VVzZGK = ("Bookmark Server", boundFunction(CCNqVt.VVVHaw, self, True, self.VVvtDi + "\t" + self.VVXVNc))
   authMore = ".." if self.portal_moreAuth else ""
   FF7Bt5(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVXVNc, authMore), VVw8eP=VVw8eP, OKBtnFnc=OKBtnFnc, VVjOJ6=VVjOJ6, VVzZGK=VVzZGK)
 def VVuKw8(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFKl3w(menuInstance, boundFunction(self.VVmObO, mode), title="Reading Categories ...")
   else : FFKl3w(menuInstance, boundFunction(self.VVWfog, menuInstance, title), title="Reading Account ...")
 def VVWfog(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVUzjr(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVXVNc)
  VVJGeM  = ("Home Menu" , FFfnA1, [])
  if totCols == 2:
   VVtvPm = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVtvPm = ("More Info.", boundFunction(self.VVdxgr, menuInstance) , [])
  FFS01Q(self, None, title=title, width=1200, header=header, VVNz0H=rows, VVTy8n=widths, VVjgTX=26, VVJGeM=VVJGeM, VVtvPm=VVtvPm, VVRFto="#0a00292B", VVHhCo="#0a002126", VVYhbt="#0a002126", VVOU5Z="#00000000", searchCol=searchCol)
 def VVdxgr(self, menuInstance, VVDhXw, title, txt, colList):
  VVDhXw.cancel()
  FFKl3w(menuInstance, boundFunction(self.VVWfog, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVmObO(self, mode):
  token, profile, tErr = self.VVZT2m()
  if not token:
   return
  res, err = self.VVOKmd(self.VVaCuJ(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CC3a1j()
     chList = tDict["js"]
     for item in chList:
      Id   = CCNqVt.VVU0Bn(item, "id"       )
      Title  = CCNqVt.VVU0Bn(item, "title"      )
      censored = CCNqVt.VVU0Bn(item, "censored"     )
      Title = processChanName.VVnjxC(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV5ZBQ:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVxS4B(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A(mode)
   mName = self.VVxS4B(mode)
   VV2zCi   = ("Show List"   , boundFunction(self.VVy1PC, mode) , [])
   VVJGeM  = ("Home Menu"   , FFfnA1         , [])
   if mode in ("vod", "series"):
    VV6rfs = ("Find in %s" % mName , boundFunction(self.VVZpor, mode), [])
   else:
    VV6rfs = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFS01Q(self, None, title=title, width=1200, header=header, VVNz0H=list, VVTy8n=widths, VVjgTX=30, VVJGeM=VVJGeM, VV6rfs=VV6rfs, VV2zCi=VV2zCi, VVRFto=VVRFto, VVHhCo=VVHhCo, VVYhbt=VVYhbt, VVOU5Z=VVOU5Z)
  else:
   s = "Authorization failed"
   if err    : txt = err
   elif s in res.text : txt = s
   else    : txt = "Could not get Categories from server!"
   FFc88f(self, txt, title=title)
 def VVDMkc(self, mode, VVDhXw, title, txt, colList):
  FFKl3w(VVDhXw, boundFunction(self.VVfKaz, mode, VVDhXw, title, txt, colList), title="Downloading ...")
 def VVfKaz(self, mode, VVDhXw, title, txt, colList):
  token, profile, tErr = self.VVZT2m()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVOKmd(self.VVstEc(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCNqVt.VVU0Bn(item, "id"    )
      actors   = CCNqVt.VVU0Bn(item, "actors"   )
      added   = CCNqVt.VVU0Bn(item, "added"   )
      age    = CCNqVt.VVU0Bn(item, "age"   )
      category_id  = CCNqVt.VVU0Bn(item, "category_id" )
      description  = CCNqVt.VVU0Bn(item, "description" )
      director  = CCNqVt.VVU0Bn(item, "director"  )
      genres_str  = CCNqVt.VVU0Bn(item, "genres_str"  )
      name   = CCNqVt.VVU0Bn(item, "name"   )
      path   = CCNqVt.VVU0Bn(item, "path"   )
      screenshot_uri = CCNqVt.VVU0Bn(item, "screenshot_uri" )
      series   = CCNqVt.VVU0Bn(item, "series"   )
      cmd    = CCNqVt.VVU0Bn(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VV2zCi  = ("Play"    , boundFunction(self.VVhSko, mode)       , [])
   VV2kYm = (""     , boundFunction(self.VVDfYr, mode)     , [])
   VVJGeM = ("Home Menu"   , FFfnA1               , [])
   VVicyB = ("Download Options" , boundFunction(self.VVjWVH, mode, "sp", seriesName) , [])
   VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVH8tB, mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVSgvw  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFS01Q(self, None, title=seriesName, width=1200, header=header, VVNz0H=list, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VVRFto="#0a00292B", VVHhCo="#0a002126", VVYhbt="#0a002126", VVOU5Z="#00000000")
  else:
   FFc88f(self, "Could not get Episodes from server!", title=seriesName)
 def VVZpor(self, mode, VVDhXw, title, txt, colList):
  VVw8eP = []
  VVw8eP.append(("Keyboard"  , "manualEntry"))
  VVw8eP.append(("From Filter" , "fromFilter"))
  FF7Bt5(self, boundFunction(self.VVB1MB, VVDhXw, mode), title="Input Type", VVw8eP=VVw8eP, width=400)
 def VVB1MB(self, VVDhXw, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFTT6y(self, boundFunction(self.VVLaaK, VVDhXw, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC09mD(self)
    filterObj.VVU6jv(boundFunction(self.VVLaaK, VVDhXw, mode))
 def VVLaaK(self, VVDhXw, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVSS12(mode, searchName)
   if len(searchName) < 3:
    FFc88f(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CC3a1j()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VV60KL([searchName]):
     FFc88f(self, processChanName.VV5Zs5(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVBxTZ(mode, searchName, "", searchName)
 def VVy1PC(self, mode, VVDhXw, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVBxTZ(mode, bName, catID, "")
 def VVBxTZ(self, mode, bName, catID, searchName):
  self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVI9PG, mode, bName, catID, searchName)
      , VVOm4z = boundFunction(self.VVAuIB, mode, bName, catID, searchName))
 def VVAuIB(self, mode, bName, catID, searchName, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVSS12(mode, searchName)
  else   : title = "%s : %s" % (self.VVxS4B(mode), bName)
  if VVwCH6:
   VVicyB = None
   VV6rfs = None
   if mode == "series":
    VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A("series2")
    VV2zCi  = ("Episodes", boundFunction(self.VVDMkc, mode) , [])
   else:
    VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A("")
    VV2zCi  = ("Play"    , boundFunction(self.VVhSko, mode)           , [])
    VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVH8tB, mode, bName)       , [])
    VVicyB = ("Download Options" , boundFunction(self.VVjWVH, mode, "vp" if mode == "vod" else "", "") , [])
   VV2kYm = (""      , boundFunction(self.VVZtNh, mode)          , [])
   VVJGeM = ("Home Menu"    , FFfnA1                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVSgvw  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVDhXw = FFS01Q(self, None, title=title, header=header, VVNz0H=VVwCH6, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VVRFto=VVRFto, VVHhCo=VVHhCo, VVYhbt=VVYhbt, VVOU5Z=VVOU5Z, VVjrzO=True, searchCol=1)
   if not VVxVJy:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVDhXw.VVI5gL(VVDhXw.VV1toc() + tot)
    if threadErr: FF4n96(VVDhXw, "Error while reading !", 2000)
    else  : FF4n96(VVDhXw, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFc88f(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFc88f(self, "Could not get list from server !", title=title)
 def VVZtNh(self, mode, VVDhXw, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFgbQa(self, fncMode=CCPltO.VV9VdH, portalHost=self.VVvtDi, portalMac=self.VVXVNc, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVEvJ3(mode, VVDhXw, title, txt, colList)
 def VVDfYr(self, mode, VVDhXw, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFkGYB(colList[10], VVLchc)
  txt += "Description:\n%s" % FFkGYB(colList[11], VVLchc)
  self.VVEvJ3(mode, VVDhXw, title, txt, colList)
 def VVEvJ3(self, mode, VVDhXw, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVsVMz(mode, colList)
  refCode, chUrl = self.VVI7mj(self.VVvtDi, self.VVXVNc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFgbQa(self, fncMode=CCPltO.VVu5LF, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVI9PG(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVZT2m()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVwCH6, total_items, max_page_items, err = self.VVnBe5(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVwCH6 and total_items > -1 and max_page_items > -1:
    progBarObj.VVQ1QY(total_items)
    progBarObj.VVUkc0(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVnBe5(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VViCXZ()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVwCH6 += list
      progBarObj.VVUkc0(len(list), True)
  except:
   pass
 def VVnBe5(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVJ7wv(mode, searchName, page)
  else   : url = self.VV3YSA(mode, catID, page)
  res, err = self.VVOKmd(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVJJZ3(CCNqVt.VVU0Bn(item, "total_items" ))
     max_page_items = self.VVJJZ3(CCNqVt.VVU0Bn(item, "max_page_items" ))
     processChanName = CC3a1j()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCNqVt.VVU0Bn(item, "id"    )
      name   = CCNqVt.VVU0Bn(item, "name"   )
      tv_genre_id  = CCNqVt.VVU0Bn(item, "tv_genre_id" )
      number   = CCNqVt.VVU0Bn(item, "number"   ) or str(counter)
      logo   = CCNqVt.VVU0Bn(item, "logo"   )
      screenshot_uri = CCNqVt.VVU0Bn(item, "screenshot_uri" )
      cmd    = CCNqVt.VVU0Bn(item, "cmd"   )
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8"):
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      counter += 1
      name = processChanName.VVHFwm(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVH8tB(self, mode, bName, VVDhXw, title, txt, colList):
  FFKl3w(VVDhXw, boundFunction(self.VVBGMa, mode, bName, VVDhXw, title, txt, colList), title="Adding Channels ...")
 def VVBGMa(self, mode, bName, VVDhXw, title, txt, colList):
  bNameFile = CCNqVt.VVK2Qy_forBouquet(bName)
  num  = 0
  path = VV9m85 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VV9m85 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVDhXw.VVB6yQ():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVsVMz(mode, row)
    refCode, chUrl = self.VVI7mj(self.VVvtDi, self.VVXVNc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFjfIu(os.path.basename(path))
  self.VVu8L4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVJJZ3(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVhSko(self, mode, VVDhXw, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVsVMz(mode, colList)
  refCode, chUrl = self.VVI7mj(self.VVvtDi, self.VVXVNc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVINkt(chName):
   FF4n96(VVDhXw, "This is a marker!", 300)
  else:
   FFKl3w(VVDhXw, boundFunction(self.VVbYmX, mode, VVDhXw, chUrl), title="Playing ...")
 def VVbYmX(self, mode, VVDhXw, chUrl):
  FFaA9c(self, chUrl, VVNAZj=False)
  self.session.open(CC9DjN, portalTableParam=(self, VVDhXw, mode))
 def VV4tZe(self, mode, VVDhXw, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVsVMz(mode, colList)
  refCode, chUrl = self.VVI7mj(self.VVvtDi, self.VVXVNc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVsVMz(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV4mkm(SELF):
  try:
   import requests
   return True
  except:
   FFfK5z(SELF, boundFunction(CCIF1Z.VVLxJR, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVLxJR(SELF):
  from sys import version_info
  cmdUpd = FFZsGt(VVcIup, "")
  if cmdUpd:
   cmdInst = FFp0JH(VVggHo, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFypV6(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFdCT7(SELF)
class CCNqVt(Screen, CCIF1Z):
 VVY0pq    = 0
 VVyBy4    = 1
 VVoGaw    = 2
 VVEbFP    = 3
 VVVYzu     = 4
 VV2dog     = 5
 VVXMJH     = 6
 VVHWzS     = 7
 VV9gai      = 8
 VVntMu     = 9
 VVm973     = 10
 VVPwiA     = 11
 VVoBYg     = 12
 VVk8QD      = 13
 VVpcLm      = 14
 VVwC49      = 15
 VVP51q      = 16
 VVSsle      = 17
 VVxxiC    = 0
 VVP9Iw   = 1
 VVPvM2   = 2
 VVaG6v   = 3
 VVYeMD  = 4
 VVOldp  = 5
 VVBrrs   = 6
 VVd1oR   = 7
 VVzCE5  = 8
 VVW6tB  = 9
 VVaIDt  = 10
 VVAbwq = 0
 VVUZ9G = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFAEOm(VVEShK, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVDhXw  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVEvpjData  = {}
  self.lastFindIptvName = ""
  CCIF1Z.__init__(self)
  VVw8eP= self.VVDGq3()
  FFSF9U(self, title="IPTV", VVw8eP=VVw8eP)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
  FFUfvu(self)
  if self.m3uOrM3u8File:
   self.VVWrfW(self.m3uOrM3u8File)
 def VVDGq3(self):
  files = self.VVJnMl()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVEvpj_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVEvpj_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVEvpj_fromM3u"  ))
  qUrl, iptvRef = self.VVvIGM()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVEvpj_fromCurrChan" ))
  VVw8eP = []
  if files:
   if self.VVDhXw:
    VVw8eP.append(("Add Current List to a New Bouquet"      , "VVATVP"  ))
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("Change Current List References to Unique Codes"   , "VVEK1O"))
    VVw8eP.append(("Change Current List References to Identical Codes"  , "VVkXPy_rows" ))
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVoqa0"   ))
    VVw8eP.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVCOKP"   ))
   else:
    VVw8eP += tList
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("M3U/M3U8 Channels Browser"        , "VVunLG"   ))
    VVw8eP.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVw8eP.append(VV9e5C)
     VVw8eP.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("Count Available IPTV Channels"       , "VVYJWy"    ))
    VVw8eP.append(("Check Reference Codes Format"        , "VV5pKk"   ))
    VVw8eP.append(("Check System Acceptable Reference Types"     , "VVuNBh"   ))
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVrXHT" ))
    VVw8eP.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVjIxJ"  ))
    VVw8eP.append(("Change ALL References to Unique Codes"     , "VVFqjM" ))
    VVw8eP.append(("Change ALL References to Identical Codes"     , "VVkXPy_all" ))
  if not self.VVDhXw:
   if not files:
    VVw8eP += tList
   if not CCaDOu.VVBRy7():
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("Download Manager"           , "dload_stat"    ))
  return VVw8eP
 def VVZSWM(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVATVP"   : FFTT6y(self, self.VVATVP, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVEK1O" : FFfK5z(self, boundFunction(FFKl3w, self.VVDhXw, self.VVEK1O ), "Change Current List References to Unique Codes ?")
   elif item == "VVkXPy_rows" : FFfK5z(self, boundFunction(FFKl3w, self.VVDhXw, self.VVkXPy   ), "Change Current List References to Identical Codes ?")
   elif item == "VVoqa0"   : self.VVoqa0(tTitle)
   elif item == "VVCOKP"   : self.VVCOKP(tTitle)
   elif item == "VVEvpj_fromPlayList" : FFKl3w(self, self.VVL1up, title=title)
   elif item == "VVEvpj_fromM3u"  : FFKl3w(self, boundFunction(self.VVsfiI, 0), title=title)
   elif item == "VVEvpj_fromMac"  : self.VVtnZN()
   elif item == "VVEvpj_fromCurrChan" : self.VVSHzp_fromCurrChan()
   elif item == "VVunLG"   : self.VVunLG()
   elif item == "iptvTable_live"   : FFKl3w(self, boundFunction(self.VVlHI4, self.VVHWzS ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFKl3w(self, boundFunction(self.VVlHI4, self.VVY0pq) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVwS1I()
   elif item == "VVYJWy"    : FFKl3w(self, self.VVYJWy)
   elif item == "VV5pKk"    : FFKl3w(self, self.VV5pKk)
   elif item == "VVuNBh"   : FFKl3w(self, self.VVuNBh)
   elif item == "VVrXHT"  : FFfK5z(self, boundFunction(FFKl3w, self, self.VVrXHT ), "Continue ?")
   elif item == "VVjIxJ"  : self.VVjIxJ()
   elif item == "VVFqjM" : FFfK5z(self, boundFunction(FFKl3w, self, self.VVFqjM ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVkXPy_all" : FFfK5z(self, boundFunction(FFKl3w, self, self.VVkXPy  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCaDOu.VVqHnS(self)
   elif item == "VV2pB2"   : FFKl3w(self, boundFunction(CCUJnZ.VV2pB2, self))
 def VVunLG(self):
  if CCIF1Z.VV4mkm(self):
   FFKl3w(self, boundFunction(self.VVsfiI, 1), title="Searching ...")
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVZSWM(item)
 def VVlHI4(self, mode):
  VV5w32 = self.VVBmvF(mode)
  if VV5w32:
   VVicyB = ("Current Service", self.VVfGNc  , [])
   VV6rfs = ("Options"  , self.VVs6kh    , [])
   VVtvPm = ("Filter"   , self.VVqtLu    , [])
   VV2zCi  = ("Play"   , boundFunction(self.VVzmzk) , [])
   VV2kYm = (""    , self.VVZ5Jj     , [])
   VVbsCJ = (""    , self.VVAkgp      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVSgvw  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFS01Q(self, None, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26
     , VV2zCi=VV2zCi, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm, VV2kYm=VV2kYm, VVbsCJ=VVbsCJ
     , VVRFto="#0a00292B", VVHhCo="#0a002126", VVYhbt="#0a002126", VVOU5Z="#00000000", VVjrzO=True, searchCol=1)
  else:
   if mode == self.VVHWzS: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFc88f(self, err)
 def VVAkgp(self, VVDhXw, title, txt, colList):
  self.VVDhXw = VVDhXw
 def VVs6kh(self, VVDhXw, title, txt, colList):
  VVw8eP= self.VVDGq3()
  FF7Bt5(self, self.VVZSWM, title="IPTV Tools", VVw8eP=VVw8eP)
 def VVqtLu(self, VVDhXw, title, txt, colList):
  VVw8eP = []
  VVw8eP.append(("All"         , "all"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Prefix of Selected Channel"   , "sameName" ))
  VVw8eP.append(("Suggest Words from Selected Channel" , "partName" ))
  VVw8eP.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Live TV"        , "live"  ))
  VVw8eP.append(("VOD"         , "vod"   ))
  VVw8eP.append(("Series"        , "series"  ))
  VVw8eP.append(("Uncategorised"      , "uncat"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Video"        , "video"  ))
  VVw8eP.append(("Audio"        , "audio"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("MKV"         , "MKV"   ))
  VVw8eP.append(("MP4"         , "MP4"   ))
  VVw8eP.append(("MP3"         , "MP3"   ))
  VVw8eP.append(("AVI"         , "AVI"   ))
  VVw8eP.append(("FLV"         , "FLV"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVHSre()
  if bNames:
   bNames.sort()
   VVw8eP.append(VV9e5C)
   for item in bNames:
    VVw8eP.append((item, "__b__" + item))
  filterObj = CC09mD(self)
  filterObj.VVIOJM(VVw8eP, VVw8eP, boundFunction(self.VVRoKP, VVDhXw))
 def VVRoKP(self, VVDhXw, item=None):
  prefix = VVDhXw.VVLIgd(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVY0pq, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVyBy4 , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVoGaw , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVEbFP , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVHWzS  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV9gai   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVntMu  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVm973  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVPwiA  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVoBYg  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVk8QD   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVpcLm   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVwC49   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVP51q   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVSsle   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVXMJH  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVVYzu  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VV2dog  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVoGaw:
   VVw8eP = []
   chName = VVDhXw.VVLIgd(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVw8eP.append((item, item))
    if not VVw8eP and chName:
     VVw8eP.append((chName, chName))
    FF7Bt5(self, boundFunction(self.VVBMwh_partOfName, title), title="Words from Current Selection", VVw8eP=VVw8eP)
   else:
    VVDhXw.VVEQT9("Invalid Channel Name")
  else:
   words, asPrefix = CC09mD.VVl1Dd(words)
   if not words and mode in (self.VVVYzu, self.VV2dog):
    FF4n96(self.VVDhXw, "Incorrect filter", 2000)
   else:
    FFKl3w(self.VVDhXw, boundFunction(self.VVR9eO, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVBMwh_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFKl3w(self.VVDhXw, boundFunction(self.VVR9eO, self.VVoGaw, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV5iHK(txt):
  return "#f#11ffff00#" + txt
 def VVR9eO(self, mode, words, asPrefix, title):
  VV5w32 = self.VVBmvF(mode=mode, words=words, asPrefix=asPrefix)
  if VV5w32 : self.VVDhXw.VVC9qg(VV5w32, title)
  else  : self.VVDhXw.VVEQT9("Not found")
 def VVBmvF(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV5w32 = []
  files  = self.VVJnMl()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFzVLg(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVYtt0 = span.group(1)
    else : VVYtt0 = ""
    VVYtt0_lCase = VVYtt0.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVINkt(chName): chNameMod = self.VV5iHK(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVYtt0, chType, refCode, url)
     ok = False
     tUrl = FFWpIM(url).lower()
     if mode == self.VVY0pq       : ok = True
     elif mode == self.VVXMJH       : ok = True
     elif mode == self.VVPwiA:
      if CCNqVt.VVXjzP(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVoBYg:
      if CCNqVt.VVXjzP(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVHWzS:
      if CCNqVt.VVXjzP(tUrl, compareType="live")  : ok = True
     elif mode == self.VV9gai:
      if CCNqVt.VVXjzP(tUrl, compareType="movie") : ok = True
     elif mode == self.VVntMu:
      if CCNqVt.VVXjzP(tUrl, compareType="series") : ok = True
     elif mode == self.VVm973:
      if CCNqVt.VVXjzP(tUrl, compareType="")   : ok = True
     elif mode == self.VVk8QD:
      if CCNqVt.VVXjzP(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVpcLm:
      if CCNqVt.VVXjzP(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVwC49:
      if CCNqVt.VVXjzP(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVP51q:
      if CCNqVt.VVXjzP(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVSsle:
      if CCNqVt.VVXjzP(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVyBy4:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVoGaw:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVEbFP:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVVYzu:
      if words[0] == VVYtt0_lCase:
       ok = True
     elif mode == self.VV2dog:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV5w32.append(row)
      chNum += 1
  if VV5w32 and mode == self.VVXMJH:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV5w32)
   for item in VV5w32:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV5w32 = newRows
  return VV5w32
 def VVATVP(self, bName):
  if bName:
   FFKl3w(self.VVDhXw, boundFunction(self.VVECfl, bName), title="Adding Channels ...")
 def VVECfl(self, bName):
  num = 0
  path = VV9m85 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VV9m85 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVDhXw.VVB6yQ():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFtG6X(row[1]))
    totChange += 1
  FFjfIu(os.path.basename(path))
  self.VVu8L4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVjIxJ(self):
  txt = "Stream Type "
  VVw8eP = []
  VVw8eP.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVw8eP.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVw8eP.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVw8eP.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVw8eP.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVw8eP.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF7Bt5(self, self.VVgxlR, title="Change Reference Types to:", VVw8eP=VVw8eP)
 def VVgxlR(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVhvOn("1"   )
   elif item == "RT_4097" : self.VVhvOn("4097")
   elif item == "RT_5001" : self.VVhvOn("5001")
   elif item == "RT_5002" : self.VVhvOn("5002")
   elif item == "RT_8192" : self.VVhvOn("8192")
   elif item == "RT_8193" : self.VVhvOn("8193")
 def VVhvOn(self, rType):
  FFfK5z(self, boundFunction(FFKl3w, self, boundFunction(self.VVbX7i, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVbX7i(self, refType):
  totChange = 0
  files  = self.VVJnMl()
  if files:
   for path in files:
    txt = FFzVLg(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFjfIu(os.path.basename(path))
  self.VVu8L4(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVYJWy(self):
  totFiles = 0
  files  = self.VVJnMl()
  if files:
   totFiles = len(files)
  totChans = 0
  VV5w32 = self.VVBmvF()
  if VV5w32:
   totChans = len(VV5w32)
  FFVxvP(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV5pKk(self):
  files  = self.VVJnMl()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFzVLg(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVfxXg
   else    : color = VVtUnE
   totInvalid = FFkGYB(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFkGYB("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFVxvP(self, txt, title="Check IPTV References")
 def VVuNBh(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VV9m85 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFjfIu(os.path.basename(path))
  FFikPN()
  acceptedList = []
  VV7KNp = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV7KNp:
   VVfQ5S = FF2rc7(VV7KNp)
   if VVfQ5S:
    for service in VVfQ5S:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VV9m85 + userBName
  bFile = VV9m85 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFK72g("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFK72g("rm -f '%s'" % path)
  os.system(cmd)
  FFikPN()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVfxXg
    else     : res, color = "No" , VVtUnE
    txt += "    %s\t: %s\n" % (item, FFkGYB(res, color))
   FFVxvP(self, txt, title=title)
  else:
   txt = FFc88f(self, "Could not complete the test on your system!", title=title)
 def VVrXHT(self):
  lameDbChans = CCUJnZ.VVBpsi(self, CCUJnZ.VVkdIi)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVJnMl():
    toSave = False
    txt = FFzVLg(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVu8L4(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFc88f(self, 'No channels in "lamedb" !')
 def VVFqjM(self):
  files  = self.VVJnMl()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFg2eB(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVMgrg(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVu8L4(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVEK1O(self):
  iptvRefList = []
  files  = self.VVJnMl()
  if files:
   for path in files:
    txt = FFzVLg(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVDhXw.VVc4m9(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVMgrg(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVJnMl()
  if files:
   for path in files:
    lines = FFg2eB(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVu8L4(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVMgrg(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVkXPy(self):
  list = None
  if self.VVDhXw:
   list = []
   for row in self.VVDhXw.VVB6yQ():
    list.append(row[4] + row[5])
  files  = self.VVJnMl()
  totChange = 0
  if files:
   for path in files:
    lines = FFg2eB(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVu8L4(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVu8L4(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFikPN()
   if refreshTable and self.VVDhXw:
    VV5w32 = self.VVBmvF()
    if VV5w32 and self.VVDhXw:
     self.VVDhXw.VVC9qg(VV5w32, self.tableTitle)
     self.VVDhXw.VVEQT9(txt)
   FFVxvP(self, txt, title=title)
  else:
   FF1ATN(self, "No changes.")
 def VVHSre(self):
  files = self.VVJnMl()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVe6dO = FFcqwa()
    if VVe6dO:
     for b in VVe6dO:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVJnMl(self):
  return CCNqVt.VV1iJE(self)
 @staticmethod
 def VV1iJE(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VV9m85 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFzVLg(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVZ5Jj(self, VVDhXw, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFWpIM(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFgbQa(self, fncMode=CCPltO.VVmzK6, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVN7Xf(self, VVDhXw, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVzmzk(self, VVDhXw, title, txt, colList):
  chName, chUrl = self.VVN7Xf(VVDhXw, colList)
  self.VVMeAX(VVDhXw, chName, chUrl, "localIptv")
 def VVC4er(self, mode, VVDhXw, colList):
  chName, chUrl, picUrl, refCode = self.VVMjra(mode, colList)
  return chName, chUrl
 def VVGwqf(self, mode, VVDhXw, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVMjra(mode, colList)
  self.VVMeAX(VVDhXw, chName, chUrl, mode)
 def VVMeAX(self, VVDhXw, chName, chUrl, playerFlag):
  chName = FFtG6X(chName)
  if self.VVINkt(chName):
   FF4n96(VVDhXw, "This is a marker!", 300)
  else:
   FFKl3w(VVDhXw, boundFunction(self.VVgRtQ, VVDhXw, chUrl, playerFlag), title="Playing ...")
 def VVgRtQ(self, VVDhXw, chUrl, playerFlag):
  FFaA9c(self, chUrl, VVNAZj=False)
  self.session.open(CC9DjN, portalTableParam=(self, VVDhXw, playerFlag))
 @staticmethod
 def VVINkt(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVfGNc(self, VVDhXw, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if refCode:
   bName = FFkzXS()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFw2pT(refCode, origUrl, chName) }
   VVDhXw.VV9BEJ_partial(colDict, VVoTpo=True)
 def VVsfiI(self, m3uMode):
  path = CCNqVt.VVrNii()
  lines = FFgPQo("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFYGMZ(1)))
  if lines:
   lines.sort()
   VVw8eP = []
   for line in lines:
    VVw8eP.append((line, line))
   if m3uMode == self.VVAbwq:
    title = "Browse Server from M3U URLs"
    VVzZGK = ("All to Playlist", self.VVci6g)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVzZGK = None
   OKBtnFnc = boundFunction(self.VVX09u, m3uMode, title)
   VVvKTv = ("Show Full Path", self.VVBqnY)
   VVjOnb = ("Delete File", boundFunction(self.VVTSpW, boundFunction(FFKl3w, self, boundFunction(self.VVsfiI, m3uMode), title="Searching ...")))
   FF7Bt5(self, None, title=title, VVw8eP=VVw8eP, width=1200, OKBtnFnc=OKBtnFnc, VVvKTv=VVvKTv, VVjOnb=VVjOnb, VVzZGK=VVzZGK)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFc88f(self, 'No ".m3u" files found %s' % txt)
 def VVBqnY(self, VVWZQiObj, url):
  FFVxvP(self, url, title="Full Path")
 def VVX09u(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVAbwq:
    FFKl3w(menuInstance, boundFunction(self.VV0V9y, title, path))
   else:
    FFKl3w(menuInstance, boundFunction(self.VVWrfW, path))
 def VVWrfW(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFzVLg(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CC3a1j()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVIHED(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVHFwm(group):
    groups.add(group)
  VV5w32 = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV5w32.append((group, group))
   VV5w32.append(("ALL", ""))
   VV5w32.sort(key=lambda x: x[0].lower())
   VV33pw = self.VVWfoN
   VV2zCi  = ("Select" , boundFunction(self.VVlrxY, srcPath), [])
   widths   = (100  , 0)
   VVSgvw  = (LEFT  , LEFT)
   FFS01Q(self, None, title=title, width= 800, header=None, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=30, VV2zCi=VV2zCi, VV33pw=VV33pw
     , VVRFto="#11110022", VVHhCo="#11110022", VVYhbt="#11110022", VVOU5Z="#00444400")
  else:
   txt = FFzVLg(srcPath)
   self.VVuXx1(txt, filterGroup="")
 def VVlrxY(self, srcPath, VVDhXw, title, txt, colList):
  group = colList[1]
  txt = FFzVLg(srcPath)
  self.VVuXx1(txt, filterGroup=group)
 def VVuXx1(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VV6HZm, lst, filterGroup)
       , VVOm4z = boundFunction(self.VVE4dg, title, bName))
  else:
   self.VVgNCp("No valid lines found !", title)
 def VV6HZm(self, lst, filterGroup, progBarObj):
  progBarObj.VVwCH6 = []
  progBarObj.VVQ1QY(len(lst))
  processChanName = CC3a1j()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVUkc0(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVIHED(propLine, "tvg-logo")
   group = self.VVIHED(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVHFwm(group) : skip = True
    if chName and not processChanName.VVHFwm(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVwCH6.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVUdJZ_forcedUpdate("Loading %d Channels" % len(progBarObj.VVwCH6))
 def VVE4dg(self, title, bName, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  if VVwCH6:
   VV33pw = self.VVWfoN
   VV2zCi  = ("Select"    , boundFunction(self.VVeIMg, title) , [])
   VV2kYm = (""     , self.VVA46m         , [])
   VVicyB = ("Download PIcons" , self.VVad5J        , [])
   VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVcPmN, bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVSgvw  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFS01Q(self, None, title=title, header=header, VVNz0H=VVwCH6, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=28, VV2zCi=VV2zCi, VV33pw=VV33pw, VV2kYm=VV2kYm, VVicyB=VVicyB, VV6rfs=VV6rfs, VVjrzO=True, searchCol=1
     , VVRFto="#0a00192B", VVHhCo="#0a00192B", VVYhbt="#0a00192B", VVOU5Z="#00000000")
  else:
   self.VVgNCp("No valid lines found !", title)
 def VVad5J(self, VVDhXw, title, txt, colList):
  self.VVurxY(VVDhXw, "m3u/m3u8")
 def VVcPmN(self, bName, VVDhXw, title, txt, colList):
  FFKl3w(VVDhXw, boundFunction(self.VVPI6x, bName, VVDhXw), title="Adding Channels ...")
 def VVPI6x(self, bName, VVDhXw):
  bNameFile = CCNqVt.VVK2Qy_forBouquet(bName)
  num  = 0
  path = VV9m85 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VV9m85 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   for row in VVDhXw.VVB6yQ():
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVX6qL(rowNum, url, chName)
    rowNum += 1
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFjfIu(os.path.basename(path))
  self.VVu8L4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVX6qL(self, rowNum, url, chName):
  refCode = self.VVJOPa(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFtKtF(url), chName)
  return chUrl
 def VVJOPa(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVuoRh(catID, stID, chNum)
  return refCode
 def VVIHED(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVeIMg(self, Title, VVDhXw, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFKl3w(VVDhXw, boundFunction(self.VVOcWM, Title, VVDhXw, colList), title="Checking Server ...")
  else:
   self.VVBBj8(VVDhXw, url, chName)
 def VVOcWM(self, title, VVDhXw, colList):
  if not CCIF1Z.VV4mkm(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCr6oH.VVIqlT(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVw8eP = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCNqVt.VVuqrM(url, fPath)
     VVw8eP.append((resol, fullUrl))
    if VVw8eP:
     if len(VVw8eP) > 1:
      FF7Bt5(self, boundFunction(self.VVaxnA, VVDhXw, chName), VVw8eP=VVw8eP, title="Resolution", VVPsXE=True, VVqGaJ=True)
     else:
      self.VVBBj8(VVDhXw, VVw8eP[0][1], chName)
    else:
     self.VVoTpoor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVuXx1(txt, filterGroup="")
      return
    self.VVBBj8(VVDhXw, url, chName)
   else:
    self.VVgNCp("Cannot process this channel !", title)
  else:
   self.VVgNCp(err, title)
 def VVaxnA(self, VVDhXw, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVBBj8(VVDhXw, resolUrl, chName)
 def VVBBj8(self, VVDhXw, url, chName):
  FFKl3w(VVDhXw, boundFunction(self.VVHysT, VVDhXw, url, chName), title="Playing ...")
 def VVHysT(self, VVDhXw, url, chName):
  chUrl = self.VVX6qL(VVDhXw.VVynuF(), url, chName)
  FFaA9c(self, chUrl, VVNAZj=False)
  self.session.open(CC9DjN, portalTableParam=(self, VVDhXw, "m3u/m3u8"))
 def VVIBhG(self, VVDhXw, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVX6qL(VVDhXw.VVynuF(), url, chName)
  return chName, chUrl
 def VVA46m(self, VVDhXw, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFgbQa(self, fncMode=CCPltO.VVmzK6, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVgNCp(self, err, title):
  FFc88f(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVWfoN(self, VVDhXw):
  if self.m3uOrM3u8File:
   self.close()
  VVDhXw.cancel()
 def VVci6g(self, VVWZQiObj, item=None):
  FFKl3w(VVWZQiObj, boundFunction(self.VVVhWn, VVWZQiObj, item))
 def VVVhWn(self, VVWZQiObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVWZQiObj.VVw8eP):
    path = item[1]
    if fileExists(path):
     enc = FFPUkJ(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVSMaQ(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCNqVt.VVrNii(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFnEIN())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVWZQiObj.VVw8eP)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFVxvP(self, txt, title=title)
   else:
    FFc88f(self, "Could not obtain URLs from this file list !", title=title)
 def VVL1up(self):
  path = CCNqVt.VVrNii()
  lines = FFgPQo('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFYGMZ(1)))
  if lines:
   lines.sort()
   VVw8eP = []
   for line in lines:
    VVw8eP.append((line, line))
   OKBtnFnc = self.VVgZLu
   VVjOnb = ("Delete File", boundFunction(self.VVTSpW, boundFunction(FFKl3w, self, self.VVL1up, title="Searching ...")))
   FF7Bt5(self, None, title="Select Playlist File", VVw8eP=VVw8eP, width=1200, OKBtnFnc=OKBtnFnc, VVjOnb=VVjOnb)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFc88f(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVgZLu(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFKl3w(menuInstance, boundFunction(self.VVKae0, menuInstance, path), title="Processing File ...")
 def VVKae0(self, fileMenuInstance, path):
  enc = FFPUkJ(path, self)
  if enc == -1:
   return
  VV5w32 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF1ZUc(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCNqVt.VVYQ9s(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV5w32:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV5w32.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV5w32:
   title = "Playlist File"
   VV2zCi  = ("Start"    , boundFunction(self.VVNawt, title)  , [])
   VVJGeM = ("Home Menu"   , FFfnA1         , [])
   VVicyB = ("Download M3U File" , self.VVuLdn     , [])
   VV6rfs = ("Edit File"   , boundFunction(self.VVcpdQ, path) , [])
   VVtvPm = ("Check & Filter"  , boundFunction(self.VVzbXU, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVSgvw  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFS01Q(self, None, title=title, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VVJGeM=VVJGeM, VVtvPm=VVtvPm, VVicyB=VVicyB, VV6rfs=VV6rfs, VVRFto="#11001116", VVHhCo="#11001116", VVYhbt="#11001116", VVOU5Z="#00003635", VVD2dA="#0a333333", VVw0pN="#11331100", VVjrzO=True)
  else:
   FFc88f(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVuLdn(self, VVDhXw, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFfK5z(self, boundFunction(FFKl3w, VVDhXw, boundFunction(self.VV6Cfj, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV6Cfj(self, title, url):
  path, err = FFPEOO(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFc88f(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFzVLg(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFK72g("rm -f '%s'" % path))
    FFc88f(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFK72g("rm -f '%s'" % path))
    FFc88f(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCNqVt.VVrNii(orExportPath=True) + fName
    os.system(FFK72g("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF1ATN(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFc88f(self, "Could not download the M3U file!", title=errTitle)
 def VVNawt(self, Title, VVDhXw, title, txt, colList):
  url = colList[6]
  FFKl3w(VVDhXw, boundFunction(self.VVfiIq, Title, url), title="Checking Server ...")
 def VVcpdQ(self, path, VVDhXw, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCFIrc(self, path, VVOm4z=boundFunction(self.VV13n1, VVDhXw), curRowNum=rowNum)
  else    : FFOr2O(self, path)
 def VV13n1(self, VVDhXw, fileChanged):
  if fileChanged:
   VVDhXw.cancel()
 def VVoqa0(self, title):
  curChName = self.VVDhXw.VVLIgd(1)
  FFTT6y(self, boundFunction(self.VViIjO, title), defaultText=curChName, title=title, message="Enter Name:")
 def VViIjO(self, title, name):
  if name:
   lameDbChans = CCUJnZ.VVBpsi(self, CCUJnZ.VVqD2E, VVtrf6=False, VV5UFy=False)
   list = []
   if lameDbChans:
    processChanName = CC3a1j()
    name = processChanName.VVjp79(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFJJD0(item[2]), item[3], ratio))
   if list : self.VVs3dm(list, title)
   else : FFc88f(self, "Not found:\n\n%s" % name, title=title)
 def VVCOKP(self, title):
  curChName = self.VVDhXw.VVLIgd(1)
  self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVZScq
      , VVOm4z = boundFunction(self.VVs3cu, title, curChName))
 def VVZScq(self, progBarObj):
  curChName = self.VVDhXw.VVLIgd(1)
  lameDbChans = CCUJnZ.VVBpsi(self, CCUJnZ.VVVYOT, VVtrf6=False, VV5UFy=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVwCH6 = []
  progBarObj.VVQ1QY(len(lameDbChans))
  processChanName = CC3a1j()
  curCh = processChanName.VVjp79(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCvG1x.VVw0Sj(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVUkc0(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVwCH6.append((chName, FFJJD0(sat), refCode.replace("_", ":"), str(ratio)))
 def VVs3cu(self, title, curChName, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  if VVwCH6: self.VVs3dm(VVwCH6, title)
  elif VVxVJy: FFc88f(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVs3dm(self, VV5w32, title):
  curChName = self.VVDhXw.VVLIgd(1)
  curRefCode = self.VVDhXw.VVLIgd(4)
  curUrl  = self.VVDhXw.VVLIgd(5)
  VV5w32 = sorted(VV5w32, key=lambda x: (100-int(x[3]), x[0].lower()))
  VV2zCi  = ("Share Sat/C/T Ref.", boundFunction(self.VVMvBx, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFS01Q(self, None, title=title, header=header, VVNz0H=VV5w32, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VVRFto="#0a00112B", VVHhCo="#0a001126", VVYhbt="#0a001126", VVOU5Z="#00000000")
 def VVMvBx(self, newtitle, curChName, curRefCode, curUrl, VVDhXw, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFfK5z(self.VVDhXw, boundFunction(FFKl3w, self.VVDhXw, boundFunction(self.VVex0X, VVDhXw, data)), ques, title=newtitle, VVPjh4=True)
 def VVex0X(self, VVDhXw, data):
  VVDhXw.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVJnMl():
    txt = FFzVLg(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFikPN()
    newRow = []
    for i in range(6):
     newRow.append(self.VVDhXw.VVLIgd(i))
    newRow[4] = newRefCode
    done = self.VVDhXw.VV9aPB(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFlxSW(boundFunction(FF1ATN , self, resTxt, title=title))
  elif resErr: FFlxSW(boundFunction(FFc88f , self, resErr, title=title))
 def VVzbXU(self, fileMenuInstance, path, VVDhXw, title, txt, colList):
  self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVVcML, VVDhXw)
      , VVOm4z = boundFunction(self.VVtCDp, fileMenuInstance, path, VVDhXw))
 def VVVcML(self, VVDhXw, progBarObj):
  progBarObj.VVQ1QY(VVDhXw.VVYQpG())
  progBarObj.VVwCH6 = []
  for row in VVDhXw.VVB6yQ():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVUkc0(1, True)
   qUrl = self.VV1ERG(self.VVxxiC, row[6])
   txt, err = self.VVcc2w(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVU0Bn(item, "auth") == "0":
       progBarObj.VVwCH6.append(qUrl)
    except:
     pass
 def VVtCDp(self, fileMenuInstance, path, VVDhXw, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  if VVxVJy:
   list = VVwCH6
   title = "Authorized Servers"
   if list:
    totChk = VVDhXw.VVYQpG()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFnEIN()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVL1up()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFkGYB(str(totAuth), VVfxXg)
     txt += "%s\n\n%s"    %  (FFkGYB("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFVxvP(self, txt, title=title)
     VVDhXw.close()
     fileMenuInstance.close()
    else:
     FF1ATN(self, "All URLs are authorized.", title=title)
   else:
    FFc88f(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVcc2w(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVYQ9s(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVXjzP(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VV1ERG(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVYQ9s(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVxxiC   : return "%s"            % url
  elif mode == self.VVP9Iw   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVPvM2   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVaG6v  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVYeMD  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVOldp : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVBrrs   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVd1oR    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVzCE5  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVaIDt : return "%s&action=get_live_streams"      % url
  elif mode == self.VVW6tB  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVU0Bn(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF7tZn(int(val))
    elif is_base64 : val = FFrGRP(val)
    elif isToHHMMSS : val = FFcGNd(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV0V9y(self, title, path):
  if fileExists(path):
   enc = FFPUkJ(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVSMaQ(line)
     if qUrl:
      break
   if qUrl : self.VVfiIq(title, qUrl)
   else : FFc88f(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFc88f(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVSHzp_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVvIGM()
  if qUrl:
   host, mac, isPortalUrl = self.VVohA1(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVSHzp(self, host, mac)
    else   : FFc88f(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFKl3w(self, boundFunction(self.VVfiIq, title, qUrl), title="Checking Server ...")
  else:
   FFc88f(self, "Error in current channel URL !", title=title)
 def VVvIGM(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  qUrl = self.VVSMaQ(decodedUrl)
  return qUrl, iptvRef
 def VVSMaQ(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVfiIq(self, title, url):
  self.VVEvpjData = {}
  qUrl = self.VV1ERG(self.VVxxiC, url)
  txt, err = self.VVcc2w(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVEvpjData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVEvpjData["username"    ] = self.VVU0Bn(item, "username"        )
    self.VVEvpjData["password"    ] = self.VVU0Bn(item, "password"        )
    self.VVEvpjData["message"    ] = self.VVU0Bn(item, "message"        )
    self.VVEvpjData["auth"     ] = self.VVU0Bn(item, "auth"         )
    self.VVEvpjData["status"    ] = self.VVU0Bn(item, "status"        )
    self.VVEvpjData["exp_date"    ] = self.VVU0Bn(item, "exp_date"    , isDate=True )
    self.VVEvpjData["is_trial"    ] = self.VVU0Bn(item, "is_trial"        )
    self.VVEvpjData["active_cons"   ] = self.VVU0Bn(item, "active_cons"       )
    self.VVEvpjData["created_at"   ] = self.VVU0Bn(item, "created_at"   , isDate=True )
    self.VVEvpjData["max_connections"  ] = self.VVU0Bn(item, "max_connections"      )
    self.VVEvpjData["allowed_output_formats"] = self.VVU0Bn(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVEvpjData[key] = lst
    item = tDict["server_info"]
    self.VVEvpjData["url"    ] = self.VVU0Bn(item, "url"        )
    self.VVEvpjData["port"    ] = self.VVU0Bn(item, "port"        )
    self.VVEvpjData["https_port"  ] = self.VVU0Bn(item, "https_port"      )
    self.VVEvpjData["server_protocol" ] = self.VVU0Bn(item, "server_protocol"     )
    self.VVEvpjData["rtmp_port"   ] = self.VVU0Bn(item, "rtmp_port"       )
    self.VVEvpjData["timezone"   ] = self.VVU0Bn(item, "timezone"       )
    self.VVEvpjData["timestamp_now"  ] = self.VVU0Bn(item, "timestamp_now"  , isDate=True )
    self.VVEvpjData["time_now"   ] = self.VVU0Bn(item, "time_now"       )
    VVw8eP  = self.VVStsI(True)
    OKBtnFnc = self.VVEvpjOptions
    VVjOJ6 = ("Home Menu", FFfnA1)
    VVzZGK = ("Bookmark Server", boundFunction(CCNqVt.VVVHaw, self, False, self.VVEvpjData["playListURL"]))
    FF7Bt5(self, None, title="IPTV Server Resources", VVw8eP=VVw8eP, OKBtnFnc=OKBtnFnc, VVjOJ6=VVjOJ6, VVzZGK=VVzZGK)
   else:
    err = "Could not get data from server !"
  if err:
   FFc88f(self, err, title=title)
  FF4n96(self)
 def VVEvpjOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFKl3w(menuInstance, boundFunction(self.VVI6hB, self.VVP9Iw  , title=title), title=wTxt)
   elif ref == "vod"   : FFKl3w(menuInstance, boundFunction(self.VVI6hB, self.VVPvM2  , title=title), title=wTxt)
   elif ref == "series"  : FFKl3w(menuInstance, boundFunction(self.VVI6hB, self.VVaG6v , title=title), title=wTxt)
   elif ref == "catchup"  : FFKl3w(menuInstance, boundFunction(self.VVI6hB, self.VVYeMD , title=title), title=wTxt)
   elif ref == "accountInfo" : FFKl3w(menuInstance, boundFunction(self.VVniZW           , title=title), title=wTxt)
 def VVniZW(self, title):
  rows = []
  for key, val in self.VVEvpjData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVJGeM = ("Home Menu", FFfnA1, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFS01Q(self, None, title=title, width=1200, header=header, VVNz0H=rows, VVTy8n=widths, VVjgTX=26, VVJGeM=VVJGeM, VVRFto="#0a00292B", VVHhCo="#0a002126", VVYhbt="#0a002126", VVOU5Z="#00000000", searchCol=2)
 def VVdJpt(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CC3a1j()
    if mode in (self.VVBrrs, self.VVW6tB):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVU0Bn(item, "num"         )
      name     = self.VVU0Bn(item, "name"        )
      stream_id    = self.VVU0Bn(item, "stream_id"       )
      stream_icon    = self.VVU0Bn(item, "stream_icon"       )
      epg_channel_id   = self.VVU0Bn(item, "epg_channel_id"      )
      added     = self.VVU0Bn(item, "added"    , isDate=True )
      is_adult    = self.VVU0Bn(item, "is_adult"       )
      category_id    = self.VVU0Bn(item, "category_id"       )
      tv_archive    = self.VVU0Bn(item, "tv_archive"       )
      name = processChanName.VVHFwm(name)
      if name:
       if mode == self.VVBrrs or mode == self.VVW6tB and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVd1oR:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVU0Bn(item, "num"         )
      name    = self.VVU0Bn(item, "name"        )
      stream_id   = self.VVU0Bn(item, "stream_id"       )
      stream_icon   = self.VVU0Bn(item, "stream_icon"       )
      added    = self.VVU0Bn(item, "added"    , isDate=True )
      is_adult   = self.VVU0Bn(item, "is_adult"       )
      category_id   = self.VVU0Bn(item, "category_id"       )
      container_extension = self.VVU0Bn(item, "container_extension"     ) or "mp4"
      name = processChanName.VVHFwm(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVzCE5:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVU0Bn(item, "num"        )
      name    = self.VVU0Bn(item, "name"       )
      series_id   = self.VVU0Bn(item, "series_id"      )
      cover    = self.VVU0Bn(item, "cover"       )
      genre    = self.VVU0Bn(item, "genre"       )
      episode_run_time = self.VVU0Bn(item, "episode_run_time"    )
      category_id   = self.VVU0Bn(item, "category_id"      )
      container_extension = self.VVU0Bn(item, "container_extension"    ) or "mp4"
      name = processChanName.VVHFwm(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVI6hB(self, mode, title):
  cList, err = self.VVu5Zh(mode)
  if cList and mode == self.VVYeMD:
   cList = self.VVZYpM(cList)
  if err:
   FFc88f(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A(mode)
   mName = self.VVxS4B(mode)
   if   mode == self.VVP9Iw  : fMode = self.VVBrrs
   elif mode == self.VVPvM2  : fMode = self.VVd1oR
   elif mode == self.VVaG6v : fMode = self.VVzCE5
   elif mode == self.VVYeMD : fMode = self.VVW6tB
   if mode == self.VVYeMD:
    VV6rfs = None
   else:
    VV6rfs = ("Find in %s" % mName , boundFunction(self.VVITPz, fMode) , [])
   VV2zCi   = ("Show List"   , boundFunction(self.VVKMCN, mode) , [])
   VVJGeM  = ("Home Menu"   , FFfnA1          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFS01Q(self, None, title=title, width=1200, header=header, VVNz0H=cList, VVTy8n=widths, VVjgTX=30, VVJGeM=VVJGeM, VV6rfs=VV6rfs, VV2zCi=VV2zCi, VVRFto=VVRFto, VVHhCo=VVHhCo, VVYhbt=VVYhbt, VVOU5Z=VVOU5Z)
  else:
   FFc88f(self, "No list from server !", title=title)
  FF4n96(self)
 def VVu5Zh(self, mode):
  qUrl  = self.VV1ERG(mode, self.VVEvpjData["playListURL"])
  txt, err = self.VVcc2w(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CC3a1j()
    for item in tDict:
     category_id  = self.VVU0Bn(item, "category_id"  )
     category_name = self.VVU0Bn(item, "category_name" )
     parent_id  = self.VVU0Bn(item, "parent_id"  )
     category_name = processChanName.VVnjxC(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVZYpM(self, catList):
  mode  = self.VVW6tB
  qUrl  = self.VV1ERG(mode, self.VVEvpjData["playListURL"])
  txt, err = self.VVcc2w(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVdJpt(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVKMCN(self, mode, VVDhXw, title, txt, colList):
  title = colList[1]
  FFKl3w(VVDhXw, boundFunction(self.VVRGB1, mode, VVDhXw, title, txt, colList), title="Downloading ...")
 def VVRGB1(self, mode, VVDhXw, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVxS4B(mode) + " : "+ bName
  if   mode == self.VVP9Iw  : mode = self.VVBrrs
  elif mode == self.VVPvM2  : mode = self.VVd1oR
  elif mode == self.VVaG6v : mode = self.VVzCE5
  elif mode == self.VVYeMD : mode = self.VVW6tB
  qUrl  = self.VV1ERG(mode, self.VVEvpjData["playListURL"], catID)
  txt, err = self.VVcc2w(qUrl)
  list  = []
  if not err and mode in (self.VVBrrs, self.VVd1oR, self.VVzCE5, self.VVW6tB):
   list, err = self.VVdJpt(mode, txt)
  if err:
   FFc88f(self, err, title=title)
  elif list:
   VVJGeM  = ("Home Menu"   , FFfnA1             , [])
   if mode in (self.VVBrrs, self.VVW6tB):
    VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A(mode)
    VV2kYm = (""     , boundFunction(self.VVh2Ry, mode)     , [])
    VVicyB = ("Download Options" , boundFunction(self.VVjWVH, mode, "", "")  , [])
    VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVur38, mode, bName)  , [])
    if mode == self.VVBrrs:
     VV2zCi = ("Play"    , boundFunction(self.VVGwqf, mode)     , [])
    elif mode == self.VVW6tB:
     VV2zCi  = ("Programs", boundFunction(self.VVaJFM_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVSgvw  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVd1oR:
    VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A(mode)
    VV2zCi  = ("Play"    , boundFunction(self.VVGwqf, mode)    , [])
    VV2kYm = (""     , boundFunction(self.VVh2Ry, mode)    , [])
    VVicyB = ("Download Options" , boundFunction(self.VVjWVH, mode, "v", ""), [])
    VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVur38, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVSgvw  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVzCE5:
    VVRFto, VVHhCo, VVYhbt, VVOU5Z = self.VV5p8A("series2")
    VV2zCi  = ("Show Seasons", boundFunction(self.VVoact, mode) , [])
    VV2kYm = ("", boundFunction(self.VVHSWB, mode)  , [])
    VVicyB = None
    VV6rfs = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVSgvw  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFS01Q(self, None, title=title, header=header, VVNz0H=list, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VV2kYm=VV2kYm, VVRFto=VVRFto, VVHhCo=VVHhCo, VVYhbt=VVYhbt, VVOU5Z=VVOU5Z, VVjrzO=True, searchCol=1)
  else:
   FFc88f(self, "No Channels found !", title=title)
  FF4n96(self)
 def VVaJFM_fromIptvTable(self, mode, bName, VVDhXw, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVEvpjData["playListURL"]
  ok_fnc  = boundFunction(self.VVOSWl, hostUrl, chName, catId, streamId)
  FFKl3w(VVDhXw, boundFunction(CCNqVt.VVaJFM, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVOSWl(self, chUrl, chName, catId, streamId, VVDhXw, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCNqVt.VVYQ9s(chUrl)
   chNum = "333"
   refCode = CCNqVt.VVuoRh(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFaA9c(self, chUrl, VVNAZj=False)
   self.session.open(CC9DjN)
  else:
   FFc88f(self, "Incorrect Timestamp", pTitle)
 def VVoact(self, mode, VVDhXw, title, txt, colList):
  title = colList[1]
  FFKl3w(VVDhXw, boundFunction(self.VVJs4b, mode, VVDhXw, title, txt, colList), title="Downloading ...")
 def VVJs4b(self, mode, VVDhXw, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VV1ERG(self.VVOldp, self.VVEvpjData["playListURL"], series_id)
  txt, err = self.VVcc2w(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVU0Bn(tDict["info"], "name"   )
      category_id = self.VVU0Bn(tDict["info"], "category_id" )
      icon  = self.VVU0Bn(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVU0Bn(EP, "id"     )
        episode_num   = self.VVU0Bn(EP, "episode_num"   )
        epTitle    = self.VVU0Bn(EP, "title"     )
        container_extension = self.VVU0Bn(EP, "container_extension" )
        seasonNum   = self.VVU0Bn(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFc88f(self, err, title=title)
  elif list:
   VVJGeM = ("Home Menu"   , FFfnA1             , [])
   VVicyB = ("Download Options" , boundFunction(self.VVjWVH, mode, "s", title) , [])
   VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVur38, mode, title)  , [])
   VV2kYm = (""     , boundFunction(self.VVh2Ry, mode)     , [])
   VV2zCi  = ("Play"    , boundFunction(self.VVGwqf, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVSgvw  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFS01Q(self, None, title=title, header=header, VVNz0H=list, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VVJGeM=VVJGeM, VVicyB=VVicyB, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VV6rfs=VV6rfs, VVRFto="#0a00292B", VVHhCo="#0a002126", VVYhbt="#0a002126", VVOU5Z="#00000000")
  else:
   FFc88f(self, "No Channels found !", title=title)
  FF4n96(self)
 def VVITPz(self, mode, VVDhXw, title, txt, colList):
  VVw8eP = []
  VVw8eP.append(("Keyboard"  , "manualEntry"))
  VVw8eP.append(("From Filter" , "fromFilter"))
  FF7Bt5(self, boundFunction(self.VVKgaW, VVDhXw, mode), title="Input Type", VVw8eP=VVw8eP, width=400)
 def VVKgaW(self, VVDhXw, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFTT6y(self, boundFunction(self.VVeoQ8, VVDhXw, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC09mD(self)
    filterObj.VVU6jv(boundFunction(self.VVeoQ8, VVDhXw, mode))
 def VVeoQ8(self, VVDhXw, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CC3a1j()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VV60KL(words):
     FFc88f(self, processChanName.VV5Zs5(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVgRkB, VVDhXw, mode, title, words, toFind, asPrefix, processChanName)
         , VVOm4z = boundFunction(self.VV3z2k, mode, toFind, title))
   else:
    FFc88f(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVgRkB(self, VVDhXw, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVQ1QY(VVDhXw.VVljsD())
  progBarObj.VVwCH6 = []
  for row in VVDhXw.VVB6yQ():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVUkc0(1)
   progBarObj.VVUdJZ_fromIptvFind(catName)
   qUrl  = self.VV1ERG(mode, self.VVEvpjData["playListURL"], catID)
   txt, err = self.VVcc2w(qUrl)
   if not err:
    tList, err = self.VVdJpt(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVHFwm(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVBrrs:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVwCH6.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVd1oR:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVwCH6.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVzCE5:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVwCH6.append((num, name, catID, ID, genre, catName, ext, cover))
 def VV3z2k(self, mode, toFind, title, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  if VVwCH6:
   title = self.VVSS12(mode, toFind)
   if mode == self.VVBrrs or mode == self.VVd1oR:
    if mode == self.VVd1oR : typ = "v"
    else          : typ = ""
    bName   = CCNqVt.VVK2Qy_forBouquet(toFind)
    VV2zCi  = ("Play"     , boundFunction(self.VVGwqf, mode)    , [])
    VVicyB = ("Download Options" , boundFunction(self.VVjWVH, mode, typ, ""), [])
    VV6rfs = ("Add ALL to Bouquet" , boundFunction(self.VVur38, mode, bName) , [])
   elif mode == self.VVzCE5:
    VV2zCi  = ("Show Seasons"  , boundFunction(self.VVoact, mode)    , [])
    VV6rfs = None
    VVicyB = None
   VV2kYm  = (""     , boundFunction(self.VVh2Ry, mode)    , [])
   VVJGeM  = ("Home Menu"   , FFfnA1            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVSgvw  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVDhXw = FFS01Q(self, None, title=title, header=header, VVNz0H=VVwCH6, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VV2kYm=VV2kYm, VVRFto="#0a00292B", VVHhCo="#0a002126", VVYhbt="#0a002126", VVOU5Z="#00000000", VVjrzO=True, searchCol=1)
   if not VVxVJy:
    FF4n96(VVDhXw, "Stopped" , 1000)
  else:
   if VVxVJy:
    FFc88f(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVMjra(self, mode, colList):
  if mode in (self.VVBrrs, self.VVW6tB):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVd1oR:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFtG6X(chName)
  url = self.VVEvpjData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVYQ9s(url)
  refCode = self.VVuoRh(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVh2Ry(self, mode, VVDhXw, title, txt, colList):
  FFKl3w(VVDhXw, boundFunction(self.VVkfYn, mode, VVDhXw, title, txt, colList))
 def VVkfYn(self, mode, VVDhXw, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVMjra(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFgbQa(self, fncMode=CCPltO.VVwf5n, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVHSWB(self, mode, VVDhXw, title, txt, colList):
  FFKl3w(VVDhXw, boundFunction(self.VVxMcN, mode, VVDhXw, title, txt, colList))
 def VVxMcN(self, mode, VVDhXw, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFgbQa(self, fncMode=CCPltO.VVCWsd, chName=name, text=txt, picUrl=Cover)
 def VVur38(self, mode, bName, VVDhXw, title, txt, colList):
  FFKl3w(VVDhXw, boundFunction(self.VVPi11, mode, bName, VVDhXw, title, txt, colList), title="Adding Channels ...")
 def VVPi11(self, mode, bName, VVDhXw, title, txt, colList):
  url = self.VVEvpjData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVYQ9s(url)
  bNameFile = CCNqVt.VVK2Qy_forBouquet(bName)
  num  = 0
  path = VV9m85 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VV9m85 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVDhXw.VVB6yQ():
    chName, chUrl, picUrl, refCode = self.VVMjra(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFjfIu(os.path.basename(path))
  self.VVu8L4(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVjWVH(self, mode, typ, seriesName, VVDhXw, title, txt, colList):
  VVw8eP = []
  VVw8eP.append(("Download all PIcons"       , "dnldPicons" ))
  if typ:
   VVw8eP.append(VV9e5C)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVw8eP.append(("Download Selected %s" % tName    , "dnldSel"  ))
   VVw8eP.append(("Add Selected %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVw8eP.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCaDOu.VVBRy7():
    VVw8eP.append(VV9e5C)
    VVw8eP.append(("Download Manager"      , "dload_stat" ))
  FF7Bt5(self, boundFunction(self.VVZSWM_VVujt1, VVDhXw, mode, typ, seriesName, colList), title="Download Options", VVw8eP=VVw8eP)
 def VVZSWM_VVujt1(self, VVDhXw, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVurxY(VVDhXw, mode)
   elif item == "dnldSel"  : self.VVMfDc(VVDhXw, mode, typ, colList, True)
   elif item == "addSel"  : self.VVMfDc(VVDhXw, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVoRGR(VVDhXw, mode, typ, seriesName)
   elif item == "dload_stat" : CCaDOu.VVqHnS(self)
 def VVMfDc(self, VVDhXw, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVKLHM(mode, typ, colList)
  if startDnld:
   CCaDOu.VVPAU4_url(self, decodedUrl)
  else:
   self.VVujt1_FFfK5z(VVDhXw, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVoRGR(self, VVDhXw, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVDhXw.VVB6yQ():
   chName, decodedUrl = self.VVKLHM(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVujt1_FFfK5z(VVDhXw, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVujt1_FFfK5z(self, VVDhXw, title, chName, decodedUrl_list, startDnld):
  FFfK5z(self, boundFunction(self.VVbPLq, VVDhXw, decodedUrl_list, startDnld), chName, title=title)
 def VVbPLq(self, VVDhXw, decodedUrl_list, startDnld):
  added, skipped = CCaDOu.VVsa5sList(decodedUrl_list)
  FF4n96(VVDhXw, "Added", 1000)
 def VVKLHM(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVMjra(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVsVMz(mode, colList)
   refCode, chUrl = self.VVI7mj(self.VVvtDi, self.VVXVNc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFCoVU(chUrl)
  return chName, decodedUrl
 def VVurxY(self, VVDhXw, mode):
  if os.system(FFK72g("which ffmpeg")) == 0:
   self.session.open(CCC5nR, barTheme=CCC5nR.VVEGAJ
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVNmzx, VVDhXw, mode)
       , VVOm4z = self.VVWuJH)
  else:
   FFfK5z(self, boundFunction(CCNqVt.VVP1UP, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVWuJH(self, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVwCH6["proces"], VVwCH6["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVwCH6["ok"], VVwCH6["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVwCH6["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVwCH6["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVwCH6["badURL"]
  txt += "Download Failure\t: %d\n"   % VVwCH6["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVwCH6["path"]
  if not VVxVJy  : color = "#11402000"
  elif VVwCH6["err"]: color = "#11201000"
  else     : color = None
  if VVwCH6["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVwCH6["err"], txt)
  title = "PIcons Download Result"
  if not VVxVJy:
   title += "  (cancelled)"
  FFVxvP(self, txt, title=title, VVYhbt=color)
 def VVNmzx(self, VVDhXw, mode, progBarObj):
  totRows = VVDhXw.VVljsD()
  progBarObj.VVQ1QY(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCvG1x.VVulgY()
  progBarObj.VVwCH6 = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVDhXw.VVB6yQ()):
    if progBarObj.isCancelled:
     break
    progBarObj.VVwCH6["proces"] += 1
    progBarObj.VVUkc0(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVsVMz(mode, row)
     refCode = CCNqVt.VVuoRh(catID, stID, chNum)
    elif mode == "m3u/m3u8":
     chName = row[1].strip()
     url  = row[3].strip()
     picUrl = row[4].strip()
     refCode = self.VVJOPa(rowNum, url, chName)
    else:
     chName, chUrl, picUrl, refCode = self.VVMjra(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVwCH6["attempt"] += 1
      path, err = FFPEOO(picUrl, picon, timeout=1, mustBeImage=True)
      if path:
       progBarObj.VVwCH6["ok"] += 1
       if FFCOks(path) > 0:
        cmd = ""
        if not mode == CCNqVt.VVBrrs:
         cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
        cmd += FFK72g("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVwCH6["size0"] += 1
        os.system(FFK72g("rm -f '%s'" % path))
      elif err:
       progBarObj.VVwCH6["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVwCH6["err"] = err.title()
        break
     else:
      progBarObj.VVwCH6["exist"] += 1
    else:
     progBarObj.VVwCH6["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVP1UP(SELF):
  cmd = FFp0JH(VVggHo, "ffmpeg")
  if cmd : FFypV6(SELF, cmd, title="Installing FFmpeg")
  else : FFdCT7(SELF)
 def VVwS1I(self):
  self.session.open(CCC5nR, barTheme=CCC5nR.VVEGAJ
      , titlePrefix = ""
      , fncToRun  = self.VVptD7
      , VVOm4z = self.VVWDxY)
 def VVptD7(self, progBarObj):
  bName = FFkzXS()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVwCH6 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFtBXK()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVQ1QY(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVUkc0(1)
    progBarObj.VVUdJZ_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FF7z8Z(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFCoVU(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCr6oH.VVSgRo(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCNqVt.VVXjzP(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCNqVt.VVXjzP(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCNqVt.VVXjzP(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCNqVt.VVopAs(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCPltO.VVcHJh(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVwCH6 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVwCH6 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVWDxY(self, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVwCH6
  title = "IPTV EPG Import"
  if err:
   FFc88f(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFkGYB(str(totNotIptv), VVtUnE)
    if totServErr : txt += "Server Errors\t: %s\n" % FFkGYB(str(totServErr) + t1, VVtUnE)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFkGYB(str(totInv), VVtUnE)
   if not VVxVJy:
    title += "  (stopped)"
   FFVxvP(self, txt, title=title)
 @staticmethod
 def VVopAs(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCNqVt.VVYQ9s(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCNqVt.VVcc2w(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCNqVt.VVU0Bn(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCNqVt.VVU0Bn(item, "has_archive"      )
    lang    = CCNqVt.VVU0Bn(item, "lang"        ).upper()
    now_playing   = CCNqVt.VVU0Bn(item, "now_playing"      )
    start    = CCNqVt.VVU0Bn(item, "start"        )
    start_timestamp  = CCNqVt.VVU0Bn(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCNqVt.VVU0Bn(item, "start_timestamp"     )
    stop_timestamp  = CCNqVt.VVU0Bn(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCNqVt.VVU0Bn(item, "stop_timestamp"      )
    tTitle    = CCNqVt.VVU0Bn(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVuoRh(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCNqVt.VVUJtJ(catID, MAX_4b)
  TSID = CCNqVt.VVUJtJ(chNum, MAX_4b)
  ONID = CCNqVt.VVUJtJ(chNum, MAX_4b)
  NS  = CCNqVt.VVUJtJ(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVUJtJ(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVK2Qy_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VV5p8A(mode):
  if   mode in ("itv"  , CCNqVt.VVP9Iw)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCNqVt.VVPvM2)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCNqVt.VVaG6v) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCNqVt.VVYeMD) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCNqVt.VVW6tB    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVrNii(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVZnKC:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FF1ZUc(path)
 @staticmethod
 def VVaJFM(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCNqVt.VVopAs(hostUrl, streamId, True)
  if err:
   FFc88f(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVRFto, VVHhCo, VVYhbt, VVOU5Z = CCNqVt.VV5p8A("")
   VVJGeM = ("Home Menu" , FFfnA1, [])
   VV2zCi  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVSgvw  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFS01Q(SELF, None, title="Programs for : " + chName, header=header, VVNz0H=pList, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=24, VV2zCi=VV2zCi, VVJGeM=VVJGeM, VVRFto=VVRFto, VVHhCo=VVHhCo, VVYhbt=VVYhbt, VVOU5Z=VVOU5Z)
  else:
   FFc88f(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVuqrM(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVVHaw(SELF, isPortal, line, VVWZQiObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCNqVt.VVrNii(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with open(path, "r") as f:
     for fLine in f:
      if line in fLine:
       FFc88f(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF1ATN(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFc88f(SELF, "Error:\n\n%s" % str(e), title=title)
class CCD9yx(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFAEOm(VVEShK, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVgdJX  = 0
  self.VVu33e = 1
  self.VVLMED  = 2
  VVw8eP = []
  VVw8eP.append(("Find in All Service (from filter)" , "VVIPJy" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Find in All (Manual Entry)"   , "VVQlur"    ))
  VVw8eP.append(("Find in TV"       , "VV7rK5"    ))
  VVw8eP.append(("Find in Radio"      , "VVzuhV"   ))
  if self.VVoL8f():
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Hide Channel: %s" % self.servName , "VV4onU"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Zap History"       , "VVjlEG"    ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("IPTV Tools"       , "iptv"      ))
  VVw8eP.append(("PIcons Tools"       , "PIconsTools"     ))
  VVw8eP.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFSF9U(self, VVw8eP=VVw8eP, title=title)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
  if self.isFindMode:
   self.VVhJCH(self.VVQjnc())
 def VVhKHG(self):
  global VVXkf5
  VVXkf5 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVQlur"    : self.VVQlur()
   elif item == "VVIPJy" : self.VVIPJy()
   elif item == "VV7rK5"    : self.VV7rK5()
   elif item == "VVzuhV"   : self.VVzuhV()
   elif item == "VV4onU"   : self.VV4onU()
   elif item == "VVjlEG"    : self.VVjlEG()
   elif item == "iptv"       : self.session.open(CCNqVt)
   elif item == "PIconsTools"     : self.session.open(CCvG1x)
   elif item == "ChannelsTools"    : self.session.open(CCUJnZ)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV7rK5(self) : self.VVhJCH(self.VVgdJX)
 def VVzuhV(self) : self.VVhJCH(self.VVu33e)
 def VVQlur(self) : self.VVhJCH(self.VVLMED)
 def VVhJCH(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFTT6y(self, boundFunction(self.VVXKDg, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVIPJy(self):
  filterObj = CC09mD(self)
  filterObj.VVU6jv(self.VVQwQJ)
 def VVQwQJ(self, item):
  self.VVXKDg(self.VVLMED, item)
 def VVoL8f(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF7z8Z(self.refCode)        : return False
  return True
 def VVXKDg(self, mode, VVQGE6):
  FFKl3w(self, boundFunction(self.VVZjaJ, mode, VVQGE6), title="Searching ...")
 def VVZjaJ(self, mode, VVQGE6):
  if VVQGE6:
   self.findTxt = VVQGE6
   if   mode == self.VVgdJX  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVu33e : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVQGE6)
   if len(title) > 55:
    title = title[:55] + ".."
   VV5w32 = self.VVrPeV(VVQGE6, servTypes)
   if self.isFindMode or mode == self.VVLMED:
    VV5w32 += self.VV79KC(VVQGE6)
   if VV5w32:
    VV5w32.sort(key=lambda x: x[0].lower())
    VV33pw = self.VVOHRY
    VV2zCi  = ("Zap"   , self.VVcRTl    , [])
    VVicyB = ("Current Service", self.VVZ2mH , [])
    VV6rfs = ("Options"  , self.VVtXM7 , [])
    VV2kYm = (""    , self.VV65Lc , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVSgvw  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFS01Q(self, None, title=title, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VV33pw=VV33pw, VVicyB=VVicyB, VV6rfs=VV6rfs, VV2kYm=VV2kYm)
   else:
    self.VVhJCH(self.VVQjnc())
    FF1ATN(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVrPeV(self, VVQGE6, servTypes):
  VVNfWS  = eServiceCenter.getInstance()
  VVhQ1Q   = '%s ORDER BY name' % servTypes
  VV43yi   = eServiceReference(VVhQ1Q)
  VVnMMW = VVNfWS.list(VV43yi)
  if VVnMMW: VVNz0H = VVnMMW.getContent("CN", False)
  else     : VVNz0H = None
  VV5w32 = []
  if VVNz0H:
   VVO0bf, VVEX0Z = FF8cJh()
   tp   = CCriLw()
   words, asPrefix = CC09mD.VVl1Dd(VVQGE6)
   colorYellow  = CC4LkW.VV1rCL(VVYPWI)
   colorWhite  = CC4LkW.VV1rCL(VVB0Ol)
   for s in VVNz0H:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFCJvX(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVO0bf:
        STYPE = VVEX0Z[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVTBFi(refCode)
       if not "-S" in syst:
        sat = syst
       VV5w32.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV5w32
 def VV79KC(self, VVQGE6):
  VVQGE6 = VVQGE6.lower()
  VVe6dO = FFcqwa()
  VV5w32 = []
  colorYellow  = CC4LkW.VV1rCL(VVYPWI)
  colorWhite  = CC4LkW.VV1rCL(VVB0Ol)
  if VVe6dO:
   for b in VVe6dO:
    VVYtt0  = b[0]
    VVHahg  = b[1].toString()
    VV7KNp = eServiceReference(VVHahg)
    VVfQ5S = FF2rc7(VV7KNp)
    for service in VVfQ5S:
     refCode  = service[0]
     if FF7z8Z(refCode):
      servName = service[1]
      if VVQGE6 in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVQGE6), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV5w32.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV5w32
 def VVQjnc(self):
  VV0Hqr = InfoBar.instance
  if VV0Hqr:
   VVtLl0 = VV0Hqr.servicelist
   if VVtLl0:
    return VVtLl0.mode == 1
  return self.VVLMED
 def VVOHRY(self, VVDhXw):
  self.close()
  VVDhXw.cancel()
 def VVcRTl(self, VVDhXw, title, txt, colList):
  FFaA9c(VVDhXw, colList[2], VVNAZj=False, checkParentalControl=True)
 def VVZ2mH(self, VVDhXw, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(VVDhXw)
  if refCode:
   VVDhXw.VV0DkM(2, FFw2pT(refCode, iptvRef, chName), True)
 def VVtXM7(self, VVDhXw, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCtEJp(self, VVDhXw, 2)
  mSel.VVnlEa(servName, refCode)
 def VV65Lc(self, VVDhXw, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFgbQa(self, fncMode=CCPltO.VVydv4, refCode=refCode, chName=chName, text=txt)
 def VV4onU(self):
  FFfK5z(self, self.VVpQVp, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVpQVp(self):
  ret = FFOcmO(self.refCode, True)
  if ret:
   self.VVcESv()
   self.close()
  else:
   FF4n96(self, "Cannot change state" , 1000)
 def VVcESv(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVJseG()
  except:
   self.VVGWMk()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFycMY(self, serviceRef)
 def VV1bXC(self):
  VV0Hqr = InfoBar.instance
  if VV0Hqr:
   VVtLl0 = VV0Hqr.servicelist
   if VVtLl0:
    VVtLl0.setMode()
 def VVJseG(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV0Hqr = InfoBar.instance
   if VV0Hqr:
    VVtLl0 = VV0Hqr.servicelist
    if VVtLl0:
     hList = VVtLl0.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVtLl0.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVtLl0.history  = newList
       VVtLl0.history_pos = pos
 def VVGWMk(self):
  VV0Hqr = InfoBar.instance
  if VV0Hqr:
   VVtLl0 = VV0Hqr.servicelist
   if VVtLl0:
    VVtLl0.history  = []
    VVtLl0.history_pos = 0
 def VVjlEG(self):
  VV0Hqr = InfoBar.instance
  VV5w32 = []
  if VV0Hqr:
   VVtLl0 = VV0Hqr.servicelist
   if VVtLl0:
    VVO0bf, VVEX0Z = FF8cJh()
    for chParams in VVtLl0.history:
     refCode = chParams[-1].toString()
     chName = FFMgu7(refCode)
     isIptv = FF7z8Z(refCode)
     if isIptv: sat = "-"
     else  : sat = FFCJvX(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVO0bf:
       STYPE = VVEX0Z[sTypeInt]
     VV5w32.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV5w32:
   VV2zCi  = ("Zap"   , self.VV5iaM   , [])
   VV6rfs = ("Clear History" , self.VV8A5E   , [])
   VV2kYm = (""    , self.VVTiiHFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVSgvw  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFS01Q(self, None, title=title, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=28, VV2zCi=VV2zCi, VV6rfs=VV6rfs, VV2kYm=VV2kYm)
  else:
   FF1ATN(self, "Not found", title=title)
 def VV5iaM(self, VVDhXw, title, txt, colList):
  FFaA9c(VVDhXw, colList[3], VVNAZj=False, checkParentalControl=True)
 def VV8A5E(self, VVDhXw, title, txt, colList):
  FFfK5z(self, boundFunction(self.VVdHZv, VVDhXw), "Clear Zap History ?")
 def VVdHZv(self, VVDhXw):
  self.VVGWMk()
  VVDhXw.cancel()
 def VVTiiHFromZapHistory(self, VVDhXw, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFgbQa(self, fncMode=CCPltO.VVZUZl, refCode=refCode, chName=chName, text=txt)
class CCvG1x(Screen):
 VVGkl9   = 0
 VVfdUL  = 1
 VVitwF  = 2
 VVchuc  = 3
 VVjYD0  = 4
 VVDPPN  = 5
 VVTV8B  = 6
 VVo0uP  = 7
 VVPSAW = 8
 VVdmVJ = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFAEOm(VVHHzS, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFSF9U(self, self.Title)
  FFw7jX(self["keyRed"] , "OK = Zap")
  FFw7jX(self["keyGreen"] , "Current Service")
  FFw7jX(self["keyYellow"], "Page Options")
  FFw7jX(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCvG1x.VVulgY()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVNz0H    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVv1Jt        ,
   "green"   : self.VVbypf       ,
   "yellow"  : self.VV8wE6        ,
   "blue"   : self.VVhADs        ,
   "menu"   : self.VVvDX7        ,
   "info"   : self.VVTiiH         ,
   "up"   : self.VVdENK          ,
   "down"   : self.VV6OgH         ,
   "left"   : self.VVmZkC         ,
   "right"   : self.VVTOrf         ,
   "pageUp"  : boundFunction(self.VVhPe4, True) ,
   "chanUp"  : boundFunction(self.VVhPe4, True) ,
   "pageDown"  : boundFunction(self.VVhPe4, False) ,
   "chanDown"  : boundFunction(self.VVhPe4, False) ,
   "next"   : self.VV1d4U        ,
   "last"   : self.VVlZ6D         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFzPkO(self)
  FFEgCR(self)
  FFtJEw(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFKl3w(self, boundFunction(self.VV1gcE, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVvDX7(self):
  if not self.isBusy:
   VVw8eP = []
   VVw8eP.append(("Statistics"           , "VV3zdw"    ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Suggest PIcons for Current Channel"     , "VVuoZc"   ))
   VVw8eP.append(("Set to Current Channel (copy file)"     , "VVzT6a_file"  ))
   VVw8eP.append(("Set to Current Channel (as SymLink)"     , "VVzT6a_link"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(CCvG1x.VV4P4T())
   VVw8eP.append(VV9e5C)
   if self.filterTitle == "PIcons without Channels":
    c = VVtUnE
    VVw8eP.append((FFkGYB("Move Unused PIcons to a Directory", c) , "VVVoPa"  ))
    VVw8eP.append((FFkGYB("DELETE Unused PIcons", c)    , "VVKPOg" ))
    VVw8eP.append(VV9e5C)
   VVw8eP.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVeUPB"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP += CCvG1x.VVZ3mw()
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("RCU Keys Help"          , "VVN2CQ"    ))
   FF7Bt5(self, self.VVZSWM, title=self.Title, VVw8eP=VVw8eP)
 def VVZSWM(self, item=None):
  if item is not None:
   if   item == "VV3zdw"     : self.VV3zdw()
   elif item == "VVuoZc"    : self.VVuoZc()
   elif item == "VVzT6a_file"   : self.VVzT6a(0)
   elif item == "VVzT6a_link"   : self.VVzT6a(1)
   elif item == "VVpsNi_file"  : self.VVpsNi(0)
   elif item == "VVpsNi_link"  : self.VVpsNi(1)
   elif item == "VVA1oc"   : self.VVA1oc()
   elif item == "VVpYa8"  : self.VVpYa8()
   elif item == "VVVoPa"    : self.VVVoPa()
   elif item == "VVKPOg"   : self.VVKPOg()
   elif item == "VVeUPB"   : self.VVeUPB()
   elif item == "VVThyJ"   : CCvG1x.VVThyJ(self)
   elif item == "VVo46b"   : CCvG1x.VVo46b(self)
   elif item == "findPiconBrokenSymLinks"  : CCvG1x.VVFDyp(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCvG1x.VVFDyp(self, False)
   elif item == "VVN2CQ"      : self.VVN2CQ()
 def VV8wE6(self):
  if not self.isBusy:
   VVw8eP = []
   VVw8eP.append(("Go to First PIcon"  , "VVp7yN"  ))
   VVw8eP.append(("Go to Last PIcon"   , "VVhh8E"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Sort by Channel Name"     , "sortByChan" ))
   VVw8eP.append(("Sort by File Name"  , "sortByFile" ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Find from File List .." , "VVvnJq" ))
   FF7Bt5(self, self.VVGTN7, title=self.Title, VVw8eP=VVw8eP)
 def VVGTN7(self, item=None):
  if item is not None:
   if   item == "VVp7yN"   : self.VVp7yN()
   elif item == "VVhh8E"   : self.VVhh8E()
   elif item == "sortByChan"  : self.VVKmEi(2)
   elif item == "sortByFile"  : self.VVKmEi(0)
   elif item == "VVvnJq"  : self.VVvnJq()
 def VVN2CQ(self):
  FF47lG(self, VVAwa9 + "_help_picons", "PIcons Manager (Keys Help)")
 def VVdENK(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVhh8E()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV3lAS()
 def VV6OgH(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVp7yN()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV3lAS()
 def VVmZkC(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVhh8E()
  else:
   self.curCol -= 1
   self.VV3lAS()
 def VVTOrf(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVp7yN()
  else:
   self.curCol += 1
   self.VV3lAS()
 def VVlZ6D(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV3lAS(True)
 def VV1d4U(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV3lAS(True)
 def VVp7yN(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV3lAS(True)
 def VVhh8E(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV3lAS(True)
 def VVvnJq(self):
  VVw8eP = []
  for item in self.VVNz0H:
   VVw8eP.append((item[0], item[0]))
  FF7Bt5(self, self.VVL0k4, title='PIcons ".png" Files', VVw8eP=VVw8eP, VVPsXE=True)
 def VVL0k4(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVrB5u(ndx)
 def VVv1Jt(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVmZRQ()
   if refCode:
    FFaA9c(self, refCode)
    self.VVXfvu()
    self.VV1CGw()
 def VVhPe4(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVXfvu()
   self.VV1CGw()
  except:
   pass
 def VVbypf(self):
  if self["keyGreen"].getVisible():
   self.VVrB5u(self.curChanIndex)
 def VVrB5u(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV3lAS(True)
  else:
   FF4n96(self, "Not found", 1000)
 def VVKmEi(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFKl3w(self, boundFunction(self.VV1gcE, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVzT6a(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVmZRQ()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVw8eP = []
     VVw8eP.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVw8eP.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF7Bt5(self, boundFunction(self.VVlrxx, mode, curChF, selPiconF), VVw8eP=VVw8eP, title="Current Channel PIcon (already exists)")
    else:
     self.VVlrxx(mode, curChF, selPiconF, "overwrite")
   else:
    FFc88f(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFc88f(self, "Could not read current channel info. !", title=title)
 def VVlrxx(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFKl3w(self, boundFunction(self.VV1gcE, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVpsNi(self, mode):
  pass
 def VVA1oc(self):
  pass
 def VVpYa8(self):
  pass
 def VVVoPa(self):
  defDir = FF1ZUc(CCvG1x.VVulgY() + "picons_backup")
  os.system(FFK72g("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVnMHj, defDir), boundFunction(CCWnyZ
         , mode=CCWnyZ.VVH82H, VVZHg3=CCvG1x.VVulgY()))
 def VVnMHj(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCvG1x.VVulgY():
    FFc88f(self, "Cannot move to same directory !", title=title)
   else:
    if not FF1ZUc(path) == FF1ZUc(defDir):
     self.VViAol(defDir)
    FFfK5z(self, boundFunction(FFKl3w, self, boundFunction(self.VVR5Bu, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVNz0H), path), title=title)
  else:
   self.VViAol(defDir)
 def VVR5Bu(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VViAol(defDir)
   FFc88f(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FF1ZUc(toPath)
  pPath = CCvG1x.VVulgY()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVNz0H:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVNz0H)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFVxvP(self, txt, title=title, VVYhbt="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVBMwh("all")
 def VViAol(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVKPOg(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVNz0H)
  s = "s" if tot > 1 else ""
  FFfK5z(self, boundFunction(FFKl3w, self, boundFunction(self.VVBUFn, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVBUFn(self, title):
  pPath = CCvG1x.VVulgY()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVNz0H:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVNz0H)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFkGYB(str(totErr), VVtUnE)
  FFVxvP(self, txt, title=title)
 def VVeUPB(self):
  lines = FFgPQo("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFfK5z(self, boundFunction(self.VV7Jgx, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVPjh4=True)
  else:
   FF1ATN(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV7Jgx(self, fList):
  os.system(FFK72g("find -L '%s' -type l -delete" % self.pPath))
  FF1ATN(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVTiiH(self):
  FFKl3w(self, self.VVpgFW)
 def VVpgFW(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVmZRQ()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFkGYB("PIcon Directory:\n", VVy6YC)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF61bG(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF61bG(path)
   txt += FFkGYB("PIcon File:\n", VVy6YC)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFgPQo(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFkGYB("Found %d SymLink%s to this file from:\n" % (tot, s), VVy6YC)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFMgu7(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFkGYB(tChName, VVfxXg)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFkGYB(line, VVLchc), tChName)
    txt += "\n"
   if chName:
    txt += FFkGYB("Channel:\n", VVy6YC)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFkGYB(chName, VVfxXg)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFkGYB("Remarks:\n", VVy6YC)
    txt += "  %s\n" % FFkGYB("Unused", VVtUnE)
  else:
   txt = "No info found"
  FFgbQa(self, fncMode=CCPltO.VVH57h, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVmZRQ(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVNz0H[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFJJD0(sat)
  return fName, refCode, chName, sat, inDB
 def VVXfvu(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVNz0H):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VV1CGw(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVmZRQ()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFkGYB("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVy6YC))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVmZRQ()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFkGYB(self.curChanName, VVYPWI)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VV3zdw(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVNz0H:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFla3R("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFVxvP(self, txt, title=self.Title)
 def VVhADs(self):
  if not self.isBusy:
   VVw8eP = []
   VVw8eP.append(("All"         , "all"   ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Used by Channels"      , "used"  ))
   VVw8eP.append(("Unused PIcons"      , "unused"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("PIcons Files"       , "pFiles"  ))
   VVw8eP.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVw8eP.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVw8eP.append(VV9e5C)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFcRp5(val)
      VVw8eP.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC09mD(self)
   filterObj.VVIOJM(VVw8eP, self.nsList, self.VVO3K3)
 def VVO3K3(self, item=None):
  if item is not None:
   self.VVBMwh(item)
 def VVBMwh(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVGkl9   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVfdUL   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVitwF  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVchuc  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVjYD0  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVDPPN  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVTV8B   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVo0uP   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVPSAW , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVDPPN:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFgPQo("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF4n96(self, "Not found", 1000)
     return
   elif mode == self.VVdmVJ:
    return
   else:
    words, asPrefix = CC09mD.VVl1Dd(words)
   if not words and mode in (self.VVo0uP, self.VVPSAW):
    FF4n96(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFKl3w(self, boundFunction(self.VV1gcE, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVuoZc(self):
  self.session.open(CCC5nR, barTheme=CCC5nR.VV5aAT
      , titlePrefix = ""
      , fncToRun  = self.VVpcSV
      , VVOm4z = self.VVs7Mi)
 def VVpcSV(self, progBarObj):
  lameDbChans = CCUJnZ.VVBpsi(self, CCUJnZ.VVVYOT, VVtrf6=False, VV5UFy=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVwCH6 = []
  progBarObj.VVQ1QY(len(lameDbChans))
  if lameDbChans:
   processChanName = CC3a1j()
   curCh = processChanName.VVjp79(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVUkc0(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCvG1x.VVw0Sj(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCvG1x.VV2nYL(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVwCH6.append(f.replace(".png", ""))
 def VVs7Mi(self, VVxVJy, VVwCH6, threadCounter, threadTotal, threadErr):
  if VVwCH6:
   self.timer = eTimer()
   fnc = boundFunction(FFKl3w, self, boundFunction(self.VV1gcE, mode=self.VVdmVJ, words=VVwCH6), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FF4n96(self, "Not found", 2000)
 def VV1gcE(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVAYtF(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCUJnZ.VVBpsi(self, CCUJnZ.VVVYOT, VVtrf6=False, VV5UFy=False)
  iptvRefList = self.VVghGB()
  tList = []
  for fName, fType in CCvG1x.VV2BGS(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVGkl9:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVfdUL  and chName         : isAdd = True
   elif mode == self.VVitwF and not chName        : isAdd = True
   elif mode == self.VVchuc  and fType == 0        : isAdd = True
   elif mode == self.VVjYD0  and fType == 1        : isAdd = True
   elif mode == self.VVDPPN  and fName in words       : isAdd = True
   elif mode == self.VVdmVJ and fName in words       : isAdd = True
   elif mode == self.VVTV8B  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVo0uP  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVPSAW:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVNz0H   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FF4n96(self)
  else:
   self.isBusy = False
   FF4n96(self, "Not found", 1000)
   return
  self.VVNz0H.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVXfvu()
  self.totalPIcons = len(self.VVNz0H)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV3lAS(True)
 def VVAYtF(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCvG1x.VV2BGS(self.pPath):
    if fName:
     return True
   if isFirstTime : FFc88f(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF4n96(self, "Not found", 1000)
  else:
   FFc88f(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVghGB(self):
  VV5w32 = {}
  files  = CCNqVt.VV1iJE(self)
  if files:
   for path in files:
    txt = FFzVLg(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV5w32[refCode] = item[1]
  return VV5w32
 def VV3lAS(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVJbbc = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVJbbc: self.curPage = VVJbbc
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VV3GPv()
  if self.curPage == VVJbbc:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VV1CGw()
  filName, refCode, chName, sat, inDB = self.VVmZRQ()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV3GPv(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVNz0H[ndx]
   fName = self.VVNz0H[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFkGYB(chName, VVfxXg))
    else : lbl.setText("-")
   except:
    lbl.setText(FFkGYB(chName, VV0cUe))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVw0Sj(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV4P4T():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVThyJ"   )
 @staticmethod
 def VVZ3mw():
  VVw8eP = []
  VVw8eP.append(("Find SymLinks (to PIcon Directory)"   , "VVo46b"   ))
  VVw8eP.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVw8eP.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVw8eP
 @staticmethod
 def VVThyJ(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(SELF)
  png, path = CCvG1x.VVkDWS(refCode)
  if path : CCvG1x.VVakhe(SELF, png, path)
  else : FFc88f(SELF, "No PIcon found for current channel in:\n\n%s" % CCvG1x.VVulgY())
 @staticmethod
 def VVo46b(SELF):
  if VVYPWI:
   sed1 = FF6sH0("->", VVYPWI)
   sed2 = FF6sH0("picon", VVtUnE)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV0cUe, VVB0Ol)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFZust(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFYGMZ(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVFDyp(SELF, isPIcon):
  sed1 = FF6sH0("->", VV0cUe)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF6sH0("picon", VVtUnE)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFZust(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFYGMZ(), grep, sed1, sed2))
 @staticmethod
 def VV2BGS(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVulgY():
  path = CFG.PIconsPath.getValue()
  return FF1ZUc(path)
 @staticmethod
 def VVkDWS(refCode, chName=None):
  if FF7z8Z(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFCoVU(refCode)
  allPath, fName, refCodeFile, pList = CCvG1x.VV2nYL(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVakhe(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF6sH0("%s%s" % (dest, png), VVfxXg))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF6sH0(errTxt, VVFT40))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFelLa(SELF, cmd)
 @staticmethod
 def VV2nYL(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCvG1x.VVulgY()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFtG6X(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCcbwl():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVhgMT  = None
  self.VVwyyF = ""
  self.VVC5J8  = noService
  self.VVnX80 = 0
  self.VVrxZb  = noService
  self.VVuS7x = 0
  self.VVxetG  = "-"
  self.VV3oGn = 0
  self.VVL99k  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVNCZE(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVhgMT = frontEndStatus
     self.VV0FKJ()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV0FKJ(self):
  if self.VVhgMT:
   val = self.VVhgMT.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVwyyF = "%3.02f dB" % (val / 100.0)
   else         : self.VVwyyF = ""
   val = self.VVhgMT.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVnX80 = int(val)
   self.VVC5J8  = "%d%%" % val
   val = self.VVhgMT.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVuS7x = int(val)
   self.VVrxZb  = "%d%%" % val
   val = self.VVhgMT.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVxetG  = "%d" % val
   val = int(val * 100 / 500)
   self.VV3oGn = min(500, val)
   val = self.VVhgMT.get("tuner_locked", 0)
   if val == 1 : self.VVL99k = "Locked"
   else  : self.VVL99k = "Not locked"
 def VV8IT4(self)   : return self.VVwyyF
 def VVHKhO(self)   : return self.VVC5J8
 def VVqQgA(self)  : return self.VVnX80
 def VV6OS2(self)   : return self.VVrxZb
 def VVdgfD(self)  : return self.VVuS7x
 def VVaLML(self)   : return self.VVxetG
 def VVVaed(self)  : return self.VV3oGn
 def VVjeJM(self)   : return self.VVL99k
 def VVZda3(self) : return self.serviceName
class CCriLw():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVo62N(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FF2vrH(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVzSMe(self.ORPOS  , mod=1   )
      self.sat2  = self.VVzSMe(self.ORPOS  , mod=2   )
      self.freq  = self.VVzSMe(self.FREQ  , mod=3   )
      self.sr   = self.VVzSMe(self.SR   , mod=4   )
      self.inv  = self.VVzSMe(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVzSMe(self.POL  , self.D_POL )
      self.fec  = self.VVzSMe(self.FEC  , self.D_FEC )
      self.syst  = self.VVzSMe(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVzSMe("modulation" , self.D_MOD )
       self.rolof = self.VVzSMe("rolloff"  , self.D_ROLOF )
       self.pil = self.VVzSMe("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVzSMe("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVzSMe("pls_code"  )
       self.iStId = self.VVzSMe("is_id"   )
       self.t2PlId = self.VVzSMe("t2mi_plp_id" )
       self.t2PId = self.VVzSMe("t2mi_pid"  )
 def VVzSMe(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFcRp5(val)
  elif mod == 2   : return FF9joe(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVeMDR(self, refCode):
  txt = ""
  self.VVo62N(refCode)
  if self.data:
   def VVtmK4(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVtmK4("System"   , self.syst)
    txt += VVtmK4("Satellite"  , self.sat2)
    txt += VVtmK4("Frequency"  , self.freq)
    txt += VVtmK4("Inversion"  , self.inv)
    txt += VVtmK4("Symbol Rate"  , self.sr)
    txt += VVtmK4("Polarization" , self.pol)
    txt += VVtmK4("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVtmK4("Modulation" , self.mod)
     txt += VVtmK4("Roll-Off" , self.rolof)
     txt += VVtmK4("Pilot"  , self.pil)
     txt += VVtmK4("Input Stream", self.iStId)
     txt += VVtmK4("T2MI PLP ID" , self.t2PlId)
     txt += VVtmK4("T2MI PID" , self.t2PId)
     txt += VVtmK4("PLS Mode" , self.plsMod)
     txt += VVtmK4("PLS Code" , self.plsCod)
   else:
    txt += VVtmK4("System"   , self.txMedia)
    txt += VVtmK4("Frequency"  , self.freq)
  return txt, self.namespace
 def VV3GKw(self, refCode):
  txt = "Transpoder : ?"
  self.VVo62N(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVy6YC + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVTBFi(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FF2vrH(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVzSMe(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVzSMe(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVzSMe(self.SYST, self.D_SYS_S)
     freq = self.VVzSMe(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVzSMe(self.POL , self.D_POL)
      fec = self.VVzSMe(self.FEC , self.D_FEC)
      sr = self.VVzSMe(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVj4p1(self, refCode):
  self.data = None
  self.VVo62N(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCFIrc():
 def __init__(self, VVK5Yy, path, VVOm4z=None, curRowNum=-1):
  self.VVK5Yy  = VVK5Yy
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVOm4z  = VVOm4z
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFK72g("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVtQfP(curRowNum)
  else:
   FFc88f(self.VVK5Yy, "Error while preparing edit!")
 def VVtQfP(self, curRowNum):
  VV5w32 = self.VV8Fd8()
  VVJGeM = None #("Delete Line" , self.deleteLine  , [])
  VVicyB = ("Save Changes" , self.VVWGvI   , [])
  VV2zCi  = ("Edit Line"  , self.VVwxYG    , [])
  VVtvPm = ("Line Options" , self.VV9OSN   , [])
  VVbsCJ = (""    , self.VVu7eU , [])
  VV33pw = self.VV5MvS
  VVSR5M  = self.VVJ29K
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVSgvw  = (CENTER  , LEFT  )
  VVDhXw = FFS01Q(self.VVK5Yy, None, title=self.Title, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VVJGeM=VVJGeM, VVicyB=VVicyB, VV2zCi=VV2zCi, VVtvPm=VVtvPm, VV33pw=VV33pw, VVSR5M=VVSR5M, VVbsCJ=VVbsCJ, VVjrzO=True
    , VVRFto   = "#11001111"
    , VVHhCo   = "#11001111"
    , VVYhbt   = "#11001111"
    , VVOU5Z  = "#05333333"
    , VVD2dA  = "#00222222"
    , VVw0pN  = "#11331133"
    )
  VVDhXw.VVVx22(curRowNum)
 def VV9OSN(self, VVDhXw, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVDhXw.VVYQpG()
  VVw8eP = []
  VVw8eP.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVw8eP.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVhivg"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVZVvC:
   VVw8eP.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(  ("Delete Line"         , "deleteLine"   ))
  FF7Bt5(self.VVK5Yy, boundFunction(self.VVtqFp, VVDhXw, lineNum), VVw8eP=VVw8eP, title="Line Options")
 def VVtqFp(self, VVDhXw, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVlNc1("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVDhXw)
   elif item == "VVhivg"  : self.VVhivg(VVDhXw, lineNum)
   elif item == "copyToClipboard"  : self.VVjnVd(VVDhXw, lineNum)
   elif item == "pasteFromClipboard" : self.VVFsNN(VVDhXw, lineNum)
   elif item == "deleteLine"   : self.VVlNc1("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVDhXw)
 def VVJ29K(self, VVDhXw):
  VVDhXw.VVXMpr()
 def VVu7eU(self, VVDhXw, title, txt, colList):
  if   self.insertMode == 1: VVDhXw.VVlxiN()
  elif self.insertMode == 2: VVDhXw.VVqLgb()
  self.insertMode = 0
 def VVhivg(self, VVDhXw, lineNum):
  if lineNum == VVDhXw.VVYQpG():
   self.insertMode = 1
   self.VVlNc1("echo '' >> '%s'" % self.tmpFile, VVDhXw)
  else:
   self.insertMode = 2
   self.VVlNc1("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVDhXw)
 def VVjnVd(self, VVDhXw, lineNum):
  global VVZVvC
  VVZVvC = FFla3R("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVDhXw.VVEQT9("Copied to clipboard")
 def VVWGvI(self, VVDhXw, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFK72g("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFK72g("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVDhXw.VVEQT9("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVDhXw.VVXMpr()
    else:
     FFc88f(self.VVK5Yy, "Cannot save file!")
   else:
    FFc88f(self.VVK5Yy, "Cannot create backup copy of original file!")
 def VV5MvS(self, VVDhXw):
  if self.fileChanged:
   FFfK5z(self.VVK5Yy, boundFunction(self.VVUKQM, VVDhXw), "Cancel changes ?")
  else:
   finalOK = os.system(FFK72g("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVUKQM(VVDhXw)
 def VVUKQM(self, VVDhXw):
  VVDhXw.cancel()
  os.system(FFK72g("rm -f '%s'" % self.tmpFile))
  if self.VVOm4z:
   self.VVOm4z(self.fileSaved)
 def VVwxYG(self, VVDhXw, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVB0Ol + "ORIGINAL TEXT:\n" + VVLchc + lineTxt
  FFTT6y(self.VVK5Yy, boundFunction(self.VVtBTs, lineNum, VVDhXw), title="File Line", defaultText=lineTxt, message=message)
 def VVtBTs(self, lineNum, VVDhXw, VVIh6s):
  if not VVIh6s is None:
   if VVDhXw.VVYQpG() <= 1:
    self.VVlNc1("echo %s > '%s'" % (VVIh6s, self.tmpFile), VVDhXw)
   else:
    self.VVWtaF(VVDhXw, lineNum, VVIh6s)
 def VVFsNN(self, VVDhXw, lineNum):
  if lineNum == VVDhXw.VVYQpG() and VVDhXw.VVYQpG() == 1:
   self.VVlNc1("echo %s >> '%s'" % (VVZVvC, self.tmpFile), VVDhXw)
  else:
   self.VVWtaF(VVDhXw, lineNum, VVZVvC)
 def VVWtaF(self, VVDhXw, lineNum, newTxt):
  VVDhXw.VVjyHB("Saving ...")
  lines = FFg2eB(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVDhXw.VVfo2R()
  VV5w32 = self.VV8Fd8()
  VVDhXw.VVC9qg(VV5w32)
 def VVlNc1(self, cmd, VVDhXw):
  tCons = CCPn4h()
  tCons.ePopen(cmd, boundFunction(self.VVg73f, VVDhXw))
  self.fileChanged = True
  VVDhXw.VVfo2R()
 def VVg73f(self, VVDhXw, result, retval):
  VV5w32 = self.VV8Fd8()
  VVDhXw.VVC9qg(VV5w32)
 def VV8Fd8(self):
  if fileExists(self.tmpFile):
   lines = FFg2eB(self.tmpFile)
   VV5w32 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV5w32.append((str(ndx), line.strip()))
   if not VV5w32:
    VV5w32.append((str(1), ""))
   return VV5w32
  else:
   FFOr2O(self.VVK5Yy, self.tmpFile)
class CC09mD():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVw8eP   = []
  self.satList   = []
 def VVU6jv(self, VVOm4z):
  self.VVw8eP = []
  VVw8eP, VVjhMT = self.VVhXq8(False, True)
  if VVw8eP:
   self.VVw8eP += VVw8eP
   self.VVmx6C(VVOm4z, VVjhMT)
 def VVQLQs(self, mode, VVDhXw, satCol, VVOm4z):
  VVDhXw.VVjyHB("Loading Filters ...")
  self.VVw8eP = []
  self.VVw8eP.append(("All Services" , "all"))
  if mode == 1:
   self.VVw8eP.append(VV9e5C)
   self.VVw8eP.append(("Parental Control", "parentalControl"))
   self.VVw8eP.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVw8eP.append(VV9e5C)
   self.VVw8eP.append(("Selected Transponder"   , "selectedTP" ))
   self.VVw8eP.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVTBXE(VVDhXw, satCol)
  VVw8eP, VVjhMT = self.VVhXq8(True, False)
  if VVw8eP:
   VVw8eP.insert(0, VV9e5C)
   self.VVw8eP += VVw8eP
  VVDhXw.VVdfHL()
  self.VVmx6C(VVOm4z, VVjhMT)
 def VVIOJM(self, VVw8eP, sats, VVOm4z):
  self.VVw8eP = VVw8eP
  VVw8eP, VVjhMT = self.VVhXq8(True, False)
  if VVw8eP:
   self.VVw8eP.append(VV9e5C)
   self.VVw8eP += VVw8eP
  self.VVmx6C(VVOm4z, VVjhMT)
 def VVmx6C(self, VVOm4z, VVjhMT):
  VVjOnb = ("Edit Filter", boundFunction(self.VV0mGp, VVjhMT))
  VVzZGK  = ("Filter Help", boundFunction(self.VVRIP8, VVjhMT))
  FF7Bt5(self.callingSELF, boundFunction(self.VVizg3, VVOm4z), VVw8eP=self.VVw8eP, title="Select Filter", VVjOnb=VVjOnb, VVzZGK=VVzZGK)
 def VVizg3(self, VVOm4z, item):
  if item:
   VVOm4z(item)
 def VV0mGp(self, VVjhMT, VVWZQiObj, sel):
  if fileExists(VVjhMT) : CCFIrc(self.callingSELF, VVjhMT, VVOm4z=None)
  else       : FFOr2O(self.callingSELF, VVjhMT)
  VVWZQiObj.cancel()
 def VVRIP8(self, VVjhMT, VVWZQiObj, sel):
  FF47lG(self.callingSELF, VVAwa9 + "_help_service_filter", "Service Filter")
 def VVTBXE(self, VVDhXw, satColNum):
  if not self.satList:
   satList = VVDhXw.VVc4m9(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFJJD0(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV9e5C)
  if self.VVw8eP:
   self.VVw8eP += self.satList
 def VVhXq8(self, addTag, VVoTpo):
  FFwRBd()
  fileName  = "ajpanel_services_filter"
  VVjhMT = VVvHG2 + fileName
  VVw8eP  = []
  if not fileExists(VVjhMT):
   os.system(FFK72g("cp -f '%s' '%s'" % (VVAwa9 + fileName, VVjhMT)))
  fileFound = False
  if fileExists(VVjhMT):
   fileFound = True
   lines = FFg2eB(VVjhMT)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVw8eP.append((line, "__w__" + line))
       else  : VVw8eP.append((line, line))
  if VVoTpo:
   if   not fileFound : FFOr2O(self.callingSELF , VVjhMT)
   elif not VVw8eP : FFfN7q(self.callingSELF , VVjhMT)
  return VVw8eP, VVjhMT
 @staticmethod
 def VVl1Dd(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCtEJp():
 def __init__(self, callingSELF, VVDhXw, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVDhXw = VVDhXw
  self.refCodeColNum = refCodeColNum
  self.VVw8eP = []
  iMulSel = self.VVDhXw.VVd7Y6()
  if iMulSel : self.VVw8eP.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVw8eP.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVDhXw.VVcoRU()
  self.VVw8eP.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVw8eP.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVw8eP.append(VV9e5C)
 def VVnlEa(self, servName, refCode):
  tot = self.VVDhXw.VVcoRU()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVw8eP.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVnvna_multi" ))
  else    : self.VVw8eP.append( ("Add to Bouquet : %s"      % servName , "VVnvna_one" ))
  self.VVwYJa(servName, refCode)
 def VVw2wc(self, servName, refCode, pcState, hidState):
  self.VVw8eP = []
  if pcState == "No" : self.VVw8eP.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVw8eP.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVw8eP.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVw8eP.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVwYJa(servName, refCode)
 def VVwYJa(self, servName, refCode):
  FF7Bt5(self.callingSELF, boundFunction(self.VVmOyD, servName, refCode), title="Options", VVw8eP=self.VVw8eP)
 def VVmOyD(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVDhXw.VVCMKg(True)
   elif item == "MultSelDisab"    : self.VVDhXw.VVCMKg(False)
   elif item == "selectAll"    : self.VVDhXw.VVix1Z()
   elif item == "unselectAll"    : self.VVDhXw.VV1FmU()
   elif item == "parentalControl_add"  : self.callingSELF.VV26yO(self.VVDhXw, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VV26yO(self.VVDhXw, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVDyVS(self.VVDhXw, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVDyVS(self.VVDhXw, refCode, False)
   elif item == "VVnvna_multi" : self.VVnvna(refCode, True)
   elif item == "VVnvna_one" : self.VVnvna(refCode, False)
 def VVnvna(self, refCode, isMulti):
  bouquets = FFcqwa()
  if bouquets:
   VVw8eP = []
   for item in bouquets:
    VVw8eP.append((item[0], item[1].toString()))
   VVjOnb = ("Create New", boundFunction(self.VVcOjx, refCode, isMulti))
   FF7Bt5(self.callingSELF, boundFunction(self.VV3JTU, refCode, isMulti), VVw8eP=VVw8eP, title="Add to Bouquet", VVjOnb=VVjOnb, VVPsXE=True, VVqGaJ=True)
  else:
   FFfK5z(self.callingSELF, boundFunction(self.VVgg5A, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VV3JTU(self, refCode, isMulti, bName=None):
  if bName:
   FFKl3w(self.VVDhXw, boundFunction(self.VVgqqu, refCode, isMulti, bName), title="Adding Channels ...")
 def VVgqqu(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVnUtA(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VV0Hqr = InfoBar.instance
    if VV0Hqr:
     VVtLl0 = VV0Hqr.servicelist
     if VVtLl0:
      mutableList = VVtLl0.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVDhXw.VVdfHL()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FF1ATN(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFc88f(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVnUtA(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVDhXw.VVoWIX(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVcOjx(self, refCode, isMulti, VVWZQiObj, path):
  self.VVgg5A(refCode, isMulti)
 def VVgg5A(self, refCode, isMulti):
  FFTT6y(self.callingSELF, boundFunction(self.VVFBp8, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVFBp8(self, refCode, isMulti, name):
  if name:
   FFKl3w(self.VVDhXw, boundFunction(self.VVPIbc, refCode, isMulti, name), title="Adding Channels ...")
 def VVPIbc(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVnUtA(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VV0Hqr = InfoBar.instance
    if VV0Hqr:
     VVtLl0 = VV0Hqr.servicelist
     if VVtLl0:
      try:
       VVtLl0.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVtLl0.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVDhXw.VVdfHL()
   title = "Add to Bouquet"
   if allOK: FF1ATN(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFc88f(self.callingSELF, "Nothing added!", title=title)
class CCIdMG(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVQ70f, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFSF9U(self)
  FFw7jX(self["keyRed"]  , "Exit")
  FFw7jX(self["keyGreen"]  , "Save")
  FFw7jX(self["keyYellow"] , "Refresh")
  FFw7jX(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV2OTy  ,
   "green"   : self.VVmxOr ,
   "yellow"  : self.VVMCOP  ,
   "blue"   : self.VVJwwo   ,
   "up"   : self.VVdENK    ,
   "down"   : self.VV6OgH   ,
   "left"   : self.VVmZkC   ,
   "right"   : self.VVTOrf   ,
   "cancel"  : self.VV2OTy
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVMCOP()
  self.VVd8fu()
  FFEgCR(self)
 def VV2OTy(self) : self.close(True)
 def VV3MuO(self) : self.close(False)
 def VVJwwo(self):
  self.session.openWithCallback(self.VV0ljb, boundFunction(CCa54v))
 def VV0ljb(self, closeAll):
  if closeAll:
   self.close()
 def VVdENK(self):
  self.VVe32D(1)
 def VV6OgH(self):
  self.VVe32D(-1)
 def VVmZkC(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVd8fu()
 def VVTOrf(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVd8fu()
 def VVe32D(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVRbi5(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVRbi5(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVRbi5(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVFJAz(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVFJAz(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVd8fu(self):
  for obj in self.list:
   FFtJEw(obj, "#11404040")
  FFtJEw(self.list[self.index], "#11ff8000")
 def VVMCOP(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVmxOr(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCPn4h()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVzKhI)
 def VVzKhI(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF1ATN(self, "Nothing returned from the system!")
  else:
   FF1ATN(self, str(result))
class CCa54v(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVyduo, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFSF9U(self, addLabel=True)
  FFw7jX(self["keyRed"]  , "Exit")
  FFw7jX(self["keyGreen"]  , "Sync")
  FFw7jX(self["keyYellow"] , "Refresh")
  FFw7jX(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV2OTy   ,
   "green"   : self.VVJLzZ  ,
   "yellow"  : self.VVzbvY ,
   "blue"   : self.VVQb5z  ,
   "cancel"  : self.VV2OTy
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVGTt2()
  self.onShow.append(self.start)
 def start(self):
  FFlxSW(self.refresh)
  FFEgCR(self)
 def refresh(self):
  self.VVQJFt()
  self.VVgXO8(False)
 def VV2OTy(self)  : self.close(True)
 def VVQb5z(self) : self.close(False)
 def VVGTt2(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVQJFt(self):
  self.VVGuvN()
  self.VVpLqI()
  self.VVPHYH()
  self.VVBNzD()
 def VVzbvY(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVGTt2()
   self.VVQJFt()
   FFlxSW(self.refresh)
 def VVJLzZ(self):
  if len(self["keyGreen"].getText()) > 0:
   FFfK5z(self, self.VVrcsm, "Synchronize with Internet Date/Time ?")
 def VVrcsm(self):
  self.VVQJFt()
  FFlxSW(boundFunction(self.VVgXO8, True))
 def VVGuvN(self)  : self["keyRed"].show()
 def VVGVga(self)  : self["keyGreen"].show()
 def VVm45T(self) : self["keyYellow"].show()
 def VV9UPI(self)  : self["keyBlue"].show()
 def VVpLqI(self)  : self["keyGreen"].hide()
 def VVPHYH(self) : self["keyYellow"].hide()
 def VVBNzD(self)  : self["keyBlue"].hide()
 def VVgXO8(self, sync):
  localTime = FFe93I()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV0I19(server)
   if epoch_time is not None:
    ntpTime = FF7tZn(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCPn4h()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVzKhI, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVm45T()
  self.VV9UPI()
  if ok:
   self.VVGVga()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVzKhI(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVgXO8(False)
  except:
   pass
 def VV0I19(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFyisd():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCkgBk(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAEOm(VVEEKb, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFSF9U(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFlxSW(self.VVHQEo)
 def VVHQEo(self):
  if FFyisd(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFtJEw(self["myBody"], color)
   FFtJEw(self["myLabel"], color)
  except:
   pass
class CC2IIP(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFAghz()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFAEOm(VVrpQE, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCuVDS(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCuVDS(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCuVDS(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCcbwl()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFSF9U(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVdENK          ,
   "down"  : self.VV6OgH         ,
   "left"  : self.VVmZkC         ,
   "right"  : self.VVTOrf         ,
   "info"  : self.VVuUwZ        ,
   "epg"  : self.VVuUwZ        ,
   "menu"  : self.VVN2CQ         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVpon1       ,
   "last"  : boundFunction(self.VVLqD9, -1)  ,
   "next"  : boundFunction(self.VVLqD9, 1)  ,
   "pageUp" : boundFunction(self.VVvDab, True) ,
   "chanUp" : boundFunction(self.VVvDab, True) ,
   "pageDown" : boundFunction(self.VVvDab, False) ,
   "chanDown" : boundFunction(self.VVvDab, False) ,
   "0"   : boundFunction(self.VVLqD9, 0)  ,
   "1"   : boundFunction(self.VVxsZz, pos=1) ,
   "2"   : boundFunction(self.VVxsZz, pos=2) ,
   "3"   : boundFunction(self.VVxsZz, pos=3) ,
   "4"   : boundFunction(self.VVxsZz, pos=4) ,
   "5"   : boundFunction(self.VVxsZz, pos=5) ,
   "6"   : boundFunction(self.VVxsZz, pos=6) ,
   "7"   : boundFunction(self.VVxsZz, pos=7) ,
   "8"   : boundFunction(self.VVxsZz, pos=8) ,
   "9"   : boundFunction(self.VVxsZz, pos=9) ,
  }, -1)
  self.onShown.append(self.VVscXX)
  self.onClose.append(self.onExit)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self.sliderSNR.VVbYnf()
  self.sliderAGC.VVbYnf()
  self.sliderBER.VVbYnf(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVxsZz()
  self.VVqlM2Info()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVqlM2)
  except:
   self.timer.callback.append(self.VVqlM2)
  self.timer.start(500, False)
 def VVqlM2Info(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVNCZE(service)
  serviceName = self.tunerInfo.VVZda3()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  tp = CCriLw()
  txt = tp.VV3GKw(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVqlM2(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVNCZE(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV8IT4())
   self["mySNR"].setText(self.tunerInfo.VVHKhO())
   self["myAGC"].setText(self.tunerInfo.VV6OS2())
   self["myBER"].setText(self.tunerInfo.VVaLML())
   self.sliderSNR.VV5yeB(self.tunerInfo.VVqQgA())
   self.sliderAGC.VV5yeB(self.tunerInfo.VVdgfD())
   self.sliderBER.VV5yeB(self.tunerInfo.VVVaed())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VV5yeB(0)
   self.sliderAGC.VV5yeB(0)
   self.sliderBER.VV5yeB(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
    if state and not state == "Tuned":
     FF4n96(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVuUwZ(self):
  FFgbQa(self, fncMode=CCPltO.VVryMn)
 def VVN2CQ(self):
  FF47lG(self, VVAwa9 + "_help_signal", "Signal Monitor (Keys)")
 def VVpon1(self):
  self.session.open(CC9DjN, isFromExternal=self.isFromExternal)
  self.close()
 def VVdENK(self)  : self.VVxsZz(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV6OgH(self) : self.VVxsZz(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVmZkC(self) : self.VVxsZz(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVTOrf(self) : self.VVxsZz(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVxsZz(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVLqD9(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFpr4w(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVvDab(self, isUp):
  FF4n96(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVqlM2Info()
  except:
   pass
class CCuVDS(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVbYnf(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFtJEw(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVAwa9 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFtJEw(self.covObj, self.covColor)
   else:
    FFtJEw(self.covObj, "#00006688")
    self.isColormode = True
  self.VV5yeB(0)
 def VV5yeB(self, val):
  val  = FFpr4w(val, self.minN, self.maxN)
  width = int(FF4FJG(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFpr4w(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCC5nR(Screen):
 VV5aAT    = 0
 VVEGAJ = 1
 VV67IT = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVOm4z=None, barTheme=VV5aAT):
  ratio = self.VVAFNf(barTheme)
  self.skin, self.skinParam = FFAEOm(VVpQQK, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVOm4z = VVOm4z
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVwCH6 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFSF9U(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVscXX)
  self.onClose.append(self.onExit)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self.VV0GKG()
  self["myProgBarVal"].setText("0%")
  FFtJEw(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVpu1Y()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVpu1Y)
  except:
   self.timer.callback.append(self.VVpu1Y)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVQ1QY(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVUdJZ_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVwCH6), self.counter, self.maxValue, catName)
 def VVUdJZ_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVUdJZ_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVpu1Y()
  except:
   pass
 def VVUkc0(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVwCH6), self.counter, self.maxValue)
  except:
   pass
 def VV1zWA(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVct68(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VViCXZ(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF4n96(self, "Cancelling ...")
  self.isCancelled = True
  self.VVF9I5(False)
 def VVF9I5(self, isDone):
  if self.VVOm4z:
   self.VVOm4z(isDone, self.VVwCH6, self.counter, self.maxValue, self.isError)
  self.close()
 def VVpu1Y(self):
  val = FFpr4w(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FF4FJG(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVF9I5(True)
 def VV0GKG(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVEGAJ, self.VV67IT):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVAFNf(self, barTheme):
  if   barTheme == self.VVEGAJ : return 0.7
  if   barTheme == self.VV67IT : return 0.5
  else             : return 1
class CCPn4h(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVOm4z = {}
  self.commandRunning = False
  self.VViYVL  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVOm4z, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVOm4z[name] = VVOm4z
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VViYVL:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VV1ObQ, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VV2ZVO , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VV1ObQ, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VV2ZVO , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV2ZVO(name, retval)
  return True
 def VV1ObQ(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV2ZVO(self, name, retval):
  if not self.VViYVL:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVOm4z[name]:
   self.VVOm4z[name](self.appResults[name], retval)
  del self.VVOm4z[name]
 def VVY6iP(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCA4uq(Screen):
 def __init__(self, session, title="", VVA6hv=None, VVCSrv=False, VVojAp=False, VVB3GY=False, VV4Zoh=False, VVACcx=False, VVmTcl=False, VVMBud=VVsWwL, VVpEG3=None, VVosEw=False, VVi2Cw=None, VVjkt0="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFAEOm(VVI14G, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFSF9U(self, addScrollLabel=True)
  if not VVjkt0:
   VVjkt0 = "Processing ..."
  self["myLabel"].setText("   %s" % VVjkt0)
  self.VVCSrv   = VVCSrv
  self.VVojAp   = VVojAp
  self.VVB3GY   = VVB3GY
  self.VV4Zoh  = VV4Zoh
  self.VVACcx = VVACcx
  self.VVmTcl = VVmTcl
  self.VVMBud   = VVMBud
  self.VVpEG3 = VVpEG3
  self.VVosEw  = VVosEw
  self.VVi2Cw  = VVi2Cw
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCPn4h()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFSUtV()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVA6hv, str):
   self.VVA6hv = [VVA6hv]
  else:
   self.VVA6hv = VVA6hv
  if self.VVB3GY or self.VV4Zoh:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVS5oR, VVS5oR)
   self.VVA6hv.append("echo -e '\n%s\n' %s" % (restartNote, FF6sH0(restartNote, VVYPWI)))
   if self.VVB3GY:
    self.VVA6hv.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVA6hv.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVACcx:
   FF4n96(self, "Processing ...")
  self.onLayoutFinish.append(self.VVHi3v)
  self.onClose.append(self.VVxVlB)
 def VVHi3v(self):
  self["myLabel"].VVe9VI(textOutFile="console" if self.enableSaveRes else "")
  if self.VVCSrv:
   self["myLabel"].VVKCBq()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVKwEE()
  else:
   self.VVwagb()
 def VVKwEE(self):
  if FFyisd():
   self["myLabel"].setText("Processing ...")
   self.VVwagb()
  else:
   self["myLabel"].setText(FFkGYB("\n   No connection to internet!", VVtUnE))
 def VVwagb(self):
  allOK = self.container.ePopen(self.VVA6hv[0], self.VVRCxd, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVRCxd("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVmTcl or self.VVB3GY or self.VV4Zoh:
    self["myLabel"].setText(FFGsc3("STARTED", VVYPWI) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVi2Cw:
   colorWhite = CC4LkW.VV1rCL(VVB0Ol)
   color  = CC4LkW.VV1rCL(self.VVi2Cw[0])
   words  = self.VVi2Cw[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVMBud=self.VVMBud)
 def VVRCxd(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVA6hv):
   allOK = self.container.ePopen(self.VVA6hv[self.cmdNum], self.VVRCxd, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVRCxd("Cannot connect to Console!", -1)
  else:
   if self.VVACcx and FFAkF7(self):
    FF4n96(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVmTcl:
    self["myLabel"].appendText("\n" + FFGsc3("FINISHED", VVYPWI), self.VVMBud)
   if self.VVCSrv or self.VVojAp:
    self["myLabel"].VVKCBq()
   if self.VVpEG3 is not None:
    self.VVpEG3()
   if not retval and self.VVosEw:
    self.VVxVlB()
 def VVxVlB(self):
  if self.container.VVY6iP():
   self.container.killAll()
class CC7tIZ(Screen):
 def __init__(self, session, VVA6hv=None, VVACcx=False):
  self.skin, self.skinParam = FFAEOm(VVI14G, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVvHG2 + "ajpanel_terminal.history"
  self.customCommandsFile = VVvHG2 + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFla3R("pwd") or "/home/root"
  self.container   = CCPn4h()
  FFSF9U(self, addScrollLabel=True)
  FFw7jX(self["keyRed"] , "Exit = Stop Command")
  FFw7jX(self["keyGreen"] , "OK = History")
  FFw7jX(self["keyYellow"], "Menu = Custom Cmds")
  FFw7jX(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVovNN ,
   "cancel" : self.VViZim  ,
   "menu"  : self.VVrSjC ,
   "last"  : self.VVPe8y  ,
   "next"  : self.VVPe8y  ,
   "1"   : self.VVPe8y  ,
   "2"   : self.VVPe8y  ,
   "3"   : self.VVPe8y  ,
   "4"   : self.VVPe8y  ,
   "5"   : self.VVPe8y  ,
   "6"   : self.VVPe8y  ,
   "7"   : self.VVPe8y  ,
   "8"   : self.VVPe8y  ,
   "9"   : self.VVPe8y  ,
   "0"   : self.VVPe8y
  })
  self.onLayoutFinish.append(self.VVscXX)
  self.onClose.append(self.VVI9eR)
 def VVscXX(self):
  self["myLabel"].VVe9VI(isResizable=False, textOutFile="terminal")
  FFLdCa(self["keyRed"]  , "#00ff8000")
  FFtJEw(self["keyRed"]  , self.skinParam["titleColor"])
  FFtJEw(self["keyGreen"]  , self.skinParam["titleColor"])
  FFtJEw(self["keyYellow"] , self.skinParam["titleColor"])
  FFtJEw(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVVO2a(FFla3R("date"), 5)
  result = FFla3R("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVzs9y()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVAwa9 + "LinuxCommands.lst"
   newTemplate = VVAwa9 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFK72g("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFK72g("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVI9eR(self):
  if self.container.VVY6iP():
   self.container.killAll()
   self.VVVO2a("Process killed\n", 4)
   self.VVzs9y()
 def VViZim(self):
  if self.container.VVY6iP():
   self.VVI9eR()
  else:
   FFfK5z(self, self.close, "Exit ?", VVyivk=False)
 def VVzs9y(self):
  self.VVVO2a(self.prompt, 1)
  self["keyRed"].hide()
 def VVVO2a(self, txt, mode):
  if   mode == 1 : color = VVYPWI
  elif mode == 2 : color = VVy6YC
  elif mode == 3 : color = VVB0Ol
  elif mode == 4 : color = VVtUnE
  elif mode == 5 : color = VVLchc
  elif mode == 6 : color = VVfjTY
  else   : color = VVB0Ol
  try:
   self["myLabel"].appendText(FFkGYB(txt, color))
  except:
   pass
 def VVC5ia(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVVO2a(cmd, 2)
   self.VVVO2a("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVVO2a(ch, 0)
   self.VVVO2a("\nor\n", 4)
   self.VVVO2a("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVzs9y()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFkGYB(parts[0].strip(), VVy6YC)
    right = FFkGYB("#" + parts[1].strip(), VVfjTY)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVVO2a(txt, 2)
   lastLine = self.VV90ym()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVy1St(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVRCxd, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFc88f(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVVO2a(data, 3)
 def VVRCxd(self, data, retval):
  if not retval == 0:
   self.VVVO2a("Exit Code : %d\n" % retval, 4)
  self.VVzs9y()
 def VVovNN(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV90ym() == "":
   self.VVy1St("cd /tmp")
   self.VVy1St("ls")
  VV5w32 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFg2eB(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV5w32.append((str(c), line, str(lNum)))
   self.VVQHSa(VV5w32, title, self.commandHistoryFile, isHistory=True)
  else:
   FFOr2O(self, self.commandHistoryFile, title=title)
 def VV90ym(self):
  lastLine = FFla3R("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVy1St(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVrSjC(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFg2eB(self.customCommandsFile)
   lastLineIsSep = False
   VV5w32 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV5w32.append((str(c), line, str(lNum)))
   self.VVQHSa(VV5w32, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFOr2O(self, self.customCommandsFile, title=title)
 def VVQHSa(self, VV5w32, title, filePath=None, isHistory=False):
  if VV5w32:
   VVOU5Z = "#05333333"
   if isHistory: VVRFto = VVHhCo = VVYhbt = "#11000020"
   else  : VVRFto = VVHhCo = VVYhbt = "#06002020"
   VV6rfs = VVtvPm = None
   VV2zCi   = ("Send"   , self.VVImlC        , [])
   VVicyB  = ("Modify & Send" , self.VVT2Xa        , [])
   if isHistory:
    VV6rfs = ("Clear History" , self.VV8LgM        , [])
   elif filePath:
    VVtvPm = ("Edit File"  , boundFunction(self.VVQGwe, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVSgvw     = (CENTER  , LEFT   , CENTER )
   FFS01Q(self, None, title=title, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VVicyB=VVicyB, VV6rfs=VV6rfs, VVtvPm=VVtvPm, VVjrzO=True
     , VVRFto   = VVRFto
     , VVHhCo   = VVHhCo
     , VVYhbt   = VVYhbt
     , VVRrPm  = "#05ffff00"
     , VVOU5Z  = VVOU5Z
    )
  else:
   FFfN7q(self, filePath, title=title)
 def VVImlC(self, VVDhXw, title, txt, colList):
  cmd = colList[1].strip()
  VVDhXw.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVVO2a("\n%s\n" % cmd, 6)
   self.VVVO2a(self.prompt, 1)
  else:
   self.VVC5ia(cmd)
 def VVT2Xa(self, VVDhXw, title, txt, colList):
  cmd = colList[1]
  self.VVqAEQ(VVDhXw, cmd)
 def VV8LgM(self, VVDhXw, title, txt, colList):
  FFfK5z(self, boundFunction(self.VViTyI, VVDhXw), "Reset History File ?", title="Command History")
 def VViTyI(self, VVDhXw):
  os.system(FFK72g("echo '' > %s" % self.commandHistoryFile))
  VVDhXw.cancel()
 def VVQGwe(self, filePath, VVDhXw, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCFIrc(self, filePath, VVOm4z=boundFunction(self.VV1okL, VVDhXw), curRowNum=rowNum)
  else     : FFOr2O(self, filePath)
 def VV1okL(self, VVDhXw, fileChanged):
  if fileChanged:
   VVDhXw.cancel()
   FFlxSW(self.VVrSjC)
 def VVPe8y(self):
  self.VVqAEQ(None, self.lastCommand)
 def VVqAEQ(self, VVDhXw, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFTT6y(self, boundFunction(self.VVoQXy, VVDhXw), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVoQXy(self, VVDhXw, cmd):
  if cmd and len(cmd) > 0:
   self.VVC5ia(cmd)
   if VVDhXw:
    VVDhXw.cancel()
class CCPuvC(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVIh6s="", VVUq9I=False, VVFBDJ=False, isTrimEnds=True):
  self.skin, self.skinParam = FFAEOm(VVed3u, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFSF9U(self, title, addLabel=True)
  FFw7jX(self["keyRed"] , "Up/Down = Change")
  FFw7jX(self["keyGreen"] , "Overwrite")
  FFw7jX(self["keyYellow"], "Pick Key Map")
  FFw7jX(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVFBDJ   = VVFBDJ
  self.VVUq9I  = VVUq9I
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVIh6s, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVAR1P      ,
   "green"    : self.VVXdYC    ,
   "yellow"   : self.VVFh5K      ,
   "blue"    : self.VVK9jR     ,
   "menu"    : self.VVPaxr     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVzMGB, True) ,
   "down"    : boundFunction(self.VVzMGB, False) ,
   "left"    : self.VVZLZU       ,
   "right"    : self.VVHGlx       ,
   "home"    : self.VVkJfM       ,
   "end"    : self.VVpHOG       ,
   "next"    : self.VVGEQp      ,
   "last"    : self.VV782Q      ,
   "deleteForward"  : self.VVGEQp      ,
   "deleteBackward" : self.VV782Q      ,
   "tab"    : self.VVWIrv       ,
   "toggleOverwrite" : self.VVXdYC    ,
   "0"     : self.VVLp9u     ,
   "1"     : self.VVLp9u     ,
   "2"     : self.VVLp9u     ,
   "3"     : self.VVLp9u     ,
   "4"     : self.VVLp9u     ,
   "5"     : self.VVLp9u     ,
   "6"     : self.VVLp9u     ,
   "7"     : self.VVLp9u     ,
   "8"     : self.VVLp9u     ,
   "9"     : self.VVLp9u
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVGHDb()
  self.onShown.append(self.VVscXX)
  self.onClose.append(self.onExit)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFzPkO(self)
  self["myLabel"].setText(self.message)
  self.VVwu3O()
  if self.VVUq9I : self.VVXdYC()
  else    : self.VVwAaw()
  FFEgCR(self)
  FFtJEw(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvyMb)
  except:
   self.timer.callback.append(self.VVvyMb)
 def onExit(self):
  self.timer.stop()
 def VVAR1P(self):
  self.VVi7xq()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVi7xq()
  self.close(None)
 def VVPaxr(self):
  VVw8eP = []
  VVw8eP.append(("Home"         , "home"    ))
  VVw8eP.append(("End"         , "end"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Clear All"       , "clearAll"   ))
  VVw8eP.append(("Clear To Home"      , "clearToHome"   ))
  VVw8eP.append(("Clear To End"       , "clearToEnd"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVZVvC:
   VVw8eP.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("To Capital Letters"     , "toCapital"   ))
  VVw8eP.append(("To Small Letters"      , "toSmall"    ))
  FF7Bt5(self, self.VVaOi5, title="Edit Options", VVw8eP=VVw8eP)
 def VVaOi5(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVkJfM()
   elif item == "end"     : self.VVpHOG()
   elif item == "clearAll"    : self.VVR5u6()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVkJfM()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVZVvC
    VVZVvC = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVZVvC)
    self.VVkJfM()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVvyMb(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVXdYC(self):
  self["myInput"].toggleOverwrite()
  self.VVwAaw()
 def VVFh5K(self):
  self.session.openWithCallback(self.VVvyZv, boundFunction(CCEDw8, mode=self.charMode, VVFBDJ=self.VVFBDJ))
 def VVvyZv(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVwu3O()
 def VVwAaw(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVGHDb(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVi7xq(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVeymg(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVZLZU(self)     : self.VVjPP8(self["myInput"].left)
 def VVHGlx(self)     : self.VVjPP8(self["myInput"].right)
 def VVGEQp(self)     : self.VVjPP8(self["myInput"].delete)
 def VVkJfM(self)     : self.VVjPP8(self["myInput"].home)
 def VVpHOG(self)     : self.VVjPP8(self["myInput"].end)
 def VV782Q(self)    : self.VVjPP8(self["myInput"].deleteBackward)
 def VVWIrv(self)     : self.VVjPP8(self["myInput"].tab)
 def VVR5u6(self)     : self["myInput"].setText("")
 def VVjPP8(self, fnc):
  fnc()
  self.VVvyMb()
 def VVLp9u(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVeymg(newChar, overwrite)
   self.VV9hbd(newChar, self["myInput"].mapping[number])
 def VVzMGB(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCEDw8.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCEDw8.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVeymg(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV9hbd(newChar, group)
     break
 def VV9hbd(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVB0Ol:
    group = VVLchc + group.replace(newChar, FFkGYB(newChar, VVB0Ol, VVLchc))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVK9jR(self):
  if self.VVFBDJ : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVwu3O()
 def VVwu3O(self):
  self["myInput"].mapping = CCEDw8.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCEDw8.RCU_MAP_TITLES[self.charMode])
class CCEDw8(Screen):
 VVChIK  = 0
 VVjx9d  = 1
 VV6a5C  = 2
 VViw0j  = 3
 VVrWKP = 4
 VVt5AY = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVChIK, VVFBDJ=False):
  self.skin, self.skinParam = FFAEOm(VVbMYa, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVFBDJ  = VVFBDJ
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFSF9U(self, title=self.Title)
  FFw7jX(self["keyRed"] ,"OK = Select")
  FFw7jX(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVc2gh     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVKIyf, -1) ,
   "next"  : boundFunction(self.VVKIyf, +1) ,
   "left"  : boundFunction(self.VVKIyf, -1) ,
   "right"  : boundFunction(self.VVKIyf, +1) ,
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFtJEw(self["keyRed"], "#11222222")
  FFtJEw(self["keyGreen"], "#11222222")
  self.VVIk8t()
 def VVIk8t(self):
  self.VV5kSA()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VV5kSA(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVKIyf(self, direction):
  if self.VVFBDJ : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVIk8t()
 def VVc2gh(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCdr9C(Screen):
 def __init__(self, session, title="", message="", VVMBud=VVsWwL, VVIekL=False, VVYhbt=None, VVjgTX=30, canSaveToFile=""):
  self.skin, self.skinParam = FFAEOm(VVI14G, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVjgTX)
  self.session   = session
  FFSF9U(self, title, addScrollLabel=True)
  self.VVMBud   = VVMBud
  self.VVIekL   = VVIekL
  self.VVYhbt   = VVYhbt
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self["myLabel"].VVe9VI(VVIekL=self.VVIekL, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVMBud)
  if self.VVYhbt:
   FFtJEw(self["myBody"], self.VVYhbt)
   FFtJEw(self["myLabel"], self.VVYhbt)
   FFm7Uq(self["myLabel"], self.VVYhbt)
  self["myLabel"].VVKCBq()
class CC8DfR(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFAEOm(VV5s3X, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFSF9U(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFOx42(self["errPic"], "err")
class CCwmPR(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFAEOm(VV9isB, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFSF9U(self, " ", addCloser=True)
class CCR0jD():
 def __init__(self, tSession, txt):
  self.win = tSession.instantiateDialog(CCwmPR, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.timer   = eTimer()
  self.timerCounter = 0
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVIRn2)
  except:
   self.timer.callback.append(self.VVIRn2)
  self.timer.start(100, False)
 def VVIRn2(self):
  self.timerCounter += 1
  if self.timerCounter > 15:
   self.timer.stop()
   self.win.hide()
class CCaDOu():
 VV2u6z    = 0
 VVmEu3  = 1
 VV2SGl   = ""
 VVS6Yv    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVDhXw   = None
  self.timer     = eTimer()
  self.VVUBPl   = 0
  self.VVrISR  = 1
  self.VVyd9t  = 2
  self.VVoUQJ   = 3
  self.VV9Xh9   = 4
  VV5w32 = self.VVpUWN()
  if VV5w32:
   self.VVDhXw = self.VVmKGh(VV5w32)
  if not VV5w32 and mode == self.VV2u6z:
   self.VVoTpoor("Download list is empty !")
   self.cancel()
  if mode == self.VVmEu3:
   FFKl3w(self.VVDhXw or self.SELF, boundFunction(self.VV4r0j, startDnld, decodedUrl), title="Checking Server ...")
  self.VVBwcE(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVBwcE)
  except:
   self.timer.callback.append(self.VVBwcE)
  self.timer.start(1000, False)
 def VVmKGh(self, VV5w32):
  VV5w32.sort(key=lambda x: int(x[0]))
  VV33pw = self.VVeanZ
  VV2zCi  = ("Play"  , self.VVgQ8s , [])
  VV2kYm = (""   , self.VVhU1x  , [])
  VVJGeM = ("Stop"  , self.VVw2fk  , [])
  VVicyB = ("Resume"  , self.VVqBRM , [])
  VV6rfs = ("Options" , self.VVvDX7  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVSgvw  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFS01Q(self.SELF, None, title=self.Title, header=header, VVNz0H=VV5w32, VVSgvw=VVSgvw, VVTy8n=widths, VVjgTX=26, VV2zCi=VV2zCi, VV2kYm=VV2kYm, VV33pw=VV33pw, VVJGeM=VVJGeM, VVicyB=VVicyB, VV6rfs=VV6rfs, VVHhCo="#11110011", VVRFto="#11220022", VVYhbt="#11110011", VVRrPm="#00ffff00", VVOU5Z="#00223025", VVD2dA="#0a333333", VVw0pN="#0a400040", VVjrzO=True, searchCol=1)
 def VVpUWN(self):
  lines = CCaDOu.VVGLQU()
  VV5w32 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVmDZe(decodedUrl)
      if fName:
       if   FFjwaX(decodedUrl) : sType = "Movie"
       elif FFknMo(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVUIlm(decodedUrl, fName)
       if size > -1: sizeTxt = CCWnyZ.VVDyPC(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV5w32.append((str(len(VV5w32) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV5w32
 def VV7Dsa(self):
  VV5w32 = self.VVpUWN()
  if VV5w32:
   if self.VVDhXw : self.VVDhXw.VVC9qg(VV5w32, VVGTt2Msg=False)
   else     : self.VVDhXw = self.VVmKGh(VV5w32)
  else:
   self.cancel()
 def VVBwcE(self, force=False):
  if self.VVDhXw:
   thrList = self.VVzo2t()
   VV5w32 = []
   changed = False
   for ndx, row in enumerate(self.VVDhXw.VVB6yQ()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVUBPl
    if m3u8Log:
     percent = self.VVIqjx(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVoUQJ , "%.2f %%" % percent
      else   : flag, progr = self.VV9Xh9 , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFCOks(mPath)
     if curSize > -1:
      fSize = CCWnyZ.VVDyPC(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCWnyZ.VVDyPC(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFCOks(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVoUQJ , "%.2f %%" % percent
       else   : flag, progr = self.VV9Xh9 , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCWnyZ.VVDyPC(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVyd9t
     if m3u8Log :
      if not speed and not force : flag = self.VVrISR
      elif curSize == -1   : self.VVBdyi(False)
    elif flag == self.VVUBPl  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVUBPl  : color2 = "#f#00555555#"
    elif flag == self.VVrISR : color2 = "#f#0000FFFF#"
    elif flag == self.VVyd9t : color2 = "#f#0000FFFF#"
    elif flag == self.VVoUQJ  : color2 = "#f#00FF8000#"
    elif flag == self.VV9Xh9  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVQE24(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV5w32.append(row)
   if changed or force:
    self.VVDhXw.VVC9qg(VV5w32, VVGTt2Msg=False)
 def VVQE24(self, flag):
  tDict = self.VVoWOr()
  return tDict.get(flag, "?")
 def VVa1Hp(self, state):
  for flag, txt in self.VVoWOr().items():
   if txt == state:
    return flag
  return -1
 def VVoWOr(self):
  return { self.VVUBPl: "Not started", self.VVrISR: "Connecting", self.VVyd9t: "Downloading", self.VVoUQJ: "Stopped", self.VV9Xh9: "Completed" }
 def VVNCie(self, title):
  colList = self.VVDhXw.VV7ku6()
  path = colList[6]
  url  = colList[8]
  if self.VVZlKw() : self.VVoTpoor("Cannot delete !\n\nFile is downloading.")
  else      : FFfK5z(self.SELF, boundFunction(self.VVi4cQ, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVi4cQ(self, path, url):
  m3u8Log = self.VVDhXw.VV7ku6()[12].strip()
  if m3u8Log : os.system(FFK72g("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFK72g("rm -r '%s'" % path))
  self.VVUTJL()
  self.VV7Dsa()
 def VVUTJL(self):
  if self.VVZlKw():
   FF4n96(self.VVDhXw, self.VVQE24(self.VVyd9t), 500)
  else:
   colList  = self.VVDhXw.VV7ku6()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVa1Hp(state) in (self.VVUBPl, self.VV9Xh9):
    lines = CCaDOu.VVGLQU()
    newLines = []
    found = False
    for line in lines:
     if CCaDOu.VVnZaI(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV1RKs(newLines)
     self.VV7Dsa()
     FF4n96(self.VVDhXw, "Removed.", 1000)
    else:
     FF4n96(self.VVDhXw, "Not found.", 1000)
   else:
    self.VVoTpoor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV70Vi(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFfK5z(self.SELF, boundFunction(self.VVZAbg, flag), ques, title=title)
 def VVZAbg(self, flag):
  list = []
  for ndx, row in enumerate(self.VVDhXw.VVB6yQ()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVa1Hp(state)
   if   flag == flagVal == self.VV9Xh9: list.append(decodedUrl)
   elif flag == flagVal == self.VVUBPl : list.append(decodedUrl)
  lines = CCaDOu.VVGLQU()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV1RKs(newLines)
   self.VV7Dsa()
   FF4n96(self.VVDhXw, "%d removed." % totRem, 1000)
  else:
   FF4n96(self.VVDhXw, "Not found.", 1000)
 def VVhLVb(self):
  colList  = self.VVDhXw.VV7ku6()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF4n96(self.VVDhXw, "Poster exists", 1500)
  else    : FFKl3w(self.VVDhXw, boundFunction(self.VVquYO, decodedUrl, path, png), title="Checking Server ...")
 def VVquYO(self, decodedUrl, path, png):
  err = self.VVRM4X(decodedUrl, path, png)
  if err:
   FFc88f(self.SELF, err, title="Poster Download")
 def VVRM4X(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCr6oH.VV9UBg(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCNqVt.VVXjzP(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCNqVt.VVcc2w(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCNqVt.VVU0Bn(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFPEOO(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFK72g("mv -f '%s' '%s'" % (tPath, png)))
    FFWcKR(self.SELF, title=os.path.basename(png), VVk9uz=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVhU1x(self, VVDhXw, title, txt, colList):
  def VVwkbi(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVtmK4(key, val) : return "\n%s:\n%s\n" % (FFkGYB(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVDhXw.VV68Jf()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVwkbi(heads[i]  , CCWnyZ.VVDyPC(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVwkbi("Downloaded" , CCWnyZ.VVDyPC(int(curSize), mode=0))
   else:
    txt += VVwkbi(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVtmK4(heads[i], colList[i])
  FFVxvP(self.SELF, txt, title=title)
 def VVgQ8s(self, VVDhXw, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCWnyZ.VVVQ6y(self.SELF, path)
  else    : FF4n96(self.VVDhXw, "File not found", 1000)
 def VVeanZ(self, VVDhXw):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVDhXw:
   self.VVDhXw.cancel()
  del self
 def VVvDX7(self, VVDhXw, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVw8eP = []
  VVw8eP.append(("Remove current row"      , "VVUTJL"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(('Remove all "Completed"'     , "remFinished"    ))
  VVw8eP.append(('Remove all "Not started"'     , "remPending"    ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Delete the file (and remove from list)" , "VVNCie" ))
  if FFjwaX(decodedUrl):
   VVw8eP.append(VV9e5C)
   VVw8eP.append(("Download Movie Poster (from server)" , "VVhLVb"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append((resumeTxt + " Auto Resume"     , "VVbCZh"  ))
  FF7Bt5(self.SELF, self.VVmdgh, VVw8eP=VVw8eP, title=self.Title, VVPsXE=True, VVqGaJ=True)
 def VVmdgh(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVUTJL"  : self.VVUTJL()
   elif ref == "remFinished"   : self.VV70Vi(self.VV9Xh9, txt)
   elif ref == "remPending"   : self.VV70Vi(self.VVUBPl, txt)
   elif ref == "VVNCie" : self.VVNCie(txt)
   elif ref == "VVhLVb"  : self.VVhLVb()
   elif ref == "VVbCZh"  : self.VVbCZh()
 def VV4r0j(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCr6oH.VV9UBg(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVoTpoor("Could not get download link !\n\nTry again later.")
     return
  for line in CCaDOu.VVGLQU():
   if CCaDOu.VVnZaI(decodedUrl, line):
    self.VVK07F(decodedUrl)
    FFlxSW(boundFunction(FF4n96, self.VVDhXw, "Already listed !", 2000))
    break
  else:
   params = self.VVbTsa(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVoTpoor(params[0])
   elif len(params) == 2:
    self.VVjADB(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCWnyZ.VVDyPC(fSize)
    FFfK5z(self.SELF, boundFunction(self.VVb4X2, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVb4X2(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCaDOu.VV4Qvg(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VV7Dsa()
  if self.VVDhXw:
   self.VVDhXw.VVqLgb()
  if startDnld:
   threadName = self.VVS6Yv + decodedUrl
   self.VVkuBz(threadName, url, decodedUrl, path, resp)
 def VVK07F(self, decodedUrl):
  for ndx, row in enumerate(self.VVDhXw.VVB6yQ()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVDhXw:
    self.VVDhXw.VVINep(ndx)
    break
 def VVbTsa(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVmDZe(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVUIlm(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCr6oH.VV9UBg(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCr6oH.VVnwvpHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCaDOu.VVhEs0(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVjADB(self, resp, decodedUrl):
  if not os.system(FFK72g("which ffmpeg")) == 0:
   FFfK5z(self.SELF, boundFunction(CCNqVt.VVP1UP, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVmDZe(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVcR9H(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFfK5z(self.SELF, boundFunction(self.VVUgve, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVUgve(rTxt, rUrl)
  else:
   self.VVoTpoor("Cannot process m3u8 file !")
 def VVcR9H(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVw8eP = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCNqVt.VVuqrM(rUrl, fPath)
   VVw8eP.append((resol, fullUrl))
  if VVw8eP:
   FF7Bt5(self.SELF, self.VVNUjV, VVw8eP=VVw8eP, title="Resolution", VVPsXE=True, VVqGaJ=True)
  else:
   self.VVoTpoor("Cannot get Resolutions list from server !")
 def VVNUjV(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFfK5z(self.SELF, boundFunction(FFlxSW, boundFunction(self.VV5r1M, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFlxSW(boundFunction(self.VV5r1M, resolUrl))
 def VV5r1M(self, resolUrl):
  txt, err = CCr6oH.VVIqlT(resolUrl)
  if err : self.VVoTpoor(err)
  else : self.VVUgve(txt, resolUrl)
 def VVhnuE(self, logF, decodedUrl):
  found = False
  lines = CCaDOu.VVGLQU()
  with open(CCaDOu.VV4Qvg(), "w") as f:
   for line in lines:
    if CCaDOu.VVnZaI(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCaDOu.VV4Qvg(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VV7Dsa()
 def VVUgve(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCNqVt.VVuqrM(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVoTpoor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVhnuE(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFK72g("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVS6Yv + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVIqjx(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVwq9Q(dnldLog)
   if dur > -1:
    tim = self.VVf1kp(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVwq9Q(self, dnldLog):
  lines = FFgPQo("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVf1kp(self, dnldLog):
  lines = FFgPQo("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVUIlm(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFknMo(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFK72g("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVkuBz(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVDhXw.VV7ku6()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVJOaU, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVJOaU(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCaDOu.VV2SGl == path:
       break
     else:
      break
  except:
   return
  if CCaDOu.VV2SGl:
   CCaDOu.VV2SGl = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFCOks(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVbTsa(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVJOaU(url, decodedUrl, path, resp, totFileSize, True)
 def VVw2fk(self, VVDhXw, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV11hl() : FF4n96(self.VVDhXw, self.VVQE24(self.VV9Xh9), 500)
  elif not self.VVZlKw() : FF4n96(self.VVDhXw, self.VVQE24(self.VVoUQJ), 500)
  elif m3u8Log      : FFfK5z(self.SELF, self.VVBdyi, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVzo2t():
    CCaDOu.VV2SGl = colList[6]
    FF4n96(self.VVDhXw, "Stopping ...", 1000)
   else:
    FF4n96(self.VVDhXw, "Stopped", 500)
 def VVBdyi(self, withMsg=True):
  if withMsg:
   FF4n96(self.VVDhXw, "Stopping ...", 1000)
  os.system(FFK72g("killall -INT ffmpeg"))
 def VVbCZh(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVqBRM(self, *args):
  if   self.VV11hl() : FF4n96(self.VVDhXw, self.VVQE24(self.VV9Xh9) , 500)
  elif self.VVZlKw() : FF4n96(self.VVDhXw, self.VVQE24(self.VVyd9t), 500)
  else:
   resume = False
   m3u8Log = self.VVDhXw.VV7ku6()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFfK5z(self.SELF, boundFunction(self.VVX1lx, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVtxtR():
    resume = True
   if resume: FFKl3w(self.VVDhXw, boundFunction(self.VVmHvr), title="Checking Server ...")
   else  : FF4n96(self.VVDhXw, "Cannot resume !", 500)
 def VVX1lx(self, m3u8Log):
  os.system(FFK72g("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFKl3w(self.VVDhXw, boundFunction(self.VVmHvr), title="Checking Server ...")
 def VVmHvr(self):
  colList  = self.VVDhXw.VV7ku6()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCr6oH.VV9UBg(decodedUrl)
   if url:
    decodedUrl = self.VVLYgY(decodedUrl, url)
   else:
    self.VVoTpoor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFCOks(path)
  params = self.VVbTsa(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVoTpoor(params[0])
   return
  elif len(params) == 2:
   self.VVjADB(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVLYgY(decodedUrl, url, fSize)
  threadName = self.VVS6Yv + decodedUrl
  if resumable: self.VVkuBz(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVoTpoor("Cannot resume from server !")
 def VVmDZe(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVoTpoor(self, txt):
  FFc88f(self.SELF, txt, title=self.Title)
 def VVzo2t(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVS6Yv in thr.name:
    thrList.append(thr.name.replace(self.VVS6Yv, ""))
  return thrList
 def VVZlKw(self):
  decodedUrl = self.VVDhXw.VV7ku6()[9].strip()
  return decodedUrl in self.VVzo2t()
 def VV11hl(self):
  colList = self.VVDhXw.VV7ku6()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFCOks(path)) == size
 def VVtxtR(self):
  colList = self.VVDhXw.VV7ku6()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFCOks(path)
  if curSize > -1:
   size -= curSize
  err = CCaDOu.VVhEs0(size)
  if err:
   FFc88f(self.SELF, err, title=self.Title)
   return False
  return True
 def VV1RKs(self, list):
  with open(CCaDOu.VV4Qvg(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVLYgY(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCaDOu.VVGLQU()
  url = decodedUrl
  with open(CCaDOu.VV4Qvg(), "w") as f:
   for line in lines:
    if CCaDOu.VVnZaI(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VV7Dsa()
  return url
 @staticmethod
 def VVGLQU():
  list = []
  if fileExists(CCaDOu.VV4Qvg()):
   for line in FFg2eB(CCaDOu.VV4Qvg()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVnZaI(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVhEs0(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCWnyZ.VV5jiF(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCWnyZ.VVDyPC(size), CCWnyZ.VVDyPC(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VV5jPB(SELF):
  tot = CCaDOu.VVghYT()
  if tot:
   FFc88f(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVghYT():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCaDOu.VVS6Yv):
    c += 1
  return c
 @staticmethod
 def VVBRy7():
  return len(CCaDOu.VVGLQU()) == 0
 @staticmethod
 def VVV6lH():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVFpZ8():
  mPoints = CCaDOu.VVV6lH()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFK72g("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VV4Qvg():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVqHnS(SELF):
  CCaDOu.VV5bqp(SELF, CCaDOu.VV2u6z)
 @staticmethod
 def VVPAU4_cur(SELF):
  CCaDOu.VV5bqp(SELF, CCaDOu.VVmEu3, startDnld=True)
 @staticmethod
 def VVPAU4_url(SELF, url):
  CCaDOu.VV5bqp(SELF, CCaDOu.VVmEu3, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVsa5sCurrent(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(SELF)
  added, skipped = CCaDOu.VVsa5sList([decodedUrl])
  FF4n96(SELF, "Added", 1000)
 @staticmethod
 def VVsa5sList(list):
  added = skipped = 0
  for line in CCaDOu.VVGLQU():
   for ndx, url in enumerate(list):
    if url and CCaDOu.VVnZaI(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCaDOu.VV4Qvg(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV5bqp(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCIF1Z.VV4mkm(SELF):
   return
  if mode == CCaDOu.VV2u6z and CCaDOu.VVBRy7():
   FFc88f(SELF, "Download list is empty !", title=title)
  else:
   inst = CCaDOu(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CC9DjN(Screen, CCKMVs):
 VVtJSD = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFAEOm(VVhiru, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCKMVs.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFSF9U(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVBQHb())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhKHG         ,
   "info"  : self.VVuUwZ        ,
   "epg"  : self.VVuUwZ        ,
   "menu"  : self.VVHKBv       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VViNKH        ,
   "green"  : self.VVzISE    ,
   "yellow" : self.VVhrGu   ,
   "left"  : boundFunction(self.VVSdUs, -1)   ,
   "right"  : boundFunction(self.VVSdUs,  1)   ,
   "play"  : self.VVe55n        ,
   "pause"  : self.VVe55n        ,
   "playPause" : self.VVe55n        ,
   "stop"  : self.VVe55n        ,
   "rewind" : self.VV9J0P        ,
   "forward" : self.VV4NEk        ,
   "rewindDm" : self.VV9J0P        ,
   "forwardDm" : self.VV4NEk        ,
   "last"  : boundFunction(self.VVoeLp, 0)    ,
   "next"  : self.VVIrMX        ,
   "pageUp" : boundFunction(self.VV95cF, True) ,
   "pageDown" : boundFunction(self.VV95cF, False) ,
   "chanUp" : boundFunction(self.VV95cF, True) ,
   "chanDown" : boundFunction(self.VV95cF, False) ,
   "up"  : boundFunction(self.VV95cF, True) ,
   "down"  : boundFunction(self.VV95cF, False) ,
   "audio"  : boundFunction(self.VVQqIQ, True) ,
   "subtitle" : boundFunction(self.VVQqIQ, False) ,
   "0"   : boundFunction(self.VV7JMW , 10)  ,
   "1"   : boundFunction(self.VV7JMW , 1)  ,
   "2"   : boundFunction(self.VV7JMW , 2)  ,
   "3"   : boundFunction(self.VV7JMW , 3)  ,
   "4"   : boundFunction(self.VV7JMW , 4)  ,
   "5"   : boundFunction(self.VV7JMW , 5)  ,
   "6"   : boundFunction(self.VV7JMW , 6)  ,
   "7"   : boundFunction(self.VV7JMW , 7)  ,
   "8"   : boundFunction(self.VV7JMW , 8)  ,
   "9"   : boundFunction(self.VV7JMW , 9)
  }, -1)
  self.onShown.append(self.VVscXX)
  self.onClose.append(self.onExit)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFzPkO(self)
  if not CC9DjN.VVtJSD:
   CC9DjN.VVtJSD = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  self["myPlayDnld"].instance.move(ePoint(int(left - self.skinParam["titleH"]), int(top)))
  self["myPlayDnld"].hide()
  FFOx42(self["myPlayDnld"], "dnld")
  self.VViAIF()
  self.instance.move(ePoint(40, 40))
  self.VVU8ZS(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVEYi4)
  except:
   self.timer.callback.append(self.VVEYi4)
  self.timer.start(250, False)
  self.VVEYi4("Checking ...")
  self.VVEKXg()
 def VVzISE(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if "chCode" in iptvRef:
   if CCIF1Z.VV4mkm(self):
    self.VVEKXg(True)
 def VViAIF(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFtJEw(self["myTitle"], color)
 def VVHKBv(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  VVw8eP = []
  if self.isFromExternal:
   VVw8eP.append(("IPTV Menu"     , "iptv"  ))
   VVw8eP.append(VV9e5C)
  if FF7z8Z(iptvRef) and not "&end=" in decodedUrl and not FFzavm(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCNqVt.VVXjzP(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVw8eP.append(("Catchup Programs"   , "catchup"  ))
    VVw8eP.append(VV9e5C)
  VVw8eP.append(("Stop Current Service"    , "stop"  ))
  VVw8eP.append(("Restart Current Service"   , "restart"  ))
  VVw8eP.append(VV9e5C)
  FFjwaXSeries = FFzavm(decodedUrl)
  if FFjwaXSeries:
   VVw8eP.append(("File Size"     , "fileSize" ))
   VVw8eP.append(VV9e5C)
  if self.enableDownloadMenu:
   addSep = False
   if FF7z8Z(iptvRef) and FFjwaXSeries:
    VVw8eP.append(("Start Download"   , "dload_cur" ))
    VVw8eP.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCaDOu.VVBRy7():
    VVw8eP.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVw8eP.append(VV9e5C)
  addSep = False
  fPath, fDir, fName = CCWnyZ.VVQPBU(self)
  if not CCWnyZ.VVXGnR and fPath:
   VVw8eP.append((VVYPWI + "Open path in File Manager" , "VVUxHp"))
   addSep = True
  if fPath:
   VVw8eP.append((VVYPWI + "Add to Movies Bouquet"  , "VVDG0i"))
   addSep = True
  if addSep:
   VVw8eP.append(VV9e5C)
  VVw8eP.append(("Move to Top"      , "top"   ))
  VVw8eP.append(("Move to Bottom"     , "botm"  ))
  VVw8eP.append(("Help"        , "help"  ))
  FF7Bt5(self, self.VVX35n, VVw8eP=VVw8eP, width=550, title="Options")
 def VVX35n(self, item=None):
  if item:
   if item == "iptv"     : self.VVoLzC()
   elif item == "catchup"    : self.VVhrGu()
   elif item == "stop"     : self.VVFwUw(0)
   elif item == "restart"    : self.VVFwUw(1)
   elif item == "fileSize"    : FFKl3w(self, boundFunction(CCPltO.VVqt48, self), title="Checking Server")
   elif item == "dload_cur"   : CCaDOu.VVPAU4_cur(self)
   elif item == "addToDload"   : CCaDOu.VVsa5sCurrent(self)
   elif item == "dload_stat"   : CCaDOu.VVqHnS(self)
   elif item == "VVUxHp" : self.VVUxHp()
   elif item == "VVDG0i" : FFKl3w(self, self.VVDG0i)
   elif item == "botm"     : self.VVU8ZS(0)
   elif item == "top"     : self.VVU8ZS(1)
   elif item == "help"     : FF47lG(self, VVAwa9 + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CC9DjN.VVtJSD = None
 def VVZhTT(self):
  if CC9DjN.VVtJSD:
   self.session.open(CC9DjN, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVUxHp(self):
  self.session.open(CCWnyZ, gotoMovie=True)
  self.VVZhTT()
 def VVoLzC(self):
  self.session.open(CCNqVt)
  self.VVZhTT()
 def VVFwUw(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVEYi4("Restarting Service ...")
    FFlxSW(boundFunction(self.VVRUuO, serv))
 def VVRUuO(self, serv):
  self.session.nav.stopService()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if "&end=" in decodedUrl: boundFunction(self.VVEKXg, True)
  else     : self.session.nav.playService(serv)
 def VVDG0i(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VV9m85 + "userbouquet.my_local_movies.tv"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  fPath, fDir, fName = CCWnyZ.VVQPBU(self)
  if not fPath or not chName:
   FFc88f(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCNqVt.VVuoRh(catID, stID, chNum)
  if not isNew:
   fTxt = FFzVLg(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFc88f(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCNqVt.VVuoRh(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFc88f(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVke3h(refCode)
   FFjfIu(os.path.basename(path))
   FFikPN()
   FF1ATN(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFc88f(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVke3h(self, refCode):
  fPath, fDir, fName, picFile = CCPltO.VVMKAP(self)
  pPath = CCvG1x.VVulgY()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFK72g("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFK72g("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVU8ZS(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVhKHG(self):
  if self.isManualSeek:
   self.VVHKlo()
   self.VVoeLp(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVHKlo()
  else:
   self.close()
 def VVuUwZ(self):
  FFgbQa(self, fncMode=CCPltO.VVWrw3)
 def VVe55n(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVEYi4("Toggling Play/Pause ...")
 def VVHKlo(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVSdUs(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVK1Wz()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFpr4w(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FF4FJG(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFcGNd(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VV7JMW(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFw7jX(self["myPlayJmp"], self.VVBQHb())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVEYi4("Changed Jump Minutes to : %d" % val)
 def VVBQHb(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVEYi4(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  fr = res = ""
  if info:
   w = FF9E9G(info, iServiceInformation.sVideoWidth) or -1
   h = FF9E9G(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FF9E9G(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCPltO.VVv2fa(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVK1Wz()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFpr4w(percVal, 0, 100)
    width = int(FF4FJG(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFtJEw(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFtJEw(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVwQ1A() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFLdCa(self["myPlayMsg"], "#0000ffff")
   else  : FFLdCa(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFCJvX(refCode, True))
   FFLdCa(self["myPlayMsg"], "#00ff8066")
  tot = CCaDOu.VVghYT()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVt8Lq()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVoeLp(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVjCbZ()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFLdCa(self["myPlayMsg"], "#0000ff00")
  else     : FFLdCa(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVK1Wz(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFcGNd(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFcGNd(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFcGNd(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVt8Lq(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VViNKH(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVwQ1A()
   if cList:
    VVw8eP = []
    for pts, what in cList:
     txt = FFcGNd(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVw8eP.append((txt, pts))
    FF7Bt5(self, self.VVPvlR, VVw8eP=VVw8eP, title="Cut List")
   else:
    self.VVEYi4("No Cut-List for this channel !")
 def VVPvlR(self, item=None):
  if item:
   self.VVoeLp(item)
 def VVwQ1A(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV4NEk(self) : self.VVV1bW(self.jumpMinutes)
 def VV9J0P(self) : self.VVV1bW(-self.jumpMinutes)
 def VVV1bW(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVEYi4("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVEYi4("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVEYi4("Cannot jump")
 def VV8Vtp(self):
  InfoBar.instance.VV8Vtp()
 def VVoeLp(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVEYi4("Changing Time ...")
 def VVIrMX(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVK1Wz()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVEYi4("Jumping to end ...")
  except:
   pass
 def VVjCbZ(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV95cF(self, isUp):
  if self.enableZapping:
   self.VVEYi4("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVHKlo()
   if self.portalTableParam:
    FFlxSW(boundFunction(self.VV8Gyb, isUp))
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
    if "/timeshift/" in decodedUrl:
     self.VVEYi4("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVmAnf()
 def VVmAnf(self):
  self.lastPlayPos = 0
  self.VViAIF()
  self.VVEKXg()
 def VV8Gyb(self, isUp):
  CCNqVt_inatance, VVDhXw, mode = self.portalTableParam
  if isUp : VVDhXw.VVkT6z()
  else : VVDhXw.VVvqjG()
  colList = VVDhXw.VV7ku6()
  if mode == "localIptv":
   chName, chUrl = CCNqVt_inatance.VVN7Xf(VVDhXw, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCNqVt_inatance.VVIBhG(VVDhXw, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCNqVt_inatance.VVC4er(mode, VVDhXw, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCNqVt_inatance.VV4tZe(mode, VVDhXw, colList)
  else:
   self.VVEYi4("Cannot Zap")
   return
  FFaA9c(self, chUrl, VVNAZj=False)
  self.VVmAnf()
 def VVEKXg(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVK1Wz()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
   if not self.VVozjw(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVEYi4("Refreshing Portal")
   FFlxSW(self.VVX40H)
  except:
   pass
 def VVX40H(self):
  self.restoreLastPlayPos = self.VVvO6l()
 def VVhrGu(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFEnco(self)
  if not decodedUrl or FFzavm(decodedUrl):
   self.VVEYi4("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCNqVt.VVXjzP(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVEYi4("Reading Program List ...")
   ok_fnc = boundFunction(self.VVLgbi, refCode, chName, streamId, uHost, uUser, uPass)
   FFlxSW(boundFunction(CCNqVt.VVaJFM, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVEYi4("Cannot process this channel")
 def VVLgbi(self, refCode, chName, streamId, uHost, uUser, uPass, VVDhXw, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVDhXw.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVEYi4("Changing Program ...")
   FFlxSW(boundFunction(self.VVO41M, chUrl))
  else:
   self.VVEYi4("Incorrect Timestamp !")
 def VVO41M(self, chUrl):
   FFaA9c(self, chUrl, VVNAZj=False)
   self.lastPlayPos = 0
   self.VViAIF()
 def VVQqIQ(self, isAudio):
  try:
   VV0Hqr = InfoBar.instance
   if VV0Hqr:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV0Hqr)
    else  : self.session.open(SubtitleSelection, VV0Hqr)
  except:
   pass
class CCcMPQ(Screen):
 def __init__(self, session, title="", VVffrf="Continue?", VVyivk=True, VVPjh4=False):
  self.skin, self.skinParam = FFAEOm(VVrNoE, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVffrf = VVffrf
  self.VVPjh4 = VVPjh4
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVyivk : VVw8eP = [no , yes]
  else   : VVw8eP = [yes, no ]
  FFSF9U(self, title, VVw8eP=VVw8eP, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhKHG ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVffrf)
  if self.VVPjh4:
   self["myLabel"].instance.setHAlign(0)
  self.VVEkUE()
  FFAblH(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFv5ve(self["myMenu"])
  FFV5n0(self, self["myMenu"])
 def VVhKHG(self):
  item = FFPRHj(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVEkUE(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC6E4v(Screen):
 def __init__(self, session, title="", VVw8eP=None, width=1000, OKBtnFnc=None, VVjOJ6=None, VVvKTv=None, VVjOnb=None, VVzZGK=None, VVPsXE=False, VVqGaJ=False):
  self.skin, self.skinParam = FFAEOm(VVEShK, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVw8eP   = VVw8eP
  self.OKBtnFnc   = OKBtnFnc
  self.VVjOJ6   = VVjOJ6
  self.VVvKTv  = VVvKTv
  self.VVjOnb  = VVjOnb
  self.VVzZGK   = VVzZGK
  self.VVPsXE  = VVPsXE
  self.VVqGaJ  = VVqGaJ
  FFSF9U(self, title, VVw8eP=VVw8eP)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhKHG          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVp1GJ         ,
   "green"  : self.VVCTbY         ,
   "yellow" : self.VVuOKD         ,
   "blue"  : self.VVuAVr         ,
   "pageUp" : self.VVa1Pi       ,
   "chanUp" : self.VVa1Pi       ,
   "pageDown" : self.VV2Ipk        ,
   "chanDown" : self.VV2Ipk
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFAblH(self["myMenu"])
  FFoJNI(self)
  self.VVtJu2(self["keyRed"]  , self.VVjOJ6 )
  self.VVtJu2(self["keyGreen"] , self.VVvKTv )
  self.VVtJu2(self["keyYellow"] , self.VVjOnb )
  self.VVtJu2(self["keyBlue"]  , self.VVzZGK )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFEgCR(self)
 def VVtJu2(self, btnObj, btnFnc):
  if btnFnc:
   FFw7jX(btnObj, btnFnc[0])
 def VVhKHG(self):
  item = FFPRHj(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVPsXE: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVp1GJ(self)  : self.VVjPP8(self.VVjOJ6)
 def VVCTbY(self) : self.VVjPP8(self.VVvKTv)
 def VVuOKD(self) : self.VVjPP8(self.VVjOnb)
 def VVuAVr(self) : self.VVjPP8(self.VVzZGK)
 def VVjPP8(self, btnFnc):
  if btnFnc:
   item = FFPRHj(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVqGaJ:
    self.cancel()
 def VVCLj8(self, VVw8eP):
  if len(VVw8eP) > 0:
   newList = []
   for item in VVw8eP:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVxUAr(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVa1Pi(self):
  self["myMenu"].moveToIndex(0)
 def VV2Ipk(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCMmmJ(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVNz0H=None, VVSgvw=None, VVTy8n=None, VVjgTX=26, VVjrzO=False, VV2zCi=None, VV2kYm=None, VVJGeM=None, VVicyB=None, VV6rfs=None, VVtvPm=None, VVSR5M=None, VVbsCJ=None, VV33pw=None, VVweEQ=-1, VVHESo=False, searchCol=0, VVRFto=None, VVHhCo=None, VVBvOr="#00dddddd", VVYhbt="#11002233", VVRrPm="#00ff8833", VVOU5Z="#11111111", VVD2dA="#0a555555", VV8hBr="#0affffff", VVw0pN="#11552200", VVXg1s="#0055ff55"):
  self.skin, self.skinParam = FFAEOm(VVA30l, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFSF9U(self, title)
  self.header     = header
  self.VVNz0H     = VVNz0H
  self.totalCols    = len(VVNz0H[0])
  self.VVhoKj   = 0
  self.lastSortModeIsReverese = False
  self.VVjrzO   = VVjrzO
  self.VVQGlJ   = 0.01
  self.VVe9yO   = 0.02
  self.VVr5PX = 0.03
  self.VViXep  = 1
  self.VVTy8n = VVTy8n
  self.colWidthPixels   = []
  self.VV2zCi   = VV2zCi
  self.OKButtonObj   = None
  self.VV2kYm   = VV2kYm
  self.VVJGeM   = VVJGeM
  self.VVicyB   = VVicyB
  self.VV6rfs  = VV6rfs
  self.VVtvPm   = VVtvPm
  self.VVSR5M    = VVSR5M
  self.VVbsCJ   = VVbsCJ
  self.VV33pw  = VV33pw
  self.VVweEQ    = VVweEQ
  self.VVHESo   = VVHESo
  self.searchCol    = searchCol
  self.VVSgvw    = VVSgvw
  self.keyPressed    = -1
  self.VVjgTX    = FFjMIC(VVjgTX)
  self.VVOJXs    = FF6bag(self.VVjgTX, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVRFto    = VVRFto
  self.VVHhCo      = VVHhCo
  self.VVBvOr    = FFKiR0(VVBvOr)
  self.VVYhbt    = FFKiR0(VVYhbt)
  self.VVRrPm    = FFKiR0(VVRrPm)
  self.VVOU5Z    = FFKiR0(VVOU5Z)
  self.VVD2dA   = FFKiR0(VVD2dA)
  self.VV8hBr    = FFKiR0(VV8hBr)
  self.VVw0pN    = FFKiR0(VVw0pN)
  self.VVXg1s   = FFKiR0(VVXg1s)
  self.VVPj4J  = False
  self.selectedItems   = 0
  self.VVCgCT   = FFKiR0("#01fefe01")
  self.VVTdP5   = FFKiR0("#11400040")
  self.VV7qoO  = self.VVCgCT
  self.VVgUpG  = self.VVOU5Z
  if self.VVHESo:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV6vYz  ,
   "red"   : self.VV66lQ  ,
   "green"   : self.VVEqIp ,
   "yellow"  : self.VV2mXv ,
   "blue"   : self.VVDX5i  ,
   "menu"   : self.VVmbnb ,
   "info"   : self.VV6gjg  ,
   "cancel"  : self.VVNxug  ,
   "up"   : self.VVvqjG    ,
   "down"   : self.VVkT6z  ,
   "left"   : self.VVlZ6D   ,
   "right"   : self.VV1d4U  ,
   "pageUp"  : self.VV8lr5  ,
   "chanUp"  : self.VV8lr5  ,
   "pageDown"  : self.VVqLgb  ,
   "chanDown"  : self.VVqLgb
  }, -1)
  FFGWyw(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFzPkO(self)
  try:
   self.VV01gr()
  except Exception as err:
   FFc88f(self, str(err))
   self.close(None)
 def VV01gr(self):
  FFEgCR(self)
  if self.VVRFto:
   FFtJEw(self["myTitle"], self.VVRFto)
  if self.VVHhCo:
   FFtJEw(self["myBody"] , self.VVHhCo)
   FFtJEw(self["myTableH"] , self.VVHhCo)
   FFtJEw(self["myTable"] , self.VVHhCo)
   FFtJEw(self["myBar"]  , self.VVHhCo)
  self.VVtJu2(self.VVJGeM  , self["keyRed"])
  self.VVtJu2(self.VVicyB  , self["keyGreen"])
  self.VVtJu2(self.VV6rfs , self["keyYellow"])
  self.VVtJu2(self.VVtvPm  , self["keyBlue"])
  if self.VV2zCi:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV2zCi[0])
    FFtJEw(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVOJXs)
  self["myTableH"].l.setFont(0, gFont(VV55z0, self.VVjgTX))
  self["myTable"].l.setItemHeight(self.VVOJXs)
  self["myTable"].l.setFont(0, gFont(VV55z0, self.VVjgTX))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVOJXs)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVOJXs))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVOJXs)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVOJXs
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVOJXs * len(self.VVNz0H) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVTy8n:
   self.VVTy8n = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVTy8n)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVSgvw:
   self.VVSgvw = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVSgvw
   self.VVSgvw = []
   for item in tmpList:
    self.VVSgvw.append(item | RT_VALIGN_CENTER)
  self.VVpTC2()
  if self.VVSR5M:
   self.VVSR5M(self)
 def VVtJu2(self, btnFnc, btn):
  if btnFnc : FFw7jX(btn, btnFnc[0])
  else  : FFw7jX(btn, "")
 def VVIz4K(self, waitTxt):
  FFKl3w(self, self.VVpTC2, title=waitTxt)
 def VVpTC2(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVhgUM(0, self.header, self.VV8hBr, self.VVw0pN, self.VV8hBr, self.VVw0pN, self.VVXg1s)])
   rows = []
   for c, row in enumerate(self.VVNz0H):
    rows.append(self.VVhgUM(c, row, self.VVBvOr, self.VVYhbt, self.VVRrPm, self.VVOU5Z, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVweEQ > -1:
    self["myTable"].moveToIndex(self.VVweEQ )
   self.VV7Inr()
   if self.VVHESo:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVOJXs * len(self.VVNz0H)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVbsCJ:
    self.VVjPP8(self.VVbsCJ, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFc88f(self, str(err))
    self.close()
   except:
    pass
 def VVhgUM(self, keyIndex, columns, VVBvOr, VVYhbt, VVRrPm, VVOU5Z, VVXg1s):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVXg1s and ndx == self.VVhoKj : textColor = VVXg1s
   else           : textColor = VVBvOr
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFKiR0(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVYhbt = c
    entry = span.group(3)
   if self.VVSgvw[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVOJXs)
           , font   = 0
           , flags   = self.VVSgvw[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVYhbt
           , color_sel  = VVRrPm
           , backcolor_sel = VVOU5Z
           , border_width = 1
           , border_color = self.VVD2dA
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VV6gjg(self):
  rowData = self.VVFf4u()
  if rowData:
   title, txt, colList = rowData
   if self.VV2kYm:
    fnc  = self.VV2kYm[1]
    params = self.VV2kYm[2]
    fnc(self, title, txt, colList)
   else:
    FFVxvP(self, txt, title)
 def VV6vYz(self):
  if   self.VVPj4J : self.VVEMOu(self.VVynuF(), mode=2)
  elif self.VV2zCi  : self.VVjPP8(self.VV2zCi, None)
  else      : self.VV6gjg()
 def VV66lQ(self) : self.VVjPP8(self.VVJGeM , self["keyRed"])
 def VVEqIp(self) : self.VVjPP8(self.VVicyB , self["keyGreen"])
 def VV2mXv(self): self.VVjPP8(self.VV6rfs , self["keyYellow"])
 def VVDX5i(self) : self.VVjPP8(self.VVtvPm , self["keyBlue"])
 def VVjPP8(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF4n96(self, buttonFnc[3])
    FFlxSW(boundFunction(self.VVkuD2, buttonFnc))
   else:
    self.VVkuD2(buttonFnc)
 def VVkuD2(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVFf4u()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVEMOu(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVNz0H[ndx]
   isSelected = row[1][9] == self.VVCgCT
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVhgUM(ndx, item, self.VVBvOr, self.VVYhbt, self.VVRrPm, self.VVOU5Z, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVhgUM(ndx, item, self.VVCgCT, self.VVTdP5, self.VV7qoO, self.VVgUpG, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV7Inr()
 def VVix1Z(self):
  FFKl3w(self, self.VVI3Jk, title="Selecting all ...")
 def VVI3Jk(self):
  self.VVCMKg(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVCgCT
   if not isSelected:
    item = self.VVNz0H[ndx]
    newRow = self.VVhgUM(ndx, item, self.VVCgCT, self.VVTdP5, self.VV7qoO, self.VVgUpG, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VV7Inr()
  self.VVvUiW()
 def VV1FmU(self):
  FFKl3w(self, self.VV2cJF, title="Unselecting all ...")
 def VV2cJF(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVCgCT:
    item = self.VVNz0H[ndx]
    newRow = self.VVhgUM(ndx, item, self.VVBvOr, self.VVYhbt, self.VVRrPm, self.VVOU5Z, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VV7Inr()
  self.VVvUiW()
 def VVvUiW(self):
  self.hide()
  self.show()
 def VVFf4u(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVTy8n[i] > 1 or self.VVTy8n[i] == self.VVQGlJ or self.VVTy8n[i] == self.VVr5PX:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVNz0H))
   return rowNum, txt, colList
  else:
   return None
 def VVNxug(self):
  if self.VV33pw : self.VV33pw(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VV1toc(self):
  return self["myTitle"].getText().strip()
 def VV68Jf(self):
  return self.header
 def VVI5gL(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVjyHB(self, txt):
  FF4n96(self, txt)
 def VVEQT9(self, txt):
  FF4n96(self, txt, 1000)
 def VVdfHL(self):
  FF4n96(self)
 def VVYQpG(self):
  return len(self.VVNz0H)
 def VVfo2R(self): self["keyGreen"].show()
 def VVXMpr(self): self["keyGreen"].hide()
 def VVynuF(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVljsD(self):
  return len(self["myTable"].list)
 def VVCMKg(self, isOn):
  self.VVPj4J = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVtvPm: self["keyBlue"].hide()
   if self.VV2zCi and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVtvPm: self["keyBlue"].show()
   if self.VV2zCi and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV2zCi[0])
   self.VV1FmU()
  FFtJEw(self["myTitle"], color)
  FFtJEw(self["myBar"]  , color)
 def VVd7Y6(self):
  return self.VVPj4J
 def VVcoRU(self):
  return self.selectedItems
 def VVVx22(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VV7Inr()
 def VVlxiN(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VV7Inr()
 def VVQKWl(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVNz0H:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVI49x(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVYQpG()
  txt += FFGsc3("Total Unique Items", VVtUnE)
  for i in range(self.totalCols):
   if self.VVTy8n[i - 1] > 1 or self.VVTy8n[i - 1] == self.VVQGlJ or self.VVTy8n[i - 1] == self.VVr5PX:
    name, tot = self.VVQKWl(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFVxvP(self, txt)
 def VVLIgd(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV7ku6(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVC9qg(self, newList, newTitle="", VVGTt2Msg=True):
  if newList:
   self.VVNz0H = newList
   if self.VVjrzO and self.VVhoKj == 0:
    self.VVNz0H = sorted(self.VVNz0H, key=lambda x: int(x[self.VVhoKj])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVNz0H = sorted(self.VVNz0H, key=lambda x: x[self.VVhoKj].lower(), reverse=self.lastSortModeIsReverese)
   if VVGTt2Msg : self.VVIz4K("Refreshing ...")
   else   : self.VVpTC2()
   if newTitle:
    self.VVI5gL(newTitle)
  else:
   FFc88f(self, "Cannot refresh list")
   self.cancel()
 def VV9aPB(self, data):
  ndx = self.VVynuF()
  newRow = self.VVhgUM(ndx, data, self.VVBvOr, self.VVYhbt, self.VVRrPm, self.VVOU5Z, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV7Inr()
   return True
  else:
   return False
 def VV0DkM(self, colNum, textToFind, VVoTpo=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VV7Inr()
    break
  else:
   if VVoTpo:
    FF4n96(self, "Not found", 1000)
 def VV9BEJ(self, colDict, VVoTpo=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV7Inr()
    return
  if VVoTpo:
   FF4n96(self, "Not found", 1000)
 def VV9BEJ_partial(self, colDict, VVoTpo=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VV7Inr()
    return
  if VVoTpo:
   FF4n96(self, "Not found", 1000)
 def VVc4m9(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVoWIX(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVCgCT:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVB6yQ(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVmbnb(self):
  if not self["keyMenu"].getVisible() or self.VVHESo:
   return
  VVw8eP = []
  VVw8eP.append(("Table Statistcis"             , "tableStat"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append((FFkGYB("Export Table to .html"     , VVtUnE) , "VVp6oI" ))
  VVw8eP.append((FFkGYB("Export Table to .csv"     , VVtUnE) , "VVIWrI" ))
  VVw8eP.append((FFkGYB("Export Table to .txt (Tab Separated)", VVtUnE) , "VVYhnZ" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVTy8n[i] > 1 or self.VVTy8n[i] == self.VVe9yO:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVw8eP.append(VV9e5C)
   if tot == 1 : VVw8eP.append(("Sort", sList[0][1]))
   else  : VVw8eP += sList
  FF7Bt5(self, self.VVVUho, VVw8eP=VVw8eP, title=self.VV1toc())
 def VVVUho(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVI49x()
   elif item == "VVp6oI": FFKl3w(self, self.VVp6oI, title=title)
   elif item == "VVIWrI" : FFKl3w(self, self.VVIWrI , title=title)
   elif item == "VVYhnZ" : FFKl3w(self, self.VVYhnZ , title=title)
   else:
    isReversed = False
    if self.VVhoKj == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVjrzO and item == 0:
     self.VVNz0H = sorted(self.VVNz0H, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVNz0H = sorted(self.VVNz0H, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVhoKj = item
    self.VVIz4K("Sorting ...")
 def VVvqjG(self):
  self["myTable"].up()
  self.VV7Inr()
 def VVkT6z(self):
  self["myTable"].down()
  self.VV7Inr()
 def VVlZ6D(self):
  self["myTable"].pageUp()
  self.VV7Inr()
 def VV1d4U(self):
  self["myTable"].pageDown()
  self.VV7Inr()
 def VV8lr5(self):
  self["myTable"].moveToIndex(0)
  self.VV7Inr()
 def VVqLgb(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VV7Inr()
 def VVINep(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VV7Inr()
 def VVYhnZ(self):
  expFile = self.VVKnEn() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVEkoU()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVNz0H:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVTy8n[ndx] > self.VViXep or self.VVTy8n[ndx] == self.VVr5PX:
      col = self.VVatOz(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VV4Ksp(expFile)
 def VVIWrI(self):
  expFile = self.VVKnEn() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVEkoU()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVNz0H:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVTy8n[ndx] > self.VViXep or self.VVTy8n[ndx] == self.VVr5PX:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVatOz(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VV4Ksp(expFile)
 def VVp6oI(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV1toc(), PLUGIN_NAME, VV96cs)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV1toc()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVEkoU()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVTy8n:
   colgroup += '   <colgroup>'
   for w in self.VVTy8n:
    if w > self.VViXep or w == self.VVr5PX:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVKnEn() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVNz0H:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVTy8n[ndx] > self.VViXep or self.VVTy8n[ndx] == self.VVr5PX:
      col = self.VVatOz(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VV4Ksp(expFile)
 def VVEkoU(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVTy8n[ndx] > self.VViXep or self.VVTy8n[ndx] == self.VVr5PX:
     newRow.append(col.strip())
  return newRow
 def VVatOz(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFtG6X(col)
 def VVKnEn(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV1toc())
  fileName = fileName.replace("__", "_")
  path  = FF1ZUc(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFnEIN()
  return expFile
 def VV4Ksp(self, expFile):
  FF1ATN(self, "File exported to:\n\n%s" % expFile, title=self.VV1toc())
 def VV7Inr(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC8A64(Screen):
 def __init__(self, session, title="", VVk9uz=None, showGrnMsg=""):
  self.skin, self.skinParam = FFAEOm(VVb7Jj, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFSF9U(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVk9uz = VVk9uz
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  allOK = FFfb15(self["myLabel"], self.VVk9uz)
  if allOK:
   if self.showGrnMsg:
    FF4n96(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFc88f(self, "Cannot view picture file:\n\n%s" % self.VVk9uz)
   self.close()
class CCFOfb(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAEOm(VVQTx4, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  FFSF9U(self)
  FFw7jX(self["keyGreen"], "Save")
  self.VVNz0H = []
  self.VVNz0H.append(getConfigListEntry("Show in Main Menu"          , CFG.showInMainMenu   ))
  self.VVNz0H.append(getConfigListEntry("Show in Extensions Menu"         , CFG.showInExtensionMenu  ))
  self.VVNz0H.append(getConfigListEntry("Show in Channel List Context Menu"      , CFG.showInChannelListMenu  ))
  self.VVNz0H.append(getConfigListEntry("Show in Events Info Menu"        , CFG.EventsInfoMenu   ))
  self.VVNz0H.append(getConfigListEntry("Input Type"            , CFG.keyboard     ))
  self.VVNz0H.append(getConfigListEntry("Signal & Player Cotroller Hotkey"      , CFG.hotkey_signal    ))
  if VVjdSQ:
   self.VVNz0H.append(getConfigListEntry("EPG Translation Language"       , CFG.epgLanguage    ))
  self.VVNz0H.append(getConfigListEntry(VVS5oR *2             ,         ))
  self.VVNz0H.append(getConfigListEntry("Default IPTV Reference Type"        , CFG.iptvAddToBouquetRefType ))
  self.VVNz0H.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"  , CFG.autoResetFrozenIptvChan ))
  self.VVNz0H.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"     , CFG.hideIptvServerAdultWords ))
  self.VVNz0H.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"  , CFG.hideIptvServerChannPrefix ))
  self.VVNz0H.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"   , CFG.iptvHostsPath    ))
  self.VVNz0H.append(getConfigListEntry("Movie/Series Download Path"        , CFG.MovieDownloadPath   ))
  self.VVNz0H.append(getConfigListEntry(VVS5oR *2             ,         ))
  self.VVNz0H.append(getConfigListEntry("PIcons Path"            , CFG.PIconsPath    ))
  self.VVNz0H.append(getConfigListEntry(VVS5oR *2             ,         ))
  self.VVNz0H.append(getConfigListEntry("Backup/Restore Path"          , CFG.backupPath    ))
  self.VVNz0H.append(getConfigListEntry("Created Package Files (IPK/DEB)"       , CFG.packageOutputPath   ))
  self.VVNz0H.append(getConfigListEntry("Downloaded Packages (from feeds)"      , CFG.downloadedPackagesPath ))
  self.VVNz0H.append(getConfigListEntry("Exported Tables"           , CFG.exportedTablesPath  ))
  self.VVNz0H.append(getConfigListEntry("Exported PIcons"           , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVNz0H, session)
  self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhKHG   ,
   "green"  : self.VVX9Co  ,
   "menu"  : self.VVaVew ,
   "cancel" : self.VVYdDb
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFzPkO(self)
  FFAblH(self["config"])
  FFoJNI(self,  self["config"])
  FFEgCR(self)
 def VVhKHG(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VV6w7G()
   elif item == CFG.MovieDownloadPath   : self.VVn2Az(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVjYe6(item)
   elif item == CFG.backupPath    : self.VVjYe6(item)
   elif item == CFG.packageOutputPath  : self.VVjYe6(item)
   elif item == CFG.downloadedPackagesPath : self.VVjYe6(item)
   elif item == CFG.exportedTablesPath  : self.VVjYe6(item)
   elif item == CFG.exportedPIconsPath  : self.VVjYe6(item)
 def VVn2Az(self, item, title):
  tot = CCaDOu.VVghYT()
  if tot : FFc88f(self, "Cannot change while downloading.", title=title)
  else : self.VVjYe6(item)
 def VV6w7G(self):
  VVw8eP = []
  VVw8eP.append(("Auto Find" , "auto"))
  VVw8eP.append(("Custom Path" , "path"))
  FF7Bt5(self, self.VVAaQ2, VVw8eP=VVw8eP, title="IPTV Hosts Files Path")
 def VVAaQ2(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVZnKC)
   elif item == "path": self.VVjYe6(CFG.iptvHostsPath)
 def VVjYe6(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVZnKC:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VV98qG, configObj)
         , boundFunction(CCWnyZ, mode=CCWnyZ.VVH82H, VVZHg3=sDir))
 def VV98qG(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVYdDb(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.autoResetFrozenIptvChan.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.MovieDownloadPath.isChanged()   or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFfK5z(self, self.VVX9Co, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVX9Co(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVZPxC()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVaVew(self):
  VVw8eP = []
  VVw8eP.append(("Use Backup directory in all other paths"      , "VVYyyn"   ))
  VVw8eP.append(("Reset all to default (including File Manager bookmarks)"  , "VVAFBP"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Backup %s Settings" % PLUGIN_NAME        , "VVegru"  ))
  VVw8eP.append(("Restore %s Settings" % PLUGIN_NAME       , "VVyk2a"  ))
  if fileExists(VVvHG2 + VVxv1o):
   VVw8eP.append(VV9e5C)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVw8eP.append(('%s Checking for Update' % txt1       , txt2     ))
   VVw8eP.append(("Reinstall %s" % PLUGIN_NAME        , "VVqAwc"  ))
   VVw8eP.append(("Update %s" % PLUGIN_NAME        , "VVLcc0"   ))
  FF7Bt5(self, self.VV7i9l, VVw8eP=VVw8eP, title="Config. Options")
 def VV7i9l(self, item=None):
  if item:
   if   item == "VVYyyn"  : FFfK5z(self, self.VVYyyn , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVAFBP"  : FFfK5z(self, self.VVAFBP, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CC4LkW)
   elif item == "VVegru" : self.VVegru()
   elif item == "VVyk2a" : FFKl3w(self, self.VVyk2a, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VViyXf(True)
   elif item == "disableChkUpdate" : self.VViyXf(False)
   elif item == "VVqAwc" : FFKl3w(self, self.VVqAwc , "Checking Server ...")
   elif item == "VVLcc0"  : FFKl3w(self, self.VVLcc0  , "Checking Server ...")
 def VVegru(self):
  path = "%sajpanel_settings_%s" % (VVvHG2, FFnEIN())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FF1ATN(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVyk2a(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFgPQo("find / %s -iname '%s*' | grep %s" % (FFYGMZ(1), name, name))
  if lines:
   lines.sort()
   VVw8eP = []
   for line in lines:
    VVw8eP.append((line, line))
   FF7Bt5(self, boundFunction(self.VVHtTQ, title), title=title, VVw8eP=VVw8eP, width=1200)
  else:
   FFc88f(self, "No settings files found !", title=title)
 def VVHtTQ(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFg2eB(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVZPxC()
    FFwRBd()
   else:
    FFOr2O(SELF, path, title=title)
 def VViyXf(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVYyyn(self):
  newPath = FF1ZUc(VVvHG2)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVZPxC()
 @staticmethod
 def VVPLGT():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVAFBP(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(False)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVZnKC)
  CFG.MovieDownloadPath.setValue(CCaDOu.VVFpZ8())
  CFG.PIconsPath.setValue(VVgOqp)
  CFG.backupPath.setValue(CCFOfb.VVPLGT())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.autoResetFrozenIptvChan.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.MovieDownloadPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVZPxC()
  self.close()
 def VVZPxC(self):
  configfile.save()
  global VVvHG2
  VVvHG2 = CFG.backupPath.getValue()
  FFtFJf()
 def VVLcc0(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVJBvi(title)
  if webVer:
   FFfK5z(self, boundFunction(FFKl3w, self, boundFunction(self.VV63TW, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVqAwc(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVJBvi(title, True)
  if webVer:
   FFfK5z(self, boundFunction(FFKl3w, self, boundFunction(self.VV63TW, webVer, title)), "Install and Restart ?", title=title)
 def VV63TW(self, webVer, title):
  url = self.VVExh4(self, title)
  if url:
   VViYVL = FFFQGA() == "dpkg"
   if VViYVL == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VViYVL else "ipk")
   path, err = FFPEOO(url + fName, fName, timeout=2)
   if path:
    cmd = FFp0JH(VV0Gj2, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFypV6(self, cmd)
    else:
     FFdCT7(self, title=title)
   else:
    FFc88f(self, err, title=title)
 def VVJBvi(self, title, anyVer=False):
  url = self.VVExh4(self, title)
  if not url:
   return ""
  path, err = FFPEOO(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFc88f(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFzVLg(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFc88f(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VV96cs.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFgPQo(cmd)
   if list and curVer == list[0]:
    return webVer
  FF1ATN(self, FFkGYB("No update required.", VVfxXg) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVExh4(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVvHG2 + VVxv1o
  if fileExists(path):
   span = iSearch(r"(http.+)", FFzVLg(path), IGNORECASE)
   if span : url = FF1ZUc(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFc88f(SELF, err, title)
  return url
 @staticmethod
 def VVSTiY(url):
  path, err = FFPEOO(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFzVLg(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VV96cs.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFgPQo(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CC4LkW(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAEOm(VVIVwd, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VV8qMu
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFSF9U(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVPvan("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVPvan("\c00888888", i) + sp + "GREY\n"
   txt += self.VVPvan("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVPvan("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVPvan("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVPvan("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVPvan("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVPvan("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVPvan("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVPvan("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVPvan("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVPvan("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVhKHG ,
   "green"   : self.VVhKHG ,
   "left"   : self.VVmZkC ,
   "right"   : self.VVTOrf ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  self.VVWE94()
 def VVhKHG(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFfK5z(self, self.VVr6Z4, "Change to : %s" % txt, title=self.Title)
 def VVr6Z4(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VV8qMu
  VV8qMu = self.cursorPos
  self.VVlPxa()
  self.close()
 def VVmZkC(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVWE94()
 def VVTOrf(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVWE94()
 def VVWE94(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVPvan(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV1rCL(color):
  if VVYPWI: return "\\" + color
  else    : return ""
 @staticmethod
 def VVlPxa():
  global VVfjTY, VVLchc, VVFT40, VVtUnE, VVzCLY, VVwwQa, VVfxXg, VVYPWI, COLOR_CONS_BRIGHT_YELLOW, VVy6YC, VVakPb, VV0cUe, VVB0Ol
  VVB0Ol   = CC4LkW.VVPvan("\c00FFFFFF", VV8qMu)
  VVLchc    = CC4LkW.VVPvan("\c00888888", VV8qMu)
  VVfjTY  = CC4LkW.VVPvan("\c005A5A5A", VV8qMu)
  VVwwQa    = CC4LkW.VVPvan("\c00FF0000", VV8qMu)
  VVFT40   = CC4LkW.VVPvan("\c00FF5000", VV8qMu)
  VVYPWI   = CC4LkW.VVPvan("\c00FFFF00", VV8qMu)
  COLOR_CONS_BRIGHT_YELLOW = CC4LkW.VVPvan("\c00FFFFAA", VV8qMu)
  VVfxXg   = CC4LkW.VVPvan("\c0000FF00", VV8qMu)
  VVzCLY    = CC4LkW.VVPvan("\c000066FF", VV8qMu)
  VVy6YC    = CC4LkW.VVPvan("\c0000FFFF", VV8qMu)
  VVakPb  = CC4LkW.VVPvan("\c00DSFFFF", VV8qMu)  #
  VV0cUe   = CC4LkW.VVPvan("\c00FA55E7", VV8qMu)
  VVtUnE    = CC4LkW.VVPvan("\c00FF8F5F", VV8qMu)
CC4LkW.VVlPxa()
class CCMmad(Screen):
 def __init__(self, session, path, VViYVL):
  self.skin, self.skinParam = FFAEOm(VVyduo, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVu9hp   = path
  self.VVpCQ6   = ""
  self.VVmkz5   = ""
  self.VViYVL    = VViYVL
  self.VVdDLq    = ""
  self.VV4FQ7  = ""
  self.VVwCrO    = False
  self.VVYTr5  = False
  self.postInstAcion   = 0
  self.VVlJwr  = "enigma2-plugin-extensions"
  self.VVXcXp  = "enigma2-plugin-systemplugins"
  self.VVYOei = "enigma2"
  self.VVLpxJ  = 0
  self.VV2GOP  = 1
  self.VVcvQZ  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV7xUH = "DEBIAN"
  else        : self.VV7xUH = "CONTROL"
  self.controlPath = self.Path + self.VV7xUH
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VViYVL:
   self.packageExt  = ".deb"
   self.VVYhbt  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVYhbt  = "#11001020"
  FFSF9U(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFw7jX(self["keyRed"] , "Create")
  FFw7jX(self["keyGreen"] , "Post Install")
  FFw7jX(self["keyYellow"], "Installation Path")
  FFw7jX(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVTPa5  ,
   "green"   : self.VV5auC ,
   "yellow"  : self.VVdf8o  ,
   "blue"   : self.VVkERk  ,
   "cancel"  : self.VV2OTy
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  FFEgCR(self)
  if self.VVYhbt:
   FFtJEw(self["myBody"], self.VVYhbt)
   FFtJEw(self["myLabel"], self.VVYhbt)
  self.VV9Glb(True)
  self.VVTiiH(True)
 def VVTiiH(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVNqDZ()
  if isFirstTime:
   if   package.startswith(self.VVlJwr) : self.VVu9hp = VVbBic + self.VVdDLq + "/"
   elif package.startswith(self.VVXcXp) : self.VVu9hp = VVm7l9 + self.VVdDLq + "/"
   else            : self.VVu9hp = self.Path
  if self.VVwCrO : myColor = VVtUnE
  else    : myColor = VVB0Ol
  txt  = ""
  txt += "Source Path\t: %s\n" % FFkGYB(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFkGYB(self.VVu9hp, VVYPWI)
  if self.VVmkz5 : txt += "Package File\t: %s\n" % FFkGYB(self.VVmkz5, VVLchc)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFkGYB("Check Control File fields : %s" % errTxt, VVFT40)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFkGYB("Restart GUI", VVtUnE)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFkGYB("Reboot Device", VVtUnE)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFkGYB("Post Install", VVfxXg), act)
  if not errTxt and VVFT40 in controlInfo:
   txt += "Warning\t: %s\n" % FFkGYB("Errors in control file may affect the result package.", VVFT40)
  txt += "\nControl File\t: %s\n" % FFkGYB(self.controlFile, VVLchc)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV5auC(self):
  VVw8eP = []
  VVw8eP.append(("No Action"    , "noAction"  ))
  VVw8eP.append(("Restart GUI"    , "VVB3GY"  ))
  VVw8eP.append(("Reboot Device"   , "rebootDev"  ))
  FF7Bt5(self, self.VVzGBb, title="Package Installation Option (after completing installation)", VVw8eP=VVw8eP)
 def VVzGBb(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVB3GY"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV9Glb(False)
   self.VVTiiH()
 def VVdf8o(self):
  rootPath = FFkGYB("/%s/" % self.VVdDLq, VVfjTY)
  VVw8eP = []
  VVw8eP.append(("Current Path"        , "toCurrent"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Extension Path"       , "toExtensions" ))
  VVw8eP.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVw8eP.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF7Bt5(self, self.VVntvN, title="Installation Path", VVw8eP=VVw8eP)
 def VVntvN(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVjvAe(FFxq1R(self.Path, True))
   elif item == "toExtensions"  : self.VVjvAe(VVbBic)
   elif item == "toSystemPlugins" : self.VVjvAe(VVm7l9)
   elif item == "toRootPath"  : self.VVjvAe("/")
   elif item == "toRoot"   : self.VVjvAe("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVUhZi, boundFunction(CCWnyZ, mode=CCWnyZ.VVH82H, VVZHg3=VVvHG2))
 def VVUhZi(self, path):
  if len(path) > 0:
   self.VVjvAe(path)
 def VVjvAe(self, parent, withPackageName=True):
  if withPackageName : self.VVu9hp = parent + self.VVdDLq + "/"
  else    : self.VVu9hp = "/"
  mode = self.VVWSOj()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV82nU(mode), self.controlFile))
  self.VVTiiH()
 def VVkERk(self):
  if fileExists(self.controlFile):
   lines = FFg2eB(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFTT6y(self, self.VVCoLg, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFc88f(self, "Version not found or incorrectly set !")
  else:
   FFOr2O(self, self.controlFile)
 def VVCoLg(self, VVIh6s):
  if VVIh6s:
   version, color = self.VVXH8t(VVIh6s, False)
   if color == VVy6YC:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVIh6s, self.controlFile))
    self.VVTiiH()
   else:
    FFc88f(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV2OTy(self):
  if self.newControlPath:
   if self.VVwCrO:
    self.VV6J5K()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFkGYB(self.newControlPath, VVLchc)
    txt += FFkGYB("Do you want to keep these files ?", VVYPWI)
    FFfK5z(self, self.close, txt, callBack_No=self.VV6J5K, title="Create Package", VVPjh4=True)
  else:
   self.close()
 def VV6J5K(self):
  os.system(FFK72g("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV82nU(self, mode):
  if   mode == self.VV2GOP : prefix = self.VVlJwr
  elif mode == self.VVcvQZ : prefix = self.VVXcXp
  else        : prefix = self.VVYOei
  return prefix + "-" + self.VV4FQ7
 def VVWSOj(self):
  if   self.VVu9hp.startswith(VVbBic) : return self.VV2GOP
  elif self.VVu9hp.startswith(VVm7l9) : return self.VVcvQZ
  else            : return self.VVLpxJ
 def VV9Glb(self, isFirstTime):
  self.VVdDLq   = os.path.basename(os.path.normpath(self.Path))
  self.VVdDLq   = "_".join(self.VVdDLq.split())
  self.VV4FQ7 = self.VVdDLq.lower()
  self.VVwCrO = self.VV4FQ7 == VViplk.lower()
  if self.VVwCrO and self.VV4FQ7.endswith("ajpan"):
   self.VV4FQ7 += "el"
  if self.VVwCrO : self.VVpCQ6 = VVvHG2
  else    : self.VVpCQ6 = CFG.packageOutputPath.getValue()
  self.VVpCQ6 = FF1ZUc(self.VVpCQ6)
  if not pathExists(self.controlPath):
   os.system(FFK72g("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVwCrO : t = PLUGIN_NAME
  else    : t = self.VVdDLq
  self.VVGX10(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVTTSd.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVwCrO : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVGX10(self.postrmFile, txt)
  if self.VVwCrO:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VV96cs)
   self.VVGX10(self.preinstFile, txt)
  else:
   self.VVGX10(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVdDLq)
  mode = self.VVWSOj()
  if isFirstTime and not mode == self.VVLpxJ:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVS5oR
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVGX10(self.postinstFile, txt, VVUq9I=True)
  os.system(FFK72g("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVwCrO : version, descripton, maintainer = VV96cs , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVdDLq , self.VVdDLq
   txt = ""
   txt += "Package: %s\n"  % self.VV82nU(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVGX10(self, path, lines, VVUq9I=False):
  if not fileExists(path) or VVUq9I:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVNqDZ(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFg2eB(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFkGYB(line, VVFT40)
     elif not line.startswith(" ")    : line = FFkGYB(line, VVFT40)
     else          : line = FFkGYB(line, VVy6YC)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVy6YC
   else   : color = VVFT40
   descr = FFkGYB(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVFT40
     elif line.startswith((" ", "\t")) : color = VVFT40
     elif line.startswith("#")   : color = VVLchc
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVXH8t(val, True)
      elif key == "Version"  : version, color = self.VVXH8t(val, False)
      elif key == "Maintainer" : maint  , color = val, VVy6YC
      elif key == "Architecture" : arch  , color = val, VVy6YC
      else:
       color = VVy6YC
      if not key == "OE" and not key.istitle():
       color = VVFT40
     else:
      color = VVtUnE
     txt += FFkGYB(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVmkz5 = self.VVpCQ6 + packageName
   self.VVYTr5 = True
   errTxt = ""
  else:
   self.VVmkz5  = ""
   self.VVYTr5 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVXH8t(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVy6YC
  else          : return val, VVFT40
 def VVTPa5(self):
  if not self.VVYTr5:
   FFc88f(self, "Please fix Control File errors first.")
   return
  if self.VViYVL: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFxq1R(self.VVu9hp, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVdDLq
  symlinkTo  = FFh7YC(self.Path)
  dataDir   = self.VVu9hp.rstrip("/")
  removePorjDir = FFK72g("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFK72g("rm -f '%s'" % self.VVmkz5) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFsXZx()
  if self.VViYVL:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFQAHp("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVwCrO:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVu9hp == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV7xUH)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVmkz5, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVmkz5
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVmkz5, FF6sH0(result  , VVfxXg))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVu9hp, FF6sH0(instPath, VVy6YC))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF6sH0(failed, VVFT40))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFypV6(self, cmd)
class CCWnyZ(Screen):
 VV5tIT   = 0
 VVH82H  = 1
 VVrRai = 20
 VVXGnR  = None
 def __init__(self, session, VVZHg3="/", mode=VV5tIT, VVmM5k="Select", VVjgTX=30, gotoMovie=False):
  self.skin, self.skinParam = FFAEOm(VVEShK, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFSF9U(self)
  FFw7jX(self["keyRed"] , "Exit")
  FFw7jX(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVmM5k = VVmM5k
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCWnyZ.VVXGnR = self
  if   self.gotoMovie        : VVpW60, self.VVZHg3 = True , CCWnyZ.VVQPBU(self)[1] or "/"
  elif self.mode == self.VV5tIT  : VVpW60, self.VVZHg3 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVH82H : VVpW60, self.VVZHg3 = False, VVZHg3
  else           : VVpW60, self.VVZHg3 = True , VVZHg3
  self.VVZHg3 = FF1ZUc(self.VVZHg3)
  self["myMenu"] = CCTb7L(  directory   = "/"
         , VVpW60   = VVpW60
         , VVglKa = True
         , VVtFqb   = self.skinParam["width"]
         , VVjgTX   = self.skinParam["bodyFontSize"]
         , VVOJXs  = self.skinParam["bodyLineH"]
         , VVyjEK  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVhKHG      ,
   "red"    : self.VVlQsJ     ,
   "green"    : self.VVXZw0    ,
   "yellow"   : self.VVxyjY   ,
   "blue"    : self.VV9Blg   ,
   "menu"    : self.VV3TNF    ,
   "info"    : self.VVh5oQ    ,
   "cancel"   : self.VVrxAn     ,
   "pageUp"   : self.VVrxAn     ,
   "chanUp"   : self.VVrxAn
  }, -1)
  FFGWyw(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVd8fu)
 def onExit(self):
  CCWnyZ.VVXGnR = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVd8fu)
  FFzPkO(self)
  FFAblH(self["myMenu"], bg="#06003333")
  FFEgCR(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVH82H:
   FFw7jX(self["keyGreen"], self.VVmM5k)
   color = "#22000022"
   FFtJEw(self["myBody"], color)
   FFtJEw(self["myMenu"], color)
   color = "#22220000"
   FFtJEw(self["myTitle"], color)
   FFtJEw(self["myBar"], color)
  self.VVd8fu()
  if self.VVcQfk(self.VVZHg3) > self.bigDirSize:
   FF4n96(self, "Changing directory...")
   FFlxSW(self.VVfOqp)
  else:
   self.VVfOqp()
 def VVfOqp(self):
  self["myMenu"].VVgNF5(self.VVZHg3)
  if self.gotoMovie:
   self.VVJJF1(chDir=False)
 def VVINep(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV9RED(self):
  self["myMenu"].refresh()
  FFSY53()
 def VVcQfk(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVhKHG(self):
  if self["myMenu"].VVtXpd():
   path = self.VVq573(self.VVWZQi())
   if self.VVcQfk(path) > self.bigDirSize:
    FF4n96(self, "Changing directory...")
    FFlxSW(self.VVgxuk)
   else:
    self.VVgxuk()
  else:
   self.VVMuj8()
 def VVgxuk(self):
  self["myMenu"].descent()
  self.VVd8fu()
 def VVrxAn(self):
  if self["myMenu"].VVWDBe():
   self["myMenu"].moveToIndex(0)
   self.VVgxuk()
 def VVlQsJ(self):
  if not FFAkF7(self):
   self.close("")
 def VVXZw0(self):
  if self.mode == self.VVH82H:
   path = self.VVq573(self.VVWZQi())
   self.close(path)
 def VVh5oQ(self):
  FFKl3w(self, self.VVwHgR, title="Calculating size ...")
 def VVwHgR(self):
  path = self.VVq573(self.VVWZQi())
  param = self.VVQuKU(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFla3R("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCWnyZ.VVy9Fl(path)
     freeSize = CCWnyZ.VV5jiF(path)
     size = totSize - freeSize
     totSize  = CCWnyZ.VVDyPC(totSize)
     freeSize = CCWnyZ.VVDyPC(freeSize)
    else:
     size = FFla3R("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCWnyZ.VVDyPC(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFkGYB(pathTxt, VVtUnE) + "\n"
   if slBroken : fileTime = self.VVw3j5(path)
   else  : fileTime = self.VVL3Dr(path)
   def VVwkbi(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVwkbi("Path"    , pathTxt)
   txt += VVwkbi("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVwkbi("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVwkbi("Total Size"   , "%s" % totSize)
    txt += VVwkbi("Used Size"   , "%s" % usedSize)
    txt += VVwkbi("Free Size"   , "%s" % freeSize)
   else:
    txt += VVwkbi("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVwkbi("Owner"    , owner)
   txt += VVwkbi("Group"    , group)
   txt += VVwkbi("Perm. (User)"  , permUser)
   txt += VVwkbi("Perm. (Group)"  , permGroup)
   txt += VVwkbi("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVwkbi("Perm. (Ext.)" , permExtra)
   txt += VVwkbi("iNode"    , iNode)
   txt += VVwkbi("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVS5oR, VVS5oR)
    txt += hLinkedFiles
   txt += self.VVdXTF(path)
  else:
   FFc88f(self, "Cannot access information !")
  if len(txt) > 0:
   FFVxvP(self, txt)
 def VVQuKU(self, path):
  path = path.strip()
  path = FFh7YC(path)
  result = FFla3R("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV2dpJ(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV2dpJ(perm, 1, 4)
   permGroup = VV2dpJ(perm, 4, 7)
   permOther = VV2dpJ(perm, 7, 10)
   permExtra = VV2dpJ(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FF9r0n("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVdXTF(self, path):
  txt  = ""
  res  = FFla3R("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFkGYB("File Attributes:", VV0cUe), txt)
  return txt
 def VVL3Dr(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF7tZn(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF7tZn(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF7tZn(os.path.getctime(path))
  return txt
 def VVw3j5(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFla3R("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFla3R("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFla3R("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVq573(self, currentSel):
  currentDir  = self["myMenu"].VVWDBe()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVtXpd():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVWZQi(self):
  return self["myMenu"].getSelection()[0]
 def VVd8fu(self):
  FF4n96(self)
  path = self.VVq573(self.VVWZQi())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVNz0H = self.VVYTaU()
  if VVNz0H and len(VVNz0H) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVd2V7(path)
  if self.mode == self.VV5tIT and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVd2V7(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVsxJH(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VV3TNF(self):
  if self.mode == self.VV5tIT:
   path  = self.VVq573(self.VVWZQi())
   isDir  = os.path.isdir(path)
   VVw8eP = []
   VVw8eP.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVPhEQ(path):
     sepShown = True
     VVw8eP.append(VV9e5C)
     VVw8eP.append( (VVtUnE + "Archiving / Packaging"      , "VVQa6R"  ))
    if self.VVCokO(path):
     if not sepShown:
      VVw8eP.append(VV9e5C)
     VVw8eP.append( (VVtUnE + "Read Backup information"     , "VV0iwf"  ))
     VVw8eP.append( (VVtUnE + "Compress Octagon Image (to zip File)"  , "VVsZdW" ))
   elif os.path.isfile(path):
    selFile = self.VVWZQi()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVw8eP.extend(self.VVMLeu(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVw8eP.extend(self.VVy96G(True))
    elif selFile.endswith(".m3u")              : VVw8eP.extend(self.VVIBGR(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF6Jad(path):
     VVw8eP.append(VV9e5C)
     VVw8eP.append((VVtUnE + "View" , "text_View" ))
     VVw8eP.append((VVtUnE + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVw8eP.append(VV9e5C)
     VVw8eP.append(   (VVtUnE + txt      , "VVMuj8"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(     ("Create SymLink"       , "VV0IFi" ))
   if not self.VVPhEQ(path):
    VVw8eP.append(   ("Rename"          , "VV46us" ))
    VVw8eP.append(   ("Copy"           , "copyFileOrDir" ))
    VVw8eP.append(   ("Move"           , "moveFileOrDir" ))
    VVw8eP.append(   ("DELETE"          , "VVsWbQ" ))
    if fileExists(path):
     VVw8eP.append(VV9e5C)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVw8eP.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVw8eP.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVw8eP.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVw8eP.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCWnyZ.VVQPBU(self)
   if fPath:
    VVw8eP.append(VV9e5C)
    VVw8eP.append(   (VVYPWI + "Go to current movie"  , "VVJJF1"))
   VVw8eP.append(VV9e5C)
   VVw8eP.append(    ("Set current directory as \"Startup Path\"" , "VV7QGW" ))
   FF7Bt5(self, self.VVdp2F, title="Options", VVw8eP=VVw8eP)
 def VVdp2F(self, item=None):
  if self.mode == self.VV5tIT:
   if item is not None:
    path = self.VVq573(self.VVWZQi())
    selFile = self.VVWZQi()
    if   item == "properties"    : self.VVh5oQ()
    elif item == "VVQa6R"  : self.VVQa6R(path)
    elif item == "VV0iwf"  : self.VV0iwf(path)
    elif item == "VVsZdW" : self.VVsZdW(path)
    elif item.startswith("extract_")  : self.VVbVQf(path, selFile, item)
    elif item.startswith("script_")   : self.VV0XLm(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVZSWMItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFTDoH(self, path)
    elif item.startswith("text_Edit")  : CCFIrc(self, path)
    elif item == "chmod644"     : self.VVf7Lf(path, selFile, "644")
    elif item == "chmod755"     : self.VVf7Lf(path, selFile, "755")
    elif item == "chmod777"     : self.VVf7Lf(path, selFile, "777")
    elif item == "VV0IFi"   : self.VV0IFi(path, selFile)
    elif item == "VV46us"   : self.VV46us(path, selFile)
    elif item == "copyFileOrDir"   : self.VV97mp(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VV97mp(path, selFile, True)
    elif item == "VVsWbQ"   : self.VVsWbQ(path, selFile)
    elif item == "createNewFile"   : self.VVwAlH(path, True)
    elif item == "createNewDir"    : self.VVwAlH(path, False)
    elif item == "VVJJF1"   : self.VVJJF1()
    elif item == "VV7QGW"   : self.VV7QGW(path)
    elif item == "VVMuj8"    : self.VVMuj8()
    else         : self.close()
 def VVMuj8(self):
  selFile = self.VVWZQi()
  path  = self.VVq573(selFile)
  if os.path.isfile(path):
   VVA6hv = []
   category = self["myMenu"].VV843Y(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVfb4S(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFWcKR(self, selFile, path)
   elif category == "txt"         : FFTDoH(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVJSLX(path, selFile)
   elif category == "scr"         : self.VVL7A1(path, selFile)
   elif category == "m3u"         : self.VVJjKh(path, selFile)
   elif category in ("ipk", "deb")       : self.VVHGZX(path, selFile)
   elif category == "mus"         : self.VVVQ6y(self, path)
   elif category == "mov"         : self.VVVQ6y(self, path)
   elif not FF6Jad(path)        : FFTDoH(self, path)
 def VVxyjY(self):
  path = self.VVq573(self.VVWZQi())
  action = self.VVd2V7(path)
  if action == 1:
   self.VVxlSm(path)
   FF4n96(self, "Added", 500)
  elif action == -1:
   self.VVD0Rb(path)
   FF4n96(self, "Removed", 500)
  self.VVd2V7(path)
 def VVxlSm(self, path):
  VVNz0H = self.VVYTaU()
  if not VVNz0H:
   VVNz0H = []
  if len(VVNz0H) >= self.VVrRai:
   FFc88f(SELF, "Max bookmarks reached (max=%d)." % self.VVrRai)
  elif not path in VVNz0H:
   VVNz0H = [path] + VVNz0H
   self.VVwwpJ(VVNz0H)
 def VV9Blg(self):
  VVNz0H = self.VVYTaU()
  if VVNz0H:
   newList = []
   for line in VVNz0H:
    newList.append((line, line))
   VVjOJ6  = ("Delete"  , self.VVsuDH )
   VVjOnb = ("Move Up"   , self.VVlT9M )
   VVzZGK  = ("Move Down" , self.VVuMTv )
   self.bookmarkMenu = FF7Bt5(self, self.VVJd2R, title="Bookmarks", VVw8eP=newList, VVjOJ6=VVjOJ6, VVjOnb=VVjOnb, VVzZGK=VVzZGK)
 def VVsuDH(self, VVWZQiObj, path):
  if self.bookmarkMenu:
   VVNz0H = self.VVD0Rb(path)
   self.bookmarkMenu.VVCLj8(VVNz0H)
 def VVlT9M(self, VVWZQiObj, path):
  if self.bookmarkMenu:
   VVNz0H = self.bookmarkMenu.VVxUAr(True)
   if VVNz0H:
    self.VVwwpJ(VVNz0H)
 def VVuMTv(self, VVWZQiObj, path):
  if self.bookmarkMenu:
   VVNz0H = self.bookmarkMenu.VVxUAr(False)
   if VVNz0H:
    self.VVwwpJ(VVNz0H)
 def VVJd2R(self, folder=None):
  if folder:
   folder = FF1ZUc(folder)
   self["myMenu"].VVgNF5(folder)
   self["myMenu"].moveToIndex(0)
  self.VVd8fu()
 def VVYTaU(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVsxJH(self, path):
  VVNz0H = self.VVYTaU()
  if VVNz0H and path in VVNz0H:
   return True
  else:
   return False
 def VVyXsd(self):
  if VVYTaU():
   return True
  else:
   return False
 def VVwwpJ(self, VVNz0H):
  line = ",".join(VVNz0H)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVD0Rb(self, path):
  VVNz0H = self.VVYTaU()
  if VVNz0H:
   while path in VVNz0H:
    VVNz0H.remove(path)
   self.VVwwpJ(VVNz0H)
   return VVNz0H
 def VVJJF1(self, chDir=True):
  fPath, fDir, fName = CCWnyZ.VVQPBU(self)
  if fPath:
   if chDir:
    self["myMenu"].VVgNF5(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF4n96(self, "Not found", 1000)
 def VV7QGW(self, path):
  if not os.path.isdir(path):
   path = FFxq1R(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVfb4S(self, selFile, VVffrf, command):
  FFfK5z(self, boundFunction(FFypV6, self, command, VVpEG3=self.VV9RED), "%s\n\n%s" % (VVffrf, selFile))
 def VVMLeu(self, path, calledFromMenu):
  destPath = self.VV5aXZ(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVw8eP = []
  if calledFromMenu:
   VVw8eP.append(VV9e5C)
   color = VVtUnE
  else:
   color = ""
  VVw8eP.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVw8eP.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVw8eP.append((color + "Extract Here"            , "extract_here"  ))
  if VVWfYG and path.endswith(".tar.gz"):
   VVw8eP.append(VV9e5C)
   VVw8eP.append((color + 'Convert to ".ipk" Package' , "VVc2Xk"  ))
   VVw8eP.append((color + 'Convert to ".deb" Package' , "VV8Eoj"  ))
  return VVw8eP
 def VVJSLX(self, path, selFile):
  FF7Bt5(self, boundFunction(self.VVbVQf, path, selFile), title="Compressed File Options", VVw8eP=self.VVMLeu(path, False))
 def VVbVQf(self, path, selFile, item=None):
  if item is not None:
   parent  = FFxq1R(path, False)
   destPath = self.VV5aXZ(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVS5oR
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFQAHp("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFQAHp("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVS5oR, VVS5oR)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFZust(self, cmd)
   elif path.endswith(".zip"):
    self.VVbkGv(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVnw1R(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFK72g("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVfb4S(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVfb4S(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFxq1R(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVfb4S(selFile, "Extract Here ?"      , cmd)
   elif item == "VVc2Xk" : self.VVc2Xk(path)
   elif item == "VV8Eoj" : self.VV8Eoj(path)
 def VV5aXZ(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVbkGv(self, item, path, parent, destPath, VVffrf):
  FFfK5z(self, boundFunction(self.VV5jLQ, item, path, parent, destPath), VVffrf)
 def VV5jLQ(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVS5oR
  cmd  = FFQAHp("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF6sH0(destPath, VVfxXg))
  cmd +=   sep
  cmd += "fi;"
  FF34xz(self, cmd, VVpEG3=self.VV9RED)
 def VVnw1R(self, item, path, parent, destPath, VVffrf):
  FFfK5z(self, boundFunction(self.VV7FoQ, item, path, parent, destPath), VVffrf)
 def VV7FoQ(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF1ZUc(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVS5oR
  cmd  = FFQAHp("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF6sH0(destPath, VVfxXg))
  cmd +=   sep
  cmd += "fi;"
  FF34xz(self, cmd, VVpEG3=self.VV9RED)
 def VVy96G(self, addSep=False):
  VVw8eP = []
  if addSep:
   VVw8eP.append(VV9e5C)
  VVw8eP.append((VVtUnE + "View Script File"  , "script_View"  ))
  VVw8eP.append((VVtUnE + "Execute Script File" , "script_Execute" ))
  VVw8eP.append((VVtUnE + "Edit"     , "script_Edit" ))
  return VVw8eP
 def VVL7A1(self, path, selFile):
  FF7Bt5(self, boundFunction(self.VV0XLm, path, selFile), title="Script File Options", VVw8eP=self.VVy96G())
 def VV0XLm(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFTDoH(self, path)
   elif item == "script_Execute" : self.VVfb4S(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCFIrc(self, path)
 def VVIBGR(self, addSep=False):
  VVw8eP = []
  if addSep:
   VVw8eP.append(VV9e5C)
  VVw8eP.append((VVtUnE + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVw8eP.append((VVtUnE + "Edit"      , "m3u_Edit" ))
  VVw8eP.append((VVtUnE + "View"      , "m3u_View" ))
  return VVw8eP
 def VVJjKh(self, path, selFile):
  FF7Bt5(self, boundFunction(self.VVZSWMItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVw8eP=self.VVIBGR())
 def VVZSWMItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFKl3w(self, boundFunction(self.session.open, CCNqVt, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCFIrc(self, path)
   elif item == "m3u_View"  : FFTDoH(self, path)
 def VVf7Lf(self, path, selFile, newChmod):
  FFfK5z(self, boundFunction(self.VVllA5, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVllA5(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVuFH5)
  result = FFla3R(cmd)
  if result == "Successful" : FF1ATN(self, result)
  else      : FFc88f(self, result)
 def VV0IFi(self, path, selFile):
  parent = FFxq1R(path, False)
  self.session.openWithCallback(self.VVed1j, boundFunction(CCWnyZ, mode=CCWnyZ.VVH82H, VVZHg3=parent, VVmM5k="Create Symlink here"))
 def VVed1j(self, newPath):
  if len(newPath) > 0:
   target = self.VVq573(self.VVWZQi())
   target = FFh7YC(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF1ZUc(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFc88f(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFfK5z(self, boundFunction(self.VV1qR3, target, link), "Create Soft Link ?\n\n%s" % txt, VVPjh4=True)
 def VV1qR3(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVuFH5)
  result = FFla3R(cmd)
  if result == "Successful" : FF1ATN(self, result)
  else      : FFc88f(self, result)
 def VV46us(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFTT6y(self, boundFunction(self.VVSmG7, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVSmG7(self, path, selFile, VVIh6s):
  if VVIh6s:
   parent = FFxq1R(path, True)
   if os.path.isdir(path):
    path = FFh7YC(path)
   newName = parent + VVIh6s
   cmd = "mv '%s' '%s' %s" % (path, newName, VVuFH5)
   if VVIh6s:
    if selFile != VVIh6s:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFfK5z(self, boundFunction(self.VVspHw, cmd), message, title="Rename file?")
    else:
     FFc88f(self, "Cannot use same name!", title="Rename")
 def VVspHw(self, cmd):
  result = FFla3R(cmd)
  if "Fail" in result:
   FFc88f(self, result)
  self.VV9RED()
 def VV97mp(self, path, selFile, isMove):
  if isMove : VVmM5k = "Move to here"
  else  : VVmM5k = "Copy to here"
  parent = FFxq1R(path, False)
  self.session.openWithCallback(boundFunction(self.VV2WTP, isMove, path, selFile)
         , boundFunction(CCWnyZ, mode=CCWnyZ.VVH82H, VVZHg3=parent, VVmM5k=VVmM5k))
 def VV2WTP(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFh7YC(path)
   newPath = FF1ZUc(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFfK5z(self, boundFunction(FFelLa, self, cmd, VVpEG3=self.VV9RED), txt, VVPjh4=True)
   else:
    FFc88f(self, "Cannot %s to same directory !" % action.lower())
 def VVsWbQ(self, path, fileName):
  path = FFh7YC(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFfK5z(self, boundFunction(self.VVmkNl, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVmkNl(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VV9RED()
 def VVPhEQ(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VV5ZBQ and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVwAlH(self, path, isFile):
  dirName = FF1ZUc(os.path.dirname(path))
  if isFile : objName, VVIh6s = "File"  , self.edited_newFile
  else  : objName, VVIh6s = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFTT6y(self, boundFunction(self.VV6rZx, dirName, isFile, title), title=title, defaultText=VVIh6s, message="Enter %s Name:" % objName)
 def VV6rZx(self, dirName, isFile, title, VVIh6s):
  if VVIh6s:
   if isFile : self.edited_newFile = VVIh6s
   else  : self.edited_newDir  = VVIh6s
   path = dirName + VVIh6s
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVuFH5)
    else  : cmd = "mkdir '%s' %s" % (path, VVuFH5)
    result = FFla3R(cmd)
    if "Fail" in result:
     FFc88f(self, result)
    self.VV9RED()
   else:
    FFc88f(self, "Name already exists !\n\n%s" % path, title)
 def VVHGZX(self, path, selFile):
  VVw8eP = []
  VVw8eP.append(("List Package Files"          , "VVE2bO"     ))
  VVw8eP.append(("Package Information"          , "VVqVTO"     ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Install Package"           , "VVzxSG_CheckVersion" ))
  VVw8eP.append(("Install Package (force reinstall)"      , "VVzxSG_ForceReinstall" ))
  VVw8eP.append(("Install Package (force overwrite)"      , "VVzxSG_ForceOverwrite" ))
  VVw8eP.append(("Install Package (force downgrade)"      , "VVzxSG_ForceDowngrade" ))
  VVw8eP.append(("Install Package (ignore failed dependencies)"    , "VVzxSG_IgnoreDepends" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Remove Related Package"         , "VVnl2q_ExistingPackage" ))
  VVw8eP.append(("Remove Related Package (force remove)"     , "VVnl2q_ForceRemove"  ))
  VVw8eP.append(("Remove Related Package (ignore failed dependencies)"  , "VVnl2q_IgnoreDepends" ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("Extract Files"           , "VVoR54"     ))
  VVw8eP.append(("Unbuild Package"           , "VVw030"     ))
  FF7Bt5(self, boundFunction(self.VVrJIz, path, selFile), VVw8eP=VVw8eP)
 def VVrJIz(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVE2bO"      : self.VVE2bO(path, selFile)
   elif item == "VVqVTO"      : self.VVqVTO(path)
   elif item == "VVzxSG_CheckVersion"  : self.VVzxSG(path, selFile, VVggHo     )
   elif item == "VVzxSG_ForceReinstall" : self.VVzxSG(path, selFile, VV0Gj2 )
   elif item == "VVzxSG_ForceOverwrite" : self.VVzxSG(path, selFile, VVSKZV )
   elif item == "VVzxSG_ForceDowngrade" : self.VVzxSG(path, selFile, VVyV6h )
   elif item == "VVzxSG_IgnoreDepends" : self.VVzxSG(path, selFile, VVmetP )
   elif item == "VVnl2q_ExistingPackage" : self.VVnl2q(path, selFile, VVr4M9     )
   elif item == "VVnl2q_ForceRemove"  : self.VVnl2q(path, selFile, VV8CGQ  )
   elif item == "VVnl2q_IgnoreDepends"  : self.VVnl2q(path, selFile, VV4urB )
   elif item == "VVoR54"     : self.VVoR54(path, selFile)
   elif item == "VVw030"     : self.VVw030(path, selFile)
   else           : self.close()
 def VVE2bO(self, path, selFile):
  if FFGzR8("ar") : cmd = "allOK='1';"
  else    : cmd  = FFsXZx()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVS5oR, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVS5oR, VVS5oR)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFoSpn(self, cmd, VVpEG3=self.VV9RED)
 def VVoR54(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFxq1R(path, True) + selFile[:-4]
  cmd  =  FFsXZx()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFK72g("mkdir '%s'" % dest) + ";"
  cmd +=    FFK72g("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF6sH0(dest, VVfxXg))
  cmd += "fi;"
  FFypV6(self, cmd, VVpEG3=self.VV9RED)
 def VVw030(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVqRpK = os.path.splitext(path)[0]
  else        : VVqRpK = path + "_"
  if path.endswith(".deb")   : VV7xUH = "DEBIAN"
  else        : VV7xUH = "CONTROL"
  cmd  = FFsXZx()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVqRpK, FFahWw())
  cmd += "  mkdir '%s';"    % VVqRpK
  cmd += "  CONTPATH='%s/%s';"  % (VVqRpK, VV7xUH)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVqRpK
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVqRpK, VVqRpK)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVqRpK
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVqRpK, VVqRpK)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVqRpK
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVqRpK
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVqRpK, FF6sH0(VVqRpK, VVfxXg))
  cmd += "fi;"
  FFypV6(self, cmd, VVpEG3=self.VV9RED)
 def VVqVTO(self, path):
  listCmd  = FFZsGt(VVryhT, "")
  infoCmd  = FFp0JH(VVV9W2 , "")
  filesCmd = FFp0JH(VVHJAK, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFEtzo(VVYPWI)
   notInst = "Package not installed."
   cmd  = FFdbLX("File Info", VVYPWI)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFdbLX("System Info", VVYPWI)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF6sH0(notInst, VVtUnE))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFdbLX("Related Files", VVYPWI)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFZust(self, cmd)
  else:
   FFdCT7(self)
 def VVzxSG(self, path, selFile, cmdOpt):
  cmd = FFp0JH(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFfK5z(self, boundFunction(FFypV6, self, cmd, VVpEG3=FFSY53), "Install Package ?\n\n%s" % selFile)
  else:
   FFdCT7(self)
 def VVnl2q(self, path, selFile, cmdOpt):
  listCmd  = FFZsGt(VVryhT, "")
  infoCmd  = FFp0JH(VVV9W2, "")
  instRemCmd = FFp0JH(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF6sH0(errTxt, VVtUnE))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF6sH0(cannotTxt, VVtUnE))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF6sH0(tryTxt, VVtUnE))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFfK5z(self, boundFunction(FFypV6, self, cmd, VVpEG3=FFSY53), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFdCT7(self)
 def VVOvAR(self, path):
  hostName = FFla3R("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVCokO(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVOvAR(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVQa6R(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVw8eP = []
  VVw8eP.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVw8eP.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVw8eP.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVw8eP.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVw8eP.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVw8eP.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVw8eP.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVw8eP.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVw8eP.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVw8eP.append(VV9e5C)
  VVw8eP.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVw8eP.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF7Bt5(self, boundFunction(self.VVqv0u, path), VVw8eP=VVw8eP)
 def VVqv0u(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVO1Mg(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVO1Mg(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVO1Mg(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVO1Mg(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVO1Mg(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVO1Mg(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVO1Mg(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVO1Mg(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVO1Mg(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVO1Mg(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVIItD(path, False)
   elif item == "convertDirToDeb"   : self.VVIItD(path, True)
   else         : self.close()
 def VVIItD(self, path, VViYVL):
  self.session.openWithCallback(self.VV9RED, boundFunction(CCMmad, path=path, VViYVL=VViYVL))
 def VVO1Mg(self, path, fileExt, preserveDirStruct):
  parent  = FFxq1R(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFQAHp("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFQAHp("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFQAHp("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVS5oR
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFK72g("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF6sH0(resultFile, VVfxXg))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF6sH0(failed, VVFT40))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFoSpn(self, cmd, VVpEG3=self.VV9RED)
 def VV0iwf(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFTDoH(self, versionFile)
 def VVsZdW(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVOvAR(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFc88f(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFg2eB(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFxq1R(path, False)
  VVqRpK = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF6sH0(errCmd, VVFT40))
  installCmd = FFp0JH(VVggHo , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVqRpK, VVqRpK)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVqRpK
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVqRpK
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVqRpK, VVqRpK)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFypV6(self, cmd, VVpEG3=self.VV9RED)
 def VVc2Xk(self, path):
  FFc88f(self, "Under Construction.")
 def VV8Eoj(self, path):
  FFc88f(self, "Under Construction.")
 @staticmethod
 def VVVQ6y(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CC9DjN, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVQPBU(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF1ZUc(fDir), fName
  return "", "", ""
 @staticmethod
 def VVy9Fl(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV5jiF(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVDyPC(size, mode=0):
  txt = CCWnyZ.VVmoHi(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVmoHi(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCTb7L(MenuList):
 def __init__(self, VVglKa=False, directory="/", VVZj3A=True, VVpW60=True, VVxOKg=True, VVMTkF=None, VV9Zsc=False, VV3Nc0=False, VVOTyh=False, isTop=False, VV43Tb=None, VVtFqb=1000, VVjgTX=30, VVOJXs=30, VVyjEK="#00000000"):
  MenuList.__init__(self, list, VVglKa, eListboxPythonMultiContent)
  self.VVZj3A  = VVZj3A
  self.VVpW60    = VVpW60
  self.VVxOKg  = VVxOKg
  self.VVMTkF  = VVMTkF
  self.VV9Zsc   = VV9Zsc
  self.VV3Nc0   = VV3Nc0 or []
  self.VVOTyh   = VVOTyh or []
  self.isTop     = isTop
  self.additional_extensions = VV43Tb
  self.VVtFqb    = VVtFqb
  self.VVjgTX    = VVjgTX
  self.VVOJXs    = VVOJXs
  self.pngBGColor    = FFKiR0(VVyjEK)
  self.EXTENSIONS    = self.VVXJ7g()
  self.VVNfWS   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VV55z0, self.VVjgTX))
  self.l.setItemHeight(self.VVOJXs)
  self.png_mem   = self.VVeadK("mem")
  self.png_usb   = self.VVeadK("usb")
  self.png_fil   = self.VVeadK("fil")
  self.png_dir   = self.VVeadK("dir")
  self.png_dirup   = self.VVeadK("dirup")
  self.png_srv   = self.VVeadK("srv")
  self.png_slwfil   = self.VVeadK("slwfil")
  self.png_slbfil   = self.VVeadK("slbfil")
  self.png_slwdir   = self.VVeadK("slwdir")
  self.VV4ZoK()
  self.VVgNF5(directory)
 def VVeadK(self, category):
  return LoadPixmap("%s%s.png" % (VVAwa9, category), getDesktop(0))
 def VVXJ7g(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VViqKz(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFh7YC(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFkGYB(" -> " , VVYPWI) + FFkGYB(os.readlink(path), VVfxXg)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVOJXs + 10, 0, self.VVtFqb, self.VVOJXs, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVsviS: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVOJXs-4, self.VVOJXs-4, png, self.pngBGColor, self.pngBGColor, VVsviS))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVOJXs-4, self.VVOJXs-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VV843Y(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VV4ZoK(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVkSHM(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVal98(self, file):
  if os.path.realpath(file) == file:
   return self.VVkSHM(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVkSHM(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVkSHM(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVvOxF(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVNfWS.info(l[0][0]).getEvent(l[0][0])
 def VVnCzC(self):
  return self.list
 def VVQFvW(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVgNF5(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVxOKg:
    self.current_mountpoint = self.VVal98(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVxOKg:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVOTyh and not self.VVQFvW(path, self.VV3Nc0):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VViqKz(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV9Zsc:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVNfWS = eServiceCenter.getInstance()
   list = VVNfWS.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVZj3A and not self.isTop:
   if directory == self.current_mountpoint and self.VVxOKg:
    self.list.append(self.VViqKz(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVOTyh and self.VVkSHM(directory) in self.VVOTyh):
    self.list.append(self.VViqKz(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVZj3A:
   for x in directories:
    if not (self.VVOTyh and self.VVkSHM(x) in self.VVOTyh) and not self.VVQFvW(x, self.VV3Nc0):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VViqKz(name = name, absolute = x, isDir = True, png = png))
  if self.VVpW60:
   for x in files:
    if self.VV9Zsc:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFkGYB(" -> " , VVYPWI) + FFkGYB(target, VVfxXg)
       else:
        png = self.png_slbfil
        name += FFkGYB(" -> " , VVYPWI) + FFkGYB(target, VVFT40)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VV843Y(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVAwa9, category))
    if (self.VVMTkF is None) or iCompile(self.VVMTkF).search(path):
     self.list.append(self.VViqKz(name = name, absolute = x , isDir = False, png = png))
  if self.VVxOKg and len(self.list) == 0:
   self.list.append(self.VViqKz(name = FFkGYB("No USB connected", VVLchc), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVWDBe(self):
  return self.current_directory
 def VVtXpd(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVgNF5(self.getSelection()[0], select = self.current_directory)
 def VVnwiP(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVf3C9(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVQqLM)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVQqLM)
 def refresh(self):
  self.VVgNF5(self.current_directory, self.VVnwiP())
 def VVQqLM(self, action, device):
  self.VV4ZoK()
  if self.current_directory is None:
   self.refresh()
class CC9lYb(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFAEOm(VVom0v, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVNz0H   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVGqIP(defFG, "#00FFFFFF")
  self.defBG   = self.VVGqIP(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFSF9U(self, self.Title)
  self["keyRed"].show()
  FFw7jX(self["keyGreen"] , "< > Transp.")
  FFw7jX(self["keyYellow"], "Foreground")
  FFw7jX(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVKIdw        ,
   "yellow"   : boundFunction(self.VVdGcn, False)  ,
   "blue"   : boundFunction(self.VVdGcn, True)  ,
   "up"   : self.VVdENK          ,
   "down"   : self.VV6OgH         ,
   "left"   : self.VVmZkC         ,
   "right"   : self.VVTOrf         ,
   "last"   : boundFunction(self.VVzzug, -5) ,
   "next"   : boundFunction(self.VVzzug, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVscXX)
 def VVscXX(self):
  self.onShown.remove(self.VVscXX)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFtJEw(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFtJEw(self["keyRed"] , c)
  FFtJEw(self["keyGreen"] , c)
  self.VVlde2()
  self.VVWd8U()
  FFLdCa(self["myColorTst"], self.defFG)
  FFtJEw(self["myColorTst"], self.defBG)
 def VVGqIP(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVWd8U(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVbujz(0, 0)
     return
 def VVKIdw(self):
  self.close(self.defFG, self.defBG)
 def VVdENK(self): self.VVbujz(-1, 0)
 def VV6OgH(self): self.VVbujz(1, 0)
 def VVmZkC(self): self.VVbujz(0, -1)
 def VVTOrf(self): self.VVbujz(0, 1)
 def VVbujz(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVdvzN()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVZrdT()
 def VVlde2(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVZrdT(self):
  color = self.VVdvzN()
  if self.isBgMode: FFtJEw(self["myColorTst"], color)
  else   : FFLdCa(self["myColorTst"], color)
 def VVdGcn(self, isBg):
  self.isBgMode = isBg
  self.VVlde2()
  self.VVWd8U()
 def VVzzug(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVbujz(0, 0)
 def VVpHBZ(self):
  return hex(self.transp)[2:].zfill(2)
 def VVdvzN(self):
  return ("#%s%s" % (self.VVpHBZ(), self.colors[self.curRow][self.curCol])).upper()
class CCxBZn(ScrollLabel):
 def __init__(self, parentSELF, text="", VVKNdD=True):
  ScrollLabel.__init__(self, text)
  self.VVKNdD=VVKNdD
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVBPYM  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVjgTX    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVAT3x   ,
   "green"   : self.VVOdia  ,
   "yellow"  : self.VVrxjd  ,
   "blue"   : self.VVACUy  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVP9mq    ,
   "chanUp"  : self.VVP9mq    ,
   "pageDown"  : self.VVJbbc    ,
   "chanDown"  : self.VVJbbc
  }, -1)
 def VVe9VI(self, isResizable=True, VVIekL=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFEgCR(self.parentSELF, True)
  self.isResizable = isResizable
  if VVIekL:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVjgTX  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFtJEw(self, color)
 def FFtJEwColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVBPYM - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVoooo()
 def pageUp(self):
  if self.VVBPYM > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVBPYM > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVP9mq(self):
  self.setPos(0)
 def VVJbbc(self):
  self.setPos(self.VVBPYM-self.pageHeight)
 def VVZnyw(self):
  return self.VVBPYM <= self.pageHeight or self.curPos == self.VVBPYM - self.pageHeight
 def VVoooo(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVBPYM, 3))
   start = int((100 - vis) * self.curPos / (self.VVBPYM - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVMBud=VVsWwL):
  old_VVZnyw = self.VVZnyw()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVBPYM = self.long_text.calculateSize().height()
   if self.VVKNdD and self.VVBPYM > self.pageHeight:
    self.scrollbar.show()
    self.VVoooo()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVBPYM))
   if   VVMBud == VVOJfg: self.setPos(0)
   elif VVMBud == VVpkLV : self.VVJbbc()
   elif old_VVZnyw    : self.VVJbbc()
 def appendText(self, text, VVMBud=VVpkLV):
  self.setText(self.message + str(text), VVMBud)
 def VVrxjd(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVuZBy(size)
 def VVACUy(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVuZBy(size)
 def VVOdia(self):
  self.VVuZBy(self.VVjgTX)
 def VVuZBy(self, VVjgTX):
  self.long_text.setFont(gFont(self.fontFamily, VVjgTX))
  self.setText(self.message, VVMBud=VVsWwL)
  self.VVKCBq(calledFromFontSizer=True)
 def VVAT3x(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FF1ZUc(expPath), self.textOutFile, FFnEIN())
    with open(outF, "w") as f:
     f.write(FFtG6X(self.message))
    FF1ATN(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFc88f(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVKCBq(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVBPYM > 0 and self.pageHeight > 0:
   if self.VVBPYM < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVBPYM
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
