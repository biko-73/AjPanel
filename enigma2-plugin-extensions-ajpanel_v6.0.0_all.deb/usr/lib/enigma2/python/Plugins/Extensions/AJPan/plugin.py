import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from difflib     import get_close_matches as iClosest
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVJHEy   = "v6.0.0"
VVZztu    = "01-08-2022"
EASY_MODE    = 0
VVoTP7   = 0
VVl5oG   = 0
VVubKs  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVkWLd  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVcqbj    = "/media/usb/"
VVu0OF    = "/usr/share/enigma2/picon/"
VVC6WH = "/etc/enigma2/blacklist"
VVSwef   = "/etc/enigma2/"
VVzPWd  = "ajpanel_update_url"
VV2PHh   = "AJPan"
VV2lDQ  = "AUTO FIND"
VVWUoy  = "Custom"
VVZr72    = ""
VV8NsC    = "Regular"
VVJ1qT      = "-" * 80
VVEgY4    = ("-" * 100, )
VVqmOn    = ""
VV4Q9M   = " && echo 'Successful' || echo 'Failed!'"
VVhoY8    = []
VVq1UG  = "Cannot continue (No Enough Memory) !"
VVYACA  = False
VVv9Mc  = False
VVGp08 = False
VVHFCN     = 0
VV0IRp    = 1
VVcj6X    = 2
VVF06t   = 3
VVuVSN    = 4
VVaWzv    = 5
VVM7on = 6
VVqL9P = 7
VVQEAr  = 8
VVU9A6   = 9
VVFwlX  = 10
VVQjBQ  = 11
VV44nA    = 12
VVoG3n   = 13
VVmXPN   = 14
VVM6Ow    = 15
VVSV74    = 16
VVWvky  = 17
VVebGP   = 0
VVxPlb   = 1
VVs2cN   = 2
def FFI1Fg():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VV8NsC]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default") ])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[ ("d", "Directory Up"), ("e", "Exit File Manage") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VV2lDQ, visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVu0OF, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVcqbj, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindTpStat    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-300, max=300, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VV8NsC, choices=[ (x,  x) for x in FFI1Fg() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-300, max=40, wraparound=False)
del tmp
def FFQsK0():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVGY7W  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVBDdZ = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVGY7W  : return 0
  elif VVBDdZ : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVFYPg = FFQsK0()
VVAc0p = VVpi4Z = VVG74s = VVFkfi = VVpqRv = VVvinO = VVEwOk = VV41YE = VVxbdF = VVFeau = VVMXOB = VV4mPL = VV31Rm = VVXldd = ""
def FFem1q()  : FFxO0H(FFpThb())
def FFALNO()  : FFxO0H(FFls9u())
def FFCDXm(tDict): FFxO0H(iDumps(tDict, indent=4, sort_keys=True))
def FFcsXT(*args): FF5r09(True, False, *args)
def FFxO0H(*args) : FF5r09(True , True , *args)
def FFBKVF(*args): FF5r09(False, True , *args)
def FF5r09(addSep=True, oneLine=True, *args):
 if VVoTP7:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FF2pWJ(txt, isAppend=True, ignoreErr=False):
 if VVoTP7:
  tm = FFj3cu()
  err = ""
  if not ignoreErr:
   err = FFls9u()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFxO0H(err)
  FFxO0H("Output Log File : %s" % fileName)
def FFls9u():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFj3cu()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFpThb():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVhoY8 = []
def FFr6hs(win):
 global VVhoY8
 if not win in VVhoY8:
  VVhoY8.append(win)
def FFDRAB(*args):
 global VVhoY8
 for win in VVhoY8:
  try:
   win.close()
  except:
   pass
 VVhoY8 = []
def FFcCl9():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV2US3 = FFcCl9()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF2FMR()     : return PluginDescriptor(fnc=FFpjpn, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFcGfn()      : return getDescriptor(FFjX1v   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFLsCo()       : return getDescriptor(FFbhz1  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFkLCB()   : return getDescriptor(FFMjDU , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFMMhQ(): return getDescriptor(FFu5rx , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFaly6()  : return getDescriptor(FFrZTx  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFPMci()     : return getDescriptor(FF8nWf , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFcGfn() , FFLsCo() , FF2FMR() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFkLCB())
  result.append(FFMMhQ())
  result.append(FFaly6())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFPMci())
 return result
def FFpjpn(reason, **kwargs):
 if reason == 0:
  FFtxHC()
  if "session" in kwargs:
   session = kwargs["session"]
   FFw326(session)
   CCleqq(session)
  CCF2zZ.VVDloz()
def FFbhz1(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFjX1v, PLUGIN_NAME, 45)]
 else:
  return []
def FFjX1v(session, **kwargs):
 session.open(Main_Menu)
def FFMjDU(session, **kwargs):
 session.open(CC0Jp1)
def FFu5rx(session, **kwargs):
 FFSj4o(session, isFromSession=True)
def FFrZTx(session, **kwargs):
 session.open(CC5Be5)
def FF8nWf(session, **kwargs):
 session.open(CCGnOY, fncMode=CCGnOY.VVvPe7)
def FFFyU6():
 FFvxSJ(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFkLCB(), FFMMhQ(), FFaly6() ])
 FFvxSJ(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFPMci() ])
def FFvxSJ(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV8k1p = None
def FFtxHC():
 try:
  global VV8k1p
  if VV8k1p is None:
   VV8k1p    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFHRWq
  ChannelContextMenu.FF6lLf = FF6lLf
 except:
  pass
def FFHRWq(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV8k1p(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FF6lLf, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FF6lLf, title1, csel, isFind=True))))
def FF6lLf(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFBfr9(refCode)
 except:
  pass
 self.session.open(BF(CCgWhv, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFw326(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = BF(FFuADm, session, "lok")
 hk.actions['longCancel'] = BF(FFuADm, session, "lesc")
 hk.actions['longRed']  = BF(FFuADm, session, "lred")
def FFuADm(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   session.open(CCZilb, isFromExternal=True)
  except:
   pass
def FF2wUT(SELF, title="", addLabel=False, addScrollLabel=False, VVWp2B=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFPcSK()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCvFYC(SELF)
 if VVWp2B:
  SELF["myMenu"] = MenuList(VVWp2B)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVxkj1        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFsG3C(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFz4UZ, SELF, "0") ,
  "1" : BF(FFz4UZ, SELF, "1") ,
  "2" : BF(FFz4UZ, SELF, "2") ,
  "3" : BF(FFz4UZ, SELF, "3") ,
  "4" : BF(FFz4UZ, SELF, "4") ,
  "5" : BF(FFz4UZ, SELF, "5") ,
  "6" : BF(FFz4UZ, SELF, "6") ,
  "7" : BF(FFz4UZ, SELF, "7") ,
  "8" : BF(FFz4UZ, SELF, "8") ,
  "9" : BF(FFz4UZ, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFmOPm, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFz4UZ(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVXldd:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVXldd + SELF.keyPressed + VVpi4Z)
    txt = VVpi4Z + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFMnBb(SELF, txt)
def FFmOPm(SELF, tableObj, colNum):
 FFMnBb(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVtsKn(i)
     break
 except:
  pass
def FFxhQe(SELF, setMenuAction=True):
 if setMenuAction:
  global VVqmOn
  VVqmOn = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFPcSK():
 return ("  %s" % VVqmOn)
def FF4HaE(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFYfxZ(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFcFXO(color):
 return parseColor(color).argb()
def FFryZu(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFQZ4f(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFdhoC(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFoqGv(win, top):
 win.instance.move(ePoint(int(win.instance.position().x()), int(top)))
def FF7gKg(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVXldd)
 else:
  return ""
def FFy2ZV(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVJ1qT, word, VVJ1qT, VVXldd)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVJ1qT, word, VVJ1qT)
def FFtSnl(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVXldd
def FFygy9(color):
 if color: return "echo -e '%s' %s;" % (VVJ1qT, FF7gKg(VVJ1qT, VVxbdF))
 else : return "echo -e '%s';" % VVJ1qT
def FFpGai(title, color):
 title = "%s\n%s\n%s\n" % (VVJ1qT, title, VVJ1qT)
 return FFtSnl(title, color)
def FFysS0(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFdpaS(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFrvtJ(callBackFunction):
 tCons = CCtypF()
 tCons.ePopen("echo", BF(FFwYa6, callBackFunction))
def FFwYa6(callBackFunction, result, retval):
 callBackFunction()
def FFOvQF(SELF, fnc, title="Processing ...", clearMsg=True):
 FFMnBb(SELF, title)
 tCons = CCtypF()
 tCons.ePopen("echo", BF(FFEDLH, SELF, fnc, clearMsg))
def FFEDLH(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFMnBb(SELF)
def FFWdfY(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVq1UG
  else       : return ""
def FF42E1(cmd):
 txt = FFWdfY(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFrbAO(cmd):
 lines = FF42E1(cmd)
 if lines: return lines[0]
 else : return ""
def FFVMzp(SELF, cmd):
 lines = FF42E1(cmd)
 VVMGU8 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVMGU8.append((key, val))
  elif line:
   VVMGU8.append((line, ""))
 if VVMGU8:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFGcVX(SELF, None, header=header, VVJXpL=VVMGU8, VVQGhe=widths, VVlOla=28)
 else:
  FFxeLA(SELF, cmd)
def FFxeLA(    SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, VV7p8T=True, VVwvtK=VVxPlb, **kwargs)
def FF4Tqj(  SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, **kwargs)
def FFIhbm(   SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, VVsIM5=True, VVHaYT=True, VVwvtK=VVxPlb, **kwargs)
def FFEMu6(  SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, VVsIM5=True, VVHaYT=True, VVwvtK=VVs2cN, **kwargs)
def FF355v(  SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, VVPLML=True , **kwargs)
def FFn5PT( SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, VVP3ns=True   , **kwargs)
def FF3db0( SELF, cmd, **kwargs): SELF.session.open(CC8r1x, VVmobY=cmd, VV8eLm=True  , **kwargs)
def FFBSzC(cmd):
 return cmd + " > /dev/null 2>&1"
def FFCsCC(cmd):
 return cmd + " 2> /dev/null"
def FFZ6H5():
 return " > /dev/null 2>&1"
def FFCi72(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFizMC(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFc0wg():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFrbAO(cmd)
VV00Qq     = 0
VVIqCh      = 1
VVX80U   = 2
VVIObq      = 3
VV9BI1      = 4
VVlZ5b     = 5
VVRzYh     = 6
VVXPbD = 7
VV6une = 8
VVoxQ2 = 9
VVJxK8  = 10
VVThwT     = 11
VV7m8G  = 12
VVfrPk  = 13
def FFU3rV(parmNum, grepTxt):
 if   parmNum == VV00Qq  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVIqCh   : param = ["list"   , "apt list" ]
 elif parmNum == VVX80U: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFc0wg()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFWksx(parmNum, package):
 if   parmNum == VVIObq      : param = ["info"      , "apt show"         ]
 elif parmNum == VV9BI1      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVlZ5b     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVRzYh     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVXPbD : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV6une : param = ["install --force-overwrite" , "dpkg -i --force-overwrite"     ]
 elif parmNum == VVoxQ2 : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVJxK8  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVThwT     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VV7m8G  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVfrPk  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFc0wg()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFrwtR():
 result = FFrbAO("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFWksx(VVRzYh , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFBSzC("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFBSzC("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF7gKg(failed1, VVxbdF))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF7gKg(failed2, VVxbdF))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF7gKg(failed3, VVG74s))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFkr8y(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFWksx(VVRzYh , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFBSzC("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF7gKg(failed1, VVxbdF))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF7gKg(failed2, VVG74s))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFqH9S(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFBSzC('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFBSzC("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFS3H9(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCF2zZ.VVTDKm()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFsCGi(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFS3H9(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFjMtD(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFHaPS(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFS3H9(path, maxSize=maxSize, encLst=encLst)
  if lines: FFzNhe(SELF, lines, title=title, VVwvtK=VVxPlb)
  else : FF5DrN(SELF, path, title=title)
 else:
  FFdzz0(SELF, path, title)
def FFXRcG(SELF, path, title):
 if fileExists(path):
  txt = FFS3H9(path)
  txt = txt.replace("#W#", VVXldd)
  txt = txt.replace("#Y#", VVFeau)
  txt = txt.replace("#G#", VVpi4Z)
  txt = txt.replace("#C#", VVMXOB)
  txt = txt.replace("#P#", VVpqRv)
  FFzNhe(SELF, txt, title=title)
 else:
  FFdzz0(SELF, path, title)
def FFvbuz(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFO4sU(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFjGgP(parent)
 else    : return FFRs7V(parent)
def FFRwag(path):
 return os.path.basename(os.path.normpath(path))
def FFHaPS(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFu9NF(path):
 try:
  os.remove(path)
 except:
  pass
def FFjGgP(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFRs7V(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFUtyn():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVubKs)
 paths.append(VVubKs.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFvbuz(ba)
 for p in list:
  p = ba + p + VVubKs
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV2PHh, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVubKs, VV2PHh , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVH5lR, VVE4he = FFUtyn()
def FFnpBj():
 def VVjUAO(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VV6rpB   = VVjUAO(CFG.backupPath, CCVDyw.VVhN1R())
 VVq6q0   = VVjUAO(CFG.downloadedPackagesPath, t)
 VVdtOF  = VVjUAO(CFG.exportedTablesPath, t)
 VVFYRE  = VVjUAO(CFG.exportedPIconsPath, t)
 VV5z34   = VVjUAO(CFG.packageOutputPath, t)
 global VVcqbj
 VVcqbj = FFjGgP(CFG.backupPath.getValue())
 if VV6rpB or VV5z34 or VVq6q0 or VVdtOF or VVFYRE or oldMovieDownloadPath:
  configfile.save()
 return VV6rpB, VV5z34, VVq6q0, VVdtOF, VVFYRE, oldMovieDownloadPath
def FFaFe3(path):
 path = FFRs7V(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFrWpy(SELF, pathList, tarFileName, addTimeStamp=True):
 VVJXpL = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVJXpL.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVJXpL.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVJXpL.append(path)
 if not VVJXpL:
  FFNkji(SELF, "Files not found!")
 elif not pathExists(VVcqbj):
  FFNkji(SELF, "Path not found!\n\n%s" % VVcqbj)
 else:
  VVUQnF = FFjGgP(VVcqbj)
  tarFileName = "%s%s" % (VVUQnF, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF03bo())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVJXpL:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVJ1qT
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF7gKg(tarFileName, VV41YE))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF7gKg(failed, VV41YE))
  cmd += "fi;"
  cmd +=  sep
  FF4Tqj(SELF, cmd)
def FFGCUP(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFUKsz(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFUKsz(SELF["keyInfo"], "info")
def FFUKsz(barObj, fName):
 path = "%s%s%s" % (VVE4he, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF3aJg(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFc8os(satNum)
  return satName
def FFc8os(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFzd48(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF3aJg(val)
  else  : sat = FFc8os(val)
 return sat
def FFwTSp(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF3aJg(num)
 except:
  pass
 return sat
def FFhx4J(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFxnns(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFFiXK(info, iServiceInformation.sServiceref)
   prov = FFFiXK(info, iServiceInformation.sProvider)
   state = str(FFFiXK(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFmwez(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FF2PL9(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFFiXK(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFwmMJ(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFBfr9(refCode):
 info = FFj7PA(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFEzDT(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFE6fQ(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFj7PA(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVCR76 = eServiceCenter.getInstance()
  if VVCR76:
   info = VVCR76.info(service)
 return info
def FFQ5yd(SELF, refCode, VVz7YZ=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFL1Gi(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVz7YZ:
   FFSj4o(SELF, isFromSession)
 try:
  VVe94g = InfoBar.instance
  if VVe94g:
   VVNETX = VVe94g.servicelist
   if VVNETX:
    servRef = eServiceReference(refCode)
    VVNETX.saveChannel(servRef)
 except:
  pass
def FFL1Gi(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCl3K2()
    if pr.VVfDCP(refCode, chName, decodedUrl, iptvRef):
     pr.VVjSec(SELF, isFromSession)
def FFmwez(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFh3oH(url): return FFQlgA(url) or FFutXo(url)
def FFQlgA(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFutXo(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FF2PL9(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFm5cy(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFm5cy(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FF3nQE(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFDENy(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFdLhv(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFss9S(txt):
 try:
  return FFDENy(FFdLhv(txt)) == txt
 except:
  return False
def FFSj4o(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCZilb, isFromExternal=isFromSession)
 else      : FF55kE(session, reopen=True, isFromExternal=isFromSession)
def FF55kE(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(BF(FF55kE, session, isFromExternal=isFromExternal), BF(CCTEDW, isFromExternal=isFromExternal))
  except:
   try:
    FF9ChJ(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFG0HY(refCode):
 tp = CCW6PA()
 if tp.VVASqv(refCode) : return True
 else        : return False
def FFWbo4(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFbWMQ():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF1xYh(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVCR76 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVCR76.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFD0f0():
 VVT9kk = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVS8sI = list(VVT9kk)
 return VVS8sI, VVT9kk
def FFbhWc():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFz7fz(session, VVoXmK):
 VVsqzS, VVbw5x, VVrWPz, camCommand = FF02qn()
 if VVbw5x:
  runLog = False
  if   VVoXmK == CCWGoE.VVFB1d : runLog = True
  elif VVoXmK == CCWGoE.VVGadb : runLog = True
  elif not VVrWPz          : FF9ChJ(session, message="SoftCam not started yet!")
  elif fileExists(VVrWPz)        : runLog = True
  else             : FF9ChJ(session, message="File not found !\n\n%s" % VVrWPz)
  if runLog:
   session.open(BF(CCWGoE, VVsqzS=VVsqzS, VVbw5x=VVbw5x, VVrWPz=VVrWPz, VVoXmK=VVoXmK))
 else:
  FF9ChJ(session, message="No active OSCam/NCam found !", title="Live Log")
def FF02qn():
 VVsqzS = "/etc/tuxbox/config/"
 VVbw5x = None
 VVrWPz  = None
 camCommand = FFrbAO("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVbw5x = "oscam"
 elif "ncam"  in camCommand : VVbw5x = "ncam"
 if VVbw5x:
  path = FFrbAO(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFjGgP(path)
  if pathExists(path):
   VVsqzS = path
  tFile = VVsqzS + VVbw5x + ".conf"
  tFile = FFrbAO("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVrWPz = tFile
 return VVsqzS, VVbw5x, VVrWPz, camCommand
def FFhNVP(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFP6g0(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFvSuo():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF03bo():
 return FFvSuo().replace(" ", "_").replace("-", "").replace(":", "")
def FFAdnL(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFj3cu():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFhNjK(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC5Be5.VVTRui(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC5Be5.VVGOKA(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFBSzC("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFDLFU(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFDe6w(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFyKQV(a, b):
 return (a > b) - (a < b)
def FFGmLx(a, b):
 def VVAqNT(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVAqNT(a)
 b = VVAqNT(b)
 return (a > b) - (a < b)
def FFDsiG(mycmp):
 class CCr0Jm(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCr0Jm
VVGsvB = 0
def FFldz0():
 global VVGsvB
 VVGsvB = iTime()
def FFwI7J(txt=""):
 FFxO0H(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVGsvB)).rstrip("0"), txt))
def FFO5iz(SELF, message, title=""):
 SELF.session.open(BF(CCvhn7, title=title, message=message, VVW7PG=True))
def FFzNhe(SELF, message, title="", VVwvtK=VVxPlb, **kwargs):
 SELF.session.open(BF(CCvhn7, title=title, message=message, VVwvtK=VVwvtK, **kwargs))
def FFNkji(SELF, message, title="")  : FF9ChJ(SELF.session, message, title)
def FFdzz0(SELF, path, title="") : FF9ChJ(SELF.session, "File not found !\n\n%s" % path, title)
def FF5DrN(SELF, path, title="") : FF9ChJ(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFdMgN(SELF, title="")  : FF9ChJ(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF9ChJ(session, message, title="") : session.open(BF(CC2zeu, title=title, message=message))
def FFhzot(SELF, VVJcVO, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVJcVO, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVJcVO, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFNkji(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFm5Au(SELF, callBack_Yes, VVljeR, callBack_No=None, title="", VVYN57=False, VV2Aw2=True):
 return SELF.session.openWithCallback(BF(FFmbfh, callBack_Yes, callBack_No)
          , BF(CCHgOS, title=title, VVljeR=VVljeR, VV2Aw2=VV2Aw2, VVYN57=VVYN57))
def FFmbfh(callBack_Yes, callBack_No, FFm5Aued):
 if FFm5Aued : callBack_Yes()
 elif callBack_No: callBack_No()
def FFMnBb(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFQZ4f(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFVUFq(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFPtMH(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVZjiQ = eTimer()
def FFVUFq(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFVJGb, SELF))
 fnc = BF(FFVJGb, SELF)
 try:
  t = VVZjiQ.timeout.connect(fnc)
 except:
  VVZjiQ.callback.append(fnc)
 VVZjiQ.start(milliSeconds, 1)
def FFVJGb(SELF):
 VVZjiQ.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFGcVX(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCw9VL, **kwargs))
  else   : win = SELF.session.open(BF(CCw9VL, **kwargs))
  FFr6hs(win)
  return win
 except:
  return None
def FFkkcl(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCVd7z, **kwargs))
 FFr6hs(win)
 return win
def FFhiR0(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFRDSd(SELF, **kwargs):
 SELF.session.open(CCGnOY, **kwargs)
def FFLvNc(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFZmKs(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FF4E9v(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV8NsC, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFMyEE(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF4E9v(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = (max(minRows, len(menuObj.list))) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFCroK():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF6Vdr(VVlOla):
 screenSize  = FFCroK()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVlOla)
 return bodyFontSize
def FFEiMT(VVlOla, extraSpace):
 font = gFont(VV8NsC, VVlOla)
 VVu02V = fontRenderClass.getInstance().getLineHeight(font) or (VVlOla * 1.25)
 return int(VVu02V + VVu02V * extraSpace)
def FFbZTb(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True):
 screenSize = FFCroK()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VV8NsC, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFEiMT(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VV8NsC, titleFontSize, alignLeftCenter)
 if winType == VVHFCN or winType == VV0IRp:
  if winType == VV0IRp : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVWvky:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVSV74:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#55113355" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VV44nA:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFO5izL = b2Left2 + timeW + marginLeft
  FFO5izW = b2Left3 - marginLeft - FFO5izL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFO5izL , b2Top, FFO5izW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVoG3n:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVuVSN:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVcj6X:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVF06t:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV8NsC, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV8NsC, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVFwlX:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV8NsC, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVmXPN:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV8NsC, fontH, alignCenter)
 elif winType == VVQjBQ:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VV8NsC, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VV8NsC, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VV8NsC, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVM6Ow:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVaWzv:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVqL9P : align = alignLeftCenter
  elif winType == VVM7on : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVU9A6:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VV8NsC
  if usefixedFont and winType == VVM7on:
   fnt = "Fixed"
   if fnt in FFI1Fg():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVlOla = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV8NsC, VVlOla, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVHzNF = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV8NsC, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVHzNF[i], VV8NsC, barFont, alignCenter)
   left += btnW + gap
 if winType == VVM7on:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVHzNF = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVHzNF[i], VV8NsC, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVtuuZ = ""
  self.themsList  = []
  s = "  "
  VVWp2B = []
  if VVl5oG:
   VVWp2B.append(("-- MY TEST --"    , "myTest"   ))
  VVWp2B.append((s + "File Manager"     , "FileManager"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append((s + "Services/Channels"   , "ChannelsTools" ))
  VVWp2B.append((s + "IPTV"       , "IptvTools"  ))
  VVWp2B.append((s + "PIcons"      , "PIconsTools"  ))
  VVWp2B.append((s + "SoftCam"      , "SoftCam"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append((s + "Plugins"      , "PluginsTools" ))
  VVWp2B.append((s + "Terminal"      , "Terminal"  ))
  VVWp2B.append((s + "Backup & Restore"    , "BackupRestore" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append((s + "Date/Time"     , "Date_Time"  ))
  VVWp2B.append((s + "Check Internet Connection" , "CheckInternet" ))
  self.totalItems = len(VVWp2B)
  FF2wUT(self, VVWp2B=VVWp2B)
  FF4HaE(self["keyRed"] , "Exit")
  FF4HaE(self["keyGreen"] , "Settings")
  FF4HaE(self["keyYellow"], "Dev. Info.")
  FF4HaE(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close      ,
   "green"   : self.VVKl50     ,
   "yellow"  : self.VVqEty     ,
   "blue"   : self.VVSv4b     ,
   "info"   : self.VVSv4b     ,
   "next"   : self.VVpf21     ,
   "menu"   : self.VVeKIG   ,
   "text"   : self.VVcm3r    ,
   "0"    : BF(self.VVbyat, 0)  ,
   "1"    : BF(self.VVe7u5, 1)   ,
   "2"    : BF(self.VVe7u5, 2)   ,
   "3"    : BF(self.VVe7u5, 3)   ,
   "4"    : BF(self.VVe7u5, 4)   ,
   "5"    : BF(self.VVe7u5, 5)   ,
   "6"    : BF(self.VVe7u5, 6)   ,
   "7"    : BF(self.VVe7u5, 7)   ,
   "8"    : BF(self.VVe7u5, 8)   ,
   "9"    : BF(self.VVe7u5, 9)
  })
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
  global VVYACA, VVv9Mc, VVGp08
  VVYACA = VVv9Mc = VVGp08 = False
 def VVxkj1(self):
  item = FFxhQe(self)
  self.VVe7u5(item)
 def VVe7u5(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVxquG()
   elif item in ("FileManager"  , 1) : self.session.open(CC0Jp1)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCabmO)
   elif item in ("IptvTools"  , 3) : self.session.open(CC5Be5)
   elif item in ("PIconsTools"  , 4) : self.VVcAH5()
   elif item in ("SoftCam"   , 5) : self.session.open(CCmkEc)
   elif item in ("PluginsTools" , 6) : self.session.open(CCYsEd)
   elif item in ("Terminal"  , 7) : self.session.open(CCAxj8)
   elif item in ("BackupRestore" , 8) : self.session.open(CCpjyK)
   elif item in ("Date_Time"  , 9) : self.session.open(CChXIF)
   elif item in ("CheckInternet" , 10) : self.session.open(CC4PeP)
   else         : self.close()
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
  FFLvNc(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVJHEy)
  self["myTitle"].setText(title)
  VV6rpB, VV5z34, VVq6q0, VVdtOF, VVFYRE, oldMovieDownloadPath = FFnpBj()
  self.VV4U2g()
  if VV6rpB or VV5z34 or VVq6q0 or VVdtOF or VVFYRE or oldMovieDownloadPath:
   VVZ1Gm = lambda path, subj: "%s:\n%s\n\n" % (subj, FFtSnl(path, VVFkfi)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVZ1Gm(VV6rpB   , "Backup/Restore Path"    )
   txt += VVZ1Gm(VV5z34  , "Created Package Files (IPK/DEB)" )
   txt += VVZ1Gm(VVq6q0  , "Download Packages (from feeds)" )
   txt += VVZ1Gm(VVdtOF , "Exported Tables"     )
   txt += VVZ1Gm(VVFYRE , "Exported PIcons"     )
   txt += VVZ1Gm(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFzNhe(self, txt, title="Settings Paths")
  if (EASY_MODE or VVoTP7 or VVl5oG):
   FFQZ4f(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFMnBb(self, "Welcome", 300)
  FFrvtJ(BF(self.VVsgxx, title))
 def VVsgxx(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCVDyw.VV4z4h()
   if url:
    newWebVer = CCVDyw.VVDHyj(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFBSzC("rm /tmp/ajpanel*"))
  global VVYACA, VVv9Mc, VVGp08
  VVYACA = VVv9Mc = VVGp08 = False
 def VVbyat(self, digit):
  self.VVtuuZ += str(digit)
  ln = len(self.VVtuuZ)
  global VVYACA, VVGp08
  if ln == 4:
   if self.VVtuuZ == "0" * ln:
    VVYACA = True
    FFQZ4f(self["myTitle"], "#800080")
   else:
    self.VVtuuZ = "x"
  elif self.VVtuuZ == "0" * 8:
   VVGp08 = True
 def VVpf21(self):
  self.VVtuuZ += ">"
  if self.VVtuuZ == "0" * 4 + ">" * 2:
   global VVv9Mc
   VVv9Mc = True
   FFQZ4f(self["myTitle"], "#dd5588")
 def VVcm3r(self):
  if self.VVtuuZ == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFMnBb(self, txt, 2000, isGrn=ok)
 def VVcAH5(self):
  found = False
  pPath = CCgJhP.VVkis2()
  if pathExists(pPath):
   for fName, fType in CCgJhP.VVxlTB(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCgJhP)
  else:
   VVWp2B = []
   VVWp2B.append(("PIcons Tools" , "CCgJhP" ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(CCgJhP.VV6b2T())
   VVWp2B.append(VVEgY4)
   VVWp2B += CCgJhP.VVA6FY()
   FFkkcl(self, self.VVxCrJ, VVWp2B=VVWp2B)
 def VVxCrJ(self, item=None):
  if item:
   if   item == "CCgJhP"   : self.session.open(CCgJhP)
   elif item == "VV1grA"  : CCgJhP.VV1grA(self)
   elif item == "VVKwF6"  : CCgJhP.VVKwF6(self)
   elif item == "findPiconBrokenSymLinks" : CCgJhP.VVhF3a(self, True)
   elif item == "FindAllBrokenSymLinks" : CCgJhP.VVhF3a(self, False)
 def VVKl50(self):
  self.session.open(CCVDyw)
 def VVqEty(self):
  self.session.open(CCQeh4)
 def VVSv4b(self):
  changeLogFile = VVE4he + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFsCGi(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFtSnl("\n%s\n%s\n%s" % (VVJ1qT, line, VVJ1qT), VVxbdF, VVXldd)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFtSnl(line, VVpi4Z, VVXldd)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFzNhe(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVJHEy, PLUGIN_DESCRIPTION), VVlOla=26)
 def VVeKIG(self):
  VVWp2B = []
  VVWp2B.append(("Title Colors"   , "title" ))
  VVWp2B.append(("Menu Area Colors"  , "body" ))
  VVWp2B.append(("Menu Pointer Colors" , "cursor" ))
  VVWp2B.append(("Bottom Bar Colors" , "bar"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFkkcl(self, BF(self.VV8sFD, title), VVWp2B=VVWp2B, width=500, title=title)
 def VV8sFD(self, title, item=None):
  if item:
   if item == "reset":
    FFm5Au(self, self.VV0XRK, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVgUMT()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVWfeW, tDict, item), CCtsQD, defFG=fg, defBG=bg)
 def VVLk2d(self):
  return VVcqbj + "ajpanel_colors"
 def VVgUMT(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVLk2d()
  if fileExists(p):
   txt = FFS3H9(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVWfeW(self, tDict, item, fg, bg):
  if fg:
   self.VVSJ01(item, fg)
   self.VVbXoy(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VV8kKw(tDict)
 def VV8kKw(self, tDict):
   p = self.VVLk2d()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVSJ01(self, item, fg):
  if   item == "title" : FFryZu(self["myTitle"], fg)
  elif item == "body"  :
   FFryZu(self["myMenu"], fg)
   FFryZu(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFQZ4f(self["myBar"], fg)
   FFryZu(self["keyRed"], fg)
   FFryZu(self["keyGreen"], fg)
   FFryZu(self["keyYellow"], fg)
   FFryZu(self["keyBlue"], fg)
 def VVbXoy(self, item, bg):
  if   item == "title" : FFQZ4f(self["myTitle"], bg)
  elif item == "body"  :
   FFQZ4f(self["myMenu"], bg)
   FFQZ4f(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFQZ4f(self["myBar"], bg)
 def VV0XRK(self):
  os.system(FFBSzC("rm %s" % self.VVLk2d()))
  self.close()
 def VV4U2g(self):
  tDict = self.VVgUMT()
  self.VV42Q6(tDict, "title")
  self.VV42Q6(tDict, "body")
  self.VV42Q6(tDict, "cursor")
  self.VV42Q6(tDict, "bar")
 def VV42Q6(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVSJ01(name, fg)
  if bg: self.VVbXoy(name, bg)
 def VVxquG(self):
  self.session.open(CCZilb)
class CCF2zZ():
 @staticmethod
 def VVTDKm():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVDloz(isApply=False):
  global VVgzsn, VVqWYD
  VVgzsn  = True
  VVqWYD = CCF2zZ.VVoFkl()
  CCF2zZ.VVukuk()
 @staticmethod
 def VVukuk():
  if VVqWYD:
   global VVgzsn
   if CFG.forceUtf8Encoding.getValue():
    if CCF2zZ.VVMJ45() : VVgzsn = True
    else        : VVgzsn = False
   else:
    CCF2zZ.VV0Gy9()
    VVgzsn = False
 @staticmethod
 def VVoFkl(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    txt = FFS3H9(path)
    span = iSearch(r"open.?vision", txt, IGNORECASE)
    if span:
     return True
  return False
 @staticmethod
 def VVMJ45():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VV0Gy9():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VV2XbA(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFGcVX(SELF, None, VVJXpL=lst, VVlOla=30, VVf6X3=True)
 @staticmethod
 def VVNH6s(path, SELF=None):
  for enc in CCF2zZ.VVTDKm():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFNkji(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVSvbv(SELF, path, cbFnc, defEnc="utf8", pos=0, onlyWorkingEnc=True, title="Select Encoding"):
  FFMnBb(SELF)
  lst = CCF2zZ.VVJIdt(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVWp2B = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFtSnl(txt, VV41YE)
    VVWp2B.append((txt, enc))
   if onlyWorkingEnc: VVcV6s, VV89EB = "#22003344", "#22002233"
   else    : VVcV6s, VV89EB = "#22220000", "#22220000"
   win = FFkkcl(SELF, cbFnc, title=title, VVWp2B=VVWp2B, width=900, height=500 if pos == 1 else 0, VVcV6s=VVcV6s, VV89EB=VV89EB)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFMnBb(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVJIdt(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVE4he + "codecs"
  if fileExists(cPath):
   lines = FFsCGi(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCF2zZ.VVTDKm())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCQeh4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVWp2B = []
  VVWp2B.append(("Settings File"        , "SettingsFile"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Box Info"          , "VVQZC3"    ))
  VVWp2B.append(("Tuners Info"         , "VVFwpI"   ))
  VVWp2B.append(("Python Version"        , "VViChk"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Screen Size"         , "ScreenSize"    ))
  VVWp2B.append(("Language/Locale"        , "Locale"     ))
  VVWp2B.append(("Processor"         , "Processor"    ))
  VVWp2B.append(("Operating System"        , "OperatingSystem"   ))
  VVWp2B.append(("Drivers"          , "drivers"     ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("System Users"         , "SystemUsers"    ))
  VVWp2B.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVWp2B.append(("Uptime"          , "Uptime"     ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Host Name"         , "HostName"    ))
  VVWp2B.append(("MAC Address"         , "MACAddress"    ))
  VVWp2B.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVWp2B.append(("Network Status"        , "NetworkStatus"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Disk Usage"         , "VVCS8M"    ))
  VVWp2B.append(("Mount Points"         , "MountPoints"    ))
  VVWp2B.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVWp2B.append(("USB Devices"         , "USB_Devices"    ))
  VVWp2B.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVWp2B.append(("Directory Size"        , "DirectorySize"   ))
  VVWp2B.append(("Memory"          , "Memory"     ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVWp2B.append(("Running Processes"       , "RunningProcesses"  ))
  VVWp2B.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF2wUT(self, VVWp2B=VVWp2B, title="Device Information")
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCEzEM)
   elif item == "VVQZC3"    : self.VVQZC3()
   elif item == "VVFwpI"   : self.VVFwpI()
   elif item == "VViChk"   : self.VViChk()
   elif item == "ScreenSize"    : FFzNhe(self, "Width\t: %s\nHeight\t: %s" % (FFCroK()[0], FFCroK()[1]))
   elif item == "Locale"     : CCF2zZ.VV2XbA(self)
   elif item == "Processor"    : self.VVOFMb()
   elif item == "OperatingSystem"   : FFxeLA(self, "uname -a"        )
   elif item == "drivers"     : self.VVrEqO()
   elif item == "SystemUsers"    : FFxeLA(self, "id"          )
   elif item == "LoggedInUsers"   : FFxeLA(self, "who -a"         )
   elif item == "Uptime"     : FFxeLA(self, "uptime"         )
   elif item == "HostName"     : FFxeLA(self, "hostname"        )
   elif item == "MACAddress"    : self.VVKIdT()
   elif item == "NetworkConfiguration"  : FFxeLA(self, "ifconfig %s %s" % (FF7gKg("HWaddr", VV31Rm), FF7gKg("addr:", VVxbdF)))
   elif item == "NetworkStatus"   : FFxeLA(self, "netstat -tulpn"       )
   elif item == "VVCS8M"    : self.VVCS8M()
   elif item == "MountPoints"    : FFxeLA(self, "mount %s" % (FF7gKg(" on ", VVxbdF)))
   elif item == "FileSystemTable"   : FFxeLA(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFxeLA(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFxeLA(self, "blkid"         )
   elif item == "DirectorySize"   : FFxeLA(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVmOjC="Reading size ...")
   elif item == "Memory"     : FFxeLA(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVqpe7()
   elif item == "RunningProcesses"   : FFxeLA(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFxeLA(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVS0lh()
   else         : self.close()
 def VVKIdT(self):
  res = FFWdfY("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFzNhe(self, txt)
  else:
   FFxeLA(self, "ip link")
 def VVv1rP(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF42E1(cmd)
  return lines
 def VV13oO(self, lines, headerRepl, widths, VVKrzB):
  VVMGU8 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVMGU8.append(parts)
  if VVMGU8 and len(header) == len(widths):
   VVMGU8.sort(key=lambda x: x[0].lower())
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=28, VVf6X3=True)
   return True
  else:
   return False
 def VVCS8M(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFWdfY(cmd)
  if not "invalid option" in txt:
   lines  = self.VVv1rP(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVKrzB = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV13oO(lines, headerRepl, widths, VVKrzB)
  else:
   cmd = "df -h"
   lines  = self.VVv1rP(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVKrzB = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV13oO(lines, headerRepl, widths, VVKrzB)
  if not allOK:
   lines = FF42E1(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFRs7V(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV41YE:
     note = "\n%s" % FFtSnl("Green = Mounted Partitions", VV41YE)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVxbdF
     elif line.endswith(mountList) : color = VV41YE
     else       : color = VVpi4Z
     txt += FFtSnl(line, color) + "\n"
    FFzNhe(self, txt + note)
   else:
    FFNkji(self, "Not data from system !")
 def VVqpe7(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVv1rP(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVKrzB = (LEFT , CENTER, LEFT )
  allOK = self.VV13oO(lines, headerRepl, widths, VVKrzB)
  if not allOK:
   FFxeLA(self, cmd)
 def VVrEqO(self):
  cmd = FFU3rV(VVX80U, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFxeLA(self, cmd)
  else : FFdMgN(self)
 def VVOFMb(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFxeLA(self, cmd)
 def VVS0lh(self):
  cmd = FFU3rV(VVIqCh, "| grep secondstage")
  if cmd : FFxeLA(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFdMgN(self)
 def VVQZC3(self):
  c = VV41YE
  VVJXpL = []
  VVJXpL.append((FFtSnl("Box Type"  , c), FFtSnl(self.VVaHOu("boxtype").upper(), c)))
  VVJXpL.append((FFtSnl("Board Version", c), FFtSnl(self.VVaHOu("board_revision") , c)))
  VVJXpL.append((FFtSnl("Chipset"  , c), FFtSnl(self.VVaHOu("chipset")  , c)))
  VVJXpL.append((FFtSnl("S/N"   , c), FFtSnl(self.VVaHOu("sn")    , c)))
  VVJXpL.append((FFtSnl("Version"  , c), FFtSnl(self.VVaHOu("version")  , c)))
  VVXIjM   = []
  VVCeJr = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVCeJr = SystemInfo[key]
     else:
      VVXIjM.append((FFtSnl(str(key), VVMXOB), FFtSnl(str(SystemInfo[key]), VVMXOB)))
  except:
   pass
  if VVCeJr:
   VVB1fs = self.VVT0RA(VVCeJr)
   if VVB1fs:
    VVB1fs.sort(key=lambda x: x[0].lower())
    VVJXpL += VVB1fs
  if VVXIjM:
   VVXIjM.sort(key=lambda x: x[0].lower())
   VVJXpL += VVXIjM
  if VVJXpL:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFGcVX(self, None, header=header, VVJXpL=VVJXpL, VVQGhe=widths, VVlOla=28, VVf6X3=True)
  else:
   FFzNhe(self, "Could not read info!")
 def VVaHOu(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFsCGi(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVT0RA(self, mbDict):
  try:
   mbList = list(mbDict)
   VVJXpL = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVJXpL.append((FFtSnl(subject, VVxbdF), FFtSnl(value, VVxbdF)))
  except:
   pass
  return VVJXpL
 def VVFwpI(self):
  txt = self.VVZTTF("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVZTTF("/proc/bus/nim_sockets")
  if not txt: txt = self.VV6iKe()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFzNhe(self, txt)
 def VV6iKe(self):
  txt = ""
  VVZ1Gm = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVZ1Gm("Slot Name" , slot.getSlotName())
     txt += FFtSnl(slotName, VVxbdF)
     txt += VVZ1Gm("Description"  , slot.getFullDescription())
     txt += VVZ1Gm("Frontend ID"  , slot.frontend_id)
     txt += VVZ1Gm("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVZTTF(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFsCGi(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFtSnl(line, VVxbdF)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VViChk(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFzNhe(self, txt)
 @staticmethod
 def VVdrxI():
  def VVZ1Gm(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVZ1Gm(v,0), "/etc/issue.net": VVZ1Gm(v,1), "/etc/image-version": VVZ1Gm(v,2)}
  for p1, d in v.items():
   img = CCQeh4.VVtOEp(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVZ1Gm(v,0), p + "Plugins/": VVZ1Gm(v,1), VVkWLd: VVZ1Gm(v,2), VVubKs: VVZ1Gm(v,3)}
  for p1, d in v.items():
   img = CCQeh4.VV43B6(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVtOEp(path, d):
  if fileExists(path):
   txt = FFS3H9(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VV43B6(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCEzEM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVWp2B = []
  VVWp2B.append(("Settings (All)"   , "Settings_All"   ))
  VVWp2B.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVv9Mc:
   VVWp2B.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVWp2B.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVWp2B.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVWp2B.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVWp2B.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVWp2B.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FF2wUT(self, VVWp2B=VVWp2B)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFxeLA(self, cmd                )
   elif item == "Settings_HotKeys"   : FFxeLA(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFxeLA(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFxeLA(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFxeLA(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFxeLA(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFxeLA(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFxeLA(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCmkEc(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVsqzS, VVbw5x, VVrWPz, camCommand = FF02qn()
  self.VVbw5x = VVbw5x
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVWp2B = []
  VVWp2B.append(("OSCam Files"        , "OSCamFiles"  ))
  VVWp2B.append(("NCam Files"        , "NCamFiles"  ))
  VVWp2B.append(("CCcam Files"        , "CCcamFiles"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVWp2B.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVWp2B.append(VVEgY4)
  if VVbw5x:
   if   "oscam" in VVbw5x : camName = "OSCam"
   elif "ncam"  in VVbw5x : camName = "NCam"
   VVWp2B.append((camName + " Info."      , "camInfo"   ))
   VVWp2B.append((camName + " Live Status"    , "camLiveStatus" ))
   VVWp2B.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVWp2B.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVWp2B.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FF2wUT(self, VVWp2B=VVWp2B)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCxKLG, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCxKLG, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCxKLG, "cccam"))
   elif item == "OSCamReaders"  : self.VVhIAF("os")
   elif item == "NSCamReaders"  : self.VVhIAF("n")
   elif item == "camInfo"   : FFVMzp(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFz7fz(self.session, CCWGoE.VVFB1d)
   elif item == "camLiveReaders" : FFz7fz(self.session, CCWGoE.VVGadb)
   elif item == "camLiveLog"  : FFz7fz(self.session, CCWGoE.VVsXUK)
   else       : self.close()
 def VVhIAF(self, camPrefix):
  VVMGU8 = self.VVimbL(camPrefix)
  if VVMGU8:
   VVMGU8.sort(key=lambda x: int(x[0]))
   if self.VVbw5x and self.VVbw5x.startswith(camPrefix):
    VV1NOm = ("Toggle State", self.VVvd31, [camPrefix], "Changing State ...")
   else:
    VV1NOm = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVKrzB  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VV1NOm=VV1NOm, VVLHme=True)
 def VVimbL(self, camPrefix):
  readersFile = self.VVsqzS + camPrefix + "cam.server"
  VVMGU8 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFsCGi(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVMGU8.append((str(len(VVMGU8) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVMGU8:
    FFNkji(self, "No readers found !")
  else:
   FFdzz0(self, readersFile)
  return VVMGU8
 def VVvd31(self, VVMsCC, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVsqzS, camPrefix)
  readerState  = VVMsCC.VVG5WS(1)
  readerLabel  = VVMsCC.VVG5WS(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCmkEc.VVY4zK(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVMsCC.VVjUpN()
    FFNkji(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVMGU8 = self.VVimbL(camPrefix)
   if VVMGU8:
    VVMsCC.VVsLrn(VVMGU8)
 @staticmethod
 def VVY4zK(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFsCGi(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFNkji(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFNkji(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFdzz0(SELF, confFile)
   return None
  if not iRequest:
   FFNkji(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFNkji(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFNkji(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCxKLG(Screen):
 def __init__(self, VVNBtj, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVsqzS, VVbw5x, VVrWPz, camCommand = FF02qn()
  if   VVNBtj == "ncam" : self.prefix = "n"
  elif VVNBtj == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVWp2B = []
  if self.prefix == "":
   VVWp2B.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVWp2B.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVWp2B.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVWp2B.append(("constant.cw"         , "x_constant_cw" ))
   VVWp2B.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVWp2B.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVWp2B.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVWp2B.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVWp2B.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVWp2B.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVWp2B.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVWp2B.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVWp2B.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVWp2B.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVWp2B.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF2wUT(self, VVWp2B=VVWp2B)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFjMtD(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFjMtD(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFjMtD(self, self.VVsqzS + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFjMtD(self, self.VVsqzS + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVDY0W("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVDY0W("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVDY0W("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVDY0W("cam.provid"        )
   elif item == "x_cam_server"  : self.VVDY0W("cam.server"        )
   elif item == "x_cam_services" : self.VVDY0W("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVDY0W("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVDY0W("cam.user"        )
   elif item == "x_VVJ1qT"   : pass
   elif item == "x_SoftCam_Key" : self.VVaAxh()
   elif item == "x_CCcam_cfg"  : FFjMtD(self, self.VVsqzS + "CCcam.cfg"    )
   elif item == "x_VVJ1qT"   : pass
   elif item == "x_cam_log"  : FFjMtD(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFjMtD(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFjMtD(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVDY0W(self, fileName):
  FFjMtD(self, self.VVsqzS + self.prefix + fileName)
 def VVaAxh(self):
  path = self.VVsqzS + "SoftCam.Key"
  if fileExists(path) : FFjMtD(self, path)
  else    : FFjMtD(self, path.replace(".Key", ".key"))
class CCWGoE(Screen):
 VVFB1d  = 0
 VVGadb = 1
 VVsXUK = 2
 def __init__(self, session, VVsqzS="", VVbw5x="", VVrWPz="", VVoXmK=VVFB1d):
  self.skin, self.skinParam = FFbZTb(VVM7on, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVrWPz   = VVrWPz
  self.VVoXmK  = VVoXmK
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVsqzS + VVbw5x + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVbw5x : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVsqzS, self.camPrefix)
  if self.VVoXmK == self.VVFB1d:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVoXmK == self.VVGadb:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF2wUT(self, self.Title, addScrollLabel=True)
  FF4HaE(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VViwlE
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self["myLabel"].VVVQK5(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFLvNc(self)
  self.VViwlE()
 def onExit(self):
  self.timer.stop()
 def VVuopD(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVNAW5)
  except:
   self.timer.callback.append(self.VVNAW5)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFMnBb(self, "Started", 1000)
 def VV119a(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVNAW5)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFMnBb(self, "Stopped", 1000)
 def VViwlE(self):
  if self.timerRunning:
   self.VV119a()
  else:
   self.VVuopD()
   if self.VVoXmK == self.VVFB1d or self.VVoXmK == self.VVGadb:
    if self.VVoXmK == self.VVFB1d : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCmkEc.VVY4zK(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFrvtJ(self.VV2PJ4)
    else:
     self.close()
   else:
    self.VVo1cf()
 def VVNAW5(self):
  if self.timerRunning:
   if   self.VVoXmK == self.VVFB1d : self.VVWnWq()
   elif self.VVoXmK == self.VVGadb : self.VVWnWq()
   else            : self.VVo1cf()
 def VVo1cf(self):
  if fileExists(self.VVrWPz):
   fTime = FFP6g0(os.path.getmtime(self.VVrWPz))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVLmWF(), VVwvtK=VVs2cN)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVrWPz)
 def VV2PJ4(self):
  self.VVWnWq()
 def VVWnWq(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFtSnl("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVpqRv))
   self.camWebIfErrorFound = True
   self.VV119a()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVoXmK == self.VVFB1d : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFtSnl("Error while parsing data elements !\n\nError = %s" % str(e), VVG74s)
   self.camWebIfErrorFound = True
   self.VV119a()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVqjFS(root)
  self["myLabel"].setText(txt, VVwvtK=VVs2cN)
  self["myBar"].setText("Last Update : %s" % FFvSuo())
 def VVqjFS(self, rootElement):
  def VVZ1Gm(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVoXmK == self.VVFB1d:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFtSnl(status, VV41YE)
    else          : status = FFtSnl(status, VVG74s)
    txt += VVJ1qT + "\n"
    txt += VVZ1Gm("Name"  , name)
    txt += VVZ1Gm("Description" , desc)
    txt += VVZ1Gm("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVZ1Gm("Protocol" , protocol)
    txt += VVZ1Gm("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFtSnl("Yes", VV41YE)
    else    : enabTxt = FFtSnl("No", VVG74s)
    txt += VVJ1qT + "\n"
    txt += VVZ1Gm("Label"  , label)
    txt += VVZ1Gm("Protocol" , protocol)
    txt += VVZ1Gm("Enabled" , enabTxt)
  return txt
 def VVLmWF(self):
  wordsDict = self.VVgKx2()
  color = [ VVxbdF, VV31Rm, VV41YE, VVG74s, VVMXOB, VVvinO]
  lines = FF42E1("tail -n %d %s" % (100, self.VVrWPz))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVpqRv + line[:19] + VVpi4Z + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVXldd + line[ndx + 3:] + VVpi4Z
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVxbdF + line[ndx + 8 : ndx1 + 4] + VVpi4Z + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVpi4Z)
   elif line.startswith("----") or ">>" in line:
    line = FFtSnl(line, VVxbdF)
   txt += line + "\n"
  return txt
 def VVgKx2(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFsCGi(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCpjyK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVWp2B = []
  VVWp2B.append(("Backup Channels"    , "VVdtN6"   ))
  VVWp2B.append(("Restore Channels"    , "Restore_Channels"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Backup SoftCAM Files"   , "VVJ732" ))
  VVWp2B.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVWp2B.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVWp2B.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Backup Network Settings"  , "VVubbf"   ))
  VVWp2B.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVv9Mc:
   VVWp2B.append(VVEgY4)
   VVWp2B.append((VVpqRv + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VV176y"   ))
   VVWp2B.append((VV41YE + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVZztu) , "createMyIpk"   ))
   VVWp2B.append((VV41YE + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVZztu) , "createMyDeb"   ))
   VVWp2B.append((VVMXOB + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVWp2B.append((VVMXOB + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV6PlX" ))
  FF2wUT(self, VVWp2B=VVWp2B)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVdtN6"    : self.VVdtN6()
   elif item == "Restore_Channels"    : self.VVssLK("channels_backup*.tar.gz", self.VVgbTb)
   elif item == "VVJ732"   : self.VVJ732()
   elif item == "Restore_SoftCAM_Files"  : self.VVssLK("softcam_backup*.tar.gz", self.VVWrT4)
   elif item == "Backup_TunerDiSEqC"   : self.VVmUQO("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVssLK("tuner_backup*.backup", BF(self.VVQplb, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVmUQO("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVssLK("hotkey_*backup*.backup", BF(self.VVQplb, "misc"))
   elif item == "VVubbf"    : self.VVubbf()
   elif item == "Restore_Network"    : self.VVssLK("network_backup*.tar.gz", self.VVoXtr)
   elif item == "VV176y"     : FFm5Au(self, BF(FFOvQF, self, BF(CCpjyK.VV176y, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVGOPb(False)
   elif item == "createMyDeb"     : self.VVGOPb(True)
   elif item == "createMyTar"     : self.VVuhgy()
   elif item == "VV6PlX"   : self.VV6PlX()
 @staticmethod
 def VV176y(SELF):
  OBF_Path = VVH5lR + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVH5lR, VVJHEy, VVZztu)
   if err : FFNkji(SELF, err)
   else : FFzNhe(SELF, txt)
  else:
   FFdzz0(SELF, OBF_Path)
 def VVGOPb(self, VVeUfE):
  OBF_Path = VVH5lR + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFNkji(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVH5lR)
  os.system("mv -f %s %s" % (VVH5lR + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVH5lR + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVH5lR + "plugin.py"))
  self.session.openWithCallback(self.VVrqxP, BF(CCwDfU, path=VVH5lR, VVeUfE=VVeUfE))
 def VVrqxP(self):
  os.system("mv -f %s %s" % (VVH5lR + "OBF/main.py"  , VVH5lR))
  os.system("mv -f %s %s" % (VVH5lR + "OBF/plugin.py" , VVH5lR))
 def VV6PlX(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFNkji(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFNkji(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVx0OB("%s*.list" % path)
  if err:
   FFdzz0(self, path + "*.list")
   return
  srcF, err = self.VVx0OB("%s*main_final.py" % path)
  if err:
   FFdzz0(self, path + "*.final.py")
   return
  VVJXpL = []
  for f in files:
   f = os.path.basename(f)
   VVJXpL.append((f, f))
  FFkkcl(self, BF(self.VVaYuG, path, codF, srcF), VVWp2B=VVJXpL)
 def VVaYuG(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFdzz0(self, logF)
   else     : FFOvQF(self, BF(self.VVlqpV, logF, codF, srcF))
 def VVlqpV(self, logF, codF, srcF):
  lst  = []
  lines = FFsCGi(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFNkji(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVYl6Y(lst, logF, newLogF)
  totSrc  = self.VVYl6Y(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFzNhe(self, txt)
 def VVx0OB(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVYl6Y(self, lst, f1, f2):
  txt = FFS3H9(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVuhgy(self):
  VVJXpL = []
  VVJXpL.append("%s%s" % (VVH5lR, "*.py"))
  VVJXpL.append("%s%s" % (VVH5lR, "*.png"))
  VVJXpL.append("%s%s" % (VVH5lR, "*.xml"))
  VVJXpL.append("%s"  % (VVE4he))
  FFrWpy(self, VVJXpL, "%s_%s" % (PLUGIN_NAME, VVJHEy), addTimeStamp=False)
 def VVdtN6(self):
  path1 = VVSwef
  path2 = "/etc/tuxbox/"
  VVJXpL = []
  VVJXpL.append("%s%s" % (path1, "*.tv"))
  VVJXpL.append("%s%s" % (path1, "*.radio"))
  VVJXpL.append("%s%s" % (path1, "*list"))
  VVJXpL.append("%s%s" % (path1, "lamedb*"))
  VVJXpL.append("%s%s" % (path2, "*.xml"))
  FFrWpy(self, VVJXpL, self.VVxOso("channels_backup"), addTimeStamp=True)
 def VVJ732(self):
  VVJXpL = []
  VVJXpL.append("/etc/tuxbox/config/")
  VVJXpL.append("/usr/keys/")
  VVJXpL.append("/usr/scam/")
  VVJXpL.append("/etc/CCcam.cfg")
  FFrWpy(self, VVJXpL, self.VVxOso("softcam_backup"), addTimeStamp=True)
 def VVubbf(self):
  VVJXpL = []
  VVJXpL.append("/etc/hostname")
  VVJXpL.append("/etc/default_gw")
  VVJXpL.append("/etc/resolv.conf")
  VVJXpL.append("/etc/wpa_supplicant*.conf")
  VVJXpL.append("/etc/network/interfaces")
  VVJXpL.append("/etc/enigma2/nameserversdns.conf")
  FFrWpy(self, VVJXpL, self.VVxOso("network_backup"), addTimeStamp=True)
 def VVxOso(self, fName):
  img = CCQeh4.VVdrxI()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVgbTb(self, fileName=None):
  if fileName:
   FFm5Au(self, BF(self.VVWHVW, fileName), "Overwrite current channels ?")
 def VVWHVW(self, fileName):
  path = "%s%s" % (VVcqbj, fileName)
  if fileExists(path):
   VVPg8l , VV4kv4 = CCabmO.VVRNsy()
   VVT8q3, VVuNCO = CCabmO.VVAB9n()
   cmd = ""
   cmd += FFBSzC("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFBSzC("rm -f %s %s" % (VV4kv4, VVuNCO)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFbWMQ()
   if res == 0 : FFO5iz(self, "Channels Restored.")
   else  : FFNkji(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFdzz0(self, path)
 def VVWrT4(self, fileName=None):
  if fileName:
   FFm5Au(self, BF(self.VV72HF, fileName), "Overwrite SoftCAM files ?")
 def VV72HF(self, fileName):
  fileName = "%s%s" % (VVcqbj, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVJ1qT
   note = "You may need to restart your SoftCAM."
   FFEMu6(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF7gKg(note, VVxbdF), sep))
  else:
   FFdzz0(self, fileName)
 def VVoXtr(self, fileName=None):
  if fileName:
   FFm5Au(self, BF(self.VV6pEJ, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV6pEJ(self, fileName):
  fileName = "%s%s" % (VVcqbj, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF355v(self,  cmd)
  else:
   FFdzz0(self, fileName)
 def VVssLK(self, pattern, callBackFunction, isTuner=False):
  title = FFPcSK()
  if pathExists(VVcqbj):
   myFiles = iGlob("%s%s" % (VVcqbj, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVJXpL = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVJXpL.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVKBZE = ("Sat. List", self.VV7RVN)
    else  : VVKBZE = None
    VVBc7a = ("Delete File", self.VVgOGw)
    FFkkcl(self, callBackFunction, title=title, width=1200, VVWp2B=VVJXpL, VVKBZE=VVKBZE, VVBc7a=VVBc7a)
   else:
    FFNkji(self, "No files found in:\n\n%s" % VVcqbj, title)
  else:
   FFNkji(self, "Path not found:\n\n%s" % VVcqbj, title)
 def VVgOGw(self, VVW8faObj, path):
  FFm5Au(self, BF(self.VVu1o9, VVW8faObj, path), "Delete this file ?\n\n%s" % path)
 def VVu1o9(self, VVW8faObj, path):
  path = VVcqbj + path
  os.system(FFBSzC("rm -f '%s'" % path))
  if fileExists(path) : FFMnBb(VVW8faObj, "Not deleted", 1000)
  else    : VVW8faObj.VV5ZmU()
 def VVmUQO(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCtypF()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVgXVr, filePrefix))
 def VVgXVr(self, filePrefix, result, retval):
  title = FFPcSK()
  if pathExists(VVcqbj):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFNkji(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVcqbj, filePrefix, self.VVxOso(""), FF03bo())
    try:
     VVJXpL = str(result.strip()).split()
     if VVJXpL:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVJXpL:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVJ1qT, FFtSnl(fName, VVxbdF), VVJ1qT)
       FFzNhe(self, txt, title=title, VVwvtK=VVs2cN)
      else:
       FFNkji(self, "File creation failed!", title)
     else:
      FFNkji(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFBSzC("rm %s" % fName))
     FFNkji(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFBSzC("rm %s" % fName))
     FFNkji(self, "Error while writing file.")
  else:
   FFNkji(self, "Path not found:\n\n%s" % VVcqbj, title)
 def VVQplb(self, mode, path=None):
  if path:
   path = "%s%s" % (VVcqbj, path)
   if fileExists(path):
    lines = FFsCGi(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFm5Au(self, BF(self.VV7Y9R, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF5DrN(self, path, title=FFPcSK())
   else:
    FFdzz0(self, path)
 def VV7Y9R(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVmobY = []
  VVmobY.append("echo -e 'Reading current settings ...'")
  VVmobY.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVmobY.append("echo -e 'Preparing new settings ...'")
  VVmobY.append(settingsLines)
  VVmobY.append("echo -e 'Applying new settings ...'")
  VVmobY.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FF3db0(self, VVmobY)
 def VV7RVN(self, VVW8faObj, path):
  if not path:
   return
  path = VVcqbj + path
  if not fileExists(path):
   FFdzz0(self, path)
   return
  txt = FFS3H9(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVJXpL  = []
   for item in satList:
    VVJXpL.append("%s\t%s" % (item[0], FF3aJg(item[1])))
   FFzNhe(self, VVJXpL, title="  Satellites List")
  else:
   FFNkji(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCYsEd(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVWp2B = []
  VVWp2B.append(("Plugins Browser List"       , "VVEzWn"   ))
  VVWp2B.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVWp2B.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVWp2B.append(("Remove Packages (show all)"     , "VVRgIvsAll"   ))
  VVWp2B.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Update List of Available Packages"   , "VVxMjv"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Packaging Tool"        , "VVLDP6"    ))
  VVWp2B.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF2wUT(self, VVWp2B=VVWp2B)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVEzWn"   : self.VVEzWn()
   elif item == "pluginsMenus"     : self.VVqlDl(0)
   elif item == "pluginsStartup"    : self.VVqlDl(1)
   elif item == "pluginsDirList"    : self.VV8Iqm()
   elif item == "downloadInstallPackages"  : FFOvQF(self, BF(self.VVS5qm, 0, ""))
   elif item == "VVRgIvsAll"   : FFOvQF(self, BF(self.VVS5qm, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFOvQF(self, BF(self.VVS5qm, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVxMjv"   : self.VVxMjv()
   elif item == "VVLDP6"    : self.VVLDP6()
   elif item == "packagesFeeds"    : self.VVPR1s()
   else          : self.close()
 def VV8Iqm(self):
  extDirs  = FFvbuz(VVubKs)
  sysDirs  = FFvbuz(VVkWLd)
  VVJXpL  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVJXpL.append((item, VVubKs + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVJXpL.append((item, VVkWLd + item))
  if VVJXpL:
   VVJXpL.sort(key=lambda x: x[0].lower())
   VVfzl8 = ("Package Info.", self.VVm4oc, [])
   VVL1b6 = ("Open in File Manager", BF(self.VVFysm, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFGcVX(self, None, header=header, VVJXpL=VVJXpL, VVQGhe=widths, VVlOla=28, VVfzl8=VVfzl8, VVL1b6=VVL1b6)
  else:
   FFNkji(self, "Nothing found!")
 def VVm4oc(self, VVMsCC, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVubKs) : loc = "extensions"
  elif path.startswith(VVkWLd) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VV7lqA(package)
  else:
   FFNkji(self, "No info!")
 def VVPR1s(self):
  pkg = FFc0wg()
  if pkg : FFxeLA(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFdMgN(self)
 def VVEzWn(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVZ1Gm(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVJ1qT + "\n"
    txt += VVZ1Gm("Number"   , str(c))
    txt += VVZ1Gm("Name"   , FFtSnl(str(p.name), VVxbdF))
    txt += VVZ1Gm("Path"  , p.path  )
    txt += VVZ1Gm("Description" , p.description )
    txt += VVZ1Gm("Icon"  , p.iconstr  )
    txt += VVZ1Gm("Wakeup Fnc" , p.wakeupfnc )
    txt += VVZ1Gm("NeedsRestart", p.needsRestart)
    txt += VVZ1Gm("Internal" , p.internal )
    txt += VVZ1Gm("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFzNhe(self, txt)
 def VVqlDl(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVJXpL = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVJXpL.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVJXpL:
   VVJXpL.sort(key=lambda x: x[0].lower())
   VVL1b6 = ("Open in File Manager", BF(self.VVFysm, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFGcVX(self, None, title=title, header=header, VVJXpL=VVJXpL, VVQGhe=widths, VVlOla=26, VVL1b6=VVL1b6)
  else:
   FFNkji(self, "Nothing Found", title=title)
 def VVFysm(self, pathColNum, VVMsCC, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CC0Jp1, mode=CC0Jp1.VVpslM, VV4wg8=path)
  else    : FFMnBb(VVMsCC, "Path not found !", 1500)
 def VVxMjv(self):
  cmd = FFU3rV(VV00Qq, "")
  if cmd : FF355v(self, cmd, checkNetAccess=True)
  else : FFdMgN(self)
 def VVLDP6(self):
  pkg = FFc0wg()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFO5iz(self, txt)
 def VVS5qm(self, mode, grep, VVMsCC=None, title=""):
  if   mode == 0: cmd = FFU3rV(VVIqCh    , grep)
  elif mode == 1: cmd = FFU3rV(VVX80U , grep)
  elif mode == 2: cmd = FFU3rV(VVX80U , grep)
  if not cmd:
   FFdMgN(self)
   return
  VVMGU8 = FF42E1(cmd)
  if not VVMGU8:
   if VVMsCC: VVMsCC.VVjUpN()
   FFNkji(self, "No packages found!")
   return
  elif len(VVMGU8) == 1 and VVMGU8[0] == VVq1UG:
   FFNkji(self, VVq1UG)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVJXpL  = []
  for item in VVMGU8:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVJXpL.append((name, package, version))
  if mode > 0:
   extensions = FF42E1("ls %s -l | grep '^d' | awk '{print $9}'" % VVubKs)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVJXpL:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVJXpL.append((name, VVubKs + item, "-"))
   systemPlugins = FF42E1("ls %s -l | grep '^d' | awk '{print $9}'" % VVkWLd)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVJXpL:
      if item.lower() == row[0].lower():
       break
     else:
      VVJXpL.append((item, VVkWLd + item, "-"))
  if not VVJXpL:
   FFNkji(self, "No packages found!")
   return
  if VVMsCC:
   VVJXpL.sort(key=lambda x: x[0].lower())
   VVMsCC.VVsLrn(VVJXpL, title)
  else:
   widths = (20, 50, 30)
   VV1NOm = None
   VVL1b6 = None
   if mode == 0:
    VV6i1u = ("Install" , self.VVUY7n   , [])
    VV1NOm = ("Download" , self.VVWRLf   , [])
    VVL1b6 = ("Filter"  , self.VVH3Ll , [])
   elif mode == 1:
    VV6i1u = ("Uninstall", self.VVRgIv, [])
   elif mode == 2:
    VV6i1u = ("Uninstall", self.VVRgIv, [])
    widths= (18, 57, 25)
   VVJXpL.sort(key=lambda x: x[0].lower())
   VVfzl8 = ("Package Info.", self.VV0hfJ, [])
   header   = ("Name" ,"Package" , "Version" )
   FFGcVX(self, None, header=header, VVJXpL=VVJXpL, VVQGhe=widths, VVlOla=28, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, VVhOBL=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVcV6s="#22110011", VV89EB="#22191111", VVHzNF="#22191111", VVhGFp="#00003030", VV3VgO="#00333333")
 def VV0hfJ(self, VVMsCC, title, txt, colList):
  package = colList[1]
  self.VV7lqA(package)
 def VVH3Ll(self, VVMsCC, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVWp2B = []
  VVWp2B.append(("All Packages", "all"))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVWp2B.append(VVEgY4)
  for word in words:
   VVWp2B.append((word, word))
  FFkkcl(self, BF(self.VV2P9c, VVMsCC), VVWp2B=VVWp2B, title="Select Filter")
 def VV2P9c(self, VVMsCC, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFOvQF(VVMsCC, BF(self.VVS5qm, 0, grep, VVMsCC, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVRgIv(self, VVMsCC, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVubKs, VVkWLd)):
   FFm5Au(self, BF(self.VV0iSr, VVMsCC, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVWp2B = []
   VVWp2B.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVWp2B.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVWp2B.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFkkcl(self, BF(self.VVUGfH, VVMsCC, package), VVWp2B=VVWp2B)
 def VV0iSr(self, VVMsCC, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV4Q9M)
  FF355v(self, cmd, VVyLAy=BF(self.VV4HxA, VVMsCC))
 def VVUGfH(self, VVMsCC, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVThwT
   elif item == "remove_ForceRemove"  : cmdOpt = VV7m8G
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVfrPk
   FFm5Au(self, BF(self.VVHSUs, VVMsCC, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVHSUs(self, VVMsCC, package, cmdOpt):
  self.lastSelectedRow = VVMsCC.VVeXGB()
  cmd = FFWksx(cmdOpt, package)
  if cmd : FF355v(self, cmd, VVyLAy=BF(self.VV4HxA, VVMsCC))
  else : FFdMgN(self)
 def VV4HxA(self, VVMsCC):
  VVMsCC.cancel()
  FFbhWc()
 def VVUY7n(self, VVMsCC, title, txt, colList):
  package  = colList[1]
  VVWp2B = []
  VVWp2B.append(("Install Package"         , "install_CheckVersion" ))
  VVWp2B.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVWp2B.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVWp2B.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVWp2B.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFkkcl(self, BF(self.VVDpuv, package), VVWp2B=VVWp2B)
 def VVDpuv(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVRzYh
   elif item == "install_ForceReinstall" : cmdOpt = VVXPbD
   elif item == "install_ForceOverwrite" : cmdOpt = VV6une
   elif item == "install_ForceDowngrade" : cmdOpt = VVoxQ2
   elif item == "install_IgnoreDepends" : cmdOpt = VVJxK8
   FFm5Au(self, BF(self.VVBH52, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVBH52(self, package, cmdOpt):
  cmd = FFWksx(cmdOpt, package)
  if cmd : FF355v(self, cmd, VVyLAy=FFbhWc, checkNetAccess=True)
  else : FFdMgN(self)
 def VVWRLf(self, VVMsCC, title, txt, colList):
  package  = colList[1]
  FFm5Au(self, BF(self.VVLDtn, package), "Download Package ?\n\n%s" % package)
 def VVLDtn(self, package):
  if FFqH9S():
   cmd = FFWksx(VVlZ5b, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF7gKg(success, VV41YE))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF7gKg(fail, VVG74s))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF355v(self, cmd, VV6nEO=[VVG74s, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFdMgN(self)
  else:
   FFNkji(self, "No internet connection !")
 def VV7lqA(self, package):
  infoCmd  = FFWksx(VVIObq, package)
  filesCmd = FFWksx(VV9BI1, package)
  listInstCmd = FFU3rV(VVX80U, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFygy9(VVxbdF)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF7gKg(notInst, VVpqRv))
   cmd += "else "
   cmd +=   FFy2ZV("System Info", VVxbdF)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFy2ZV("Related Files", VVxbdF)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFIhbm(self, cmd)
  else:
   FFdMgN(self)
class CCabmO(Screen):
 VVzidG  = 0
 VVipVd = 1
 VVR3Xl  = 2
 VVZdwy  = 3
 VVFSF3 = 4
 VVaZOM = 5
 VVzeWC = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVpBf1 = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVWp2B = self.VVagLV()
  FF2wUT(self, VVWp2B=VVWp2B, title="Services/Channels")
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self["myMenu"].setList(self.VVagLV())
  FFysS0(self["myMenu"])
  FFMyEE(self)
 def VVagLV(self):
  VVWp2B = []
  VVWp2B.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVWp2B.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVWp2B.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVWp2B.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVWp2B.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVWp2B.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVWp2B.append(("Services with PIcons for the System"  , "VVo5rm"     ))
  VVWp2B.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVWp2B.append(VVEgY4)
  VVPg8l, VV4kv4 = CCabmO.VVRNsy()
  if fileExists(VVPg8l):
   if fileExists(VV4kv4):
    VVWp2B.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVWp2B.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVWp2B.append(("Reset Parental Control Settings"   , "VV3fMF"    ))
  VVWp2B.append(("Delete Channels with no names"   , "VVe1m2"    ))
  VVWp2B.append(('Export Services to "channels.xml"'  , "VVmawI"      ))
  VVWp2B.append(("Reload Channels and Bouquets"    , "VV1gfS"      ))
  return VVWp2B
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFSj4o(self)
   elif item == "currentServiceInfo"     : FFRDSd(self, fncMode=CCGnOY.VVvPe7)
   elif item == "TranspondersStats"     : FFOvQF(self, self.VVhTmL     )
   elif item == "SatellitesXmlStats"     : FFOvQF(self, self.VVWzd0     )
   elif item == "lameDB_allChannels_with_refCode"  : FFOvQF(self, self.VVhemr )
   elif item == "lameDB_allChannels_with_tranaponder" : FFOvQF(self, self.VVQ902)
   elif item == "lameDB_allChannels_with_details"  : FFOvQF(self, self.VVa1Oa )
   elif item == "parentalControlChannels"    : FFOvQF(self, self.VVSrUh   )
   elif item == "showHiddenChannels"     : FFOvQF(self, self.VVZ5ps     )
   elif item == "VVo5rm"     : FFOvQF(self, self.VVSn70     )
   elif item == "servicesWithMissingPIcons"   : FFOvQF(self, self.VVTZcz   )
   elif item == "enableHiddenChannels"     : self.VVDk5y(True)
   elif item == "disableHiddenChannels"    : self.VVDk5y(False)
   elif item == "VV3fMF"    : FFm5Au(self, self.VV3fMF, "Reset and Restart ?" )
   elif item == "VVe1m2"    : FFOvQF(self, self.VVe1m2)
   elif item == "VVmawI"      : self.VVmawI()
   elif item == "VV1gfS"      : FFOvQF(self, BF(CCabmO.VV1gfS, self))
   else            : self.close()
 def VVmawI(self):
  VVWp2B = []
  VVWp2B.append(("All Sat/C/T Services", "all"))
  VVWp2B.extend(CC0dGf.VV1JB7())
  FFkkcl(self, self.VVozbI, VVWp2B=VVWp2B, title="", VV83XM=True)
 def VVozbI(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCabmO.VVxkb1("1:7:")
   else   : lst = FF1xYh(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFzd48(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFmwez(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFjGgP(CFG.exportedTablesPath.getValue()), FF03bo())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFO5iz(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFMnBb(self, "No Services found !", 1500)
 @staticmethod
 def VV1gfS(SELF):
  FFbWMQ()
  FFO5iz(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVhemr(self):
  self.VVpBf1 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCG8u1(self)
  VVMGU8, err = CCabmO.VVN2H3(self, self.VVzidG)
  if VVMGU8:
   VVMGU8.sort(key=lambda x: x[0].lower())
   VVBh0a  = ("Zap"   , self.VVP0jj     , [])
   VV9ZE5 = (""    , self.VVT3Z8   , [])
   VVfzl8 = ("Options"  , self.VVuQdZ , [])
   VV1NOm = ("Current Service", self.VVVlQN , [])
   VVL1b6 = ("Filter"   , self.VVXqaX  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVKrzB  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, lastFindConfigObj=CFG.lastFindServices)
 def VVQ902(self):
  self.VVpBf1 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCG8u1(self)
  VVMGU8, err = CCabmO.VVN2H3(self, self.VVipVd)
  if VVMGU8:
   VVMGU8.sort(key=lambda x: x[0].lower())
   VVBh0a  = ("Zap"   , self.VVP0jj      , [])
   VV9ZE5 = (""    , self.VVT3Z8    , [])
   VV1NOm = ("Current Service", self.VVVlQN  , [])
   VVfzl8 = ("Options"  , self.VVyKgA , [])
   VVL1b6 = ("Filter"   , self.VVmVei  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVKrzB  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, lastFindConfigObj=CFG.lastFindServices)
 def VVuQdZ(self, VVMsCC, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCiNIs(self, VVMsCC, 3)
  mSel.VVysX1(servName, refCode, pcState, hidState)
 def VVyKgA(self, VVMsCC, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCiNIs(self, VVMsCC, 3)
  mSel.VVLK10(servName, refCode)
 def VVpHnC(self, VVMsCC, refCode, isAddToBlackList):
  VVMsCC.VV9Ct6("Processing ...")
  FFrvtJ(BF(self.VVqrX6, VVMsCC, [refCode], isAddToBlackList))
 def VV9A84(self, VVMsCC, isAddToBlackList):
  refCodeList = VVMsCC.VVXWzY(3)
  if not refCodeList:
   FFNkji(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVMsCC.VV9Ct6("Processing ...")
  FFrvtJ(BF(self.VVqrX6, VVMsCC, refCodeList, isAddToBlackList))
 def VVqrX6(self, VVMsCC, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVC6WH, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVC6WH):
   lines = FFsCGi(VVC6WH)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVC6WH, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVMsCC.VVE8N3
   if isMulti:
    self.VVeqbj(VVMsCC, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVSfYX(VVMsCC, refCode)
    VVMsCC.VVjUpN()
  else:
   VVMsCC.VVQ7Zq("No changes")
 def VVimBZ(self, VVMsCC, refCode, isHide):
  title = "Change Hidden State"
  if FFG0HY(refCode):
   VVMsCC.VV9Ct6("Processing ...")
   ret = FFWbo4(refCode, isHide)
   if ret : FFOvQF(self, BF(self.VVSfYX, VVMsCC, refCode))
   else : FFNkji(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFNkji(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVSfYX(self, VVMsCC, refCode):
  VVMGU8, err = CCabmO.VVN2H3(self, self.VVzidG, VV3mN4=[3, [refCode], False])
  done = False
  if VVMGU8:
   data = VVMGU8[0]
   if data[3] == refCode:
    done = VVMsCC.VVNvto(data)
  if not done:
   self.VV3Gvn(VVMsCC, VVMsCC.VVEU20(), self.VVzidG)
  VVMsCC.VVjUpN()
 def VVeqbj(self, VVMsCC, totRefCodes):
  VVMGU8, err = CCabmO.VVN2H3(self, self.VVzidG, VV3mN4=self.VVpBf1)
  VVMsCC.VVsLrn(VVMGU8)
  VVMsCC.VVDdFZ(False)
  VVMsCC.VVQ7Zq("%d Processed" % totRefCodes)
 def VVWdvu(self, VVMsCC, isHide):
  refCodeList = VVMsCC.VVXWzY(3)
  if not refCodeList:
   FFNkji(self, "Nothing selected", title="Change Hidden State")
   return
  VVMsCC.VV9Ct6("Processing ...")
  FFrvtJ(BF(self.VVzgj4, VVMsCC, refCodeList, isHide))
 def VVzgj4(self, VVMsCC, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFWbo4(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVeqbj(VVMsCC, len(refCodeList))
  else:
   VVMsCC.VVQ7Zq("No changes")
 def VVXqaX(self, VVMsCC, title, txt, colList):
  inFilterFnc = BF(self.VVagkg, VVMsCC) if self.VVpBf1 else None
  self.filterObj.VVOLiE(1, VVMsCC, 2, BF(self.VVwZrS, VVMsCC), inFilterFnc=inFilterFnc)
 def VVwZrS(self, VVMsCC, item):
  self.VVBLhv(VVMsCC, False, item, 2, self.VVzidG)
 def VVagkg(self, VVMsCC, menuInstance, item):
  self.VVBLhv(VVMsCC, True, item, 2, self.VVzidG)
 def VVmVei(self, VVMsCC, title, txt, colList):
  inFilterFnc = BF(self.VVreMH, VVMsCC) if self.VVpBf1 else None
  self.filterObj.VVOLiE(2, VVMsCC, 4, BF(self.VVo6vd, VVMsCC), inFilterFnc=inFilterFnc)
 def VVo6vd(self, VVMsCC, item):
  self.VVBLhv(VVMsCC, False, item, 4, self.VVipVd)
 def VVreMH(self, VVMsCC, menuInstance, item):
  self.VVBLhv(VVMsCC, True, item, 4, self.VVipVd)
 def VVZnpL(self, VVMsCC, title, txt, colList):
  inFilterFnc = BF(self.VV38bG, VVMsCC) if self.VVpBf1 else None
  self.filterObj.VVOLiE(0, VVMsCC, 4, BF(self.VVU9D4, VVMsCC), inFilterFnc=inFilterFnc)
 def VVU9D4(self, VVMsCC, item):
  self.VVBLhv(VVMsCC, False, item, 4, self.VVR3Xl)
 def VV38bG(self, VVMsCC, menuInstance, item):
  self.VVBLhv(VVMsCC, True, item, 4, self.VVR3Xl)
 def VVBLhv(self, VVMsCC, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVMsCC.VVG5WS(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVpBf1 = None
  else:
   words, asPrefix = CCG8u1.VVStOm(words)
   self.VVpBf1 = [col, words, asPrefix]
  if words: FFOvQF(VVMsCC, BF(self.VV3Gvn, VVMsCC, title, mode), clearMsg=False)
  else : FFMnBb(VVMsCC, "Incorrect filter", 2000)
 def VV3Gvn(self, VVMsCC, title, mode):
  VVMGU8, err = CCabmO.VVN2H3(self, mode, VV3mN4=self.VVpBf1, VVBmG6=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVMsCC.VVy2g3():
    try:
     ndx = VVMGU8.index(tuple(list(map(str.strip, row))))
     lst.append(VVMGU8[ndx])
    except:
     pass
   VVMGU8 = lst
  if VVMGU8:
   VVMGU8.sort(key=lambda x: x[0].lower())
   VVMsCC.VVsLrn(VVMGU8, title)
  else:
   FFMnBb(VVMsCC, "Not found!", 1500)
 def VVsIkp(self, VVJXpL, VVBh0a=None, VV9ZE5=None, VV6i1u=None, VV1NOm=None, VVfzl8=None, VVL1b6=None):
  VV1NOm = ("Current Service", self.VVVlQN, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVKrzB = (LEFT  , LEFT  , CENTER, LEFT    )
  FFGcVX(self, None, header=header, VVJXpL=VVJXpL, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, lastFindConfigObj=CFG.lastFindServices)
 def VVVlQN(self, VVMsCC, title, txt, colList):
  self.VVuhy6(VVMsCC)
 def VVuifY(self, VVMsCC, title, txt, colList):
  self.VVuhy6(VVMsCC, True)
 def VVuhy6(self, VVMsCC, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVMsCC.VVrsh1(colDict, VVvNCa=True)
   else:
    VVMsCC.VV6kaZ(3, refCode, True)
   return
  FFNkji(self, "Colud not read current Reference Code !")
 def VVa1Oa(self):
  self.VVpBf1 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCG8u1(self)
  VVMGU8, err = CCabmO.VVN2H3(self, self.VVR3Xl)
  if VVMGU8:
   VVMGU8.sort(key=lambda x: x[0].lower())
   VV9ZE5 = (""    , self.VVUcYt , []      )
   VV1NOm = ("Current Service", self.VVuifY  , []      )
   VVL1b6 = ("Filter"   , self.VVZnpL   , [], "Loading Filters ..." )
   VVBh0a  = ("Zap"   , self.VVPL51      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVKrzB  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VV1NOm=VV1NOm, VVL1b6=VVL1b6, lastFindConfigObj=CFG.lastFindServices)
 def VVUcYt(self, VVMsCC, title, txt, colList):
  refCode  = self.VVcQI1(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFRDSd(self, fncMode=CCGnOY.VVx147, refCode=refCode, chName=chName, text=txt)
 def VVPL51(self, VVMsCC, title, txt, colList):
  refCode = self.VVcQI1(colList)
  FFQ5yd(self, refCode)
 def VVP0jj(self, VVMsCC, title, txt, colList):
  FFQ5yd(self, colList[3])
 def VVcQI1(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVN2H3(SELF, mode, VV3mN4=None, VVBmG6=True, VVkNHV=True):
  VVPg8l, err = CCabmO.VVD6fl(SELF, VVkNHV)
  if err:
   return None, err
  asPrefix = False
  if VV3mN4:
   filterCol = VV3mN4[0]
   filterWords = VV3mN4[1]
   asPrefix = VV3mN4[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCabmO.VVzidG:
   blackList = None
   if fileExists(VVC6WH):
    blackList = FFsCGi(VVC6WH)
    if blackList:
     blackList = set(blackList)
  elif mode == CCabmO.VVipVd:
   tp = CCW6PA()
  VVS8sI, VVT9kk = FFD0f0()
  tagFound  = False
  if mode in (CCabmO.VVaZOM, CCabmO.VVzeWC):
   VVMGU8 = {}
  else:
   VVMGU8 = []
  with ioOpen(VVPg8l, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFc8os(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCabmO.VVR3Xl:
       if sTypeInt in VVS8sI:
        STYPE = VVT9kk[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVMGU8.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVMGU8.append(tRow)
       else:
        VVMGU8.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCabmO.VVaZOM:
        VVMGU8[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCabmO.VVzeWC:
        VVMGU8[chName] = refCode
       elif mode == CCabmO.VVzidG:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVMGU8.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVMGU8.append(tRow)
        else:
         VVMGU8.append(tRow)
       elif mode == CCabmO.VVipVd:
        if sTypeInt in VVS8sI:
         STYPE = VVT9kk[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVxpjn(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVMGU8.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVMGU8.append(tRow)
        else:
         VVMGU8.append(tRow)
       elif mode == CCabmO.VVZdwy:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVMGU8.append((chName, chProv, sat, refCode))
       elif mode == CCabmO.VVFSF3:
        VVMGU8.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVMGU8 and VVBmG6:
   FFNkji(SELF, "No services found!")
  return VVMGU8, ""
 def VVSrUh(self):
  if fileExists(VVC6WH):
   lines = FFsCGi(VVC6WH)
   if lines:
    newRows = []
    VVMGU8, err = CCabmO.VVN2H3(self, self.VVFSF3)
    if VVMGU8:
     lines = set(lines)
     for item in VVMGU8:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVMGU8 = newRows
      VVMGU8.sort(key=lambda x: x[0].lower())
      VV9ZE5 = ("", self.VVT3Z8, [])
      VVBh0a = ("Zap", self.VVP0jj, [])
      self.VVsIkp(VVJXpL=VVMGU8, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5)
     else:
      FFzNhe(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVMGU8)))
   else:
    FFO5iz(self, "No active Parental Control services.", FFPcSK())
  else:
   FFdzz0(self, VVC6WH)
 def VVZ5ps(self):
  VVMGU8, err = CCabmO.VVN2H3(self, self.VVZdwy)
  if VVMGU8:
   VVMGU8.sort(key=lambda x: x[0].lower())
   VV9ZE5 = ("" , self.VVT3Z8, [])
   VVBh0a  = ("Zap", self.VVP0jj, [])
   self.VVsIkp(VVJXpL=VVMGU8, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5)
  elif err:
   pass
  else:
   FFO5iz(self, "No hidden services.", FFPcSK())
 def VVhTmL(self):
  VVPg8l, err = CCabmO.VVD6fl(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVksGS(VVPg8l)
  txt = FFtSnl("Total Transponders:\n\n", VVMXOB)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFtSnl("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVMXOB)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFhx4J(item), satList.count(item))
  FFzNhe(self, txt)
 def VVksGS(self, VVPg8l):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVPg8l, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVWzd0(self):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFdzz0(self, path)
   return
  elif not CC0Jp1.VVoodk(self, path, "satellites.xml"):
   return
  try:
   from xml.etree import ElementTree
   tree = ElementTree.parse(path)
  except Exception as e:
   FFNkji(self, "File Parsing Error:\n\n%s" % str(e))
   return
  VVMGU8 = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFc8os(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVMGU8.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVMGU8:
   VVMGU8.sort(key=lambda x: int(x[1]))
   VV1NOm = ("Current Satellite", self.VVn554 , [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = ( 36    , 7   , 0   , 10  , 7  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVKrzB  = ( LEFT  , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=25, VV1NOm=VV1NOm, lastFindConfigObj=CFG.lastFindTpStat)
  else:
   FFNkji(self, "No data found !")
 def VVn554(self, VVMsCC, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  sat = FFzd48(refCode, False)
  for ndx, row in enumerate(VVMsCC.VVy2g3()):
   if sat == row[2].strip():
    VVMsCC.VVtsKn(ndx)
    break
  else:
   FFMnBb(VVMsCC, "No listed !", 1500)
 def VVSn70(self)   : self.VVo5rm(True)
 def VVTZcz(self) : self.VVo5rm(False)
 def VVo5rm(self, isWithPIcons):
  piconsPath = CCgJhP.VVkis2()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCgJhP.VVxlTB(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVMGU8, err = CCabmO.VVN2H3(self, self.VVFSF3)
    if VVMGU8:
     channels = []
     for (chName, chProv, sat, refCode) in VVMGU8:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFE6fQ(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVMGU8)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVZ1Gm(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVZ1Gm("PIcons Path"  , piconsPath)
     txt += VVZ1Gm("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVZ1Gm("Total services" , totalServices)
     txt += VVZ1Gm("With PIcons"  , totalWithPIcons)
     txt += VVZ1Gm("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFzNhe(self, txt)
     else:
      VV9ZE5     = (""      , self.VVT3Z8 , [])
      if isWithPIcons : VVL1b6 = ("Export Current PIcon", self.VV0KkE  , [])
      else   : VVL1b6 = None
      VVfzl8     = ("Statistics", FFzNhe, [txt])
      VVBh0a      = ("Zap", self.VVP0jj, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVsIkp(VVJXpL=channels, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VVfzl8=VVfzl8, VVL1b6=VVL1b6)
   else:
    FFNkji(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFNkji(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVT3Z8(self, VVMsCC, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFRDSd(self, fncMode=CCGnOY.VVx147, refCode=refCode, chName=chName, text=txt)
 def VV0KkE(self, VVMsCC, title, txt, colList):
  png, path = CCgJhP.VVFfYi(colList[3], colList[0])
  if path:
   CCgJhP.VVEFxA(self, png, path)
 @staticmethod
 def VVRNsy():
  VVPg8l  = "/etc/enigma2/lamedb"
  VV4kv4 = "/etc/enigma2/lamedb.disabled"
  return VVPg8l, VV4kv4
 @staticmethod
 def VVAB9n():
  VVT8q3  = "/etc/enigma2/lamedb5"
  VVuNCO = "/etc/enigma2/lamedb5.disabled"
  return VVT8q3, VVuNCO
 def VVDk5y(self, isEnable):
  VVPg8l, VV4kv4 = CCabmO.VVRNsy()
  if isEnable and not fileExists(VV4kv4):
   FFO5iz(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVPg8l):
   FFNkji(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFm5Au(self, BF(self.VVnUiH, isEnable), "%s Hidden Channels ?" % word)
 def VVnUiH(self, isEnable):
  VVPg8l , VV4kv4 = CCabmO.VVRNsy()
  VVT8q3, VVuNCO = CCabmO.VVAB9n()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV4kv4, VV4kv4, VVPg8l)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVuNCO, VVuNCO, VVT8q3)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVPg8l  , VVPg8l , VV4kv4)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVT8q3 , VVT8q3, VVuNCO)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV4kv4, VVPg8l )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVuNCO, VVT8q3)
  res = os.system(cmd)
  FFbWMQ()
  if res == 0 : FFO5iz(self, "Hidden List %s" % word)
  else  : FFNkji(self, "Error while restoring:\n\n%s" % fileName)
 def VV3fMF(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FF3db0(self, cmd)
 def VVe1m2(self):
  VVPg8l, VV4kv4 = CCabmO.VVRNsy()
  if fileExists(VVPg8l):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFBSzC("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFsCGi(VVPg8l, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFBSzC("mv -f '%s' '%s'" % (tmpFile, VVPg8l)))
   FFbWMQ()
   FFzNhe(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFdzz0(self, VVPg8l)
 @staticmethod
 def VVD6fl(SELF, VVkNHV=True):
  VVPg8l, VV4kv4 = CCabmO.VVRNsy()
  if   not fileExists(VVPg8l)          : err = "File not found !\n\n%s" % VVPg8l
  elif not CC0Jp1.VVoodk(SELF, VVPg8l, "lamedb"): err = "'lamedb' file is not in 'UTF-8' Encoding !\n\n%s" % VVPg8l
  else                : err = ""
  if err and VVkNHV:
   FFNkji(SELF, err)
  return VVPg8l, err
 @staticmethod
 def VVxkb1(servTypes):
  VVCR76  = eServiceCenter.getInstance()
  VVnrRn   = '%s ORDER BY name' % servTypes
  VVXQZ7   = eServiceReference(VVnrRn)
  VVNl3w = VVCR76.list(VVXQZ7)
  if VVNl3w: return VVNl3w.getContent("CN", False)
  else     : return []
class CCGnOY(Screen):
 VVvPe7  = 0
 VVbhvp   = 1
 VV0ALq   = 2
 VVx147    = 3
 VVsjxB    = 4
 VVqTVj   = 5
 VVyEEB   = 6
 VV7EVt    = 7
 VVEc4k   = 8
 VV7yBK   = 9
 VVrx0L   = 10
 VVMsCz   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFbZTb(VVM7on, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVvPe7)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFtSnl("%s\n", VVAc0p) % VVJ1qT
  self.picViewer  = None
  FF2wUT(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVle8z })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self["myLabel"].VVVQK5(outputFileToSave="chann_info")
  if   self.fncMode == self.VVvPe7 : fnc = self.VVIM5X
  elif self.fncMode == self.VVbhvp  : fnc = self.VVIM5X
  elif self.fncMode == self.VV0ALq  : fnc = self.VVIM5X
  elif self.fncMode == self.VVx147  : fnc = self.VVPARY
  elif self.fncMode == self.VVsjxB  : fnc = self.VVZ7N3
  elif self.fncMode == self.VVqTVj  : fnc = self.VVXC4h
  elif self.fncMode == self.VVyEEB  : fnc = self.VVHBCg
  elif self.fncMode == self.VV7EVt  : fnc = self.VVk70R
  elif self.fncMode == self.VVEc4k  : fnc = self.VV6uct
  elif self.fncMode == self.VV7yBK : fnc = self.VVyJwM
  elif self.fncMode == self.VVrx0L  : fnc = self.VVeot5
  elif self.fncMode == self.VVMsCz : fnc = self.VVOB53
  self["myLabel"].setText("\n   Reading Info ...")
  FFrvtJ(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV5wXr()
 def VVoqUg(self, err):
  self["myLabel"].setText(err)
  FFQZ4f(self["myTitle"], "#22200000")
  FFQZ4f(self["myBody"], "#22200000")
  self["myLabel"].VVSdvO("#22200000")
  self["myLabel"].VVr1fk()
 def VVIM5X(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  self.refCode = refCode
  self.VV3IBr(chName)
 def VVPARY(self):
  self.VV3IBr(self.chName)
 def VVZ7N3(self):
  self.VV3IBr(self.chName)
 def VVXC4h(self):
  self.VV3IBr(self.chName)
 def VVHBCg(self):
  self.VV3IBr("Picon Info")
 def VVk70R(self):
  self.VV3IBr(self.chName)
 def VV6uct(self):
  self.VV3IBr(self.chName)
 def VVyJwM(self):
  self.VV3IBr(self.chName)
 def VVeot5(self):
  self.chUrl = self.refCode + self.callingSELF.VV6Rfu(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VV3IBr(self.chName)
 def VVOB53(self):
  self.VV3IBr(self.chName)
 def VV3IBr(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFxnns(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVMMoi(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFtSnl(self.VV7syA(tUrl), VVpi4Z)
  if not self.epg:
   epg = self.VV2Hzx(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVkbTJ(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCgJhP.VVFfYi(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVkbTJ(path)
  self.VVvTxx()
  self.VVonij()
  self["myLabel"].setText(self.text, VVwvtK=VVxPlb)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVr1fk(minHeight=minH)
 def VVonij(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFmwez(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVJq85(FFm5cy(url))
  if epg:
   self.text += "\n" + FFpGai("EPG:", VVFeau) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVvTxx()
 def VVvTxx(self):
  if not self.piconShown and self.picUrl:
   path, err = FFhNjK(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVkbTJ(path)
    if self.piconShown and self.refCode:
     self.VVsob9(path, self.refCode)
 def VVsob9(self, path, refCode):
  if path and fileExists(path) and os.system(FFBSzC("which ffmpeg")) == 0:
   pPath = CCgJhP.VVkis2()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCGnOY.VVW24u(path)
    cmd += FFBSzC("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVkbTJ(self, path):
  if path and fileExists(path):
   err, w, h = self.VVTbQH(path)
   if not err:
    if h > w:
     self.VVH6cR(self["myPicF"], w, h, True)
     self.VVH6cR(self["myPic"] , w, h, False)
   self.picViewer = CCjvta.VVyu70(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVH6cR(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVTbQH(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFrbAO(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVMMoi(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFtSnl(chName, VVFeau)
  txt += self.VVZ1Gm(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFtSnl(state, VVpqRv)
   txt += "State\t: %s\n" % state
  w = FFFiXK(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFFiXK(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVFTMM(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVZ1Gm(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVZ1Gm(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVZ1Gm(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVb2q1()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVF9dl()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCGnOY.VVaaZL(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFtSnl("IPTV", VVMXOB)
   txt += self.VVmtIT(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVXOBH(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCW6PA()
    tpTxt, namespace = tp.VV6UeG(refCode)
    if tpTxt:
     txt += FFtSnl("Tuner:\n", VVFeau)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFtSnl("Codes:\n", VVFeau)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVZ1Gm(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVZ1Gm(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVZ1Gm(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVZ1Gm(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVZ1Gm(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVZ1Gm(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVZ1Gm(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVZ1Gm(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVZ1Gm(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVFTMM(info):
  if info:
   aspect = FFFiXK(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVZ1Gm(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFFiXK(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVJUvr(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVJUvr(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVb2q1(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVF9dl(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVXOBH(self, refCode, iptvRef, chName):
  refCode = FFwmMJ(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFS3H9(VVSwef + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFS3H9(VVSwef + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVJXpL = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVSwef + item
   if fileExists(path):
    txt = FFS3H9(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVJXpL.append(bName)
  txt = self.Sep
  if VVJXpL:
   if len(VVJXpL) == 1:
    txt += "%s\t: %s\n" % (FFtSnl("Bouquet", VVFeau), VVJXpL[0])
   else:
    txt += FFtSnl("Bouquets:\n", VVFeau)
    for ndx, item in enumerate(VVJXpL):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV2Hzx(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVza1J(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVza1J(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVza1J(event, 0)
     except:
      pass
  return epg
 def VVza1J(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCGnOY.VVbRmx(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = CCGnOY.VVo1JI(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFtSnl(evName, VVFeau)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFtSnl(evNameTransl, VVFeau))
    if evTime           : txt += "Start Time\t: %s\n" % FFP6g0(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFP6g0(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFAdnL(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFAdnL(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFAdnL(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFtSnl(evShort, VV4mPL)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFtSnl(evDesc , VV4mPL)
    if txt:
     txt = FFtSnl("\n%s\n%s Event:\n%s\n" % (VVJ1qT, ("Current", "Next")[evNum], VVJ1qT), VVFeau) + txt
  return txt
 def VVmtIT(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FF2PL9(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCFpLh()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVO1mk(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFtSnl("URL:", VVMXOB) + "\n%s\n" % self.VV7syA(decodedUrl)
  else:
   txt = "\n"
   txt += FFtSnl("Reference:", VVMXOB) + "\n%s\n" % refCode
  return txt
 def VV7syA(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVv9Mc:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVJq85(self, decodedUrl):
  if not FFqH9S():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC5Be5.VVTRui(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC5Be5.VVsGVC(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVnleY(tDict)
   elif uType == "movie" : epg, picUrl = CCGnOY.VVRosH(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVnleY(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC5Be5.VVlB8q(item, "title"    , is_base64=True )
     lang    = CC5Be5.VVlB8q(item, "lang"         ).upper()
     description   = CC5Be5.VVlB8q(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC5Be5.VVlB8q(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC5Be5.VVlB8q(item, "start_timestamp"      )
     stop_timestamp  = CC5Be5.VVlB8q(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC5Be5.VVlB8q(item, "stop_timestamp"       )
     now_playing   = CC5Be5.VVlB8q(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVXldd, ""
      else     : color, txt = VVpqRv , "    (CURRENT EVENT)"
      epg += FFtSnl("_" * 32 + "\n", VVAc0p)
      epg += FFtSnl("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFtSnl(description, VVpi4Z)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVI9AV(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVRosH(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC5Be5.VVlB8q(item, "movie_image" )
    genre  = CC5Be5.VVlB8q(item, "genre"   ) or "-"
    plot  = CC5Be5.VVlB8q(item, "plot"   ) or "-"
    cast  = CC5Be5.VVlB8q(item, "cast"   ) or "-"
    rating  = CC5Be5.VVlB8q(item, "rating"   ) or "-"
    director = CC5Be5.VVlB8q(item, "director"  ) or "-"
    releasedate = CC5Be5.VVlB8q(item, "releasedate" ) or "-"
    duration = CC5Be5.VVlB8q(item, "duration"  ) or "-"
    try:
     lang = CC5Be5.VVlB8q(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFtSnl(cast, VVpi4Z)
    epg += "Plot:\n%s"    % FFtSnl(CCGnOY.VVo1JI(plot), VVpi4Z)
   except:
    pass
  return epg, movie_image
 @staticmethod
 def VVo1JI(evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = CCGnOY.VVPwQF(evTxt, lang)
   return CCGnOY.VVs6R8(txt).strip() or evTxt
 def VVle8z(self):
  if VVv9Mc:
   def VVZ1Gm(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVZ1Gm(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCFpLh()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVO1mk(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVZ1Gm(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVJ1qT, txt))
   FFMnBb(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVs6R8(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VViAPL(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCGnOY.VVbRmx(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVbRmx(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCGnOY.VV0a2s(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVBy9W(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     for evNum in range(2):
      event = eCache.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCGnOY.VVbRmx(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFP6g0(evTime)
       evEndTxt  = FFP6g0(evEnd)
       evDurTxt  = FFAdnL(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFAdnL(evPos)
        evRem = evEnd - now
        evRemTxt = FFAdnL(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFAdnL(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except Exception as e:
    pass
  return evLst
 @staticmethod
 def VVPwQF(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FF3nQE(txt))
   txt, err = CC5Be5.VVsGVC(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFm5cy(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVI9AV(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVOVFa(SELF):
  if not CCielb.VVhzF1(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(SELF)
  err = url =  fSize = resumable = ""
  if FFh3oH(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCFpLh.VVts0u(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCFpLh.VVaK2c(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFNkji(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC0Jp1.VVCLeS(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFtSnl(" (M3U/M3U8 File)", VVpi4Z)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCuF83.VVpc7B(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVQ9OX(subj, val):
   return "%s\n%s\n\n" % (FFtSnl("%s:" % subj, VVFeau), val)
  title = "File Size"
  txt  = VVQ9OX(title , fSize or "?")
  txt += VVQ9OX("Name" , chName)
  txt += VVQ9OX("URL" , url)
  if resumable: txt += VVQ9OX("Supports Download-Resume", resumable)
  if err  : txt += FFtSnl("Error:\n", VVpqRv) + err
  FFzNhe(SELF, txt, title=title)
 @staticmethod
 def VVaaZL(SELF):
  fPath, fDir, fName = CC0Jp1.VVtTvV(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VV0a2s(event):
  genre = PR = ""
  try:
   genre  = CCGnOY.VVGj1u(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCGnOY.VV7m9H(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VV7m9H(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVGj1u(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCGnOY.VV787K()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VV787K():
  path = VVE4he + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFS3H9(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFS3H9(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVW24u(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVNdv1(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCgJhP.VVkis2() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VV3Rhn(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFmwez(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    ns = FFEzDT(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  isDvb = any([isDvbT, isDvbC, isDvbS])
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCFpLh():
 def __init__(self):
  self.VVfW7f   = ""
  self.VVGOxv    = ""
  self.VV0aqY   = ""
  self.VVP7c2 = ""
  self.VVG6D3  = ""
  self.VVkASs = 0
  self.VVcnvi    = ""
  self.VVlrra   = "#f#11ffffaa#User"
  self.VVPeo6   = "#f#11aaffff#Server"
 def VVMV6v(self, url, mac, ph1="", VVvNCa=True):
  self.VVfW7f   = ""
  self.VVGOxv    = ""
  self.VV0aqY   = ""
  self.VVP7c2 = ""
  self.VVG6D3  = ""
  self.VVkASs = 0
  self.VVcnvi    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVUOkH(url)
  if not host:
   if VVvNCa:
    self.VVQDGO("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVa9uZ(mac)
  if not host:
   if VVvNCa:
    self.VVQDGO("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVfW7f = host
  self.VVGOxv  = mac
  return True
 def VVUOkH(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVa9uZ(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVsBwX(self):
  res, err = self.VV83RA(self.VV51yi())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVfW7f:
   self.VVfW7f = self.VVfW7f.replace(urlPath, "")
   res, err = self.VV83RA(self.VV51yi())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC5Be5.VVlB8q(tDict["js"], "token")
    rand  = CC5Be5.VVlB8q(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVDUPQ(self, VVvNCa=True):
  if not self.VVcnvi:
   self.VVcnvi = self.VVgeaA()
  err = blkMsg = FFO5izTxt = ""
  try:
   token, rand, err = self.VVsBwX()
   if token:
    self.VV0aqY = token
    self.VVP7c2 = rand
    if rand:
     self.VVkASs = 2
    prof, retTxt = self.VVWPnb(True)
    if prof:
     self.VVG6D3 = retTxt
     if "device_id mismatch" in retTxt:
      self.VVkASs = 3
      prof, retTxt = self.VVWPnb(False)
      if retTxt:
       self.VVG6D3 = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFO5izTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFO5izTxt: tErr += "\n%s" % FFO5izTxt
  if VVvNCa:
   self.VVQDGO(tErr)
  return "", "", tErr
 def VVgeaA(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVfW7f, headers=CCFpLh.VVaK2c(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVWPnb(self, capMac):
  res, err = self.VV83RA(self.VVSzD5(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC5Be5.VVlB8q(tDict["js"], "block_%s" % word)
    FFO5izTxt = CC5Be5.VVlB8q(tDict["js"], word)
    return tDict, FFO5izTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVSzD5(self, capMac):
  param = ""
  if self.VVG6D3 or self.VVP7c2:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVGOxv.upper() if capMac else self.VVGOxv.lower(), self.VVP7c2))
  return self.VV64PE() + "type=stb&action=get_profile" + param
 exec(FFdLhv("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gID0gIiZhdXRoX3NlY29uZF9zdGVwPTEmaHdfdmVyc2lvbj0yLjE3LUlCLTAwJmh3X3ZlcnNpb25fMj02MiZzbj0lcyZkZXZpY2VfaWQ9JXMmZGV2aWNlX2lkMj0lcyZzaWduYXR1cmU9JXMiICUgKElkWzBdLCBJZFsxXSwgSWRbMV0sIElkWzJdKQ0KIHJldHVybiBwYXJhbSArICcmbWV0cmljcz17Im1hYyI6IiVzIiwic24iOiIlcyIsInR5cGUiOiJTVEIiLCJtb2RlbCI6Ik1BRzI1MCIsInJhbmRvbSI6IiVzIn0nICUgKElkWzNdLCBJZFswXSwgSWRbNF0pDQpkZWYgZ2V0TW9yZUF1dGhfSURzKHNlbGYsIG0sIHIpOg0KIGltcG9ydCBoYXNobGliDQogbWFjVXRmOCA9IG0uZW5jb2RlKCd1dGYtOCcpDQogcyA9IGhhc2hsaWIubWQ1KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKClbOjEzXQ0KIHJldHVybiBzLCBoYXNobGliLnNoYTI1NihtYWNVdGY4KS5oZXhkaWdlc3QoKS51cHBlcigpLCBoYXNobGliLnNoYTI1NigocyArIG0pLmVuY29kZSgndXRmLTgnKSkuaGV4ZGlnZXN0KCkudXBwZXIoKSwgbSwgcg=="))
 def VVH5HJ(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV1d0I()
  if len(rows) < 10:
   rows = self.VVyEgo()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVfW7f ))
   rows.append(("MAC (from URL)" , self.VVGOxv ))
   rows.append(("Token"   , self.VV0aqY ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVlrra  , "MAC" , self.VVGOxv ))
   rows.append(("2", self.VVPeo6, "Host" , self.VVfW7f ))
   rows.append(("2", self.VVPeo6, "Token" , self.VV0aqY ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVQIqp(self, isPhp=True, VVvNCa=False):
  token, profile, tErr = self.VVDUPQ(VVvNCa)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVY2Tk()
  res, err = self.VV83RA(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC5Be5.VVlB8q(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FF3nQE(span.group(2))
     pass1 = FF3nQE(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV1d0I(self):
  m3u_Url, host, user1, pass1, err = self.VVQIqp()
  rows = []
  if m3u_Url:
   res, err = self.VV83RA(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFP6g0(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVlrra, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFP6g0(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVPeo6, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVyEgo(self):
  token, profile, tErr = self.VVDUPQ()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFss9S(val): val = FFdLhv(val.decode("UTF-8"))
     else     : val = self.VVGOxv
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFP6g0(int(parts[1]))
      if parts[2] : ends = FFP6g0(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFP6g0(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VV6Rfu(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVDUPQ(VVvNCa=False)
  if not token:
   return ""
  crLinkUrl = self.VVEsY3(mode, chCm, epNum, epId)
  res, err = self.VV83RA(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC5Be5.VVlB8q(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV64PE(self):
  return self.VVfW7f + (self.VVcnvi or "/server/load.php") + "?"
 def VV51yi(self):
  return self.VV64PE() + "type=stb&action=handshake&token=&mac=%s" % self.VVGOxv
 def VVDbdy(self, mode):
  url = self.VV64PE() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV7ohA(self, catID):
  return self.VV64PE() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVkRLG(self, mode, catID, page):
  url = self.VV64PE() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VV5RfO(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV64PE() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVti24(self, mode, catID):
  return self.VV64PE() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVEsY3(self, mode, chCm, serCode, serId):
  url = self.VV64PE() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVY2Tk(self):
  return self.VV64PE() + "type=itv&action=create_link"
 def VV0fot(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVW8Zc(catID, stID, chNum)
  query = self.VV9b41(mode, self.VVcnvi[1:2], FFDENy(host), FFDENy(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV9b41(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVO1mk(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV9b41(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFdLhv(host)
  mac   = FFdLhv(mac)
  valid = False
  if self.VVUOkH(playHost) and self.VVUOkH(host) and self.VVUOkH(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV83RA(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCFpLh.VVaK2c()
   if self.VV0aqY:
    headers["Authorization"] = "Bearer %s" % self.VV0aqY
   if useCookies : cookies = {"mac": self.VVGOxv, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok :
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVdePF(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCFpLh.VVaK2c(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVaK2c():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVlYbu(host, mac, tType, action, keysList=[]):
  myPortal = CCFpLh()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVMV6v(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVDUPQ(VVvNCa=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VV83RA(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVlSLt(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVlSLt(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVQDGO(self, err, title="Portal Browser"):
  FFNkji(self, str(err), title=title)
 def VVCAIT(self, mode):
  if   mode in ("itv"  , CC5Be5.VVPpHH , CC5Be5.VVQYMA)  : return "Live"
  elif mode in ("vod"  , CC5Be5.VVMzCK , CC5Be5.VVVDBH)  : return "VOD"
  elif mode in ("series" , CC5Be5.VVFitc , CC5Be5.VVobfF) : return "Series"
  else                          : return "IPTV"
 def VVcF6a(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVCAIT(mode), searchName)
 def VVni84(self, catchup=False):
  VVWp2B = []
  VVWp2B.append(("Live"    , "live"  ))
  VVWp2B.append(("VOD"    , "vod"   ))
  VVWp2B.append(("Series"   , "series"  ))
  if catchup:
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Catchup TV" , "catchup"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Account Info." , "accountInfo" ))
  return VVWp2B
 @staticmethod
 def VVLS7h(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCFpLh()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVO1mk(decodedUrl)
  if valid:
   ok = p.VVMV6v(host, mac, ph1, VVvNCa=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVQIqp(isPhp=False, VVvNCa=False)
    streamId = CCFpLh.VVr42Z(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVr42Z(decodedUrl):
  p = CCFpLh()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVO1mk(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFdLhv(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVts0u(decodedUrl):
  p = CCFpLh()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVO1mk(decodedUrl)
  if valid:
   if CCFpLh.VVk4GJ(chCm):
    return FFm5cy(chCm)
   else:
    ok = p.VVMV6v(host, mac, ph1, VVvNCa=False)
    if ok:
     try:
      chUrl = p.VV6Rfu(mode, chCm, epNum, epId)
      return FFm5cy(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVk4GJ(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCl3K2(CCFpLh):
 def __init__(self):
  CCFpLh.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVfDCP(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVO1mk(decodedUrl)
  if valid:
   if self.VVMV6v(host, mac, ph1, VVvNCa=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVjSec(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VV6Rfu(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCFpLh.VVk4GJ(self.chCm):
   chUrl = FFm5cy(self.chCm)
   chUrl = FF3nQE(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVeG48(chUrl)
  if newIptvRef:
   success = self.VVOqdF(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFQ5yd(passedSELF, newIptvRef, VVz7YZ=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFQ5yd(self, newIptvRef, VVz7YZ=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVeG48(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVOqdF(self, oldCode, newCode, isDirect):
  bPath = CC0dGf.VV5Y0k()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FFsCGi(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFbWMQ()
       return True
   else:
    txt = FFS3H9(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFbWMQ()
     return True
  return False
class CCleqq(CCl3K2):
 def __init__(self, passedSession):
  CCl3K2.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVmoKR, iPlayableService.evEOF: self.VVVKlP, iPlayableService.evEnd: self.VV1dh4})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVuVN9)
  except:
   self.timer2.callback.append(self.VVuVN9)
  self.timer2.start(3000, False)
  self.VVuVN9()
 def VVuVN9(self):
  if not CFG.downloadMonitor.getValue():
   self.VV5TwA()
   return
  lst = CCuF83.VVdQvs()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFHaPS(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCuF83.VVlEDP(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCbihD, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFZmKs(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VV5TwA()
 def VV5TwA(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVmoKR(self):
  self.startTime = iTime()
 def VVVKlP(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self.passedSession, isFromSession=True)
    if iptvRef and not FFh3oH(decodedUrl):
     self.isFromEOF = True
     CCzuW4(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VV1dh4(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVk0mJ)
  except:
   self.timer1.callback.append(self.VVk0mJ)
  self.timer1.start(100, True)
 def VVk0mJ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVfDCP(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCZilb.VV5SmK:
       self.isFromEOF = False
       self.VVjSec(self.passedSession, isFromSession=True)
class CCvNDE():
 def __init__(self):
  self.missingUtf8 = VVqWYD and not VVgzsn
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z0-9]+\s*\|*[|:-]\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][A-z0-9\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVFRrn(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC5Be5.VVtCRr(name):
   return CC5Be5.VVobwP(name)
  name = self.VVfPEi(name)
  return name.strip() or name
 def VVfPEi(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2)
  return name
 def VV4Nkx(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVfPEi(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV6Q9i(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VV7AR0(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVuZVs(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCielb(CCFpLh):
 def __init__(self):
  CCFpLh.__init__(self)
 def VVSSNS(self):
  if CCielb.VVhzF1(self):
   FFOvQF(self, self.VVe44X, title="Searching ...")
 def VV2fEc(self, winSession, url, mac):
  if CCielb.VVhzF1(self):
   if self.VVMV6v(url, mac):
    FFOvQF(winSession, self.VVQm5W, title="Checking Server ...")
   else:
    FFNkji(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVe44X(self):
  lines = self.VVPw9t(2)
  if lines:
   lines.sort()
   VVWp2B = []
   for line in lines:
    VVWp2B.append((line, line))
   OKBtnFnc  = self.VVsaqB
   VVBc7a = ("Delete File", self.VVkNMq)
   FFkkcl(self, None, title="Select Portals File", VVWp2B=VVWp2B, width=1200, OKBtnFnc=OKBtnFnc, VVBc7a=VVBc7a)
 def VVkNMq(self, VVW8faObj, path):
  FFm5Au(self, BF(self.VVhUO1, VVW8faObj, path), "Delete this file ?\n\n%s" % path)
 def VVhUO1(self, VVW8faObj, path):
  os.system(FFBSzC("rm -f '%s'" % path))
  if fileExists(path) : FFMnBb(VVW8faObj, "Not deleted", 1000)
  else    : VVW8faObj.VV5ZmU()
 def VVsaqB(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCF2zZ.VVNH6s(path, self)
   if enc == -1:
    return
   self.session.open(CC4A0C, barTheme=CC4A0C.VVo57g
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVwu5u, path, enc)
       , VVJcVO = BF(self.VVYdit, menuInstance, path))
 def VVwu5u(self, path, enc, VVbrNS):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVbrNS.VVdoFu(totLines)
  VVbrNS.VV4mwj = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVbrNS or VVbrNS.isCancelled:
     return
    VVbrNS.VV0CXi(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVUOkH(url)
     mac  = self.VVa9uZ(mac)
     if host and mac and VVbrNS:
      VVbrNS.VV4mwj.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVUOkH(url)
      mac  = self.VVa9uZ(mac)
      if host and mac and not mac.startswith("AC") and VVbrNS:
       VVbrNS.VV4mwj.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVYdit(self, menuInstance, path, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VV4mwj:
   VV6i1u  = ("Home Menu"  , FFDRAB            , [])
   VVfzl8 = ("Edit File"  , BF(self.VVG1eh, path)       , [])
   VV1NOm = ("M3U Options" , self.VV5FPy         , [])
   VVL1b6 = ("Check & Filter" , BF(self.VVXVdE, menuInstance, path), [])
   VVBh0a  = ("Select"   , self.VVS5DV      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVKrzB  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVMsCC = FFGcVX(self, None, title=title, header=header, VVJXpL=VV4mwj, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, VVcV6s="#0a001122", VV89EB="#0a001122", VVHzNF="#0a001122", VVhGFp="#00004455", VV3VgO="#0a333333", VVGPak="#11331100", VVLHme=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVTgbE:
    FFMnBb(VVMsCC, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVTgbE:
    FFNkji(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV5FPy(self, VVMsCC, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVWp2B = []
  VVWp2B.append(("Browse as M3U"  , "browse"))
  VVWp2B.append(("Download M3U File" , "downld"))
  FFkkcl(self, BF(self.VVjkzr, VVMsCC, host, mac), title=title, VVWp2B=VVWp2B, width=600, VV83XM=True)
 def VVjkzr(self, VVMsCC, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFOvQF(VVMsCC, BF(self.VVmDP8, VVMsCC, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFm5Au(self, BF(FFOvQF, VVMsCC, BF(self.VVmDP8, VVMsCC, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVmDP8(self, VVMsCC, title, host, mac, item):
  p = CCFpLh()
  m3u_Url = ""
  ok = p.VVMV6v(host, mac, VVvNCa=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVQIqp(VVvNCa=False)
  if m3u_Url:
   if   item == "browse": self.VVRxnh(title, m3u_Url)
   elif item == "downld": self.VVSFML(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFNkji(self, err or "No response from Server !", title=title)
 def VVS5DV(self, VVMsCC, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV2fEc(VVMsCC, url, mac)
 def VVG1eh(self, path, VVMsCC, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC6mSu(self, path, VVJcVO=BF(self.VVLjPk, VVMsCC), curRowNum=rowNum)
  else    : FFdzz0(self, path)
 def VVXVdE(self, menuInstance, path, VVMsCC, title, txt, colList):
  self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVJk5a, VVMsCC)
      , VVJcVO = BF(self.VV5OUs, menuInstance, VVMsCC, path))
 def VVJk5a(self, VVMsCC, VVbrNS):
  VVbrNS.VV4mwj = []
  VVbrNS.VVdoFu(VVMsCC.VVPmHc())
  for row in VVMsCC.VVy2g3():
   if not VVbrNS or VVbrNS.isCancelled:
    return
   VVbrNS.VV0CXi(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVMV6v(host, mac, VVvNCa=False):
    token, profile, tErr = self.VVDUPQ(VVvNCa=False)
    if token and VVbrNS and not VVbrNS.isCancelled:
     res, err = self.VV83RA(self.VVDbdy("itv"))
     if res and VVbrNS and not VVbrNS.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVbrNS.VV0CXi(0, showFound=True)
       VVbrNS.VV4mwj.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVbrNS:
    return
 def VV5OUs(self, menuInstance, VVMsCC, path, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if VV4mwj:
   VVMsCC.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FF03bo())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VV4mwj:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFtSnl(str(threadCounter), VVpqRv)
    skipped = FFtSnl(str(threadTotal - threadCounter), VVpqRv)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VV4mwj)
   txt += "%s\n\n%s"    %  (FFtSnl("Result File:", VVFeau), newPath)
   FFzNhe(self, txt, title="Accessible Portals")
  elif VVTgbE:
   FFNkji(self, "No portal access found !", title="Accessible Portals")
 def VVSphi(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFdLhv(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVQm5W(self):
  token, profile, tErr = self.VVDUPQ()
  if token:
   dots = "." * self.VVkASs
   dots += "+" if self.VVcnvi[1:2] == "p" else ""
   VVWp2B  = self.VVni84()
   OKBtnFnc = self.VVj6nI
   VVaTfU = ("Home Menu", FFDRAB)
   VVK0co = ("Bookmark Server", BF(CC5Be5.VVQyOy, self, True, self.VVfW7f + "\t" + self.VVGOxv))
   FFkkcl(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVGOxv, dots), VVWp2B=VVWp2B, OKBtnFnc=OKBtnFnc, VVaTfU=VVaTfU, VVK0co=VVK0co)
 def VVj6nI(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFOvQF(menuInstance, BF(self.VVXI0G, mode), title="Reading Categories ...")
   else : FFOvQF(menuInstance, BF(self.VVx1UQ, menuInstance, title), title="Reading Account ...")
 def VVx1UQ(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVH5HJ(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVGOxv)
  VV6i1u  = ("Home Menu" , FFDRAB         , [])
  VV1NOm  = None
  if VVYACA:
   VV1NOm = ("Get JS"  , BF(self.VVeL5W, self.VVfW7f), [])
  if totCols == 2:
   VVL1b6 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVL1b6 = ("More Info.", BF(self.VVdYHt, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFGcVX(self, None, title=title, width=1200, header=header, VVJXpL=rows, VVQGhe=widths, VVlOla=26, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVL1b6=VVL1b6, VVcV6s="#0a00292B", VV89EB="#0a002126", VVHzNF="#0a002126", VVhGFp="#00000000", searchCol=searchCol)
 def VVeL5W(self, url, VVMsCC, title, txt, colList):
  FFOvQF(VVMsCC, BF(self.VVdaeM, url), title="Getting JS ...")
 def VVdaeM(self, url):
  txt = "// Host\t: %s\n" % url
  verOK = False
  ver, err = self.VVKOU6("%s/c/version.js" % url)
  if err:
   txt += err
  else:
   txt += "// Version\t: %s\n\n" % ver
   js, err = self.VVKOU6("%s/c/xpcom.common.js" % url)
   if err: txt += err
   else  : txt += "%s" % js
  FFzNhe(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVKOU6(self, url):
  res, err = self.VV83RA(url)
  if err:
   return "", "Error: %s" % err
  else:
   cont = res.headers.get("content-type")
   if "javascript" in cont : return res.text, ""
   else     : return "", "\nError: content-type = %s" % cont
 def VVdYHt(self, menuInstance, VVMsCC, title, txt, colList):
  VVMsCC.cancel()
  FFOvQF(menuInstance, BF(self.VVx1UQ, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVXI0G(self, mode):
  token, profile, tErr = self.VVDUPQ()
  if not token:
   return
  res, err = self.VV83RA(self.VVDbdy(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVKieG = CCvNDE()
     chList = tDict["js"]
     for item in chList:
      Id   = CC5Be5.VVlB8q(item, "id"       )
      Title  = CC5Be5.VVlB8q(item, "title"      )
      censored = CC5Be5.VVlB8q(item, "censored"     )
      Title = VVKieG.VV6Q9i(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVYACA:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVCAIT(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4(mode)
   mName = self.VVCAIT(mode)
   VVBh0a   = ("Show List"   , BF(self.VVnO21, mode)   , [])
   VV6i1u  = ("Home Menu"   , FFDRAB        , [])
   if mode in ("vod", "series"):
    VVfzl8 = ("Find in %s" % mName , BF(self.VV2Oo3, mode, False), [])
    VVL1b6 = ("Find in Selected" , BF(self.VV2Oo3, mode, True) , [])
   else:
    VVfzl8 = None
    VVL1b6 = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFGcVX(self, None, title=title, width=1200, header=header, VVJXpL=list, VVQGhe=widths, VVlOla=30, VV6i1u=VV6i1u, VVfzl8=VVfzl8, VVL1b6=VVL1b6, VVBh0a=VVBh0a, VVcV6s=VVcV6s, VV89EB=VV89EB, VVHzNF=VVHzNF, VVhGFp=VVhGFp, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVG6D3:
     txt += "\n\n( %s )" % self.VVG6D3
   else:
    txt = "Could not get Categories from server!"
   FFNkji(self, txt, title=title)
 def VVie5d(self, mode, VVMsCC, title, txt, colList):
  FFOvQF(VVMsCC, BF(self.VV3kNK, mode, VVMsCC, title, txt, colList), title="Downloading ...")
 def VV3kNK(self, mode, VVMsCC, title, txt, colList):
  token, profile, tErr = self.VVDUPQ()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV83RA(self.VV7ohA(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CC5Be5.VVlB8q(item, "id"    )
      actors   = CC5Be5.VVlB8q(item, "actors"   )
      added   = CC5Be5.VVlB8q(item, "added"   )
      age    = CC5Be5.VVlB8q(item, "age"   )
      category_id  = CC5Be5.VVlB8q(item, "category_id" )
      description  = CC5Be5.VVlB8q(item, "description" )
      director  = CC5Be5.VVlB8q(item, "director"  )
      genres_str  = CC5Be5.VVlB8q(item, "genres_str"  )
      name   = CC5Be5.VVlB8q(item, "name"   )
      path   = CC5Be5.VVlB8q(item, "path"   )
      screenshot_uri = CC5Be5.VVlB8q(item, "screenshot_uri" )
      series   = CC5Be5.VVlB8q(item, "series"   )
      cmd    = CC5Be5.VVlB8q(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVBh0a  = ("Play"    , BF(self.VVEu6l, mode)       , [])
   VV9ZE5 = (""     , BF(self.VViVTF, mode)     , [])
   VV6i1u = ("Home Menu"   , FFDRAB            , [])
   VV1NOm = ("Download Options" , BF(self.VV1wZQ, mode, "sp", seriesName) , [])
   VVfzl8 = ("Options"   , BF(self.VVNwuk, 0, "pEp", mode, seriesName), [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVKrzB  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFGcVX(self, None, title=seriesName, width=1200, header=header, VVJXpL=list, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, lastFindConfigObj=CFG.lastFindIptv, VVcV6s="#0a00292B", VV89EB="#0a002126", VVHzNF="#0a002126", VVhGFp="#00000000")
  else:
   FFNkji(self, "Could not get Episodes from server!", title=seriesName)
 def VV2Oo3(self, mode, searchInCat, VVMsCC, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVWp2B = []
  VVWp2B.append(("Keyboard"  , "manualEntry"))
  VVWp2B.append(("From Filter" , "fromFilter"))
  FFkkcl(self, BF(self.VVol05, VVMsCC, mode, searchCatId), title="Input Type", VVWp2B=VVWp2B, width=400)
 def VVol05(self, VVMsCC, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFhzot(self, BF(self.VVZvCj, VVMsCC, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCG8u1(self)
    filterObj.VVYsxj(BF(self.VVZvCj, VVMsCC, mode, searchCatId))
 def VVZvCj(self, VVMsCC, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   self.VVLN7n(searchName)
   title = self.VVcF6a(mode, searchName)
   if "," in searchName : FFNkji(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFNkji(self, "Enter at least 3 characters.", title=title)
   else     :
    VVKieG = CCvNDE()
    if CFG.hideIptvServerAdultWords.getValue() and VVKieG.VV7AR0([searchName]):
     FFNkji(self, VVKieG.VVuZVs(), title=title)
    else:
     self.VVqVu6(mode, searchName, "", searchName, searchCatId)
 def VVnO21(self, mode, VVMsCC, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVqVu6(mode, bName, catID, "", "")
 def VVqVu6(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CC4A0C, barTheme=CC4A0C.VVo57g
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVMASz, mode, bName, catID, searchName, searchCatId)
      , VVJcVO = BF(self.VVwzKh, mode, bName, catID, searchName, searchCatId))
 def VVwzKh(self, mode, bName, catID, searchName, searchCatId, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVcF6a(mode, searchName)
  else   : title = "%s : %s" % (self.VVCAIT(mode), bName)
  if VV4mwj:
   VV1NOm = None
   VVfzl8 = None
   if mode == "series":
    VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4("series2")
    VVBh0a  = ("Episodes"   , BF(self.VVie5d, mode)           , [])
   else:
    VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4("")
    VVBh0a  = ("Play"    , BF(self.VVEu6l, mode)           , [])
    VV1NOm = ("Download Options" , BF(self.VV1wZQ, mode, "vp" if mode == "vod" else "", "") , [])
    VVfzl8 = ("Options"   , BF(self.VVNwuk, 1, "pCh", mode, bName)      , [])
   VV9ZE5 = (""      , BF(self.VVAho7, mode)         , [])
   VV6i1u = ("Home Menu"    , FFDRAB                , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" )
   widths   = (10  , 65  , 0   , 0     , 0  , 0  , 25    )
   VVKrzB  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    )
   VVMsCC = FFGcVX(self, None, title=title, header=header, VVJXpL=VV4mwj, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, lastFindConfigObj=CFG.lastFindIptv, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VVcV6s=VVcV6s, VV89EB=VV89EB, VVHzNF=VVHzNF, VVhGFp=VVhGFp, VVLHme=True, searchCol=1)
   if not VVTgbE:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVMsCC.VVb9yH(VVMsCC.VVEU20() + tot)
    if threadErr: FFMnBb(VVMsCC, "Error while reading !", 2000)
    else  : FFMnBb(VVMsCC, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFNkji(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFNkji(self, "Could not get list from server !", title=title)
 def VVAho7(self, mode, VVMsCC, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFRDSd(self, fncMode=CCGnOY.VVMsCz, portalHost=self.VVfW7f, portalMac=self.VVGOxv, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVtpqb(mode, VVMsCC, title, txt, colList)
 def VViVTF(self, mode, VVMsCC, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFtSnl(colList[10], VVpi4Z)
  txt += "Description:\n%s" % FFtSnl(colList[11], VVpi4Z)
  self.VVtpqb(mode, VVMsCC, title, txt, colList)
 def VVtpqb(self, mode, VVMsCC, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVfYMl(mode, colList)
  refCode, chUrl = self.VV0fot(self.VVfW7f, self.VVGOxv, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFRDSd(self, fncMode=CCGnOY.VVrx0L, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVMASz(self, mode, bName, catID, searchName, searchCatId, VVbrNS):
  try:
   token, profile, tErr = self.VVDUPQ()
   if not token:
    return
   if VVbrNS.isCancelled:
    return
   VVbrNS.VV4mwj, total_items, max_page_items, err = self.VVe0XJ(mode, catID, 1, 1, searchName, searchCatId)
   if VVbrNS.isCancelled:
    return
   if VVbrNS.VV4mwj and total_items > -1 and max_page_items > -1:
    VVbrNS.VVdoFu(total_items)
    VVbrNS.VV0CXi(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVbrNS.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVe0XJ(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVbrNS.VVgK2m()
     if VVbrNS.isCancelled:
      return
     if list:
      VVbrNS.VV4mwj += list
      VVbrNS.VV0CXi(len(list), True)
  except:
   pass
 def VVe0XJ(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VV5RfO(mode, searchName, searchCatId, page)
  else   : url = self.VVkRLG(mode, catID, page)
  res, err = self.VV83RA(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVzDir(CC5Be5.VVlB8q(item, "total_items" ))
     max_page_items = self.VVzDir(CC5Be5.VVlB8q(item, "max_page_items" ))
     VVKieG = CCvNDE()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC5Be5.VVlB8q(item, "id"    )
      name   = CC5Be5.VVlB8q(item, "name"   )
      o_name   = CC5Be5.VVlB8q(item, "o_name"   )
      tv_genre_id  = CC5Be5.VVlB8q(item, "tv_genre_id" )
      number   = CC5Be5.VVlB8q(item, "number"   ) or str(counter)
      logo   = CC5Be5.VVlB8q(item, "logo"   )
      screenshot_uri = CC5Be5.VVlB8q(item, "screenshot_uri" )
      cmd    = CC5Be5.VVlB8q(item, "cmd"   )
      censored  = CC5Be5.VVlB8q(item, "censored"  )
      genres_str  = CC5Be5.VVlB8q(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVfW7f + picon).replace(sp * 2, sp)
      counter += 1
      name = VVKieG.VVFRrn(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVzDir(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVEu6l(self, mode, VVMsCC, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVfYMl(mode, colList)
  refCode, chUrl = self.VV0fot(self.VVfW7f, self.VVGOxv, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVtCRr(chName):
   FFMnBb(VVMsCC, "This is a marker!", 300)
  else:
   FFOvQF(VVMsCC, BF(self.VVJB0K, mode, VVMsCC, chUrl), title="Playing ...")
 def VVJB0K(self, mode, VVMsCC, chUrl):
  FFQ5yd(self, chUrl, VVz7YZ=False)
  self.session.open(CCZilb, portalTableParam=(self, VVMsCC, mode))
 def VVoL9e(self, mode, VVMsCC, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVfYMl(mode, colList)
  refCode, chUrl = self.VV0fot(self.VVfW7f, self.VVGOxv, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVfYMl(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVhzF1(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVWp2B = []
   VVWp2B.append((title        , "inst" ))
   VVWp2B.append(("Update Packages then %s" % title , "updInst" ))
   FFkkcl(SELF, BF(CCielb.VVtxiT, SELF), title='This requires Python "Requests" library', VVWp2B=VVWp2B)
   return False
 @staticmethod
 def VVtxiT(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFU3rV(VV00Qq, "")
   if cmdUpd:
    cmdInst = FFWksx(VVRzYh, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF355v(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FFdMgN(SELF)
class CC5Be5(Screen, CCielb):
 VVKFxs    = 0
 VVd7Mo    = 1
 VVoFWp    = 2
 VVQprV    = 3
 VVgdkk     = 4
 VVMUuA     = 5
 VVHppG     = 6
 VV1z36     = 7
 VVfyAf     = 8
 VVguyI      = 9
 VVdBbB     = 10
 VVilAy     = 11
 VVUV37     = 12
 VVuivX     = 13
 VV7uel      = 14
 VV8C1U      = 15
 VVwFBv      = 16
 VVq75J      = 17
 VVk730      = 18
 VVxF4t    = 0
 VVPpHH   = 1
 VVMzCK   = 2
 VVFitc   = 3
 VVqDkv  = 4
 VVCiGV  = 5
 VVQYMA   = 6
 VVVDBH   = 7
 VVobfF  = 8
 VVkCGN  = 9
 VVZInt  = 10
 VV6Jlp = 0
 VVvKyI = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVMsCC    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVr5xsData    = {}
  self.localIptvFilterInFilter = False
  CCielb.__init__(self)
  VVWp2B = []
  VVWp2B.append(("IPTV Server Browser (from Playlists)"      , "VVr5xs_fromPlayList" ))
  VVWp2B.append(("IPTV Server Browser (from Portal List)"     , "VVr5xs_fromMac"  ))
  VVWp2B.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)" , "VVr5xs_fromM3u"  ))
  qUrl, iptvRef = self.VVCvdP()
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVWp2B.append((item      , "VVr5xs_fromCurrChan" ))
  else       : VVWp2B.append((item      ,       ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("M3U/M3U8 File Browser"         , "VV0LVx"   ))
  files = self.VVpGZM()
  if files:
   VVWp2B.append(("Local IPTV Services"         , "iptvTable_all"   ))
  VVWp2B.append(VVEgY4)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVWp2B.append((item1             , "refreshIptvEPG"   ))
   VVWp2B.append((item2             , "refreshIptvPicons"  ))
  else:
   VVWp2B.append((item1             ,       ))
   VVWp2B.append((item2             ,       ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Check System Acceptable Reference Types"     , "VVKtVx"   ))
  if files:
   VVWp2B.append(("Count Available IPTV Channels"      , "VV8Oj1"    ))
   VVWp2B.append(("Check Reference Codes Format"       , "VVuicp"   ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Reference Tools ..."         , "VV2i89"   ))
   VVWp2B.append(("Reload Channels and Bouquets"       , "VV1gfS"   ))
  VVWp2B.append(VVEgY4)
  if not CCuF83.VV9YR3():
   VVWp2B.append(("Download Manager"          , "dload_stat"    ))
  else:
   VVWp2B.append(("Download Manager ... No donwloads"     ,       ))
  FF2wUT(self, title="IPTV", VVWp2B=VVWp2B)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
  FFr6hs(self)
  if self.m3uOrM3u8File:
   self.VVvJS9(self.m3uOrM3u8File)
 def VVe7u5(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVkJq2"   : self.VVkJq2()
   elif item == "VVupDS" : FFm5Au(self, self.VVupDS, "Change Current List References to Unique Codes ?")
   elif item == "VVkkG1_rows" : FFm5Au(self, BF(FFOvQF, self.VVMsCC, self.VVkkG1), "Change Current List References to Identical Codes ?")
   elif item == "VVTQOZ"   : self.VVTQOZ(tTitle)
   elif item == "VVSVcD"   : self.VVSVcD(tTitle)
   elif item == "VVr5xs_fromPlayList" : FFOvQF(self, self.VVXxaO, title=title)
   elif item == "VVr5xs_fromM3u"  : FFOvQF(self, BF(self.VVuZdA, 0), title=title)
   elif item == "VVr5xs_fromMac"  : self.VVSSNS()
   elif item == "VVr5xs_fromCurrChan" : self.VVAzsB()
   elif item == "VV0LVx"   : self.VV0LVx()
   elif item == "iptvTable_all"   : FFOvQF(self, BF(self.VVYzL4, self.VVKFxs), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VV9tEU()
   elif item == "refreshIptvPicons"  : self.VV9JMx()
   elif item == "VV8Oj1"    : FFOvQF(self, self.VV8Oj1)
   elif item == "VVuicp"    : FFOvQF(self, self.VVuicp)
   elif item == "VVKtVx"   : FFOvQF(self, self.VVKtVx)
   elif item == "VV2i89"    : self.VV2i89()
   elif item == "VV1gfS"   : FFOvQF(self, BF(CCabmO.VV1gfS, self))
   elif item == "dload_stat"    : CCuF83.VVQEJc(self)
 def VV0LVx(self):
  if CCielb.VVhzF1(self):
   FFOvQF(self, BF(self.VVuZdA, 1), title="Searching ...")
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVe7u5(item)
 def VVYzL4(self, mode):
  VVMGU8 = self.VVRth6(mode)
  if VVMGU8:
   VV1NOm = ("Current Service", self.VVZUon , [])
   VVfzl8 = ("Options"  , self.VVBQEA   , [])
   VVL1b6 = ("Filter"   , self.VVakEp   , [])
   VVBh0a  = ("Play"   , BF(self.VVrE3e)  , [])
   VV9ZE5 = (""    , self.VVk66e    , [])
   VVaNtS = (""    , self.VVMuzU     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVKrzB  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFGcVX(self, None, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26
     , VVBh0a=VVBh0a, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, VV9ZE5=VV9ZE5, VVaNtS=VVaNtS
     , VVcV6s="#0a00292B", VV89EB="#0a002126", VVHzNF="#0a002126", VVhGFp="#00000000", VVLHme=True, searchCol=1)
  else:
   if mode == self.VVfyAf: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFNkji(self, err)
 def VVMuzU(self, VVMsCC, title, txt, colList):
  self.VVMsCC = VVMsCC
 def VVBQEA(self, VVMsCC, title, txt, colList):
  VVWp2B = []
  VVWp2B.append(("Add Current List to a New Bouquet"      , "VVkJq2"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Change Current List References to Unique Codes"   , "VVupDS"))
  VVWp2B.append(("Change Current List References to Identical Codes"  , "VVkkG1_rows" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVTQOZ"   ))
  VVWp2B.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVSVcD"   ))
  FFkkcl(self, self.VVe7u5, title="IPTV Tools", VVWp2B=VVWp2B)
 def VVakEp(self, VVMsCC, title, txt, colList):
  VVWp2B = []
  VVWp2B.append(("All"         , "all"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Prefix of Selected Channel"   , "sameName" ))
  VVWp2B.append(("Suggest Words from Selected Channel" , "partName" ))
  VVWp2B.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVWp2B.append(("Duplicate References"     , "depRef"  ))
  VVWp2B.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVWp2B.append(FFhiR0("Category"))
  VVWp2B.append(("Live TV"        , "live"  ))
  VVWp2B.append(("VOD"         , "vod"   ))
  VVWp2B.append(("Series"        , "series"  ))
  VVWp2B.append(("Uncategorised"      , "uncat"  ))
  VVWp2B.append(FFhiR0("Media"))
  VVWp2B.append(("Video"        , "video"  ))
  VVWp2B.append(("Audio"        , "audio"  ))
  VVWp2B.append(FFhiR0("File Type"))
  VVWp2B.append(("MKV"         , "MKV"   ))
  VVWp2B.append(("MP4"         , "MP4"   ))
  VVWp2B.append(("MP3"         , "MP3"   ))
  VVWp2B.append(("AVI"         , "AVI"   ))
  VVWp2B.append(("FLV"         , "FLV"   ))
  VVWp2B.extend(CC0dGf.VV1JB7(prefix="__b__"))
  inFilterFnc = BF(self.VVJAMT, VVMsCC) if VVMsCC.VVEU20().startswith("IPTV Filter ") else None
  filterObj = CCG8u1(self)
  filterObj.VV2Jpr(VVWp2B, VVWp2B, BF(self.VVDjui, VVMsCC, False), inFilterFnc=inFilterFnc)
 def VVJAMT(self, VVMsCC, menuInstance, item):
  self.VVDjui(VVMsCC, True, item)
 def VVDjui(self, VVMsCC, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVMsCC.VVG5WS(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVKFxs , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVd7Mo , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVoFWp , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVQprV , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVHppG  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV1z36  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "live"    : mode, words, title = self.VVfyAf  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVguyI   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVdBbB  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVilAy  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVUV37  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVuivX  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV7uel   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV8C1U   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVwFBv   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVq75J   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVk730   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVgdkk  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVMUuA  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVoFWp:
   VVWp2B = []
   chName = VVMsCC.VVG5WS(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVWp2B.append((item, item))
    if not VVWp2B and chName:
     VVWp2B.append((chName, chName))
    FFkkcl(self, BF(self.VVc2Jj, title), title="Words from Current Selection", VVWp2B=VVWp2B)
   else:
    VVMsCC.VVQ7Zq("Invalid Channel Name")
  else:
   words, asPrefix = CCG8u1.VVStOm(words)
   if not words and mode in (self.VVgdkk, self.VVMUuA):
    FFMnBb(self.VVMsCC, "Incorrect filter", 2000)
   else:
    FFOvQF(self.VVMsCC, BF(self.VV7GC4, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVc2Jj(self, title, word=None):
  if word:
   words = [word.lower()]
   FFOvQF(self.VVMsCC, BF(self.VV7GC4, self.VVoFWp, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVobwP(txt):
  return "#f#11ffff00#" + txt
 def VV7GC4(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVMGU8 = self.VVPABM(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVMGU8 = self.VVRth6(mode=mode, words=words, asPrefix=asPrefix)
  if VVMGU8 : self.VVMsCC.VVsLrn(VVMGU8, title)
  else  : self.VVMsCC.VVQ7Zq("Not found")
 def VVPABM(self, mode=0, words=None, asPrefix=False):
  VVMGU8 = []
  for row in self.VVMsCC.VVy2g3():
   row = list(map(str.strip, row))
   chNum, chName, VVbzVm, chType, refCode, url = row
   if self.VVXqKm(mode, refCode, FFm5cy(url).lower(), chName, words, VVbzVm.lower(), asPrefix):
    VVMGU8.append(row)
  VVMGU8 = self.VV3ff5(mode, VVMGU8)
  return VVMGU8
 def VVRth6(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVMGU8 = []
  files  = self.VVpGZM()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFS3H9(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVbzVm = span.group(1)
    else : VVbzVm = ""
    VVbzVm_lCase = VVbzVm.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVtCRr(chName): chNameMod = self.VVobwP(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVbzVm, chType, refCode, url)
     if self.VVXqKm(mode, refCode, FFm5cy(url).lower(), chName, words, VVbzVm_lCase, asPrefix):
      VVMGU8.append(row)
      chNum += 1
  VVMGU8 = self.VV3ff5(mode, VVMGU8)
  return VVMGU8
 def VV3ff5(self, mode, VVMGU8):
  newRows = []
  if VVMGU8 and mode == self.VVHppG:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVMGU8)
   for item in VVMGU8:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVMGU8
 def VVXqKm(self, mode, refCode, tUrl, chName, words, VVbzVm_lCase, asPrefix):
  if   mode == self.VVKFxs : return True
  elif mode == self.VVHppG : return True
  elif mode == self.VV1z36  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVUV37  : return CC5Be5.VVTRui(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVuivX  : return CC5Be5.VVTRui(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVfyAf  : return CC5Be5.VVTRui(tUrl, compareType="live")
  elif mode == self.VVguyI  : return CC5Be5.VVTRui(tUrl, compareType="movie")
  elif mode == self.VVdBbB : return CC5Be5.VVTRui(tUrl, compareType="series")
  elif mode == self.VVilAy  : return CC5Be5.VVTRui(tUrl, compareType="")
  elif mode == self.VV7uel  : return CC5Be5.VVTRui(tUrl, compareExt="mkv")
  elif mode == self.VV8C1U  : return CC5Be5.VVTRui(tUrl, compareExt="mp4")
  elif mode == self.VVwFBv  : return CC5Be5.VVTRui(tUrl, compareExt="mp3")
  elif mode == self.VVq75J  : return CC5Be5.VVTRui(tUrl, compareExt="avi")
  elif mode == self.VVk730  : return CC5Be5.VVTRui(tUrl, compareExt="flv")
  elif mode == self.VVd7Mo: return chName.lower().startswith(words[0])
  elif mode == self.VVoFWp: return words[0] in chName.lower()
  elif mode == self.VVQprV: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVgdkk : return words[0] == VVbzVm_lCase
  elif mode == self.VVMUuA :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVkJq2(self):
  picker = CC0dGf(self, self.VVMsCC, "Add to Bouquet", self.VVBo3b)
 def VVBo3b(self):
  chUrlLst = []
  for row in self.VVMsCC.VVy2g3():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VV2i89(self):
  VVWp2B = []
  VVWp2B.append(("Share Reference with Sat./C/T (Only Matching Names)"   , "VVcdDv"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(('Change Bouquet Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVFZxp" ))
  VVWp2B.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..'  , "VV87ne_all"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Change ALL References to Unique Codes"      , "VViuMg"  ))
  VVWp2B.append(("Change ALL References to Identical Codes"      , "VVkkG1_all"  ))
  OKBtnFnc = self.VVERPZ
  FFkkcl(self, self.VVERPZ, width=1200, title="Reference Tools", VVWp2B=VVWp2B, OKBtnFnc=OKBtnFnc)
 def VVERPZ(self, item=None):
  if item:
   menuInstance, txt, item, ndx = item
   ques  = "Continue ?"
   if   item == "VVcdDv"   : FFm5Au(self, BF(FFOvQF, menuInstance, self.VVcdDv ), title=txt, VVljeR=ques)
   elif item == "VVFZxp" : self.VVFZxp(menuInstance)
   elif item == "VV87ne_all"  : self.VVHNf0(menuInstance, None, None)
   elif item == "VViuMg"  : FFm5Au(self, BF(self.VViuMg , menuInstance, txt), title=txt, VVljeR=ques)
   elif item == "VVkkG1_all"  : FFm5Au(self, BF(FFOvQF, menuInstance, self.VVkkG1), title=txt, VVljeR=ques)
 def VVHNf0(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVWp2B = []
  VVWp2B.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVWp2B.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVWp2B.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVWp2B.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVWp2B.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVWp2B.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFkkcl(self, BF(self.VV68HQ, menuInstance, bName, bPath), width=750, title="Change Reference Types to:", VVWp2B=VVWp2B)
 def VV68HQ(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVUQ01(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVUQ01(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVUQ01(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVUQ01(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVUQ01(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVUQ01(menuInstance, bName, bPath, "8193")
 def VVFZxp(self, menuInstance):
  VVWp2B = CC0dGf.VV1JB7()
  if VVWp2B:
   FFkkcl(self, BF(self.VVUs75, menuInstance), VVWp2B=VVWp2B, title="IPTV Bouquets", VV83XM=True)
  else:
   FFMnBb(menuInstance, "No bouquets Found !", 1500)
 def VVUs75(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVSwef + span.group(1)
    if fileExists(bPath): self.VVHNf0(menuInstance, bName, bPath)
    else    : FFMnBb(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFMnBb(menuInstance, "Cannot process bouquet !", 2000)
 def VVUQ01(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFtSnl(bName, VVxbdF)
  else : title = "Change for %s" % FFtSnl("All IPTV Services", VVxbdF)
  FFm5Au(self, BF(FFOvQF, menuInstance, BF(self.VVbraD, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFtSnl(rType, VVxbdF), title=title)
 def VVbraD(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVpGZM()
  if files:
   newRType = rType + ":"
   piconPath = CCgJhP.VVkis2()
   for path in files:
    if   not fileExists(path)        : err = "Cannot read the file:\n\n%s" % path
    elif not CC0Jp1.VVoodk(self, path, "lamedb") : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else             : err = ""
    if err:
     FFNkji(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFBSzC("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFBSzC(cmd))
  self.VVQs6O(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VV8Oj1(self):
  totFiles = 0
  files  = self.VVpGZM()
  if files:
   totFiles = len(files)
  totChans = 0
  VVMGU8 = self.VVRth6()
  if VVMGU8:
   totChans = len(VVMGU8)
  FFzNhe(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVuicp(self):
  files  = self.VVpGZM()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFS3H9(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV41YE
   else    : color = VVpqRv
   totInvalid = FFtSnl(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFtSnl("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFzNhe(self, txt, title="Check IPTV References")
 def VVKtVx(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CC0dGf.VVqGMw(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVckRJ = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVckRJ:
   VViYKE = FF1xYh(VVckRJ)
   if VViYKE:
    for service in VViYKE:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVSwef + userBName
  bFile = VVSwef + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFBSzC("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFBSzC("rm -f '%s'" % path)
  os.system(cmd)
  FFbWMQ()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV41YE
    else     : res, color = "No" , VVpqRv
    txt += "    %s\t: %s\n" % (item, FFtSnl(res, color))
   FFzNhe(self, txt, title=title)
  else:
   txt = FFNkji(self, "Could not complete the test on your system!", title=title)
 def VVcdDv(self):
  VVGCEl, err = CCabmO.VVN2H3(self, CCabmO.VVzeWC)
  if VVGCEl:
   totChannels = 0
   totChange = 0
   for path in self.VVpGZM():
    toSave = False
    txt = FFS3H9(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVGCEl.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVQs6O(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFNkji(self, 'No channels in "lamedb" !')
 def VViuMg(self, menuInstance, title):
  bFiles = self.VVpGZM()
  if bFiles:
   self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVYvkR, bFiles)
       , VVJcVO = BF(self.VVWR5X, title))
  else:
   FFMnBb(menuInstance, "No bouquets files !", 1500)
 def VVYvkR(self, bFiles, VVbrNS):
  VVbrNS.VV4mwj = ""
  VVbrNS.VVCxfw("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFsCGi(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVbrNS or VVbrNS.isCancelled:
   return
  elif not totLines:
   VVbrNS.VV4mwj = "No IPTV Services !"
   return
  else:
   VVbrNS.VVdoFu(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVbrNS or VVbrNS.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFsCGi(path)
    for ndx, line in enumerate(lines):
     if not VVbrNS or VVbrNS.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVbrNS:
       VVbrNS.VVCxfw("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVbrNS:
       VVbrNS.VV0CXi(1)
      refCode, startId, startNS = CC0dGf.VVaamb(rType, CC0dGf.VV4ytl, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVbrNS:
        VVbrNS.VV4mwj = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
 def VVWR5X(self, title, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VV4mwj:
   txt += "\n\n%s\n%s" % (FFtSnl("Ended with Error:", VVpqRv), VV4mwj)
  self.VVQs6O(True, title, txt)
 def VVupDS(self):
  bFiles = self.VVpGZM()
  if not bFiles:
   FFMnBb(self.VVMsCC, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVMsCC.VVy2g3():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFMnBb(self.VVMsCC, "Cannot read list", 1500)
   return
  self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVUI4m, bFiles, tableRefList)
      , VVJcVO = BF(self.VVWR5X, "Change Current List References to Unique Codes"))
 def VVUI4m(self, bFiles, tableRefList, VVbrNS):
  VVbrNS.VV4mwj = ""
  VVbrNS.VVCxfw("Reading System References ...")
  refLst = CC0dGf.VVFqKp(CC0dGf.VV4ytl, stripRType=True)
  if not VVbrNS or VVbrNS.isCancelled:
   return
  VVbrNS.VVdoFu(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVbrNS or VVbrNS.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFS3H9(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVbrNS or VVbrNS.isCancelled:
     return
    VVbrNS.VVCxfw("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVbrNS or VVbrNS.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVbrNS.VV0CXi(1)
      refCode, startId, startNS = CC0dGf.VVaamb(rType, CC0dGf.VV4ytl, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVbrNS:
        VVbrNS.VV4mwj = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVkkG1(self):
  list = None
  if self.VVMsCC:
   list = []
   for row in self.VVMsCC.VVy2g3():
    list.append(row[4] + row[5])
  files  = self.VVpGZM()
  totChange = 0
  if files:
   for path in files:
    lines = FFsCGi(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVQs6O(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVQs6O(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFbWMQ()
   if refreshTable and self.VVMsCC:
    VVMGU8 = self.VVRth6()
    if VVMGU8 and self.VVMsCC:
     self.VVMsCC.VVsLrn(VVMGU8, self.tableTitle)
     self.VVMsCC.VVQ7Zq(txt)
   FFzNhe(self, txt, title=title)
  else:
   FFO5iz(self, "No changes.")
 def VVpGZM(self):
  return CC5Be5.VVzeTw(self)
 @staticmethod
 def VVzeTw(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVSwef + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFS3H9(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVk66e(self, VVMsCC, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFm5cy(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFRDSd(self, fncMode=CCGnOY.VV7EVt, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVx0SN(self, VVMsCC, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVrE3e(self, VVMsCC, title, txt, colList):
  chName, chUrl = self.VVx0SN(VVMsCC, colList)
  self.VVDGXz(VVMsCC, chName, chUrl, "localIptv")
 def VVdyE5(self, mode, VVMsCC, colList):
  chName, chUrl, picUrl, refCode = self.VVYfcX(mode, colList)
  return chName, chUrl
 def VVEG7s(self, mode, VVMsCC, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVYfcX(mode, colList)
  self.VVDGXz(VVMsCC, chName, chUrl, mode)
 def VVDGXz(self, VVMsCC, chName, chUrl, playerFlag):
  chName = FFYfxZ(chName)
  if self.VVtCRr(chName):
   FFMnBb(VVMsCC, "This is a marker!", 300)
  else:
   FFOvQF(VVMsCC, BF(self.VVqGi4, VVMsCC, chUrl, playerFlag), title="Playing ...")
 def VVqGi4(self, VVMsCC, chUrl, playerFlag):
  FFQ5yd(self, chUrl, VVz7YZ=False)
  self.session.open(CCZilb, portalTableParam=(self, VVMsCC, playerFlag))
 @staticmethod
 def VVtCRr(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVZUon(self, VVMsCC, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  if refCode:
   bName = CC0dGf.VV4fhK()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFwmMJ(refCode, origUrl, chName) }
   VVMsCC.VV3Dgb(colDict, VVvNCa=True)
 def VVuZdA(self, m3uMode):
  lines = self.VVPw9t(3)
  if lines:
   lines.sort()
   VVWp2B = []
   for line in lines:
    VVWp2B.append((line, line))
   if m3uMode == self.VV6Jlp:
    title = "Browse Server from M3U URLs"
    VVK0co = ("All to Playlist", self.VV7tK6)
   else:
    title = "M3U/M3U8 File Browser"
    VVK0co = None
   OKBtnFnc = BF(self.VVsrFd, m3uMode, title)
   VVKBZE  = ("Show Full Path", self.VVzBn7)
   VVBc7a = ("Delete File", self.VVkNMq)
   FFkkcl(self, None, title=title, VVWp2B=VVWp2B, width=1200, OKBtnFnc=OKBtnFnc, VVKBZE=VVKBZE, VVBc7a=VVBc7a, VVK0co=VVK0co)
 def VVzBn7(self, VVW8faObj, url):
  FFzNhe(self, url, title="Full Path")
 def VVsrFd(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VV6Jlp:
    FFOvQF(menuInstance, BF(self.VVPMwv, title, path))
   else:
    FFOvQF(menuInstance, BF(self.VVvJS9, path))
 def VVvJS9(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFS3H9(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVKieG = CCvNDE()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVwBFO(propLine, "group-title") or "-"
   if not group == "-" and VVKieG.VVFRrn(group):
    groups.add(group)
  VVMGU8 = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVMGU8.append((group, group))
   VVMGU8.append(("ALL", ""))
   VVMGU8.sort(key=lambda x: x[0].lower())
   VVOTt1 = self.VVnTBo
   VVBh0a  = ("Select" , BF(self.VV07kF, srcPath), [])
   widths   = (100  , 0)
   VVKrzB  = (LEFT  , LEFT)
   FFGcVX(self, None, title=title, width= 1000, header=None, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=30, VVBh0a=VVBh0a, VVOTt1=VVOTt1, lastFindConfigObj=CFG.lastFindIptv
     , VVcV6s="#11110022", VV89EB="#11110022", VVHzNF="#11110022", VVhGFp="#00444400")
  else:
   txt = FFS3H9(srcPath)
   self.VVaGj0(txt, filterGroup="")
 def VV07kF(self, srcPath, VVMsCC, title, txt, colList):
  group = colList[1]
  txt = FFS3H9(srcPath)
  self.VVaGj0(txt, filterGroup=group)
 def VVaGj0(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CC4A0C, barTheme=CC4A0C.VVo57g
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VVghrV, lst, filterGroup)
       , VVJcVO = BF(self.VVLr5o, title, bName))
  else:
   self.VVZwXO("No valid lines found !", title)
 def VVghrV(self, lst, filterGroup, VVbrNS):
  VVbrNS.VV4mwj = []
  VVbrNS.VVdoFu(len(lst))
  VVKieG = CCvNDE()
  num = 0
  for cols in lst:
   if not VVbrNS or VVbrNS.isCancelled:
    return
   VVbrNS.VV0CXi(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVwBFO(propLine, "tvg-logo")
   group = self.VVwBFO(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not VVKieG.VVFRrn(group) : skip = True
    if chName and not VVKieG.VVFRrn(chName): skip = True
    if not skip and VVbrNS:
     num += 1
     VVbrNS.VV4mwj.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVbrNS:
   VVbrNS.VVDL2P("Loading %d Channels" % len(VVbrNS.VV4mwj))
 def VVLr5o(self, title, bName, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if VV4mwj:
   VVOTt1 = self.VVnTBo
   VVBh0a  = ("Select"   , BF(self.VVCudI, title)    , [])
   VV9ZE5 = (""    , self.VVf4oP         , [])
   VV1NOm = ("Download PIcons", self.VVbxJt        , [])
   VVfzl8 = ("Options"  , BF(self.VVNwuk, 1, "m3Ch", "", bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVKrzB  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFGcVX(self, None, title=title, header=header, VVJXpL=VV4mwj, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=28, VVBh0a=VVBh0a, VVOTt1=VVOTt1, VV9ZE5=VV9ZE5, VV1NOm=VV1NOm, VVfzl8=VVfzl8, lastFindConfigObj=CFG.lastFindIptv, VVLHme=True, searchCol=1
     , VVcV6s="#0a00192B", VV89EB="#0a00192B", VVHzNF="#0a00192B", VVhGFp="#00000000")
  else:
   self.VVZwXO("No valid lines found !", title)
 def VVbxJt(self, VVMsCC, title, txt, colList):
  self.VVmQVj(VVMsCC, "m3u/m3u8")
 def VV8MUJ(self, rowNum, url, chName):
  refCode = self.VVy3O2(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FF3nQE(url), chName)
  return chUrl
 def VVy3O2(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVW8Zc(catID, stID, chNum)
  return refCode
 def VVwBFO(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVCudI(self, Title, VVMsCC, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFOvQF(VVMsCC, BF(self.VVVa0p, Title, VVMsCC, colList), title="Checking Server ...")
  else:
   self.VVvno4(VVMsCC, url, chName)
 def VVVa0p(self, title, VVMsCC, colList):
  if not CCielb.VVhzF1(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCFpLh.VVdePF(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVWp2B = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC5Be5.VVgc6R(url, fPath)
     VVWp2B.append((resol, fullUrl))
    if VVWp2B:
     if len(VVWp2B) > 1:
      FFkkcl(self, BF(self.VVw4oT, VVMsCC, chName), VVWp2B=VVWp2B, title="Resolution", VV83XM=True, VV7G8l=True)
     else:
      self.VVvno4(VVMsCC, VVWp2B[0][1], chName)
    else:
     self.VVQDGO("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVaGj0(txt, filterGroup="")
      return
    self.VVvno4(VVMsCC, url, chName)
   else:
    self.VVZwXO("Cannot process this channel !", title)
  else:
   self.VVZwXO(err, title)
 def VVw4oT(self, VVMsCC, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVvno4(VVMsCC, resolUrl, chName)
 def VVvno4(self, VVMsCC, url, chName):
  FFOvQF(VVMsCC, BF(self.VV0YM0, VVMsCC, url, chName), title="Playing ...")
 def VV0YM0(self, VVMsCC, url, chName):
  chUrl = self.VV8MUJ(VVMsCC.VVeXGB(), url, chName)
  FFQ5yd(self, chUrl, VVz7YZ=False)
  self.session.open(CCZilb, portalTableParam=(self, VVMsCC, "m3u/m3u8"))
 def VVM1lG(self, VVMsCC, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VV8MUJ(VVMsCC.VVeXGB(), url, chName)
  return chName, chUrl
 def VVf4oP(self, VVMsCC, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFRDSd(self, fncMode=CCGnOY.VV7EVt, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVZwXO(self, err, title):
  FFNkji(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVnTBo(self, VVMsCC):
  if self.m3uOrM3u8File:
   self.close()
  VVMsCC.cancel()
 def VV7tK6(self, VVW8faObj, item=None):
  FFOvQF(VVW8faObj, BF(self.VVoctj, VVW8faObj, item))
 def VVoctj(self, VVW8faObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVW8faObj.VVWp2B):
    path = item[1]
    if fileExists(path):
     enc = CCF2zZ.VVNH6s(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVflFt(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC5Be5.VVovQ1()
    pListF = "%sPlaylist_%s.txt" % (path, FF03bo())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVW8faObj.VVWp2B)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFzNhe(self, txt, title=title)
   else:
    FFNkji(self, "Could not obtain URLs from this file list !", title=title)
 def VVXxaO(self):
  lines = self.VVPw9t(1)
  if lines:
   lines.sort()
   VVWp2B = []
   for line in lines:
    VVWp2B.append((line, line))
   OKBtnFnc  = self.VVWiKP
   VVBc7a = ("Delete File", self.VVkNMq)
   FFkkcl(self, None, title="Select Playlist File", VVWp2B=VVWp2B, width=1200, OKBtnFnc=OKBtnFnc, VVBc7a=VVBc7a)
 def VVWiKP(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFOvQF(menuInstance, BF(self.VVCIDS, menuInstance, path), title="Processing File ...")
 def VVCIDS(self, VVgxmd, path):
  enc = CCF2zZ.VVNH6s(path, self)
  if enc == -1:
   return
  VVMGU8 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFjGgP(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC5Be5.VVZNOQ(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVMGU8:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVMGU8.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVMGU8:
   title = "Playlist File : %s" % os.path.basename(path)
   VVBh0a  = ("Start"    , BF(self.VVSXwZ, "Playlist File")      , [])
   VV6i1u = ("Home Menu"   , FFDRAB             , [])
   VV1NOm = ("Download M3U File" , self.VVkCUx         , [])
   VVfzl8 = ("Edit File"   , BF(self.VVMEMz, path)        , [])
   VVL1b6 = ("Check & Filter"  , BF(self.VVCFmV, VVgxmd, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVKrzB  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFGcVX(self, None, title=title, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV6i1u=VV6i1u, VVL1b6=VVL1b6, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVcV6s="#11001116", VV89EB="#11001116", VVHzNF="#11001116", VVhGFp="#00003635", VV3VgO="#0a333333", VVGPak="#11331100", VVLHme=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFNkji(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVkCUx(self, VVMsCC, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFm5Au(self, BF(FFOvQF, VVMsCC, BF(self.VVSFML, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVSFML(self, title, url):
  path, err = FFhNjK(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFNkji(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFS3H9(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFBSzC("rm -f '%s'" % path))
    FFNkji(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFBSzC("rm -f '%s'" % path))
    FFNkji(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC5Be5.VVovQ1() + fName
    os.system(FFBSzC("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFO5iz(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFNkji(self, "Could not download the M3U file!", title=errTitle)
 def VVSXwZ(self, Title, VVMsCC, title, txt, colList):
  url = colList[6]
  FFOvQF(VVMsCC, BF(self.VVRxnh, Title, url), title="Checking Server ...")
 def VVMEMz(self, path, VVMsCC, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC6mSu(self, path, VVJcVO=BF(self.VVLjPk, VVMsCC), curRowNum=rowNum)
  else    : FFdzz0(self, path)
 def VVLjPk(self, VVMsCC, fileChanged):
  if fileChanged:
   VVMsCC.cancel()
 def VVTQOZ(self, title):
  curChName = self.VVMsCC.VVG5WS(1)
  FFhzot(self, BF(self.VVI5St, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVI5St(self, title, name):
  if name:
   VVGCEl, err = CCabmO.VVN2H3(self, CCabmO.VVFSF3, VVBmG6=False, VVkNHV=False)
   list = []
   if VVGCEl:
    VVKieG = CCvNDE()
    name = VVKieG.VV4Nkx(name)
    ratio = "1"
    for item in VVGCEl:
     if name in item[0].lower():
      list.append((item[0], FFwTSp(item[2]), item[3], ratio))
   if list : self.VVQr4j(list, title)
   else : FFNkji(self, "Not found:\n\n%s" % name, title=title)
 def VVSVcD(self, title):
  curChName = self.VVMsCC.VVG5WS(1)
  self.session.open(CC4A0C, barTheme=CC4A0C.VVo57g
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVJvzP
      , VVJcVO = BF(self.VVBX2p, title, curChName))
 def VVJvzP(self, VVbrNS):
  curChName = self.VVMsCC.VVG5WS(1)
  VVGCEl, err = CCabmO.VVN2H3(self, CCabmO.VVaZOM, VVBmG6=False, VVkNHV=False)
  if not VVGCEl or not VVbrNS or VVbrNS.isCancelled:
   return
  VVbrNS.VV4mwj = []
  VVbrNS.VVdoFu(len(VVGCEl))
  VVKieG = CCvNDE()
  curCh = VVKieG.VV4Nkx(curChName)
  for refCode in VVGCEl:
   chName, sat, inDB = VVGCEl.get(refCode, ("", "", 0))
   ratio = CCgJhP.VVFPfC(chName.lower(), curCh)
   if not VVbrNS or VVbrNS.isCancelled:
    return
   VVbrNS.VV0CXi(1, True)
   if VVbrNS and ratio > 50:
    VVbrNS.VV4mwj.append((chName, FFwTSp(sat), refCode.replace("_", ":"), str(ratio)))
 def VVBX2p(self, title, curChName, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if VV4mwj: self.VVQr4j(VV4mwj, title)
  elif VVTgbE: FFNkji(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVQr4j(self, VVMGU8, title):
  curChName = self.VVMsCC.VVG5WS(1)
  VVEamR = self.VVMsCC.VVG5WS(4)
  curUrl  = self.VVMsCC.VVG5WS(5)
  VVMGU8.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVBh0a  = ("Share Sat/C/T Ref.", BF(self.VVEaDy, title, curChName, VVEamR, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFGcVX(self, None, title=title, header=header, VVJXpL=VVMGU8, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VVcV6s="#0a00112B", VV89EB="#0a001126", VVHzNF="#0a001126", VVhGFp="#00000000")
 def VVEaDy(self, newtitle, curChName, VVEamR, curUrl, VVMsCC, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVEamR, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFm5Au(self.VVMsCC, BF(FFOvQF, self.VVMsCC, BF(self.VVibi7, VVMsCC, data)), ques, title=newtitle, VVYN57=True)
 def VVibi7(self, VVMsCC, data):
  VVMsCC.cancel()
  title, curChName, VVEamR, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVEamR = VVEamR.strip()
  newRefCode = newRefCode.strip()
  if not VVEamR.endswith(":") : VVEamR += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVEamR, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVEamR + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVpGZM():
    txt = FFS3H9(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFbWMQ()
    newRow = []
    for i in range(6):
     newRow.append(self.VVMsCC.VVG5WS(i))
    newRow[4] = newRefCode
    done = self.VVMsCC.VVNvto(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFrvtJ(BF(FFO5iz , self, resTxt, title=title))
  elif resErr: FFrvtJ(BF(FFNkji, self, resErr, title=title))
 def VVCFmV(self, VVgxmd, path, VVMsCC, title, txt, colList):
  self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVGvdZ, VVMsCC)
      , VVJcVO = BF(self.VVOfJU, VVgxmd, path, VVMsCC))
 def VVGvdZ(self, VVMsCC, VVbrNS):
  VVbrNS.VVdoFu(VVMsCC.VV7STd())
  VVbrNS.VV4mwj = []
  for row in VVMsCC.VVy2g3():
   if not VVbrNS or VVbrNS.isCancelled:
    return
   VVbrNS.VV0CXi(1, True)
   qUrl = self.VVS35w(self.VVxF4t, row[6])
   txt, err = self.VVsGVC(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVlB8q(item, "auth") == "0":
       VVbrNS.VV4mwj.append(qUrl)
    except:
     pass
 def VVOfJU(self, VVgxmd, path, VVMsCC, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if VVTgbE:
   list = VV4mwj
   title = "Authorized Servers"
   if list:
    totChk = VVMsCC.VV7STd()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF03bo()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVXxaO()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFtSnl(str(totAuth), VV41YE)
     txt += "%s\n\n%s"    %  (FFtSnl("Result File:", VVFeau), newPath)
     FFzNhe(self, txt, title=title)
     VVMsCC.close()
     VVgxmd.close()
    else:
     FFO5iz(self, "All URLs are authorized.", title=title)
   else:
    FFNkji(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVsGVC(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVZNOQ(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVTRui(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCBLUS.VVG0g6()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVGmAe(decodedUrl):
  return CC5Be5.VVTRui(decodedUrl, justRetDotExt=True)
 def VVS35w(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVZNOQ(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVxF4t   : return "%s"            % url
  elif mode == self.VVPpHH   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVMzCK   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVFitc  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVqDkv  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVCiGV : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVQYMA   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVVDBH    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVobfF  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVZInt : return "%s&action=get_live_streams"      % url
  elif mode == self.VVkCGN  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVlB8q(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFP6g0(int(val))
    elif is_base64 : val = FFdLhv(val)
    elif isToHHMMSS : val = FFAdnL(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVPMwv(self, title, path):
  if fileExists(path):
   enc = CCF2zZ.VVNH6s(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVflFt(line)
     if qUrl:
      break
   if qUrl : self.VVRxnh(title, qUrl)
   else : FFNkji(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFNkji(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVAzsB(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVCvdP()
  if qUrl or "chCode" in iptvRef:
   p = CCFpLh()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVO1mk(iptvRef)
   if valid:
    self.VV2fEc(self, host, mac)
    return
   elif qUrl:
    FFOvQF(self, BF(self.VVRxnh, title, qUrl), title="Checking Server ...")
    return
  FFNkji(self, "Error in current channel URL !", title=title)
 def VVCvdP(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  qUrl = self.VVflFt(decodedUrl)
  return qUrl, iptvRef
 def VVflFt(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVRxnh(self, title, url):
  self.VVr5xsData = {}
  qUrl = self.VVS35w(self.VVxF4t, url)
  txt, err = self.VVsGVC(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVr5xsData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVr5xsData["username"    ] = self.VVlB8q(item, "username"        )
    self.VVr5xsData["password"    ] = self.VVlB8q(item, "password"        )
    self.VVr5xsData["message"    ] = self.VVlB8q(item, "message"        )
    self.VVr5xsData["auth"     ] = self.VVlB8q(item, "auth"         )
    self.VVr5xsData["status"    ] = self.VVlB8q(item, "status"        )
    self.VVr5xsData["exp_date"    ] = self.VVlB8q(item, "exp_date"    , isDate=True )
    self.VVr5xsData["is_trial"    ] = self.VVlB8q(item, "is_trial"        )
    self.VVr5xsData["active_cons"   ] = self.VVlB8q(item, "active_cons"       )
    self.VVr5xsData["created_at"   ] = self.VVlB8q(item, "created_at"   , isDate=True )
    self.VVr5xsData["max_connections"  ] = self.VVlB8q(item, "max_connections"      )
    self.VVr5xsData["allowed_output_formats"] = self.VVlB8q(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVr5xsData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVr5xsData["url"    ] = self.VVlB8q(item, "url"        )
    self.VVr5xsData["port"    ] = self.VVlB8q(item, "port"        )
    self.VVr5xsData["https_port"  ] = self.VVlB8q(item, "https_port"      )
    self.VVr5xsData["server_protocol" ] = self.VVlB8q(item, "server_protocol"     )
    self.VVr5xsData["rtmp_port"   ] = self.VVlB8q(item, "rtmp_port"       )
    self.VVr5xsData["timezone"   ] = self.VVlB8q(item, "timezone"       )
    self.VVr5xsData["timestamp_now"  ] = self.VVlB8q(item, "timestamp_now"  , isDate=True )
    self.VVr5xsData["time_now"   ] = self.VVlB8q(item, "time_now"       )
    VVWp2B  = self.VVni84(True)
    OKBtnFnc = self.VVwjSa
    VVaTfU = ("Home Menu", FFDRAB)
    VVK0co = ("Bookmark Server", BF(CC5Be5.VVQyOy, self, False, self.VVr5xsData["playListURL"]))
    FFkkcl(self, None, title="IPTV Server Resources", VVWp2B=VVWp2B, OKBtnFnc=OKBtnFnc, VVaTfU=VVaTfU, VVK0co=VVK0co)
   else:
    err = "Could not get data from server !"
  if err:
   FFNkji(self, err, title=title)
  FFMnBb(self)
 def VVwjSa(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFOvQF(menuInstance, BF(self.VVLAV0, self.VVPpHH  , title=title), title=wTxt)
   elif ref == "vod"   : FFOvQF(menuInstance, BF(self.VVLAV0, self.VVMzCK  , title=title), title=wTxt)
   elif ref == "series"  : FFOvQF(menuInstance, BF(self.VVLAV0, self.VVFitc , title=title), title=wTxt)
   elif ref == "catchup"  : FFOvQF(menuInstance, BF(self.VVLAV0, self.VVqDkv , title=title), title=wTxt)
   elif ref == "accountInfo" : FFOvQF(menuInstance, BF(self.VV2vpB           , title=title), title=wTxt)
 def VV2vpB(self, title):
  rows = []
  for key, val in self.VVr5xsData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVPeo6
   else:
    num, part = "1", self.VVlrra
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VV6i1u  = ("Home Menu", FFDRAB, [])
  VV1NOm  = None
  if VVYACA:
   VV1NOm = ("Get JS" , BF(self.VVeL5W, "/".join(self.VVr5xsData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFGcVX(self, None, title=title, width=1200, header=header, VVJXpL=rows, VVQGhe=widths, VVlOla=26, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVcV6s="#0a00292B", VV89EB="#0a002126", VVHzNF="#0a002126", VVhGFp="#00000000", searchCol=2)
 def VVpYh1(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVKieG = CCvNDE()
    if mode in (self.VVQYMA, self.VVkCGN):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVlB8q(item, "num"         )
      name     = self.VVlB8q(item, "name"        )
      stream_id    = self.VVlB8q(item, "stream_id"       )
      stream_icon    = self.VVlB8q(item, "stream_icon"       )
      epg_channel_id   = self.VVlB8q(item, "epg_channel_id"      )
      added     = self.VVlB8q(item, "added"    , isDate=True )
      is_adult    = self.VVlB8q(item, "is_adult"       )
      category_id    = self.VVlB8q(item, "category_id"       )
      tv_archive    = self.VVlB8q(item, "tv_archive"       )
      name = VVKieG.VVFRrn(name)
      if name:
       if mode == self.VVQYMA or mode == self.VVkCGN and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVVDBH:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVlB8q(item, "num"         )
      name    = self.VVlB8q(item, "name"        )
      stream_id   = self.VVlB8q(item, "stream_id"       )
      stream_icon   = self.VVlB8q(item, "stream_icon"       )
      added    = self.VVlB8q(item, "added"    , isDate=True )
      is_adult   = self.VVlB8q(item, "is_adult"       )
      category_id   = self.VVlB8q(item, "category_id"       )
      container_extension = self.VVlB8q(item, "container_extension"     ) or "mp4"
      name = VVKieG.VVFRrn(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVobfF:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVlB8q(item, "num"        )
      name    = self.VVlB8q(item, "name"       )
      series_id   = self.VVlB8q(item, "series_id"      )
      cover    = self.VVlB8q(item, "cover"       )
      genre    = self.VVlB8q(item, "genre"       )
      episode_run_time = self.VVlB8q(item, "episode_run_time"    )
      category_id   = self.VVlB8q(item, "category_id"      )
      container_extension = self.VVlB8q(item, "container_extension"    ) or "mp4"
      name = VVKieG.VVFRrn(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVLAV0(self, mode, title):
  cList, err = self.VVO3c9(mode)
  if cList and mode == self.VVqDkv:
   cList = self.VVTI8E(cList)
  if err:
   FFNkji(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4(mode)
   mName = self.VVCAIT(mode)
   if   mode == self.VVPpHH  : fMode = self.VVQYMA
   elif mode == self.VVMzCK  : fMode = self.VVVDBH
   elif mode == self.VVFitc : fMode = self.VVobfF
   elif mode == self.VVqDkv : fMode = self.VVkCGN
   if mode == self.VVqDkv:
    VVfzl8 = None
   else:
    VVfzl8 = ("Find in %s" % mName , BF(self.VV5g5Q, fMode) , [])
   VVBh0a   = ("Show List"   , BF(self.VVXNoC, mode), [])
   VV6i1u  = ("Home Menu"   , FFDRAB       , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFGcVX(self, None, title=title, width=1200, header=header, VVJXpL=cList, VVQGhe=widths, VVlOla=30, VV6i1u=VV6i1u, VVfzl8=VVfzl8, VVBh0a=VVBh0a, VVcV6s=VVcV6s, VV89EB=VV89EB, VVHzNF=VVHzNF, VVhGFp=VVhGFp, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFNkji(self, "No list from server !", title=title)
  FFMnBb(self)
 def VVO3c9(self, mode):
  qUrl  = self.VVS35w(mode, self.VVr5xsData["playListURL"])
  txt, err = self.VVsGVC(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVKieG = CCvNDE()
    for item in tDict:
     category_id  = self.VVlB8q(item, "category_id"  )
     category_name = self.VVlB8q(item, "category_name" )
     parent_id  = self.VVlB8q(item, "parent_id"  )
     category_name = VVKieG.VV6Q9i(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVTI8E(self, catList):
  mode  = self.VVkCGN
  qUrl  = self.VVS35w(mode, self.VVr5xsData["playListURL"])
  txt, err = self.VVsGVC(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVpYh1(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVXNoC(self, mode, VVMsCC, title, txt, colList):
  title = colList[1]
  FFOvQF(VVMsCC, BF(self.VVZBzm, mode, VVMsCC, title, txt, colList), title="Downloading ...")
 def VVZBzm(self, mode, VVMsCC, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVCAIT(mode) + " : "+ bName
  if   mode == self.VVPpHH  : mode = self.VVQYMA
  elif mode == self.VVMzCK  : mode = self.VVVDBH
  elif mode == self.VVFitc : mode = self.VVobfF
  elif mode == self.VVqDkv : mode = self.VVkCGN
  qUrl  = self.VVS35w(mode, self.VVr5xsData["playListURL"], catID)
  txt, err = self.VVsGVC(qUrl)
  list  = []
  if not err and mode in (self.VVQYMA, self.VVVDBH, self.VVobfF, self.VVkCGN):
   list, err = self.VVpYh1(mode, txt)
  if err:
   FFNkji(self, err, title=title)
  elif list:
   VV6i1u  = ("Home Menu"   , FFDRAB            , [])
   if mode in (self.VVQYMA, self.VVkCGN):
    VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4(mode)
    VV9ZE5 = (""     , BF(self.VV9sJr, mode)      , [])
    VV1NOm = ("Download Options" , BF(self.VV1wZQ, mode, "", "")   , [])
    VVfzl8 = ("Options"   , BF(self.VVNwuk, 1, "lv", mode, bName)  , [])
    if mode == self.VVQYMA:
     VVBh0a = ("Play"    , BF(self.VVEG7s, mode)       , [])
    elif mode == self.VVkCGN:
     VVBh0a  = ("Programs"  , BF(self.VVBAa4, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVKrzB  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVVDBH:
    VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4(mode)
    VVBh0a  = ("Play"    , BF(self.VVEG7s, mode)       , [])
    VV9ZE5 = (""     , BF(self.VV9sJr, mode)      , [])
    VV1NOm = ("Download Options" , BF(self.VV1wZQ, mode, "v", "")   , [])
    VVfzl8 = ("Options"   , BF(self.VVNwuk, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVKrzB  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVobfF:
    VVcV6s, VV89EB, VVHzNF, VVhGFp = self.VVxWU4("series2")
    VVBh0a  = ("Show Seasons"  , BF(self.VVIJ5L, mode)       , [])
    VV9ZE5 = (""     , BF(self.VVJg0U, mode)     , [])
    VV1NOm = None
    VVfzl8 = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVKrzB  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFGcVX(self, None, title=title, header=header, VVJXpL=list, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, lastFindConfigObj=CFG.lastFindIptv, VV9ZE5=VV9ZE5, VVcV6s=VVcV6s, VV89EB=VV89EB, VVHzNF=VVHzNF, VVhGFp=VVhGFp, VVLHme=True, searchCol=1)
  else:
   FFNkji(self, "No Channels found !", title=title)
  FFMnBb(self)
 def VVBAa4(self, mode, bName, VVMsCC, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVr5xsData["playListURL"]
  ok_fnc  = BF(self.VVIE0X, hostUrl, chName, catId, streamId)
  FFOvQF(VVMsCC, BF(CC5Be5.VVKUGt, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVIE0X(self, chUrl, chName, catId, streamId, VVMsCC, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC5Be5.VVZNOQ(chUrl)
   chNum = "333"
   refCode = CC5Be5.VVW8Zc(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFQ5yd(self, chUrl, VVz7YZ=False)
   self.session.open(CCZilb)
  else:
   FFNkji(self, "Incorrect Timestamp", pTitle)
 def VVIJ5L(self, mode, VVMsCC, title, txt, colList):
  title = colList[1]
  FFOvQF(VVMsCC, BF(self.VVf67l, mode, VVMsCC, title, txt, colList), title="Downloading ...")
 def VVf67l(self, mode, VVMsCC, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVS35w(self.VVCiGV, self.VVr5xsData["playListURL"], series_id)
  txt, err = self.VVsGVC(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVlB8q(tDict["info"], "name"   )
      category_id = self.VVlB8q(tDict["info"], "category_id" )
      icon  = self.VVlB8q(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVKieG = CCvNDE()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVlB8q(EP, "id"     )
        episode_num   = self.VVlB8q(EP, "episode_num"   )
        epTitle    = self.VVlB8q(EP, "title"     )
        container_extension = self.VVlB8q(EP, "container_extension" )
        seasonNum   = self.VVlB8q(EP, "season"    )
        epTitle = VVKieG.VVFRrn(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFNkji(self, err, title=title)
  elif list:
   VV6i1u = ("Home Menu"   , FFDRAB           , [])
   VV1NOm = ("Download Options" , BF(self.VV1wZQ, mode, "s", title) , [])
   VVfzl8 = ("Options"   , BF(self.VVNwuk, 0, "s", mode, title) , [])
   VV9ZE5 = (""     , BF(self.VV9sJr, mode)     , [])
   VVBh0a  = ("Play"    , BF(self.VVEG7s, mode)      , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVKrzB  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFGcVX(self, None, title=title, header=header, VVJXpL=list, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VVfzl8=VVfzl8, lastFindConfigObj=CFG.lastFindIptv, VVcV6s="#0a00292B", VV89EB="#0a002126", VVHzNF="#0a002126", VVhGFp="#00000000")
  else:
   FFNkji(self, "No Channels found !", title=title)
  FFMnBb(self)
 def VV5g5Q(self, mode, VVMsCC, title, txt, colList):
  VVWp2B = []
  VVWp2B.append(("Keyboard"  , "manualEntry"))
  VVWp2B.append(("From Filter" , "fromFilter"))
  FFkkcl(self, BF(self.VVMAgi, VVMsCC, mode), title="Input Type", VVWp2B=VVWp2B, width=400)
 def VVMAgi(self, VVMsCC, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFhzot(self, BF(self.VVOp3y, VVMsCC, mode), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCG8u1(self)
    filterObj.VVYsxj(BF(self.VVOp3y, VVMsCC, mode))
 def VVOp3y(self, VVMsCC, mode, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   self.VVLN7n(toFind)
   if toFind:
    words, asPrefix = CCG8u1.VVStOm(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFNkji(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFNkji(self, "All words must be at least 3 characters !", title=title)
        return
     VVKieG = CCvNDE()
     if CFG.hideIptvServerAdultWords.getValue() and VVKieG.VV7AR0(words):
      FFNkji(self, VVKieG.VVuZVs(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CC4A0C, barTheme=CC4A0C.VVo57g
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VV4aoj, VVMsCC, mode, title, words, toFind, asPrefix, VVKieG)
          , VVJcVO = BF(self.VV8XbC, mode, toFind, title))
   if not words:
    FFMnBb(VVMsCC, "Nothing to find !", 1500)
 def VV4aoj(self, VVMsCC, mode, title, words, toFind, asPrefix, VVKieG, VVbrNS):
  VVbrNS.VVdoFu(VVMsCC.VVPmHc())
  VVbrNS.VV4mwj = []
  for row in VVMsCC.VVy2g3():
   catName = row[0]
   catID = row[1]
   if not VVbrNS or VVbrNS.isCancelled:
    return
   VVbrNS.VV0CXi(1)
   VVbrNS.VVzqj2(catName)
   qUrl  = self.VVS35w(mode, self.VVr5xsData["playListURL"], catID)
   txt, err = self.VVsGVC(qUrl)
   if not err:
    tList, err = self.VVpYh1(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVKieG.VVFRrn(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVQYMA:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        VVbrNS.VV4mwj.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVVDBH:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        VVbrNS.VV4mwj.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVobfF:
        num, name, catID, ID, genre, dur, ext, cover = item
        VVbrNS.VV4mwj.append((num, name, catID, ID, genre, catName, ext, cover))
 def VV8XbC(self, mode, toFind, title, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if VV4mwj:
   title = self.VVcF6a(mode, toFind)
   if mode == self.VVQYMA or mode == self.VVVDBH:
    if mode == self.VVVDBH : typ = "v"
    else          : typ = ""
    bName   = CC5Be5.VVGOKA(toFind)
    VVBh0a  = ("Play"     , BF(self.VVEG7s, mode)      , [])
    VV1NOm = ("Download Options" , BF(self.VV1wZQ, mode, typ, "")  , [])
    VVfzl8 = ("Options"   , BF(self.VVNwuk, 1, "fnd", mode, bName) , [])
   elif mode == self.VVobfF:
    VVBh0a  = ("Show Seasons"  , BF(self.VVIJ5L, mode)      , [])
    VVfzl8 = None
    VV1NOm = None
   VV9ZE5  = (""     , BF(self.VV9sJr, mode)     , [])
   VV6i1u  = ("Home Menu"   , FFDRAB           , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVKrzB  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVMsCC = FFGcVX(self, None, title=title, header=header, VVJXpL=VV4mwj, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VV9ZE5=VV9ZE5, VVcV6s="#0a00292B", VV89EB="#0a002126", VVHzNF="#0a002126", VVhGFp="#00000000", VVLHme=True, searchCol=1)
   if not VVTgbE:
    FFMnBb(VVMsCC, "Stopped" , 1000)
  else:
   if VVTgbE:
    FFNkji(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVYfcX(self, mode, colList):
  if mode in (self.VVQYMA, self.VVkCGN):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVVDBH:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFYfxZ(chName)
  url = self.VVr5xsData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVZNOQ(url)
  refCode = self.VVW8Zc(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV9sJr(self, mode, VVMsCC, title, txt, colList):
  FFOvQF(VVMsCC, BF(self.VVX8G4, mode, VVMsCC, title, txt, colList))
 def VVX8G4(self, mode, VVMsCC, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVYfcX(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFRDSd(self, fncMode=CCGnOY.VVEc4k, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVJg0U(self, mode, VVMsCC, title, txt, colList):
  FFOvQF(VVMsCC, BF(self.VVfKO7, mode, VVMsCC, title, txt, colList))
 def VVfKO7(self, mode, VVMsCC, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFRDSd(self, fncMode=CCGnOY.VV7yBK, chName=name, text=txt, picUrl=Cover)
 def VV1wZQ(self, mode, typ, seriesName, VVMsCC, title, txt, colList):
  VVWp2B = []
  isMulti = VVMsCC.VVE8N3
  tot  = VVMsCC.VVtQKr()
  if isMulti:
   if tot < 1:
    FFMnBb(VVMsCC, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVWp2B.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVWp2B.append(VVEgY4)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVWp2B.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVWp2B.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVWp2B.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCuF83.VV9YR3():
    VVWp2B.append(VVEgY4)
    VVWp2B.append(("Download Manager"      , "dload_stat" ))
  FFkkcl(self, BF(self.VVsaNf, VVMsCC, mode, typ, seriesName, colList), title="Download Options", VVWp2B=VVWp2B)
 def VVsaNf(self, VVMsCC, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVmQVj(VVMsCC, mode)
   elif item == "dnldSel"  : self.VV3UIz(VVMsCC, mode, typ, colList, True)
   elif item == "addSel"  : self.VV3UIz(VVMsCC, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV47jc(VVMsCC, mode, typ, seriesName)
   elif item == "dload_stat" : CCuF83.VVQEJc(self)
 def VV3UIz(self, VVMsCC, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVglAf(mode, typ, colList)
  if startDnld:
   CCuF83.VVWoDJ(self, decodedUrl)
  else:
   self.VVFLOY(VVMsCC, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV47jc(self, VVMsCC, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVMsCC.VVy2g3():
   chName, decodedUrl = self.VVglAf(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVFLOY(VVMsCC, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVFLOY(self, VVMsCC, title, chName, decodedUrl_list, startDnld):
  FFm5Au(self, BF(self.VVAESi, VVMsCC, decodedUrl_list, startDnld), chName, title=title)
 def VVAESi(self, VVMsCC, decodedUrl_list, startDnld):
  added, skipped = CCuF83.VVgy6A(decodedUrl_list)
  FFMnBb(VVMsCC, "Added", 1000)
 def VVglAf(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVYfcX(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVfYMl(mode, colList)
   refCode, chUrl = self.VV0fot(self.VVfW7f, self.VVGOxv, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FF2PL9(chUrl)
  return chName, decodedUrl
 def VVmQVj(self, VVMsCC, mode):
  if os.system(FFBSzC("which ffmpeg")) == 0:
   self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VV47vm, VVMsCC, mode)
       , VVJcVO = self.VVtXH1)
  else:
   FFm5Au(self, BF(CC5Be5.VVoJaF, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVtXH1(self, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VV4mwj["proces"], VV4mwj["total"])
  txt += "Download Success\t: %d of %s\n"  % (VV4mwj["ok"], VV4mwj["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VV4mwj["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VV4mwj["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VV4mwj["badURL"]
  txt += "Download Failure\t: %d\n"   % VV4mwj["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VV4mwj["path"]
  if not VVTgbE  : color = "#11402000"
  elif VV4mwj["err"]: color = "#11201000"
  else     : color = None
  if VV4mwj["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VV4mwj["err"], txt)
  title = "PIcons Download Result"
  if not VVTgbE:
   title += "  (cancelled)"
  FFzNhe(self, txt, title=title, VVHzNF=color)
 def VV47vm(self, VVMsCC, mode, VVbrNS):
  isMulti = VVMsCC.VVE8N3
  if isMulti : totRows = VVMsCC.VVtQKr()
  else  : totRows = VVMsCC.VVPmHc()
  VVbrNS.VVdoFu(totRows)
  VVbrNS.VVr4Jf(0)
  counter     = VVbrNS.counter
  maxValue    = VVbrNS.maxValue
  pPath     = CCgJhP.VVkis2()
  VVbrNS.VV4mwj = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVMsCC.VVy2g3()):
    if VVbrNS.isCancelled:
     break
    if not isMulti or VVMsCC.VVC1Rc(rowNum):
     VVbrNS.VV4mwj["proces"] += 1
     VVbrNS.VV0CXi(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVfYMl(mode, row)
      refCode = CC5Be5.VVW8Zc(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVy3O2(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVYfcX(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVbrNS.VV4mwj["attempt"] += 1
       path, err = FFhNjK(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVbrNS:
         VVbrNS.VV4mwj["ok"] += 1
         VVbrNS.VVr4Jf(VVbrNS.VV4mwj["ok"])
        if FFHaPS(path) > 0:
         cmd = CCGnOY.VVW24u(path)
         cmd += FFBSzC("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVbrNS:
          VVbrNS.VV4mwj["size0"] += 1
         os.system(FFBSzC("rm -f '%s'" % path))
       elif err:
        if VVbrNS:
         VVbrNS.VV4mwj["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVbrNS:
          VVbrNS.VV4mwj["err"] = err.title()
         break
      else:
       if VVbrNS:
        VVbrNS.VV4mwj["exist"] += 1
     else:
      if VVbrNS:
       VVbrNS.VV4mwj["badURL"] += 1
  except:
   pass
 def VV9JMx(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFBSzC("which ffmpeg")) == 0:
   self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
       , titlePrefix = ""
       , fncToRun  = self.VVEkv4
       , VVJcVO = BF(self.VVL3uc, title))
  else:
   FFm5Au(self, BF(CC5Be5.VVoJaF, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVEkv4(self, VVbrNS):
  bName = CC0dGf.VV4fhK()
  pPath = CCgJhP.VVkis2()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVbrNS.VV4mwj = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CC0dGf.VVuizt()
  if not VVbrNS or VVbrNS.isCancelled:
   return
  if not services or len(services) == 0:
   VVbrNS.VV4mwj = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVbrNS.VVdoFu(totCh)
  VVbrNS.VVr4Jf(0)
  for serv in services:
   if not VVbrNS or VVbrNS.isCancelled:
    return
   VVbrNS.VV4mwj = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVbrNS.VV0CXi(1)
   VVbrNS.VVr4Jf(totPic)
   fullRef  = serv[0]
   if FFmwez(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FF2PL9(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCFpLh.VVLS7h(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CC5Be5.VVTRui(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC5Be5.VVsGVC(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCGnOY.VVRosH(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFhNjK(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVbrNS:
     VVbrNS.VVr4Jf(totPic)
    if FFHaPS(path) > 0:
     cmd = CCGnOY.VVW24u(path)
     cmd += FFBSzC("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     os.system(FFBSzC("rm -f '%s'" % path))
  if VVbrNS:
   VVbrNS.VV4mwj = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVL3uc(self, title, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VV4mwj
  if err:
   FFNkji(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFtSnl(str(totExist)  , VVpqRv)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFtSnl(str(totNotIptv)  , VVpqRv)
    if totServErr : txt += "Server Errors\t: %s\n" % FFtSnl(str(totServErr) + t1, VVpqRv)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFtSnl(str(totParseErr) , VVpqRv)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFtSnl(str(totInvServ)  , VVpqRv)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFtSnl(str(totInvPicUrl) , VVpqRv)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFtSnl(str(totSize0)  , VVpqRv)
   if not VVTgbE:
    title += "  (stopped)"
   FFzNhe(self, txt, title=title)
 @staticmethod
 def VVoJaF(SELF):
  cmd = FFWksx(VVRzYh, "ffmpeg")
  if cmd : FF355v(SELF, cmd, title="Installing FFmpeg")
  else : FFdMgN(SELF)
 def VV9tEU(self):
  self.session.open(CC4A0C, barTheme=CC4A0C.VVMNNJ
      , titlePrefix = ""
      , fncToRun  = self.VVjmSn
      , VVJcVO = self.VV9e4Y)
 def VVjmSn(self, VVbrNS):
  bName = CC0dGf.VV4fhK()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVbrNS.VV4mwj = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CC0dGf.VVuizt()
  if not VVbrNS or VVbrNS.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVbrNS.VVdoFu(totCh)
   for serv in services:
    if not VVbrNS or VVbrNS.isCancelled:
     return
    VVbrNS.VV0CXi(1)
    fullRef = serv[0]
    if FFmwez(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FF2PL9(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCFpLh.VVLS7h(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CC5Be5.VVTRui(m3u_Url)
     if VVbrNS:
      VVbrNS.VV4ADa(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CC5Be5.VVDkY9(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCGnOY.VVI9AV(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVbrNS:
     VVbrNS.VV4mwj = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVbrNS.VV4mwj = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VV9e4Y(self, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VV4mwj
  title = "IPTV EPG Import"
  if err:
   FFNkji(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFtSnl(str(totNotIptv), VVpqRv)
    if totServErr : txt += "Server Errors\t: %s\n" % FFtSnl(str(totServErr) + t1, VVpqRv)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFtSnl(str(totInv), VVpqRv)
   if not VVTgbE:
    title += "  (stopped)"
   FFzNhe(self, txt, title=title)
 @staticmethod
 def VVDkY9(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC5Be5.VVZNOQ(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC5Be5.VVsGVC(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC5Be5.VVlB8q(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CC5Be5.VVlB8q(item, "lang"        ).upper()
    now_playing   = CC5Be5.VVlB8q(item, "now_playing"      )
    start    = CC5Be5.VVlB8q(item, "start"        )
    start_timestamp  = CC5Be5.VVlB8q(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC5Be5.VVlB8q(item, "start_timestamp"     )
    stop_timestamp  = CC5Be5.VVlB8q(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC5Be5.VVlB8q(item, "stop_timestamp"      )
    tTitle    = CC5Be5.VVlB8q(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVW8Zc(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC5Be5.VVrW3Z(catID, MAX_4b)
  TSID = CC5Be5.VVrW3Z(chNum, MAX_4b)
  ONID = CC5Be5.VVrW3Z(chNum, MAX_4b)
  NS  = CC5Be5.VVrW3Z(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVrW3Z(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVGOKA(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVxWU4(mode):
  if   mode in ("itv"  , CC5Be5.VVPpHH)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC5Be5.VVMzCK)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC5Be5.VVFitc) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC5Be5.VVqDkv) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC5Be5.VVkCGN    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVPw9t(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VV2lDQ:
   excl = FFizMC(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFNkji(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FF42E1('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFNkji(self, err)
  elif len(files) == 1 and files[0] == VVq1UG:
   FFNkji(self, VVq1UG)
  else:
   return files
 @staticmethod
 def VVovQ1():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFjGgP(path)
  return "/"
 @staticmethod
 def VVKUGt(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CC5Be5.VVDkY9(hostUrl, streamId, True)
  title = "Catchup TV Programs"
  if err:
   FFNkji(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVcV6s, VV89EB, VVHzNF, VVhGFp = CC5Be5.VVxWU4("")
   VV6i1u = ("Home Menu" , FFDRAB, [])
   VVBh0a  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVKrzB  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFGcVX(SELF, None, title="Programs for : " + chName, header=header, VVJXpL=pList, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=24, VVBh0a=VVBh0a, VV6i1u=VV6i1u, VVcV6s=VVcV6s, VV89EB=VV89EB, VVHzNF=VVHzNF, VVhGFp=VVhGFp)
  else:
   FFNkji(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVgc6R(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVQyOy(SELF, isPortal, line, VVW8faObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC5Be5.VVovQ1()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFNkji(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFO5iz(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFNkji(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVNwuk(self, nameCol, source, mode, curBName, VVMsCC, title, txt, colList):
  isMulti = VVMsCC.VVE8N3
  mSel = CCiNIs(self, VVMsCC, nameCol, addSep=False)
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVMsCC.VVtQKr()
   totTxt = "%d Service%s" % (tot, "s" if tot > 1 else "")
   if tot < 1:
    itemsOK = False
  totTxt = FFtSnl(totTxt, VVFeau)
  if itemsOK:
   mSel.VVWp2B.append(VVEgY4)
   mSel.VVWp2B.append(("Add %s to New Bouquet : %s" % (totTxt, FFtSnl(curBName, VV41YE)), "addToCur"))
   mSel.VVWp2B.append(("Add %s to Other Bouquet ..." % (totTxt)          , "addToNew"))
  FFkkcl(self, BF(self.VVc86V, mSel, source, mode, curBName, VVMsCC), title="Options", VVWp2B=mSel.VVWp2B, VV83XM=True)
 def VVc86V(self, mSel, source, mode, curBName, VVMsCC, item):
  if item:
   title, ref, ndx = item
   if   ref == "multSelEnab" : mSel.VVMsCC.VVDdFZ(True)
   elif ref == "MultSelDisab" : mSel.VVMsCC.VVDdFZ(False)
   elif ref == "selectAll"  : mSel.VVMsCC.VV6pI2()
   elif ref == "unselectAll" : mSel.VVMsCC.VVR1Jm()
   elif ref == "addToCur"  : FFOvQF(mSel.VVMsCC, BF(self.VVuh0E,source, mode, curBName, VVMsCC, title), title="Adding Services ...")
   elif ref == "addToNew"  : self.VVU1Ib(source, mode, curBName, VVMsCC, title)
 def VVuh0E(self, source, mode, curBName, VVMsCC, Title):
  chUrlLst = self.VVcvlN(source, mode, VVMsCC)
  CC0dGf.VVqGMw(self, Title, curBName, "", chUrlLst)
 def VVU1Ib(self, source, mode, curBName, VVMsCC, Title):
  picker = CC0dGf(self, VVMsCC, Title, BF(self.VVcvlN, source, mode, VVMsCC), defBName=curBName)
 def VVcvlN(self, source, mode, VVMsCC):
  totChange = 0
  isMulti = VVMsCC.VVE8N3
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVMsCC.VVy2g3()):
   if not isMulti or VVMsCC.VVC1Rc(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVfYMl(mode, row)
     refCode, chUrl = self.VV0fot(self.VVfW7f, self.VVGOxv, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VV8MUJ(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVYfcX(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 def VVLN7n(self, txt):
  CFG.lastFindIptv.setValue(txt)
  CFG.lastFindIptv.save()
  configfile.save()
class CCgWhv(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVVrxs  = 0
  self.VV4SuV = 1
  self.VVQTp0  = 2
  VVWp2B = []
  VVWp2B.append(("Find in All Service (from filter)" , "VVxFxA" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Find in All (Manual Entry)"   , "VVNI7W"    ))
  VVWp2B.append(("Find in TV"       , "VVmCPU"    ))
  VVWp2B.append(("Find in Radio"      , "VVHSvs"   ))
  if self.VVAoDS():
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Hide Channel: %s" % self.servName , "VVbdti"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Zap History"       , "VVqgiK"    ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("IPTV Tools"       , "iptv"      ))
  VVWp2B.append(("PIcons Tools"       , "PIconsTools"     ))
  VVWp2B.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FF2wUT(self, VVWp2B=VVWp2B, title=title)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self)
  if self.isFindMode:
   self.VVeQiy(self.VVUK81())
 def VVxkj1(self):
  global VVqmOn
  VVqmOn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVNI7W"    : self.VVNI7W()
   elif item == "VVxFxA" : self.VVxFxA()
   elif item == "VVmCPU"    : self.VVmCPU()
   elif item == "VVHSvs"   : self.VVHSvs()
   elif item == "VVbdti"   : self.VVbdti()
   elif item == "VVqgiK"    : self.VVqgiK()
   elif item == "iptv"       : self.session.open(CC5Be5)
   elif item == "PIconsTools"     : self.session.open(CCgJhP)
   elif item == "ChannelsTools"    : self.session.open(CCabmO)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVmCPU(self) : self.VVeQiy(self.VVVrxs)
 def VVHSvs(self) : self.VVeQiy(self.VV4SuV)
 def VVNI7W(self) : self.VVeQiy(self.VVQTp0)
 def VVeQiy(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFhzot(self, BF(self.VVy75I, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVxFxA(self):
  filterObj = CCG8u1(self)
  filterObj.VVYsxj(self.VVVN9i)
 def VVVN9i(self, item):
  self.VVy75I(self.VVQTp0, item)
 def VVAoDS(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFmwez(self.refCode)        : return False
  return True
 def VVy75I(self, mode, VVjKrF):
  FFOvQF(self, BF(self.VVLlFd, mode, VVjKrF), title="Searching ...")
 def VVLlFd(self, mode, VVjKrF):
  if VVjKrF:
   VVjKrF = VVjKrF.strip()
  if VVjKrF:
   self.findTxt = VVjKrF
   CFG.lastFindContextFind.setValue(VVjKrF)
   if   mode == self.VVVrxs  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV4SuV : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVjKrF)
   if len(title) > 55:
    title = title[:55] + ".."
   VVMGU8 = self.VVEIeY(VVjKrF, servTypes)
   if self.isFindMode or mode == self.VVQTp0:
    VVMGU8 += self.VVLUoV(VVjKrF)
   if VVMGU8:
    VVMGU8.sort(key=lambda x: x[0].lower())
    VVOTt1 = self.VVTlby
    VVBh0a  = ("Zap"   , self.VVbKU1    , [])
    VV1NOm = ("Current Service", self.VVhd6k , [])
    VVfzl8 = ("Options"  , self.VVjnJW , [])
    VV9ZE5 = (""    , self.VVJANx , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVKrzB  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFGcVX(self, None, title=title, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VVOTt1=VVOTt1, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VV9ZE5=VV9ZE5, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVeQiy(self.VVUK81())
    FFO5iz(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVEIeY(self, VVjKrF, servTypes):
  VVJXpL = CCabmO.VVxkb1(servTypes)
  VVMGU8 = []
  if VVJXpL:
   VVS8sI, VVT9kk = FFD0f0()
   tp = CCW6PA()
   words, asPrefix = CCG8u1.VVStOm(VVjKrF)
   colorYellow  = CCJoLU.VVBZ2S(VVxbdF)
   colorWhite  = CCJoLU.VVBZ2S(VVXldd)
   for s in VVJXpL:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFzd48(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVS8sI:
        STYPE = VVT9kk[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVxpjn(refCode)
       if not "-S" in syst:
        sat = syst
       VVMGU8.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVMGU8
 def VVLUoV(self, VVjKrF):
  VVjKrF = VVjKrF.lower()
  VVMGU8 = []
  colorYellow  = CCJoLU.VVBZ2S(VVxbdF)
  colorWhite  = CCJoLU.VVBZ2S(VVXldd)
  for b in CC0dGf.VVmtoG():
   VVbzVm  = b[0]
   VVHR8t  = b[1].toString()
   VVckRJ = eServiceReference(VVHR8t)
   VViYKE = FF1xYh(VVckRJ)
   for service in VViYKE:
    refCode  = service[0]
    if FFmwez(refCode):
     servName = service[1]
     if VVjKrF in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVjKrF), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVMGU8.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVMGU8
 def VVUK81(self):
  VVe94g = InfoBar.instance
  if VVe94g:
   VVNETX = VVe94g.servicelist
   if VVNETX:
    return VVNETX.mode == 1
  return self.VVQTp0
 def VVTlby(self, VVMsCC):
  self.close()
  VVMsCC.cancel()
 def VVbKU1(self, VVMsCC, title, txt, colList):
  FFQ5yd(VVMsCC, colList[2], VVz7YZ=False, checkParentalControl=True)
 def VVhd6k(self, VVMsCC, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(VVMsCC)
  if refCode:
   VVMsCC.VV6kaZ(2, FFwmMJ(refCode, iptvRef, chName), True)
 def VVjnJW(self, VVMsCC, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCiNIs(self, VVMsCC, 2)
  mSel.VVLK10(servName, refCode)
 def VVJANx(self, VVMsCC, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFRDSd(self, fncMode=CCGnOY.VVsjxB, refCode=refCode, chName=chName, text=txt)
 def VVbdti(self):
  FFm5Au(self, self.VVkkkC, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVkkkC(self):
  ret = FFWbo4(self.refCode, True)
  if ret:
   self.VVHwff()
   self.close()
  else:
   FFMnBb(self, "Cannot change state" , 1000)
 def VVHwff(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVHlrm()
  except:
   self.VVGpif()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFL1Gi(self, serviceRef)
 def VVDFLW(self):
  VVe94g = InfoBar.instance
  if VVe94g:
   VVNETX = VVe94g.servicelist
   if VVNETX:
    VVNETX.setMode()
 def VVHlrm(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVe94g = InfoBar.instance
   if VVe94g:
    VVNETX = VVe94g.servicelist
    if VVNETX:
     hList = VVNETX.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVNETX.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVNETX.history  = newList
       VVNETX.history_pos = pos
 def VVGpif(self):
  VVe94g = InfoBar.instance
  if VVe94g:
   VVNETX = VVe94g.servicelist
   if VVNETX:
    VVNETX.history  = []
    VVNETX.history_pos = 0
 def VVqgiK(self):
  VVe94g = InfoBar.instance
  VVMGU8 = []
  if VVe94g:
   VVNETX = VVe94g.servicelist
   if VVNETX:
    VVS8sI, VVT9kk = FFD0f0()
    for serv in VVNETX.history:
     refCode = serv[-1].toString()
     chName = FFBfr9(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFmwez(refCode)
     if   isIptv or isLocal : sat = "-"
     else     : sat = FFzd48(refCode, True)
     if isIptv : STYPE = "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVS8sI:
       STYPE = VVT9kk[sTypeInt]
     VVMGU8.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVMGU8:
   VVBh0a  = ("Zap"   , self.VVGUD5   , [])
   VVfzl8 = ("Clear History" , self.VVzwnV   , [])
   VV9ZE5 = (""    , self.VVGOPH , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVKrzB  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFGcVX(self, None, title=title, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=28, VVBh0a=VVBh0a, VVfzl8=VVfzl8, VV9ZE5=VV9ZE5)
  else:
   FFO5iz(self, "Not found", title=title)
 def VVGUD5(self, VVMsCC, title, txt, colList):
  FFQ5yd(VVMsCC, colList[3], VVz7YZ=False, checkParentalControl=True)
 def VVzwnV(self, VVMsCC, title, txt, colList):
  FFm5Au(self, BF(self.VV4Y7I, VVMsCC), "Clear Zap History ?")
 def VV4Y7I(self, VVMsCC):
  self.VVGpif()
  VVMsCC.cancel()
 def VVGOPH(self, VVMsCC, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFRDSd(self, fncMode=CCGnOY.VVqTVj, refCode=refCode, chName=chName, text=txt)
class CCgJhP(Screen):
 VVyNAj   = 0
 VVUHpV  = 1
 VVM5jm  = 2
 VVJxbJ  = 3
 VVUHZ9  = 4
 VVGouI  = 5
 VVGUO8  = 6
 VVEexC  = 7
 VVnQRT = 8
 VVj7uo = 9
 VV7CmU = 10
 VVv9vd = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFbZTb(VVQjBQ, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF2wUT(self, self.Title)
  FF4HaE(self["keyRed"] , "OK = Zap")
  FF4HaE(self["keyGreen"] , "Current Service")
  FF4HaE(self["keyYellow"], "Page Options")
  FF4HaE(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCgJhP.VVkis2()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVJXpL    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVJCaE     ,
   "green"   : self.VV4DCV    ,
   "yellow"  : self.VVKey2     ,
   "blue"   : self.VV7A49     ,
   "menu"   : self.VVE1GE     ,
   "info"   : self.VV4CkR    ,
   "up"   : self.VVRYLD       ,
   "down"   : self.VVk2gz      ,
   "left"   : self.VVmpQP      ,
   "right"   : self.VVV9jd      ,
   "pageUp"  : BF(self.VVit3Q, True) ,
   "chanUp"  : BF(self.VVit3Q, True) ,
   "pageDown"  : BF(self.VVit3Q, False) ,
   "chanDown"  : BF(self.VVit3Q, False) ,
   "next"   : self.VVCdOb     ,
   "last"   : self.VVzAcr      ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFGCUP(self)
  FFLvNc(self)
  FFQZ4f(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFOvQF(self, BF(self.VVvo7U, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVE1GE(self):
  if not self.isBusy:
   VVWp2B = []
   VVWp2B.append(("Statistics"           , "VVYgFZ"    ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Suggest PIcons for Current Channel"     , "VVNVM2"   ))
   VVWp2B.append(("Set to Current Channel (copy file)"     , "VVW9vR_file"  ))
   VVWp2B.append(("Set to Current Channel (as SymLink)"     , "VVW9vR_link"  ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Export Current File Names List"      , "VVmg9a" ))
   VVWp2B.append(CCgJhP.VV6b2T())
   VVWp2B.append(VVEgY4)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVFkfi
    VVWp2B.append((c + movTxt           , "VVm9dw"  ))
    VVWp2B.append((c + delTxt           , "VVJ7SQ" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVWp2B.append((movTxt + disTxt         ,       ))
    VVWp2B.append((delTxt + disTxt         ,       ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVUndv"  ))
   VVWp2B.append(VVEgY4)
   VVWp2B += CCgJhP.VVA6FY()
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Keys Help"           , "VVAWyE"    ))
   FFkkcl(self, self.VVe7u5, width=1100, height=1050, title=self.Title, VVWp2B=VVWp2B)
 def VVe7u5(self, item=None):
  if item is not None:
   if   item == "VVYgFZ"     : self.VVYgFZ()
   elif item == "VVNVM2"    : self.VVNVM2()
   elif item == "VVW9vR_file"   : self.VVW9vR(0)
   elif item == "VVW9vR_link"   : self.VVW9vR(1)
   elif item == "VVmg9a"   : self.VVmg9a()
   elif item == "VV1grA"   : CCgJhP.VV1grA(self)
   elif item == "VVm9dw"    : self.VVm9dw()
   elif item == "VVJ7SQ"   : self.VVJ7SQ()
   elif item == "VVUndv"   : self.VVUndv()
   elif item == "VVKwF6"   : CCgJhP.VVKwF6(self)
   elif item == "findPiconBrokenSymLinks"  : CCgJhP.VVhF3a(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCgJhP.VVhF3a(self, False)
   elif item == "VVAWyE"      : self.VVAWyE()
 def VVKey2(self):
  if not self.isBusy:
   VVWp2B = []
   VVWp2B.append(("Go to First PIcon"  , "VVqEQZ"  ))
   VVWp2B.append(("Go to Last PIcon"   , "VVypYE"  ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Sort by Channel Name"     , "sortByChan" ))
   VVWp2B.append(("Sort by File Name"  , "sortByFile" ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Find from File List .." , "VVBMA1" ))
   FFkkcl(self, self.VVJ2z6, title=self.Title, VVWp2B=VVWp2B)
 def VVJ2z6(self, item=None):
  if item is not None:
   if   item == "VVqEQZ"   : self.VVqEQZ()
   elif item == "VVypYE"   : self.VVypYE()
   elif item == "sortByChan"  : self.VVHTAy(2)
   elif item == "sortByFile"  : self.VVHTAy(0)
   elif item == "VVBMA1"  : self.VVBMA1()
 def VVAWyE(self):
  FFXRcG(self, VVE4he + "_help_picons", "PIcons Tools (Keys Help)")
 def VVRYLD(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVypYE()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV2FCp()
 def VVk2gz(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVqEQZ()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV2FCp()
 def VVmpQP(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVypYE()
  else:
   self.curCol -= 1
   self.VV2FCp()
 def VVV9jd(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVqEQZ()
  else:
   self.curCol += 1
   self.VV2FCp()
 def VVzAcr(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV2FCp(True)
 def VVCdOb(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV2FCp(True)
 def VVqEQZ(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV2FCp(True)
 def VVypYE(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV2FCp(True)
 def VVBMA1(self):
  VVWp2B = []
  for item in self.VVJXpL:
   VVWp2B.append((item[0], item[0]))
  FFkkcl(self, self.VVX1xH, title='PIcons ".png" Files', VVWp2B=VVWp2B, VV83XM=True)
 def VVX1xH(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVvou0(ndx)
 def VVJCaE(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVU5Qy()
   if refCode:
    FFQ5yd(self, refCode)
    self.VV6Kea()
    self.VVSdna()
 def VVit3Q(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VV6Kea()
   self.VVSdna()
  except:
   pass
 def VV4DCV(self):
  if self["keyGreen"].getVisible():
   self.VVvou0(self.curChanIndex)
 def VVvou0(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV2FCp(True)
  else:
   FFMnBb(self, "Not found", 1000)
 def VVHTAy(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFOvQF(self, BF(self.VVvo7U, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVW9vR(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVU5Qy()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVWp2B = []
     VVWp2B.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVWp2B.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFkkcl(self, BF(self.VVmFAf, mode, curChF, selPiconF), VVWp2B=VVWp2B, title="Current Channel PIcon (already exists)")
    else:
     self.VVmFAf(mode, curChF, selPiconF, "overwrite")
   else:
    FFNkji(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFNkji(self, "Could not read current channel info. !", title=title)
 def VVmFAf(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFOvQF(self, BF(self.VVvo7U, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVm9dw(self):
  defDir = FFjGgP(CCgJhP.VVkis2() + "picons_backup")
  os.system(FFBSzC("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVHDGt, defDir), BF(CC0Jp1
         , mode=CC0Jp1.VVahR0, VV4wg8=CCgJhP.VVkis2()))
 def VVHDGt(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCgJhP.VVkis2():
    FFNkji(self, "Cannot move to same directory !", title=title)
   else:
    if not FFjGgP(path) == FFjGgP(defDir):
     self.VVe60l(defDir)
    FFm5Au(self, BF(FFOvQF, self, BF(self.VViUBO, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVJXpL), path), title=title)
  else:
   self.VVe60l(defDir)
 def VViUBO(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVe60l(defDir)
   FFNkji(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFjGgP(toPath)
  pPath = CCgJhP.VVkis2()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVJXpL:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVJXpL)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFzNhe(self, txt, title=title, VVHzNF="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVWvpL("all")
 def VVe60l(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVJ7SQ(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVJXpL)
  s = "s" if tot > 1 else ""
  FFm5Au(self, BF(FFOvQF, self, BF(self.VV6YhR, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VV6YhR(self, title):
  pPath = CCgJhP.VVkis2()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVJXpL:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVJXpL)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFtSnl(str(totErr), VVpqRv)
  FFzNhe(self, txt, title=title)
 def VVUndv(self):
  lines = FF42E1("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFm5Au(self, BF(self.VV0ml5, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVYN57=True)
  else:
   FFO5iz(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV0ml5(self, fList):
  os.system(FFBSzC("find -L '%s' -type l -delete" % self.pPath))
  FFO5iz(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV4CkR(self):
  FFOvQF(self, self.VVxbxl)
 def VVxbxl(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVU5Qy()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFtSnl("PIcon Directory:\n", VVMXOB)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFaFe3(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFaFe3(path)
   txt += FFtSnl("PIcon File:\n", VVMXOB)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FF42E1(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFtSnl("Found %d SymLink%s to this file from:\n" % (tot, s), VVMXOB)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFBfr9(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFtSnl(tChName, VV41YE)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFtSnl(line, VVpi4Z), tChName)
    txt += "\n"
   if chName:
    txt += FFtSnl("Channel:\n", VVMXOB)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFtSnl(chName, VV41YE)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFtSnl("Remarks:\n", VVMXOB)
    txt += "  %s\n" % FFtSnl("Unused", VVpqRv)
  else:
   txt = "No info found"
  FFRDSd(self, fncMode=CCGnOY.VVyEEB, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVU5Qy(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVJXpL[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFwTSp(sat)
  return fName, refCode, chName, sat, inDB
 def VV6Kea(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVJXpL):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVSdna(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVU5Qy()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFtSnl("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVMXOB))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVU5Qy()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFtSnl(self.curChanName, VVxbdF)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVYgFZ(self):
  VVS8sI, VVT9kk = FFD0f0()
  sTypeNameDict = {}
  for key, val in VVT9kk.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVJXpL:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVT9kk: sTypeDict[VVT9kk[stNum]] = sTypeDict.get(VVT9kk[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFrbAO("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVMGU8 = []
  c = "#b#11003333#"
  VVMGU8.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalPIcons, totUsedFiles + totUsedLinks)))
  VVMGU8.append((c + "Files" , "%d\tUsed = %s" % (self.totalPIcons - totSymLinks, totUsedFiles)))
  VVMGU8.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVMGU8.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVMGU8.append((c + "Not In Database (lamedb)" , str(self.totalPIcons - totInDB)))
  VVMGU8.append((c + "Satellites"    , str(len(self.nsList))))
  VVMGU8.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVMGU8.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVMGU8.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVMGU8.extend(sTypeRows)
  FFGcVX(self, None, title=self.Title, VVJXpL=VVMGU8, VVlOla=28, VVhGFp="#00003333", VV3VgO="#00222222")
 def VVmg9a(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFjGgP(CFG.exportedTablesPath.getValue()), txt, FF03bo())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVJXpL:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFO5iz(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VV7A49(self):
  if not self.isBusy:
   VVWp2B = []
   VVWp2B.append(("All"         , "all"   ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Used by Channels"      , "used"  ))
   VVWp2B.append(("Unused PIcons"      , "unused"  ))
   VVWp2B.append(("IPTV PIcons"       , "iptv"  ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("PIcons Files"       , "pFiles"  ))
   VVWp2B.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVWp2B.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVWp2B.append(("By Files Date ..."     , "pDate"  ))
   VVWp2B.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVWp2B.append(FFhiR0("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFc8os(val)
      VVWp2B.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCG8u1(self)
   filterObj.VV2Jpr(VVWp2B, self.nsList, self.VV7N8Y)
 def VV7N8Y(self, item=None):
  if item is not None:
   self.VVWvpL(item)
 def VVWvpL(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVyNAj   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVUHpV   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVM5jm  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVGUO8   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVJxbJ  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVUHZ9  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVGouI  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV7CmU , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVv9vd , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVEexC   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVnQRT , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVGouI:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF42E1("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFRwag(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFMnBb(self, "Not found", 1000)
     return
   elif mode == self.VV7CmU:
    self.VVJ7Fn(mode)
    return
   elif mode == self.VVv9vd:
    self.VVIU1D(mode)
    return
   elif mode == self.VVj7uo:
    return
   else:
    words, asPrefix = CCG8u1.VVStOm(words)
   if not words and mode in (self.VVEexC, self.VVnQRT):
    FFMnBb(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFOvQF(self, BF(self.VVvo7U, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVJ7Fn(self, mode):
  VVWp2B = []
  VVWp2B.append(("Today"   , "today" ))
  VVWp2B.append(("Since Yesterday" , "yest" ))
  VVWp2B.append(("Since 7 days"  , "week" ))
  FFkkcl(self, BF(self.VVJ5J5, mode), VVWp2B=VVWp2B, title="Filter by Added/Modified Date")
 def VVJ5J5(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFhNVP(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFhNVP(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFhNVP(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFOvQF(self, BF(self.VVvo7U, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVIU1D(self, mode):
  VVS8sI, VVT9kk = FFD0f0()
  lst = set()
  for key, val in VVT9kk.items():
   lst.add(val)
  VVWp2B = []
  for item in lst:
   VVWp2B.append((item, item))
  VVWp2B.sort(key=lambda x: x[0])
  FFkkcl(self, BF(self.VVmtj3, mode), VVWp2B=VVWp2B, title="Filter by Service Type")
 def VVmtj3(self, mode, item=None):
  if item:
   VVS8sI, VVT9kk = FFD0f0()
   sTypeList = []
   for key, val in VVT9kk.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFOvQF(self, BF(self.VVvo7U, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVNVM2(self):
  self.session.open(CC4A0C, barTheme=CC4A0C.VVo57g
      , titlePrefix = ""
      , fncToRun  = self.VVxwJo
      , VVJcVO = self.VVLsXS)
 def VVxwJo(self, VVbrNS):
  VVGCEl, err = CCabmO.VVN2H3(self, CCabmO.VVaZOM, VVBmG6=False, VVkNHV=False)
  files = []
  words = []
  if not VVbrNS or VVbrNS.isCancelled:
   return
  VVbrNS.VV4mwj = []
  VVbrNS.VVdoFu(len(VVGCEl))
  if VVGCEl:
   VVKieG = CCvNDE()
   curCh = VVKieG.VV4Nkx(self.curChanName)
   for refCode in VVGCEl:
    if not VVbrNS or VVbrNS.isCancelled:
     return
    VVbrNS.VV0CXi(1, True)
    chName, sat, inDB = VVGCEl.get(refCode, ("", "", 0))
    ratio = CCgJhP.VVFPfC(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCgJhP.VV7g4q(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFRwag(f)
       VVbrNS.VV4mwj.append(f.replace(".png", ""))
 def VVLsXS(self, VVTgbE, VV4mwj, threadCounter, threadTotal, threadErr):
  if VV4mwj:
   self.timer = eTimer()
   fnc = BF(FFOvQF, self, BF(self.VVvo7U, mode=self.VVj7uo, words=VV4mwj), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFMnBb(self, "Not found", 2000)
 def VVvo7U(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VViLOF(isFirstTime):
   return
  self.isBusy = True
  VVkNHV = True if isFirstTime else False
  VVGCEl, err = CCabmO.VVN2H3(self, CCabmO.VVaZOM, VVBmG6=False, VVkNHV=VVkNHV)
  if err:
   self.close()
  iptvRefList = self.VV067v()
  tList = []
  for fName, fType in CCgJhP.VVxlTB(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVGCEl:
    if fName in VVGCEl:
     chName, sat, inDB = VVGCEl.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVyNAj:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVUHpV  and chName         : isAdd = True
   elif mode == self.VVM5jm and not chName        : isAdd = True
   elif mode == self.VVJxbJ  and fType == 0        : isAdd = True
   elif mode == self.VVUHZ9  and fType == 1        : isAdd = True
   elif mode == self.VVGouI  and fName in words       : isAdd = True
   elif mode == self.VVj7uo and fName in words       : isAdd = True
   elif mode == self.VVGUO8  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVEexC  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVnQRT:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV7CmU:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVv9vd:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVJXpL   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFMnBb(self)
  else:
   self.isBusy = False
   FFMnBb(self, "Not found", 1000)
   return
  self.VVJXpL.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV6Kea()
  self.totalPIcons = len(self.VVJXpL)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV2FCp(True)
 def VViLOF(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCgJhP.VVxlTB(self.pPath):
    if fName:
     return True
   if isFirstTime : FFNkji(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFMnBb(self, "Not found", 1000)
  else:
   FFNkji(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV067v(self):
  VVMGU8 = {}
  files  = CC5Be5.VVzeTw(self)
  if files:
   for path in files:
    txt = FFS3H9(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVMGU8[refCode] = item[1]
  return VVMGU8
 def VV2FCp(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVtjM8 = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVtjM8: self.curPage = VVtjM8
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VV5gD1()
  if self.curPage == VVtjM8:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVSdna()
  filName, refCode, chName, sat, inDB = self.VVU5Qy()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV5gD1(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVJXpL[ndx]
   fName = self.VVJXpL[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFtSnl(chName, VV41YE))
    else : lbl.setText("-")
   except:
    lbl.setText(FFtSnl(chName, VV31Rm))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVFPfC(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV6b2T():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VV1grA"   )
 @staticmethod
 def VVA6FY():
  VVWp2B = []
  VVWp2B.append(("Find SymLinks (to PIcon Directory)"   , "VVKwF6"   ))
  VVWp2B.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVWp2B.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVWp2B
 @staticmethod
 def VV1grA(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(SELF)
  png, path = CCgJhP.VVFfYi(refCode)
  if path : CCgJhP.VVEFxA(SELF, png, path)
  else : FFNkji(SELF, "No PIcon found for current channel in:\n\n%s" % CCgJhP.VVkis2())
 @staticmethod
 def VVKwF6(SELF):
  if VVxbdF:
   sed1 = FF7gKg("->", VVxbdF)
   sed2 = FF7gKg("picon", VVpqRv)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV31Rm, VVXldd)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFIhbm(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFizMC(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVhF3a(SELF, isPIcon):
  sed1 = FF7gKg("->", VV31Rm)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF7gKg("picon", VVpqRv)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFIhbm(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFizMC(), grep, sed1, sed2))
 @staticmethod
 def VVxlTB(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVkis2():
  path = CFG.PIconsPath.getValue()
  return FFjGgP(path)
 @staticmethod
 def VVFfYi(refCode, chName=None):
  if FFmwez(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FF2PL9(refCode)
  allPath, fName, refCodeFile, pList = CCgJhP.VV7g4q(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVEFxA(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF7gKg("%s%s" % (dest, png), VV41YE))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF7gKg(errTxt, VVG74s))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFxeLA(SELF, cmd)
 @staticmethod
 def VV7g4q(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCgJhP.VVkis2()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFYfxZ(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFRwag(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCd6rH():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVQzai  = None
  self.VVL8sL = ""
  self.VV6hGn  = noService
  self.VVSjMx = 0
  self.VVThzm  = noService
  self.VV0quV = 0
  self.VVIDSo  = "-"
  self.VVUPIC = 0
  self.VVpIsa  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVjgJP(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVQzai = frontEndStatus
     self.VVfmna()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVfmna(self):
  if self.VVQzai:
   val = self.VVQzai.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVL8sL = "%3.02f dB" % (val / 100.0)
   else         : self.VVL8sL = ""
   val = self.VVQzai.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVSjMx = int(val)
   self.VV6hGn  = "%d%%" % val
   val = self.VVQzai.get("tuner_signal_power" , 0) * 100 / 65536
   self.VV0quV = int(val)
   self.VVThzm  = "%d%%" % val
   val = self.VVQzai.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVIDSo  = "%d" % val
   val = int(val * 100 / 500)
   self.VVUPIC = min(500, val)
   val = self.VVQzai.get("tuner_locked", 0)
   if val == 1 : self.VVpIsa = "Locked"
   else  : self.VVpIsa = "Not locked"
 def VVwhT6(self)   : return self.VVL8sL
 def VVdy0Y(self)   : return self.VV6hGn
 def VVUu6W(self)  : return self.VVSjMx
 def VV0Jnp(self)   : return self.VVThzm
 def VVgf0V(self)  : return self.VV0quV
 def VVqeMO(self)   : return self.VVIDSo
 def VV2hCv(self)  : return self.VVUPIC
 def VV8jPk(self)   : return self.VVpIsa
 def VV1wtD(self) : return self.serviceName
class CCW6PA():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVRi2J(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFEzDT(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV4RSU(self.ORPOS  , mod=1   )
      self.sat2  = self.VV4RSU(self.ORPOS  , mod=2   )
      self.freq  = self.VV4RSU(self.FREQ  , mod=3   )
      self.sr   = self.VV4RSU(self.SR   , mod=4   )
      self.inv  = self.VV4RSU(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV4RSU(self.POL  , self.D_POL )
      self.fec  = self.VV4RSU(self.FEC  , self.D_FEC )
      self.syst  = self.VV4RSU(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV4RSU("modulation" , self.D_MOD )
       self.rolof = self.VV4RSU("rolloff"  , self.D_ROLOF )
       self.pil = self.VV4RSU("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV4RSU("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV4RSU("pls_code"  )
       self.iStId = self.VV4RSU("is_id"   )
       self.t2PlId = self.VV4RSU("t2mi_plp_id" )
       self.t2PId = self.VV4RSU("t2mi_pid"  )
 def VV4RSU(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFc8os(val)
  elif mod == 2   : return FF3aJg(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VV6UeG(self, refCode):
  txt = ""
  self.VVRi2J(refCode)
  if self.data:
   def VVZ1Gm(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVZ1Gm("System"   , self.syst)
    txt += VVZ1Gm("Satellite"  , self.sat2)
    txt += VVZ1Gm("Frequency"  , self.freq)
    txt += VVZ1Gm("Inversion"  , self.inv)
    txt += VVZ1Gm("Symbol Rate"  , self.sr)
    txt += VVZ1Gm("Polarization" , self.pol)
    txt += VVZ1Gm("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVZ1Gm("Modulation" , self.mod)
     txt += VVZ1Gm("Roll-Off" , self.rolof)
     txt += VVZ1Gm("Pilot"  , self.pil)
     txt += VVZ1Gm("Input Stream", self.iStId)
     txt += VVZ1Gm("T2MI PLP ID" , self.t2PlId)
     txt += VVZ1Gm("T2MI PID" , self.t2PId)
     txt += VVZ1Gm("PLS Mode" , self.plsMod)
     txt += VVZ1Gm("PLS Code" , self.plsCod)
   else:
    txt += VVZ1Gm("System"   , self.txMedia)
    txt += VVZ1Gm("Frequency"  , self.freq)
  return txt, self.namespace
 def VVoeZZ(self, refCode):
  txt = "Transpoder : ?"
  self.VVRi2J(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVxpjn(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFEzDT(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV4RSU(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV4RSU(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV4RSU(self.SYST, self.D_SYS_S)
     freq = self.VV4RSU(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV4RSU(self.POL , self.D_POL)
      fec = self.VV4RSU(self.FEC , self.D_FEC)
      sr = self.VV4RSU(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVASqv(self, refCode):
  self.data = None
  self.VVRi2J(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC6mSu():
 def __init__(self, VV3pw3, path, VVJcVO=None, curRowNum=-1):
  self.VV3pw3  = VV3pw3
  self.origFile   = path
  self.Title    = "File Editor: " + FFRwag(path)
  self.VVJcVO  = VVJcVO
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFBSzC("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVb8Vo(curRowNum)
  else:
   FFNkji(self.VV3pw3, "Error while preparing edit!")
 def VVb8Vo(self, curRowNum):
  VVMGU8 = self.VVxKvc()
  VV6i1u = None #("Delete Line" , self.deleteLine  , [])
  VV1NOm = ("Save Changes" , self.VVlI5k   , [])
  VVBh0a  = ("Edit Line"  , self.VVPMXt    , [])
  VVfzl8 = ("Go to Line Num" , self.VVaJht   , [])
  VVL1b6 = ("Line Options" , self.VVoJk7   , [])
  VVaNtS = (""    , self.VVzxji , [])
  VVOTt1 = self.VVQeKR
  VVFKIR  = self.VV9pzz
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVKrzB  = (CENTER  , LEFT  )
  VVMsCC = FFGcVX(self.VV3pw3, None, title=self.Title, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVBh0a=VVBh0a, VVfzl8=VVfzl8, VVL1b6=VVL1b6, VVOTt1=VVOTt1, VVFKIR=VVFKIR, VVaNtS=VVaNtS, VVLHme=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVcV6s   = "#11001111"
    , VV89EB   = "#11001111"
    , VVHzNF   = "#11001111"
    , VVhGFp  = "#05333333"
    , VV3VgO  = "#00222222"
    , VVGPak  = "#11331133"
    )
  VVMsCC.VVtsKn(curRowNum)
 def VVaJht(self, VVMsCC, title, txt, colList):
  totRows = VVMsCC.VVPmHc()
  lineNum = VVMsCC.VVeXGB() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFhzot(self.VV3pw3, BF(self.VVHClD, VVMsCC, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVHClD(self, VVMsCC, lineNum, totRows, VVk7Wd):
  if VVk7Wd:
   VVk7Wd = VVk7Wd.strip()
   if VVk7Wd.isdigit():
    num = FFDLFU(int(VVk7Wd) - 1, 0, totRows)
    VVMsCC.VVtsKn(num)
    self.lastLineNum = num + 1
   else:
    FFMnBb(VVMsCC, "Incorrect number", 1500)
 def VVoJk7(self, VVMsCC, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVMsCC.VV7STd()
  VVWp2B = []
  VVWp2B.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVWp2B.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVPYgg"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVZr72:
   VVWp2B.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(  ("Delete Line"         , "deleteLine"   ))
  FFkkcl(self.VV3pw3, BF(self.VVgLvB, VVMsCC, lineNum), VVWp2B=VVWp2B, title="Line Options")
 def VVgLvB(self, VVMsCC, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV438K("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVMsCC)
   elif item == "VVPYgg"  : self.VVPYgg(VVMsCC, lineNum)
   elif item == "copyToClipboard"  : self.VVZBMH(VVMsCC, lineNum)
   elif item == "pasteFromClipboard" : self.VVPwOd(VVMsCC, lineNum)
   elif item == "deleteLine"   : self.VV438K("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVMsCC)
 def VV9pzz(self, VVMsCC):
  VVMsCC.VVdZPd()
 def VVzxji(self, VVMsCC, title, txt, colList):
  if   self.insertMode == 1: VVMsCC.VVDbpO()
  elif self.insertMode == 2: VVMsCC.VVSmFJ()
  self.insertMode = 0
 def VVPYgg(self, VVMsCC, lineNum):
  if lineNum == VVMsCC.VV7STd():
   self.insertMode = 1
   self.VV438K("echo '' >> '%s'" % self.tmpFile, VVMsCC)
  else:
   self.insertMode = 2
   self.VV438K("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVMsCC)
 def VVZBMH(self, VVMsCC, lineNum):
  global VVZr72
  VVZr72 = FFrbAO("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVMsCC.VVQ7Zq("Copied to clipboard")
 def VVlI5k(self, VVMsCC, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFBSzC("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFBSzC("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVMsCC.VVQ7Zq("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVMsCC.VVdZPd()
    else:
     FFNkji(self.VV3pw3, "Cannot save file!")
   else:
    FFNkji(self.VV3pw3, "Cannot create backup copy of original file!")
 def VVQeKR(self, VVMsCC):
  if self.fileChanged:
   FFm5Au(self.VV3pw3, BF(self.VVfdNQ, VVMsCC), "Cancel changes ?")
  else:
   finalOK = os.system(FFBSzC("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVfdNQ(VVMsCC)
 def VVfdNQ(self, VVMsCC):
  VVMsCC.cancel()
  os.system(FFBSzC("rm -f '%s'" % self.tmpFile))
  if self.VVJcVO:
   self.VVJcVO(self.fileSaved)
 def VVPMXt(self, VVMsCC, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVXldd + "ORIGINAL TEXT:\n" + VVpi4Z + lineTxt
  FFhzot(self.VV3pw3, BF(self.VV4xxy, lineNum, VVMsCC), title="File Line", defaultText=lineTxt, message=message)
 def VV4xxy(self, lineNum, VVMsCC, VVk7Wd):
  if not VVk7Wd is None:
   if VVMsCC.VV7STd() <= 1:
    self.VV438K("echo %s > '%s'" % (VVk7Wd, self.tmpFile), VVMsCC)
   else:
    self.VVsfSS(VVMsCC, lineNum, VVk7Wd)
 def VVPwOd(self, VVMsCC, lineNum):
  if lineNum == VVMsCC.VV7STd() and VVMsCC.VV7STd() == 1:
   self.VV438K("echo %s >> '%s'" % (VVZr72, self.tmpFile), VVMsCC)
  else:
   self.VVsfSS(VVMsCC, lineNum, VVZr72)
 def VVsfSS(self, VVMsCC, lineNum, newTxt):
  VVMsCC.VV9Ct6("Saving ...")
  lines = FFsCGi(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVMsCC.VVJmOH()
  VVMGU8 = self.VVxKvc()
  VVMsCC.VVsLrn(VVMGU8)
 def VV438K(self, cmd, VVMsCC):
  tCons = CCtypF()
  tCons.ePopen(cmd, BF(self.VV0c6s, VVMsCC))
  self.fileChanged = True
  VVMsCC.VVJmOH()
 def VV0c6s(self, VVMsCC, result, retval):
  VVMGU8 = self.VVxKvc()
  VVMsCC.VVsLrn(VVMGU8)
 def VVxKvc(self):
  if fileExists(self.tmpFile):
   lines = FFsCGi(self.tmpFile)
   VVMGU8 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVMGU8.append((str(ndx), line.strip()))
   if not VVMGU8:
    VVMGU8.append((str(1), ""))
   return VVMGU8
  else:
   FFdzz0(self.VV3pw3, self.tmpFile)
class CCG8u1():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVWp2B   = []
  self.satList   = []
 def VVYsxj(self, VVJcVO):
  self.VVWp2B = []
  VVWp2B, VVjt2V = CCG8u1.VV5vkf(self.callingSELF, False, True)
  if VVWp2B:
   self.VVWp2B += VVWp2B
   self.VVfprv(VVJcVO, VVjt2V)
 def VVOLiE(self, mode, VVMsCC, satCol, VVJcVO, inFilterFnc=None):
  VVMsCC.VV9Ct6("Loading Filters ...")
  self.VVWp2B = []
  self.VVWp2B.append(("All Services" , "all"))
  if mode == 1:
   self.VVWp2B.append(VVEgY4)
   self.VVWp2B.append(("Parental Control", "parentalControl"))
   self.VVWp2B.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVWp2B.append(VVEgY4)
   self.VVWp2B.append(("Selected Transponder"   , "selectedTP" ))
   self.VVWp2B.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVrvgB(VVMsCC, satCol)
  VVWp2B, VVjt2V = CCG8u1.VV5vkf(self.callingSELF, True, False)
  if VVWp2B:
   VVWp2B.insert(0, FFhiR0("Custom Words"))
   self.VVWp2B += VVWp2B
  VVMsCC.VVjUpN()
  self.VVfprv(VVJcVO, VVjt2V, inFilterFnc)
 def VV2Jpr(self, VVWp2B, sats, VVJcVO, inFilterFnc=None):
  self.VVWp2B = VVWp2B
  VVWp2B, VVjt2V = CCG8u1.VV5vkf(self.callingSELF, True, False)
  if VVWp2B:
   self.VVWp2B.append(FFhiR0("Custom Words"))
   self.VVWp2B += VVWp2B
  self.VVfprv(VVJcVO, VVjt2V, inFilterFnc)
 def VVfprv(self, VVJcVO, VVjt2V, inFilterFnc=None):
  VVKBZE  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVBc7a = ("Edit Filter"  , BF(self.VVKqSJ, VVjt2V))
  VVK0co  = ("Filter Help"  , BF(self.VVNZNx, VVjt2V))
  FFkkcl(self.callingSELF, BF(self.VVvant, VVJcVO), VVWp2B=self.VVWp2B, title="Select Filter", VVKBZE=VVKBZE, VVBc7a=VVBc7a, VVK0co=VVK0co, VV7G8l=True)
 def VVvant(self, VVJcVO, item):
  if item:
   VVJcVO(item)
 def VVKqSJ(self, VVjt2V, VVW8faObj, sel):
  if fileExists(VVjt2V) : CC6mSu(self.callingSELF, VVjt2V, VVJcVO=None)
  else       : FFdzz0(self.callingSELF, VVjt2V)
  VVW8faObj.cancel()
 def VVNZNx(self, VVjt2V, VVW8faObj, sel):
  FFXRcG(self.callingSELF, VVE4he + "_help_service_filter", "Service Filter")
 def VVrvgB(self, VVMsCC, satColNum):
  if not self.satList:
   satList = VVMsCC.VVHiTf(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFwTSp(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFhiR0("Satellites"))
  if self.VVWp2B:
   self.VVWp2B += self.satList
 @staticmethod
 def VV5vkf(SELF, addTag, VVvNCa):
  FFnpBj()
  fileName  = "ajpanel_services_filter"
  VVjt2V = VVcqbj + fileName
  VVWp2B  = []
  if not fileExists(VVjt2V):
   os.system(FFBSzC("cp -f '%s' '%s'" % (VVE4he + fileName, VVjt2V)))
  fileFound = False
  if fileExists(VVjt2V):
   fileFound = True
   lines = FFsCGi(VVjt2V)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVWp2B.append((line, "__w__" + line))
       else  : VVWp2B.append((line, line))
  if VVvNCa:
   if   not fileFound : FFdzz0(SELF, VVjt2V)
   elif not VVWp2B : FF5DrN(SELF, VVjt2V)
  return VVWp2B, VVjt2V
 @staticmethod
 def VVStOm(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  elif txt:
   lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCiNIs():
 def __init__(self, callingSELF, VVMsCC, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVMsCC = VVMsCC
  self.refCodeColNum = refCodeColNum
  self.VVWp2B = []
  iMulSel = self.VVMsCC.VVvs58()
  if iMulSel : self.VVWp2B.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVWp2B.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVMsCC.VVtQKr()
  self.VVWp2B.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVWp2B.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVWp2B.append(VVEgY4)
 def VVe0id(self, servName):
  tot = self.VVMsCC.VVtQKr()
  s = "s" if tot > 1 else ""
  if tot > 0:
   sTxt = FFtSnl("%d Service%s" % (tot, "s" if tot > 0 else ""), VVFeau)
   self.VVWp2B.append(("Add %s to Bouquet ..." % sTxt  , "addToBouquet_multi" ))
  else:
   servName = FFYfxZ(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFtSnl(servName, VVFeau)
   self.VVWp2B.append(('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" ))
 def VVLK10(self, servName, refCode):
  self.VVe0id(servName)
  self.VVs08q(servName, refCode)
 def VVysX1(self, servName, refCode, pcState, hidState):
  isMulti = self.VVMsCC.VVE8N3
  if isMulti:
   refCodeList = self.VVMsCC.VVXWzY(3)
   if refCodeList:
    self.VVWp2B.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVWp2B.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVWp2B.append(VVEgY4)
    self.VVWp2B.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVWp2B.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVWp2B.pop(len(self.VVWp2B) - 1)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    self.VVWp2B.append((txt1, "parentalControl_add" ))
    self.VVWp2B.append((txt2,       ))
   else:
    self.VVWp2B.append((txt1,       ))
    self.VVWp2B.append((txt2, "parentalControl_remove"))
   self.VVWp2B.append(VVEgY4)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    self.VVWp2B.append((txt1, "hiddenServices_add" ))
    self.VVWp2B.append((txt2,       ))
   else:
    self.VVWp2B.append((txt1,       ))
    self.VVWp2B.append((txt2, "hiddenServices_remove" ))
  self.VVWp2B.append(VVEgY4)
  self.VVe0id(servName)
  self.VVs08q(servName, refCode)
 def VVs08q(self, servName, refCode):
  FFkkcl(self.callingSELF, BF(self.VV40GJ, servName, refCode), title="Options", VVWp2B=self.VVWp2B)
 def VV40GJ(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVMsCC.VVDdFZ(True)
   elif item == "MultSelDisab"     : self.VVMsCC.VVDdFZ(False)
   elif item == "selectAll"     : self.VVMsCC.VV6pI2()
   elif item == "unselectAll"     : self.VVMsCC.VVR1Jm()
   elif item == "parentalControl_add"   : self.callingSELF.VVpHnC(self.VVMsCC, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVpHnC(self.VVMsCC, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVimBZ(self.VVMsCC, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVimBZ(self.VVMsCC, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VV9A84(self.VVMsCC, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VV9A84(self.VVMsCC, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVWdvu(self.VVMsCC, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVWdvu(self.VVMsCC, False)
   elif item == "addToBouquet_multi"   : self.VVeYJO(refCode, True)
   elif item == "addToBouquet_one"    : self.VVeYJO(refCode, False)
 def VVcex1(self, VVMsCC):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel  = CCiNIs(self, VVMsCC, 3)
  mSel.VVLK10(servName, refCode)
 def VVeYJO(self, refCode, isMulti):
  picker = CC0dGf(self.callingSELF, self.VVMsCC, "Add to Bouquet", BF(self.VVpKYD, isMulti))
 def VVpKYD(self, isMulti):
  if isMulti : refCodeList = self.VVMsCC.VVXWzY(self.refCodeColNum)
  else  : refCodeList = [self.VVMsCC.VV0cqe()[self.refCodeColNum]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
class CChXIF(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVF06t, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF2wUT(self)
  FF4HaE(self["keyRed"]  , "Exit")
  FF4HaE(self["keyGreen"]  , "Save")
  FF4HaE(self["keyYellow"] , "Refresh")
  FF4HaE(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV9DHQ  ,
   "green"   : self.VVlDn2 ,
   "yellow"  : self.VVCvB8  ,
   "blue"   : self.VVQHuQ   ,
   "up"   : self.VVRYLD    ,
   "down"   : self.VVk2gz   ,
   "left"   : self.VVmpQP   ,
   "right"   : self.VVV9jd   ,
   "cancel"  : self.VV9DHQ
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVCvB8()
  self.VVZEp4()
  FFLvNc(self)
 def VV9DHQ(self) : self.close(True)
 def VVCFxE(self) : self.close(False)
 def VVQHuQ(self):
  self.session.openWithCallback(self.VVZ02M, BF(CCbERZ))
 def VVZ02M(self, closeAll):
  if closeAll:
   self.close()
 def VVRYLD(self):
  self.VV8sUZ(1)
 def VVk2gz(self):
  self.VV8sUZ(-1)
 def VVmpQP(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVZEp4()
 def VVV9jd(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVZEp4()
 def VV8sUZ(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVIz1P(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVIz1P(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVIz1P(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVfuVw(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVfuVw(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVZEp4(self):
  for obj in self.list:
   FFQZ4f(obj, "#11404040")
  FFQZ4f(self.list[self.index], "#11ff8000")
 def VVCvB8(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVlDn2(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCtypF()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVdy00)
 def VVdy00(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFO5iz(self, "Nothing returned from the system!")
  else:
   FFO5iz(self, str(result))
class CCbERZ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVqL9P, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF2wUT(self, addLabel=True)
  FF4HaE(self["keyRed"]  , "Exit")
  FF4HaE(self["keyGreen"]  , "Sync")
  FF4HaE(self["keyYellow"] , "Refresh")
  FF4HaE(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV9DHQ   ,
   "green"   : self.VVtMJd  ,
   "yellow"  : self.VVmIwE ,
   "blue"   : self.VVQbPP  ,
   "cancel"  : self.VV9DHQ
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVeXLR()
  self.onShow.append(self.start)
 def start(self):
  FFrvtJ(self.refresh)
  FFLvNc(self)
 def refresh(self):
  self.VVkbzB()
  self.VVfZAu(False)
 def VV9DHQ(self)  : self.close(True)
 def VVQbPP(self) : self.close(False)
 def VVeXLR(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVkbzB(self):
  self.VVLAyI()
  self.VVvX5G()
  self.VVU6JZ()
  self.VV7Add()
 def VVmIwE(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVeXLR()
   self.VVkbzB()
   FFrvtJ(self.refresh)
 def VVtMJd(self):
  if len(self["keyGreen"].getText()) > 0:
   FFm5Au(self, self.VVmQsx, "Synchronize with Internet Date/Time ?")
 def VVmQsx(self):
  self.VVkbzB()
  FFrvtJ(BF(self.VVfZAu, True))
 def VVLAyI(self)  : self["keyRed"].show()
 def VVzdP6(self)  : self["keyGreen"].show()
 def VVN5g6(self) : self["keyYellow"].show()
 def VVesYs(self)  : self["keyBlue"].show()
 def VVvX5G(self)  : self["keyGreen"].hide()
 def VVU6JZ(self) : self["keyYellow"].hide()
 def VV7Add(self)  : self["keyBlue"].hide()
 def VVfZAu(self, sync):
  localTime = FFvSuo()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVjhL0(server)
   if epoch_time is not None:
    ntpTime = FFP6g0(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCtypF()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVdy00, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVN5g6()
  self.VVesYs()
  if ok:
   self.VVzdP6()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVdy00(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVfZAu(False)
  except:
   pass
 def VVjhL0(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFqH9S():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CC4PeP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbZTb(VVQEAr, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FF2wUT(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFrvtJ(self.VV5HlD)
 def VV5HlD(self):
  if FFqH9S(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFQZ4f(self["myBody"], color)
   FFQZ4f(self["myLabel"], color)
  except:
   pass
class CCTEDW(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFCroK()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFbZTb(VVFwlX, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCWOuI(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCWOuI(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCWOuI(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCd6rH()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF2wUT(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVRYLD       ,
   "down"  : self.VVk2gz      ,
   "left"  : self.VVmpQP      ,
   "right"  : self.VVV9jd      ,
   "info"  : self.VVJnIW     ,
   "epg"  : self.VVJnIW     ,
   "menu"  : self.VVAWyE      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVubUZ, -1)  ,
   "next"  : BF(self.VVubUZ, 1)  ,
   "pageUp" : BF(self.VVP4bK, True) ,
   "chanUp" : BF(self.VVP4bK, True) ,
   "pageDown" : BF(self.VVP4bK, False) ,
   "chanDown" : BF(self.VVP4bK, False) ,
   "0"   : BF(self.VVubUZ, 0)  ,
   "1"   : BF(self.VVcCOn, pos=1) ,
   "2"   : BF(self.VVcCOn, pos=2) ,
   "3"   : BF(self.VVcCOn, pos=3) ,
   "4"   : BF(self.VVcCOn, pos=4) ,
   "5"   : BF(self.VVcCOn, pos=5) ,
   "6"   : BF(self.VVcCOn, pos=6) ,
   "7"   : BF(self.VVcCOn, pos=7) ,
   "8"   : BF(self.VVcCOn, pos=8) ,
   "9"   : BF(self.VVcCOn, pos=9) ,
  }, -1)
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self.sliderSNR.VVZV92()
  self.sliderAGC.VVZV92()
  self.sliderBER.VVZV92(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVcCOn()
  self.VV9Q43()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVknpq)
  except:
   self.timer.callback.append(self.VVknpq)
  self.timer.start(500, False)
 def VV9Q43(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVjgJP(service)
  serviceName = self.tunerInfo.VV1wtD()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  tp = CCW6PA()
  tpTxt, satTxt = tp.VVoeZZ(refCode)
  self["myTPInfo"].setText(tpTxt + "  " + FFtSnl(satTxt, VVFeau))
 def VVknpq(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVjgJP(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVwhT6())
   self["mySNR"].setText(self.tunerInfo.VVdy0Y())
   self["myAGC"].setText(self.tunerInfo.VV0Jnp())
   self["myBER"].setText(self.tunerInfo.VVqeMO())
   self.sliderSNR.VVOkvH(self.tunerInfo.VVUu6W())
   self.sliderAGC.VVOkvH(self.tunerInfo.VVgf0V())
   self.sliderBER.VVOkvH(self.tunerInfo.VV2hCv())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVOkvH(0)
   self.sliderAGC.VVOkvH(0)
   self.sliderBER.VVOkvH(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
    if state and not state == "Tuned":
     FFMnBb(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVJnIW(self):
  FFRDSd(self, fncMode=CCGnOY.VVbhvp)
 def VVAWyE(self):
  FFXRcG(self, VVE4he + "_help_signal", "Signal Monitor (Keys)")
 def VVRYLD(self)  : self.VVcCOn(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVk2gz(self) : self.VVcCOn(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVmpQP(self) : self.VVcCOn(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVV9jd(self) : self.VVcCOn(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVcCOn(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVubUZ(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFDLFU(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVP4bK(self, isUp):
  FFMnBb(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VV9Q43()
  except:
   pass
class CCWOuI(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVZV92(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFQZ4f(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVE4he +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFQZ4f(self.covObj, self.covColor)
   else:
    FFQZ4f(self.covObj, "#00006688")
    self.isColormode = True
  self.VVOkvH(0)
 def VVOkvH(self, val):
  val  = FFDLFU(val, self.minN, self.maxN)
  width = int(FFDe6w(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFDLFU(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC4A0C(Screen):
 VVo57g    = 0
 VVMNNJ = 1
 VVzxN8 = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVJcVO=None, barTheme=VVo57g):
  ratio = self.VVeXrZ(barTheme)
  self.skin, self.skinParam = FFbZTb(VVmXPN, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVJcVO = VVJcVO
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VV4mwj = None
  self.timer   = eTimer()
  self.myThread  = None
  FF2wUT(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self.VVB8ee()
  self["myProgBarVal"].setText("0%")
  FFQZ4f(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVH63C()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVH63C)
  except:
   self.timer.callback.append(self.VVH63C)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVdoFu(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVzqj2(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VV4mwj), self.counter, self.maxValue, catName)
 def VV4ADa(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVr4Jf(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVDL2P(self, title):
  self.newTitle = title
  try:
   self.VVH63C()
  except:
   pass
 def VVCxfw(self, txt):
  self.newTitle = txt
 def VV0CXi(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VV4mwj), self.counter, self.maxValue)
  except:
   pass
 def VVVgYT(self, val):
  try:
   self.counter = val
  except:
   pass
 def VV9UAT(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVgK2m(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFMnBb(self, "Cancelling ...")
  self.isCancelled = True
  self.VVUix8(False)
 def VVUix8(self, isDone):
  if self.VVJcVO:
   self.VVJcVO(isDone, self.VV4mwj, self.counter, self.maxValue, self.isError)
  self.close()
 def VVH63C(self):
  val = FFDLFU(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFDe6w(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVUix8(True)
 def VVB8ee(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVMNNJ, self.VVzxN8):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVeXrZ(self, barTheme):
  if   barTheme == self.VVMNNJ : return 0.7
  if   barTheme == self.VVzxN8 : return 0.5
  else             : return 1
class CCtypF(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVJcVO = {}
  self.commandRunning = False
  self.VVeUfE  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVJcVO, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVJcVO[name] = VVJcVO
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVeUfE:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVUsgd, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVK9I9 , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVUsgd, name))
    self.appContainers[name].appClosed.append(BF(self.VVK9I9 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVK9I9(name, retval)
  return True
 def VVUsgd(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVK9I9(self, name, retval):
  if not self.VVeUfE:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVJcVO[name]:
   self.VVJcVO[name](self.appResults[name], retval)
  del self.VVJcVO[name]
 def VVNGzo(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CC8r1x(Screen):
 def __init__(self, session, title="", VVmobY=None, VV7p8T=False, VVHaYT=False, VVP3ns=False, VV8eLm=False, VVsIM5=False, VVPLML=False, VVwvtK=VVebGP, VVyLAy=None, VV5Bgh=False, VV6nEO=None, VVmOjC="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFbZTb(VVM7on, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF2wUT(self, addScrollLabel=True)
  if not VVmOjC:
   VVmOjC = "Processing ..."
  self["myLabel"].setText("   %s" % VVmOjC)
  self.VV7p8T   = VV7p8T
  self.VVHaYT   = VVHaYT
  self.VVP3ns   = VVP3ns
  self.VV8eLm  = VV8eLm
  self.VVsIM5 = VVsIM5
  self.VVPLML = VVPLML
  self.VVwvtK   = VVwvtK
  self.VVyLAy = VVyLAy
  self.VV5Bgh  = VV5Bgh
  self.VV6nEO  = VV6nEO
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCtypF()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFPcSK()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVmobY, str):
   self.VVmobY = [VVmobY]
  else:
   self.VVmobY = VVmobY
  if self.VVP3ns or self.VV8eLm:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVJ1qT, VVJ1qT)
   self.VVmobY.append("echo -e '\n%s\n' %s" % (restartNote, FF7gKg(restartNote, VVxbdF)))
   if self.VVP3ns:
    self.VVmobY.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVmobY.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVsIM5:
   FFMnBb(self, "Processing ...")
  self.onLayoutFinish.append(self.VVfS7b)
  self.onClose.append(self.VVVHcN)
 def VVfS7b(self):
  self["myLabel"].VVVQK5(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VV7p8T:
   self["myLabel"].VVr1fk()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVxeTI()
  else:
   self.VVKjSM()
 def VVxeTI(self):
  if FFqH9S():
   self["myLabel"].setText("Processing ...")
   self.VVKjSM()
  else:
   self["myLabel"].setText(FFtSnl("\n   No connection to internet!", VVpqRv))
 def VVKjSM(self):
  allOK = self.container.ePopen(self.VVmobY[0], self.VVEVso, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVEVso("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVPLML or self.VVP3ns or self.VV8eLm:
    self["myLabel"].setText(FFpGai("STARTED", VVxbdF) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV6nEO:
   colorWhite = CCJoLU.VVBZ2S(VVXldd)
   color  = CCJoLU.VVBZ2S(self.VV6nEO[0])
   words  = self.VV6nEO[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVwvtK=self.VVwvtK)
 def VVEVso(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVmobY):
   allOK = self.container.ePopen(self.VVmobY[self.cmdNum], self.VVEVso, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVEVso("Cannot connect to Console!", -1)
  else:
   if self.VVsIM5 and FFPtMH(self):
    FFMnBb(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVPLML:
    self["myLabel"].appendText("\n" + FFpGai("FINISHED", VVxbdF), self.VVwvtK)
   if self.VV7p8T or self.VVHaYT:
    self["myLabel"].VVr1fk()
   if self.VVyLAy is not None:
    self.VVyLAy()
   if not retval and self.VV5Bgh:
    self.VVVHcN()
 def VVVHcN(self):
  if self.container.VVNGzo():
   self.container.killAll()
class CCAxj8(Screen):
 def __init__(self, session, VVmobY=None, VVsIM5=False):
  self.skin, self.skinParam = FFbZTb(VVM7on, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVcqbj + "ajpanel_terminal.history"
  self.customCommandsFile = VVcqbj + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFrbAO("pwd") or "/home/root"
  self.container   = CCtypF()
  FF2wUT(self, addScrollLabel=True)
  FF4HaE(self["keyRed"] , "Exit = Stop Command")
  FF4HaE(self["keyGreen"] , "OK = History")
  FF4HaE(self["keyYellow"], "Menu = Custom Cmds")
  FF4HaE(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVBMRF ,
   "cancel" : self.VV58QG  ,
   "menu"  : self.VVFbiZ ,
   "last"  : self.VV5s2G  ,
   "next"  : self.VV5s2G  ,
   "1"   : self.VV5s2G  ,
   "2"   : self.VV5s2G  ,
   "3"   : self.VV5s2G  ,
   "4"   : self.VV5s2G  ,
   "5"   : self.VV5s2G  ,
   "6"   : self.VV5s2G  ,
   "7"   : self.VV5s2G  ,
   "8"   : self.VV5s2G  ,
   "9"   : self.VV5s2G  ,
   "0"   : self.VV5s2G
  })
  self.onLayoutFinish.append(self.VV5WGz)
  self.onClose.append(self.VV6dyr)
 def VV5WGz(self):
  self["myLabel"].VVVQK5(isResizable=False, outputFileToSave="terminal")
  FFryZu(self["keyRed"]  , "#00ff8000")
  FFQZ4f(self["keyRed"]  , self.skinParam["titleColor"])
  FFQZ4f(self["keyGreen"]  , self.skinParam["titleColor"])
  FFQZ4f(self["keyYellow"] , self.skinParam["titleColor"])
  FFQZ4f(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVY00I(FFrbAO("date"), 5)
  result = FFrbAO("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVWDAw()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVE4he + "LinuxCommands.lst"
   newTemplate = VVE4he + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFBSzC("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFBSzC("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VV6dyr(self):
  if self.container.VVNGzo():
   self.container.killAll()
   self.VVY00I("Process killed\n", 4)
   self.VVWDAw()
 def VV58QG(self):
  if self.container.VVNGzo():
   self.VV6dyr()
  else:
   FFm5Au(self, self.close, "Exit ?", VV2Aw2=False)
 def VVWDAw(self):
  self.VVY00I(self.prompt, 1)
  self["keyRed"].hide()
 def VVY00I(self, txt, mode):
  if   mode == 1 : color = VVxbdF
  elif mode == 2 : color = VVMXOB
  elif mode == 3 : color = VVXldd
  elif mode == 4 : color = VVpqRv
  elif mode == 5 : color = VVpi4Z
  elif mode == 6 : color = VVAc0p
  else   : color = VVXldd
  try:
   self["myLabel"].appendText(FFtSnl(txt, color))
  except:
   pass
 def VVewiA(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVY00I(cmd, 2)
   self.VVY00I("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVY00I(ch, 0)
   self.VVY00I("\nor\n", 4)
   self.VVY00I("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVWDAw()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFtSnl(parts[0].strip(), VVMXOB)
    right = FFtSnl("#" + parts[1].strip(), VVAc0p)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVY00I(txt, 2)
   lastLine = self.VVGae7()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVvDhu(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVEVso, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFNkji(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVY00I(data, 3)
 def VVEVso(self, data, retval):
  if not retval == 0:
   self.VVY00I("Exit Code : %d\n" % retval, 4)
  self.VVWDAw()
 def VVBMRF(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVGae7() == "":
   self.VVvDhu("cd /tmp")
   self.VVvDhu("ls")
  VVMGU8 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFsCGi(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVMGU8.append((str(c), line, str(lNum)))
   self.VVhvju(VVMGU8, title, self.commandHistoryFile, isHistory=True)
  else:
   FFdzz0(self, self.commandHistoryFile, title=title)
 def VVGae7(self):
  lastLine = FFrbAO("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVvDhu(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVFbiZ(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFsCGi(self.customCommandsFile)
   lastLineIsSep = False
   VVMGU8 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVMGU8.append((str(c), line, str(lNum)))
   self.VVhvju(VVMGU8, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFdzz0(self, self.customCommandsFile, title=title)
 def VVhvju(self, VVMGU8, title, filePath=None, isHistory=False):
  if VVMGU8:
   VVhGFp = "#05333333"
   if isHistory: VVcV6s = VV89EB = VVHzNF = "#11000020"
   else  : VVcV6s = VV89EB = VVHzNF = "#06002020"
   VVBh0a   = ("Send"   , self.VVfZyK     , [])
   VV1NOm  = ("Modify & Send" , self.VVVv5i     , [])
   if isHistory:
    VVfzl8 = ("Clear History" , self.VViTQZ     , [])
    VVL1b6 = None
   elif filePath:
    VVfzl8 = None
    VVL1b6 = ("Edit File"  , BF(self.VVSch2, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVKrzB     = (CENTER  , LEFT   , CENTER )
   FFGcVX(self, None, title=title, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV1NOm=VV1NOm, VVfzl8=VVfzl8, VVL1b6=VVL1b6, lastFindConfigObj=CFG.lastFindTerminal, VVLHme=True, searchCol=1
     , VVcV6s   = VVcV6s
     , VV89EB   = VV89EB
     , VVHzNF   = VVHzNF
     , VVmD06  = "#05ffff00"
     , VVhGFp  = VVhGFp
    )
  else:
   FF5DrN(self, filePath, title=title)
 def VVfZyK(self, VVMsCC, title, txt, colList):
  cmd = colList[1].strip()
  VVMsCC.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVY00I("\n%s\n" % cmd, 6)
   self.VVY00I(self.prompt, 1)
  else:
   self.VVewiA(cmd)
 def VVVv5i(self, VVMsCC, title, txt, colList):
  cmd = colList[1]
  self.VV61Zx(VVMsCC, cmd)
 def VViTQZ(self, VVMsCC, title, txt, colList):
  FFm5Au(self, BF(self.VVQgQg, VVMsCC), "Reset History File ?", title="Command History")
 def VVQgQg(self, VVMsCC):
  os.system(FFBSzC("echo '' > %s" % self.commandHistoryFile))
  VVMsCC.cancel()
 def VVSch2(self, filePath, VVMsCC, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC6mSu(self, filePath, VVJcVO=BF(self.VVO0Nm, VVMsCC), curRowNum=rowNum)
  else     : FFdzz0(self, filePath)
 def VVO0Nm(self, VVMsCC, fileChanged):
  if fileChanged:
   VVMsCC.cancel()
   FFrvtJ(self.VVFbiZ)
 def VV5s2G(self):
  self.VV61Zx(None, self.lastCommand)
 def VV61Zx(self, VVMsCC, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFhzot(self, BF(self.VVMsna, VVMsCC), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVMsna(self, VVMsCC, cmd):
  if cmd and len(cmd) > 0:
   self.VVewiA(cmd)
   if VVMsCC:
    VVMsCC.cancel()
class CCvhn7(Screen):
 def __init__(self, session, title="", message="", VVwvtK=VVebGP, VVW7PG=False, VVHzNF=None, VVlOla=30, outputFileToSave=""):
  self.skin, self.skinParam = FFbZTb(VVM7on, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVlOla)
  self.session   = session
  FF2wUT(self, title, addScrollLabel=True)
  self.VVwvtK   = VVwvtK
  self.VVW7PG   = VVW7PG
  self.VVHzNF   = VVHzNF
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self["myLabel"].VVVQK5(VVW7PG=self.VVW7PG, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVwvtK)
  if self.VVHzNF:
   FFQZ4f(self["myBody"], self.VVHzNF)
   FFQZ4f(self["myLabel"], self.VVHzNF)
   FFdhoC(self["myLabel"], self.VVHzNF)
  self["myLabel"].VVr1fk()
class CC2zeu(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFbZTb(VVU9A6, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF2wUT(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFUKsz(self["errPic"], "err")
class CCbihD(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFbZTb(VVWvky, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FF2wUT(self, " ", addCloser=True)
class CCzuW4():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCbihD, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFZmKs(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVBj2y)
  except:
   self.timer.callback.append(self.VVBj2y)
  self.timer.start(timeout, True)
 def VVBj2y(self):
  self.session.deleteDialog(self.win)
class CCuF83():
 VVt1c2    = 0
 VVwjUR  = 1
 VVY7zP   = ""
 VVZhTm    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVMsCC   = None
  self.timer     = eTimer()
  self.VVuAM2   = 0
  self.VVGq5i  = 1
  self.VVSXjY  = 2
  self.VVcTRE   = 3
  self.VVB99D   = 4
  VVMGU8 = self.VVhT6j()
  if VVMGU8:
   self.VVMsCC = self.VV4a57(VVMGU8)
  if not VVMGU8 and mode == self.VVt1c2:
   self.VVQDGO("Download list is empty !")
   self.cancel()
  if mode == self.VVwjUR:
   FFOvQF(self.VVMsCC or self.SELF, BF(self.VVUvZh, startDnld, decodedUrl), title="Checking Server ...")
  self.VVMfyM(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVMfyM)
  except:
   self.timer.callback.append(self.VVMfyM)
  self.timer.start(1000, False)
 def VV4a57(self, VVMGU8):
  VVMGU8.sort(key=lambda x: int(x[0]))
  VVOTt1 = self.VVrmg5
  VVBh0a  = ("Play"  , self.VViA8c , [])
  VV9ZE5 = (""   , self.VVFXzV  , [])
  VV6i1u = ("Stop"  , self.VVQaZ3  , [])
  VV1NOm = ("Resume"  , self.VVEUDF , [])
  VVfzl8 = ("Options" , self.VVE1GE  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVKrzB  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFGcVX(self.SELF, None, title=self.Title, header=header, VVJXpL=VVMGU8, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VVOTt1=VVOTt1, VV6i1u=VV6i1u, VV1NOm=VV1NOm, VVfzl8=VVfzl8, lastFindConfigObj=CFG.lastFindIptv, VV89EB="#11110011", VVcV6s="#11220022", VVHzNF="#11110011", VVmD06="#00ffff00", VVhGFp="#00223025", VV3VgO="#0a333333", VVGPak="#0a400040", VVLHme=True, searchCol=1)
 def VVhT6j(self):
  lines = CCuF83.VVJQPn()
  VVMGU8 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVH5y9(decodedUrl)
      if fName:
       if   FFQlgA(decodedUrl) : sType = "Movie"
       elif FFutXo(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVs3us(decodedUrl, fName)
       if size > -1: sizeTxt = CC0Jp1.VVCLeS(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVMGU8.append((str(len(VVMGU8) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVMGU8
 def VVH1Sp(self):
  VVMGU8 = self.VVhT6j()
  if VVMGU8:
   if self.VVMsCC : self.VVMsCC.VVsLrn(VVMGU8, VVeXLRMsg=False)
   else     : self.VVMsCC = self.VV4a57(VVMGU8)
  else:
   self.cancel()
 def VVMfyM(self, force=False):
  if self.VVMsCC:
   thrListUrls = self.VVxypH()
   VVMGU8 = []
   changed = False
   for ndx, row in enumerate(self.VVMsCC.VVy2g3()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVuAM2
    if m3u8Log:
     percent = CCuF83.VVlEDP(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVcTRE , "%.2f %%" % percent
      else   : flag, progr = self.VVB99D , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFHaPS(mPath)
     if curSize > -1:
      fSize = CC0Jp1.VVCLeS(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC0Jp1.VVCLeS(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFHaPS(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVcTRE , "%.2f %%" % percent
       else   : flag, progr = self.VVB99D , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC0Jp1.VVCLeS(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVSXjY
     if m3u8Log :
      if not speed and not force : flag = self.VVGq5i
      elif curSize == -1   : self.VVl6L7(False)
    elif flag == self.VVuAM2  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVuAM2  : color2 = "#f#00555555#"
    elif flag == self.VVGq5i : color2 = "#f#0000FFFF#"
    elif flag == self.VVSXjY : color2 = "#f#0000FFFF#"
    elif flag == self.VVcTRE  : color2 = "#f#00FF8000#"
    elif flag == self.VVB99D  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVssQg(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVMGU8.append(row)
   if changed or force:
    self.VVMsCC.VVsLrn(VVMGU8, VVeXLRMsg=False)
 def VVssQg(self, flag):
  tDict = self.VVfdkR()
  return tDict.get(flag, "?")
 def VVqAuF(self, state):
  for flag, txt in self.VVfdkR().items():
   if txt == state:
    return flag
  return -1
 def VVfdkR(self):
  return { self.VVuAM2: "Not started", self.VVGq5i: "Connecting", self.VVSXjY: "Downloading", self.VVcTRE: "Stopped", self.VVB99D: "Completed" }
 def VVADzR(self, title):
  colList = self.VVMsCC.VV0cqe()
  path = colList[6]
  url  = colList[8]
  if self.VV6bJf() : self.VVQDGO("Cannot delete !\n\nFile is downloading.")
  else      : FFm5Au(self.SELF, BF(self.VVP89w, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVP89w(self, path, url):
  m3u8Log = self.VVMsCC.VV0cqe()[12]
  if m3u8Log : os.system(FFBSzC("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFBSzC("rm -r '%s'" % path))
  self.VV2P9b(False)
  self.VVH1Sp()
 def VV2P9b(self, VVvNCa=True):
  if self.VV6bJf():
   FFMnBb(self.VVMsCC, self.VVssQg(self.VVSXjY), 500)
  else:
   colList  = self.VVMsCC.VV0cqe()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVqAuF(state) in (self.VVuAM2, self.VVB99D, self.VVcTRE):
    lines = CCuF83.VVJQPn()
    newLines = []
    found = False
    for line in lines:
     if CCuF83.VV42F9(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVEjer(newLines)
     self.VVH1Sp()
     FFMnBb(self.VVMsCC, "Removed.", 1000)
    else:
     FFMnBb(self.VVMsCC, "Not found.", 1000)
   elif VVvNCa:
    self.VVQDGO("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVZkfD(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFm5Au(self.SELF, BF(self.VVzn2u, flag), ques, title=title)
 def VVzn2u(self, flag):
  list = []
  for ndx, row in enumerate(self.VVMsCC.VVy2g3()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVqAuF(state)
   if   flag == flagVal == self.VVB99D: list.append(decodedUrl)
   elif flag == flagVal == self.VVuAM2 : list.append(decodedUrl)
  lines = CCuF83.VVJQPn()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVEjer(newLines)
   self.VVH1Sp()
   FFMnBb(self.VVMsCC, "%d removed." % totRem, 1000)
  else:
   FFMnBb(self.VVMsCC, "Not found.", 1000)
 def VVsKi5(self):
  colList  = self.VVMsCC.VV0cqe()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFMnBb(self.VVMsCC, "Poster exists", 1500)
  else    : FFOvQF(self.VVMsCC, BF(self.VVzpLD, decodedUrl, path, png), title="Checking Server ...")
 def VVzpLD(self, decodedUrl, path, png):
  err = self.VV8TAg(decodedUrl, path, png)
  if err:
   FFNkji(self.SELF, err, title="Poster Download")
 def VV8TAg(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCFpLh.VVts0u(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC5Be5.VVTRui(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC5Be5.VVsGVC(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC5Be5.VVlB8q(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFhNjK(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFBSzC("mv -f '%s' '%s'" % (tPath, png)))
   CCTnxh.VVJldG(self.SELF, VV9WF2=png, showGrnMsg="Downloaded")
   return ""
 def VVFXzV(self, VVMsCC, title, txt, colList):
  def VVQ9OX(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVZ1Gm(key, val) : return "\n%s:\n%s\n" % (FFtSnl(key, VVFeau), val.strip())
  heads  = self.VVMsCC.VVLxm8()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVQ9OX(heads[i]  , CC0Jp1.VVCLeS(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVQ9OX("Downloaded" , CC0Jp1.VVCLeS(int(curSize), mode=0))
   else:
    txt += VVQ9OX(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVZ1Gm(heads[i], colList[i])
  FFzNhe(self.SELF, txt, title=title)
 def VViA8c(self, VVMsCC, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC0Jp1.VV6UHs(self.SELF, path)
  else    : FFMnBb(self.VVMsCC, "File not found", 1000)
 def VVrmg5(self, VVMsCC):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVMsCC:
   self.VVMsCC.cancel()
  del self
 def VVE1GE(self, VVMsCC, title, txt, colList):
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVWp2B = []
  VVWp2B.append(("Remove current row"      , "VV2P9b"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(('Remove all "Completed"'     , "remFinished"    ))
  VVWp2B.append(('Remove all "Not started"'     , "remPending"    ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Delete the file (and remove from list)" , "VVADzR" ))
  if FFQlgA(decodedUrl):
   VVWp2B.append(VVEgY4)
   VVWp2B.append(("Download Movie Poster (from server)" , "VVsKi5"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append((resumeTxt + " Auto Resume"     , "VVDSwj"  ))
  VVWp2B.append((showMonitor + " On-screen Monitor"   , "toggleMonitor"   ))
  FFkkcl(self.SELF, self.VV1xzA, VVWp2B=VVWp2B, title=self.Title, VV83XM=True, VV7G8l=True)
 def VV1xzA(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VV2P9b"  : self.VV2P9b()
   elif ref == "remFinished"   : self.VVZkfD(self.VVB99D, txt)
   elif ref == "remPending"   : self.VVZkfD(self.VVuAM2, txt)
   elif ref == "VVADzR" : self.VVADzR(txt)
   elif ref == "VVsKi5"  : self.VVsKi5()
   elif ref == "VVDSwj"  :
    CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
    CFG.downloadAutoResume.save()
    configfile.save()
   elif ref == "toggleMonitor"   :
    CFG.downloadMonitor.setValue(not CFG.downloadMonitor.getValue())
    CFG.downloadMonitor.save()
    configfile.save()
 def VVUvZh(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCFpLh.VVts0u(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVQDGO("Could not get download link !\n\nTry again later.")
     return
  for line in CCuF83.VVJQPn():
   if CCuF83.VV42F9(decodedUrl, line):
    if self.VVMsCC:
     self.VV85YY(decodedUrl)
     FFrvtJ(BF(FFMnBb, self.VVMsCC, "Already listed !", 2000))
    break
  else:
   params = self.VVea1y(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVQDGO(params[0])
   elif len(params) == 2:
    FFm5Au(self.SELF, BF(self.VVFpcR, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC0Jp1.VVCLeS(fSize)
    FFm5Au(self.SELF, BF(self.VVpKbh, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVpKbh(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCuF83.VVvY8K(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVH1Sp()
  if self.VVMsCC:
   self.VVMsCC.VVSmFJ()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCuF83.VVZhTm, path, decodedUrl)
   self.VVGrwq(threadName, url, decodedUrl, path, resp)
 def VV85YY(self, decodedUrl):
  if self.VVMsCC:
   for ndx, row in enumerate(self.VVMsCC.VVy2g3()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVMsCC:
     self.VVMsCC.VVtsKn(ndx)
     break
 def VVea1y(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVH5y9(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVs3us(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCFpLh.VVts0u(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCFpLh.VVaK2c()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCuF83.VVpc7B(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCuF83.VVjxQi(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVFpcR(self, resp, decodedUrl):
  if not os.system(FFBSzC("which ffmpeg")) == 0:
   FFm5Au(self.SELF, BF(CC5Be5.VVoJaF, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVH5y9(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVbq5t(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFm5Au(self.SELF, BF(self.VV6I8o, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV6I8o(rTxt, rUrl)
  else:
   self.VVQDGO("Cannot process m3u8 file !")
 def VVbq5t(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVWp2B = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC5Be5.VVgc6R(rUrl, fPath)
   VVWp2B.append((resol, fullUrl))
  if VVWp2B:
   FFkkcl(self.SELF, self.VVycxp, VVWp2B=VVWp2B, title="Resolution", VV83XM=True, VV7G8l=True)
  else:
   self.VVQDGO("Cannot get Resolutions list from server !")
 def VVycxp(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFm5Au(self.SELF, BF(FFrvtJ, BF(self.VVNQVV, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFrvtJ(BF(self.VVNQVV, resolUrl))
 def VVNQVV(self, resolUrl):
  txt, err = CCFpLh.VVdePF(resolUrl)
  if err : self.VVQDGO(err)
  else : self.VV6I8o(txt, resolUrl)
 def VVgk0W(self, logF, decodedUrl):
  found = False
  lines = CCuF83.VVJQPn()
  with open(CCuF83.VVvY8K(), "w") as f:
   for line in lines:
    if CCuF83.VV42F9(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCuF83.VVvY8K(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVH1Sp()
  if self.VVMsCC:
   self.VVMsCC.VVSmFJ()
 def VV6I8o(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC5Be5.VVgc6R(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVQDGO("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVgk0W(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFBSzC("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCuF83.VVZhTm, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVlEDP(dnldLog):
  if fileExists(dnldLog):
   dur = CCuF83.VVXsFr(dnldLog)
   if dur > -1:
    tim = CCuF83.VVrKA9(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVXsFr(dnldLog):
  lines = FF42E1("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVrKA9(dnldLog):
  lines = FF42E1("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVs3us(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFutXo(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFBSzC("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVGrwq(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVMsCC.VV0cqe()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVif1G, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVif1G(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVY7zP == path:
       break
     else:
      break
  except:
   return
  if CCuF83.VVY7zP:
   CCuF83.VVY7zP = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFHaPS(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVea1y(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVif1G(url, decodedUrl, path, resp, totFileSize, True)
 def VVQaZ3(self, VVMsCC, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVwWG3() : FFMnBb(self.VVMsCC, self.VVssQg(self.VVB99D), 500)
  elif not self.VV6bJf() : FFMnBb(self.VVMsCC, self.VVssQg(self.VVcTRE), 500)
  elif m3u8Log      : FFm5Au(self.SELF, self.VVl6L7, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVxypH():
    CCuF83.VVY7zP = colList[6]
    FFMnBb(self.VVMsCC, "Stopping ...", 1000)
   else:
    FFMnBb(self.VVMsCC, "Stopped", 500)
 def VVl6L7(self, withMsg=True):
  if withMsg:
   FFMnBb(self.VVMsCC, "Stopping ...", 1000)
  os.system(FFBSzC("killall -INT ffmpeg"))
 def VVEUDF(self, *args):
  if   self.VVwWG3() : FFMnBb(self.VVMsCC, self.VVssQg(self.VVB99D) , 500)
  elif self.VV6bJf() : FFMnBb(self.VVMsCC, self.VVssQg(self.VVSXjY), 500)
  else:
   resume = False
   m3u8Log = self.VVMsCC.VV0cqe()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFm5Au(self.SELF, BF(self.VVVNId, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVcEzv():
    resume = True
   if resume: FFOvQF(self.VVMsCC, BF(self.VVfJYK), title="Checking Server ...")
   else  : FFMnBb(self.VVMsCC, "Cannot resume !", 500)
 def VVVNId(self, m3u8Log):
  os.system(FFBSzC("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFOvQF(self.VVMsCC, BF(self.VVfJYK), title="Checking Server ...")
 def VVfJYK(self):
  colList  = self.VVMsCC.VV0cqe()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCFpLh.VVts0u(decodedUrl)
   if url:
    decodedUrl = self.VVl6gl(decodedUrl, url)
   else:
    self.VVQDGO("Could not get download link !\n\nTry again later.")
    return
  curSize = FFHaPS(path)
  params = self.VVea1y(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVQDGO(params[0])
   return
  elif len(params) == 2:
   self.VVFpcR(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVl6gl(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCuF83.VVZhTm, path, decodedUrl)
  if resumable: self.VVGrwq(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVQDGO("Cannot resume from server !")
 def VVH5y9(self, decodedUrl):
  fileExt = CC5Be5.VVGmAe(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = fileExt
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFh3oH(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVQDGO(self, txt):
  FFNkji(self.SELF, txt, title=self.Title)
 def VVxypH(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCuF83.VVZhTm, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VV6bJf(self):
  decodedUrl = self.VVMsCC.VV0cqe()[9]
  return decodedUrl in self.VVxypH()
 def VVwWG3(self):
  colList = self.VVMsCC.VV0cqe()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFHaPS(path)) == size
 def VVcEzv(self):
  colList = self.VVMsCC.VV0cqe()
  path = colList[6]
  size = int(colList[7])
  curSize = FFHaPS(path)
  if curSize > -1:
   size -= curSize
  err = CCuF83.VVjxQi(size)
  if err:
   FFNkji(self.SELF, err, title=self.Title)
   return False
  return True
 def VVEjer(self, list):
  with open(CCuF83.VVvY8K(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVl6gl(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCuF83.VVJQPn()
  url = decodedUrl
  with open(CCuF83.VVvY8K(), "w") as f:
   for line in lines:
    if CCuF83.VV42F9(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVH1Sp()
  return url
 @staticmethod
 def VVJQPn():
  list = []
  if fileExists(CCuF83.VVvY8K()):
   for line in FFsCGi(CCuF83.VVvY8K()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VV42F9(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVjxQi(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC0Jp1.VVtIN5(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC0Jp1.VVCLeS(size), CC0Jp1.VVCLeS(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVllox(SELF):
  tot = CCuF83.VVsoHD()
  if tot:
   FFNkji(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVsoHD():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCuF83.VVZhTm):
    c += 1
  return c
 @staticmethod
 def VVdQvs():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCuF83.VVZhTm, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VV9YR3():
  return len(CCuF83.VVJQPn()) == 0
 @staticmethod
 def VVXEGi():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVWqqI():
  mPoints = CCuF83.VVXEGi()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFBSzC("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVvY8K():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVQEJc(SELF):
  CCuF83.VVp1FQ(SELF, CCuF83.VVt1c2)
 @staticmethod
 def VVRj9W(SELF):
  CCuF83.VVp1FQ(SELF, CCuF83.VVwjUR, startDnld=True)
 @staticmethod
 def VVWoDJ(SELF, url):
  CCuF83.VVp1FQ(SELF, CCuF83.VVwjUR, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVSKGf(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(SELF)
  added, skipped = CCuF83.VVgy6A([decodedUrl])
  FFMnBb(SELF, "Added", 1000)
 @staticmethod
 def VVgy6A(list):
  added = skipped = 0
  for line in CCuF83.VVJQPn():
   for ndx, url in enumerate(list):
    if url and CCuF83.VV42F9(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCuF83.VVvY8K(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVp1FQ(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCielb.VVhzF1(SELF):
   return
  if mode == CCuF83.VVt1c2 and CCuF83.VV9YR3():
   FFNkji(SELF, "Download list is empty !", title=title)
  else:
   inst = CCuF83(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVpc7B(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCZilb(Screen, CCl3K2):
 VV5SmK = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFbZTb(VV44nA, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCl3K2.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FF2wUT(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVmnEw())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxkj1       ,
   "info"  : self.VVJnIW      ,
   "epg"  : self.VVJnIW      ,
   "menu"  : self.VV7a6z     ,
   "cancel" : self.cancel       ,
   "blue"  : self.VVJCTn      ,
   "green"  : self.VVqppu  ,
   "yellow" : self.VVvW5V ,
   "left"  : BF(self.VVNngl, -1)    ,
   "right"  : BF(self.VVNngl,  1)    ,
   "play"  : self.VVrcOm      ,
   "pause"  : self.VVrcOm      ,
   "playPause" : self.VVrcOm      ,
   "stop"  : self.VVrcOm      ,
   "rewind" : self.VVAyAE      ,
   "forward" : self.VV5Zhq      ,
   "rewindDm" : self.VVAyAE      ,
   "forwardDm" : self.VV5Zhq      ,
   "last"  : self.VV1Zv7      ,
   "next"  : self.VVEttg      ,
   "pageUp" : BF(self.VVOOML, True)  ,
   "pageDown" : BF(self.VVOOML, False)  ,
   "chanUp" : BF(self.VVOOML, True)  ,
   "chanDown" : BF(self.VVOOML, False)  ,
   "up"  : BF(self.VVOOML, True)  ,
   "down"  : BF(self.VVOOML, False)  ,
   "audio"  : BF(self.VVOqEB, True)  ,
   "subtitle" : BF(self.VVOqEB, False)  ,
   "0"   : BF(self.VVyQDq , 10)   ,
   "1"   : BF(self.VVyQDq , 1)   ,
   "2"   : BF(self.VVyQDq , 2)   ,
   "3"   : BF(self.VVyQDq , 3)   ,
   "4"   : BF(self.VVyQDq , 4)   ,
   "5"   : BF(self.VVyQDq , 5)   ,
   "6"   : BF(self.VVyQDq , 6)   ,
   "7"   : BF(self.VVyQDq , 7)   ,
   "8"   : BF(self.VVyQDq , 8)   ,
   "9"   : BF(self.VVyQDq , 9)
  }, -1)
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFGCUP(self)
  if not CCZilb.VV5SmK:
   CCZilb.VV5SmK = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFUKsz(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFUKsz(self["myPlayRpt"], "rpt")
  self.VVkFXs()
  self.instance.move(ePoint(40, 40))
  self.VVPjtK(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVtDXl)
  except:
   self.timer.callback.append(self.VVtDXl)
  self.timer.start(250, False)
  self.VVtDXl("Checking ...")
  self.VV4qQc()
 def VVqppu(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  self.lastSubtitle = CCZd3U.VVslnk()
  if "chCode" in iptvRef:
   if CCielb.VVhzF1(self):
    self.VV4qQc(True)
  else:
   self.VVtDXl("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVkFXs(self):
  self.satInfo_TP = ""
  refCode, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVQkSG()
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  FFQZ4f(self["myTitle"], tColor)
  FFQZ4f(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFQZ4f(self["myPlay%s" % item], tColor)
  picFile = CCGnOY.VVNdv1(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCGnOY.VVaaZL(self)
  cl = CCjvta.VVyu70(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVtDXl(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCuF83.VVsoHD()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVQkSG()
  if evName:
   evName = "    %s    " % FFtSnl(evName, VVpi4Z)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVctrS():
   FFryZu(self["myPlayBlu"], "#00FFFFFF")
   FFQZ4f(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
  else:
   FFryZu(self["myPlayBlu"], "#00FFFF88")
   FFQZ4f(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov if prov else "")
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  width = 0
  percent = FFDLFU(percVal, 0, 100)
  width = int(FFDe6w(percent, 0, 100, 0, self.barWidth))
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if not durTxt:
   self["myPlayVal"].setText(">>>>")
   FFQZ4f(self["myPlayBarBG"], tColor)
   self["myPlayBarF"].hide()
  else:
   FFQZ4f(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  if stateTxt:
   if highlight: FFryZu(self["myPlayMsg"], "#0000ffff")
   else  : FFryZu(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if isDvb:
   FFryZu(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV39mi()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVFqhu(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCZd3U.VVPTXb(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV1Zv7()
  state = self.VVlZjp()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFryZu(self["myPlayMsg"], "#0000ff00")
  else     : FFryZu(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVQkSG(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFxnns(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCGnOY.VV3Rhn(serv)
  if   isDvb : tColor = "#1100102a"
  elif isLocal: tColor = "#0a441100"
  elif "chCode" in origUrl:
   if "get_download_link" in origUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  else  : tColor = "#11002a2a"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCW6PA()
   tpTxt, satTxt = tp.VVoeZZ(refCode)
   self.satInfo_TP = tpTxt + "  " + FFtSnl(satTxt, VV4mPL)
  evName = evNameNext = ""
  if not seekable:
   evLst = CCGnOY.VVBy9W(refCode)
   if evLst:
    evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFFiXK(info, iServiceInformation.sVideoWidth) or -1
   h = FFFiXK(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFFiXK(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCGnOY.VVFTMM(info)
  return refCode, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVk80u(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFAdnL(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFAdnL(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFAdnL(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VV7a6z(self):
  if self.SubtWin:
   self.SubtWin.VVAM26()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  VVWp2B = []
  if self.isFromExternal:
   VVWp2B.append(("IPTV Menu"     , "iptv"  ))
   VVWp2B.append(VVEgY4)
  if FFmwez(iptvRef) and not "&end=" in decodedUrl and not FFh3oH(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CC5Be5.VVTRui(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVWp2B.append(("Catchup Programs"   , "catchup"  ))
    VVWp2B.append(VVEgY4)
  VVWp2B.append(("Stop Current Service"    , "stop"  ))
  VVWp2B.append(("Restart Current Service"   , "restart"  ))
  VVWp2B.append(VVEgY4)
  FFQlgASeries = FFh3oH(decodedUrl)
  if FFQlgASeries:
   VVWp2B.append(("File Size"     , "fileSize" ))
   VVWp2B.append(VVEgY4)
  if self.enableDownloadMenu:
   addSep = False
   if FFmwez(iptvRef) and FFQlgASeries:
    VVWp2B.append(("Start Download"   , "dload_cur" ))
    VVWp2B.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCuF83.VV9YR3():
    VVWp2B.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVWp2B.append(VVEgY4)
  fPath, fDir, fName = CC0Jp1.VVtTvV(self)
  if fPath:
   if not CC0Jp1.VVi5w5:
    VVWp2B.append((VVxbdF + "Open path in File Manager", "VVw8bc" ))
   VVWp2B.append((VVxbdF + "Add to Bouquet"        , "VV2C6y" ))
   VVWp2B.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVgbAx"  ))
   VVWp2B.append(VVEgY4)
  enabl = False
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
  if posVal and durVal:
   enabl = True
  else:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCGnOY.VViAPL(self)
   enabl = evName and evTime and evDur
  if enabl:
   VVWp2B.append((VVxbdF + "Start Subtitle"    , "VVaTzq"  ))
   VVWp2B.append(VVEgY4)
  if CFG.playerPos.getValue() : VVWp2B.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVWp2B.append(("Move Bar to Top"  , "top"     ))
  if not iptvRef:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv and not serv.getPath():
    VVWp2B.append((FFtSnl("Signal Monitor", VVFeau), "sigMon"  ))
  VVWp2B.append(("Help"             , "help"    ))
  FFkkcl(self, self.VVInpT, VVWp2B=VVWp2B, width=550, title="Options")
 def VVInpT(self, item=None):
  if item:
   if item == "iptv"     : self.VV5OdG()
   elif item == "catchup"    : self.VVvW5V()
   elif item == "stop"     : self.VV2QjR(0)
   elif item == "restart"    : self.VV2QjR(1)
   elif item == "fileSize"    : FFOvQF(self, BF(CCGnOY.VVOVFa, self), title="Checking Server")
   elif item == "dload_cur"   : CCuF83.VVRj9W(self)
   elif item == "addToDload"   : CCuF83.VVSKGf(self)
   elif item == "dload_stat"   : CCuF83.VVQEJc(self)
   elif item == "VVw8bc" : self.VVw8bc()
   elif item == "VV2C6y" : self.VV2C6y()
   elif item == "VVaTzq"  : self.VVaTzq(CCZd3U.VVMW3S)
   elif item == "VVgbAx"  : self.VVgbAx()
   elif item == "botm"     : self.VVPjtK(0)
   elif item == "top"     : self.VVPjtK(1)
   elif item == "sigMon"    : self.VV9Ksq()
   elif item == "help"     : FFXRcG(self, VVE4he + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCZilb.VV5SmK = None
  self.VVnfSF()
 def VVRe3t(self):
  if CCZilb.VV5SmK:
   self.session.open(CCZilb, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVw8bc(self):
  self.session.open(CC0Jp1, gotoMovie=True)
  self.VVRe3t()
 def VV5OdG(self):
  self.session.open(CC5Be5)
  self.VVRe3t()
 def VV2QjR(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVtDXl("Restarting Service ...")
    FFrvtJ(BF(self.VVccCs, serv))
 def VVccCs(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  if "&end=" in decodedUrl: BF(self.VV4qQc, True)
  else     : self.session.nav.playService(serv)
 def VV2C6y(self):
  fPath, fDir, fName = CC0Jp1.VVtTvV(self)
  if fPath: picker = CC0dGf(self, self, "Add Current Movie to a Bouquet", BF(self.VVql33, [fPath]))
  else : FFMnBb(self, "Path not found !", 1500)
 def VVql33(self, pathLst):
  return CC0dGf.VVGf8v(pathLst)
 def VVgbAx(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVtDXl(txt, highlight=ok)
 def VVaTzq(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCZd3U, mode=mode, endCallback=self.VVNs8u)
  self.SubtWin.show()
  self.SubtWin.VV1bxJ(useSubtFile)
 def VVNs8u(self, err):
  if err:
   if err == "noResume": self.VVnfSF(False)
   else    : self.VVnfSF(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCZd3U.VVVySz(self)
   else      : FFMnBb(self, err, 2000)
 def VVPjtK(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VV9Ksq(self):
  self.session.open(CCTEDW)
  self.close()
 def VVxkj1(self):
  if self.isManualSeek:
   self.VVzCcv()
   self.VVFqhu(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVaTzq(CCZd3U.VVAynG)
   else:
    self.VVnfSF()
 def VVnfSF(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVzCcv()
  elif self.SubtWin : self.VVnfSF()
  else    : self.close()
 def VVJnIW(self):
  if self.SubtWin:
   self.SubtWin.VVVoj4("noErr")
  FFRDSd(self, fncMode=CCGnOY.VV0ALq)
 def VVrcOm(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVtDXl("Toggling Play/Pause ...")
 def VVzCcv(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVNngl(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVMkl3()
   else:
    self.manualSeekSec += direc * self.VVMkl3()
    self.manualSeekSec = FFDLFU(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFDe6w(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFAdnL(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVyQDq(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVmnEw())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVtDXl("Changed Seek Time to : %d%s" % (val, self.VVsZhZ()))
 def VVmnEw(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVsZhZ())
 def VVsZhZ(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VV5sBZ(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVMkl3(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV39mi(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVJCTn(self):
  cList = self.VVctrS()
  if cList:
   VVWp2B = []
   for pts, what in cList:
    txt = FFAdnL(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVWp2B.append((txt, pts))
   FFkkcl(self, self.VVaCv7, VVWp2B=VVWp2B, title="Cut List")
  else:
   self.VVtDXl("No Cut-List for this channel !")
 def VVaCv7(self, item=None):
  if item:
   self.VVFqhu(item)
 def VVctrS(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV5Zhq(self) : self.VVnmvw(1)
 def VVAyAE(self) : self.VVnmvw(-1)
 def VVnmvw(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVMkl3() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VV5sBZ())
    self.VVtDXl(txt)
  except:
   self.VVtDXl("Cannot jump")
 def VVFqhu(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVtDXl("Changing Time ...")
 def VV1Zv7(self):
  self.VV2QjR(1)
  self.VVtDXl("Replaying ...")
  self.VVzCcv()
 def VVEttg(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVtDXl("Jumping to end ...")
  except:
   pass
 def VVlZjp(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVOOML(self, isUp):
  if self.enableZapping:
   self.VVtDXl("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVzCcv()
   if self.portalTableParam:
    FFrvtJ(BF(self.VVs8dz, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
    if "/timeshift/" in decodedUrl:
     self.VVtDXl("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVwlvg()
 def VVwlvg(self):
  self.lastPlayPos = 0
  self.VVkFXs()
  self.VV4qQc()
 def VVs8dz(self, isUp):
  CC5Be5_inatance, VVMsCC, mode = self.portalTableParam
  if isUp : VVMsCC.VVWhye()
  else : VVMsCC.VVIO1j()
  colList = VVMsCC.VV0cqe()
  if mode == "localIptv":
   chName, chUrl = CC5Be5_inatance.VVx0SN(VVMsCC, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC5Be5_inatance.VVM1lG(VVMsCC, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC5Be5_inatance.VVdyE5(mode, VVMsCC, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC5Be5_inatance.VVoL9e(mode, VVMsCC, colList)
  else:
   self.VVtDXl("Cannot Zap")
   return
  FFQ5yd(self, chUrl, VVz7YZ=False)
  self.VVwlvg()
 def VV4qQc(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
   if not self.VVfDCP(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVtDXl("Refreshing Portal")
   FFrvtJ(self.VVrf3D)
  except:
   pass
 def VVrf3D(self):
  self.restoreLastPlayPos = self.VVjSec()
 def VVvW5V(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
  if not decodedUrl or FFh3oH(decodedUrl):
   self.VVtDXl("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC5Be5.VVTRui(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVtDXl("Reading Program List ...")
   ok_fnc = BF(self.VVocXp, refCode, chName, streamId, uHost, uUser, uPass)
   FFrvtJ(BF(CC5Be5.VVKUGt, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVtDXl("Cannot process this channel")
 def VVocXp(self, refCode, chName, streamId, uHost, uUser, uPass, VVMsCC, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVMsCC.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVtDXl("Changing Program ...")
   FFrvtJ(BF(self.VVvezd, chUrl))
  else:
   self.VVtDXl("Incorrect Timestamp !")
 def VVvezd(self, chUrl):
   FFQ5yd(self, chUrl, VVz7YZ=False)
   self.lastPlayPos = 0
   self.VVkFXs()
 def VVOqEB(self, isAudio):
  try:
   VVe94g = InfoBar.instance
   if VVe94g:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVe94g)
    else  : self.session.open(SubtitleSelection, VVe94g)
  except:
   pass
class CCHgOS(Screen):
 def __init__(self, session, title="", VVljeR="Continue?", VV2Aw2=True, VVYN57=False):
  self.skin, self.skinParam = FFbZTb(VVuVSN, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVljeR = VVljeR
  self.VVYN57 = VVYN57
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV2Aw2 : VVWp2B = [no , yes]
  else   : VVWp2B = [yes, no ]
  FF2wUT(self, title, VVWp2B=VVWp2B, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxkj1 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVljeR)
  if self.VVYN57:
   self["myLabel"].instance.setHAlign(0)
  self.VVf4yA()
  FFysS0(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFdpaS(self["myMenu"])
  FF4E9v(self, self["myMenu"])
 def VVxkj1(self):
  item = FFxhQe(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVf4yA(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCVd7z(Screen):
 def __init__(self, session, title="", VVWp2B=None, width=1000, height=0, VVlOla=30, barText="", minRows=1, OKBtnFnc=None, VVaTfU=None, VVKBZE=None, VVBc7a=None, VVK0co=None, VV83XM=False, VV7G8l=False, VVcV6s="#22003344", VV89EB="#22002233"):
  if height == 0: height = 850
  self.skin, self.skinParam = FFbZTb(VVHFCN, width, height, 50, 40, 30, VVcV6s, VV89EB, VVlOla, barHeight=40)
  self.session   = session
  self.VVWp2B   = VVWp2B
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.VVaTfU   = VVaTfU
  self.VVKBZE  = VVKBZE
  self.VVBc7a  = VVBc7a
  self.VVK0co   = VVK0co
  self.VV83XM  = VV83XM
  self.VV7G8l  = VV7G8l
  FF2wUT(self, title, VVWp2B=VVWp2B)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxkj1          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVH536         ,
   "green"  : self.VVCaRg         ,
   "yellow" : self.VVmaWX         ,
   "blue"  : self.VVJgdL         ,
   "pageUp" : self.VVFfkQ       ,
   "chanUp" : self.VVFfkQ       ,
   "pageDown" : self.VV2ODu        ,
   "chanDown" : self.VV2ODu
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFysS0(self["myMenu"])
  FFMyEE(self, minRows=self.minRows)
  self.VVX7KI(self["keyRed"]  , self.VVaTfU )
  self.VVX7KI(self["keyGreen"] , self.VVKBZE )
  self.VVX7KI(self["keyYellow"] , self.VVBc7a )
  self.VVX7KI(self["keyBlue"]  , self.VVK0co )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFLvNc(self)
 def VVX7KI(self, btnObj, btnFnc):
  if btnFnc:
   FF4HaE(btnObj, btnFnc[0])
 def VV6CcV(self, fnc=None):
  self.VVKBZE = fnc
  if fnc : self.VVX7KI(self["keyGreen"], self.VVKBZE)
  else : self["keyGreen"].hide()
 def VVxkj1(self):
  item = FFxhQe(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV83XM: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVH536(self)  : self.VVzmuz(self.VVaTfU)
 def VVCaRg(self) : self.VVzmuz(self.VVKBZE)
 def VVmaWX(self) : self.VVzmuz(self.VVBc7a)
 def VVJgdL(self) : self.VVzmuz(self.VVK0co)
 def VVzmuz(self, btnFnc):
  if btnFnc:
   item = FFxhQe(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV7G8l:
    self.cancel()
 def VV5ZmU(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVWp2B = self["myMenu"].list
  VVWp2B.pop(ndx)
  if len(VVWp2B) > 0: self["myMenu"].setList(VVWp2B)
  else    : self.close()
 def VVE8XZ(self, VVWp2B):
  if len(VVWp2B) > 0:
   newList = []
   for item in VVWp2B:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFMyEE(self, minRows=self.minRows)
  else:
   self.close("")
 def VVrGMr(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVFfkQ(self):
  self["myMenu"].moveToIndex(0)
 def VV2ODu(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCw9VL(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVJXpL=None, VVKrzB=None, VVQGhe=None, VVlOla=26, VVLHme=False, VVBh0a=None, VV9ZE5=None, VV6i1u=None, VV1NOm=None, VVfzl8=None, VVL1b6=None, VVFKIR=None, VVaNtS=None, VVOTt1=None, VVhOBL=-1, VVf6X3=False, searchCol=0, lastFindConfigObj=None, VVcV6s=None, VV89EB=None, VVyjV0="#00dddddd", VVHzNF="#11002233", VVmD06="#00ff8833", VVhGFp="#11111111", VV3VgO="#0a555555", VVwQD5="#0affffff", VVGPak="#11552200", VVvqZS="#0055ff55"):
  self.skin, self.skinParam = FFbZTb(VVcj6X, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF2wUT(self, title)
  self.header     = header
  self.VVJXpL     = VVJXpL
  self.totalCols    = len(VVJXpL[0])
  self.VV3dkv   = 0
  self.lastSortModeIsReverese = False
  self.VVLHme   = VVLHme
  self.VVV9yb   = 0.01
  self.VVYMYE   = 0.02
  self.VV2JIw = 0.03
  self.VV6nZK  = 1
  self.VVQGhe = VVQGhe
  self.colWidthPixels   = []
  self.VVBh0a   = VVBh0a
  self.OKButtonObj   = None
  self.VV9ZE5   = VV9ZE5
  self.VV6i1u   = VV6i1u
  self.VV1NOm   = VV1NOm
  self.VVfzl8  = VVfzl8
  self.VVL1b6   = VVL1b6
  self.VVFKIR    = VVFKIR
  self.VVaNtS   = VVaNtS
  self.tableRefreshCB   = None
  self.VVOTt1  = VVOTt1
  self.VVhOBL    = VVhOBL
  self.VVf6X3   = VVf6X3
  self.searchCol    = searchCol
  self.VVKrzB    = VVKrzB
  self.keyPressed    = -1
  self.VVlOla    = FF6Vdr(VVlOla)
  self.VVu02V    = FFEiMT(self.VVlOla, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVcV6s    = VVcV6s
  self.VV89EB      = VV89EB
  self.VVyjV0    = FFcFXO(VVyjV0)
  self.VVHzNF    = FFcFXO(VVHzNF)
  self.VVmD06    = FFcFXO(VVmD06)
  self.VVhGFp    = FFcFXO(VVhGFp)
  self.VV3VgO   = FFcFXO(VV3VgO)
  self.VVwQD5    = FFcFXO(VVwQD5)
  self.VVGPak    = FFcFXO(VVGPak)
  self.VVvqZS   = FFcFXO(VVvqZS)
  self.VVE8N3  = False
  self.selectedItems   = 0
  self.VV9IRH   = FFcFXO("#01fefe01")
  self.VVhKhW   = FFcFXO("#11400040")
  self.VVX2j1  = self.VV9IRH
  self.VVq6BK  = self.VVhGFp
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVf6X3:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVdFGZ  ,
   "red"   : self.VVGhuB  ,
   "green"   : self.VVTAOe ,
   "yellow"  : self.VVuvvW ,
   "blue"   : self.VVk8QJ  ,
   "menu"   : self.VViPl3 ,
   "info"   : self.VVaifn  ,
   "cancel"  : self.VVQgHo  ,
   "up"   : self.VVIO1j    ,
   "down"   : self.VVWhye  ,
   "left"   : self.VVzAcr   ,
   "right"   : self.VVCdOb  ,
   "next"   : self.VVneul  ,
   "last"   : self.VVLhen  ,
   "home"   : self.VVCzPj  ,
   "pageUp"  : self.VVCzPj  ,
   "chanUp"  : self.VVCzPj  ,
   "end"   : self.VVSmFJ  ,
   "pageDown"  : self.VVSmFJ  ,
   "chanDown"  : self.VVSmFJ
  }, -1)
  FFsG3C(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFGCUP(self)
  try:
   self.VVVnYG()
  except Exception as err:
   FFNkji(self, str(err))
   self.close(None)
 def VVVnYG(self):
  FFLvNc(self)
  if self.VVcV6s:
   FFQZ4f(self["myTitle"], self.VVcV6s)
  if self.VV89EB:
   FFQZ4f(self["myBody"] , self.VV89EB)
   FFQZ4f(self["myTableH"] , self.VV89EB)
   FFQZ4f(self["myTable"] , self.VV89EB)
   FFQZ4f(self["myBar"]  , self.VV89EB)
  self.VVX7KI(self.VV6i1u  , self["keyRed"])
  self.VVX7KI(self.VV1NOm  , self["keyGreen"])
  self.VVX7KI(self.VVfzl8 , self["keyYellow"])
  self.VVX7KI(self.VVL1b6  , self["keyBlue"])
  if self.VVBh0a:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVBh0a[0])
    FFQZ4f(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVu02V)
  self["myTableH"].l.setFont(0, gFont(VV8NsC, self.VVlOla))
  self["myTable"].l.setItemHeight(self.VVu02V)
  self["myTable"].l.setFont(0, gFont(VV8NsC, self.VVlOla))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVu02V)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVu02V))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVu02V)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVu02V
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVu02V * len(self.VVJXpL) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVQGhe:
   self.VVQGhe = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVQGhe)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVKrzB:
   self.VVKrzB = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVKrzB
   self.VVKrzB = []
   for item in tmpList:
    self.VVKrzB.append(item | RT_VALIGN_CENTER)
  self.VVZHAP()
  if self.VVFKIR:
   self.VVFKIR(self)
 def VVX7KI(self, btnFnc, btn):
  if btnFnc : FF4HaE(btn, btnFnc[0])
  else  : FF4HaE(btn, "")
 def VVpdSw(self, waitTxt):
  FFOvQF(self, self.VVZHAP, title=waitTxt)
 def VVZHAP(self, onlyHeader=False):
  try:
   if self.header:
    self["myTableH"].setList([self.VVbUO9(0, self.header, self.VVwQD5, self.VVGPak, self.VVwQD5, self.VVGPak, self.VVvqZS)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVJXpL):
    self["myTable"].list.append(self.VVbUO9(c, row, self.VVyjV0, self.VVHzNF, self.VVmD06, self.VVhGFp, None))
   self.VVJXpL = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVhOBL > -1:
    self["myTable"].moveToIndex(self.VVhOBL )
   self.VVkMxM()
   if self.VVf6X3:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVu02V * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVaNtS:
    self.VVzmuz(self.VVaNtS, None)
   if self.tableRefreshCB:
    self.VVzmuz(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFNkji(self, str(err))
    self.close()
   except:
    pass
 def VVbUO9(self, keyIndex, columns, VVyjV0, VVHzNF, VVmD06, VVhGFp, VVvqZS):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVvqZS and ndx == self.VV3dkv : textColor = VVvqZS
   else           : textColor = VVyjV0
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFcFXO(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVHzNF = c
    entry = span.group(3)
   if self.VVKrzB[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVu02V)
           , font   = 0
           , flags   = self.VVKrzB[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVHzNF
           , color_sel  = VVmD06
           , backcolor_sel = VVhGFp
           , border_width = 1
           , border_color = self.VV3VgO
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVaifn(self):
  rowData = self.VVTNMh()
  if rowData:
   title, txt, colList = rowData
   if self.VV9ZE5:
    fnc  = self.VV9ZE5[1]
    params = self.VV9ZE5[2]
    fnc(self, title, txt, colList)
   else:
    FFzNhe(self, txt, title)
 def VVdFGZ(self):
  if   self.VVE8N3 : self.VVB8jc(self.VVeXGB(), mode=2)
  elif self.VVBh0a  : self.VVzmuz(self.VVBh0a, None)
  else      : self.VVaifn()
 def VVGhuB(self) : self.VVzmuz(self.VV6i1u , self["keyRed"])
 def VVTAOe(self) : self.VVzmuz(self.VV1NOm , self["keyGreen"])
 def VVuvvW(self): self.VVzmuz(self.VVfzl8 , self["keyYellow"])
 def VVk8QJ(self) : self.VVzmuz(self.VVL1b6 , self["keyBlue"])
 def VVzmuz(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFMnBb(self, buttonFnc[3])
    FFrvtJ(BF(self.VVFtlt, buttonFnc))
   else:
    self.VVFtlt(buttonFnc)
 def VVFtlt(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVTNMh()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVB8jc(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VV9IRH
   newRow = self.VV0cqe()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVbUO9(ndx, newRow, self.VVyjV0, self.VVHzNF, self.VVmD06, self.VVhGFp, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVbUO9(ndx, newRow, self.VV9IRH, self.VVhKhW, self.VVX2j1, self.VVq6BK, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVeXGB() < len(self["myTable"].list) - 1:
    self.VVWhye()
   else:
    self.VVkMxM()
 def VV6pI2(self)  : FFOvQF(self, BF(self.VVu1dg, True ), title="Selecting all ..."  )
 def VVR1Jm(self) : FFOvQF(self, BF(self.VVu1dg, False), title="Unselecting all ...")
 def VVu1dg(self, isSel=True):
  if isSel:
   fg, bg = self.VV9IRH, self.VVhKhW
   self.selectedItems = len(self["myTable"].list)
   self.VVDdFZ(True)
  else:
   fg, bg = self.VVyjV0, self.VVHzNF
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   for col in range(1, len(row)):
    param = list(self["myTable"].list[ndx][col])
    param[8]  = fg
    param[9]  = fg
    param[10] = bg
    self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVTNMh(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVQGhe[i] > 1 or self.VVQGhe[i] == self.VVV9yb or self.VVQGhe[i] == self.VV2JIw:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVQgHo(self):
  if self.VVOTt1 : self.VVOTt1(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVEU20(self):
  return self["myTitle"].getText().strip()
 def VVLxm8(self):
  return self.header
 def VVb9yH(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV9Ct6(self, txt):
  FFMnBb(self, txt)
 def VVQ7Zq(self, txt):
  FFMnBb(self, txt, 1000)
 def VVJmOH(self): self["keyGreen"].show()
 def VVdZPd(self): self["keyGreen"].hide()
 def VVjUpN(self):
  FFMnBb(self)
 def VVixUR(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VV7STd(self):
  return len(self["myTable"].list)
 def VVeXGB(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVPmHc(self):
  return len(self["myTable"].list)
 def VVDdFZ(self, isOn):
  self.VVE8N3 = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVL1b6: self["keyBlue"].hide()
   if self.VVBh0a and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVL1b6: self["keyBlue"].show()
   if self.VVBh0a and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVBh0a[0])
   self.VVR1Jm()
  FFQZ4f(self["myTitle"], color)
  FFQZ4f(self["myBar"]  , color)
 def VVvs58(self):
  return self.VVE8N3
 def VVtQKr(self):
  return self.selectedItems
 def VVDbpO(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVkMxM()
 def VVX5R4(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVICpc(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV7STd()
  txt += FFpGai("Total Unique Items", VVpqRv)
  for i in range(self.totalCols):
   if self.VVQGhe[i - 1] > 1 or self.VVQGhe[i - 1] == self.VVV9yb or self.VVQGhe[i - 1] == self.VV2JIw:
    name, tot = self.VVX5R4(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFzNhe(self, txt)
 def VVG5WS(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV0cqe(self):
  return self.VVHJX1(self["myTable"].l.getCurrentSelectionIndex())
 def VVHJX1(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVsLrn(self, newList, newTitle="", VVeXLRMsg=True, tableRefreshCB=None):
  if newList:
   self.VVJXpL = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   if self.VVLHme and self.VV3dkv == 0:
    self.VVJXpL.sort(key=lambda x: int(x[self.VV3dkv]) , reverse=self.lastSortModeIsReverese)
   else:
    self.VVJXpL.sort(key=lambda x: x[self.VV3dkv].lower() , reverse=self.lastSortModeIsReverese)
   if VVeXLRMsg : self.VVpdSw("Refreshing ...")
   else   : self.VVZHAP()
   if newTitle:
    self.VVb9yH(newTitle)
  else:
   FFNkji(self, "Cannot refresh list")
   self.cancel()
 def VVNvto(self, data):
  ndx = self.VVeXGB()
  newRow = self.VVbUO9(ndx, data, self.VVyjV0, self.VVHzNF, self.VVmD06, self.VVhGFp, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVkMxM()
   return True
  else:
   return False
 def VV6kaZ(self, colNum, textToFind, VVvNCa=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVkMxM()
    break
  else:
   if VVvNCa:
    FFMnBb(self, "Not found", 1000)
 def VVrsh1(self, colDict, VVvNCa=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVkMxM()
    return
  if VVvNCa:
   FFMnBb(self, "Not found", 1000)
 def VV3Dgb(self, colDict, VVvNCa=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVkMxM()
    return
  if VVvNCa:
   FFMnBb(self, "Not found", 1000)
 def VVHiTf(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVXWzY(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV9IRH:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVC1Rc(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VV9IRH: return True
  else        : return False
 def VVy2g3(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VViPl3(self):
  if not self["keyMenu"].getVisible() or self.VVf6X3:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVeXGB()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVWp2B1, VVjt2V = CCG8u1.VV5vkf(self, False, False)
  VVWp2B = []
  VVWp2B.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVWp2B.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVWp2B.append(("Find ...\t\t%s" % (FFtSnl(txt, VVMXOB) if txt else ""), "findNew"   ))
  VVWp2B.append(itemOf(bool(VVWp2B1)    , "Find (from Filter) ..."   , "filter"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Table Statistcis"             , "tableStat"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append((FFtSnl("Export Table to .html"     , VVpqRv) , "VVSh66" ))
  VVWp2B.append((FFtSnl("Export Table to .csv"     , VVpqRv) , "VV2jZ8" ))
  VVWp2B.append((FFtSnl("Export Table to .txt (Tab Separated)", VVpqRv) , "VV0G9G" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVQGhe[i] > 1 or self.VVQGhe[i] == self.VVYMYE:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVWp2B.append(VVEgY4)
   if tot == 1 : VVWp2B.append(("Sort", sList[0][1]))
   else  : VVWp2B += sList
  VVK0co = ("Keys Help", self.FFGcVXHelp)
  FFkkcl(self, self.VVAkTL, VVWp2B=VVWp2B, title=self.VVEU20(), VVK0co=VVK0co)
 def VVAkTL(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVscBr()
   elif item == "findPrev"  : self.VVscBr(isPrev=True)
   elif item == "findNew"  : self.VVOXfE()
   elif item == "filter"  : self.VVlno6()
   elif item == "tableStat" : self.VVICpc()
   elif item == "VVSh66": FFOvQF(self, self.VVSh66, title=title)
   elif item == "VV2jZ8" : FFOvQF(self, self.VV2jZ8 , title=title)
   elif item == "VV0G9G" : FFOvQF(self, self.VV0G9G , title=title)
   else:
    isReversed = False
    if self.VV3dkv == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVLHme and item == 0 : self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]) , reverse=isReversed)
    else        : self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=isReversed)
    self["myTable"].l.setList(self["myTable"].list)
    self.VV3dkv = item
    self.VVZHAP(onlyHeader=True)
 def FFGcVXHelp(self, menuInstance, path):
  FFXRcG(self, VVE4he + "_help_table", "Table (Keys Help)")
 def VVIO1j(self):
  self["myTable"].up()
  self.VVkMxM()
 def VVWhye(self):
  self["myTable"].down()
  self.VVkMxM()
 def VVzAcr(self):
  self["myTable"].pageUp()
  self.VVkMxM()
 def VVCdOb(self):
  self["myTable"].pageDown()
  self.VVkMxM()
 def VVCzPj(self):
  self["myTable"].moveToIndex(0)
  self.VVkMxM()
 def VVSmFJ(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVkMxM()
 def VVtsKn(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVkMxM()
 def VVneul(self):
  if self.lastFindConfigObj.getValue():
   if self.VVeXGB() == len(self["myTable"].list) - 1 : FFMnBb(self, "End reached", 1000)
   else              : self.VVscBr()
  else:
   FFMnBb(self, 'Set "Find" in Menu', 1500)
 def VVLhen(self):
  if self.lastFindConfigObj.getValue():
   if self.VVeXGB() == 0 : FFMnBb(self, "Top reached", 1000)
   else       : self.VVscBr(isPrev=True)
  else:
   FFMnBb(self, 'Set "Find" in Menu', 1500)
 def VVKM0E(self, txt):
  self.lastFindConfigObj.setValue(txt)
  self.lastFindConfigObj.save()
  configfile.save()
 def VVOXfE(self):
  FFhzot(self, self.VVFwOf, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVFwOf(self, VVk7Wd):
  if not VVk7Wd is None:
   txt = VVk7Wd.strip()
   self.VVKM0E(txt)
   if VVk7Wd: self.VVscBr(reset=True)
   else  : FFMnBb(self, "Nothing to find !", 1500)
 def VVlno6(self):
  VVWp2B, VVjt2V = CCG8u1.VV5vkf(self, False, False)
  if VVWp2B : FFkkcl(self, self.VVYJIC, VVWp2B=VVWp2B, title="Find from Filter")
  else  : FFMnBb(self, "Filter Error !", 1500)
 def VVYJIC(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVKM0E(txt)
    self.VVscBr(reset=True)
   else:
    FFMnBb(self, "No entry !", 1500)
 def VVscBr(self, reset=False, isPrev=False):
  curRow = self.VVeXGB()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCG8u1.VVStOm(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVtsKn(i)
      break
    elif any(x in line for x in tupl):
     self.VVtsKn(i)
     break
   else:
    FFMnBb(self, "Not found", 1000)
  else:
   FFMnBb(self, "Check your query", 1500)
 def VV0G9G(self):
  expFile = self.VVkhvr() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVw3eA()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVHJX1(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVQGhe[ndx] > self.VV6nZK or self.VVQGhe[ndx] == self.VV2JIw:
      col = self.VVkRyd(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVG429(expFile)
 def VV2jZ8(self):
  expFile = self.VVkhvr() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVw3eA()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVHJX1(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVQGhe[ndx] > self.VV6nZK or self.VVQGhe[ndx] == self.VV2JIw:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVkRyd(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVG429(expFile)
 def VVSh66(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVEU20(), PLUGIN_NAME, VVJHEy)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVEU20()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVw3eA()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVQGhe:
   colgroup += '   <colgroup>'
   for w in self.VVQGhe:
    if w > self.VV6nZK or w == self.VV2JIw:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVkhvr() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVHJX1(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVQGhe[ndx] > self.VV6nZK or self.VVQGhe[ndx] == self.VV2JIw:
      col = self.VVkRyd(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVG429(expFile)
 def VVw3eA(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVQGhe[ndx] > self.VV6nZK or self.VVQGhe[ndx] == self.VV2JIw:
     newRow.append(col.strip())
  return newRow
 def VVkRyd(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFYfxZ(col)
 def VVkhvr(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVEU20())
  fileName = fileName.replace("__", "_")
  path  = FFjGgP(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF03bo()
  return expFile
 def VVG429(self, expFile):
  FFO5iz(self, "File exported to:\n\n%s" % expFile, title=self.VVEU20())
 def VVkMxM(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCjvta():
 def __init__(self, pixmapObj, picPath, VVHzNF=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVHzNF  = VVHzNF or "#2200002a"
 def VVdd19(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVG1Am)
    except:
     self.picLoad.PictureData.get().append(self.VVG1Am)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVHzNF])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVG1Am(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VV5wXr(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVyu70(pixmapObj, path, VVHzNF=None):
  cl = CCjvta(pixmapObj, path, VVHzNF)
  ok = cl.VVdd19()
  if ok: return cl
  else : return None
class CCTnxh(Screen):
 def __init__(self, session, title="", VV9WF2=None, showGrnMsg=""):
  self.skin, self.skinParam = FFbZTb(VVaWzv, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VV9WF2),
  self.session = session
  FF2wUT(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VV9WF2 = VV9WF2
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VV5WGz)
  self.onClose.append(self.onExit)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self.picViewer = CCjvta.VVyu70(self["myPic"], self.VV9WF2)
  if self.picViewer:
   if self.showGrnMsg:
    FFMnBb(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFNkji(self, "Cannot view picture file:\n\n%s" % self.VV9WF2)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV5wXr()
 @staticmethod
 def VVJldG(SELF, VV9WF2, title="", showGrnMsg=""):
  SELF.session.open(BF(CCTnxh, title=title, VV9WF2=VV9WF2, showGrnMsg=showGrnMsg))
class CCVDyw(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFbZTb(VV0IRp, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF2wUT(self, title=self.Title)
  FF4HaE(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVGp08:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVqWYD:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVJ1qT *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVJ1qT *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVJ1qT *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVpJ6S()
  self.onShown.append(self.VV5WGz)
 def VVpJ6S(self):
  kList = {
    "ok"  : self.VVxkj1    ,
    "green"  : self.VVQXyx   ,
    "menu"  : self.VVIjcV  ,
    "cancel" : self.VVsi0e  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVXxsV, 0)
     kList["chanDown"] = BF(self["config"].VVXxsV, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFGCUP(self)
  FFysS0(self["config"])
  FFMyEE(self, self["config"])
  FFLvNc(self)
 def VVxkj1(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsMode   : self.VVuDGN()
   elif item == CFG.MovieDownloadPath   : self.VVWQmR(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVdXoG(item)
   elif item == CFG.backupPath    : self.VVdXoG(item)
   elif item == CFG.packageOutputPath  : self.VVdXoG(item)
   elif item == CFG.downloadedPackagesPath : self.VVdXoG(item)
   elif item == CFG.exportedTablesPath  : self.VVdXoG(item)
   elif item == CFG.exportedPIconsPath  : self.VVdXoG(item)
 def VVWQmR(self, item, title):
  tot = CCuF83.VVsoHD()
  if tot : FFNkji(self, "Cannot change while downloading.", title=title)
  else : self.VVdXoG(item)
 def VVuDGN(self):
  VVWp2B = []
  VVWp2B.append(("Auto Find" , "auto"))
  VVWp2B.append(("Custom Path" , "cust"))
  FFkkcl(self, self.VVfz4y, VVWp2B=VVWp2B, title="IPTV Hosts Files Path")
 def VVfz4y(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VV2lDQ)
   elif item == "cust":
    VVMGU8 = self.VVSX3h()
    if VVMGU8 : self.VVi1nU(VVMGU8)
    else  : self.session.openWithCallback(self.VV2teP, BF(CC0Jp1, mode=CC0Jp1.VVahR0, VV4wg8="/"))
 def VVi1nU(self, VVMGU8):
  VVOTt1 = self.VVJ4S6
  VV6i1u = ("Remove"  , self.VVeHmf , [])
  VVfzl8 = ("Add "  , self.VVKqSS, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVKrzB  = (LEFT   , LEFT  )
  FFGcVX(self, None, title="IPTV Hosts Search Paths", header=header, VVJXpL=VVMGU8, width=1200, height=700, VVKrzB=VVKrzB, VVQGhe=widths, VVlOla=26, VVOTt1=VVOTt1, VV6i1u=VV6i1u, VVfzl8=VVfzl8
    , VV89EB="#11110000", VVcV6s="#11220000", VVHzNF="#11110011", VVmD06="#00ffff00", VVhGFp="#00223025", VV3VgO="#0a333333", VVGPak="#0a400040")
 def VVJ4S6(self, VVMsCC):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVWUoy)
  VVMsCC.cancel()
 def VV2teP(self, path):
  if path:
   CFG.iptvHostsDirs.setValue(FFjGgP(path.strip()))
   self.VVxeaC()
   VVMGU8 = self.VVSX3h()
   if VVMGU8 : self.VVi1nU(VVMGU8)
   else  : FFMnBb(self, "Cannot add dir", 1500)
 def VVYM6N(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VV2lDQ:
   return []
  return lst
 def VVSX3h(self):
  lst = self.VVYM6N()
  if lst:
   VVMGU8 = []
   for Dir in lst:
    VVMGU8.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVMGU8.sort(key=lambda x: x[0].lower())
   return VVMGU8
  else:
   return []
 def VVKqSS(self, VVMsCC, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VV9rhV, VVMsCC)
         , BF(CC0Jp1, mode=CC0Jp1.VVahR0, VV4wg8=sDir))
 def VV9rhV(self, VVMsCC, path):
  if path:
   path = FFjGgP(path.strip())
   if self.VVhACU(VVMsCC, path):
    FFMnBb(VVMsCC, "Already added", 1500)
   else:
    lst = self.VVYM6N()
    lst.append(path)
    CFG.iptvHostsDirs.setValue(",".join(lst))
    self.VVxeaC()
    VVMGU8 = self.VVSX3h()
    VVMsCC.VVsLrn(VVMGU8, tableRefreshCB=BF(self.VVFN6n, path))
 def VVFN6n(self, path, VVMsCC, title, txt, colList):
  self.VVhACU(VVMsCC, path)
 def VVhACU(self, VVMsCC, path):
  for ndx, row in enumerate(VVMsCC.VVy2g3()):
   if row[0].strip() == path.strip():
    VVMsCC.VVtsKn(ndx)
    return True
  return False
 def VVeHmf(self, VVMsCC, title, txt, colList):
  path = colList[0]
  FFm5Au(self, BF(self.VVcVIe, VVMsCC), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVcVIe(self, VVMsCC):
  row = VVMsCC.VV0cqe()
  path, rem = row[0], row[1]
  VVMGU8 = []
  lst = []
  for ndx, row in enumerate(VVMsCC.VVy2g3()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVMGU8.append((tPath, tRem))
  if len(VVMGU8) > 0:
   CFG.iptvHostsDirs.setValue(",".join(lst))
   self.VVxeaC()
   VVMsCC.VVsLrn(VVMGU8)
   FFMnBb(VVMsCC, "Deleted", 1500)
  else:
   CFG.iptvHostsMode.setValue(VV2lDQ)
   CFG.iptvHostsMode.save()
   CFG.iptvHostsDirs.setValue("")
   self.VVxeaC()
   VVMsCC.cancel()
   FFrvtJ(BF(FFMnBb, self, "Changed to Auto-Find", 1500))
 def VVxeaC(self):
  CFG.iptvHostsDirs.save()
  configfile.save()
 def VVdXoG(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVMcQB, configObj)
         , BF(CC0Jp1, mode=CC0Jp1.VVahR0, VV4wg8=sDir))
 def VVMcQB(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVsi0e(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFm5Au(self, self.VVQXyx, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVQXyx(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVkUuV()
  self.VVDYbW()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVDYbW(self):
  CCF2zZ.VVukuk()
 def VVIjcV(self):
  VVWp2B = []
  VVWp2B.append(("Use Backup Path for Package/Download/Tables/PIcons"   , "VV6lRz"   ))
  VVWp2B.append(("Reset %s Settings" % PLUGIN_NAME        , "VVtoud"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Backup %s Settings" % PLUGIN_NAME        , "VVPnlt"  ))
  VVWp2B.append(("Restore %s Settings" % PLUGIN_NAME       , "VVGXUk"  ))
  if fileExists(VVcqbj + VVzPWd):
   VVWp2B.append(VVEgY4)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVWp2B.append(('%s Checking for Update' % txt1       , txt2     ))
   VVWp2B.append(("Reinstall %s" % PLUGIN_NAME        , "VVdTvT"  ))
   VVWp2B.append(("Update %s" % PLUGIN_NAME        , "VVoctH"   ))
  FFkkcl(self, self.VVvzNv, VVWp2B=VVWp2B, title="Config. Options")
 def VVvzNv(self, item=None):
  if item:
   if   item == "VV6lRz"  : FFm5Au(self, self.VV6lRz , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVtoud"  : FFm5Au(self, self.VVtoud, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCJoLU)
   elif item == "VVPnlt" : self.VVPnlt()
   elif item == "VVGXUk" : FFOvQF(self, self.VVGXUk, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVfCj7(True)
   elif item == "disableChkUpdate" : self.VVfCj7(False)
   elif item == "VVdTvT" : FFOvQF(self, self.VVdTvT , "Checking Server ...")
   elif item == "VVoctH"  : FFOvQF(self, self.VVoctH  , "Checking Server ...")
 def VVPnlt(self):
  path = "%sajpanel_settings_%s" % (VVcqbj, FF03bo())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFO5iz(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVGXUk(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FF42E1("find / %s -iname '%s*' | grep %s" % (FFizMC(1), name, name))
  if lines:
   lines.sort()
   VVWp2B = []
   for line in lines:
    VVWp2B.append((line, line))
   FFkkcl(self, BF(self.VV4k15, title), title=title, VVWp2B=VVWp2B, width=1200)
  else:
   FFNkji(self, "No settings files found !", title=title)
 def VV4k15(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFsCGi(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVkUuV()
    FFnpBj()
   else:
    FFdzz0(SELF, path, title=title)
 def VVfCj7(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VV6lRz(self):
  newPath = FFjGgP(VVcqbj)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVkUuV()
 @staticmethod
 def VVhN1R():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVtoud(self):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVkUuV()
  self.close()
 def VVkUuV(self):
  configfile.save()
  global VVcqbj
  VVcqbj = CFG.backupPath.getValue()
  FFFyU6()
 def VVoctH(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVyUu6(title)
  if webVer:
   FFm5Au(self, BF(FFOvQF, self, BF(self.VVdSjs, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVdTvT(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVyUu6(title, True)
  if webVer:
   FFm5Au(self, BF(FFOvQF, self, BF(self.VVdSjs, webVer, title, True)), "Install and Restart ?", title=title)
 def VVdSjs(self, webVer, title, isReinst=False):
  url = self.VV4z4h(self, title)
  if url:
   VVeUfE = FFc0wg() == "dpkg"
   if VVeUfE == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVeUfE else "ipk")
   path, err = FFhNjK(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFWksx(VVXPbD, path)
    else  : cmd = FFWksx(VV6une, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FF355v(self, cmd)
    else:
     FFdMgN(self, title=title)
   else:
    FFNkji(self, err, title=title)
 def VVyUu6(self, title, anyVer=False):
  url = self.VV4z4h(self, title)
  if not url:
   return ""
  path, err = FFhNjK(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFNkji(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFS3H9(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFNkji(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVJHEy.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FF42E1(cmd)
   if list and curVer == list[0]:
    return webVer
  FFO5iz(self, FFtSnl("No update required.", VV41YE) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VV4z4h(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVcqbj + VVzPWd
  if fileExists(path):
   span = iSearch(r"(http.+)", FFS3H9(path), IGNORECASE)
   if span : url = FFjGgP(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFNkji(SELF, err, title)
  return url
 @staticmethod
 def VVDHyj(url):
  path, err = FFhNjK(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFS3H9(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVJHEy.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FF42E1(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCJoLU(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFbZTb(VVoG3n, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVFYPg
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF2wUT(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVdAcU("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVdAcU("\c00888888", i) + sp + "GREY\n"
   txt += self.VVdAcU("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVdAcU("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVdAcU("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVdAcU("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVdAcU("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVdAcU("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVdAcU("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVdAcU("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVdAcU("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVdAcU("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVxkj1 ,
   "green"   : self.VVxkj1 ,
   "left"   : self.VVmpQP ,
   "right"   : self.VVV9jd ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  self.VVnJVG()
 def VVxkj1(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFm5Au(self, self.VV5Tb1, "Change to : %s" % txt, title=self.Title)
 def VV5Tb1(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVFYPg
  VVFYPg = self.cursorPos
  self.VV8rsT()
  self.close()
 def VVmpQP(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVnJVG()
 def VVV9jd(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVnJVG()
 def VVnJVG(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVdAcU(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVBZ2S(color):
  if VVxbdF: return "\\" + color
  else    : return ""
 @staticmethod
 def VV8rsT():
  global VVAc0p, VVpi4Z, VVG74s, VVFkfi, VVpqRv, VVvinO, VVEwOk, VV41YE, VVxbdF, VVFeau, VVMXOB, VV4mPL, VV31Rm, VVXldd
  VVXldd   = CCJoLU.VVdAcU("\c00FFFFFF", VVFYPg)
  VVpi4Z    = CCJoLU.VVdAcU("\c00888888", VVFYPg)
  VVAc0p  = CCJoLU.VVdAcU("\c005A5A5A", VVFYPg)
  VVEwOk    = CCJoLU.VVdAcU("\c00FF0000", VVFYPg)
  VVG74s   = CCJoLU.VVdAcU("\c00FF5000", VVFYPg)
  VVFkfi   = CCJoLU.VVdAcU("\c00FFBB66", VVFYPg)
  VVxbdF   = CCJoLU.VVdAcU("\c00FFFF00", VVFYPg)
  VVFeau = CCJoLU.VVdAcU("\c00FFFFAA", VVFYPg)
  VV41YE   = CCJoLU.VVdAcU("\c0000FF00", VVFYPg)
  VVvinO    = CCJoLU.VVdAcU("\c000066FF", VVFYPg)
  VVMXOB    = CCJoLU.VVdAcU("\c0000FFFF", VVFYPg)
  VV4mPL  = CCJoLU.VVdAcU("\c00DSFFFF", VVFYPg)  #
  VV31Rm   = CCJoLU.VVdAcU("\c00FA55E7", VVFYPg)
  VVpqRv    = CCJoLU.VVdAcU("\c00FF8F5F", VVFYPg)
CCJoLU.VV8rsT()
class CCwDfU(Screen):
 def __init__(self, session, path, VVeUfE):
  self.skin, self.skinParam = FFbZTb(VVqL9P, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVbeKf   = path
  self.VVXZEN   = ""
  self.VVhLSr   = ""
  self.VVeUfE    = VVeUfE
  self.VVaEfI    = ""
  self.VVU4kd  = ""
  self.VV7RK7    = False
  self.VV9gUl  = False
  self.postInstAcion   = 0
  self.VV6kln  = "enigma2-plugin-extensions"
  self.VVcEa5  = "enigma2-plugin-systemplugins"
  self.VVPP5a = "enigma2"
  self.VVVYDy  = 0
  self.VVv1si  = 1
  self.VVPF8z  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVIVyT = "DEBIAN"
  else        : self.VVIVyT = "CONTROL"
  self.controlPath = self.Path + self.VVIVyT
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVeUfE:
   self.packageExt  = ".deb"
   self.VVHzNF  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVHzNF  = "#11001020"
  FF2wUT(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF4HaE(self["keyRed"] , "Create")
  FF4HaE(self["keyGreen"] , "Post Install")
  FF4HaE(self["keyYellow"], "Installation Path")
  FF4HaE(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVkCUS  ,
   "green"   : self.VVs1tb ,
   "yellow"  : self.VVrduX  ,
   "blue"   : self.VV5h3Y  ,
   "cancel"  : self.VV9DHQ
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFLvNc(self)
  if self.VVHzNF:
   FFQZ4f(self["myBody"], self.VVHzNF)
   FFQZ4f(self["myLabel"], self.VVHzNF)
  self.VVprES(True)
  self.VVqbyq(True)
 def VVqbyq(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVM1eL()
  if isFirstTime:
   if   package.startswith(self.VV6kln) : self.VVbeKf = VVubKs + self.VVaEfI + "/"
   elif package.startswith(self.VVcEa5) : self.VVbeKf = VVkWLd + self.VVaEfI + "/"
   else            : self.VVbeKf = self.Path
  if self.VV7RK7 : myColor = VVpqRv
  else    : myColor = VVXldd
  txt  = ""
  txt += "Source Path\t: %s\n" % FFtSnl(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFtSnl(self.VVbeKf, VVxbdF)
  if self.VVhLSr : txt += "Package File\t: %s\n" % FFtSnl(self.VVhLSr, VVpi4Z)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFtSnl("Check Control File fields : %s" % errTxt, VVG74s)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFtSnl("Restart GUI", VVpqRv)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFtSnl("Reboot Device", VVpqRv)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFtSnl("Post Install", VV41YE), act)
  if not errTxt and VVG74s in controlInfo:
   txt += "Warning\t: %s\n" % FFtSnl("Errors in control file may affect the result package.", VVG74s)
  txt += "\nControl File\t: %s\n" % FFtSnl(self.controlFile, VVpi4Z)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVs1tb(self):
  VVWp2B = []
  VVWp2B.append(("No Action"    , "noAction"  ))
  VVWp2B.append(("Restart GUI"    , "VVP3ns"  ))
  VVWp2B.append(("Reboot Device"   , "rebootDev"  ))
  FFkkcl(self, self.VVieBk, title="Package Installation Option (after completing installation)", VVWp2B=VVWp2B)
 def VVieBk(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVP3ns"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVprES(False)
   self.VVqbyq()
 def VVrduX(self):
  rootPath = FFtSnl("/%s/" % self.VVaEfI, VVAc0p)
  VVWp2B = []
  VVWp2B.append(("Current Path"        , "toCurrent"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Extension Path"       , "toExtensions" ))
  VVWp2B.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVWp2B.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFkkcl(self, self.VV5Ff6, title="Installation Path", VVWp2B=VVWp2B)
 def VV5Ff6(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVUhnP(FFO4sU(self.Path, True))
   elif item == "toExtensions"  : self.VVUhnP(VVubKs)
   elif item == "toSystemPlugins" : self.VVUhnP(VVkWLd)
   elif item == "toRootPath"  : self.VVUhnP("/")
   elif item == "toRoot"   : self.VVUhnP("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVQIoN, BF(CC0Jp1, mode=CC0Jp1.VVahR0, VV4wg8=VVcqbj))
 def VVQIoN(self, path):
  if len(path) > 0:
   self.VVUhnP(path)
 def VVUhnP(self, parent, withPackageName=True):
  if withPackageName : self.VVbeKf = parent + self.VVaEfI + "/"
  else    : self.VVbeKf = "/"
  mode = self.VVtPZL()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVpe5s(mode), self.controlFile))
  self.VVqbyq()
 def VV5h3Y(self):
  if fileExists(self.controlFile):
   lines = FFsCGi(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFhzot(self, self.VV8o3w, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFNkji(self, "Version not found or incorrectly set !")
  else:
   FFdzz0(self, self.controlFile)
 def VV8o3w(self, VVk7Wd):
  if VVk7Wd:
   version, color = self.VVegNp(VVk7Wd, False)
   if color == VVMXOB:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVk7Wd, self.controlFile))
    self.VVqbyq()
   else:
    FFNkji(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV9DHQ(self):
  if self.newControlPath:
   if self.VV7RK7:
    self.VVNkaB()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFtSnl(self.newControlPath, VVpi4Z)
    txt += FFtSnl("Do you want to keep these files ?", VVxbdF)
    FFm5Au(self, self.close, txt, callBack_No=self.VVNkaB, title="Create Package", VVYN57=True)
  else:
   self.close()
 def VVNkaB(self):
  os.system(FFBSzC("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVpe5s(self, mode):
  if   mode == self.VVv1si : prefix = self.VV6kln
  elif mode == self.VVPF8z : prefix = self.VVcEa5
  else        : prefix = self.VVPP5a
  return prefix + "-" + self.VVU4kd
 def VVtPZL(self):
  if   self.VVbeKf.startswith(VVubKs) : return self.VVv1si
  elif self.VVbeKf.startswith(VVkWLd) : return self.VVPF8z
  else            : return self.VVVYDy
 def VVprES(self, isFirstTime):
  self.VVaEfI   = FFRwag(self.Path)
  self.VVaEfI   = "_".join(self.VVaEfI.split())
  self.VVU4kd = self.VVaEfI.lower()
  self.VV7RK7 = self.VVU4kd == VV2PHh.lower()
  if self.VV7RK7 and self.VVU4kd.endswith("ajpan"):
   self.VVU4kd += "el"
  if self.VV7RK7 : self.VVXZEN = VVcqbj
  else    : self.VVXZEN = CFG.packageOutputPath.getValue()
  self.VVXZEN = FFjGgP(self.VVXZEN)
  if not pathExists(self.controlPath):
   os.system(FFBSzC("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VV7RK7 : t = PLUGIN_NAME
  else    : t = self.VVaEfI
  self.VVqTsf(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVH5lR.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VV7RK7 : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVqTsf(self.postrmFile, txt)
  if self.VV7RK7:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVJHEy)
   self.VVqTsf(self.preinstFile, txt)
  else:
   self.VVqTsf(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVaEfI)
  mode = self.VVtPZL()
  if isFirstTime and not mode == self.VVVYDy:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVJ1qT
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVqTsf(self.postinstFile, txt, VVQUbv=True)
  os.system(FFBSzC("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VV7RK7 : version, descripton, maintainer = VVJHEy , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVaEfI , self.VVaEfI
   txt = ""
   txt += "Package: %s\n"  % self.VVpe5s(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVqTsf(self, path, lines, VVQUbv=False):
  if not fileExists(path) or VVQUbv:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVM1eL(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFsCGi(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFtSnl(line, VVG74s)
     elif not line.startswith(" ")    : line = FFtSnl(line, VVG74s)
     else          : line = FFtSnl(line, VVMXOB)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVMXOB
   else   : color = VVG74s
   descr = FFtSnl(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVG74s
     elif line.startswith((" ", "\t")) : color = VVG74s
     elif line.startswith("#")   : color = VVpi4Z
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVegNp(val, True)
      elif key == "Version"  : version, color = self.VVegNp(val, False)
      elif key == "Maintainer" : maint  , color = val, VVMXOB
      elif key == "Architecture" : arch  , color = val, VVMXOB
      else:
       color = VVMXOB
      if not key == "OE" and not key.istitle():
       color = VVG74s
     else:
      color = VVpqRv
     txt += FFtSnl(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVhLSr = self.VVXZEN + packageName
   self.VV9gUl = True
   errTxt = ""
  else:
   self.VVhLSr  = ""
   self.VV9gUl = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVegNp(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVMXOB
  else          : return val, VVG74s
 def VVkCUS(self):
  if not self.VV9gUl:
   FFNkji(self, "Please fix Control File errors first.")
   return
  if self.VVeUfE: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFO4sU(self.VVbeKf, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVaEfI
  symlinkTo  = FFRs7V(self.Path)
  dataDir   = self.VVbeKf.rstrip("/")
  removePorjDir = FFBSzC("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFBSzC("rm -f '%s'" % self.VVhLSr) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFrwtR()
  if self.VVeUfE:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFkr8y("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV7RK7:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVbeKf == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVIVyT)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVhLSr, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVhLSr
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVhLSr, FF7gKg(result  , VV41YE))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVbeKf, FF7gKg(instPath, VVMXOB))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF7gKg(failed, VVG74s))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF355v(self, cmd)
class CC0dGf():
 VVYFGU  = "666"
 VV4ytl   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VV0Ack()
 def VV0Ack(self):
  VVWp2B = CC0dGf.VV1JB7()
  if VVWp2B:
   VVBc7a = ("Create New", self.VVo7lK)
   self.menuInstance = FFkkcl(self.SELF, self.VVq44i, VVWp2B=VVWp2B, title=self.Title, VVBc7a=VVBc7a, VV83XM=True, VVcV6s="#22222233", VV89EB="#22222233")
  else:
   self.VVo7lK()
 def VVq44i(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVXthU(bName, bRef)
  else:
   CC0dGf.VVGGiQ(self)
 def VVo7lK(self, VVW8faObj=None, item=None):
  FFhzot(self.SELF, BF(self.VVbfUj), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVbfUj(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VVXthU(bName, "")
   else:
    FFMnBb(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CC0dGf.VVGGiQ(self)
 def VVXthU(self, bName, bRef):
  FFOvQF(self.waitMsgSELF, BF(self.VVQgv5, bName, bRef), title="Adding Services ...")
 def VVQgv5(self, bName, bRef):
  CC0dGf.VVqGMw(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVGGiQ(classObj):
  del classObj
 @staticmethod
 def VVqGMw(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFNkji(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVSwef + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFdzz0(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CC0dGf.VVtAAQ(bRef)
   bPath = VVSwef + bFile
  else:
   fName = CC5Be5.VVGOKA(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVSwef + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVSwef + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CC0dGf.VVChY7(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CC0dGf.VVChY7(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCgJhP.VVkis2()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFBSzC("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CCGnOY.VVW24u(picon))
       break
  FFbWMQ()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFzNhe(SELF, txt, title=title)
 @staticmethod
 def VV1JB7(mode=2, showTitle=True, prefix=""):
  VVWp2B = []
  if mode in (0, 2): VVWp2B.extend(CC0dGf.VV18a5(0, showTitle, prefix))
  if mode in (1, 2): VVWp2B.extend(CC0dGf.VV18a5(1, showTitle, prefix))
  return VVWp2B
 @staticmethod
 def VV18a5(mode, showTitle, prefix):
  VVWp2B = []
  lst = CC0dGf.VVLUqn(mode)
  if lst:
   if showTitle:
    VVWp2B.append(FFhiR0("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVWp2B.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVWp2B.append((item[0], item[1].toString()))
  return VVWp2B
 @staticmethod
 def VVmtoG():
  bLise = CC0dGf.VVLUqn(0)
  bLise.extend(CC0dGf.VVLUqn(1))
  return bLise
 @staticmethod
 def VVLUqn(mode=0):
  bList = []
  VVe94g = InfoBar.instance
  VVNETX = VVe94g and VVe94g.servicelist
  if VVNETX:
   curMode = VVNETX.mode
   CC0dGf.VVj5KQ(VVNETX, mode)
   bList.extend(VVNETX.getBouquetList() or [])
   CC0dGf.VVj5KQ(VVNETX, curMode)
  return bList
 @staticmethod
 def VVj5KQ(VVNETX, mode):
  if not mode == VVNETX.mode:
   if   mode == 0: VVNETX.setModeTv()
   elif mode == 1: VVNETX.setModeRadio()
 @staticmethod
 def VVChY7(fPath):
  addCr = False
  with open(fPath, "r") as file:
   for line in file:
    pass
   addCr = not line.endswith("\n")
  if addCr:
   with open(fPath, "a") as f:
    f.write("\n")
  return addCr
 @staticmethod
 def VVtAAQ(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VV5Y0k():
  try:
   fName = CC0dGf.VVtAAQ(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVSwef, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VV4fhK():
  path = CC0dGf.VV5Y0k()
  if path:
   txt = FFS3H9(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVuizt():
  return FF1xYh(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVzs0h(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVFqKp(SID="", stripRType=False):
  if SID : patt = CC0dGf.VVzs0h(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CC0dGf.VVmtoG():
   for service in FF1xYh(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVaamb(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVGf8v(pathLst):
  refLst = CC0dGf.VVFqKp(CC0dGf.VVYFGU, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CC0dGf.VVaamb(rType, CC0dGf.VVYFGU, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CC0Jp1(Screen):
 VVSzQz   = 0
 VVpslM  = 1
 VVahR0  = 2
 VVsll1  = 3
 VV99TA    = 20
 VVi5w5  = None
 def __init__(self, session, VV4wg8="/", mode=VVSzQz, VVfpab="Select", height=920, VVlOla=30, gotoMovie=False):
  self.skin, self.skinParam = FFbZTb(VVHFCN, 1400, height, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF2wUT(self)
  FF4HaE(self["keyRed"] , "Exit" if mode == self.VVSzQz else "Cancel")
  FF4HaE(self["keyYellow"], "More Options")
  FF4HaE(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVfpab = VVfpab
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CC0Jp1.VVi5w5 = self
  if   self.gotoMovie        : VVlPXC, self.VV4wg8 = True , CC0Jp1.VVtTvV(self)[1] or "/"
  elif self.mode == self.VVSzQz  : VVlPXC, self.VV4wg8 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVahR0 : VVlPXC, self.VV4wg8 = False, VV4wg8
  elif self.mode == self.VVsll1 : VVlPXC, self.VV4wg8 = True , VV4wg8
  else           : VVlPXC, self.VV4wg8 = True , VV4wg8
  self.VV4wg8 = FFjGgP(self.VV4wg8)
  VVK3eF = None
  if self.mode == self.VVsll1:
   VVK3eF = "^.*\.srt"
  self["myMenu"] = CCBLUS(  directory   = None
         , VVK3eF = VVK3eF
         , VVlPXC   = VVlPXC
         , VVpcbH = True
         , VVyD2v   = self.skinParam["width"]
         , VVlOla   = self.skinParam["bodyFontSize"]
         , VVu02V  = self.skinParam["bodyLineH"]
         , VVp96O  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVxkj1      ,
   "red"    : self.VVsrDu     ,
   "green"    : self.VVVzKA    ,
   "yellow"   : self.VVaOqR    ,
   "blue"    : self.VVFBei   ,
   "menu"    : self.VVnmN0    ,
   "info"    : self.VVEIFh    ,
   "cancel"   : self.VV3wlY      ,
   "pageUp"   : self.VVFgX7     ,
   "chanUp"   : self.VVFgX7
  }, -1)
  FFsG3C(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVZEp4)
 def onExit(self):
  CC0Jp1.VVi5w5 = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVZEp4)
  FFGCUP(self)
  FFysS0(self["myMenu"], bg="#06003333")
  FFLvNc(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVahR0, self.VVsll1):
   FF4HaE(self["keyGreen"], self.VVfpab)
   color = "#22000022"
   FFQZ4f(self["myBody"], color)
   FFQZ4f(self["myMenu"], color)
   color = "#22220000"
   FFQZ4f(self["myTitle"], color)
   FFQZ4f(self["myBar"], color)
  self.VVZEp4()
  if self.VVZURw(self.VV4wg8) > self.bigDirSize:
   FFMnBb(self, "Changing directory...")
   FFrvtJ(self.VVOU6c)
  else:
   self.VVOU6c()
 def VVOU6c(self):
  if self.gotoMovie : self.VVahMw(chDir=False)
  else    : self["myMenu"].VV8RQj(self.VV4wg8)
 def VVtsKn(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV4h0p(self):
  self["myMenu"].refresh()
  FFbhWc()
 def VVZURw(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVxkj1(self):
  if self["myMenu"].VVkRSV():
   path = self.VV6wsu(self.VVW8fa())
   if self.VVZURw(path) > self.bigDirSize:
    FFMnBb(self, "Changing directory...")
    FFrvtJ(self.VVfs4X)
   else:
    self.VVfs4X()
  else:
   self.VVzJdU()
 def VVfs4X(self):
  self["myMenu"].descent()
  self.VVZEp4()
 def VVFgX7(self):
  if self["myMenu"].VVoXkx():
   self["myMenu"].moveToIndex(0)
   self.VVfs4X()
 def VV3wlY(self):
  if CFG.FileManagerExit.getValue() == "e": self.VVsrDu()
  else         : self.VVFgX7()
 def VVsrDu(self):
  if not FFPtMH(self):
   self.close("")
 def VVVzKA(self):
  path = self.VV6wsu(self.VVW8fa())
  if self.mode == self.VVahR0:
   self.close(path)
  elif self.mode == self.VVsll1:
   if os.path.isfile(path) : self.close(path)
   else     : FFMnBb(self, "Only .srt files", 1000)
 def VVEIFh(self):
  if not self.mode == self.VVsll1:
   FFOvQF(self, self.VVcfVs, title="Calculating size ...")
 def VVcfVs(self):
  path = self.VV6wsu(self.VVW8fa())
  param = self.VVecA5(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFrbAO("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC0Jp1.VV9013(path)
     freeSize = CC0Jp1.VVtIN5(path)
     size = totSize - freeSize
     totSize  = CC0Jp1.VVCLeS(totSize)
     freeSize = CC0Jp1.VVCLeS(freeSize)
    else:
     size = FFrbAO("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CC0Jp1.VVCLeS(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFtSnl(pathTxt, VVpqRv) + "\n"
   if slBroken : fileTime = self.VVSscb(path)
   else  : fileTime = self.VV5VPH(path)
   def VVQ9OX(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVQ9OX("Path"    , pathTxt)
   txt += VVQ9OX("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVQ9OX("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVQ9OX("Total Size"   , "%s" % totSize)
    txt += VVQ9OX("Used Size"   , "%s" % usedSize)
    txt += VVQ9OX("Free Size"   , "%s" % freeSize)
   else:
    txt += VVQ9OX("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVQ9OX("Owner"    , owner)
   txt += VVQ9OX("Group"    , group)
   txt += VVQ9OX("Perm. (User)"  , permUser)
   txt += VVQ9OX("Perm. (Group)"  , permGroup)
   txt += VVQ9OX("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVQ9OX("Perm. (Ext.)" , permExtra)
   txt += VVQ9OX("iNode"    , iNode)
   txt += VVQ9OX("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVJ1qT, VVJ1qT)
    txt += hLinkedFiles
   txt += self.VVWMID(path)
  else:
   FFNkji(self, "Cannot access information !")
  if len(txt) > 0:
   FFzNhe(self, txt)
 def VVecA5(self, path):
  path = path.strip()
  path = FFRs7V(path)
  result = FFrbAO("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVZuVI(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVZuVI(perm, 1, 4)
   permGroup = VVZuVI(perm, 4, 7)
   permOther = VVZuVI(perm, 7, 10)
   permExtra = VVZuVI(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFWdfY("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVWMID(self, path):
  txt  = ""
  res  = FFrbAO("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFtSnl("File Attributes:", VV31Rm), txt)
  return txt
 def VV5VPH(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFP6g0(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFP6g0(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFP6g0(os.path.getctime(path))
  return txt
 def VVSscb(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFrbAO("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFrbAO("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFrbAO("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV6wsu(self, currentSel):
  currentDir  = self["myMenu"].VVoXkx()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVkRSV():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVW8fa(self):
  return self["myMenu"].getSelection()[0]
 def VVZEp4(self):
  FFMnBb(self)
  path = self.VV6wsu(self.VVW8fa())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVW02n()
  if self.mode == self.VVSzQz and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
  if self.mode == self.VVsll1 and len(path) > 0 : self["keyInfo"].hide()
  else               : self["keyInfo"].show()
  if self.mode == self.VVsll1:
   path = self.VV6wsu(self.VVW8fa())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVW02n(self):
  if self.VVfeh5() : self["keyBlue"].show()
  else      : self["keyBlue"].hide()
 def VVnmN0(self):
  if self.mode == self.VVSzQz:
   color   = VVFkfi
   path  = self.VV6wsu(self.VVW8fa())
   isDir  = os.path.isdir(path)
   VVWp2B = []
   VVWp2B.append(   ("Properties"         , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVUAbS(path):
     sepShown = True
     VVWp2B.append(VVEgY4)
     VVWp2B.append( (color + "Archiving / Packaging"     , "VVCVlo"  ))
    if self.VVwqMm(path):
     if not sepShown:
      VVWp2B.append(VVEgY4)
     VVWp2B.append( (color + "Read Backup information"     , "VVmoBy"  ))
     VVWp2B.append( (color + "Compress Octagon Image (to zip)"   , "VVraRF" ))
   elif os.path.isfile(path):
    selFile = self.VVW8fa()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVWp2B.extend(self.VVitpo(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVWp2B.extend(self.VVcNBz(True))
    elif selFile.endswith(".m3u")              : VVWp2B.extend(self.VVfcr2(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CC0Jp1.VV4scp(path):
     VVWp2B.append(VVEgY4)
     VVWp2B.append( (color + "View"          , "textView_def"   ))
     VVWp2B.append( (color + "View (Select Encoder)"     , "textView_enc"   ))
     VVWp2B.append( (color + "Edit"          , "text_Edit"    ))
     VVWp2B.append( (color + "Save as UTF-8 ..."      , "textSave_encUtf8"  ))
     VVWp2B.append( (color + "Save as other Encoding ..."    , "textSave_encOthr"  ))
    elif selFile.endswith(CC0Jp1.VVoCGs()):
     VVWp2B.append(VVEgY4)
     VVWp2B.append( (color + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
     VVWp2B.append( (color + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
    if len(txt) > 0:
     VVWp2B.append(VVEgY4)
     VVWp2B.append( (color + txt          , "VVzJdU"    ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(     ("Create SymLink"       , "VV5cVB"   ))
   if not self.VVUAbS(path):
    VVWp2B.append(  ("Rename"           , "VVb52n"   ))
    VVWp2B.append(  ("Copy"            , "copyFileOrDir"   ))
    VVWp2B.append(  ("Move"            , "moveFileOrDir"   ))
    VVWp2B.append(  ("DELETE"           , "VVnGSZ"   ))
    if fileExists(path):
     VVWp2B.append(VVEgY4)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVWp2B.append( (chmodTxt + "644)"       , "chmod644"    ))
     if show755 : VVWp2B.append( (chmodTxt + "755)"       , "chmod755"    ))
     if show777 : VVWp2B.append( (chmodTxt + "777)"       , "chmod777"    ))
   VVWp2B.append(VVEgY4)
   VVWp2B.append(    ("Create New File (in current directory)"  , "createNewFile"   ))
   VVWp2B.append(    ("Create New Directory (in current directory)" , "createNewDir"   ))
   fPath, fDir, fName = CC0Jp1.VVtTvV(self)
   if fPath:
    VVWp2B.append(VVEgY4)
    VVWp2B.append(   (color + "Go to Current Movie Dir"    , "VVahMw"  ))
   FFkkcl(self, self.VVlQ3E, height=1050, title="Options", VVWp2B=VVWp2B, VVcV6s="#00101020", VV89EB="#00101A2A")
 def VVlQ3E(self, item=None):
  if self.mode == self.VVSzQz:
   if item is not None:
    path = self.VV6wsu(self.VVW8fa())
    selFile = self.VVW8fa()
    if   item == "properties"    : self.VVEIFh()
    elif item == "VVCVlo"  : self.VVCVlo(path)
    elif item == "VVmoBy"  : self.VVmoBy(path)
    elif item == "VVraRF" : self.VVraRF(path)
    elif item.startswith("extract_")  : self.VVCSFf(path, selFile, item)
    elif item.startswith("script_")   : self.VVOpmF(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVAj4N(path, selFile, item)
    elif item.startswith("textView_def") : FFjMtD(self, path)
    elif item.startswith("textView_enc") : self.VVLmlE(path)
    elif item.startswith("text_Edit")  : FFOvQF(self, BF(CC6mSu, self, path), title="Opening File ...")
    elif item.startswith("textSave_encUtf8"): self.VVEE7Z(path, "Save as UTF-8"   , True)
    elif item.startswith("textSave_encOthr"): self.VVEE7Z(path, "Save as Other Encoding", False)
    elif item == "addMovieToBouquet"  : self.VVggxQ(path, False)
    elif item == "addAllMoviesToBouquet" : self.VVggxQ(path, True)
    elif item == "VV5cVB"   : self.VV5cVB(path, selFile)
    elif item == "VVb52n"   : self.VVb52n(path, selFile)
    elif item == "copyFileOrDir"   : self.VV2Et4(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VV2Et4(path, selFile, True)
    elif item == "VVnGSZ"   : self.VVnGSZ(path, selFile)
    elif item == "chmod644"     : self.VVqeQ4(path, selFile, "644")
    elif item == "chmod755"     : self.VVqeQ4(path, selFile, "755")
    elif item == "chmod777"     : self.VVqeQ4(path, selFile, "777")
    elif item == "createNewFile"   : self.VVbEtT(path, True)
    elif item == "createNewDir"    : self.VVbEtT(path, False)
    elif item == "VVahMw"   : self.VVahMw()
    elif item == "VVzJdU"    : self.VVzJdU()
    else         : self.close()
 def VVzJdU(self):
  if self.mode == self.VVsll1:
   return
  selFile = self.VVW8fa()
  path  = self.VV6wsu(selFile)
  if os.path.isfile(path):
   VVmobY = []
   category = self["myMenu"].VVBKJj(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVRjN1(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CCTnxh.VVJldG(self, path)
   elif category == "txt"         : FFjMtD(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVurH3(path, selFile)
   elif category == "scr"         : self.VVO5Ie(path, selFile)
   elif category == "m3u"         : self.VVb2oq(path, selFile)
   elif category in ("ipk", "deb")       : self.VVRAmw(path, selFile)
   elif category == "mus"         : self.VV6UHs(self, path)
   elif category == "mov"         : self.VV6UHs(self, path)
   elif not CC0Jp1.VV4scp(path)    : FFjMtD(self, path)
 def VVFBei(self):
  if self["keyBlue"].getVisible():
   VVJXpL = self.VVfeh5()
   if VVJXpL:
    path = self.VV6wsu(self.VVW8fa())
    enableGreenBtn = False if path in self.VVfeh5() else True
    newList = []
    for line in VVJXpL:
     newList.append((line, line))
    VVaTfU  = ("Delete"    , self.VVe8zf    )
    VVKBZE  = ("Add Current Dir"   , BF(self.VVh3yp, path) ) if enableGreenBtn else None
    VVBc7a = ("Move Up"     , self.VV8CnN    )
    VVK0co  = ("Move Down"   , self.VVE6P5    )
    self.bookmarkMenu = FFkkcl(self, self.VVeyBa, width=1200, title="Bookmarks", VVWp2B=newList, minRows=10 ,VVaTfU=VVaTfU, VVKBZE=VVKBZE, VVBc7a=VVBc7a, VVK0co=VVK0co, VVcV6s="#00000022", VV89EB="#00000022")
 def VVe8zf(self, menuInstance=None, path=None):
  VVJXpL = self.VVfeh5()
  if VVJXpL:
   while path in VVJXpL:
    VVJXpL.remove(path)
   self.VVnzrB(VVJXpL)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVE8XZ(VVJXpL)
   self.bookmarkMenu.VV6CcV(("Add Current Dir", BF(self.VVh3yp, path)))
  else:
   FFMnBb(self, "Removed", 800)
  self.VVW02n()
 def VVh3yp(self, path, menuInstance=None, item=None):
  VVJXpL = self.VVfeh5()
  if len(VVJXpL) >= self.VV99TA:
   FFNkji(SELF, "Max bookmarks reached (max=%d)." % self.VV99TA)
  elif not path in VVJXpL:
   newList = [path] + VVJXpL
   self.VVnzrB(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVE8XZ(newList)
    self.bookmarkMenu.VV6CcV()
   else:
    FFMnBb(self, "Added", 800)
  self.VVW02n()
 def VV8CnN(self, VVW8faObj, path):
  if self.bookmarkMenu:
   VVJXpL = self.bookmarkMenu.VVrGMr(True)
   if VVJXpL:
    self.VVnzrB(VVJXpL)
 def VVE6P5(self, VVW8faObj, path):
  if self.bookmarkMenu:
   VVJXpL = self.bookmarkMenu.VVrGMr(False)
   if VVJXpL:
    self.VVnzrB(VVJXpL)
 def VVeyBa(self, folder=None):
  if folder:
   folder = FFjGgP(folder)
   self["myMenu"].VV8RQj(folder)
   self["myMenu"].moveToIndex(0)
  self.VVZEp4()
 def VVfeh5(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVEaNt(self):
  return True if VVfeh5() else False
 def VVnzrB(self, VVJXpL):
  line = ",".join(VVJXpL)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VV4HSY(self, path):
  if fileExists(path):
   fDir  = FFjGgP(os.path.dirname(path))
   if fDir:
    self["myMenu"].VV8RQj(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFMnBb(self, "Not found", 1000)
 def VVahMw(self, chDir=True):
  fPath, fDir, fName = CC0Jp1.VVtTvV(self)
  self.VV4HSY(fPath)
 def VVaOqR(self):
  path = self.VV6wsu(self.VVW8fa())
  isAdd = False if path in self.VVfeh5() else True
  VVWp2B = []
  VVWp2B.append(   ("Find Files ..."      , "find" ))
  VVWp2B.append(   ("Sort ..."        , "sort" ))
  VVWp2B.append(VVEgY4)
  if isAdd: VVWp2B.append( ("Add Current Dir to Bookmarks"   , "addBM" ))
  else : VVWp2B.append( ("Remove Current Dir from Bookmarks" , "remBM" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(   ('Set Current Dir as "Startup Dir"'  , "start" ))
  FFkkcl(self, BF(self.VVKRXd, path), width=750, title="More Options", VVWp2B=VVWp2B, VVcV6s="#00221111", VV89EB="#00221111")
 def VVKRXd(self, path, item):
  if item:
   if   item == "find" : self.VV69Lr(path)
   elif item == "sort" : self.VVxDjJ()
   elif item == "addBM": self.VVh3yp(path)
   elif item == "remBM": self.VVe8zf(None, path)
   elif item == "start": self.VV0u1q(path)
 def VV69Lr(self, path):
  VVWp2B = []
  VVWp2B.append(("Find in Current Directory"    , "findCur"  ))
  VVWp2B.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVWp2B.append(("Find in all Storage Systems"    , "findAll"  ))
  FFkkcl(self, BF(self.VVe5Pn, path), width=700, title="Find File/Pattern", VVWp2B=VVWp2B, VV83XM=True, VV7G8l=True, VVcV6s="#00221111", VV89EB="#00221111")
 def VVe5Pn(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVmrZS(0, path, title)
   elif item == "findCurR" : self.VVmrZS(1, path, title)
   elif item == "findAll" : self.VVmrZS(2, path, title)
 def VVmrZS(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFhzot(self, BF(self.VV54GA, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VV54GA(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   CFG.lastFileManFindPatt.setValue(filePatt)
   CFG.lastFileManFindPatt.save()
   configfile.save()
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFMnBb(self, "No entery", 1500)
   elif badLst  : FFMnBb(self, "Too many file !", 1500)
   else   : FFOvQF(self, BF(self.VVsUV8, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVsUV8(self, mode, path, title, filePatt):
  FFMnBb(self)
  lst = FF42E1(FFCsCC("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   if len(lst) == 1 and lst[0] == VVq1UG:
    FFNkji(self, VVq1UG)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VV9ZE5 = (""     , self.VV66X3 , [])
    VV1NOm = ("Go to File Location", self.VVd5SF  , [])
    FFGcVX(self, None, title="%s : %s" % (title, filePatt), header=header, VVJXpL=lst, VVQGhe=widths, VVlOla=26, VV9ZE5=VV9ZE5, VV1NOm=VV1NOm)
  else:
   FFMnBb(self, "Not found !", 2000)
 def VVd5SF(self, VVMsCC, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVMsCC.cancel()
   self.VV4HSY(path)
  else:
   FFMnBb(VVMsCC, "Path not found !", 1000)
 def VV66X3(self, VVMsCC, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFtSnl("File:"  , VVFeau), colList[0])
  txt += "%s\n%s"  % (FFtSnl("Directory:", VVFeau), FFjGgP(colList[1]))
  FFzNhe(VVMsCC, txt, title=title)
 def VVxDjJ(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVhp4G()
  VVWp2B = []
  VVWp2B.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVWp2B.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVWp2B.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVWp2B.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVK0co = ("Mix", BF(self.VVoOE9, True))
  FFkkcl(self, BF(self.VVcDQF, False), barText=txt, width=650, title="Sort Options", VVWp2B=VVWp2B, VVK0co=VVK0co, VV7G8l=True, VVcV6s="#00221111", VV89EB="#00221111")
 def VVoOE9(self, isMix, menuInstance, item):
  self.VVcDQF(True, item)
 def VVcDQF(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVhp4G()
   title = "Sorting ... "
   if   item == "nameAlp": FFOvQF(self, BF(self["myMenu"].VV66aM, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFOvQF(self, BF(self["myMenu"].VV66aM, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFOvQF(self, BF(self["myMenu"].VV66aM, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFOvQF(self, BF(self["myMenu"].VV66aM, typeMode , isMix, False), title=title)
 def VV0u1q(self, path):
  if not os.path.isdir(path):
   path = FFO4sU(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
  FFMnBb(self, "Done", 500)
 def VVRjN1(self, selFile, VVljeR, command):
  FFm5Au(self, BF(FF355v, self, command, VVyLAy=self.VV4h0p), "%s\n\n%s" % (VVljeR, selFile))
 def VVitpo(self, path, calledFromMenu):
  destPath = self.VViiC0(path)
  lastPart = FFRwag(destPath)
  VVWp2B = []
  if calledFromMenu:
   VVWp2B.append(VVEgY4)
   color = VVpqRv
  else:
   color = ""
  VVWp2B.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVWp2B.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVWp2B.append((color + "Extract Here"            , "extract_here"  ))
  if VVv9Mc and path.endswith(".tar.gz"):
   VVWp2B.append(VVEgY4)
   VVWp2B.append((color + 'Convert to ".ipk" Package' , "VVL65g"  ))
   VVWp2B.append((color + 'Convert to ".deb" Package' , "VV55UV"  ))
  return VVWp2B
 def VVurH3(self, path, selFile):
  FFkkcl(self, BF(self.VVCSFf, path, selFile), title="Compressed File Options", VVWp2B=self.VVitpo(path, False))
 def VVCSFf(self, path, selFile, item=None):
  if item is not None:
   parent  = FFO4sU(path, False)
   destPath = self.VViiC0(path)
   lastPart = FFRwag(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVJ1qT
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFkr8y("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFkr8y("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVJ1qT, VVJ1qT)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFIhbm(self, cmd)
   elif path.endswith(".zip"):
    self.VVqann(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV3Oer(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFBSzC("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVRjN1(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVRjN1(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFO4sU(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVRjN1(selFile, "Extract Here ?"      , cmd)
   elif item == "VVL65g" : self.VVL65g(path)
   elif item == "VV55UV" : self.VV55UV(path)
 def VViiC0(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVqann(self, item, path, parent, destPath, VVljeR):
  FFm5Au(self, BF(self.VVYQcw, item, path, parent, destPath), VVljeR)
 def VVYQcw(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVJ1qT
  cmd  = FFkr8y("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF7gKg(destPath, VV41YE))
  cmd +=   sep
  cmd += "fi;"
  FFEMu6(self, cmd, VVyLAy=self.VV4h0p)
 def VV3Oer(self, item, path, parent, destPath, VVljeR):
  FFm5Au(self, BF(self.VVEOHX, item, path, parent, destPath), VVljeR)
 def VVEOHX(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFjGgP(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVJ1qT
  cmd  = FFkr8y("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF7gKg(destPath, VV41YE))
  cmd +=   sep
  cmd += "fi;"
  FFEMu6(self, cmd, VVyLAy=self.VV4h0p)
 def VVcNBz(self, addSep=False):
  VVWp2B = []
  if addSep:
   VVWp2B.append(VVEgY4)
  VVWp2B.append((VVpqRv + "View Script File"  , "script_View"  ))
  VVWp2B.append((VVpqRv + "Execute Script File" , "script_Execute" ))
  VVWp2B.append((VVpqRv + "Edit"     , "script_Edit" ))
  return VVWp2B
 def VVO5Ie(self, path, selFile):
  FFkkcl(self, BF(self.VVOpmF, path, selFile), title="Script File Options", VVWp2B=self.VVcNBz())
 def VVOpmF(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFjMtD(self, path)
   elif item == "script_Execute" : self.VVRjN1(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC6mSu(self, path)
 def VVfcr2(self, addSep=False):
  VVWp2B = []
  if addSep:
   VVWp2B.append(VVEgY4)
  VVWp2B.append((VVpqRv + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVWp2B.append((VVpqRv + "Edit"      , "m3u_Edit" ))
  VVWp2B.append((VVpqRv + "View"      , "m3u_View" ))
  return VVWp2B
 def VVb2oq(self, path, selFile):
  FFkkcl(self, BF(self.VVAj4N, path, selFile), title="M3U/M3U8 File Options", VVWp2B=self.VVfcr2())
 def VVAj4N(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFOvQF(self, BF(self.session.open, CC5Be5, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CC6mSu(self, path)
   elif item == "m3u_View"  : FFjMtD(self, path)
 def VVLmlE(self, path):
  if fileExists(path) : FFOvQF(self, BF(CCF2zZ.VVSvbv, self, path, BF(self.VVM08b, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFdzz0(self, path)
 def VVM08b(self, path, item=None):
  if item:
   FFjMtD(self, path, encLst=item)
 def VVEE7Z(self, path, title, asUtf8):
  if fileExists(path) : FFOvQF(self, BF(CCF2zZ.VVSvbv, self, path, BF(self.VVVeMW, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFdzz0(self, path)
 def VVVeMW(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVgMRY(path, title, fromEnc, "UTF-8")
   else  : CCF2zZ.VVSvbv(self, path,  BF(self.VVgMRY, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVgMRY(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFtSnl("Successful\n\n", VV41YE)
      txt += FFtSnl("From Encoding (%s):\n" % fromEnc, VVxbdF)
      txt += "%s\n\n" % path
      txt += FFtSnl("To Encoding (%s):\n" % toEnc, VVxbdF)
      txt += "%s\n\n" % outFile
      FFzNhe(self, txt, title=title)
    except:
     FFNkji(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFMnBb(self, "Cannot open file", 2000)
  self.VV4h0p()
 def VVqeQ4(self, path, selFile, newChmod):
  FFm5Au(self, BF(self.VVUXR9, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVUXR9(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV4Q9M)
  result = FFrbAO(cmd)
  if result == "Successful" : FFO5iz(self, result)
  else      : FFNkji(self, result)
 def VV5cVB(self, path, selFile):
  parent = FFO4sU(path, False)
  self.session.openWithCallback(self.VVDfUj, BF(CC0Jp1, mode=CC0Jp1.VVahR0, VV4wg8=parent, VVfpab="Create Symlink here"))
 def VVDfUj(self, newPath):
  if len(newPath) > 0:
   target = self.VV6wsu(self.VVW8fa())
   target = FFRs7V(target)
   linkName = FFRwag(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFjGgP(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFNkji(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFm5Au(self, BF(self.VVB7m1, target, link), "Create Soft Link ?\n\n%s" % txt, VVYN57=True)
 def VVB7m1(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV4Q9M)
  result = FFrbAO(cmd)
  if result == "Successful" : FFO5iz(self, result)
  else      : FFNkji(self, result)
 def VVb52n(self, path, selFile):
  lastPart = FFRwag(path)
  FFhzot(self, BF(self.VV0r3e, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV0r3e(self, path, selFile, VVk7Wd):
  if VVk7Wd:
   parent = FFO4sU(path, True)
   if os.path.isdir(path):
    path = FFRs7V(path)
   newName = parent + VVk7Wd
   cmd = "mv '%s' '%s' %s" % (path, newName, VV4Q9M)
   if VVk7Wd:
    if selFile != VVk7Wd:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFm5Au(self, BF(self.VVPeqC, cmd), message, title="Rename file?")
    else:
     FFNkji(self, "Cannot use same name!", title="Rename")
 def VVPeqC(self, cmd):
  result = FFrbAO(cmd)
  if "Fail" in result:
   FFNkji(self, result)
  self.VV4h0p()
 def VV2Et4(self, path, selFile, isMove):
  if isMove : VVfpab = "Move to here"
  else  : VVfpab = "Paste here"
  parent = FFO4sU(path, False)
  self.session.openWithCallback(BF(self.VViVQ8, isMove, path, selFile)
         , BF(CC0Jp1, mode=CC0Jp1.VVahR0, VV4wg8=parent, VVfpab=VVfpab))
 def VViVQ8(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = FFRwag(path)
   if os.path.isdir(path):
    path = FFRs7V(path)
   newPath = FFjGgP(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFNkji(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFm5Au(self, BF(FFxeLA, self, cmd, VVyLAy=self.VV4h0p), txt, VVYN57=True)
   else:
    FFNkji(self, "Cannot %s to same directory !" % action.lower())
 def VVnGSZ(self, path, fileName):
  path = FFRs7V(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFm5Au(self, BF(self.VVeZow, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVeZow(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VV4h0p()
 def VVUAbS(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVYACA and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVbEtT(self, path, isFile):
  dirName = FFjGgP(os.path.dirname(path))
  if isFile : objName, VVk7Wd = "File"  , self.edited_newFile
  else  : objName, VVk7Wd = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFhzot(self, BF(self.VVQnqG, dirName, isFile, title), title=title, defaultText=VVk7Wd, message="Enter %s Name:" % objName)
 def VVQnqG(self, dirName, isFile, title, VVk7Wd):
  if VVk7Wd:
   if isFile : self.edited_newFile = VVk7Wd
   else  : self.edited_newDir  = VVk7Wd
   path = dirName + VVk7Wd
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV4Q9M)
    else  : cmd = "mkdir '%s' %s" % (path, VV4Q9M)
    result = FFrbAO(cmd)
    if "Fail" in result:
     FFNkji(self, result)
    self.VV4h0p()
   else:
    FFNkji(self, "Name already exists !\n\n%s" % path, title)
 def VVRAmw(self, path, selFile):
  VVWp2B = []
  VVWp2B.append(("List Package Files"          , "VVi1bL"     ))
  VVWp2B.append(("Package Information"          , "VVtvYS"     ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Install Package"           , "VVllaI_CheckVersion" ))
  VVWp2B.append(("Install Package (force reinstall)"      , "VVllaI_ForceReinstall" ))
  VVWp2B.append(("Install Package (force overwrite)"      , "VVllaI_ForceOverwrite" ))
  VVWp2B.append(("Install Package (force downgrade)"      , "VVllaI_ForceDowngrade" ))
  VVWp2B.append(("Install Package (ignore failed dependencies)"    , "VVllaI_IgnoreDepends" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Remove Related Package"         , "VVGMCD_ExistingPackage" ))
  VVWp2B.append(("Remove Related Package (force remove)"     , "VVGMCD_ForceRemove"  ))
  VVWp2B.append(("Remove Related Package (ignore failed dependencies)"  , "VVGMCD_IgnoreDepends" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Extract Files"           , "VVQxZg"     ))
  VVWp2B.append(("Unbuild Package"           , "VVkH2a"     ))
  FFkkcl(self, BF(self.VVvAm6, path, selFile), VVWp2B=VVWp2B)
 def VVvAm6(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVi1bL"      : self.VVi1bL(path, selFile)
   elif item == "VVtvYS"      : self.VVtvYS(path)
   elif item == "VVllaI_CheckVersion"  : self.VVllaI(path, selFile, VVRzYh     )
   elif item == "VVllaI_ForceReinstall" : self.VVllaI(path, selFile, VVXPbD )
   elif item == "VVllaI_ForceOverwrite" : self.VVllaI(path, selFile, VV6une )
   elif item == "VVllaI_ForceDowngrade" : self.VVllaI(path, selFile, VVoxQ2 )
   elif item == "VVllaI_IgnoreDepends" : self.VVllaI(path, selFile, VVJxK8 )
   elif item == "VVGMCD_ExistingPackage" : self.VVGMCD(path, selFile, VVThwT     )
   elif item == "VVGMCD_ForceRemove"  : self.VVGMCD(path, selFile, VV7m8G  )
   elif item == "VVGMCD_IgnoreDepends"  : self.VVGMCD(path, selFile, VVfrPk )
   elif item == "VVQxZg"     : self.VVQxZg(path, selFile)
   elif item == "VVkH2a"     : self.VVkH2a(path, selFile)
   else           : self.close()
 def VVi1bL(self, path, selFile):
  if FFCi72("ar") : cmd = "allOK='1';"
  else    : cmd  = FFrwtR()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVJ1qT, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVJ1qT, VVJ1qT)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FF4Tqj(self, cmd, VVyLAy=self.VV4h0p)
 def VVQxZg(self, path, selFile):
  lastPart = FFRwag(path)
  dest  = FFO4sU(path, True) + selFile[:-4]
  cmd  =  FFrwtR()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFBSzC("mkdir '%s'" % dest) + ";"
  cmd +=    FFBSzC("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF7gKg(dest, VV41YE))
  cmd += "fi;"
  FF355v(self, cmd, VVyLAy=self.VV4h0p)
 def VVkH2a(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVUQnF = os.path.splitext(path)[0]
  else        : VVUQnF = path + "_"
  if path.endswith(".deb")   : VVIVyT = "DEBIAN"
  else        : VVIVyT = "CONTROL"
  cmd  = FFrwtR()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVUQnF, FFZ6H5())
  cmd += "  mkdir '%s';"    % VVUQnF
  cmd += "  CONTPATH='%s/%s';"  % (VVUQnF, VVIVyT)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVUQnF
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVUQnF, VVUQnF)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVUQnF
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVUQnF, VVUQnF)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVUQnF
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVUQnF
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVUQnF, FF7gKg(VVUQnF, VV41YE))
  cmd += "fi;"
  FF355v(self, cmd, VVyLAy=self.VV4h0p)
 def VVtvYS(self, path):
  listCmd  = FFU3rV(VVX80U, "")
  infoCmd  = FFWksx(VVIObq , "")
  filesCmd = FFWksx(VV9BI1, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFygy9(VVxbdF)
   notInst = "Package not installed."
   cmd  = FFy2ZV("File Info", VVxbdF)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFy2ZV("System Info", VVxbdF)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF7gKg(notInst, VVpqRv))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFy2ZV("Related Files", VVxbdF)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFIhbm(self, cmd)
  else:
   FFdMgN(self)
 def VVllaI(self, path, selFile, cmdOpt):
  cmd = FFWksx(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFm5Au(self, BF(FF355v, self, cmd, VVyLAy=FFbhWc), "Install Package ?\n\n%s" % selFile)
  else:
   FFdMgN(self)
 def VVGMCD(self, path, selFile, cmdOpt):
  listCmd  = FFU3rV(VVX80U, "")
  infoCmd  = FFWksx(VVIObq, "")
  instRemCmd = FFWksx(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF7gKg(errTxt, VVpqRv))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF7gKg(cannotTxt, VVpqRv))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF7gKg(tryTxt, VVpqRv))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFm5Au(self, BF(FF355v, self, cmd, VVyLAy=FFbhWc), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFdMgN(self)
 def VVmYY7(self, path):
  hostName = FFrbAO("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVwqMm(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVmYY7(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVCVlo(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVWp2B = []
  VVWp2B.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVWp2B.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVWp2B.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVWp2B.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVWp2B.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVWp2B.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVWp2B.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVWp2B.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVWp2B.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVWp2B.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFkkcl(self, BF(self.VVplah, path), VVWp2B=VVWp2B)
 def VVplah(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVt0cC(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVt0cC(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVt0cC(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVt0cC(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVt0cC(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVt0cC(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVt0cC(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVt0cC(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVt0cC(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVt0cC(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVASKf(path, False)
   elif item == "convertDirToDeb"   : self.VVASKf(path, True)
   else         : self.close()
 def VVASKf(self, path, VVeUfE):
  self.session.openWithCallback(self.VV4h0p, BF(CCwDfU, path=path, VVeUfE=VVeUfE))
 def VVt0cC(self, path, fileExt, preserveDirStruct):
  parent  = FFO4sU(path, True)
  lastPart = FFRwag(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFkr8y("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFkr8y("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFkr8y("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVJ1qT
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFBSzC("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF7gKg(resultFile, VV41YE))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF7gKg(failed, VVG74s))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FF4Tqj(self, cmd, VVyLAy=self.VV4h0p)
 def VVggxQ(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CC0Jp1.VVkfSS(FFO4sU(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CC0dGf(self, self, title, BF(self.VVql33, pathLst))
 def VVql33(self, pathLst):
  return CC0dGf.VVGf8v(pathLst)
 def VVmoBy(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFjMtD(self, versionFile)
 def VVraRF(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVmYY7(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFNkji(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFsCGi(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFO4sU(path, False)
  VVUQnF = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF7gKg(errCmd, VVG74s))
  installCmd = FFWksx(VVRzYh , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVUQnF, VVUQnF)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVUQnF
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVUQnF
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVUQnF, VVUQnF)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FF355v(self, cmd, VVyLAy=self.VV4h0p)
 def VVL65g(self, path):
  FFNkji(self, "Under Construction.")
 def VV55UV(self, path):
  FFNkji(self, "Under Construction.")
 @staticmethod
 def VV6UHs(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCZilb, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVtTvV(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFjGgP(fDir), fName
  return "", "", ""
 @staticmethod
 def VV9013(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVtIN5(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVCLeS(size, mode=0):
  txt = CC0Jp1.VVsswo(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVsswo(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VV4scp(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVoodk(SELF, path, fName, VVkNHV=True):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if VVkNHV:
    FFNkji(SELF, '"%s" file is not a standard UTF-8 file !' % fName)
   return False
 @staticmethod
 def VVoCGs():
  tDict = CCBLUS.VVG0g6()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVkfSS(path):
  lst = []
  for ext in CC0Jp1.VVoCGs():
   lst.extend(iGlob("%s/*.%s" % (path, ext)))
  return lst
class CCBLUS(MenuList):
 VVyLja  = 0
 VV7bUG  = 1
 VVBQ4y  = 2
 VVTLZ5  = 3
 VVqZUB  = 4
 VVtc4P  = 5
 VVtLzk  = 6
 VVypGQ  = 7
 def __init__(self, VVpcbH=False, directory="/", VVVySn=True, VVlPXC=True, VVso0u=True, VVK3eF=None, VVwWN3=False, VVu3uW=False, VVmbVv=False, isTop=False, VVKIm4=None, VVyD2v=1000, VVlOla=30, VVu02V=30, VVp96O="#00000000"):
  MenuList.__init__(self, list, VVpcbH, eListboxPythonMultiContent)
  self.VVVySn  = VVVySn
  self.VVlPXC    = VVlPXC
  self.VVso0u  = VVso0u
  self.VVK3eF  = VVK3eF
  self.VVwWN3   = VVwWN3
  self.VVu3uW   = VVu3uW or []
  self.VVmbVv   = VVmbVv or []
  self.isTop     = isTop
  self.additional_extensions = VVKIm4
  self.VVyD2v    = VVyD2v
  self.VVlOla    = VVlOla
  self.VVu02V    = VVu02V
  self.pngBGColor    = FFcFXO(VVp96O)
  self.EXTENSIONS    = CCBLUS.VVG0g6()
  self.VVCR76   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.l.setFont(0, gFont(VV8NsC, self.VVlOla))
  self.l.setItemHeight(self.VVu02V)
  self.png_mem   = self.VVvxfb("mem")
  self.png_usb   = self.VVvxfb("usb")
  self.png_fil   = self.VVvxfb("fil")
  self.png_dir   = self.VVvxfb("dir")
  self.png_dirup   = self.VVvxfb("dirup")
  self.png_srv   = self.VVvxfb("srv")
  self.png_slwfil   = self.VVvxfb("slwfil")
  self.png_slbfil   = self.VVvxfb("slbfil")
  self.png_slwdir   = self.VVvxfb("slwdir")
  self.VVe73d()
  self.VV8RQj(directory)
 def VVvxfb(self, category):
  return LoadPixmap("%s%s.png" % (VVE4he, category), getDesktop(0))
 @staticmethod
 def VVG0g6():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","mvi","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","ogm","ogv","pva","rm","rmvb","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVeMrf(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFRs7V(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFtSnl(" -> " , VVxbdF) + FFtSnl(os.readlink(path), VV41YE)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVu02V + 10, 0, self.VVyD2v, self.VVu02V, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV2US3: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVu02V-4, self.VVu02V-4, png, self.pngBGColor, self.pngBGColor, VV2US3))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVu02V-4, self.VVu02V-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVBKJj(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVe73d(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVkmcf(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV3IG9(self, file):
  if os.path.realpath(file) == file:
   return self.VVkmcf(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVkmcf(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVkmcf(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVllXL(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVCR76.info(l[0][0]).getEvent(l[0][0])
 def VV6KT5(self):
  return self.list
 def VVPMFB(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV8RQj(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVso0u:
    self.current_mountpoint = self.VV3IG9(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVso0u:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVmbVv and not self.VVPMFB(path, self.VVu3uW):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVeMrf(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVwWN3:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVCR76 = eServiceCenter.getInstance()
   list = VVCR76.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVVySn and not self.isTop:
   if directory == self.current_mountpoint and self.VVso0u:
    self.list.append(self.VVeMrf(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVmbVv and self.VVkmcf(directory) in self.VVmbVv):
    self.list.append(self.VVeMrf(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVVySn:
   for x in directories:
    if not (self.VVmbVv and self.VVkmcf(x) in self.VVmbVv) and not self.VVPMFB(x, self.VVu3uW):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVeMrf(name = name, absolute = x, isDir = True, png = png))
  if self.VVlPXC:
   for x in files:
    if self.VVwWN3:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFtSnl(" -> " , VVxbdF) + FFtSnl(target, VV41YE)
       else:
        png = self.png_slbfil
        name += FFtSnl(" -> " , VVxbdF) + FFtSnl(target, VVG74s)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVBKJj(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVE4he, category))
    if (self.VVK3eF is None) or iCompile(self.VVK3eF).search(path):
     self.list.append(self.VVeMrf(name = name, absolute = x , isDir = False, png = png))
  if self.VVso0u and len(self.list) == 0:
   self.list.append(self.VVeMrf(name = FFtSnl("No USB connected", VVpi4Z), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  self.VV66aM()
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVoXkx(self):
  return self.current_directory
 def VVkRSV(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV8RQj(self.getSelection()[0], select = self.current_directory)
 def VVukDw(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVzwJt(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVGMoh)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVGMoh)
 def refresh(self):
  self.VV8RQj(self.current_directory, self.VVukDw())
 def VVGMoh(self, action, device):
  self.VVe73d()
  if self.current_directory is None:
   self.refresh()
 def VVhp4G(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVyLja : nameAlpMode, nameAlpTxt = self.VV7bUG, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVyLja, sAZ
  if mode == self.VVBQ4y : nameNumMode, nameNumTxt = self.VVTLZ5, s90
  else       : nameNumMode, nameNumTxt = self.VVBQ4y, s09
  if mode == self.VVqZUB : dateMode, dateTxt = self.VVtc4P, sON
  else       : dateMode, dateTxt = self.VVqZUB, sNO
  if mode == self.VVtLzk : typeMode, typeTxt = self.VVypGQ, sZA
  else       : typeMode, typeTxt = self.VVtLzk, sAZ
  if   mode in (self.VVyLja, self.VV7bUG): txt = "Name (%s)" % (sAZ if mode == self.VVyLja else sZA)
  elif mode in (self.VVBQ4y, self.VVTLZ5): txt = "Name (%s)" % (s09 if mode == self.VVyLja else s90)
  elif mode in (self.VVqZUB, self.VVtc4P): txt = "Date (%s)" % (sNO if mode == self.VVqZUB else sON)
  elif mode in (self.VVtLzk, self.VVypGQ): txt = "Type (%s)" % (sAZ if mode == self.VVtLzk else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VV66aM(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   CFG.browserSortMode.setValue(mode)
   CFG.browserSortMix.setValue(isMix)
   CFG.browserSortMode.save()
   CFG.browserSortMix.save()
   configfile.save()
  topRow = self.list[0]
  mode = CFG.browserSortMode.getValue()
  isMix = CFG.browserSortMix.getValue()
  if mode in (self.VVyLja, self.VV7bUG):
   rev = True if mode == self.VV7bUG else False
   if isMix: self.list = sorted(self.list[1:], key=lambda x: x[1][7]         , reverse=rev)
   else : self.list = sorted(self.list[1:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
  elif mode in (self.VVBQ4y, self.VVTLZ5):
   rev = True if mode == self.VVTLZ5 else False
   self.list = sorted(self.list[1:], key=FFDsiG(BF(self.VVShsW, isMix, rev)), reverse=rev)
  elif mode in (self.VVqZUB, self.VVtc4P):
   rev = True if mode == self.VVtc4P else False
   self.list = sorted(self.list[1:], key=FFDsiG(BF(self.VVTmQv, isMix)), reverse=rev)
  else:
   rev = True if mode == self.VVypGQ else False
   if isMix: self.list = sorted(self.list[1:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
   else : self.list = sorted(self.list[1:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
  self.list.insert(0, topRow)
  self.l.setList(self.list)
 def VVShsW(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFGmLx(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFyKQV(dir2, dir1) or FFGmLx(name1, name2)
 def VVTmQv(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFyKQV(stat2.st_ctime, stat1.st_ctime)
    else : return FFyKQV(dir2, dir1) or FFyKQV(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCtsQD(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFbZTb(VVM6Ow, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVJXpL   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVZXq4(defFG, "#00FFFFFF")
  self.defBG   = self.VVZXq4(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF2wUT(self, self.Title)
  self["keyRed"].show()
  FF4HaE(self["keyGreen"] , "< > Transp.")
  FF4HaE(self["keyYellow"], "Foreground")
  FF4HaE(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVOivX     ,
   "yellow"  : BF(self.VVNPhx, False)  ,
   "blue"   : BF(self.VVNPhx, True)  ,
   "up"   : self.VVRYLD       ,
   "down"   : self.VVk2gz      ,
   "left"   : self.VVmpQP      ,
   "right"   : self.VVV9jd      ,
   "last"   : BF(self.VVOws0, -5) ,
   "next"   : BF(self.VVOws0, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFQZ4f(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFQZ4f(self["keyRed"] , c)
  FFQZ4f(self["keyGreen"] , c)
  self.VVc9MZ()
  self.VVWn8z()
  FFryZu(self["myColorTst"], self.defFG)
  FFQZ4f(self["myColorTst"], self.defBG)
 def VVZXq4(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVWn8z(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVuJKR(0, 0)
     return
 def VVOivX(self):
  self.close(self.defFG, self.defBG)
 def VVRYLD(self): self.VVuJKR(-1, 0)
 def VVk2gz(self): self.VVuJKR(1, 0)
 def VVmpQP(self): self.VVuJKR(0, -1)
 def VVV9jd(self): self.VVuJKR(0, 1)
 def VVuJKR(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVPMtk()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVkta8()
 def VVc9MZ(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVkta8(self):
  color = self.VVPMtk()
  if self.isBgMode: FFQZ4f(self["myColorTst"], color)
  else   : FFryZu(self["myColorTst"], color)
 def VVNPhx(self, isBg):
  self.isBgMode = isBg
  self.VVc9MZ()
  self.VVWn8z()
 def VVOws0(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVuJKR(0, 0)
 def VV9LPS(self):
  return hex(self.transp)[2:].zfill(2)
 def VVPMtk(self):
  return ("#%s%s" % (self.VV9LPS(), self.colors[self.curRow][self.curCol])).upper()
class CCZd3U(Screen):
 VVMW3S  = 0
 VVAynG = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFCroK()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFbZTb(VVSV74, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60, titleSep=False)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  self.settingsWinBottom = 0
  FF2wUT(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVVoj4)
 def VV1bxJ(self, path=""):
  if path :
   self.VVFeEH()
   FFOvQF(self, BF(self.VVFuzA, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVFuzA()
 def VVFuzA(self, path=""):
  if path:
   subtList, err = self.VV11yF(path)
   if err    : self.VVVoj4(err)
   elif not subtList : self.VVVoj4("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VV9SjG()
  else:
   if self.VVCKHv():
    self.VV9SjG()
   elif self.subtitleMode == CCZd3U.VVAynG:
    self.VVVoj4("noResume")
   else:
    if self.VVGLfl(): self.VV9SjG()
    else         : self.VVVoj4("noAutoSrt")
 def VV9SjG(self):
  CCZd3U.VVPTXb(None)
  FFMnBb(self, "Subtitle started", 1000, isGrn=True)
  self.VVFeEH()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVbhKG)
  except:
   self.timerUpdate.callback.append(self.VVbhKG)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VV0NRJ)
  except:
   self.timerEndText.callback.append(self.VV0NRJ)
  self.VV93rg(True)
 def VVVoj4(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VV93rg(False)
  self.endCallback(res)
 def VV93rg(self, isAdd):
  lst = [CFG.subtDelaySec, CFG.subtBGTransp, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VVFeEH
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except:
      pass
 def VVCKHv(self):
  path = self.VVrDiI()
  if path:
   if fileExists(path):
    lines = FFsCGi(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VV11yF(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelaySec.setValue(int(delay))
      except:
       pass
      return True
  return False
 def VVGLfl(self):
  bestRatio = 0
  fPath, fDir, fName = CC0Jp1.VVtTvV(self)
  if fName:
   movName = os.path.splitext(fName)[0]
   paths = CCZd3U.VV15nZ(self)
   bLst = CCZd3U.VVlyOY(movName, paths, 1, 0.3)
   if bLst:
    subtList, err = self.VV11yF(bLst[0])
    if subtList:
     self.subtList = subtList
     return True
  return False
 def VVAM26(self):
  VVWp2B = []
  if self.lastSubtFile:
   VVWp2B.append(("Settings"        , "setting"  ))
   VVWp2B.append(("Change Subtitle File Encoding"  , "enc"   ))
   VVWp2B.append(("Disable Current Subtitle"    , "disab"  ))
   VVWp2B.append(VVEgY4)
  VVWp2B.extend(CCZd3U.VVYjGj())
  OKBtnFnc = self.VV1bHC
  win = FFkkcl(self, None, VVWp2B=VVWp2B, width=600, VVlOla=26, title="Subtitle Options", OKBtnFnc=OKBtnFnc)
  win.instance.move(ePoint(40, 40))
 def VV1bHC(self, item=None):
  if item:
   menuInstance, txt, ref, ndx = item
   if ref == "setting":
    self["mySubtFr"].show()
    win = self.session.openWithCallback(self.VVEecG, CCaVpe)
    self.settingsWinBottom = win.instance.position().y() + win.instance.size().height() + 10
   elif ref == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFOvQF(menuInstance, BF(CCF2zZ.VVSvbv, menuInstance, self.lastSubtFile, BF(self.VV0p0F, menuInstance), defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else             : FFMnBb(menuInstance, "SRT File error", 1000)
   elif ref == "disab":
    menuInstance.cancel()
    FFu9NF(self.VVrDiI())
    self.VVVoj4("noErr")
   elif ref == "fileMan"   : CCZd3U.VV4LB4(self, True)
   elif ref.startswith("sugSrt") : CCZd3U.VVyCC6(self, self.VVpjUb, defSrt=self.lastSubtFile, pos=1, mode=2, coeff=float(ref[6:]))
   elif ref == "allSrt"   : CCZd3U.VVyCC6(self, self.VVpjUb, defSrt=self.lastSubtFile, pos=1, mode=0)
   elif ref == "curDirSrt"   : CCZd3U.VVyCC6(self, self.VVpjUb, defSrt=self.lastSubtFile, pos=1, mode=1)
 def VVEecG(self, res):
  self["mySubtFr"].hide()
  if res:
   self.VVaH5s()
   self.VVFeEH()
 @staticmethod
 def VVYjGj(addSep=False):
  VVWp2B = []
  VVWp2B.append(("Manual Search (with File Manager)"  , "fileMan" ))
  if addSep: VVWp2B.append(VVEgY4)
  VVWp2B.append(("Suggest srt files (25% similar)"   , "sugSrt0.25" ))
  VVWp2B.append(("Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVWp2B.append(("Suggest srt files (75% similar)"   , "sugSrt0.70" ))
  if addSep: VVWp2B.append(VVEgY4)
  VVWp2B.append(("Find srt Files (in all directories)"  , "allSrt"  ))
  VVWp2B.append(("Find srt Files (in Current Directory)" , "curDirSrt" ))
  return VVWp2B
 @staticmethod
 def VVVySz(SELF):
  VVWp2B = CCZd3U.VVYjGj(True)
  win = FFkkcl(SELF, BF(CCZd3U.VVj7tF, SELF), VVWp2B=VVWp2B, title='Find Subtitle ".srt" File')
 @staticmethod
 def VVj7tF(SELF, item=None):
  if item:
   if   item == "fileMan"   : CCZd3U.VV4LB4(SELF, False)
   elif item.startswith("sugSrt") : CCZd3U.VVyCC6(SELF, BF(CCZd3U.VVtoeS, SELF), mode=2, coeff=float(item[6:]))
   elif item == "allSrt"   : CCZd3U.VVyCC6(SELF, BF(CCZd3U.VVtoeS, SELF), mode=0)
   elif item == "curDirSrt"  : CCZd3U.VVyCC6(SELF, BF(CCZd3U.VVtoeS, SELF), mode=1)
 @staticmethod
 def VVtoeS(SELF, path):
  FFMnBb(SELF)
  if path:
   SELF.VVaTzq(CCZd3U.VVMW3S, useSubtFile=path)
 @staticmethod
 def VV4LB4(SELF, fromSubtMenu):
  if fromSubtMenu : height = 500
  else   : height = 920
  sDir = CFG.lastFileManFindSrt.getValue()
  if not pathExists(sDir): sDir = "/media/"
  if not pathExists(sDir): sDir = "/"
  fileMan = SELF.session.openWithCallback(BF(CCZd3U.VVjjAM, SELF, fromSubtMenu)
            , BF(CC0Jp1, height=height, mode=CC0Jp1.VVsll1, VV4wg8=sDir))
  if fromSubtMenu:
   FFoqGv(fileMan, 40)
 @staticmethod
 def VVjjAM(SELF, fromSubtMenu, path):
  if path:
   if fromSubtMenu : SELF.VVpjUb(path)
   else   : SELF.VVaTzq(CCZd3U.VVMW3S, useSubtFile=path)
   CFG.lastFileManFindSrt.setValue(os.path.dirname(path))
   CFG.lastFileManFindSrt.save()
   configfile.save()
 def VVFeEH(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFI1Fg():
   fnt = VV8NsC
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFryZu(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    bg = int(FFDe6w(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
    for i in range(3):
     FFQZ4f(self["mySubt%d" % i], "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFEiMT(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = max(y, self.settingsWinBottom)
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVpjUb(self, path, enc="utf8"):
  FFMnBb(self)
  self.timerUpdate.stop()
  subtList, err = self.VV11yF(path, enc)
  if err    : FFMnBb(self, err, 2000)
  elif not subtList : FFMnBb(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = enc
   self.currentIndex = 0
   CFG.subtDelaySec.setValue(0)
   for i in range(3):
    FFryZu(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFMnBb(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VV0p0F(self, menuInstance, item=None):
  if item:
   FFOvQF(menuInstance, BF(self.VVpjUb, self.lastSubtFile, item), title="Loading Subtitle ...")
 def VVwHwC(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV11yF(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFHaPS(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFsCGi(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVwHwC(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVaH5s()
  return subtList, ""
 def VVaH5s(self):
  path = self.VVrDiI()
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVrDiI(self):
  fPath, fDir, fName = CC0Jp1.VVtTvV(self)
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(self)
   if iptvRef: fPath = "/tmp/" + chName
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCGnOY.VViAPL(self)
   if evName and evTime and evDur: fPath = "/tmp/" + evName
  if fPath: return fPath + ".ajp"
  else : return ""
 def VVbhKG(self):
  posVal = self.VV7g1h()
  self.VVYktw(posVal)
  if self.currentIndex == -2:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VV0NRJ()
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFryZu(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
        self["mySubt%d" % ndx].show()
        inst = self["mySubt%d" % ndx].instance
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
      self.timerEndText.start(txtDur, True)
 def VV7g1h(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCZilb.VVk80u(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCGnOY.VViAPL(self)
   if evTime and evDur:
    posVal = iTime() - evTime
  return posVal
 def VVYktw(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VV0NRJ(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFryZu(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 @staticmethod
 def VVULYF(SELF, srtList, coeff):
  lst = []
  err = ""
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCGnOY.VViAPL(SELF)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFxnns(SELF)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   lst = CCZd3U.VVlyOY(evName, srtList, 50, coeff)
   if not lst:
    err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 @staticmethod
 def VVlyOY(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   if n == -1:
    n = len(paths)
   files = []
   for ndx, p in enumerate(paths):
    fName = os.path.splitext(os.path.basename(os.path.basename(p)))[0]
    files.append("%d,%s" % (ndx, fName))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst
 @staticmethod
 def VV15nZ(SELF):
  fPath, fDir, fName = CC0Jp1.VVtTvV(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVyCC6(SELF, cbFnc, defSrt="", pos=0, mode=0, coeff=0.25):
  FFOvQF(SELF, BF(CCZd3U.VVv8rl, SELF, cbFnc, defSrt, pos, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVv8rl(SELF, cbFnc, defSrt="", pos=0, mode=0, coeff=0.25):
  FFMnBb(SELF)
  if mode == 1:
   srtList = CCZd3U.VV15nZ(SELF)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FF42E1('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFizMC(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = CCZd3U.VVULYF(SELF, srtList, coeff)
     if err:
      FFMnBb(SELF, err, 1000)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   height = 500 if pos else 900
   VVMGU8 = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFjGgP(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVMGU8.append((fName, Dir))
   VVBh0a  = ("Select"    , BF(CCZd3U.VVdRkP, SELF, cbFnc) , [])
   VV9ZE5 = (""     , CCZd3U.VVyNeG       , [])
   VVaNtS = (""     , BF(CCZd3U.VVvPiG, defSrt, False) , [])
   VV1NOm = ("Find Current File" , BF(CCZd3U.VVvPiG, defSrt, True ) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   VVMsCC = FFGcVX(SELF, None, title=title, header=header, VVJXpL=VVMGU8, height=height, VVQGhe=widths, VVlOla=28, VVBh0a=VVBh0a, VV9ZE5=VV9ZE5, VVaNtS=VVaNtS, VV1NOm=VV1NOm, lastFindConfigObj=CFG.lastFindSubtitle
          , VV89EB="#33001111", VVcV6s="#11002222", VVHzNF="#33001111", VVmD06="#11ffff00", VVhGFp="#11445544", VV3VgO="#22222222", VVGPak="#11002233")
   if pos: FFoqGv(VVMsCC, 40)
  else:
   FFMnBb(SELF, "No srt files found !", 1500)
 @staticmethod
 def VVyNeG(VVMsCC, title, txt, colList):
  fName, Dir = colList
  FFzNhe(VVMsCC, "%s\n\n%s%s" % (FFtSnl("Path:", VVFeau), Dir, fName), title=title)
 @staticmethod
 def VVvPiG(path, VVvNCa, VVMsCC, title, txt, colList):
  for ndx, row in enumerate(VVMsCC.VVy2g3()):
   if path == row[1].strip() + row[0].strip():
    VVMsCC.VVtsKn(ndx)
    break
  else:
   if VVvNCa:
    FFMnBb(VVMsCC, "Not in list !", 1000)
 @staticmethod
 def VVdRkP(SELF, cbFnc, VVMsCC, title, txt, colList):
  VVMsCC.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  FFOvQF(SELF, BF(cbFnc, path), "Loading Subtitle ...", clearMsg=False)
 @staticmethod
 def VVslnk():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVPTXb(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCZd3U.VVZNMm()
 @staticmethod
 def VVZNMm():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCaVpe(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFbZTb(VV0IRp, 700, 600, 40, 30, 10, "#11331010", "#11442020", 28, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FF2wUT(self, title=self.Title)
  FF4HaE(self["keyRed"] , "Exit")
  FF4HaE(self["keyGreen"] , "Save")
  FF4HaE(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)"  , CFG.subtDelaySec  ))
  self.confList.append(getConfigListEntry(VVJ1qT *2      ,       ))
  self.confList.append(getConfigListEntry("Background Transparency %" , CFG.subtBGTransp  ))
  self.confList.append(getConfigListEntry("Text Color"    , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"     , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"     , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"     , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"    , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"    , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVJ1qT *2      ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"    , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVsi0e  ,
   "green"   : self.VVQXyx   ,
   "yellow"  : self.VVygzl ,
   "menu"   : self.VVvisU ,
   "cancel"  : self.VVsi0e
  }, -1)
  self.onShown.append(self.VV5WGz)
 def VV5WGz(self):
  self.onShown.remove(self.VV5WGz)
  FFGCUP(self)
  FFysS0(self["config"])
  FFMyEE(self, self["config"])
  FFLvNc(self)
  self.instance.move(ePoint(40, 40))
 def VVvisU(self):
  VVWp2B = []
  VVWp2B.append(("Reset Delay"    , "resetDel" ))
  VVWp2B.append(("Reset Subtitle Settings" , "resetAll" ))
  win = FFkkcl(self, self.VVN0pQ, VVWp2B=VVWp2B, title="Subtitle Settings Option", width=600)
  win.instance.move(ePoint(40, 40))
 def VVN0pQ(self, item=None):
  if item:
   if   item == "resetDel"  : CFG.subtDelaySec.setValue(0)
   elif item == "resetAll"  : self.VVygzl()
 def VVsi0e(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     win = FFm5Au(self, self.VVQXyx, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     FFoqGv(win, 200)
     break
   except:
    pass
  else:
   self.cancel()
 def VVQXyx(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVygzl(self):
  FFm5Au(self, self.VVtoud, "Reset Subtitle Settings to default ?", title="Subtitle Settings")
 def VVtoud(self):
  CFG.subtDelaySec.setValue(0)
  CFG.subtBGTransp.setValue(100)
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VV8NsC)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVQXyx()
class CCvFYC(ScrollLabel):
 def __init__(self, parentSELF, text="", VVRKOR=True):
  ScrollLabel.__init__(self, text)
  self.VVRKOR   = VVRKOR
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VV6vEh  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVlOla    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVP8is ,
   "green"   : self.VVXzBT ,
   "yellow"  : self.VV6kVw ,
   "blue"   : self.VVx2g2 ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VVB54O, 0) ,
   "0"    : BF(self.VVB54O, 1) ,
   "next"   : BF(self.VVB54O, 2) ,
   "pageUp"  : self.VVQ4Y9   ,
   "chanUp"  : self.VVQ4Y9   ,
   "pageDown"  : self.VVtjM8   ,
   "chanDown"  : self.VVtjM8
  }, -1)
 def VVVQK5(self, isResizable=True, VVW7PG=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFryZu(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFQZ4f(self.parentSELF["keyRedTop"], "#113A5365")
  FFLvNc(self.parentSELF, True)
  self.isResizable = isResizable
  if VVW7PG:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVlOla  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFQZ4f(self, color)
 def VVSdvO(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV6vEh - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVZmkM()
 def pageUp(self):
  if self.VV6vEh > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV6vEh > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVQ4Y9(self):
  self.setPos(0)
 def VVtjM8(self):
  self.setPos(self.VV6vEh-self.pageHeight)
 def VVcS5o(self):
  return self.VV6vEh <= self.pageHeight or self.curPos == self.VV6vEh - self.pageHeight
 def getText(self):
  return self.message
 def VVZmkM(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV6vEh, 3))
   start = int((100 - vis) * self.curPos / (self.VV6vEh - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVwvtK=VVebGP):
  old_VVcS5o = self.VVcS5o()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VV6vEh = self.long_text.calculateSize().height()
   if self.VVRKOR and self.VV6vEh > self.pageHeight:
    self.scrollbar.show()
    self.VVZmkM()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV6vEh))
   if   VVwvtK == VVxPlb: self.setPos(0)
   elif VVwvtK == VVs2cN : self.VVtjM8()
   elif old_VVcS5o    : self.VVtjM8()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVwvtK=VVwvtK)
 def appendText(self, text, VVwvtK=VVs2cN):
  self.setText(self.message + str(text), VVwvtK=VVwvtK)
 def VV6kVw(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVA19X(size)
 def VVx2g2(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVA19X(size)
 def VVXzBT(self):
  self.VVA19X(self.VVlOla)
 def VVA19X(self, VVlOla):
  self.long_text.setFont(gFont(self.fontFamily, VVlOla))
  self.setText(self.message, VVwvtK=VVebGP)
  self.VVr1fk(calledFromFontSizer=True)
 def VVB54O(self, align):
  self.long_text.setHAlign(align)
 def VVP8is(self):
  VVWp2B = []
  VVWp2B.append(("%s Wrapping" % ("Enable" if self.long_text.getNoWrap() else "Disable"), "wrap" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Align Left"  , "left" ))
  VVWp2B.append(("Align Center"  , "center" ))
  VVWp2B.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVWp2B.append(VVEgY4)
   VVWp2B.append((FFtSnl("Save to File", VVFeau), "save" ))
  VVWp2B.append(VVEgY4)
  VVWp2B.append(("Keys (Shortcuts)" , "help" ))
  FFkkcl(self.parentSELF, self.VVcKmy, VVWp2B=VVWp2B, title="Text Option", width=500)
 def VVcKmy(self, item=None):
  if item:
   if   item == "wrap"  : self.long_text.setNoWrap(not self.long_text.getNoWrap())
   elif item == "left"  : self.VVB54O(0)
   elif item == "center" : self.VVB54O(1)
   elif item == "right" : self.VVB54O(2)
   elif item == "save"  : self.VVsBvB()
   elif item == "help"  : FFXRcG(self.parentSELF, VVE4he + "_help_txt", "Player Controller (Keys)")
 def VVsBvB(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFjGgP(expPath), self.outputFileToSave, FF03bo())
   with open(outF, "w") as f:
    f.write(FFYfxZ(self.message))
   FFO5iz(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFNkji(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVr1fk(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV6vEh > 0 and self.pageHeight > 0:
   if self.VV6vEh < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV6vEh
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
